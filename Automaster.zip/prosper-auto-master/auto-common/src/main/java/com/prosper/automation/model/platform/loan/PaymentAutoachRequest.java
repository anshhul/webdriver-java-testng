package com.prosper.automation.model.platform.loan;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author sphatak
 *
 */
public class PaymentAutoachRequest {

	@JsonProperty("bank_routing_number")
	private String bankRoutingNumber;
	@JsonProperty("bank_account_number")
	private String bankAccountNumber;
	@JsonProperty("auto_ach")
	private Boolean autoAch;
	@JsonProperty("source")
	private String source;
	@JsonProperty("financial_institution_name")
	private String financialInstitutionName;
	@JsonProperty("bank_account_type")
	private String bankAccountType;
	@JsonProperty("monthly_due_date")
	private Integer monthlyDueDate;

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public Boolean getAutoAch() {
		return autoAch;
	}

	public void setAutoAch(Boolean autoAch) {
		this.autoAch = autoAch;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getFinancialInstitutionName() {
		return financialInstitutionName;
	}

	public void setFinancialInstitutionName(String financialInstitutionName) {
		this.financialInstitutionName = financialInstitutionName;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public Integer getMonthlyDueDate() {
		return monthlyDueDate;
	}

	public void setMonthlyDueDate(Integer monthlyDueDate) {
		this.monthlyDueDate = monthlyDueDate;
	}

	public static class PaymentAutoachRequestBuilder {
		private String bankRoutingNumber;
		private String bankAccountNumber;
		private Boolean autoAch;
		private String source;
		private String financialInstitutionName;
		private String bankAccountType;
		private Integer monthlyDueDate;

		public PaymentAutoachRequest builder() {
			PaymentAutoachRequest result = new PaymentAutoachRequest();
			result.setAutoAch(autoAch);
			result.setBankAccountNumber(bankAccountNumber);
			result.setBankRoutingNumber(bankRoutingNumber);
			result.setSource(source);
			result.setFinancialInstitutionName(financialInstitutionName);
			result.setBankAccountType(bankAccountType);
			result.setBankAccountNumber(bankAccountNumber);
			result.setMonthlyDueDate(monthlyDueDate);
			return result;
		}

		public PaymentAutoachRequestBuilder BankRoutingNumber(
				String bankRoutingNumber) {
			this.bankRoutingNumber = bankRoutingNumber;
			return this;
		}

		public PaymentAutoachRequestBuilder bankAccountNumber(
				String bankAccountNumber) {
			this.bankAccountNumber = bankAccountNumber;
			return this;
		}

		public PaymentAutoachRequestBuilder autoAch(Boolean autoAch) {
			this.autoAch = autoAch;
			return this;
		}

		public PaymentAutoachRequestBuilder source(String source) {
			this.source = source;
			return this;

		}

		public PaymentAutoachRequestBuilder financialInstitutionName(
				String financialInstitutionName) {
			this.financialInstitutionName = financialInstitutionName;
			return this;
		}

		public PaymentAutoachRequestBuilder bankAccountType(
				String bankAccountType) {
			this.bankAccountType = bankAccountType;
			return this;
		}

		public PaymentAutoachRequestBuilder monthlyDueDate(
				Integer monthlyDueDate) {
			this.monthlyDueDate = monthlyDueDate;
			return this;
		}

	}
}
