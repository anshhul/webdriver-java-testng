
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public final class SlpAllocationConfig {

    @JsonProperty("config_property_name")
    private String configPropertyName;

    @JsonProperty("config_property_value")
    private String configPropertyValue;
    
    
    /**
     *
     * CLASS / TYPE DESCRIPTION GOES HERE.
     *
     * @author pchaturvedi
     */

    public static class SlpAllocationConfigBuilder {
        
        private String configPropertyName;
        private String configPropertyValue;


        /**
         * @return
         */
        public SlpAllocationConfig build() {
            final SlpAllocationConfig result = new SlpAllocationConfig();

            result.setConfigPropertyName(configPropertyName);
            result.setConfigPropertyValue(configPropertyValue);
            return result;
        }

        /**
         *
         * @param value
         * @return
         */
        /**
         * @param value
         * @return
         */
        public SlpAllocationConfigBuilder configPropertyName(final String value) {
            this.configPropertyName = value;
            return this;
        }

        /**
         * @param value
         * @return
         */
        public SlpAllocationConfigBuilder configPropertyValue(final String value) {
            this.configPropertyValue = value;
            return this;
        }
    }
    
    
    /**
     * @param original
     * @return
     */
    public static SlpAllocationConfigBuilder buildUpon(final SlpAllocationConfig original) {
        final SlpAllocationConfigBuilder builder = newBuilder();
        builder.configPropertyName(original.getConfigPropertyName());
        builder.configPropertyValue(original.getConfigPropertyValue());
        return builder;
    }

    /**
     * @return
     */
    public static SlpAllocationConfigBuilder newBuilder() {
        return new SlpAllocationConfigBuilder();
    }

    /**
     * @return
     */
    public String getConfigPropertyName() {
        return configPropertyName;
    }
    
    /**
     * @return
     */
    public String getConfigPropertyValue() {
        return configPropertyValue;
    }
    
    /**
     * @param configPropertyName
     */
    public void setConfigPropertyName(final String configPropertyName) {
        this.configPropertyName = configPropertyName;
    }
    
    /**
     * @param configPropertyValue
     */
    public void setConfigPropertyValue(final String configPropertyValue) {
        this.configPropertyValue = configPropertyValue;
    }

}
