package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

import java.util.List;

/**
 * Created by aamalraj on 12/21/15.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder({"email"}) public final class RegisteredUserContactInfo {

    @JsonProperty("email") private String email;

    public RegisteredUserContactInfo() {
    }

    public RegisteredUserContactInfo(final String email) {
        this.email = email;
    }

    private RegisteredUserContactInfo(final Builder builder) {
        email = builder.email;
    }

    /**
     * @return The email
     */
    public String getEmail() {
        return email;
    }

    public void setEmail(final String email) {
        this.email = email;
    }

    @Override public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegisteredUserContactInfo that = (RegisteredUserContactInfo) o;
        return Objects.equal(email, that.email);
    }

    public static final class Builder {

        private List<PhoneNumber> phoneNumbers;
        private String email;

        public Builder() {
        }

        public Builder withEmail(final String email) {
            this.email = email;
            return this;
        }

        public RegisteredUserContactInfo build() {
            return new RegisteredUserContactInfo(this);
        }
    }
}
