package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by pbudiono on 9/8/16.
 */
public class ScoreFactorResponseDTO {

    @JsonProperty("factor")
    private List<FactorResponseDTO> factor;
}
