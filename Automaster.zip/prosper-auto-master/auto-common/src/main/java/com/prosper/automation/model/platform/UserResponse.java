
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UserResponse {
    
    private static final String USER_RESPONSE_CSV_TEMPLATE = "%s,%s";
    
    @JsonProperty("userRequest")
    private UserRequest userRequest;

    public UserRequest getUserRequest() {
        return userRequest;
    }
    
    @Override
    public String toString() {
        return String.format(USER_RESPONSE_CSV_TEMPLATE, userRequest.getUserId(),
                userRequest.getUserContactInfo().getEmail());
    }

    @JsonIgnore
    public String getUserEmail() {
        return userRequest.getUserEmail();
    }
}
