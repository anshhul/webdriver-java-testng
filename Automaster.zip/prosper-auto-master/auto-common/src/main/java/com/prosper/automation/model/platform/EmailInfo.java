
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Date;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"userID", "toAddress", "fromAddress", "subject", "creationDate", "userRead", "archived", "showOnSite",
        "modifiedDate", "messageID"})
public final class EmailInfo {
    
    @JsonProperty("userID")
    private Long userId;
    @JsonProperty("toAddress")
    private String toAddress;
    @JsonProperty("fromAddress")
    private String fromAddress;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("creationDate")
    private Date creationDate;
    @JsonProperty("userRead")
    private Boolean userRead;
    @JsonProperty("archived")
    private Boolean archived;
    @JsonProperty("showOnSite")
    private Boolean showOnSite;
    @JsonProperty("modifiedDate")
    private Date modifiedDate;
    @JsonProperty("messageID")
    private Long messageId;
    
    
    @JsonIgnore
    public Long getUserId() {
        return userId;
    }
    
    @JsonIgnore
    public String getToAddress() {
        return toAddress;
    }
    
    @JsonIgnore
    public String getFromAddress() {
        return fromAddress;
    }
    
    @JsonIgnore
    public String getSubject() {
        return subject;
    }
    
    @JsonIgnore
    public Date getCreationDate() {
        return creationDate;
    }
    
    @JsonIgnore
    public Boolean getUserRead() {
        return userRead;
    }
    
    @JsonIgnore
    public Boolean getArchived() {
        return archived;
    }
    
    @JsonIgnore
    public Boolean getShowOnSite() {
        return showOnSite;
    }
    
    @JsonIgnore
    public Date getModifiedDate() {
        return modifiedDate;
    }
    
    @JsonIgnore
    public Long getMessageId() {
        return messageId;
    }
    
}
