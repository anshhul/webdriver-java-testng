
package com.prosper.automation.constant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class TestConstant {
    
    public static final String DATA_PROVIDER_THREAD_COUNT_STRING = "dataproviderthreadcount";
    
    
    private TestConstant() {
    }
}
