
package com.prosper.automation.model.platform.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by pbudiono on 7/29/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class EmailMessageTemplate {

	@JsonProperty("message_template_key")
	private String messageTemplateKey;
	@JsonProperty("message_template_code")
	private String messageTemplateCode;
	@JsonProperty("template_description")
	private String templateDescription;
	@JsonProperty("template_content")
	private String templateContent;
	@JsonProperty("template_subject")
	private String templateSubject;
	@JsonProperty("is_shown_on_public_site")
	private Boolean isShownOnPublicSite;
	@JsonProperty("is_sent_externally")
	private Boolean isSentExternally;
	@JsonProperty("is_active")
	private Boolean isActive;
	@JsonProperty("delivery_type_code")
	private String deliveryTypeCode;
	@JsonProperty("content_type_code")
	private String contentTypeCode;

	public EmailMessageTemplate() {
	}
	private EmailMessageTemplate(Builder builder) {
		messageTemplateKey = builder.messageTemplateKey;
		messageTemplateCode = builder.messageTemplateCode;
		templateDescription = builder.templateDescription;
		templateContent = builder.templateContent;
		templateSubject = builder.templateSubject;
		isShownOnPublicSite = builder.isShownOnPublicSite;
		isSentExternally = builder.isSentExternally;
		isActive = builder.isActive;
		deliveryTypeCode = builder.deliveryTypeCode;
		contentTypeCode = builder.contentTypeCode;
	}

	@JsonIgnore
	public String getMessageTemplateCode() {
		return messageTemplateCode;
	}

	@JsonIgnore
	public String getTemplateDescription() {
		return templateDescription;
	}

	@JsonIgnore
	public String getTemplateContent() {
		return templateContent;
	}

	@JsonIgnore
	public String getTemplateSubject() {
		return templateSubject;
	}

	@JsonIgnore
	public Boolean getShownOnPublicSite() {
		return isShownOnPublicSite;
	}

	@JsonIgnore
	public Boolean getSentExternally() {
		return isSentExternally;
	}

	@JsonIgnore
	public Boolean getActive() {
		return isActive;
	}

	@JsonIgnore
	public String getDeliveryTypeCode() {
		return deliveryTypeCode;
	}

	public void setDeliveryTypeCode(String deliveryTypeCode) {
		this.deliveryTypeCode = deliveryTypeCode;
	}

	@JsonIgnore
	public String getContentTypeCode() {
		return contentTypeCode;
	}

	public void setContentTypeCode(String contentTypeCode) {
		this.contentTypeCode = contentTypeCode;
	}

	@JsonIgnore
	public String getMessageTemplateKey() {
		return messageTemplateKey;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		EmailMessageTemplate that = (EmailMessageTemplate) o;
		return Objects.equal(messageTemplateCode, that.messageTemplateCode)
				&& Objects.equal(templateDescription, that.templateDescription)
				&& Objects.equal(templateContent, that.templateContent) && Objects.equal(templateSubject, that.templateSubject)
				&& Objects.equal(isShownOnPublicSite, that.isShownOnPublicSite)
				&& Objects.equal(isSentExternally, that.isSentExternally) && Objects.equal(isActive, that.isActive)
				&& Objects.equal(deliveryTypeCode, that.deliveryTypeCode) && Objects.equal(contentTypeCode, that.contentTypeCode);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(messageTemplateKey, messageTemplateCode, templateDescription, templateContent, templateSubject,
				isShownOnPublicSite, isSentExternally, isActive, deliveryTypeCode, contentTypeCode);
	}

	public void setMessageTemplateCode(String messageTemplateCode) {
		this.messageTemplateCode = messageTemplateCode;
	}

	public static final class Builder {

		private String messageTemplateKey;
		private String messageTemplateCode;
		private String templateDescription;
		private String templateContent;
		private String templateSubject;
		private Boolean isShownOnPublicSite;
		private Boolean isSentExternally;
		private Boolean isActive;
		private String deliveryTypeCode;
		private String contentTypeCode;

		public Builder() {
		}

		public Builder withMessageTemplateKey(String val) {
			messageTemplateKey = val;
			return this;
		}

		public Builder withMessageTemplateCode(String val) {
			messageTemplateCode = val;
			return this;
		}

		public Builder withTemplateDescription(String val) {
			templateDescription = val;
			return this;
		}

		public Builder withTemplateContent(String val) {
			templateContent = val;
			return this;
		}

		public Builder withTemplateSubject(String val) {
			templateSubject = val;
			return this;
		}

		public Builder withIsShownOnPublicSite(Boolean val) {
			isShownOnPublicSite = val;
			return this;
		}

		public Builder withIsSentExternally(Boolean val) {
			isSentExternally = val;
			return this;
		}

		public Builder withIsActive(Boolean val) {
			isActive = val;
			return this;
		}

		public Builder withDeliveryTypeCode(String val) {
			deliveryTypeCode = val;
			return this;
		}

		public Builder withContentTypeCode(String val) {
			contentTypeCode = val;
			return this;
		}

		public EmailMessageTemplate build() {
			return new EmailMessageTemplate(this);
		}
	}
}
