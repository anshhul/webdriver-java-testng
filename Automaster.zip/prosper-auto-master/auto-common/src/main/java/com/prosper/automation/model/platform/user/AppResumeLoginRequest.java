package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by ppatil on 11/5/16.
 */

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AppResumeLoginRequest {

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("year_of_birth")
    private String yearOfBirth;

    @JsonProperty("zip_code")
    private String zipCode;

    @JsonProperty("ssn")
    private String ssn;

    public AppResumeLoginRequest() {
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(String yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    private AppResumeLoginRequest (final Builder builder){
        lastName = builder.lastName;
        yearOfBirth = builder.yearOfBirth;
        zipCode = builder.zipCode;
        ssn = builder.ssn;

    }


    public static final class Builder {

        private String lastName;
        private String yearOfBirth;
        private String zipCode;
        private String ssn;

        public Builder() {
        }

        public Builder withLastName(final String lastName) {
            this.lastName =lastName;
            return this;
        }

        public Builder withYearOfBirth(final String yearOfBirth) {
            this.yearOfBirth = yearOfBirth;
            return this;
        }

        public Builder withZipCode(final String zipCode) {
            this.zipCode =zipCode;
            return this;
        }

        public Builder withSSN(final String ssn) {
            this.ssn =ssn;
            return this;
        }



        public AppResumeLoginRequest build() {
            return new AppResumeLoginRequest(this);
        }
    }
}
