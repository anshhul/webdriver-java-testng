
package com.prosper.automation.model.testdata;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class TUUserInformation {

    private String firstName;
    private String middleName;
    private String prefix;
    private String suffix;


    private TUUserInformation(Builder builder) {
        setFirstName(builder.firstName);
        setMiddleName(builder.middleName);
        setPrefix(builder.prefix);
        setSuffix(builder.suffix);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }


    public static final class Builder {

        private String firstName;
        private String middleName;
        private String prefix;
        private String suffix;


        public Builder() {
        }

        public Builder withFirstName(String val) {
            firstName = val;
            return this;
        }

        public Builder withMiddleName(String val) {
            middleName = val;
            return this;
        }

        public Builder withPrefix(String val) {
            prefix = val;
            return this;
        }

        public Builder withSuffix(String val) {
            suffix = val;
            return this;
        }

        public TUUserInformation build() {
            return new TUUserInformation(this);
        }
    }
}
