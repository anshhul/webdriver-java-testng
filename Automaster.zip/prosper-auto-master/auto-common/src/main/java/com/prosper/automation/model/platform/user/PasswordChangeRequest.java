
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PasswordChangeRequest {
    
    @JsonProperty("oldPassword")
    private String oldPassword;
    
    @JsonProperty("newPassword")
    private String newPassword;
    
    
    public PasswordChangeRequest() {
    }
    
    private PasswordChangeRequest(final Builder builder) {
        oldPassword = builder.oldPassword;
        newPassword = builder.newPassword;
    }

    public void setNewPassword(final String newPassword) {
        this.newPassword = newPassword;
    }


    public static final class Builder {
        
        private String oldPassword;
        private String newPassword;
        
        
        public Builder() {
        }
        
        public Builder withOldPassword(final String oldPassword) {
            this.oldPassword = oldPassword;
            return this;
        }
        
        public Builder withNewPassword(final String newPassword) {
            this.newPassword = newPassword;
            return this;
        }
        
        public PasswordChangeRequest build() {
            return new PasswordChangeRequest(this);
        }
    }
}
