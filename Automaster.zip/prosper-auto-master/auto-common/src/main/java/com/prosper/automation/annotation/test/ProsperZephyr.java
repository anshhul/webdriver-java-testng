
package com.prosper.automation.annotation.test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 * Interface to hold test case details
 *
 * @author Prateek
 */
@Inherited
@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface ProsperZephyr {

    String project() default "QE";

    String ticketId() default "";

    String ticketNumber() default "";

    String priority() default "P1";

    String[]labels() default {};

    String[]stepToTests() default {};

    String expectedResult() default "";

    int[]jiraId() default {};

    String testTitle() default "";
}
