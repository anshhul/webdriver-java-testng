
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class TUCreditReportRequest {

    @JsonProperty("address")
    private AddressRequestDTO address;
    @JsonProperty("person_name")
    private PersonNameRequestDTO personName;
    @JsonProperty("social_security_number")
    private SocialSecurityRequestDTO socialSecurity;
    @JsonProperty("date_of_birth")
    private String dateOfBirth;


    public TUCreditReportRequest() {
    }

    private TUCreditReportRequest(Builder builder) {
        setAddress(builder.address);
        setPersonName(builder.personName);
        setSocialSecurity(builder.socialSecurity);
        setDateOfBirth(builder.dateOfBirth);
    }

    @JsonIgnore
    public AddressRequestDTO getAddress() {
        return address;
    }

    public void setAddress(AddressRequestDTO address) {
        this.address = address;
    }

    @JsonIgnore
    public PersonNameRequestDTO getPersonName() {
        return personName;
    }

    public void setPersonName(PersonNameRequestDTO personName) {
        this.personName = personName;
    }

    @JsonIgnore
    public SocialSecurityRequestDTO getSocialSecurity() {
        return socialSecurity;
    }

    public void setSocialSecurity(SocialSecurityRequestDTO socialSecurity) {
        this.socialSecurity = socialSecurity;
    }

    @JsonIgnore
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }


    public static final class Builder {

        private AddressRequestDTO address;
        private PersonNameRequestDTO personName;
        private SocialSecurityRequestDTO socialSecurity;
        private String dateOfBirth;


        public Builder() {
        }

        public Builder withAddress(AddressRequestDTO val) {
            address = val;
            return this;
        }

        public Builder withPersonName(PersonNameRequestDTO val) {
            personName = val;
            return this;
        }

        public Builder withSocialSecurity(SocialSecurityRequestDTO val) {
            socialSecurity = val;
            return this;
        }

        public Builder withDateOfBirth(String val) {
            dateOfBirth = val;
            return this;
        }

        public TUCreditReportRequest build() {
            return new TUCreditReportRequest(this);
        }
    }
}
