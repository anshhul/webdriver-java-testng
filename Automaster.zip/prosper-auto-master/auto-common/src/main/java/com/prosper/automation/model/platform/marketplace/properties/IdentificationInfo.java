package com.prosper.automation.model.platform.marketplace.properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class IdentificationInfo {

    @JsonProperty("partner_source_code")
    private String partnerSourceCode;

    @JsonProperty("client_reference_id")
    private String clientReferenceId;

    @JsonProperty("provider_third_party_id")
    private String providerThirdPartyId;


    public IdentificationInfo() {
    }

    private IdentificationInfo(Builder builder) {
        partnerSourceCode = builder.partnerSourceCode;
        clientReferenceId = builder.clientReferenceId;
        providerThirdPartyId = builder.providerThirdPartyId;
    }

    public String getPartnerSourceCode() {
        return partnerSourceCode;
    }

    public String getClientReferenceId() {
        return clientReferenceId;
    }

    @Override
    public String toString() {
        return "IdentificationInfo{" +
                "partnerSourceCode='" + partnerSourceCode + '\'' +
                ", clientReferenceId='" + clientReferenceId + '\'' +
                '}';
    }


    public static class Builder {

        private String partnerSourceCode;
        private String clientReferenceId;
        private String providerThirdPartyId;


        public Builder() {
        }

        public Builder withPartnerSourceCode(String val) {
            partnerSourceCode = val;
            return this;
        }

        public Builder withClientReferenceId(String val) {
            clientReferenceId = val;
            return this;
        }

        public Builder withProviderThirdPartyId(String val) {
            providerThirdPartyId = val;
            return this;
        }

        public IdentificationInfo build() {
            return new IdentificationInfo(this);
        }
    }
}
