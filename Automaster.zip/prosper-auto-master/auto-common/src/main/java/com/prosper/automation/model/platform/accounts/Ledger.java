
package com.prosper.automation.model.platform.accounts;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 *
 * @Description: Account Ledger
 * @author agarg
 */

public final class Ledger {

    @JsonProperty("money_in")
    private MoneyIn MONEY_IN;

    @JsonProperty("money_out")
    private MoneyOut MONEY_OUT;


    public MoneyIn getMONEY_IN() {
        return MONEY_IN;
    }

    public void setMONEY_IN(MoneyIn mONEY_IN) {
        MONEY_IN = mONEY_IN;
    }

    public MoneyOut getMONEY_OUT() {
        return MONEY_OUT;
    }

    public void setMONEY_OUT(MoneyOut mONEY_OUT) {
        MONEY_OUT = mONEY_OUT;
    }




}
