package com.prosper.automation.model.platform.marketplace.util;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public enum ResponseErrorsHelper {
    MISSING_PARTNER_SOURCE_CODE("MKTPL-1001", "The partner source code is missing.", "MKTPL-1001", "The partner source code is missing."),
    INVALID_PARTNER_SOURCE_CODE("MKTPL-1004",
            "Unauthorized access, the submitted partner source code is invalid (either expired or incorrect).", "MKTPL-1004",
            "Unauthorized access, the submitted partner source code is invalid (either expired or incorrect)."),
    LOAN_AMOUNT_NULL_OR_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-101",
            "Loan amount is null or empty, and is required to generate an offer."),
    LOAN_AMOUNT_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-102",
            "Loan amount \\[decimal\\] [\\\\(].*[\\\\)]* is not a valid format."),
    LOAN_AMOUNT_LESS_THAN_ALLOWED("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-103",
            "Requested loan amount [\\\\(].*[\\\\)]* is less than the Prosper minimum [\\\\(].*[\\\\)]*."),
    LOAN_AMOUNT_MORE_THAN_ALLOWED("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-104",
            "Requested loan amount [\\\\(].*[\\\\)]* is greater than the Prosper maximum [\\\\(].*[\\\\)]*."),
    LOAN_PURPOSE_ID_NOT_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-111",
            "Loan purpose id is null or empty, and is required to generate an offer."),
    LOAN_PURPOSE_ID_NOT_INTEGER("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-112",
            "Loan purpose id must be an integer value: .*. Refer to the documentation for acceptable values."),
    LOAN_PURPOSE_ID_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-112",
            "Loan purpose id is not a valid value: .*. Refer to the documentation for acceptable values."),
    CREDIT_SCORE_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-121",
            "Self reported credit score is null or empty, and is required to generate an offer."),
    CREDIT_SCORE_NOT_INTEGER("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-122",
            "Self reported credit score must be an integer value: .*. Refer to the documentation for acceptable values."),
    CREDIT_SCORE_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-123",
            "Self reported credit score is not a valid value: .*. Refer to the documentation for acceptable values."),
    NAME_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-131",
            "Name is null or empty, and is required to generate an offer."),
    FIRST_NAME_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-141",
            "First name is null or empty, and is required to generate an offer."),
    FIRST_NAME_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-142",
            "First name [\\\\(].*[\\\\)]*, is not a valid format."),
    LAST_NAME_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-151",
            "Last name is null or empty, and is required to generate an offer."),
    LAST_NAME_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-152",
            "Last name [\\\\(].*[\\\\)]*, is not a valid format."),
    MIDDLE_INITIAL_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-161",
            "Middle initial can only contain a single-letter character [\\\\(].*[\\\\)]* not a valid format."),
    DOB_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-171",
            "Date of birth is null or empty, and is required to generate an offer."),
    DOB_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-172",
            "Date of birth is not a date value: .*."),
    INVALID_AGE_REQUIREMENT("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-173",
            "The applicant does not meet the minimum age requirement."),
    SSN_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-181",
            "Enter a valid 9 digit social security number."),
    ADDRESS_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-191",
            "Address is null or empty, and is required to generate an offer."),
    STREET_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-201",
            "Street is null or empty, and is required to generate an offer."),
    PO_BOX_ERROR("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-202",
            "Applicant's address can not contain a PO Box."),
    CITY_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-211",
            "City is null or empty, and is required to generate an offer."),
    STATE_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-221",
            "State is null or empty, and is required to generate an offer. The state must be a two character code."),
    STATE_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-222",
            "State contains invalid characters, and is required to generate an offer. The state must be a two character code."),
    ZIPCODE_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-231",
            "Zipcode is null or empty, and is required to generate an offer."),
    ZIPCODE_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-232",
            "Zipcode format is not valid, and is required to generate an offer. Prosper accepts a 5 digit or 5 \\+ 4 zipcode format."),
    EMAIL_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-242",
            "Email address is null or empty, and is required to generate an offer."),
    EMAIL_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-243",
            "Applicant's email address is not in a valid format."),
    EMP_STATUS_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-281",
            "Employment status id is null or empty, and is required to generate an offer."),
    EMP_MONTH_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-261",
            "Employment month contains invalid characters, and is required to generate an offer."),
    EMP_YEAR_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-271",
            "Employment year contains invalid characters, and is required to generate an offer."),
    EMP_STATUS_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-282",
            "Employment status id must be a valid integer value \\(Self-employed = 3; Not employed = 5; Other = 6; Employed = 7\\): .*"),
    YEARLY_INCOME_NULL_EMPTY("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-291",
            "Yearly income is null or empty, and is required to generate an offer."),
    YEARLY_INCOME_INVALID("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-292",
            "Yearly income [decimal] [\\\\(].*[\\\\)]* is not a valid format."),
    YEARLY_INCOME_EXCEEDS_MAX("MKTPL-1012", TestDataProviderUtil.VALIDATION_ERRORS_COMMON_MESSAGE, "MKTPL-1012-293",
            "Yearly income amount [\\\\(].*(\\\\.)?.*[\\\\)]* exceeds the Prosper maximum amount."),
    NO_MATCHING_OFFERS("MKTPL-1009", "Based on the information presented, Prosper could not find any matching offers.",
            "MKTPL-1009", "Based on the information presented, Prosper could not find any matching offers."),
    UNSUPPORTED_STATE("MKTPL-1007", "Prosper does not conduct business in the state where the applicant resides.",
                               "MKTPL-1007", "Prosper does not conduct business in the state where the applicant resides."),
    MIN_LOAN_STATE("MKTPL-1008", "The amount requested exceeds Prosper's limits for the state where the applicant resides.",
                              "MKTPL-1008", "The amount requested exceeds Prosper's limits for the state where the applicant resides.");

    private final String mainErrorsCode;
    private final String mainErrorsMessage;
    private final String code;
    private final String message;

    ResponseErrorsHelper(String mainErrorsCode, String mainErrorsMessage, String code, String message) {
        this.mainErrorsCode = mainErrorsCode;
        this.mainErrorsMessage = mainErrorsMessage;
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public String getMainErrorsCode() {
        return mainErrorsCode;
    }

    public String getMainErrorsMessage() {
        return mainErrorsMessage;
    }

    public String toString() {
        return this.message;
    }
}
