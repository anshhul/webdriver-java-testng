
package com.prosper.automation.model.platform.email;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 7/24/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UpdateEmailMessage {

    @JsonProperty("is_user_read")
    private Boolean isUserRead;
    @JsonProperty("is_deleted")
    private Boolean isDeleted;
    @JsonProperty("is_shown_on_public_site")
    private Boolean isShowOnPublicSite;


    private UpdateEmailMessage(Builder builder) {
        isUserRead = builder.isUserRead;
        isDeleted = builder.isDeleted;
        isShowOnPublicSite = builder.isShowOnPublicSite;
    }


    public static final class Builder {

        private Boolean isUserRead;
        private Boolean isDeleted;
        private Boolean isShowOnPublicSite;


        public Builder() {
        }

        public Builder withIsUserRead(Boolean val) {
            isUserRead = val;
            return this;
        }

        public Builder withIsDeleted(Boolean val) {
            isDeleted = val;
            return this;
        }

        public Builder withIsShowOnPublicSite(Boolean val) {
            isShowOnPublicSite = val;
            return this;
        }

        public UpdateEmailMessage build() {
            return new UpdateEmailMessage(this);
        }
    }
}
