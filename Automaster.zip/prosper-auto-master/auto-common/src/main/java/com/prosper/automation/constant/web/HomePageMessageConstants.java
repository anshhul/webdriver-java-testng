package com.prosper.automation.constant.web;

/**
 * Created by ppatil on 5/22/16.
 */
public class HomePageMessageConstants {

    public static final String PROSPER_DAILY = "Prosper Daily";
    public static final String LOAN_INFORMATION = "Loan Information";
    public static final String HIW_CHECK_RATE = "Check your rate";
    public static final String HIW_CHECK_RATE_SUMMARY = "Answer a few questions and get your lowest eligible rate in minutes.";
    public static final String HIW_CHOOSE_YOUR_TERM = "Choose your term";
    public static final String HIW_CHOOSE_YOUR_TERM_SUMMARY =
            "Get a fixed term for 3 or 5 years*. No hidden fees, early payment penalties or tricky fine print.";
    public static final String HIW_GET_YOUR_FUNDS = "Get your funds";
    public static final String HIW_GET_YOUR_FUNDS_SUMMARY = "Your money goes straight to your bank account via direct deposit.";
    // New Get Rate Pane
    public static final String loanTermsHeader = "Loans made simple";
    public static final String loanTermsText1 = "Low interest rate";
    public static final String loanTermsText2 = "Fixed term3 or 5 years*";
    public static final String loanTermsText3 = "Single monthly payment";
    public static final String loanTermsText4 = "No hidden fees or prepayment penalties";
    public static final String checkingRate = "Checking your rate won't affect your credit score.";
    public static final String checkingRateWithEstimate = "Checking your rate and estimate won't affect your credit score.";
    public static final String loanAmount = "5000";
    public static final String loanPurpose = "Debt Consolidation";
    public static final String creditquality = "Good Credit (700+)";
    // Old Get Rate Pane
    public static final String loanfooterText1 = "Low fixed rates";
    public static final String loanfooterText2 = "Fast and easy online application";
    public static final String loanfooterText3 = "No teaser rates or hidden fees";
    // Testimonila Pane
    public static final String SHANITA_TESTIMONIAL =
            "Prosper helped me pay for essential things we needed, as well as pay down credit card debt. In such an uncertain time, we didn't have to worry about losing everything we worked so hard for.";
    public static final String SHANITA = "Shanita";
    public static final String OSCAR_TESTIMONIAL = "Within a week I got the money in my bank account. I'll be able to pay off my credit card debt in 3 yearsat half the interest rate I was paying before.";
    public static final String OSCAR = "Oscar";
    public static final String NIK_TESTIMONIAL =
            "It was tough getting my finances back together, and I was kind of relying on my credit card. Prosper let me consolidate, and now I only have one payment.";
    public static final String NIK = "Nik";
    // Investor Pane
    public static final String IVESTOR_PROMO_HEADER_TEXT_1 = "Invest in loans through Prosper";
    public static final String INVESTOR_PROMO_TEXT_2 = "A diversification opportunity that delivers solid monthly returns";
    //Loan Purpose
    public static final String DEBT_CONSOLIDATION_LOAN_PAGE = "Get a Debt Consolidation Loan";
    public static final String HOME_IMPROVEMENT_LOAN_PAGE = "Get a Home Improvement Loan";
    public static final String SMALL_BUSSINESS_LOAN_PAGE = "Get a Personal Loan for Your Small Business";
    public static final String SPECIAL_OCCASIONS_LOAN_PAGE = "Special Occasion Loans";
    public static final String AUTO_VEHICAL_LOAN_PAGE = "Get an Auto Loan or Vehicle Loan";
    public static final String BABY_AND_ADOPTION_LOAN_PAGE = "Get a Loan for an Adoption or for Your New Baby";

    public static final String LOAN_TYPES_DEBT_CONSOLIDATION_LOANS = "plp/loans/loan-types/debt-consolidation-loans/";
    public static final String LOAN_TYPES_HOME_IMPROVEMENT_LOANS = "plp/loans/loan-types/home-improvement-loans/";
    public static final String LOAN_TYPES_AUTO_LOANS = "plp/loans/loan-types/auto-loans/";
    public static final String LOAN_TYPES_SPECIAL_OCCASION_LOANS = "plp/loans/loan-types/special-occasion-loans/";
    public static final String LOAN_TYPES_SMALL_BUSINESS_LOANS = "plp/loans/loan-types/personal-loans-business/";
    public static final String LOAN_TYPES_BABY_ADOPTION_LOANS = "plp/loans/loan-types/baby-adoption-loans/";

    public static final String HIW_PANE_TITLE = "How it works";
    public static final String CYR_TITLE = "Check your rate";
    public static final String CYR_DETAIL = "Answer a few questions and get your lowest eligible rate in minutes.";
    public static final String CYT_TITLE = "Choose your term";
    public static final String CYT_DETAIL = "Get a fixed term for 3 or 5 years*. No hidden fees, early payment penalties or tricky fine print.";
    public static final String GYF_TITLE = "Get your funds";
    public static final String GYF_DETAIL = "Your money goes straight to your bank account via direct deposit.";

    public static final String TESTIMONIAL_PANE_TITLE = "Real customer stories";
    public static final String TESTIMONIAL_OSCAR_NAME = "Oscar";
    public static final String TESTIMONIAL_OSCAR_2 = "at half the interest rate I was paying before.";
    public static final String TESTIMONIAL_OSCAR_1 =
            "I'll be able to pay off my credit card debt in 3 years";

    public static final String TESTIMONIAL_NIK_NAME = "Nik";
    public static final String TESTIMONIAL_NIK = "It was tough getting my finances back together and I was relying on my credit card. Prosper let me consolidate and now I only have one payment.";

    public static final String TESTIMONIAL_SHANITA_NAME = "Shanita";
    public static final String TESTIMONIAL_SHANITA ="Prosper helped me pay for essential things we needed, as well as pay down credit card debt.";

    public static final String NERDWALLET_LOGO = "/web-borrower/assets/images/shared/web-borrower/homepage/user-testimonials/nerdwallet-38dcec73ed2fc9b02c13d25504a8c8e8.png";
    public static final String NERDWALLET_WEBURL = "https://www.nerdwallet.com/blog/loans/prosper-personal-loans-review/";

    public static final String WASHINGTON_LOGO = "/web-borrower/assets/images/shared/web-borrower/homepage/user-testimonials/the_washington_post-53875d6af6d0bb808ae0d8f33afe1708.png";
    public static final String WASHINGTON_WEBURL = "https://www.washingtonpost.com/news/where-we-live/wp/2016/05/19/partnership-creates-one-stop-shopping-to-find-money-and-contractors-for-home-renovations/";

    public static final String NPR_LOGO = "/web-borrower/assets/images/shared/web-borrower/homepage/user-testimonials/npr-0d2688212c1d5cf813d74b91bb6efc91.png";
    public static final String NPR_WEBURL = "http://www.marketplace.org/2015/12/11/world/tech-meets-finance-and-gives-banks-scare";

    public static final String CARDRATES_LOGO = "/web-borrower/assets/images/shared/web-borrower/homepage/user-testimonials/cardrates-531158b1e1d810d8888c365c6622c806.png";
    public static final String CARDRATES_WEBURL = "http://www.cardrates.com/news/prosper-marketplace-lending/";

    public static final String CONSUMER_REPORTS_LOGO = "/web-borrower/assets/images/shared/web-borrower/homepage/user-testimonials/consumer_reports-7c2d5513221331e14c83b2ef731626bb.png";
    public static final String CONSUMER_REPORTS_WEBURL = "http://www.consumerreports.org/cro/news/2015/01/what-to-know-about-lending-club-and-prosper-peer-to-peer/index.htm";

    public static final String PROSPER_DAILY_TITLE = "Stay on top of your\nmoney with Prosper Daily";
    public static final String PROSPER_DAILY_BULLET1 = "View your financial accounts and loan in one place";
    public static final String PROSPER_DAILY_BULLET2 = "Know exactly where your money is going";
    public static final String PROSPER_DAILY_BULLET3= "Get smarter about your credit card";


}