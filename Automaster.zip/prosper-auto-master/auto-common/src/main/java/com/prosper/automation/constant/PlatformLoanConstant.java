
package com.prosper.automation.constant;

public class PlatformLoanConstant {

    public static String VALID_BLENDER = "user1078@prosper.stg";
    
    
    private PlatformLoanConstant() {
        // intended private
    }
}
