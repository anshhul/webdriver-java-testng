
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"correctedAddress", "address_1", "address_2", "address_type_id", "source_type_id", "state", "zip_code"})
public final class AddressValidationResponse {
    
    @JsonProperty("correctedAddress")
    private AddressInfo correctedAddress;
    @JsonProperty("defaultAddress")
    private boolean defaultAddress;
    @JsonProperty("addressValid")
    private boolean addressValid;
    @JsonProperty("address_1")
    private String address1;
    @JsonProperty("address_2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip_code")
    private String zipCode;
    @JsonProperty("addressValidationFailureReason")
    private String addressValidationFailureReason;
    
    
    public AddressInfo getCorrectedAddress() {
        return correctedAddress;
    }
    
    public String getAddressValidationFailureReason() {
        return addressValidationFailureReason;
    }
}
