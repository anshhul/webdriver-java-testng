
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"url", "id", "file_name", "size", "created_date", "modified_date"})
public final class Documents {

	@JsonProperty("url")
    private String fileURL;

    @JsonProperty("id")
    private String fileId;

    @JsonProperty("file_name")
    private String fileName;

    @JsonProperty("size")
    private long fileSize;

    @JsonProperty("created_date")
    private String createdDate;

    @JsonProperty("modified_date")
    private String modifiedDate;


    public Documents() {
    }

    private Documents(final Builder builder) {
    	fileURL = builder.fileURL;
    	fileId = builder.fileId;
    	fileName = builder.fileName;
        fileSize = builder.fileSize;
        createdDate = builder.createdDate;
        modifiedDate = builder.modifiedDate;
    }


    public String getFileURL(){
    	return fileURL;
    }

    public String getFileId(){
    	return fileId;
    }

    public String getFileName(){
    	return fileName;
    }


    public String getCreatedDate() {
        return createdDate;
    }


    public String getModifiedDate() {
        return modifiedDate;
    }

    public long getFileSize(){
    	return fileSize;
    }

    @Override
	public String toString() {
        return "documents [fileURL=" + fileURL + ", fileId=" + fileId + ", fileName=" + fileName + ", fileSize=" + fileSize
                + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + "]";
	}

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Documents that = (Documents) o;
        return Objects.equal(fileId, that.fileId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fileURL, fileId, fileName, fileSize, createdDate, modifiedDate);
    }

    public static Builder getBuilder() {
        return new Builder();
    }

    public static final class Builder {
    	private String fileURL;
        private String fileId;
        private String fileName;
        private long fileSize;
        private String createdDate;
        private String modifiedDate;


        public Builder() {
        }

        public Builder withFileURL(final String fileURL) {
            this.fileURL = fileURL;
            return this;
        }

        public Builder withFileId(final String fileId) {
            this.fileId = fileId;
            return this;
        }

        public Builder withFileName(final String fileName) {
            this.fileName = fileName;
            return this;
        }

        public Builder withFileSize(final long fileSize) {
            this.fileSize = fileSize;
            return this;
        }

        public Builder withcreatedDate(final String createdDate) {
            this.createdDate = createdDate;
            return this;
        }

        public Builder withmodifiedDate(final String modifiedDate) {
            this.modifiedDate = modifiedDate;
            return this;
        }

        public Documents build() {
            return new Documents(this);
        }
    }
}
