
package com.prosper.automation.constant;

/**
 * Created by pbudiono on 8/2/16.
 */
public final class PartnerConstant {

    public static final String PARTNER_NAME_PREFIX = "auto_partner_name";


    private PartnerConstant() {
    }
}
