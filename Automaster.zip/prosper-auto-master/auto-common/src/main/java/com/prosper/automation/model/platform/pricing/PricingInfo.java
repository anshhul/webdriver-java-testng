
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"breChannel", "breCampaign", "breProgram", "pricingVersion", "pricingRules", "pricingName",
        "pricingScoreModelId", "offerCode", "dmUser"})
public final class PricingInfo {

    @JsonProperty("breChannel")
    private String breChannel;
    @JsonProperty("breCampaign")
    private String breCampaign;
    @JsonProperty("breProgram")
    private String breProgram;
    @JsonProperty("pricingVersion")
    private String pricingVersion;
    @JsonProperty("pricingRules")
    private String pricingRules;
    @JsonProperty("pricingName")
    private String pricingName;
    @JsonProperty("pricingScoreModelId")
    private String pricingScoreModelId;
    @JsonProperty("offerCode")
    private String offerCode;
    @JsonProperty("dmUser")
    private Boolean dmUser;
    @JsonProperty("breDMPricingBin")
    private String breDmPricingBin;
    @JsonProperty("superPrimeRules")
    private String superPrimeRules;

    public PricingInfo() {
    }

    private PricingInfo(final Builder builder) {
        breChannel = builder.breChannel;
        breCampaign = builder.breCampaign;
        breProgram = builder.breProgram;
        pricingVersion = builder.pricingVersion;
        pricingRules = builder.pricingRules;
        pricingName = builder.pricingName;
        pricingScoreModelId = builder.pricingScoreModelId;
        offerCode = builder.offerCode;
        dmUser = builder.dmUser;
        breDmPricingBin = builder.breDmPricingBin;
        superPrimeRules = builder.superPrimeRules;
    }

    public static final class Builder {

        private String breChannel;
        private String breCampaign;
        private String breProgram;
        private String pricingVersion;
        private String pricingRules;
        private String pricingName;
        private String pricingScoreModelId;
        private String offerCode;
        private Boolean dmUser;
        private String breDmPricingBin;
        private String superPrimeRules;

        public Builder() {
        }

        public Builder withBreChannel(final String breChannel) {
            this.breChannel = breChannel;
            return this;
        }

        public Builder withBreCampaign(final String breCampaign) {
            this.breCampaign = breCampaign;
            return this;
        }

        public Builder withBreProgram(final String breProgram) {
            this.breProgram = breProgram;
            return this;
        }

        public Builder withPricingVersion(final String pricingVersion) {
            this.pricingVersion = pricingVersion;
            return this;
        }

        public Builder withPricingRules(final String pricingRules) {
            this.pricingRules = pricingRules;
            return this;
        }

        public Builder withPricingName(final String pricingName) {
            this.pricingName = pricingName;
            return this;
        }

        public Builder withSuperPrimeRules(final String superPrimeRules) {
            this.superPrimeRules = superPrimeRules;
            return this;
        }

        public Builder withPricingScoreModelId(final String pricingScoreModelId) {
            this.pricingScoreModelId = pricingScoreModelId;
            return this;
        }

        public Builder withOfferCode(final String offerCode) {
            this.offerCode = offerCode;
            return this;
        }

        public Builder withDmUser(final Boolean dmUser) {
            this.dmUser = dmUser;
            return this;
        }

        public Builder withBreDmPricingBin(final String breDmPricingBin) {
            this.breDmPricingBin = breDmPricingBin;
            return this;
        }

        public PricingInfo build() {
            return new PricingInfo(this);
        }
    }
}
