
package com.prosper.automation.constant.web;

import com.prosper.automation.constant.Constant;

/**
 * Pages Constants
 *
 * @author jdoriya
 *
 */
public class Constants {

    public static String ROOT_SUITE = "MyProject";

    // sheets
    public static String TESTCASES_SHEET = "TestCases";
    public static String DATA_SHEET = "Data";

    // Col names
    public static String RUNMODE_COL = "Runmode";
    public static String TESTCASES_COL = "TestCases";

    // runmode
    public static String RUNMODE_YES = "Y";
    public static String RUNMODE_NO = "N";

    // result output
    public static String resultSheetName = "ExecutionData";
    public static String resultColumnName = "JiraID";
    // New BUSINESSRULEVERSION

    public static final String BRE_RULE_VERSION = "7.005";
     //UserAddressTypeID
    public static final String USERADDRESSTYPEID="3";


    // social site page titles
    public static final String FACEBOOK_PAGE_TITLE = "Prosper.com | Facebook";
    public static final String LINKEDIN_PAGE_TITLE = "Prosper Marketplace | LinkedIn";
    public static final String TWITTER_PAGE_TITLE = "Prosper Loans (@ProsperLoans) | Twitter";

    // Brand Name for DM User
    public static final String RESKIN_PROMO_BRAND_NAME = "Brand new logo. Same great rates.";

    public static final String SESSION_TIMEOUT_MODAL_HEADER = "Your session has expired!";
    public static final String SESSION_TIMEOUT_MODAL_SUB_HEADER = "Please enter your password to resume.";

    // Deprecated: Gear-1948
    // public static final String NEW_OFFER_PAGE_HEADER = "YOU'RE PRE-QUALIFIED FOR";
    public static final String NEW_OFFER_PAGE_HEADER = "Youâ€™re qualified!";
    public static final String OLD_OFFER_PAGE_HEADER = "You Qualify for a";
    public static final String ALTERNATE_LOAN_OFFER_PAGE_HEAR = "You're qualified!";

    public static final String THANK_YOU_PAGE_HEADER = "Thank you for your loan request";

    public static final String CSA_PASSWORD_RESET_INSTRUCTION = "Check your email to reset your password";

    public static final String LANDING_PAGE_TITLE = "Prosper | Borrower";
    public static final String PRIVACY_POLICY_TITLE = "Prosper Privacy Policy & Federal Privacy Notice";
    public static final String INVALID_MONTHLY_PAYMENT_VALIDATION = "Monthly payment must be greater than $0";

    public static final String FOR_EXAMPLE_DISCLAIMER =
            "*For example, a three year $10,000 loan with a rate of 5.99% APR would have 36 scheduled monthly payments of $302. A five year $10,000 loan with a rate of 9.68% APR would have 60 scheduled monthly payments of $201. Annual percentage rates (APRs) through Prosper range from 5.99% APR (AA) to 36.00% APR (HR) for first-time borrowers, with the lowest rates for the most creditworthy borrowers. Eligibility is not guaranteed, and requires that a sufficient number of investors commit funds to your account and that you meet credit and other conditions. Refer to Borrower Registration Agreement for details and all terms and conditions. All loans made by WebBank, a Utah-chartered industrial bank, member FDIC.";
    public static final String PROSPER_AND_WEBBANK =
            "Prosper and WebBank take your privacy seriously. Please see Prosper's Privacy Policy and WebBank's Privacy Policy for more details.";
    public static final String NOTES_OFFERED =
            "Notes offered by Prospectus. Notes investors receive are dependent for payment on unsecured loans made to individual borrowers. Not FDIC-insured; investments may lose value; no Prosper or bank guarantee. Prosper does not verify all information provided by borrowers in listings. Investors should review the prospectus before investing.";
    public static final String COPYRIGHT = "Ã‚Â© 2005-2016 Prosper Funding LLC. All rights reserved.";

    public static final String NOTES_ARE_NOT_GUARANTEED = "Notes are not guaranteed or FDIC insured, and investors may lose some or all of the principal invested. Investors should carefully consider these and other risks and uncertainties before investing. This and other information can be found in the prospectus. Investors should consult their financial advisor if they have any questions or need additional information.";

    public static final String AS_OF_FEBRUARY =
            "As of February 1, 2013, the Prosper marketplace was transferred by Prosper Marketplace, Inc. to Prosper Funding LLC, a wholly-owned subsidiary of Prosper Marketplace, Inc. From and after February 1, 2013 Prosper Funding LLC is the sole obligor of Notes offered and secured by loans made through the Prosper marketplace, including Notes originally issued by Prosper Marketplace, Inc. prior to such transfer. Prosper Marketplace, Inc. continues to provide services to Prosper Funding LLC relating to loan and Note servicing, and may interact with borrowers and investors in relation thereto as agent of Prosper Funding LLC. Except where otherwise noted, throughout this website ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œProsperÃƒÂ¢Ã¢â€šÂ¬Ã¯Â¿Â½ refers to Prosper Funding LLC including acting directly or through its agents.";
    public static final String ALL_PERSONAL_LOANS =
            "All personal loans are made by WebBank, a Utah-chartered Industrial Bank, Member FDIC. Loans are unsecured, fully amortized personal loans.";
    public static final String SEASONED_RETURN =
            "*Seasoned Return calculations represent historical performance data for the Borrower Payment Dependent Notes (ÃƒÂ¢Ã¢â€šÂ¬Ã¯Â¿Â½NotesÃƒÂ¢Ã¢â€šÂ¬Ã¯Â¿Â½) issued and sold by Prosper since July 15, 2009. To be included in the calculations, Notes must be associated with a borrower loan originated more than 10 months ago; this calculation uses loans originated through May 31, 2012. Our research shows that Prosper Note returns historically have shown increased stability after theyÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ve reached ten months of age. For that reason, we provide ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œSeasoned ReturnsÃƒÂ¢Ã¢â€šÂ¬Ã¯Â¿Â½, defined as the Return for Notes aged 10 months or more.";
    public static final String TO_CALCULATE =
            "To calculate the Return, all payments received on borrower loans, net of principal repayment, credit losses, and servicing costs for such loans, are aggregated and then divided by the average daily amount of aggregate outstanding principal. To annualize this cumulative return, it is divided by the dollar-weighted average age of the loans in days and then multiplied by 365.";
    public static final String ALL_CALCULATIONS =
            "All calculations were made as of September 30th, 2013. Seasoned Return is not necessarily indicative of the future performance on any Notes.";
    public static final String ONDECK_BUSINESS_DECLINE =
            "Weâ€™ve partnered with OnDeck to provide you access to business financing.";
    public static final String AMONE_PARTNER_DECLINE = "We've partnered with AmOne to provide you with additional options";
    public static final String D110_PAGE_HEADER = "Thank you for your interest in Prosper";
    public static final String AMONE_PARTNER_DECLINE_D110 =
            "We're unable to offer you a loan at this time, but we’ve partnered with AmOne to provide you with a possible solution.";
    public static final String BASED_ON_CREDIT_DECLINE =
            "Based on the credit quality that you\u2019ve selected, you may not be eligible for a loan through Prosper at this time.";
    public static final String CONTINUE_ANYWAY_ON_DECLINE = "Continue anyway";
    public static final String INVALID_USER_INFO_MESSAGE =
            "We weren\u2019t able to verify your information - it may be a technical issue";

    public static final String EXISTING_LISTING_MESSAGE =
            "We're sorry, but you currently have an existing listing so you may not create a new listing at this time.";
    public static final String EXISTING_LISTING_MESSAGE_PAYMENT_DUE = "Can't create a listing if you have been late on Prosper loan payments";
    public static final String EXISTING_LISTING_MESSAGE_FOR_MID_FICO_AND_LOAN_LESS_6_MONTHS =
            "Borrowers with existing loans must wait between six and nine months to activate a second loan.";
    public static final String ERROR_RETRIEVING_CREDIT_FILE =
            "There was an error retrieving your credit file. If the problem persists, please try again in a few days.";
    // ABP Registration Page Constants
    public static final String BLANK_ZIP_CODE_ERROR_MESSAGE = "Please enter your 5 or 9-digit ZIP code.";
    public static final String BLANK_CITY_ERROR_MESSAGE = "Please enter the name of your city.";
    public static final String DATE_OF_BIRTH_ERROR_MESSAGE = "Please enter your full birth date in this format: MM/DD/YYYY";
    public static final String OTHER_LOAN_PURPOSER_HINT =
            "No part of your loan proceeds can be used for post-secondary educational expenses (i.e., tuition, fees, required equipment or supplies, or room and board) at a college/university/vocational school. Lean more.";
    public static final String YEARLY_INCOME_ERROR_MESSAGE = "Please enter your yearly income";

    // ABP Personal Details Page Constants
    public static final String BAD_EMPLOYMENT_SOD_MESSAGE = "Please enter valid employment start month and year";

    // Identity verification warning for App Resume
    public static final String CREDENTIAL_ERROR = "We Can't Verify Your Identity";
    // PHL Decline Page Message
    public static final String PHL_DECLINE_MESSAGE ="Unfortunately, we’re unable to accept your application at this time. Please check your personal email-we've sent you a message with full details on why your credit profile did not meet our eligibility requirements.";
    public static final String  PHL_DECLINE_MESSAGE_FICO_LESSTHAN_640="Thank you for your interest.";
    public static final String PHL_DECLINE_MESSAGE_PRIOR_LOAN_16_PLUS_DPD_LAST_12_MONTHS="Existing listing";
    public static final String PHL_DECLINE_MESSAGE_EXISTING_PROSPER_LOAN="Existing Prosper Loan";
    public static final String DTS_ANNUAL_INCOME_LESS_THAN_EQUAL_TO_ZERO="Thank you for your interest in Prosper. To meet eligibility requirements, potential borrowers must be employed or self-employed to apply for a loan through Prosper. If the status of your employment changes, then we’d be happy to check your rate (without affecting your credit score). We’ve partnered with AmOne.com to provide you with additional options today.";



    public static final String REFAC = "mint";
    public static final String REFMC = "mint";
    public static final String REDUCED_PRICING = "23";
    public static final String EMAILRESTRICTIONMSG = "Please enter a valid email address";
    public static final String HILOANPURPOSETEXT = "Your Home Improvement Loan Terms";
    public static final String NEWTILLOANPURPOSETEXT = "Your Loan Terms";
    public static final String DCLOANPURPOSETEXT = "Your Debt Consolidation Loan Terms";
    public static final String START = "Start";


    public static class dxResponse {

        public static String GETOFFERURI = "ShowSelectedOfferUrl";
        public static String LENDINGTREEURL = "PersonalizedUrlTest";
        public static String GETOFFERINELIGIBILITYREASON = "IneligibilityReason";
        public static String GETOFFERELIGIBILITYSTATUS = "EligibilityStatus";
        public static String GETOFFERERROR = "Errors";
        public static String LTOFFERERROR = "ERRORDESCRIPTION";
        public static String GETOFFERSTATUSCODE = "StatusCode";
    }

    public static class dxResponseTagValue {

        public static String GETOFFERINELIGIBILITYCOMMONREASON =
                "Based on Prosper's internal algorithm, we could not find any matching offers.";
        public static String GETOFFERINVALIDSSNERROR = "Please enter a valid 9 digit social security number.";
        public static String GETOFFERINELIGIBLESTATUS = "Ineligible";

    }

    public static class PartnerAccountInformationPage {

        public static String MILEAGEPLUSACCOUNTINFORMATIONHEADER = "Your United MileagePlus Account Information";
        public static String SPIRITMEMBERACCOUNTINFORMATIONHEADER = "Your FREE SPIRIT Account Information";
        public static String INVALIDMPN = "NL505612";
    }

    public static class VALIDATIONS {

        public static String HOMEPLUSLOANAMOUNTRESTRICTIONMSG = "Please enter amount between $2,000 and $100,000";
        public static String MAXLOANAMOUNT = "35000";
        public static String INVALID_STATE_RESTRICTION_MESSAGE = "Loans through Prosper are not available in your area.";
        public static String INVALID_STATE_RESTRICTION_MESSAGE_1 = "Not available in your state";
        public static String INVALID_STATE_RESTRICTION_MESSAGE_2 =
                "Sorry, but Prosper is not available to borrowers in your state. We will notify you via email when this service becomes available to you.";
        public static String ABP_DECLINE_MESSAGE =
                "Thank you for your interest in obtaining a loan through Prosper today. At this time your application for a loan has been denied and you will be provided with an email shortly and a mailed letter explaining the reason for the decision. We appreciate your business and do hope you consider Prosper for your personal loan needs in the future. As a matter of standard business, the credit inquiry today was only a soft pull and will not negatively impact your credit.";
        public static String ABP_DECLINE_MESSAGE_UPDATED = "Unfortunately, after reviewing the information provided, you do not currently qualify for any loan offers. We will send you an email and a mailed letter explaining the reasons for this decision. To ensure you can check rates risk-free, the credit inquiry that we conducted today was a soft inquiry that did not impact your credit score.";
        public static String ABP_DECLINE_MESSAGE_CREDIT_FILE_NOT_FOUND = "Credit file not found";
    }

    public static class PartnerLandingPage {

        public static String LOADING_DIALOG_BOX_CSS =
                "#dmAjaxSpinner[style*='display: block; opacity: 1; visibility: unset;']";
        public static String UNIQUEREFACANDREFMCMESSAGE = "Combination of ref_ac and ref_mc already exist.";
        public static String UNIQUEREFACMESSAGE = "Ref_ac already exist with other partner.";
        public static String DMOFFERDIALOGHEADER = "Attention: You have entered an invalid Personal Offer Code.";
        public static String UNITED_MILEAGE_SORRY_HEADING = "We're sorry";
        public static String UNITED_MILEAGE_SUB_HEADING = "This United MileagePlus offer has expired.";
        public static String UNITED_MILEAGE_QUESTIONS = "Questions? Contact us at (866) 615-6319";
    }

    public static class PartnerPortalApp {

        public static String PARTNER_CONTACT_NAME = "Benjamin Rockwell";
        public static String PARTNER_CONTACT_NUMBER = "4154964500";
        public static String PARTNER_CONTACT_NUMBER_NEW = "4154964501";
        public static String ADD_CAMPAIGN = "Add Campaign";
        public static String PAGE_URL_REFAC = "/plp/cardrefinance/?refac=";
        public static String PAGE_URL_REFMC = "&refmc=";
    }


    public String generatePartnerName() {
        return Constant.getRandomString();
    }


    public static class dxGetOfferClientEndpoint {

        public static String ENDPOINT_STG = "https://services.stg.circleone.com/DXReferral/API/GetOffers";
        public static String ENDPOINT_STG2 = "http://stage2-apiwcfsite.v.uc1.pspr.co/DXReferral/API/GetOffers";
        public static String ENDPOINT_QA32 = "http://services.qa32.c1.dev/DXReferral/API/GetOffers";
        public static String ENDPOINT_QA34 = "http://services.qa34.c1.dev/DXReferral/API/GetOffers";
    }

    public static class dxLendingTreeClientEndpoint {

        public static String ENDPOINT_STG = "https://services.stg.circleone.com/DXReferral/API/LendingTree";
        public static String ENDPOINT_STG2 = "http://stage2-apiwcfsite.v.uc1.pspr.co/DXReferral/API/LendingTree";
        public static String ENDPOINT_QA32 = "http://services.qa32.c1.dev/DXReferral/API/LendingTree";
        public static String ENDPOINT_QA34 = "http://services.qa34.c1.dev/DXReferral/API/LendingTree";
    }

    public static class UserEmploymentStatus {

        public static String borrowerEmployedStatusID = "7";
        public static String borrowerSelfEmployedStatusID = "3";
        public static String borrowerOtherEmploymentStatusID = "6";
    }

    public static class ClientTokenUsers {

        public static String creditKarmaUsername = "CreditKarma2";
        public static String crediKarmaPassword = "CAB5CA11-6342";
        public static String creditKarmaPassword_qa32 = "3D19C113-84BF";
        public static String creditKarmaSubProgramID = "2";
        public static String CREDITKARMANAME = "Main-DX-Credit Karma";

        public static String lendingTreeUserName = "LendingTree";
        public static String lendingTreePassword = "LT072013";
        public static String lendingTreeSubProgramID = "22";
        public static String LENDINGTREENAME = "Main-DX-Lending Tree";

        public static String ahlUsername = "AHLending";
        public static String ahlPassword = "AHL092013";
        public static String AHL_SUBPROGRAM_ID = "24";
        public static String AHLNAME = "Main-DX-American Healthcare Lending";

        public static String VESTEDFINANCIAL_USERNAME = "VestedFinancial";
        public static String VESTEDFINANCIAL_PASSWORD = "vestedfin2015";
        public static String VESTEDFINANCIAL_SUBPROGRAMID = "160";
    }

    public static class RegisterationPageConstants {

        // All tag values from XML test data file
        public static String REGISTRATIONPAGEHEADER_OLD_TEXT = "Get a Custom Rate in 1 Click";
        public static String REGISTRATIONPAGEHEADER_NEW_TEXT = "Get Your Custom Rate";
        public static String EXISTING_USER_EMAIL_NOTIFY = "This email address is already registered.";
        public static String FIRSTNAME_TAG = "FirstName";
        public static String LASTNAME_TAG = "LastName";
        public static String STREETNAME_TAG = "Street";
        public static String CITYNAME_TAG = "City";
        public static String ZIPCODE_TAG = "Zipcode";
        public static String STATE_OF_RESIDENCE_TAG="StateOfResidence";
        public static String STATE_TAG = "State";
        public static String SSN_TAG = "SSN";
        public static String SSN_TAG_HYPHEN="SSN_Hyphen";
        public static String EMPLOYMENTSTATUS_TAG = "EmploymentStatus";
        public static String EMPLOYMENTSTATUID_TAG = "EmploymentStatusId";
        public static String YEARLYINCOME_TAG = "YearlyIncome";
        public static String DATEOFBIRTH_TAG = "DateOfBirth";
        public static String EMAILADDRESS_TAG = "EmailAddress";
        public static String YEAROFBORN_TAG = "YearOfBorn";
        // HR USER DARRELL AMYLON
        public static final String HR_USER_DARRELL_FIRST_NAME = "DARRELL";
        public static final String HR_USER_DARRELL_LAST_NAME = "AMYLON";
        public static final String HR_USER_DARRELL_STREET_NAME = "5320 YANCY DR";
        public static final String HR_USER_DARRELL_CITY_NAME = "MILTON";
        public static final String HR_USER_DARRELL_STATE_NAME = "FL";
        public static final String HR_USER_DARRELL_ZIP_CODE = "325719086";
        public static final String HR_USER_DARRELL_SSN = "666318609";
        public static final String HR_USER_DARRELL_DATEOFBIRTH = "01/01/1950";
        // INVESTOR TEST DATA:
        public static final String INV_USER_RAY_FIRST_NAME = "RAY";
        public static final String INV_USER_RAY_LAST_NAME = "WILLIAMS";
        public static final String INV_USER_RAY_STREET_NAME = "1825 FOSTER AVE";
        public static final String INV_USER_RAY_CITY_NAME = "JANESVILLE";
        public static final String INV_USER_RAY_STATE_NAME = "WI";
        public static final String INV_USER_RAY_ZIP_CODE = "535450812";
        public static final String INV_USER_RAY_SSN = "666057915";
        public static final String INV_USER_RAT_DATEOFBIRTH = "01/01/1936";

        // DM Decline User : Too Few Trade Line AA
        public static final String DM_DECLINE_TFDL_OFFER_CODE = "SS8EW8SE";
        public static final String DM_DECLINE_TFDL_FIRST_NAME = "TIM";
        public static final String DM_DECLINE_TFDL_LAST_NAME = "GRIMMETT";
        public static final String DM_DECLINE_TFDL_SSN = "666706110";
        public static final String DM_DECLINE_TFDL_STREET_NAME = "7589 SANDSTONE RD";
        public static final String DM_DECLINE_TFDL_CITY_NAME = "GULF BREEZE";
        public static final String DM_DECLINE_TFDL_ZIP_CODE = "325667639";
        public static final String DM_DECLINE_TFDL_STATE_NAME = "FL";
        public static final String CREDIT_REPORT_AUTH_HEADER_PAGE_TITLE = "Authorization to Obtain Credit Report at Registration";
        public static final String TERMS_OF_USE_PAGE_TITLE = "Terms of Use";
        public static final String DATA_TERMS_OF_USE_PAGE_TITLE = "Terms of Use";
        public static final String WEB_BANK_PAGE_TITLE = "WebBank-privacy-policy";
        public static final String PRIVACY_POLICY_PAGE_TITLE = "privacy-policy";
    }

    public static class LightStreamFunnel {

        public static String URL =
                "https://www.lightstream.com/home-improvement-loan?fact=16464&cid=LP|HIL|home_improvement|apply|PHI|16464";
    }

    public static class SSNPage {

        public static final String IDV_PAGE_URL = "ssn?";
        public static final String IDV_PAGE_HEADER = "To accurately check your rate, please provide your Social Security number";
        public static final String IDV_PLACEHOLDER_HINT = "Enter your Social Security number";
        public static final String CREDIT_FILE_NOT_FOUND = "Credit file not found";
        public static final String WHY_DO_NEED_THIS_MESSAGE =
                "Your SSN is used to make sure we identify your credit history and not someone else’s. All information entered into the Prosper website is kept safe and secure. For more information, please read our";
    }

    public static class BorrowerPreRegPage {

        public static String LOANAMOUNTVALIDATIONMSG = "Please enter an amount between $2,000 and $35,000.";
        public static String LOANPURPOSEVALIDATIONMSG = "Please select the purpose of your loan.";
        public static String CREDITQUALITYVALITIONMSG =
                "Please select the range that best describes the quality of your credit. ";
        public static String PREREGISTRATIONHEADERTEXT = "Loan Information";
        public static String FINANCIAL_PROFESSIONALS_HEADER = "Prosper for Institutional Investors";
        public static String PROSPECTUS_HEADER = "Latest SEC Filings";

    }

    public static class EventHistorypage {

        public static String LEGAL_DOCUMENT_SAVED = "Legal Document Saved";
        public static String TERMS_OF_USE_EVENT_DETAIL = "You have received the Terms of Use.";
        public static String WEBBANK_PRIVAY_EVENT_DETAIL = "You have received the WebBank.com Privacy Notice.";
        public static String DATA_TERMS_OF_USE_EVENT_DETAIL = "You have received the Data Terms of Use";
        public static String PRIVACY_POLICY_EVENT_DETAIL = "You have received the Prosper Privacy Policy.";
        public static String CREDIT_AUTHORIZATION_EVENT_DETAIL =
                "You have received the Authorization to Obtain Credit Report for loan listing.";
        public static String EVENT_HISTORY_PAGE_TITLE = "Event History - Prosper";
        public static String LOAN_REQUEST_CANCELLED =
                "A message was sent to you. Subject: Your loan request has been cancelled. View message.";
        public static String CREDITSCORELOWEVENTNAME =
                "A message was sent to you. Subject: Your credit score is too low to continue. View message.";
        public static String CREDIT_SCORE_UNAVAILABLE_EVENT_NAME =
                "A message was sent to you. Subject: Credit score unavailable. View message.";
        public static String USERRECEIVEDMESSAGETYPE = "User Received Message";
        public static String AALETTERDETAILS = "You have received the Adverse Action Letter.";
        public static String CHARGEG_OFF_LOAN =
                "Thank you for applying for a loan through Prosper. We are unable to accept your loan request because your credit history indicates that you have a Charged-off Prosper loan.";
        public static String CREDITSCOREBELOW640 =
                "Thank you for applying for a loan through Prosper. We are unable to accept your loan request because your FICOÃƒÆ’Ã‚Â¯Ãƒâ€šÃ‚Â¿Ãƒâ€šÃ‚Â½08 credit score was below what Prosper requires for you to be eligible to apply for a loan.";
        public static String UNABLE_TO_APPLY =
                "A message was sent to you. Subject: Unable to apply for a Prosper loan at this time. View message.";
        public static String UNABLE_TO_APPLY_ANOTHER =
                "A message was sent to you. Subject: Unable to apply for another loan at this time. View message.";
        public static String CHANGE_OWNERSHIP_MESSAGE = "A message was sent to you. Subject: Change of Ownership. View message.";
        public static String NOT_QUALIFIED_ORIGINAL_LOAN_AMOUNT =
                "A message was sent to you. Subject: You do not qualify for the original loan amount you've requested. View message.";
    }

    public static class MessagesPage {

        public static String CREDIT_SCORE_LOW_SUBJECT = "Your credit score is too low to continue";
        public static String PMI_SCORE_14_SUBJECT = "Your credit scores are too low to continue";
        public static String CREDIT_SCORE_UNAVAILABLE = "Credit score unavailable";
        public static String UNABLE_TO_APPLY = "Unable to apply for a Prosper loan at this time";
        public static String UNABLE_TO_APPLY_ANOTHER_LOAN = "Unable to apply for another loan at this time";
        public static String LOAN_REQUEST_CANCEL = "Your loan request has been cancelled";
        public static String CREDIT_LOW_SCORE_SUBJECT = "Your credit scores are too low to continue";
        public static String NOT_QUALIFIED_FOR_ORIGINAL_LOAN_AMOUNT =
                "You do not qualify for the original loan amount you've requested";
        public static String UNABLE_TO_CREATE_ANOTHER_LOAN = "Unable to create another loan at this time";
    }

    public static class PersonalDetailPage {

        public static String PERSONAL_DETAIL_HEADER_CONTENT = "You're Almost Finished";
        public static String PERSONAL_DETAIL_NEW_HEADER_CONTENT = "Verify Your Identity";
        public static String PERSONAL_DETAIL_CREATE_ACCOUNT = "Thanks for choosing Prosper";
        public static String HOMEPHONE_TAG = "HomePhone";
        public static String HOMEPHONE = "(619) 254-3521";
        public static String MOBILEPHONE_TAG = "MobilePhone";
        public static String MOBILEPHONE = "(619) 254-3521";
        public static String WORKPHONE_TAG = "WorkPhone";
        public static String WORKPHONE = "(619) 254-3523";
        public static String EMPLOYERNAME_TAG = "EmployerName";
        public static String EMPLOYERNAME = "ACME Construction";
        public static String STARTEMPLOYMENTDATE_TAG = "StartOfEmployment";
        public static String STARTEMPLOYMENTDATE = "01/1998";
        public static String SECONDARYPHONE_TAG = "SecondaryPhone";
        public static String SECONDARYPHONE = "";
        public static String EMPLOYERPHONE_TAG = "EmployerPhoneNumber";
        public static String EMPLOYERPHONE = "(619) 254-3523";
        public static String OCCUPATION_TAG = "Occupation";
        public static String OCCUPATION = "Analyst";
        public static String SSN_TAG = "SSN";
        public static String SSN = "666-47-0340";
        public static String SSN_INCORRECT_VALUE="666470340";
        public static String PRIMARY_PHONE_BLANK_FIELD_VALIDATION = "Please enter a valid US phone number.";
        public static String SSN_FIELD_VALIDATION = "Please provide a valid 9-digit SSN.";
        public static String SSN__CHECK_CORRECT_PHONE_NUMBER_VALIDATION="We noticed that the provided SSN does not match the information the credit bureau has on file. Please contact our customer service team at 1 (866) 615-6319 for assistance.";
        public static String OCCUPATION_FIELD_VALIDATION = "Please select the option that best describes your occupation.";
        public static String EMPLOYER_NAME_FIELD_VALIDATION = "Please provide the name of your employer.";
        public static String START_OF_EMPLOYMENT_FIELD_FORMAT_VALIDATION = "Please enter valid employment start month and year";
        public static String START_OF_EMPLOYMENT_DATE_FIELD_VALIDATION =
                "Based on the birthdate you previously entered, the employment start date appears incorrect. Please correct the year of your employment start date.";
        public static String NONNUMBERIC_FIELD_VALIDATION =
                "Please enter a valid 10-digit phone number. (Ex: 323-456-7891)";
        public static String EMPLOYER_NAME_TOOLTIP = "This information will be used to verify your employment.";
        public static String SSN_FIELD_TOOLTIP =
                "For your protection, we use your Social Security number to verify your identity.";
        public static String SECONDARY_PHONE_FIELD_TOOLTIP =
                "In order to service and manage account inquires, Prosper may contact you at any telephone number provided.\nThis may include calls or text messages to mobile, cellular, or similar devices.";

    }

    public static class BankInfoPage {

        public static final String MII_CARD_BANK_NAME = "DagBank";
        public static final String MII_CARD_USER_NAME = "directid.bank1";
        public static final String MII_CARD_PASSWORD = "bank1";
        public static String BANK_INFO_OLD_HEADER = "Congratulations, your loan is ready for funding!";
        public static String BANKNAME_TAG = "BankName";
        public static String BANKNAME_SELECT = "SelectBank";
        public static String BANKNAME = "Wells Fargo";
        public static String ACCOUNTTYPE_TAG = "AccountType";
        public static String ACCOUNTTYPE = "";
        public static String ACCOUNTHOLDERNAME_TAG = "AccountHolderName";
        public static String ACCOUNTHOLDERNAME = "Mary Hopkins";
        public static String ALTACCOUNTHOLDERNAME_TAG = "AlternativerAccountHolderName";
        public static String ROUTING_TAG = "RoutingNumber";
        public static String ROUTING = "307084240";
        public static String ACCOUNTNUMBER_TAG = "AccountNumber";
        public static String ACCOUNTNUMBER = "12412451312341234";
        public static String CONFIRMACCOUNTNUMBER_TAG = "ConfirmAccountNumber";
        public static String CONFIRMACCOUNTNUMBER = "12412451312341234";
        public static String USERNAME = "UserName";
        public static String PASSWORD = "Password";

    }

    public static class ThankYourPage {

        public static String ABPTHANKYOUHEADER = "Thank you! Application by phone completed.";
    }

    public static class HomeWidgetPage {

        public static String LOANAMOUNT_TAG = "LoanAmount";
        public static String LOANPURPOSER_TAG = "LoanPurpose";
        public static String CREDITQUALTIY_TAG = "CreditQuality";
        public static String OFFCODE_TAG = "OfferCode";
        public static String DMPAGEURI_TAG = "URL";
        public static String RADIOPAGEURI_TAG = "URL";
    }

    public static class DxRequest {

        public static String GETOFFER_REQUEST = "getOfferRequest";
        public static String LENDINGTREE_REQUEST = "lendingTreeRequest";
    }

    public static class PromissoryNote {

        public static String LAST_UPADTE_DATE = "Last Updated: May 2016";
        public static String METHOD_OF_PAYMENT =
                "You have given me the choice of making my monthly payments (i) by automated withdrawal from an account that I designate using an automated clearinghouse (ACH) or"
                        + " other electronic fund transfer in the manner described in the debit authorization I execute, or "
                        + "(ii) by manually scheduled one-time withdrawals from an account that I designate using an ACH or other electronic fund transfer, "
                        + "made by logging onto my account on the Prosper website or by calling Prosper Borrower Services at (866) 615-6319,"
                        + " with my first payment being scheduled during the application process; and I have chosen one of these methods.";

        public static String LATE_CHARGE =
                "If the full amount of any monthly payment is not made by the end of fifteen (15) calendar days after its due date, "
                        + "I will pay you a late charge of the greater of $15 or 5.00% of the unpaid portion of the monthly payment. "
                        + "I will pay this late charge when it is assessed but only once on each late payment.";
        public static String INTERESTS =
                "Interest will be charged on unpaid principal until the full amount of principal has been paid. "
                        + "Interest under this Note will accrue daily, on the basis of a 365-day year."
                        + " The interest rate I will pay will be the rate I will pay both before and after any default.";
        public static String PAYMENTS =
                "I will pay the principal, interest, and any late charges or other fees on this Note when due. This Note is payable in ___ monthly installments of $___________ each, "
                        + "consisting of principal and interest, commencing on the ________ day of _____________, and "
                        + "continuing until the final payment date of __________________, which is the maturity date of this Note. "
                        + "Because of the daily accrual of interest on my loan and the effect of rounding, my final payment may be more or "
                        + "less than my regular payment. My final payment shall consist of the then remaining principal, "
                        + "unpaid accrued interest and other charges due under this Note. All payments will be applied first to any unpaid fees incurred as a result of failed payments, as provided in Paragraph 11; then to any charges for making payments other than as provided in this Note; then to any late charges then due; then to any interest then due; and then to principal. No unpaid interest or charges will be added to principal. I further acknowledge that, if I make my payments after the scheduled due date, or incur a charge/fee, this Note will not amortize as originally scheduled, which may result in a substantially higher final payment amount";
        public static String PROMISE_TO_PAY =
                "In return for a loan I have received, I promise to pay WebBank (\"you\") the principal sum of ___________________ Dollars ($__________), together with interest thereon commencing on the date of origination at the rate of ____ percent (___%) per annum simple interest. I understand that references in this Promissory Note (\"Note\") to you shall also include any person to whom you transfer this Note.";
    }

    public static class UserCommonTestDetails {

        public static String LOADING_SPINNER_ACCOUNT_OVERVIEW_PAGE_CSS = ".spinner-icon";
        public static String LOADING_COMMON_MODAL_CSS = ".reveal-modal[style*='display: block;']";
        public static String OVERLAY_MODAL_CSS = "#overlay[style*='display: block;']";
        public static String LOADING_BAR_SPINNER = "#loading-bar-spinner";
        public static String LOADING_DIALOG_BOX_AT_PUBLICSITE_PAGES_CSS =
                ".spinnerContent";
        public static String LOADING_DIALOG_BOX_AT_PHL_PAGES_CSS =
                ".reveal-modal[style*='display: block;']";
        public static String MII_CARD_SPINNER = ".loader.loader-alternate";
        public static String LOGINPASSWORD = "P@ssword23";
        public static String SUBPROGRAMID = "SubProgramId";
        public static String UPDATEYEARLYINCOME = "55555555";
        public static String UPDATELOANPURPOSE = "Home Improvement";
        public static String INCORRECTSTATE = "NY";
        public static String INCORRECTLASTNAME = "BOWSKI";
        public static String INCORRECTFIRSTNAME = "Hary";
        public static String INCORRECTSTREET = "2416 WASHINGTO AVE";
        public static String INCORRECTCITY = "AINT ";
        public static String USBANKROUTINGNO = "081000210";
        public static String USBANKNAME = "US Bank";
        public static String INVALIDSSN = "###";
        public static String INVALIDSSNNINEDIGIT = "#########";
        public static String INVALIDSPECIALCHARSSN = "@#$$%@#$#$233";
        public static String CHARSSN = "abcdefgjh";
        public static String INTSSN = "123456789";
        public static String INTSSN_HYPHEN="123-45-6789";
        public static String INTMORETHAN9DIGITSSN = "12345678943";

        public static String LOANAMOUNT = "8000";
        public static String LOANPURPOSE = "Debt Consolidation";
        public static String BUSINESS = "Business";
        public static String HOME_IMPROVEMENT = "Home Improvement";
        public static String SPECIAL_OCCASION = "Special Occasion";
        public static String BABY_ADOPTION = "Baby & Adoption";
        public static String AUTO = "Auto / Motorcycle / RV / Boat";

        public static String CREDITQUALTIY = "Good Credit (700+)";
        public static String HOMEPHONEAREACODE = "323";
        public static String MOBILEAREACODE = "323";
        public static String EMPLOYERPHONEAREACODE = "323";
        public static String WORKPHONEAREACODE = "323";
        public static String WORKPHONENUMBER = "6976355";
        public static String UPDATEPHONENUMBER = "6976357";
        public static String EMPLOYERPHONENUMBER = "6976359";
        public static String MOBILENUMBER = "6976354";
        public static String HOMEPHONENUMBER = "6976353";
        public static String EMPLOYMENTSTARTMONTH = "02";
        public static String EMPLOYMENTSTARTYEAR = "2000";
        public static String PRODOFFERCODE = "YH7BM8DE";
        public static String INVALIDZIPCODE = "251773223";
        public static String INVALID_DOB = "01/01/1990";
        public static String LENDERWEBBANKNAME = "WebBank";
        public static String LENDERWEBBANKSTREET = "215 South State Street";
        public static String LENDERWEBBANKCITYNAME = "Salt Lake City";
        public static String LENDERWEBBANKSTATENAME = "UT";
        public static String LENDERWEBBANKZIPCODE = "84111";
        public static String INCORRECTDOB = "12/12/1920";
        // MARK K JOHN SSN FOR OTHER VALID SSN TEST
        public static String DIFFERENTVALIDSSN = "666529524";
        public static String UPDATEDLOANAMOUNT = "15000";
        public static String PROSPER_HELP_LINE_PHONE_NUMBER = "(866) 213-6663";
        public static String NEW_PASSWORD = "P@ssword24";
    }

    public static class TilaPageConstants {

        public static String GIVEN_TO_YOU_DIRECTLY_TOOLTIP =
                "This is the amount you will receive in your bank account. It is calculated by";
        public static String PREPAID_FINANCE_CHARGE_TOOLTIP = "This fee is also called the \"origination fee.\"";

        public static String TILA_DOCUMENT_DISCLAIMER = "Copyright Ãƒâ€šÃ‚Â© 2005-2016 Prosper Marketplace, Inc. All rights reserved.";
        public static String TOTAL_PAYMENT_TOOLTIP =
                "This is the total cost of your loan (not including any late fees or other charges that you may incur in the future).";
        public static String ANNUAL_PERCENTAGE_RATE_TOOLTIP =
                "The Annual Percentage Rate or APR measures the total cost of your credit as an annual percentage of your loan proceeds. It includes your interest payments over the loan term and the Prepaid Finance Charge (or origination fee), which is why itâ€™s higher than your interest rate.";
        public static String WEB_BANK_TOOLTIP =
                "Prosper operates an online loan marketplace, where borrowers can apply for loans originated by WebBank, member FDIC.";
        public static String FINANCE_CHARGE =
                "This is the amount of interest you will pay over the term of the loan plus the Prepaid Finance Charge (also known as the origination fee)";
        public static String PAYMENT_AUTHORIZATION = "payment authorization";
        public static String AMOUNT_FINANCED = "This is the amount you will receive in your bank account. It is calculated by";
    }

    public static class RegistrationAgreement {

        public static String BRA_INTRO =
                "Borrower Registration Agreement\nThis Borrower Registration Agreement (this Ã¢â‚¬Å“AgreementÃ¢â‚¬ï¿½) is made and entered into between you and Prosper Funding LLC (Ã¢â‚¬Å“ProsperÃ¢â‚¬ï¿½).\nThe Prosper marketplace is an online credit platform (the Ã¢â‚¬Å“PlatformÃ¢â‚¬ï¿½) operated by Prosper.  Among other things, Prosper offers access to unsecured personal loans in the form of the promissory note attached hereto as Exhibit A (the Ã¢â‚¬Å“Promissory NoteÃ¢â‚¬ï¿½). All loans originated through the Platform are made by WebBank, a Utah-chartered industrial bank (Ã¢â‚¬Å“WebBankÃ¢â‚¬ï¿½ or Ã¢â‚¬Å“BankÃ¢â‚¬ï¿½). A separate legal entity, Prosper Marketplace, Inc. (Ã¢â‚¬Å“PMIÃ¢â‚¬ï¿½), provides services to Bank in connection with the origination of such loans. Prosper services all loans made through the Platform, but has engaged certain third parties (including PMI) to act as agents of Prosper in the performance of such servicing. The following Agreement describes those services as well as your rights and obligations should you elect to register as a borrower on the Platform. Except for Section 22, when used in this Agreement Ã¢â‚¬Å“weÃ¢â‚¬ï¿½ or Ã¢â‚¬Å“usÃ¢â‚¬ï¿½ refers to Prosper, Bank and their respective agents and affiliates (including without limitation PMI in its capacity as agent of Prosper or Bank, and Prosper Healthcare Lending).\n";

        public static String REGISTRATION_AS_A_PROSPER_BORROWER =
                "1. Registration as a Prosper Borrower. You are registering with Prosper as a borrower so that you can make loan requests or Ã¢â‚¬Å“listingsÃ¢â‚¬ï¿½ through the Platform. In entering into this Agreement, you are agreeing to comply with the Terms of Use for the Platform as well as any other rules or policies set forth on ProsperÃ¢â‚¬â„¢s website (www.prosper.com), any of which may be amended from time to time by Prosper in its sole discretion (collectively, as amended, the Ã¢â‚¬Å“Prosper Terms and ConditionsÃ¢â‚¬ï¿½). The Prosper Terms and Conditions are accessible via a link marked Ã¢â‚¬Å“PoliciesÃ¢â‚¬ï¿½ at the bottom of each page of ProsperÃ¢â‚¬â„¢s website.\nWe reserve the right to restrict access to the Platform to individuals who meet minimum credit guidelines and other criteria, as determined by us in our sole discretion.";

        public static String AUTHORIZATION_TO_OBTAIN_CREDIT_REPORT =
                "2. Authorization to Obtain Credit Report. By registering on the Platform as a borrower, you authorize us or our agents (including PMI), to obtain a credit report from one or more consumer credit reporting agencies. We may use the credit report for any purpose that would be authorized by applicable law in connection with a credit transaction involving you and involving the extension of credit to you or review or collection of your account, including but not limited to (i) for authentication purposes, to make sure you are who you say you are; (ii) to make credit decisions; (iii) for internal modeling and analysis purposes; (iv) to administer the sale of any Borrower Payment Dependent Notes (Ã¢â‚¬Å“NotesÃ¢â‚¬ï¿½) associated with your loan or the sale of your loan in its entirety; (v) to determine how much debt you currently have, in order to determine your debt-to-income ratio; (vi) to obtain your credit score and assign you a Prosper Rating based in part on that score; (vii) to obtain and display information and characteristics from your credit report from one or more consumer credit reporting agencies; and (ix) to obtain and display on the Folio Investing Note Trader Platform certain information and characteristics from your credit report from one or more consumer credit reporting agencies at any time or times that a Note corresponding to your loan is offered for sale by investors holding such Notes. Information from your credit report will be displayed on the Prosper website with your listing. You authorize us to verify information in your credit report and your listing, and you agree that Prosper, Bank or PMI (in its capacity as agent of Prosper or Bank) may contact third parties without further notice to you to verify any such information. We may obtain your credit report each time you create a listing and at any other time in our sole discretion, including in connection with loan servicing or collection.";

        public static String LISTINGS =
                "3. Listings. The Platform connects applicants who wish to obtain loans with investor members who wish to help fund them. To receive a loan, you, a borrower member, must submit a loan listing through the Platform. The listing is a request by you for a loan in the amount and at the interest rate specified in the listing. In order to submit a listing through the Platform, you must have a good faith intent to obtain and repay your loan, and your listing must be consistent with that intent.\nIn order for your listing to become a loan, you must receive aggregate funding commitments from Prosper investor members that equal or exceed the minimum funding amount applicable to your listing. After you submit your listing and complete certain verification stages, Prosper will automatically allocate your listing to one of three funding channels, based upon a random allocation methodology determined by Prosper: (i) the first channel allows investor members to commit to purchase Notes from Prosper, the payments of which are dependent on the payments you make on your loan (the Ã¢â‚¬Å“Note ChannelÃ¢â‚¬ï¿½); (ii) the second channel allows investor members to commit to purchase 100% of your loan directly from Prosper (Ã¢â‚¬Å“Active Loan ChannelÃ¢â‚¬ï¿½); and (iii) the third channel reserves your loan for sale to an investor member who has already committed to purchase loans like yours from Prosper (Ã¢â‚¬Å“Passive Loan ChannelÃ¢â‚¬ï¿½). Prosper may add or remove funding channels at any time in its sole discretion.\nIf your listing receives sufficient commitments to fund, Bank will originate a loan to you in an amount equal to the total amount of those commitments. If your listing is allocated to Passive Loan Channel, it will automatically be considered to have received a commitment equal to the amount of the loan requested. If your listing is allocated to the Note Channel, investor members who purchase Notes tied to your loan may resell those Notes to other investor members on our secondary trading platform (the Ã¢â‚¬Å“Note Trader PlatformÃ¢â‚¬ï¿½). Prosper may add or remove secondary trading platforms at any time in its sole discretion.\nInformation Included in Listings. To submit a listing, you must provide the amount of the loan you are requesting as well as your annual income, occupation and employment status. The minimum and maximum loan amounts you may request are posted on the Prosper website and are subject to change by us at any time without notice. We reserve the right to restrict the submission of listings through the Platform to applicants who meet minimum credit guidelines and other criteria, as determined by us in our sole discretion.\nYou authorize and agree that we may include in your listing any information from the credit report we obtain pursuant to Section 2 above, including but not limited to the following information:\n(i) Your Prosper Rating, which is calculated by us but based on information from your credit report;\n(ii) Your debt-to-income ratio, expressed as a percentage, reflecting the ratio between the amount of your monthly non-mortgage debt, as compared to the amount of monthly income that you indicated when completing your listing;\n(iii) Whether you own a home;\n(iv) The number of accounts on which you are currently late on a payment;\n(v) The total past-due amount you owe on all delinquent and charged-off accounts;\n(vi) The number of 90+ days past due delinquencies on your credit report;\n(vii) The number of negative public records (e.g., bankruptcies, liens, and judgments) on your credit report over the last 12 months, and over the last 10 years;\n(viii) The month and year the oldest account on your credit report (e.g., revolving, installment, or mortgage credit) was opened;\n(ix) The total number of credit lines appearing on your credit report, along with the number that are open and current;\n(x) The total balance on all of your open revolving credit lines;\n(xi) Your bankcard utilization ratio, expressed as a percentage, reflecting the ratio of the total balance used, to the aggregate credit limit on, all of your open bankcards; and\n(xii) The number of inquiries made by creditors to your credit report in the last six months.\nIn addition, you authorize and agree that we may display any of the above information in a listing for a Note corresponding to your loan on the Note Trader Platform, and that we may display updated information from your credit report, as well as information about the payment history and status of your loan, in any such listing.\nListings displayed on either Platform may also include any information we ask you to provide, including, without limitation, your self-reported occupation, employment status and range of income. You authorize us to verify your residence, income, employment and any other information you provide in connection with a listing or your registration as a borrower, and you agree that we may contact third parties to verify information you provide. If any such information changes after you submit a listing but before the listing expires, you must either (i) promptly notify us of the change, or (ii) if the listing was allocated to the Note Channel or Active Loan Channel, withdraw your listing.\nIn creating your listing, or posting content on your Prosper member web page or anywhere else on ProsperÃ¢â‚¬â„¢s website, you may not include (i) any personally identifiable information, including, without limitation, your name, address, phone number, email address, Social Security number, driverÃ¢â‚¬â„¢s license number, bank account number or credit card number, (ii) any information that reveals your race, color, religion, national origin, sex, marital status, age, sexual orientation, military status, source of income, or plans for having a family, and (iii) any information that is inconsistent with your obligations to refrain from engaging in any Prohibited Activities (as defined below) (any information of the type described in parts (i), (ii) or (iii) being, Ã¢â‚¬Å“Prohibited InformationÃ¢â‚¬ï¿½). We may take remedial action with respect to any Prohibited Information you post on ProsperÃ¢â‚¬â„¢s web site, including without limitation canceling any listing containing Prohibited Information or deleting or modifying all or any portion of a listing description or other content that contains Prohibited Information; provided, however, that we are under no obligation to take any such action, and any posting of Prohibited Information by you on ProsperÃ¢â‚¬â„¢s web site is done solely at your own risk.\nListings Allocated to the Note Channel. Any person who visits the Prosper website will be able to view your listing and see your Prosper Rating as well as certain information about the loan you have requested; provided, however, information from your credit report will only be viewable by investor members.\nWe may elect in our sole discretion to give you a partial funding option, which means your loan will be funded if it receives commitments totaling less than the full amount of your requested loan but equal to or exceeding 70% of that amount (subject to the loan size minimum). Each loan listing related to a borrower who was offered the partial funding option will indicate the minimum amount required for the loan to fund. The current percentage threshold for partial funding is 70%, but we may change that threshold from time to time. Any such change will only affect listings created after the change is made.\nDuration of Listings. A listing will expire on the earlier of (a) the time at which it has received commitments equal to the full amount of the loan requested (which could be immediately after being listed) or (b) if allocated to the Note Channel, 14 days after being posted, unless the listing is withdrawn by you or cancelled by us prior to either of those events. If a listing is allocated to Active Loan Channel and does not receive commitments sufficient to fund within one (1) hour of being posted, it will automatically be reallocated to the Note Channel.\nWITHDRAWAL OF LISTINGS. YOU HAVE THE RIGHT TO WITHDRAW YOUR LISTING AT ANY TIME PRIOR TO THE EXPIRATION OF THE LISTING PERIOD AS DESCRIBED ABOVE. AFTER THE LISTING PERIOD EXPIRES, YOU WILL NO LONGER HAVE THE RIGHT TO WITHDRAW YOUR LISTING. IF A LOAN IS MADE TO YOU, YOU DO NOT HAVE ANY RIGHT TO RESCIND THE LOAN.\nIf you elect to withdraw your listing, you may (but are not required to) submit a new listing. We reserve the right, in our sole discretion, to limit the number of listings you submit or attempt to submit through the Platform.\nAdditional Loans. The guidelines and eligibility requirements for additional loans are posted on the Prosper website and are subject to change by us in our sole discretion at any time without notice. Subject to these requirements, you may have up to two loans outstanding at any one time, provided that the aggregate outstanding principal balance of your loans does not exceed the maximum loan amount then in effect. You may not submit a listing for a second loan unless you meet the eligibility requirements then in effect as of the date of such submission.\nProhibited Activities. You agree that you will not, in connection with any listings, investor commitments, loans or other transactions involving or potentially involving Prosper or Bank, (i) make any false, misleading or deceptive statements or omissions of material fact; (ii) misrepresent your identity, or describe, present or portray yourself as a person other than yourself; (iii) give to or receive from, or offer or agree to give to or receive from, any Prosper investor member or other person any fee, bonus, additional interest, kickback or thing of value of any kind, including in exchange for such personÃ¢â‚¬â„¢s commitment, recommendation, or offer or agreement to recommend or make a commitment with respect to your listing; and (iv) represent yourself to any person as a director, officer or employee of Prosper, PMI or Bank, unless you are such director, officer or employee.";

        public static String RIGHT_TO_VERIFY_INFORMATION =
                "4. Right to Verify Information and Cancel Funding.\na. We reserve the right to verify the accuracy of all information provided by borrower and investor members in connection with listings, investor commitments and loans. We also reserve the right to determine in our sole discretion whether a registered user is using, or has used, the Prosper website illegally or in violation of any order, writ, injunction or decree of any court or governmental instrumentality, for purposes of fraud or deception, or otherwise in a manner inconsistent with the Prosper Terms and Conditions or any agreement between Prosper or Bank and such user. We may conduct our review at any time Ã¢â‚¬â€œ before, during or after the submission of a listing, or before or after the funding of a loan. You agree to respond promptly to our requests for information in connection with any such review by us.\nb. In the event we determine, prior to funding a loan, that a listing, or an investor commitment for the listing, contains materially inaccurate information (including but not limited to unintended inaccuracies, inaccuracies resulting from errors by us, or inaccuracies resulting from changes in the borrowerÃ¢â‚¬â„¢s income, residence or credit profile between the date a listing is submitted and the date the listing is to be funded) or was submitted illegally, in violation of any order, writ, injunction or decree of any court or governmental instrumentality, for purposes of fraud or deception, or otherwise in a manner inconsistent with the Prosper Terms and Conditions or any member agreement, or was generated in error or is otherwise inconsistent with the applicable credit policy and criteria, we may refuse to accept the listing or, if the listing has already been accepted, remove the listing from the Platform and cancel all investor commitments with respect to the listing.\nc. When a listing receives commitments equal to or exceeding the minimum amount required for the loan to fund, we may conduct a Ã¢â‚¬Å“pre-fundingÃ¢â‚¬ï¿½ review prior to funding the loan. Loan funding occurs when loan proceeds are disbursed to or at the direction of the borrower. We may, at any time and in our sole discretion, delay funding of a loan (i) in order to enable us to verify the accuracy of information provided by borrower members, investor members in connection with the listing or investor commitments made with respect to the listing; (ii) to determine whether there are any irregularities with respect to the listing or the investor commitments; or (iii) if we become aware of information concerning the borrower member or the listing during our pre-funding review, as a result of which we determine, in our sole discretion, that the likelihood of the borrower not making payments on the loan is materially greater than would be expected based on the assigned Prosper Rating. We may cancel or proceed with funding the loan, depending on the results of our pre-funding review. If funding is cancelled, the listing will be removed from the Platform and all investor commitments against the listing will be cancelled. In the event we cancel funding of a loan, we will notify the borrower, and all investor members who made commitments with respect to the listing of such cancellation.\nd. We may verify any of the information you provide in applying for a loan and creating a listing, and may require that you submit evidence sufficient to permit us to verify the information you provided or other information we deem necessary. We have sole discretion to determine what evidence suffices, and it is your obligation to provide that evidence. If you fail to do so within a reasonable timeframe within our discretion, we may cancel your listing.  However, if we are able to obtain the information we require from other sources, or determine that the information is no longer necessary, your loan may originate even though you have not submitted the required documents.";

        public static String MATCHING_OF_INVESTOR =
                "5. Matching of Investor Commitments and Listings; Loan Funding.\na. If your listing is allocated to the Note Channel, Prosper investor members will be able to view your listing and commit funds to purchase Notes issued by Prosper, the payments on which will be dependent on payments Prosper receives from you on your loan. In other words, the Prosper investor members who committed funds will receive payments on their Notes only to the extent you make payments on your loan. If your listing is allocated to the Active Loan Channel or the Passive Loan Channel, Prosper investor members will commit funds to purchase from Prosper a Promissory Note evidencing the loan made by Bank to you.\nb. A match of your listing with one or more investor commitments equal to or exceeding the minimum amount required for the loan to fund, will result in a loan from Bank to you, subject to our right to verify information as described above. The loan will be evidenced by a Promissory Note in the form set forth on the attached Exhibit A. Depending on the loan product you receive, loan proceeds are disbursed into your designated deposit account or they are paid directly to a merchant in satisfaction of your purchase of goods and/or services from that merchant. The loan may be sold by Bank to Prosper, and Prosper may hold the loan or sell it to one of its investor members. Prosper or its agents will service the loan on behalf of the loanÃ¢â‚¬â„¢s owner.\nc. We do not warrant or guaranty that your listing will be matched with any investor commitments. Your listing must receive one or more investor commitments equal to or exceeding the minimum amount required for the loan to fund in order for a loan to be made.\nd. To safeguard your privacy rights, your name and address will not be included in your listing. Only your Prosper screen name will appear on your listing, and only the screen name of the investor members will appear with investor commitments.";

        public static String COMPENSATION =
                "6. Compensation. If you receive a loan, you must pay Bank a non-refundable origination fee. The amount of the estimated origination fee is stated in the disclosures provided to you at the time you apply. This amount will decline if youÃ¢â‚¬â„¢ve been offered a partial funding option and your loan is not 100% funded. Notwithstanding the foregoing, no amount of the finally determined fee is refundable. The finally determined fee will be stated in your Truth in Lending disclosure. This fee will be deducted from your loan proceeds, so the loan proceeds delivered to you or at your direction will be less than the full amount of your issued loan. You acknowledge that the origination fee will be considered part of the principal on your loan and is subject to the accrual of interest.";

        public static String MAKING_YOUR_LOAN_PAYMENTS =
                "7. Making Your Loan Payments. At the time you register as a borrower, you must provide your bank account information to facilitate transfers of funds to and from your bank account. You agree to make your loan payments by automated withdrawals from your designated account, by manual payments you initiate from your designated account, with the first payment being scheduled during the application process, or by check (you must call customer service at 1-866-615-6319 to arrange payment by check). Your loan payments will be made by the payment method you choose. Prosper or its agents will act as the servicer for all loans you obtain through the Platform, and all communications regarding your loan must be made to Prosper or its agents.";

        public static String COLLECTION_AND_REPORTING =
                "8. Collection & Reporting of Delinquent Loans. In the event you do not make your loan payments on time, Bank or any subsequent owner of the loan will have all remedies authorized or permitted by the Promissory Note and applicable law. In addition, if you fail to make timely payments on your loan, your loan may be referred to a collection agency for collection. Prosper or its agents may report loan payment delinquencies in excess of thirty (30) days to one or more credit reporting agencies in accordance with applicable law. See the Ã¢â‚¬Å“Permission to ContactÃ¢â‚¬ï¿½ section below for additional important information.";

        public static String NO_GUARANTEE =
                "9. No Guarantee. Neither Prosper nor Bank warrants or guarantees (1) that your listing will be matched with any investor commitments, or (2) that you will receive a loan as a result of submitting a listing.";

        public static String RESTRICTIONS_ON_USE =
                "10. Restrictions on Use. You are not authorized or permitted to use the Prosper website to obtain, or attempt to obtain, a loan for someone other than yourself. You are not authorized or permitted to use the Prosper website to obtain, or attempt to obtain, a loan for the purpose of (i) buying, carrying or trading in securities or for the purpose of buying or carrying any part of an investment contract security, (ii) paying for postsecondary educational expenses (i.e., tuition, fees, required equipment or supplies, or room and board) at a college/university/vocational school, as the term Ã¢â‚¬Å“postsecondary educational expensesÃ¢â‚¬ï¿½ is defined in Bureau of Consumer Financial Protection Regulation Z, 12 C.F.R. Ã‚Â§ 1026.46(b)(3), or (iii) engaging in any illegal activity or gambling, and you warrant, represent and agree that you will not use the proceeds of any loan for such purposes. You must be an owner of the deposit account you designate for electronic transfers of funds, with authority to direct that loan payments be made from the account. Your designated account will be the account from which loan payments will be made. Although you are registering as a borrower member, you may also register and participate on the Platform as an investor member. If you participate on the Platform as an investor member, any amounts in your Prosper funding account are subject to set-off against any delinquent amounts owing on any loans you obtain as a Prosper borrower. You will not receive further notice in advance of our exercising our right to set-off amounts in your Prosper funding account against any delinquent amounts owing on any loans you obtain. If you obtain a loan and fail to pay your loan in full, whether due to default, bankruptcy or other reasons, you will not be eligible to submit any further listings or re-register with Prosper as a borrower or investor member. We may in our sole discretion, with or without cause and with or without notice, restrict your access to the Prosper website or Platform.";

        public static String AUTHORITY =
                "11. Authority. You warrant and represent that you have the legal competence and capacity to execute and perform this Agreement.";

        public static String TERMINATION_OF_REGISTRATION =
                "12. Termination of Registration. Prosper may, in its sole discretion, with or without cause, terminate this Agreement at any time by giving you notice as provided below. In addition, upon our determination that you committed fraud or made a material misrepresentation in connection with a listing, investor commitment or loan, performed any prohibited activity, or otherwise failed to abide by the terms of this Agreement or the Prosper Terms and Conditions, we may, in our sole discretion, immediately and without notice, take one or more of the following actions: (i) terminate or suspend your right to submit listings or otherwise participate on the Platform; or (ii) terminate this Agreement and your registration with Prosper. Upon termination of this Agreement and your registration with Prosper, any listings you have submitted through the Platform shall be cancelled, and will be removed from the Platform immediately. Any loans you obtain prior to the effective date of termination resulting from listings you had placed on the Platform shall remain in full force and effect in accordance with their terms.";

        public static String PROSPER_RIGHT_TO_MODIFY_TERMS =
                "13. ProsperÃ¢â‚¬â„¢s Right to Modify Terms. Prosper has the right to change any term or provision of this Agreement or the Prosper Terms and Conditions. Prosper will give you notice of material changes to this Agreement, or the Prosper Terms and Conditions, in the manner set forth in Section 15. You authorize us to correct obvious clerical errors appearing in information you provide to us, without notice to you, although we expressly undertake no obligation to identify or correct such errors. This Agreement, along with the Prosper Terms and Conditions, represents the entire agreement between you and Prosper regarding your participation as a borrower on the Platform, and supersedes all prior or contemporaneous communications, promises and proposals, whether oral, written or electronic, between you and Prosper with respect to your involvement as a borrower on the Platform.";

        public static String MEMBER_WEB_PAGE_DISPLAY =
                "14. Member Web Page Display and Content. You may, but are not required to, maintain a Ã¢â‚¬Å“Prosper member web pageÃ¢â‚¬ï¿½ on the Prosper website, where you can post content, logos or links to websites. If you elect to do so, you authorize us to display on the Prosper website all such material you provide. Any material you display on your member page must conform to the Prosper Terms and Conditions, and material you display or link to must not (i) infringe on ProsperÃ¢â‚¬â„¢s or any third partyÃ¢â‚¬â„¢s copyright, patent, trademark, trade secret or other proprietary rights or right of publicity or privacy; (ii) violate any applicable law, statute, ordinance or regulation; (iii) be defamatory or libelous; (iv) be lewd, hateful, violent, pornographic or obscene; (v) violate any laws regarding unfair competition, anti-discrimination or false advertising; (vi) promote violence or contain hate speech; or (vii) contain viruses, trojan horses, worms, time bombs, cancelbots or other similar harmful or deleterious programming routines. You may not include or display any personally identifying information of any Prosper member on your Prosper member web page or elsewhere on the Prosper website, including, without limitation, any Prosper memberÃ¢â‚¬â„¢s name, address, phone number, email address, Social Security number, driverÃ¢â‚¬â„¢s license number, bank account number or credit card number.";

        public static String NOTICES =
                "15. Notices. All notices and other communications hereunder shall be given either by: (1) email to your registered email address; (2) message to your Prosper message inbox; (3) posting on your Prosper accountÃ¢â‚¬â„¢s login, post-login, or home page; (4) posting to the History section (or one of its subsections) of your Prosper account; (5) posting on the Prosper website, or (6) deposit with U.S. mail or other nationally recognized courier, and shall be deemed to have been duly given and effective upon transmission or posting. It is your responsibility to monitor these areas. You can contact us by sending an email to support@prosper.com. You agree to notify Prosper if your registered email address changes, and you agree to update your registered residence address, mailing address and telephone number on the Prosper website if any of those items changes.";

        public static String NO_WARRANTIES =
                "16. No Warranties. Except for the representations contained in this Agreement, Prosper does not make any representations or warranties to you or any other party with regard to your use of the Prosper website or the Platform, including, but not limited to, any implied warranties of merchantability or fitness for a particular purpose.";

        public static String LIMITATION_ON_LIABILITY =
                "17. Limitation on Liability. In no event shall any party to this Agreement be liable to any other party for any lost profits or special, exemplary, consequential or punitive damages, even if informed of the possibility of such damages. Furthermore, neither party makes any representation or warranty to any other party regarding the effect that the Agreement may have upon the foreign, federal, state or local tax liability of the other.";

        public static String STATE_NOTICES =
                "18. STATE NOTICES\nCalifornia Residents: Married registrants may apply for a separate account.\nOhio Residents: The Ohio laws against discrimination require that all creditors make credit equally available to all credit worthy customers, and that credit reporting agencies maintain separate credit histories on each individual upon request. The Ohio civil rights commission administers compliance with this law.\nTexas Residents: Prosper Marketplace, Inc. is licensed and examined by the State of TexasÃ¢â‚¬â€˜Ã¢â‚¬â€˜Office of Consumer Credit Commissioner. Call the Consumer Credit Hotline or write for credit information or assistance with credit problems. Office of Consumer Credit Commissioner, 2601 North Lamar Boulevard, Austin, Texas 78705Ã¢â‚¬â€˜4207, (800) 538Ã¢â‚¬â€˜1579, www.occc.state.tx.us.\nWisconsin Residents: No provision of a marital property agreement, a unilateral statement or a court decree adversely affects the interest of the creditor unless the creditor, prior to the time the credit is granted, is furnished a copy of the agreement, statement or decree or has actual knowledge of the adverse provision when the obligation to the creditor is incurred.\nPlease see the attached Promissory Note for additional important state notices.";

        public static String MISCELLANEOUS =
                "19. Miscellaneous. You may not assign, transfer, sublicense or otherwise delegate your rights under this Agreement to another person without ProsperÃ¢â‚¬â„¢s prior written consent. Prosper may assign this Agreement at any time without your permission, unless prohibited by applicable law. Any such assignment, transfer, sublicense or delegation in violation of this Section 19 shall be null and void. This Agreement shall be governed by federal law and, to the extent that state law applies, the laws of the State of Delaware. Any waiver of a breach of any provision of this Agreement will not be a waiver of any other breach. Failure or delay by either party to enforce any term or condition of this Agreement will not constitute a waiver of such term or condition. If any part of this Agreement is determined to be invalid or unenforceable under applicable law, then the invalid or unenforceable provision will be deemed superseded by a valid enforceable provision that most closely matches the intent of the original provision, and the remainder of the Agreement shall continue in effect. Bank is not a party to this Agreement, but you agree that Bank is a third-party beneficiary and is entitled to rely on the provisions of this Agreement, including without limitation your representations, covenants and agreements herein. There are no third party beneficiaries to this Agreement other than Bank.";

        public static String PERFORMANCE_BY_PROSPER =
                "20. Performance by Prosper and Bank. You acknowledge and agree that any obligations of or actions by Prosper under this Agreement may be performed by PMI on behalf of Prosper in PMIÃ¢â‚¬â„¢s capacity as servicer or agent of Prosper under any administrative services or similar agreement entered into between PMI and Prosper pursuant to which Prosper appoints PMI as servicer or agent to provide administrative, management, servicing or other services to Prosper. You also acknowledge and agree that any obligations of or actions by Bank under this Agreement may be performed by PMI on behalf of Bank in PMIÃ¢â‚¬â„¢s capacity as agent of Bank under any loan program or similar agreement entered into between PMI and Bank pursuant to which Bank appoints PMI as agent to provide services to Bank.";

        public static String SEPARATE_ENTITIES =
                "21. Separate Entities. Notwithstanding Section 20, you acknowledge and agree that Prosper, Bank and PMI are separate legal entities and that neither entity has guaranteed the performance by the other entity of its obligations hereunder.";

        public static String ARBITRATION =
                "22. Arbitration. RESOLUTION OF DISPUTES: YOU ACKNOWLEDGE THAT YOU HAVE READ THIS PROVISION CAREFULLY, AND UNDERSTAND THAT IT LIMITS YOUR RIGHTS IN THE EVENT OF A DISPUTE BETWEEN YOU AND US. YOU UNDERSTAND THAT YOU HAVE THE RIGHT TO REJECT THIS PROVISION, AS PROVIDED IN PARAGRAPH (i) BELOW.\n(a) In this Resolution of Disputes provision:\n(i) Ã¢â‚¬Å“YouÃ¢â‚¬ï¿½ and Ã¢â‚¬Å“yourÃ¢â‚¬ï¿½ mean the individual entering into this Agreement, as well as any person claiming through such individual;\n(ii) Ã¢â‚¬Å“WeÃ¢â‚¬ï¿½ and Ã¢â‚¬Å“usÃ¢â‚¬ï¿½ mean Bank and Prosper Funding LLC and each of their respective parents, subsidiaries, affiliates, predecessors, successors, and assigns, as well as the officers, directors, and employees of each of them;\n(iii) Ã¢â‚¬Å“ClaimÃ¢â‚¬ï¿½ means any dispute, claim, or controversy (whether based on contract, tort, intentional tort, constitution, statute, ordinance, common law, or equity, whether pre-existing, present, or future, and whether seeking monetary, injunctive, declaratory, or any other relief) arising from or relating to this Agreement or the relationship between us and you (including claims arising prior to or after the date of the Agreement, and claims that are currently the subject of purported class action litigation in which you are not a member of a certified class), and includes claims that are brought as counterclaims, cross claims, third party claims or otherwise, as well as disputes about the validity or enforceability of this Agreement or the validity or enforceability of this Section 22.\n(b) Any Claim shall be resolved, upon the election of either us or you, by binding arbitration administered by the American Arbitration Association or JAMS, under the applicable arbitration rules of the administrator in effect at the time a Claim is filed (Ã¢â‚¬Å“RulesÃ¢â‚¬ï¿½). Any arbitration under this Agreement will take place on an individual basis; class arbitrations and class actions are not permitted. If you file a claim, you may choose the administrator; if we file a claim, we may choose the administrator, but we agree to change to the other permitted administrator at your request (assuming that the other administrator is available). You can obtain the Rules and other information about initiating arbitration by contacting the American Arbitration Association at 1633 Broadway, 10th Floor, New York, NY 10019, (800) 778-7879, www.adr.org; or by contacting JAMS at 1920 Main Street, Suite 300, Irvine, CA 92614, (949) 224-1810, www.jamsadr.com. The address for serving any arbitration demand or claim on us is Prosper Marketplace, Inc., 221 Main Street, Suite 300, San Francisco, CA 94105, Attention: Compliance.\n(c) Claims will be arbitrated by a single, neutral arbitrator, who shall be a retired judge or a lawyer with at least ten yearsÃ¢â‚¬â„¢ experience. We agree not to invoke our right to elect arbitration of an individual Claim filed by you in a small claims or similar court (if any), so long as the Claim is pending on an individual basis only in such court.\n(d) We will pay all filing and administration fees charged by the administrator and arbitrator fees up to $1,000, and we will consider your request to pay any additional arbitration costs. If an arbitrator issues an award in our favor, you will not be required to reimburse us for any fees we have previously paid to the administrator or for which we are responsible. If you receive an award from the arbitrator, we will reimburse you for any fees paid by you to the administrator or arbitrator. Each party shall bear its own attorneyÃ¢â‚¬â„¢s, expertÃ¢â‚¬â„¢s and witness fees, which shall not be considered costs of arbitration; however, if a statute gives you the right to recover these fees, or fees paid to the administrator or arbitrator, then these statutory rights will apply in arbitration.\n(e) Any in-person arbitration hearing will be held in the city with the federal district court closest to your residence, or in such other location as you and we may mutually agree. The arbitrator shall apply applicable substantive law consistent with the Federal Arbitration Act, 9 U.S.C. Ã‚Â§ 1-16, and, if requested by either party, provide written reasoned findings of fact and conclusions of law. The arbitrator shall have the power to award any relief authorized under applicable law. Any appropriate court may enter judgment upon the arbitratorÃ¢â‚¬â„¢s award. The arbitratorÃ¢â‚¬â„¢s decision will be final and binding except that: (1) any party may exercise any appeal right under the FAA; and (2) any party may appeal any award relating to a claim for more than $100,000 to a three-arbitrator panel appointed by the administrator, which will reconsider de novo any aspect of the appealed award. The panelÃ¢â‚¬â„¢s decision will be final and binding, except for any appeal right under the FAA. Unless applicable law provides otherwise, the appealing party will pay the appealÃ¢â‚¬â„¢s cost, regardless of its outcome. However, we will consider any reasonable written request by you for us to bear the cost.\n(f) YOU AND WE AGREE THAT EACH MAY BRING CLAIMS AGAINST THE OTHER ONLY IN OUR INDIVIDUAL CAPACITY, AND NOT AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS OR REPRESENTATIVE PROCEEDING. Further, unless both you and we agree otherwise in writing, the arbitrator may not consolidate more than one personÃ¢â‚¬â„¢s claims. The arbitrator shall have no power to arbitrate any Claims on a class action basis or Claims brought in a purported representative capacity on behalf of the general public, other borrowers, or other persons similarly situated. The validity and effect of this paragraph (f) shall be determined exclusively by a court, and not by the administrator or any arbitrator.\n(g) If any portion of this Section 22 is deemed invalid or unenforceable for any reason, it shall not invalidate the remaining portions of this section. However, if paragraph (f) of this Section 22 is deemed invalid or unenforceable in whole or in part, then this entire Section 22 shall be deemed invalid and unenforceable. The terms of this Section 22 will prevail if there is any conflict between the Rules and this section.\n(h) YOU AND WE AGREE THAT, BY ENTERING INTO THIS AGREEMENT, THE PARTIES ARE EACH WAIVING THE RIGHT TO A TRIAL BY JURY OR TO PARTICIPATE IN A CLASS ACTION. YOU AND WE ACKNOWLEDGE THAT ARBITRATION WILL LIMIT OUR LEGAL RIGHTS, INCLUDING THE RIGHT TO PARTICIPATE IN A CLASS ACTION, THE RIGHT TO A JURY TRIAL, THE RIGHT TO CONDUCT FULL DISCOVERY, AND THE RIGHT TO APPEAL (EXCEPT AS PERMITTED IN PARAGRAPH (e) OR UNDER THE FEDERAL ARBITRATION ACT).\n(i) You understand that you may reject the provisions of this Section 22, in which case neither us nor you will have the right to elect arbitration. Rejection of this Section 22 will not affect the remaining parts of this Agreement. To reject this Section 22, you must send us written notice of your rejection within 30 days after the date that this Agreement was made. You must include your name, address, and account number. The notice of rejection must be mailed to Prosper Marketplace, Inc., 221 Main Street, Suite 300, San Francisco, CA 94105, Attention: Legal Department. This is the only way that you can reject this Section 22.\n(j) You and we acknowledge and agree that the arbitration agreement set forth in this Section 22 is made pursuant to a transaction involving interstate commerce, and thus the Federal Arbitration Act shall govern the interpretation and enforcement of this Section 22. This Section 22 shall survive the termination of this Agreement.\n(k) This section shall not apply to covered borrowers as defined in the Military Lending Act.";

        public static String ELECTRONIC_TRANSACTIONS =
                "23. Electronic Transactions. This Agreement includes your express consent to electronic transactions and disclosures, which consent is set forth in the section entitled Ã¢â‚¬Å“Consent to Doing Business ElectronicallyÃ¢â‚¬ï¿½ as disclosed in our Terms of Use on our website, the terms and conditions of which are expressly incorporated herein in their entirety. You expressly agree that each of (a) this Agreement and (b) any Promissory Note in the form set forth on the attached Exhibit A that we sign on your behalf, may comprise a Ã¢â‚¬Å“transferable recordÃ¢â‚¬ï¿½ for all purposes under the Electronic Signatures in Global and National Commerce Act and the Uniform Electronic Transactions Act.";

        public static String PERMISSION_TO_CONTACT =
                "24. Permission to Contact.  When you give us your home and/or mobile phone number, we have your permission to contact you at that number or numbers, and any other number we believe we may reach you through (unless prohibited by applicable law), about your Prosper accounts.  Your consent allows us to use text messaging, artificial or prerecorded voice messages and automatic dialing technology, for all purposes not prohibited by applicable law. Message and data rates may apply. You may contact us anytime to change these preferences. We may also send an email to any address where we reasonably believe we can contact you. Some of the purposes for calls and messages include: suspected fraud or identity theft; obtaining information; transactions on or servicing of your account; and collecting on your account. Our rights under this Section extend to our affiliates, subsidiaries, parents, agents, vendors, and anyone so affiliated with the owner of any note evidencing a loan you obtain. Notify us immediately of any changes to your contact information by changing your contact information on your Prosper account information Ã¢â‚¬â€œ settings page.";

        public static String APPOINTMENT =
                "25. Appointment of Limited Power of Attorney and Note Registrar. If your listing receives sufficient investor commitments to fund, and you do not withdraw your listing prior to expiration of the listing period, you hereby authorize each of Prosper and PMI (and their affiliates) to act as your true and lawful Attorney-in-Fact and agent, with full power of delegation and substitution, for you in your name, place and stead, in any and all capacities, to complete and execute a Promissory Note containing the material terms set forth on the attached Exhibit A on your behalf in favor of Bank and reflecting the debt obligation reflected on your final Truth in Lending disclosure(s). You further authorize Prosper and PMI (and their affiliates) to (i) perform each and every act necessary to be done in connection with executing such Promissory Note as you might or could do in person and (ii) approve, execute and deliver the provisions of any instruments, documents, agreements, powers, releases and certificates related to the Promissory Note and to perform each and every actions regarding the same, including but not limited to, any legal or beneficial assignment of the Promissory Note. This Power of Attorney is limited to the purpose described above.\nThis Power of Attorney may be revoked by contacting Prosper by emailing us at support@prosper.com or calling us at 1-866-615-6319 and closing your account only if done prior to the origination of your loan and execution of the Promissory Note on your behalf. If you choose to revoke this Power of Attorney prior to execution, we will be unable to process your loan request and any pending loan request will be considered withdrawn. Any act or thing lawfully done hereunder prior to any revocation and within the powers herein by any attorney in fact shall be binding on you and your heirs, legal and personal representatives and assigns.\nYou further appoint Prosper as your authorized agent (in such capacity the Ã¢â‚¬Å“Note RegistrarÃ¢â‚¬ï¿½) to maintain a book-entry system (the Ã¢â‚¬Å“RegisterÃ¢â‚¬ï¿½) identifying the owners of such Promissory Note and the ownersÃ¢â‚¬â„¢ addresses and payment instructions. The person or persons identified as owners of such Promissory Note in the Register shall be deemed to be the owner(s) of the Promissory Note for purposes of receiving payment of principal and interest on such Promissory Note and for all other purposes. Any transfer of such Promissory Note shall be effective only upon being recorded in the Register. The Note Registrar may retain the services of another party to fulfill its duties as Note Registrar. The Note RegistrarÃ¢â‚¬â„¢s recordkeeping obligations will be unaffected by any transfers of the Promissory Note.";

        public static String MILITARY_LENDING =
                "26. Military Lending Act. The Military Lending Act provides specific protections for active duty service members and their dependents in consumer credit transactions. This Section includes information on the protections provided to covered borrowers as defined in the Military Lending Act.\n(a) Statement of MAPR.\nFederal law provides important protections to members of the Armed Forces and their dependents relating to extensions of consumer credit. In general, the cost of consumer credit to a member of the Armed Forces and his or her dependent may not exceed an annual percentage rate of 36 percent. This rate must include, as applicable to the credit transaction or account: The costs associated with credit insurance premiums; fees for ancillary products sold in connection with the credit transaction; any application fee charged (other than certain application fees for specified credit transactions or accounts); and any participation fee charged (other than certain participation fees for a credit card account).\n(b) The following sections of this Agreement and the Promissory Note shall not be applicable to, and shall not be enforceable against, a covered borrower as defined in the Military Lending Act: Section 22 of this Agreement and Section 18 of the Promissory Note.\n(c) Oral Disclosures\n. Please call 1-855-993-2967 to obtain oral disclosures, including the statement of MAPR and the payment schedule applicable to your loan, required under the Military Lending Act.\n________________________________________";

        public static String PROMISSORY_NOTE_SAMPLE =
                "EXHIBIT A\nPromissory Note\nLoan ID: ____________\nBorrower Address: ______________________________________________.";

        public static String PROMISE_TO_PAY_SAMPLE =
                "1. Promise to Pay. In return for a loan I have received, I promise to pay WebBank (Ã¢â‚¬Å“youÃ¢â‚¬ï¿½) the principal sum of ___________________ Dollars ($__________), together with interest thereon commencing on the date of origination at the rate of ____ percent (___%) per annum simple interest. I understand that references in this Promissory Note (Ã¢â‚¬Å“NoteÃ¢â‚¬ï¿½) to you shall also include any person to whom you transfer this Note.";

        public static String PAYMENTS_SAMPLE =
                "2. Payments. I will pay the principal, interest, and any late charges or other fees on this Note when due. This Note is payable in ___ monthly installments of $___________ each, consisting of principal and interest, commencing on the ________ day of _____________, and continuing until the final payment date of __________________, which is the maturity date of this Note. Because of the daily accrual of interest on my loan and the effect of rounding, my final payment may be more or less than my regular payment. My final payment shall consist of the then remaining principal, unpaid accrued interest and other charges due under this Note. All payments will be applied first to any unpaid fees incurred as a result of failed payments, as provided in Paragraph 11; then to any charges for making payments other than as provided in this Note; then to any late charges then due; then to any interest then due; and then to principal. No unpaid interest or charges will be added to principal. I further acknowledge that, if I make my payments after the scheduled due date, or incur a charge/fee, this Note will not amortize as originally scheduled, which may result in a substantially higher final payment amount.";

        public static String INTEREST_SAMPLE =
                "3. Interest. Interest will be charged on unpaid principal until the full amount of principal has been paid. Interest under this Note will accrue daily, on the basis of a 365-day year. The interest rate I will pay will be the rate I will pay both before and after any default.";

        public static String LATE_CHARGE_SAMPLE =
                "4. Late Charge. If the full amount of any monthly payment is not made by the end of fifteen (15) calendar days after its due date, I will pay you a late charge of the greater of $15 or 5.00% of the unpaid portion of the monthly payment. I will pay this late charge when it is assessed but only once on each late payment.";

        public static String CLAIMS_AND_DEFENSES =
                "5. Claims and Defenses; Waiver of Defenses; Exception to Waiver. Except as otherwise provided in this Note, you are not responsible or liable to me for the quality, safety, legality, or any other aspect of any property or services purchased with the proceeds of my loan. If I have a dispute with any person from whom I have purchased such property or services, I agree to settle the dispute directly with that person.\nIf and only if the proceeds of my loan will be applied in whole or part to purchase property or services from a person or entity that has entered into a contractual relationship with you or Prosper related to financing of such property or services, the following notice may apply:\nNOTICE\nANY HOLDER OF THIS CONSUMER CREDIT CONTRACT IS SUBJECT TO ALL CLAIMS AND DEFENSES WHICH THE DEBTOR COULD ASSERT AGAINST THE SELLER OF GOODS OR SERVICES OBTAINED WITH THE PROCEEDS HEREOF. RECOVERY HEREUNDER BY THE DEBTOR SHALL NOT EXCEED AMOUNTS PAID BY THE DEBTOR HEREUNDER.";

        public static String CERTIFICATION =
                "6. Certification. I certify that the proceeds of my loan will not be applied in whole or in part to postsecondary educational expenses (i.e., tuition, fees, required equipment or supplies, or room and board) at a college/university/vocational school, as the term Ã¢â‚¬Å“postsecondary educational expensesÃ¢â‚¬ï¿½ is defined in Bureau of Consumer Financial Protection Regulation Z, 12 C.F.R. Ã‚Â§ 1026.46(b)(3).";

        public static String METHOD_OF_PAYMENT =
                "7. Method of Payment. You have given me the choice of making my monthly payments (i) by automated withdrawal from an account that I designate using an automated clearinghouse (ACH) or other electronic fund transfer in the manner described in the debit authorization I execute, or (ii) by manually scheduled one-time withdrawals from an account that I designate using an ACH or other electronic fund transfer, made by logging onto my account on the Prosper website or by calling Prosper Borrower Services at 1-866-615-6319, with my first payment being scheduled during the application process; and I have chosen one of these methods.\nI also understand that I may pay my monthly payments by check. If I have chosen to pay by check by calling Prosper Borrower Services at 1-866-615-6319 and arranging such method of payment, I will make the check payable to Prosper Funding LLC and send the payment check to Prosper Marketplace, Inc., P.O. Box 396081, San Francisco, CA 94139-6081 in a manner so as to ensure that it is received with sufficient time to process prior to my scheduled payment due date.  To ensure efficient processing of my check, I will reference my loan number on the check.\nI recognize that if I have automated withdrawal enabled, it is my responsibility to ensure that all amounts I owe are paid when due, even if not debited from my account.\nIf I close my account or if my account changes or is otherwise inaccessible such that you are unable to withdraw my payments from that account or process my check, I will notify you at least three (3) business days prior to any such closure, change or inaccessibility of my account, and authorize you to withdraw my payments, or I will provide a check, from another account that I designate.\nWith regard to payments made by automatic withdrawals from my account, I have the right to (i) stop payment of a preauthorized automatic withdrawal, or (ii) revoke my prior authorization for automatic withdrawals with regard to all further payments under this Note, by notifying the financial institution where my account is held, orally or in writing at least three (3) business days before the scheduled date of the transfer. I agree to notify you orally or in writing, at least three (3) business days before the scheduled date of the transfer, of the exercise of my right to stop a payment or to revoke my prior authorization for further automatic withdrawals.";

        public static String DEFAULT_AND_REMEDIES =
                "8. Default and Remedies. If I fail to make any payment when due in the manner required by Paragraph 7, I will be delinquent.  If I (a) am delinquent, (b) file or have instituted against me a bankruptcy or insolvency proceeding or make any assignment for the benefit of creditors, or (c) in the event of my death, you may in your sole discretion deem me in default and accelerate the maturity of this Note and declare all principal, interest and other charges due under this Note immediately due and payable. If you deem me in default due to delinquency and if you exercise the remedy of acceleration, you will use reasonable efforts to provide prior notice of acceleration.";

        public static String PREPAYMENTS =
                "9. Prepayments. I may prepay this Note in full or in part at any time without penalty. I acknowledge that partial prepayments will not change the due date or amount of my monthly payment.";

        public static String WAIVERS =
                "10. Waivers. You may accept late payments or partial payments, even though marked Ã¢â‚¬Å“paid in full,Ã¢â‚¬ï¿½ without losing any rights under this Note, and you may delay enforcing any of your rights under this Note without losing them. You do not have to (a) demand payment of amounts due (known as Ã¢â‚¬Å“presentmentÃ¢â‚¬ï¿½), (b) give notice that amounts due have not been paid (known as Ã¢â‚¬Å“notice of dishonorÃ¢â‚¬ï¿½), or (c) obtain an official certification of nonpayment (known as Ã¢â‚¬Å“protestÃ¢â‚¬ï¿½). I hereby waive presentment, notice of dishonor and protest. Even if, at a time when I am in default, you do not require me to pay immediately in full as described above, you will still have the right to do so if I am in default at a later time. Neither your failure to exercise any of your rights, nor your delay in enforcing or exercising any of your rights, will waive those rights. Furthermore, if you waive any right under this Note on one occasion, that waiver will not operate as a waiver as to any other occasion.";

        public static String INSUFFICIENT_FUNDS_CHARGE =
                "11. Insufficient Funds Charge. If I attempt to make a payment, whether by automated withdrawal from my designated account or by other means, and the payment cannot be made due to (i) insufficient funds in my account, (ii) the closure, change or inaccessibility of my account without my having notified you as provided in Paragraph 7, or (iii) for any other reason (other than an error by you), I will pay you an additional fee of $15 for each returned or failed automated withdrawal or other item, unless prohibited by applicable law. I will pay this fee when it is assessed.";

        public static String ATTORNEYS =
                "12. AttorneysÃ¢â‚¬â„¢ Fees. To the extent permitted by law, I am liable to you for your legal costs if you refer collection of my loan to a lawyer who is not your salaried employee. These costs may include reasonable attorneysÃ¢â‚¬â„¢ fees as well as costs and expenses of any legal action.";

        public static String LOAN_CHARGES =
                "13. Loan Charges. If a law that applies to my loan and sets maximum loan charges is finally interpreted so that the interest or other loan charges collected or to be collected in connection with my loan exceed the permitted limits, then: (a) any such loan charge shall be reduced by the amount necessary to reduce the charge to the permitted limit; and (b) any sums already collected from me that exceeded permitted limits will be refunded to me. You may choose to make this refund by reducing the principal I owe under this Note or by making a direct payment to me.";

        public static String ASSIGNMENT =
                "14. Assignment. I may not assign any of my obligations under this Note without your written permission. You may assign this Note at any time without my permission. Unless prohibited by applicable law, you may do so without telling me. My obligations under this Note apply to all of my heirs and permitted assigns. Your rights under this Note apply to each of your successors and assigns.";

        public static String NOTICES_PN =
                "15. Notices. All notices and other communications hereunder shall be given in writing and shall be deemed to have been duly given and effective (i) upon receipt, if delivered in person or by facsimile, email or other electronic transmission, or (ii) one day after deposit prepaid for overnight delivery with a national overnight express delivery service. Except as expressly provided otherwise in this Note, notices to me may be addressed to my registered email address or to my address set forth above unless I provide you with a different address for notice by giving notice pursuant to this Paragraph, and notices to you must be addressed to WebBank at legal@prosper.com or c/o Prosper Marketplace, Inc., 221 Main Street, Third Floor, San Francisco, CA 94105, Attention: Legal Department.";

        public static String GOVERNING_LAW =
                "16. Governing Law. This Note is governed by federal law and, to the extent that state law applies, the laws of the State of Utah.";

        public static String MISCELLANEOUS_PN =
                "17. Miscellaneous. No provision of this Note shall be modified or limited except by a written agreement signed by both you and me. The unenforceability of any provision of this Note shall not affect the enforceability or validity of any other provision of this Note.";

        public static String ARBITRATION_PN =
                "18. Arbitration. RESOLUTION OF DISPUTES: I HAVE READ THIS PROVISION CAREFULLY, AND UNDERSTAND THAT IT LIMITS MY RIGHTS IN THE EVENT OF A DISPUTE BETWEEN YOU AND ME. I UNDERSTAND THAT I HAVE THE RIGHT TO REJECT THIS PROVISION, AS PROVIDED IN PARAGRAPH (i) BELOW.\n(a) In this Resolution of Disputes provision:\n(i) Ã¢â‚¬Å“I,Ã¢â‚¬ï¿½ Ã¢â‚¬Å“meÃ¢â‚¬ï¿½ and Ã¢â‚¬Å“myÃ¢â‚¬ï¿½ mean the promisor under this Note, as well as any person claiming through such promisor;\n(ii) Ã¢â‚¬Å“YouÃ¢â‚¬ï¿½ and Ã¢â‚¬Å“yourÃ¢â‚¬ï¿½ mean WebBank, any person servicing this Note for WebBank, any subsequent holders of this Note or any interest in this Note, any person servicing this Note for such subsequent holder of this note, and each of their respective parents, subsidiaries, affiliates, predecessors, successors, and assigns, as well as the officers, directors, and employees of each of them; and\n(iii) Ã¢â‚¬Å“ClaimÃ¢â‚¬ï¿½ means any dispute, claim, or controversy (whether based on contract, tort, intentional tort, constitution, statute, ordinance, common law, or equity, whether pre-existing, present, or future, and whether seeking monetary, injunctive, declaratory, or any other relief) arising from or relating to this Note or the relationship between you and me (including claims arising prior to or after the date of the Note, and claims that are currently the subject of purported class action litigation in which I am not a member of a certified class), and includes claims that are brought as counterclaims, cross claims, third party claims or otherwise, as well as disputes about the validity or enforceability of this Note or the validity or enforceability of this Section.\n(b) Any Claim shall be resolved, upon the election of either you or me, by binding arbitration administered by the American Arbitration Association or JAMS, under the applicable arbitration rules of the administrator in effect at the time a Claim is filed (Ã¢â‚¬Å“RulesÃ¢â‚¬ï¿½). Any arbitration under this arbitration agreement will take place on an individual basis; class arbitrations and class actions are not permitted. If I file a claim, I may choose the administrator; if you file a claim, you may choose the administrator, but you agree to change to the other permitted administrator at my request (assuming that the other administrator is available). I can obtain the Rules and other information about initiating arbitration by contacting the American Arbitration Association at 1633 Broadway, 10th Floor, New York, NY 10019, (800) 778-7879, www.adr.org; or by contacting JAMS at 1920 Main Street, Suite 300, Irvine, CA 92614, (949) 224-1810, www.jamsadr.com. Your address for serving any arbitration demand or claim is WebBank, c/o Prosper Marketplace, Inc., 221 Main Street, Third Floor, San Francisco, CA 94105, Attention: Legal Department.\n(c) Claims will be arbitrated by a single, neutral arbitrator, who shall be a retired judge or a lawyer with at least ten yearsÃ¢â‚¬â„¢ experience. You agree not to invoke your right to elect arbitration of an individual Claim filed by me in a small claims or similar court (if any), so long as the Claim is pending on an individual basis only in such court.\n(d) You will pay all filing and administration fees charged by the administrator and arbitrator fees up to $1,000, and you will consider my request to pay any additional arbitration costs. If an arbitrator issues an award in your favor, I will not be required to reimburse you for any fees you have previously paid to the administrator or for which you are responsible. If I receive an award from the arbitrator, you will reimburse me for any fees paid by me to the administrator or arbitrator. Each party shall bear its own attorneyÃ¢â‚¬â„¢s, expertÃ¢â‚¬â„¢s and witness fees, which shall not be considered costs of arbitration; however, if a statute gives me the right to recover these fees, or fees paid to the administrator or arbitrator, then these statutory rights will apply in arbitration.\n(e) Any in-person arbitration hearing will be held in the city with the federal district court closest to my residence, or in such other location as you and we may mutually agree. The arbitrator shall apply applicable substantive law consistent with the Federal Arbitration Act, 9 U.S.C. Ã‚Â§ 1-16, and, if requested by either party, provide written reasoned findings of fact and conclusions of law. The arbitrator shall have the power to award any relief authorized under applicable law. Any appropriate court may enter judgment upon the arbitratorÃ¢â‚¬â„¢s award. The arbitratorÃ¢â‚¬â„¢s decision will be final and binding except that: (1) any party may exercise any appeal right under the FAA; and (2) any party may appeal any award relating to a claim for more than $100,000 to a three-arbitrator panel appointed by the administrator, which will reconsider de novo any aspect of the appealed award. The panelÃ¢â‚¬â„¢s decision will be final and binding, except for any appeal right under the FAA. Unless applicable law provides otherwise, the appealing party will pay the appealÃ¢â‚¬â„¢s cost, regardless of its outcome. However, you will consider any reasonable written request by me for you to bear the cost.\n(f) YOU AND I AGREE THAT EACH MAY BRING CLAIMS AGAINST THE OTHER ONLY IN OUR INDIVIDUAL CAPACITY, AND NOT AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS OR REPRESENTATIVE PROCEEDING. Further, unless both you and I agree otherwise in writing, the arbitrator may not consolidate more than one personÃ¢â‚¬â„¢s claims. The arbitrator shall have no power to arbitrate any Claims on a class action basis or Claims brought in a purported representative capacity on behalf of the general public, other borrowers, or other persons similarly situated. The validity and effect of this paragraph (f) shall be determined exclusively by a court, and not by the administrator or any arbitrator.\n(g) If any portion of this Section 18 is deemed invalid or unenforceable for any reason, it shall not invalidate the remaining portions of this section. However, if paragraph (f) of this Section 18 is deemed invalid or unenforceable in whole or in part, then this entire Section 18 shall be deemed invalid and unenforceable. The terms of this Section 18 will prevail if there is any conflict between the Rules and this section.\n(h) YOU AND I AGREE THAT, BY ENTERING INTO THIS NOTE, THE PARTIES ARE EACH WAIVING THE RIGHT TO A TRIAL BY JURY OR TO PARTICIPATE IN A CLASS ACTION. YOU AND I ACKNOWLEDGE THAT ARBITRATION WILL LIMIT OUR LEGAL RIGHTS, INCLUDING THE RIGHT TO PARTICIPATE IN A CLASS ACTION, THE RIGHT TO A JURY TRIAL, THE RIGHT TO CONDUCT FULL DISCOVERY, AND THE RIGHT TO APPEAL (EXCEPT AS PERMITTED IN PARAGRAPH (e) OR UNDER THE FEDERAL ARBITRATION ACT).\n(i) I understand that I may reject the provisions of this Section 18, in which case neither you nor I will have the right to elect arbitration. Rejection of this Section 18 will not affect the remaining parts of this Note. To reject this Section 18, I must send you written notice of my rejection within 30 days after the date that this Note was made. I must include my name, address, and account number. The notice of rejection must be mailed to WebBank, c/o Prosper Marketplace, Inc., 221 Main Street, San Francisco, CA 94105, Attention: Legal Department. This is the only way that I can reject this Section 18.\n(j) You and I acknowledge and agree that the arbitration agreement set forth in this Section 18 is made pursuant to a transaction involving interstate commerce, and thus the Federal Arbitration Act shall govern the interpretation and enforcement of this Section 18. This Section 18 shall survive the termination of this Note and the repayment of any or all amounts borrowed thereunder.\n(k) This section shall not apply to covered borrowers as defined in the Military Lending Act.";

        public static String ELECTRONIC_TRANSACTIONS_PN =
                "19. Electronic Transactions.  THIS NOTE INCLUDES YOUR EXPRESS CONSENT TO ELECTRONIC TRANSACTIONS AND DISCLOSURES, WHICH CONSENT IS SET FORTH IN THE PARAGRAPH ENTITLED Ã¢â‚¬Å“CONSENT TO DOING BUSINESS ELECTRONICALLYÃ¢â‚¬ï¿½ AS DISCLOSED IN PROSPERÃ¢â‚¬â„¢S TERMS OF USE ON PROSPER.COM, THE TERMS AND CONDITIONS OF WHICH ARE EXPRESSLY INCORPORATED HEREIN IN THEIR ENTIRETY.  YOU EXPRESSLY AGREE THAT THIS NOTE MAY COMPRISE A Ã¢â‚¬Å“TRANSFERABLE RECORDÃ¢â‚¬ï¿½ FOR ALL PURPOSES UNDER THE ELECTRONIC SIGNATURES IN GLOBAL AND NATIONAL COMMERCE ACT AND THE UNIFORM ELECTRONIC TRANSACTIONS ACT.";

        public static String REGISTRATION_OF_NOTE_OWNERS =
                "20. Registration of Note Owners.  I have appointed Prosper Funding LLC as my authorized agent (in such capacity, the Ã¢â‚¬Å“Note RegistrarÃ¢â‚¬ï¿½) to maintain a book-entry system (the Ã¢â‚¬Å“RegisterÃ¢â‚¬ï¿½) for recording the beneficial owners of interests in this Note (the Ã¢â‚¬Å“Note OwnersÃ¢â‚¬ï¿½).  The person or persons identified as the Note Owners in the Register shall be deemed to be the owner(s) of this Note for purposes of receiving payment of principal and interest on such Note and for all other purposes. With respect to any transfer by a Note Owner of its beneficial interest in this Note, the right to payment of principal and interest on this Note shall not be effective until the transfer is recorded in the Register.";

        public static String STATE_NOTICES_PN =
                "21. State Notices\nCalifornia Residents\nMarried registrants may apply for a separate account.  As required by law, I am hereby notified that a negative credit report reflecting on my credit record may be submitted to a credit reporting agency if I fail to fulfill the terms of my credit obligations.\nIowa Residents\nNOTICE TO CONSUMER: 1. Do not sign this paper before you read it. 2. You are entitled to a copy of this paper. 3. You may prepay the unpaid balance at any time without penalty and may be entitled to receive a refund of unearned charges in accordance with law.\nIMPORTANT: READ BEFORE SIGNING. The terms of this agreement should be read carefully because only those terms in writing are enforceable. No other terms or oral promises not contained in this written contract may be legally enforced. I may change the terms of this agreement only by another written agreement.\nKansas Residents\nNOTICE TO CONSUMER: 1. Do not sign this agreement before you read it. 2. You are entitled to a copy of this agreement. 3. You may prepay the unpaid balance at any time without penalty.\nMissouri Residents\nOral or unexecuted agreements or commitments to loan money, extend credit or to forbear from enforcing repayment of a debt including promises to extend or renew such debt are not enforceable. To protect me (borrower(s)) and you (creditor) from misunderstanding or disappointment, any agreements we reach covering such matters are contained in this writing, which is the complete and exclusive statement of the agreement between us, except as we may later agree in writing to modify it.\nNebraska Residents\nA credit agreement must be in writing to be enforceable under Nebraska law. To protect you and me from any misunderstandings or disappointments, any contract, promise, undertaking, or offer to forebear repayment of money or to make any other financial accommodation in connection with this loan of money or grant or extension of credit, or any amendment of, cancellation of, waiver of, or substitution for any or all of the terms or provisions of any instrument or document executed in connection with this loan of money or grant or extension of credit, must be in writing to be effective.\nNew Jersey Residents\nBecause certain provisions of this Note are subject to applicable laws, they may be void, unenforceable or inapplicable in some jurisdictions.  None of these provisions, however, is void, unenforceable or inapplicable in New Jersey.\nOhio Residents\nThe Ohio laws against discrimination require that all creditors make credit equally available to all credit worthy customers, and that credit reporting agencies maintain separate credit histories on each individual upon request. The Ohio civil rights commission administers compliance with this law.\nUtah Residents\nAs required by Utah law, I am hereby notified that a negative credit report reflecting on my credit record may be submitted to a credit reporting agency if I fail to fulfill the terms of my credit obligations.\nThis Note is the final expression of the agreement between the parties and may not be contradicted by evidence of any alleged oral agreement.\nWisconsin Residents\nNo provision of a marital property agreement, a unilateral statement or a court decree adversely affects the interest of the creditor unless the creditor, prior to the time the credit is granted, is furnished a copy of the agreement, statement or decree or has actual knowledge of the adverse provision when the obligation to the creditor is incurred.";

        public static String MILITARY_LENDING_PN =
                "22. Military Lending Act. The Military Lending Act provides specific protections for active duty service members and their dependents in consumer credit transactions. This Section includes information on the protections provided to covered borrowers as defined in the Military Lending Act.\n(a) Statement of MAPR.\nFederal law provides important protections to members of the Armed Forces and their dependents relating to extensions of consumer credit. In general, the cost of consumer credit to a member of the Armed Forces and his or her dependent may not exceed an annual percentage rate of 36 percent. This rate must include, as applicable to the credit transaction or account: The costs associated with credit insurance premiums; fees for ancillary products sold in connection with the credit transaction; any application fee charged (other than certain application fees for specified credit transactions or accounts); and any participation fee charged (other than certain participation fees for a credit card account).\n(b) Section 18 of this Note shall not be applicable to, and shall not be enforceable against, a covered borrower as defined in the Military Lending Act.\n(c) Oral Disclosures\n. Please call 1-855-993-2967 to obtain oral disclosures, including the statement of MAPR and the payment schedule applicable to your loan, required under the Military Lending Act.";

        public static String SIGNING_THIS_NOTE =
                "23. By signing this Note, I acknowledge that I (i) have read and understand all terms and conditions of this Note, (ii) agree to the terms set forth herein, and (iii) acknowledge receipt of a completely filled-in copy of this Note.\nWisconsin Residents: NOTICE TO CUSTOMER: (a) DO NOT SIGN THIS IF IT CONTAINS ANY BLANK SPACES. (b) YOU ARE ENTITLED TO AN EXACT COPY OF ANY AGREEMENT YOU SIGN. (c) YOU HAVE THE RIGHT AT ANY TIME TO PAY IN ADVANCE THE UNPAID BALANCE DUE UNDER THIS AGREEMENT AND YOU MAY BE ENTITLED TO A PARTIAL REFUND OF THE FINANCE CHARGE.\nCAUTION Ã¢â‚¬â€˜Ã¢â‚¬â€˜ IT IS IMPORTANT THAT YOU THOROUGHLY READ THE CONTRACT BEFORE YOU SIGN IT.\nDate: _______________\nBy: Prosper\nMarketplace, Inc.\nAttorney-in-Fact for:\n_________________________________ [Borrower]\n(Signed Electronically)";

        public static String LAST_UPADTE_DATE = "Last Updated: September 2016";

        public static String LATE_CHARGE =
                "If the full amount of any monthly payment is not made by the end of fifteen (15) calendar days after its due date, I will pay you a late charge of the greater of $15 or 5.00% of the unpaid portion of the monthly payment. I will pay this late charge when it is assessed but only once on each late payment.";
        public static String INTEREST =
                "Interest will be charged on unpaid principal until the full amount of principal has been paid. Interest under this Note will accrue daily, on the basis of a 365-day year. The interest rate I will pay will be the rate I will pay both before and after any default.";
        public static String PAYMENTS =
                "I will pay the principal, interest, and any late charges or other fees on this Note when due. This Note is payable in ___ monthly installments of $___________ each, consisting of principal and interest, commencing on the ________ day of _____________, and continuing until the final payment date of __________________, which is the maturity date of this Note. Because of the daily accrual of interest on my loan and the effect of rounding, my final payment may be more or less than my regular payment.  My final payment shall consist of the then remaining principal, unpaid accrued interest and other charges due under this Note. All payments will be applied first to any unpaid fees incurred as a result of failed payments, as provided in Paragraph 11; then to any charges for making payments other than as provided in this Note; then to any late charges then due; then to any interest then due; and then to principal. No unpaid interest or charges will be added to principal. I further acknowledge that, if I make my payments after the scheduled due date, or incur a charge/fee, this Note will not amortize as originally scheduled, which may result in a substantially higher final payment amount.";
        public static String PROMISE_TO_PAY =
                "In return for a loan I have received, I promise to pay WebBank (â€œyouâ€�) the principal sum of ___________________ Dollars ($__________), together with interest thereon commencing on the date of origination at the rate of ____ percent (___%) per annum simple interest. I understand that references in this Promissory Note (â€œNoteâ€�) to you shall also include any person to whom you transfer this Note.";
    }

    public static class DebitAuthorization {

        public static String DEBIT_AUTHORIZATION_TITLE = "Authorization to Debit Account";

        public static String I_HEREBY =
                "I hereby authorize Prosper Funding LLC (Ã¢â‚¬Å“ProsperÃ¢â‚¬ï¿½), its parent, affiliates, any holder of my loan and their respective agents and their assignees to initiate, depending on the payment method I select on the following page, a single or recurring electronic debit entry/entries to my designated checking or savings account (Ã¢â‚¬Å“AccountÃ¢â‚¬ï¿½) at my designated financial institution (Ã¢â‚¬Å“Financial InstitutionÃ¢â‚¬ï¿½) for which I am an authorized user, as well as any Account or Financial Institution I later designate, for payment of the monthly payment(s) on my loan, if my loan originates. I acknowledge that the origination of electronic debits to my Account must be permitted by my Financial Institution, which must be located in the United States.";

        public static String IF_I_SELECT_PREAUTHORIZED =
                "If I select preauthorized electronic fund transfers as my payment method I agree:\nTHE AMOUNT DEBITED FROM THE ACCOUNT EACH MONTH WILL BE THE LESSER OF MY OUTSTANDING LOAN BALANCE AND THE PAYMENT LISTED ON THE FINAL TRUTH IN LENDING STATEMENT (Ã¢â‚¬Å“FINAL TILÃ¢â‚¬ï¿½). THE PAYMENT WILL BE DEBITED EACH MONTH ON THE DUE DATE LISTED ON THE FINAL TIL; HOWEVER, IF THE DUE DATE OCCURS ON A WEEKEND OR HOLIDAY, THE ACCOUNT WILL BE DEBITED THE NEXT BUSINESS DAY. I UNDERSTAND THAT MY FINAL PAYMENT WILL VARY FROM THE AMOUNT STATED ON THE FINAL TIL IF PROSPER ELECTS TO DEBIT ANY ADDITIONAL UNPAID PRINCIPAL, INTEREST, CHARGES AND/OR FEES. I UNDERSTAND THAT I MUST PAY ALL OUTSTANDING AMOUNTS EVEN IF NOT DEBITED BY PROSPER.";

        public static String IF_I_SELECT_A_ONE_TIME =
                "If I select a one-time electronic fund transfer followed by manual payments as my payment method I agree:\nTHE AMOUNT DEBITED FROM MY ACCOUNT ON THE DUE DATE OF MY FIRST PAYMENT WILL BE MY MONTHLY PAYMENT AMOUNT, AS LISTED ON THE FINAL TIL. HOWEVER, IF THE DUE DATE OCCURS ON A WEEKEND OR HOLIDAY, THE ACCOUNT WILL BE DEBITED THE NEXT BUSINESS DAY.";

        public static String I_UNDERSTAND =
                "I understand that my authorization will remain in full force and effect until Prosper has received oral or written notification from me at least 3 business days prior to my scheduled transfer to terminate this authorization.";
    }

    public static class LegalAgreementsPage {

        public static String BORROWER_REGISTRATION_AGREEMENT = "Borrower Registration Agreement";
        public static String AUTHORIZATION_TO_DEBIT_ACCOUNT = "Authorization to Debit Account";
        public static String LISTING_TRUTH_IN_LENDING_DISCLOSURE = "Listing Truth In Lending Disclosure";
        public static String LOAN_TRUTH_IN_LENDING_DISCLOSURE = "Loan Truth in Lending Disclosure";
        public static String LEGAL_AGREEMENTS_AND_DISCLOSURES =  "Legal Agreements & Disclosures - Prosper";

        // Final and Initail Tila Page.
        public static String ANNUAL_PERCENTAGE_RATE = "ANNUAL PERCENTAGE RATE";
        public static String FINANCE_CHARGE = "FINANCE CHARGE";
        public static String AMOUNT_FINANCED = "Amount Financed";
        public static String TOTAL_PAYMENTS_AMOUNT = "Total of Payments";
        public static String NUMBER_OF_PAYMENT = "Number of Payment";
        public static String MONTHLY_PAYMENT_AMOUNT = "Monthly Payment";
        public static String LAST_PAYMENT_AMOUNT = "Last Payment";
        public static String ACTUAL_FUNDING = "Actual Funding";
        public static String PREPAID_FINANCE_CHARGE = "Prepaid Finance Charge";

    }

}