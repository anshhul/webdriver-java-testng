package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 7/13/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ProspectMatchIndividualResult {
    @JsonProperty("discountCode")
    private String discountCode;
    @JsonProperty("offerCode")
    private String offerCode;
    @JsonProperty("offerCodeEntered")
    private String offerCodeEntered;
    @JsonProperty("matchedByEmail")
    private boolean matchedByEmail;
    @JsonProperty("matchedBySsnName")
    private boolean matchedBySsnName;
    @JsonProperty("matchedBySsnAddress")
    private boolean matchedBySsnAddress;
    @JsonProperty("filterByStartAndEnd")
    private String filterByStartAndEnd;
    @JsonProperty("filterByDuration")
    private String filterByDuration;
    @JsonProperty("filterByUserID")
    private String filterByUserID;

    public String getFilterByStartAndEnd() {
        return filterByStartAndEnd;
    }

    public void setFilterByStartAndEnd(String filterByStartAndEnd) {
        this.filterByStartAndEnd = filterByStartAndEnd;
    }

    public String getOfferCodeEntered() {
        return offerCodeEntered;
    }

    public void setOfferCodeEntered(String offerCodeEntered) {
        this.offerCodeEntered = offerCodeEntered;
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public String getOfferCode() {
        return offerCode;
    }

    public void setOfferCode(String offerCode) {
        this.offerCode = offerCode;
    }

    public boolean isMatchedByEmail() {
        return matchedByEmail;
    }

    public void setMatchedByEmail(boolean matchedByEmail) {
        this.matchedByEmail = matchedByEmail;
    }

    public boolean isMatchedBySsnName() {
        return matchedBySsnName;
    }

    public void setMatchedBySsnName(boolean matchedBySsnName) {
        this.matchedBySsnName = matchedBySsnName;
    }

    public boolean isMatchedBySsnAddress() {
        return matchedBySsnAddress;
    }

    public void setMatchedBySsnAddress(boolean matchedBySsnAddress) {
        this.matchedBySsnAddress = matchedBySsnAddress;
    }

    public String getFilterByDuration() {
        return filterByDuration;
    }

    public void setFilterByDuration(String filterByDuration) {
        this.filterByDuration = filterByDuration;
    }

    public String getFilterByUserID() {
        return filterByUserID;
    }

    public void setFilterByUserID(String filterByUserID) {
        this.filterByUserID = filterByUserID;
    }
}
