
package com.prosper.automation.model.platform.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A class to represent particular address location.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Location {
    
    @JsonProperty("address")
    private String address;
    @JsonProperty("partialMatch")
    private Boolean partialMatch;
    @JsonProperty("coordinates")
    private Coordinates coordinates;
    
    
    @JsonIgnore
    public Coordinates getCoordinates() {
        return coordinates;
    }
}
