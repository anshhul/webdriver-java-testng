package com.prosper.automation.configuration;

/**
 * @author vinsharma
 * @since 0.0.1
 */
public final class NachaConfiguration {

    public static final int PORT = 22;

    private String hostName;
    private String user;
    private String sftpWebKey;


    public NachaConfiguration(final String hostName, final String user, final String sftpWebKey) {
        this.hostName = hostName;
        this.user = user;
        this.sftpWebKey = sftpWebKey;
    }

    private NachaConfiguration(final Builder builder) {
        this.hostName = builder.hostName;
        this.user = builder.user;
        this.sftpWebKey = builder.sftpWebKey;
    }

    public String getHostName() {
        return hostName;
    }

    public String getUser() {
        return user;
    }

    public String getSFTPWebKey() {
        return sftpWebKey;
    }


    public static final class Builder {

        private String hostName;
        private String user;
        private String sftpWebKey;


        public Builder() {
        }

        public Builder withHostName(final String hostName) {
            this.hostName = hostName;
            return this;
        }

        public Builder withUser(final String user) {
            this.user = user;
            return this;
        }

        public Builder withSFTPWebKey(final String sftpWebKey) {
            this.sftpWebKey = sftpWebKey;
            return this;
        }

        public NachaConfiguration build() {
            return new NachaConfiguration(this);
        }
    }
}