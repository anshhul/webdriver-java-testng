package com.prosper.automation.constant;

import com.google.common.collect.ImmutableList;
import com.prosper.automation.model.platform.PhoneNumber;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PhoneNumberConstant {

    // TODO: update phone type id to use PhoneType enumeration.

    public static final String SAN_FRANCISCO_AREA_CODE = "415";
    public static final String DUMMY_PHONE_NUMBER_0 = "123-4560";
    public static final String DUMMY_PHONE_NUMBER_1 = "123-4561";
    public static final String DUMMY_PHONE_NUMBER_2 = "123-4562";
    public static final String DUMMY_PHONE_NUMBER_3 = "123-4563";
    public static final String DUMMY_PHONE_NUMBER_4 = "123-4564";

    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0 = new PhoneNumber.Builder().withPhoneNumber("2065406016")
            .withPhoneTypeId(0).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_1 = new PhoneNumber.Builder().withPhoneNumber("2065406026")
            .withPhoneTypeId(1).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_2 = new PhoneNumber.Builder().withPhoneNumber("2065406036")
            .withPhoneTypeId(2).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_3 = new PhoneNumber.Builder().withPhoneNumber("2065406046")
            .withPhoneTypeId(3).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_4 = new PhoneNumber.Builder().withPhoneNumber("2065406056")
            .withPhoneTypeId(4).withPreferredContact(false).withVisible(true).build();

    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0_WITH_COUNTRY_CODE_EXT = new PhoneNumber.Builder()
            .withPhoneNumber("5406591").withAreaCode("206")
            .withPhoneTypeId(0).withPreferredContact(false).withVisible(true).withCountryCode("+1").withExtension("").build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_1_WITH_COUNTRY_CODE_EXT = new PhoneNumber.Builder()
            .withPhoneNumber("5406591").withAreaCode("206")
            .withPhoneTypeId(1).withPreferredContact(false).withVisible(false).withCountryCode("+1").withExtension("").build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_2_WITH_COUNTRY_CODE_EXT = new PhoneNumber.Builder()
            .withPhoneNumber("5406591").withAreaCode("206")
            .withPhoneTypeId(2).withPreferredContact(false).withVisible(true).withCountryCode("+1").withExtension("").build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_3_WITH_COUNTRY_CODE_EXT = new PhoneNumber.Builder()
            .withPhoneNumber("5406591").withAreaCode("206")
            .withPhoneTypeId(3).withPreferredContact(true).withVisible(true).withCountryCode("+1").withExtension("").build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_4_WITH_COUNTRY_CODE_EXT = new PhoneNumber.Builder()
            .withPhoneNumber("5406591").withAreaCode("206")
            .withPhoneTypeId(4).withPreferredContact(false).withVisible(true).withCountryCode("+1").withExtension("").build();

    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0_DASH_SEPARATED = new PhoneNumber.Builder()
            .withPhoneNumber("206-540-6016").withPhoneTypeId(0).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE = new PhoneNumber.Builder()
            .withPhoneNumber("(206)5406016").withPhoneTypeId(0).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE_AND_DASH_SEPARATED =
            new PhoneNumber.Builder().withPhoneNumber("(206)540-6016").withPhoneTypeId(0).withPreferredContact(false)
                    .withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE_DASH_SEPARATED_AND_SPACE =
            new PhoneNumber.Builder().withPhoneNumber("(206) 540 6016").withPhoneTypeId(0).withPreferredContact(false)
                    .withVisible(true).build();

    // Keep this with 7 digit phone number since area code is not null
    public static final PhoneNumber VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE = new PhoneNumber.Builder().withAreaCode("866")
            .withPhoneNumber("6156319").withPhoneTypeId(1).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE = new PhoneNumber.Builder().withAreaCode("206")
            .withPhoneNumber("5406076").withPhoneTypeId(3).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE = new PhoneNumber.Builder().withAreaCode("206")
            .withPhoneNumber("3114137")
            .withPhoneTypeId(4).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber VALID_WA_EMP_PHONE_NUMBER_2_WITH_AREA_CODE = new PhoneNumber.Builder().withAreaCode("206")
            .withPhoneNumber("3114137")
            .withPhoneTypeId(2).withPreferredContact(false).withVisible(true).build();

    public static final List<PhoneNumber> PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS_AREA_CODE =
            new ImmutableList.Builder<PhoneNumber>()
                    .add(VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE).add(VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE)
                    .add(VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE).build();

    public static final PhoneNumber VALID_PROSPER_PHONE_NUMBER = new PhoneNumber.Builder().withAreaCode(null)
            .withPhoneNumber("4156156319").withPhoneTypeId(1).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber VALID_WA_PHONE_NUMBER_1 = new PhoneNumber.Builder().withAreaCode(null)
            .withPhoneNumber("2065406076").withPhoneTypeId(0).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber VALID_WA_PHONE_NUMBER_2 = new PhoneNumber.Builder().withPhoneNumber("2063114137")
            .withPhoneTypeId(1).withPreferredContact(false).withVisible(true).build();
    public static final PhoneNumber PHONE_NUMBER_WITHOUT_TYPE_ID = new PhoneNumber.Builder().withAreaCode(null)
            .withPhoneNumber("8666156319").withPreferredContact(false).withVisible(true).build();

    public static final List<PhoneNumber> PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS = new ImmutableList.Builder<PhoneNumber>()
            .add(PHONE_NUMBER_WITH_TYPE_ID_1).add(PHONE_NUMBER_WITH_TYPE_ID_2).add(PHONE_NUMBER_WITH_TYPE_ID_3).build();
    public static final List<PhoneNumber> PROSPER_PHONE_NUMBERS =
            new ImmutableList.Builder<PhoneNumber>().add(VALID_PROSPER_PHONE_NUMBER).build();
    public static final List<PhoneNumber> WA_PHONE_NUMBERS =
            new ImmutableList.Builder<PhoneNumber>().add(VALID_WA_PHONE_NUMBER_1).add(VALID_WA_PHONE_NUMBER_2).build();
    public static final List<PhoneNumber> PHONE_NUMBER_WITHOUT_TYPE_IDS =
            new ImmutableList.Builder<PhoneNumber>().add(PHONE_NUMBER_WITHOUT_TYPE_ID).build();
    public static final List<PhoneNumber> PHONE_NUMBERS_WITH_ALL_TYPES =
            new ImmutableList.Builder<PhoneNumber>().add(PHONE_NUMBER_WITH_TYPE_ID_0).add(PHONE_NUMBER_WITH_TYPE_ID_1)
                    .add(PHONE_NUMBER_WITH_TYPE_ID_2).add(PHONE_NUMBER_WITH_TYPE_ID_3).add(PHONE_NUMBER_WITH_TYPE_ID_4).build();
    public static final List<PhoneNumber> PHONE_NUMBERS_WITH_ALL_TYPES_WITH_CODE_EXT =
            new ImmutableList.Builder<PhoneNumber>().add(PHONE_NUMBER_WITH_TYPE_ID_0_WITH_COUNTRY_CODE_EXT)
                    .add(PHONE_NUMBER_WITH_TYPE_ID_1_WITH_COUNTRY_CODE_EXT)
                    .add(PHONE_NUMBER_WITH_TYPE_ID_2_WITH_COUNTRY_CODE_EXT)
                    .add(PHONE_NUMBER_WITH_TYPE_ID_3_WITH_COUNTRY_CODE_EXT)
                    .add(PHONE_NUMBER_WITH_TYPE_ID_4_WITH_COUNTRY_CODE_EXT).build();
    public static final PhoneNumber FAKE_PHONE_NUMBER = new PhoneNumber.Builder().withCountryCode("1")
            .withPhoneNumber("0009348247").withPhoneTypeId(1).withPreferredContact(true).withVisible(true).build();
    public static final String PROSPER_AREA_CODE = "866";
    public static final String PROSPER_PHONE_NUMBER = "6156319";
    private static final PhoneNumber INVALID_PHONE_NUMBER_1 = new PhoneNumber.Builder().withCountryCode("1")
            .withPhoneNumber("0000000000").withPhoneTypeId(1).withPreferredContact(true).withVisible(true).build();
    public static final List<PhoneNumber> INVALID_PHONE_NUMBERS =
            new ImmutableList.Builder<PhoneNumber>().add(INVALID_PHONE_NUMBER_1).build();
    public static final String INVALID_AREA_CODE = "000";


    private PhoneNumberConstant() {
    }

    public static List<PhoneNumber> buildPhoneNumbers(final List<String> phoneNumbers) {
        final ImmutableList.Builder<PhoneNumber> builder = new ImmutableList.Builder();
        for (int i = 0; i < phoneNumbers.size(); i++) {
            builder.add(new PhoneNumber.Builder().withAreaCode(null).withPhoneNumber(phoneNumbers.get(i)).withPhoneTypeId(i)
                    .withPreferredContact(false).withVisible(true).build());
        }
        return builder.build();
    }
}
