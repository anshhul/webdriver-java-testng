
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.pricing.ExperianUserCredit;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ExperianUserCreditConstant {
    
    private static final double DEFAULT_REV_CREDIT_BALANCE = 109015;
    private static final double DEFAULT_AGGR_BALANCE = 870197;
    private static final double DEFAULT_MONTHLY_DEBT = 1645;
    private static final double DEFAULT_ILN_201_AGGR_BALANCE = 13777;
    private static final int DEFAULT_SCORE_X = 742;
    
    public static final ExperianUserCredit CALCULATE_PMI_ATTR_TEST =
            new ExperianUserCredit.Builder().withRevolvingCreditBalance(DEFAULT_REV_CREDIT_BALANCE)
                    .withAggregateBalanceOnTrades6Months(DEFAULT_AGGR_BALANCE).withMonthlyDebt(DEFAULT_MONTHLY_DEBT)
                    .withIln201AggBalOpenInstallTrds(DEFAULT_ILN_201_AGGR_BALANCE).withScoreX(DEFAULT_SCORE_X).build();
                    
                    
    private ExperianUserCreditConstant() {
    }
}
