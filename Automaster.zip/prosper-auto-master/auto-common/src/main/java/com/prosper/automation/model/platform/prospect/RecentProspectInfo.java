package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 4/22/16.
 */
public class RecentProspectInfo {
    @JsonProperty("campaignName")
    private String campaignName;
    @JsonProperty("campaignChannelName")
    private String campaignChannelName;

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public String getCampaignChannelName() {
        return campaignChannelName;
    }

    public void setCampaignChannelName(String campaignChannelName) {
        this.campaignChannelName = campaignChannelName;
    }

    @Override
    public String toString() {
        return "RecentProspectInfo{" + "campaignName='" + campaignName + '\'' + ", campaignChannelName='" + campaignChannelName
                + '\'' + '}';
    }
}
