
package com.prosper.automation.constant;

/**
 * Created by pbudiono on 5/18/16.
 */
public final class DirectoryConstant {

    public static final String USER_DIR = System.getProperty("user.dir");
}
