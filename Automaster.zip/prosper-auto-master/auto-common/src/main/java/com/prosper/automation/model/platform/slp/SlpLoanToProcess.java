
package com.prosper.automation.model.platform.slp;

public final class SlpLoanToProcess {
    
    private Long loanId;
    private Double principalBalance;
    private Double originalAmount;
    private Double currIntRate;
    private String nextpaymentduedate;
    private Long borrowerid;
    private Double ownershipshare;
    private Double purchaseprice;
    private String balanceDate;
    private Double interestBalance;
    private Long lenderid;
    
    
    public static class SlpLoanToProcessBuilder {
        
        private String balanceDate;
        private Long borrowerid;
        private Double currIntRate;
        private Double interestBalance;
        private Long lenderid;
        private Long loanId;
        private String nextpaymentduedate;
        private Double originalAmount;
        private Double ownershipshare;
        private Double principalBalance;
        private Double purchaseprice;
        
        
        public SlpLoanToProcessBuilder balanceDate(final String value) {
            this.balanceDate = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder borrowerid(final Long value) {
            this.borrowerid = value;
            return this;
        }
        
        public SlpLoanToProcess build() {
            final SlpLoanToProcess result = new SlpLoanToProcess();
            
            result.setBalanceDate(balanceDate);
            result.setBorrowerid(borrowerid);
            result.setCurrIntRate(currIntRate);
            result.setInterestBalance(interestBalance);
            result.setLenderid(lenderid);
            result.setLoanId(loanId);
            result.setNextpaymentduedate(nextpaymentduedate);
            result.setOriginalAmount(originalAmount);
            result.setOwnershipshare(ownershipshare);
            result.setPrincipalBalance(principalBalance);
            result.setPurchaseprice(purchaseprice);
            return result;
        }
        
        public SlpLoanToProcessBuilder currIntRate(final Double value) {
            this.currIntRate = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder interestBalance(final Double value) {
            this.interestBalance = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder lenderid(final Long value) {
            this.lenderid = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder loanId(final Long value) {
            this.loanId = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder nextpaymentduedate(final String value) {
            this.nextpaymentduedate = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder originalAmount(final Double value) {
            this.originalAmount = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder ownershipshare(final Double value) {
            this.ownershipshare = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder principalBalance(final Double value) {
            this.principalBalance = value;
            return this;
        }
        
        public SlpLoanToProcessBuilder purchaseprice(final Double value) {
            this.purchaseprice = value;
            return this;
        }
    }


    public static SlpLoanToProcessBuilder buildUpon(final SlpLoanToProcess original) {
        final SlpLoanToProcessBuilder builder = newBuilder();
        builder.balanceDate(original.getBalanceDate());
        builder.borrowerid(original.getBorrowerid());
        builder.currIntRate(original.getCurrIntRate());
        builder.interestBalance(original.getInterestBalance());
        builder.lenderid(original.getLenderid());
        builder.loanId(original.getLoanId());
        builder.nextpaymentduedate(original.getNextpaymentduedate());
        builder.originalAmount(original.getOriginalAmount());
        builder.ownershipshare(original.getOwnershipshare());
        builder.principalBalance(original.getPrincipalBalance());
        builder.purchaseprice(original.getPurchaseprice());
        return builder;
    }

    public static SlpLoanToProcessBuilder newBuilder() {
        return new SlpLoanToProcessBuilder();
    }

    public String getBalanceDate() {
        return balanceDate;
    }

    public Long getBorrowerid() {
        return borrowerid;
    }

    public Double getCurrIntRate() {
        return currIntRate;
    }

    public Double getInterestBalance() {
        return interestBalance;
    }

    public Long getLenderid() {
        return lenderid;
    }

    public Long getLoanId() {
        return loanId;
    }

    public String getNextpaymentduedate() {
        return nextpaymentduedate;
    }

    public Double getOriginalAmount() {
        return originalAmount;
    }

    public Double getOwnershipshare() {
        return ownershipshare;
    }

    public Double getPrincipalBalance() {
        return principalBalance;
    }

    public Double getPurchaseprice() {
        return purchaseprice;
    }

    public void setBalanceDate(final String balanceDate) {
        this.balanceDate = balanceDate;
    }

    public void setBorrowerid(final Long borrowerid) {
        this.borrowerid = borrowerid;
    }

    public void setCurrIntRate(final Double currIntRate) {
        this.currIntRate = currIntRate;
    }

    public void setInterestBalance(final Double interestBalance) {
        this.interestBalance = interestBalance;
    }

    public void setLenderid(final Long lenderid) {
        this.lenderid = lenderid;
    }

    public void setLoanId(final Long loanId) {
        this.loanId = loanId;
    }

    public void setNextpaymentduedate(final String nextpaymentduedate) {
        this.nextpaymentduedate = nextpaymentduedate;
    }

    public void setOriginalAmount(final Double originalAmount) {
        this.originalAmount = originalAmount;
    }

    public void setOwnershipshare(final Double ownershipshare) {
        this.ownershipshare = ownershipshare;
    }

    public void setPrincipalBalance(final Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    public void setPurchaseprice(final Double purchaseprice) {
        this.purchaseprice = purchaseprice;
    }
    
}
