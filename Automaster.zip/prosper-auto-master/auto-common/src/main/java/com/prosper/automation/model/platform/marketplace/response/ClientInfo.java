package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by rsubramanyam on 3/15/16.
 */
public class ClientInfo
{
    @JsonProperty("oauth_id")
    int oauth_id;
    @JsonProperty("oauth_client_id")
    String oauth_client_id;
    @JsonProperty("version")
    int version;
    @JsonProperty("oauth_client_secret")
    String oauth_client_secret;
    @JsonProperty("oauth_resource_ids")
    String oauth_resource_ids;
    @JsonProperty("authority_scope")
    String authority_scope;
    @JsonProperty("authority_role")
    String authority_role;
    @JsonProperty("authorized_grant_types")

    String authorized_grant_types;
    @JsonProperty("access_token_lifetime")
    int access_token_lifetime;
    @JsonProperty("refresh_token_lifetime")
    int refresh_token_lifetime;
    @JsonProperty("permission_join_flag")

    boolean permission_join_flag;
    @JsonProperty("is_active")
    boolean is_active;
    @JsonProperty("is_internal_client")
    boolean is_internal_client;
    @JsonProperty("throttle_timeframe_max_calls")
    int throttle_timeframe_max_calls;
    @JsonProperty("throttle_timeframe_seconds")
    int throttle_timeframe_seconds;
    @JsonProperty("company_name")
    String company_name;
    @JsonProperty("external_client_id")
    String external_client_id;

    @JsonProperty("has_grant_flow_permission")
    boolean has_grant_flow_permission;

    @JsonIgnore
    public String getExternal_client_id() {
        return external_client_id;
    }

    public void setExternal_client_id(String external_client_id) {
        this.external_client_id = external_client_id;
    }

    @JsonIgnore
    public int getOauth_id() {
        return this.oauth_id;
    }
    public void setOauth_id(int oauth_id) {
        this.oauth_id = oauth_id;
    }

    @JsonIgnore
    public String getOauth_client_id() {
        return this.oauth_client_id;
    }
    public void setOauth_client_id(String oauth_client_id) {
        this.oauth_client_id = oauth_client_id;
    }

    @JsonIgnore
    public int getVersion() {
        return this.version;
    }
    public void setVersion(int version) {
        this.version = version;
    }
    @JsonIgnore
    public String getOauth_client_secret() {
        return this.oauth_client_secret;
    }

    public void setOauth_client_secret(String oauth_client_secret) {
        this.oauth_client_secret = oauth_client_secret;
    }

    @JsonIgnore
    public String getOauth_resource_ids() {
        return this.oauth_resource_ids;
    }
    public void setOauth_resource_ids(String oauth_resource_ids) {
        this.oauth_resource_ids = oauth_resource_ids;
    }

    @JsonIgnore
    public String getAuthority_scope() {
        return this.authority_scope;
    }
    public void setAuthority_scope(String authority_scope) {
        this.authority_scope = authority_scope;
    }

    @JsonIgnore
    public String getAuthority_role() {
        return this.authority_role;
    }
    public void setAuthority_role(String authority_role) {
        this.authority_role = authority_role;
    }

    @JsonIgnore
    public String getAuthorized_grant_types() {
        return this.authorized_grant_types;
    }
    public void setAuthorized_grant_types(String authorized_grant_types) {
        this.authorized_grant_types = authorized_grant_types;
    }

    @JsonIgnore
    public int getAccess_token_lifetime() {
        return this.access_token_lifetime;
    }
    public void setAccess_token_lifetime(int access_token_lifetime) {
        this.access_token_lifetime = access_token_lifetime;
    }

    @JsonIgnore
    public int getRefresh_token_lifetime() {
        return this.refresh_token_lifetime;
    }
    public void setRefresh_token_lifetime(int refresh_token_lifetime) {
        this.refresh_token_lifetime = refresh_token_lifetime;
    }

    @JsonIgnore
    public boolean getPermission_join_flag() {
        return this.permission_join_flag;
    }
    public void setPermission_join_flag(boolean permission_join_flag) {
        this.permission_join_flag = permission_join_flag;
    }

    @JsonIgnore
    public boolean getIs_active() {
        return this.is_active;
    }
    public void setIs_active(boolean is_active) {
        this.is_active = is_active;
    }

    @JsonIgnore
    public boolean getIs_internal_client() {
        return this.is_internal_client;
    }
    public void setIs_internal_client(boolean is_internal_client) {
        this.is_internal_client = is_internal_client;
    }

    @JsonIgnore
    public int getThrottle_timeframe_max_calls() {
        return this.throttle_timeframe_max_calls;
    }
    public void setThrottle_timeframe_max_calls(int throttle_timeframe_max_calls) {
        this.throttle_timeframe_max_calls = throttle_timeframe_max_calls;
    }

    @JsonIgnore
    public int getThrottle_timeframe_seconds() {
        return this.throttle_timeframe_seconds;
    }
    public void setThrottle_timeframe_seconds(int throttle_timeframe_seconds) {
        this.throttle_timeframe_seconds = throttle_timeframe_seconds;
    }

    @JsonIgnore
    public String getCompany_name() {
        return this.company_name;
    }
    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    @JsonIgnore
    public boolean getHas_grant_flow_permission() {
        return this.has_grant_flow_permission;
    }
    public void setHas_grant_flow_permission(boolean has_grant_flow_permission) {
        this.has_grant_flow_permission = has_grant_flow_permission;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ClientInfo that = (ClientInfo) o;
        return oauth_id == that.oauth_id &&
                version == that.version &&
                access_token_lifetime == that.access_token_lifetime &&
                refresh_token_lifetime == that.refresh_token_lifetime &&
                permission_join_flag == that.permission_join_flag &&
                is_active == that.is_active &&
                is_internal_client == that.is_internal_client &&
                throttle_timeframe_max_calls == that.throttle_timeframe_max_calls &&
                throttle_timeframe_seconds == that.throttle_timeframe_seconds &&
                has_grant_flow_permission == that.has_grant_flow_permission &&
                Objects.equal(oauth_client_id, that.oauth_client_id) &&
                Objects.equal(oauth_client_secret, that.oauth_client_secret) &&
                Objects.equal(oauth_resource_ids, that.oauth_resource_ids) &&
                Objects.equal(authority_scope, that.authority_scope) &&
                Objects.equal(authority_role, that.authority_role) &&
                Objects.equal(authorized_grant_types, that.authorized_grant_types) &&
                Objects.equal(company_name, that.company_name);
    }

    @Override public int hashCode() {
        return Objects.hashCode(oauth_id, oauth_client_id, version, oauth_client_secret, oauth_resource_ids, authority_scope,
                authority_role, authorized_grant_types, access_token_lifetime, refresh_token_lifetime, permission_join_flag,
                is_active, is_internal_client, throttle_timeframe_max_calls, throttle_timeframe_seconds, company_name,
                has_grant_flow_permission);
    }
}

