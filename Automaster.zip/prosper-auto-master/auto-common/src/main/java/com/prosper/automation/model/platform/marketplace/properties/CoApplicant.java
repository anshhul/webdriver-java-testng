
package com.prosper.automation.model.platform.marketplace.properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;

/**
 * Created by pbudiono on 6/21/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CoApplicant {

    @JsonProperty("personal_info")
    private PersonalInfo personalInfo;

    @JsonProperty("address_info")
    private AddressInfo addressInfo;

    @JsonProperty("contact_info")
    private ContactInfo contactInfo;

    @JsonProperty("employment_info")
    private EmploymentInfo employmentInfo;


    public CoApplicant() {
    }

    private CoApplicant(Builder builder) {
        personalInfo = builder.personalInfo;
        addressInfo = builder.addressInfo;
        contactInfo = builder.contactInfo;
        employmentInfo = builder.employmentInfo;
    }


    public static final class Builder {

        private PersonalInfo personalInfo;
        private AddressInfo addressInfo;
        private ContactInfo contactInfo;
        private EmploymentInfo employmentInfo;


        public Builder() {
        }

        public Builder withPersonalInfo(PersonalInfo val) {
            personalInfo = val;
            return this;
        }

        public Builder withAddressInfo(AddressInfo val) {
            addressInfo = val;
            return this;
        }

        public Builder withContactInfo(ContactInfo val) {
            contactInfo = val;
            return this;
        }

        public Builder withEmploymentInfo(EmploymentInfo val) {
            employmentInfo = val;
            return this;
        }

        public CoApplicant build() {
            return new CoApplicant(this);
        }
    }
}
