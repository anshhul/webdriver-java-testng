
package com.prosper.automation.model.platform.marketplace.util;

/**
 * Created by rsubramanyam on 4/1/16.
 */
public class PartnerCsvRow {

    String name;
    String campaignSource;
    String id;
    String oauthClientId;
    String oauthClientSecret;


    public PartnerCsvRow(String name, String id, String oauthClientId, String oauthClientSecret) {
        this.name = name;
        this.id = id;
        this.oauthClientId = oauthClientId;
        this.oauthClientSecret = oauthClientSecret;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCampaignSource() {
        return campaignSource;
    }

    public void setCampaignSource(String campaignSource) {
        this.campaignSource = campaignSource;
    }

    public String getOauthClientId() {
        return oauthClientId;
    }

    public void setOauthClientId(String oauthClientId) {
        this.oauthClientId = oauthClientId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOauthClientSecret() {
        return oauthClientSecret;
    }

    public void setOauthClientSecret(String oauthClientSecret) {
        this.oauthClientSecret = oauthClientSecret;
    }
}
