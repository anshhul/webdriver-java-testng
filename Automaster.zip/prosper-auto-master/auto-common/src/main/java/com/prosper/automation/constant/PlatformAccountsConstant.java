
package com.prosper.automation.constant;

public class PlatformAccountsConstant {

    public static String SEASONED_WHOLE_LOAN_INVESTOR = "SeasonedWholeLoans";
    
    public static int ACCOUNT_STATUS_CREATED = 0;
    public static int ACCOUNT_STATUS_INVALID = 1;
    public static int ACCOUNT_STATUS_ACTIVE = 2;
    public static int ACCOUNT_STATUS_FROZEN = 3; // Pending 4,5
    public static int ACCOUNT_STATUS_CLOSED = 6;
    
    public static String ACCOUNT_VERIFICATION_STATUS_FAILED = "Failed";
    public static String ACCOUNT_VERIFICATION_STATUS_INPROGRESS = "InProgress";
    public static String ACCOUNT_VERIFICATION_STATUS_NOTSTARTED = "NotStarted";
    public static String ACCOUNT_VERIFICATION_STATUS_UNABLETOVERIFY = "UnableToVerify";
    public static String ACCOUNT_VERIFICATION_STATUS_UNVERIFIED = "Unverified";
    public static String ACCOUNT_VERIFICATION_STATUS_VERIFIED = "Verified";
    public static String ACCOUNT_VERIFICATION_STATUS_NULL = null;
    
    public static String ACCOUNT_STATUS_TYPE_CODE_BANK = "Bank";
    public static String ACCOUNT_STATUS_TYPE_CODE_VIRTUAL = "VIRTUAL";
    
    public static int ACCOUNT_DEFAULT = 1;
    public static int ACCOUNT_NO_DEFAULT = 0;
    
    
    private PlatformAccountsConstant() {
        
    }
}
