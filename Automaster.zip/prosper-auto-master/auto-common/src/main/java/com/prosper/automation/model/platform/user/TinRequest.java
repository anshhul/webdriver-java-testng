
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class TinRequest {
    
    @JsonProperty("intended_role")
    private Integer intendedRole;
    @JsonProperty("tin")
    private String tin;
    @JsonProperty("date_of_birth")
    private String dateOfBirth;
    
    
    private TinRequest(final Builder builder) {
        intendedRole = builder.intendedRole;
        tin = builder.tin;
        dateOfBirth = builder.dateOfBirth;
    }

    public void setTin(final String tin) {
        this.tin = tin;
    }


    public static final class Builder {
        
        private Integer intendedRole;
        private String tin;
        private String dateOfBirth;
        
        
        public Builder() {
        }
        
        public Builder withIntendedRole(final Integer intendedRole) {
            this.intendedRole = intendedRole;
            return this;
        }
        
        public Builder withTin(final String tin) {
            this.tin = tin;
            return this;
        }
        
        public Builder withDateOfBirth(final String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
            return this;
        }
        
        public TinRequest build() {
            return new TinRequest(this);
        }
    }
}
