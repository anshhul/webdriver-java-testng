
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PersonNameRequestDTO {

    @JsonProperty("first")
    private String first;
    @JsonProperty("middle")
    private String middle;
    @JsonProperty("last")
    private String last;
    @JsonProperty("prefix")
    private String prefix;


    public PersonNameRequestDTO() {
    }

    private PersonNameRequestDTO(Builder builder) {
        setFirst(builder.first);
        setMiddle(builder.middle);
        setLast(builder.last);
        setPrefix(builder.prefix);
    }

    @JsonIgnore
    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    @JsonIgnore
    public String getMiddle() {
        return middle;
    }

    public void setMiddle(String middle) {
        this.middle = middle;
    }

    @JsonIgnore
    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    @JsonIgnore
    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }


    public static final class Builder {

        private String first;
        private String middle;
        private String last;
        private String prefix;


        public Builder() {
        }

        public Builder withFirst(String val) {
            first = val;
            return this;
        }

        public Builder withMiddle(String val) {
            middle = val;
            return this;
        }

        public Builder withLast(String val) {
            last = val;
            return this;
        }

        public Builder withPrefix(String val) {
            prefix = val;
            return this;
        }

        public PersonNameRequestDTO build() {
            return new PersonNameRequestDTO(this);
        }
    }
}
