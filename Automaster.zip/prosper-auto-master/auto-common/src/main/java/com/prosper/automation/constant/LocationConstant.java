
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.location.Coordinates;

/**
 * A class to hold location constant.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class LocationConstant {

    public static final Coordinates NORTH_POLE = new Coordinates.Builder().withLatitude(90).withLongitude(0).build();
    public static final Coordinates SOUTH_POLE = new Coordinates.Builder().withLatitude(-90).withLongitude(0).build();

    public static final Coordinates UPPER_BOUND_LAT = new Coordinates.Builder().withLatitude(91).withLongitude(0).build();
    public static final Coordinates LOWER_BOUND_LAT = new Coordinates.Builder().withLatitude(-91).withLongitude(0).build();
    public static final Coordinates UPPER_BOUND_LONG = new Coordinates.Builder().withLatitude(0).withLongitude(181).build();
    public static final Coordinates LOWER_BOUND_LONG = new Coordinates.Builder().withLatitude(0).withLongitude(-181).build();

    public static final Coordinates SAN_FRANCISCO = new Coordinates.Builder().withLatitude(37.773972F)
            .withLongitude(-122.431297F).build();
    public static final Coordinates LOS_ANGLES = new Coordinates.Builder().withLatitude(34.052235F).withLongitude(-118.243683F)
            .build();
    public static final Coordinates JAKARTA = new Coordinates.Builder().withLatitude(-6.1745F).withLongitude(106.8227F).build();
    public static final Coordinates SINGAPORE = new Coordinates.Builder().withLatitude(1.3F).withLongitude(103.8F).build();

    public static final Coordinates PROSPER_ROUTER = new Coordinates.Builder().withLatitude(37.7898F).withLongitude(-122.3942F)
            .build();
    public static final Coordinates PROSPER = new Coordinates.Builder().withLatitude(37.790413F).withLongitude(-122.39206F)
            .build();


    private LocationConstant() {
    }
}
