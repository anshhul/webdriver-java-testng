package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author sphatak
 *
 */
public class UserClickThrough {

	@JsonProperty("name")
    private String name;

    @JsonProperty("display")
    private boolean display;
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isDisplay() {
		return display;
	}

	public void setDisplay(boolean display) {
		this.display = display;
	}

}
