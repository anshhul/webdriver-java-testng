
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class OauthResponse {
    
    @JsonProperty("access_token")
    private UUID accessToken;
    
    @JsonProperty("token_type")
    private String tokenType;
    
    @JsonProperty("refresh_token")
    private UUID refreshToken;
    
    @JsonProperty("expires_in")
    private int expiresIn;
    
    @JsonProperty("scope")
    private String scope;
    
    
    public UUID getAccessToken() {
        return this.accessToken;
    }
    
    public UUID getRefreshToken() {
        return this.refreshToken;
    }

    public int getTokenExpiresIn() {
        return this.expiresIn;
    }
}
