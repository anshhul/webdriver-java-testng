
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CalculatedStaggAttributes {
    
    @JsonProperty("stagg_iln_debt_total")
    private Double staggIlnDebtTotal;
    @JsonProperty("stagg_iln_debt_total_no_mg")
    private Double staggIlnDebtTotalNoMg;
    @JsonProperty("stagg_rev_debt_total")
    private Double staggRevDebtTotal;
    @JsonProperty("stagg_rev_debt_total_no_mg")
    private Double staggRevDebtTotalNoMg;
    
    
    public CalculatedStaggAttributes() {
    }
    
    private CalculatedStaggAttributes(final Builder builder) {
        staggIlnDebtTotal = builder.staggIlnDebtTotal;
        staggIlnDebtTotalNoMg = builder.staggIlnDebtTotalNoMg;
        staggRevDebtTotal = builder.staggRevDebtTotal;
        staggRevDebtTotalNoMg = builder.staggRevDebtTotalNoMg;
    }
    
    
    public static final class Builder {
        
        private Double staggIlnDebtTotal;
        private Double staggIlnDebtTotalNoMg;
        private Double staggRevDebtTotal;
        private Double staggRevDebtTotalNoMg;
        
        
        public Builder() {
        }
        
        public Builder withStaggIlnDebtTotal(final Double staggIlnDebtTotal) {
            this.staggIlnDebtTotal = staggIlnDebtTotal;
            return this;
        }
        
        public Builder withStaggIlnDebtTotalNoMg(final Double staggIlnDebtTotalNoMg) {
            this.staggIlnDebtTotalNoMg = staggIlnDebtTotalNoMg;
            return this;
        }
        
        public Builder withStaggRevDebtTotal(final Double staggRevDebtTotal) {
            this.staggRevDebtTotal = staggRevDebtTotal;
            return this;
        }
        
        public Builder withStaggRevDebtTotalNoMg(final Double staggRevDebtTotalNoMg) {
            this.staggRevDebtTotalNoMg = staggRevDebtTotalNoMg;
            return this;
        }
        
        public CalculatedStaggAttributes build() {
            return new CalculatedStaggAttributes(this);
        }
    }
}
