package com.prosper.automation.model.platform.registeredUser;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by aamalraj on 12/21/15.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({"userRequest"})

public final class UserRegistered {

    @JsonProperty("userRequest") private RegisteredUserCreatedResponse user;

    public UserRegistered() {
    }

    @JsonIgnore public RegisteredUserResponse getUserRequest() {
        return user.getRegisteredUserResponse();
    }

    private UserRegistered(final Builder builder) {
        user = builder.user;
    }

    @JsonIgnore public RegisteredUserCreatedResponse getUser() {
        return user;
    }

    public static final class Builder {

        private RegisteredUserCreatedResponse user;

        public Builder() {
        }

        public Builder withUser(final RegisteredUserCreatedResponse user) {
            this.user = user;
            return this;
        }

        public UserRegistered build() {
            return new UserRegistered(this);
        }
    }

}


