package com.prosper.automation.model.platform.origination;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author sphatak
 *
 */
public class NetFundingTransfer {

	@JsonProperty("tmqId")
	private Integer tmqId;
	@JsonProperty("paymentSystemTypeId")
	private Integer paymentSystemTypeId;
	@JsonProperty("tmqPaymentId")
	private Integer tmqPaymentId;
	@JsonProperty("processOnDate")
	private String processOnDate;
	@JsonProperty("fromAccount")
	private Integer fromAccount;
	@JsonProperty("toAccount")
	private Integer toAccount;
	@JsonProperty("amount")
	private BigDecimal amount;
	@JsonProperty("isValid")
	private Boolean isValid;
	@JsonProperty("outcome")
	private String outcome;

	public Integer getTmqId() {
		return tmqId;
	}

	public void setTmqId(Integer tmqId) {
		this.tmqId = tmqId;
	}

	public Integer getPaymentSystemTypeId() {
		return paymentSystemTypeId;
	}

	public void setPaymentSystemTypeId(Integer paymentSystemTypeId) {
		this.paymentSystemTypeId = paymentSystemTypeId;
	}

	public Integer getTmqPaymentId() {
		return tmqPaymentId;
	}

	public void setTmqPaymentId(Integer tmqPaymentId) {
		this.tmqPaymentId = tmqPaymentId;
	}

	public String getProcessOnDate() {
		return processOnDate;
	}

	public void setProcessOnDate(String processOnDate) {
		this.processOnDate = processOnDate;
	}

	public Integer getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(Integer fromAccount) {
		this.fromAccount = fromAccount;
	}

	public Integer getToAccount() {
		return toAccount;
	}

	public void setToAccount(Integer toAccount) {
		this.toAccount = toAccount;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public String getOutcome() {
		return outcome;
	}

	public void setOutcome(String outcome) {
		this.outcome = outcome;
	}

}
