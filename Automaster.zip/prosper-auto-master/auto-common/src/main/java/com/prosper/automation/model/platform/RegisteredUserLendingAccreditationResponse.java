package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by aamalraj on 12/21/15.
 */

public class RegisteredUserLendingAccreditationResponse {

    @JsonProperty("credit_profile_auth") private Boolean creditProfileAuth;
    @JsonProperty("terms_of_use") private Boolean termsOfUse;
    @JsonProperty("privacy_policies_agreement") private Boolean privacyPoliciesAgreement;
    @JsonProperty("data_terms_of_use") private Boolean dataTermsOfUse;
    @JsonProperty("provider_info_sharing") private Boolean providerInfoSharing;

    public Boolean getPrivacyPoliciesAgreement() {
        return privacyPoliciesAgreement;
    }

    public Boolean getTermsOfUse() {
        return termsOfUse;
    }

    public Boolean getCreditProfileAuth() {
        return creditProfileAuth;
    }

    public Boolean getDataTermsOfUse() {
        return dataTermsOfUse;
    }

    public Boolean getProviderInfoSharing() {
        return providerInfoSharing;
    }

}
