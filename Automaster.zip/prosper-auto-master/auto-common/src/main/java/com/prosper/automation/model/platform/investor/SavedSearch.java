package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SavedSearch {
    @JsonProperty("saved_search_name")
    private String savedSearchName;

    @JsonProperty("saved_search_id")
    private String jsonSearchId;

    public String getJsonSearchId() {
        return jsonSearchId;
    }

    public String getSavedSearchName() {
        return savedSearchName;
    }

    public void setJsonSearchId(final String jsonSearchId) {
        this.jsonSearchId = jsonSearchId;
    }

    public void setSavedSearchName(final String savedSearchName) {
        this.savedSearchName = savedSearchName;
    }

}
