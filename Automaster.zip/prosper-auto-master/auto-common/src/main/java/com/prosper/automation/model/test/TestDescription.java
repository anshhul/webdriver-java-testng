
package com.prosper.automation.model.test;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class TestDescription {
    
    private static final String TEST_DESCRIPTION_TEMPLATE = new StringBuilder().append("*STEP TO TEST*\n").append("%s\n")
            .append("*EXPECTED RESULT*\n").append("%s\n\n").toString();
            
    private String expectedResult;
    private List<String> stepToTests;
    
    
    private TestDescription(final Builder builder) {
        expectedResult = builder.expectedResult;
        stepToTests = builder.stepToTests;
    }
    
    @Override
    public String toString() {
        final StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < stepToTests.size(); i++) {
            stringBuilder.append(String.format("%d. %s\n", i + 1, stepToTests.get(i)));
        }
        return String.format(TEST_DESCRIPTION_TEMPLATE, stringBuilder.toString(), expectedResult);
    }
    
    
    public static final class Builder {
        
        private String expectedResult;
        private List<String> stepToTests;
        
        
        public Builder() {
        }
        
        public Builder withExpectedResult(final String expectedResult) {
            this.expectedResult = expectedResult;
            return this;
        }
        
        public Builder withStepToTests(final List<String> stepToTests) {
            this.stepToTests = stepToTests;
            return this;
        }
        
        public TestDescription build() {
            return new TestDescription(this);
        }
    }
}
