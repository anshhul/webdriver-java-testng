
package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.UUID;

/**
 * Created by rsubramanyam on 4/15/16.
 */
public class Campaign {

    @JsonProperty("campaign_id")
    String campaignId;
    @JsonProperty("campaign_source_id")
    String campaignSourceId;
    @JsonProperty("campaign_channel_id")
    String campaignChannelId;
    @JsonProperty("rank")
    String rank;
    @JsonProperty("name")
    String name;
    @JsonProperty("description")
    String description;
    @JsonProperty("send_date")
    String sendDate;
    @JsonProperty("start_date")
    String startDate;
    @JsonProperty("end_date")
    String endDate;
    @JsonProperty("landing_page")
    String landingPage;
    @JsonProperty("created_date")
    String createdDate;
    @JsonProperty("modified_date")
    String modifiedDate;
    @JsonProperty("legacy_id")
    String legacyId;
    @JsonProperty("legacy_channel")
    String legacyChannel;
    @JsonProperty("duration")
    String duration;
    @JsonProperty("ref_ac")
    String refac;


    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getCampaignSourceId() {
        return campaignSourceId;
    }

    public void setCampaignSourceId(String campaignSourceId) {
        this.campaignSourceId = campaignSourceId;
    }

    public String getCampaignChannelId() {
        return campaignChannelId;
    }

    public void setCampaignChannelId(String campaignChannelId) {
        this.campaignChannelId = campaignChannelId;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getLandingPage() {
        return landingPage;
    }

    public void setLandingPage(String landingPage) {
        this.landingPage = landingPage;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getLegacyId() {
        return legacyId;
    }

    public void setLegacyId(String legacyId) {
        this.legacyId = legacyId;
    }

    public String getLegacyChannel() {
        return legacyChannel;
    }

    public void setLegacyChannel(String legacyChannel) {
        this.legacyChannel = legacyChannel;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public String getRefac() {
        return refac;
    }

    public void setRefac(String refac) {
        this.refac = refac;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Campaign campaign = (Campaign) o;
        return Objects.equal(campaignId, campaign.campaignId) &&
                Objects.equal(campaignSourceId, campaign.campaignSourceId) &&
                Objects.equal(campaignChannelId, campaign.campaignChannelId) &&
                Objects.equal(rank, campaign.rank) &&
                Objects.equal(name, campaign.name) &&
                Objects.equal(description, campaign.description) &&
                Objects.equal(sendDate, campaign.sendDate) &&
                Objects.equal(startDate, campaign.startDate) &&
                Objects.equal(endDate, campaign.endDate) &&
                Objects.equal(landingPage, campaign.landingPage) &&
                Objects.equal(createdDate, campaign.createdDate) &&
                Objects.equal(modifiedDate, campaign.modifiedDate) &&
                Objects.equal(legacyId, campaign.legacyId) &&
                Objects.equal(legacyChannel, campaign.legacyChannel) &&
                Objects.equal(duration, campaign.duration) &&
                Objects.equal(refac, campaign.refac);
    }

    public boolean equalsWithoutDates(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Campaign campaign = (Campaign) o;
        return Objects.equal(campaignId, campaign.campaignId) &&
                Objects.equal(campaignSourceId, campaign.campaignSourceId) &&
                Objects.equal(campaignChannelId, campaign.campaignChannelId) &&
                Objects.equal(rank, campaign.rank) &&
                Objects.equal(name, campaign.name) &&
                Objects.equal(description, campaign.description) &&
                Objects.equal(landingPage, campaign.landingPage) &&
                Objects.equal(legacyId, campaign.legacyId) &&
                Objects.equal(legacyChannel, campaign.legacyChannel) &&
                Objects.equal(duration, campaign.duration) &&
                Objects.equal(refac, campaign.refac);
    }

    @Override
    public int hashCode() {
        return Objects
                .hashCode(campaignId, campaignSourceId, campaignChannelId, rank, name, description, sendDate, startDate, endDate,
                        landingPage, createdDate, modifiedDate, legacyId, legacyChannel, duration, refac);
    }
}
