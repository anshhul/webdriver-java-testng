
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author Prateek
 */

@JsonInclude(Include.NON_NULL)
public final class Bids {
    
    @JsonProperty("listing_id")
    private Integer listingId;

    @JsonProperty("bid_amount")
    private Double bidAmount;
    
    @JsonProperty("bid_status")
    private String bidStatus;
    
    @JsonProperty("bid_amount_placed")
    private Double bidAmountPlaced;
    
    @JsonProperty("bid_result")
    private String bidResult;
    
    
    public Integer getListingId() {
        return listingId;
    }
    
    public void setListingId(Integer listingId) {
        this.listingId = listingId;
    }
    
    public Double getBidAmount() {
        return bidAmount;
    }
    
    public void setBidAmount(Double bidAmount) {
        this.bidAmount = bidAmount;
    }
    
    public String getBidStatus() {
        return bidStatus;
    }
    
    public void setBidStatus(String bidStatus) {
        this.bidStatus = bidStatus;
    }
    
    public Double getBidAmountPlaced() {
        return bidAmountPlaced;
    }
    
    public void setBidAmountPlaced(Double bidAmountPlaced) {
        this.bidAmountPlaced = bidAmountPlaced;
    }
    
    public String getBidResult() {
        return bidResult;
    }
    
    public void setBidResult(String bidResult) {
        this.bidResult = bidResult;
    }
    
    
    public static class BidsBuilder {

        private Integer listingId;
        private Double bidAmount;
        private String bidStatus;
        private Double bidAmountPlaced;
        private String bidResult;


        public BidsBuilder listingId(Integer value) {
            this.listingId = value;
            return this;
        }

        public BidsBuilder bidAmount(Double value) {
            this.bidAmount = value;
            return this;
        }

        public BidsBuilder bidStatus(String value) {
            this.bidStatus = value;
            return this;
        }

        public BidsBuilder bidAmountPlaced(Double value) {
            this.bidAmountPlaced = value;
            return this;
        }

        public BidsBuilder bidResult(String value) {
            this.bidResult = value;
            return this;
        }

        public Bids build() {
            final Bids result = new Bids();

            result.setListingId(listingId);
            result.setBidAmount(bidAmount);
            result.setBidStatus(bidStatus);
            result.setBidAmountPlaced(bidAmountPlaced);
            result.setBidResult(bidResult);
            return result;
        }
    }
    
    
    public static BidsBuilder newBuilder() {
        return new BidsBuilder();
    }
    
    public static BidsBuilder buildUpon(Bids original) {
        final BidsBuilder builder = newBuilder();
        builder.listingId(original.getListingId());
        builder.bidAmount(original.getBidAmount());
        builder.bidStatus(original.getBidStatus());
        builder.bidAmountPlaced(original.getBidAmountPlaced());
        builder.bidResult(original.getBidResult());
        return builder;
    }
    
}
