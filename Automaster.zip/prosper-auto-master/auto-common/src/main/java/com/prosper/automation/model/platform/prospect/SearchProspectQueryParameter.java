
package com.prosper.automation.model.platform.prospect;

import com.prosper.automation.model.platform.PhoneNumber;

import java.util.HashMap;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public class SearchProspectQueryParameter extends HashMap<String, String> {
    
    private static final String SIZE_KEY = "limit";
    private static final String OFFSET_KEY = "offset";
    
    private static final String FIRST_NAME_KEY = "first_name";
    private static final String LAST_NAME_KEY = "last_name";
    private static final String OFFER_CODE_KEY = "offer_code";
    private static final String PHONE_NUMBER_KEY = "phone_number";
    private static final String PHONE_TYPE_KEY = "phone_type";
    private static final String EMAIL_KEY = "email";
    
    private static final String SORT_KEY = "sort_by";
    
    private static final String SORT_KEY_TEMPLATE = "%s,%s";
    private static final String SSN_KEY = "ssn";
    
    
    private SearchProspectQueryParameter() {
        super();
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstName(final int size, final int page, final String firstName) {
        return buildSearchByFirstAndLastName(String.valueOf(size), String.valueOf(page), firstName, null);
    }
    
    public static SearchProspectQueryParameter buildSearchByLastName(final int size, final int page, final String lastName) {
        return buildSearchByFirstAndLastName(String.valueOf(size), String.valueOf(page), null, lastName);
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstAndLastName(final String size, final int page,
                                                                             final String firstName, final String lastName) {
        return buildSearchByFirstAndLastName(size, String.valueOf(page), firstName, lastName);
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstAndLastName(final int size, final String page,
                                                                             final String firstName, final String lastName) {
        return buildSearchByFirstAndLastName(String.valueOf(size), page, firstName, lastName);
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstAndLastName(final int size, final int page,
                                                                             final String firstName, final String lastName) {
        return buildSearchByFirstAndLastName(String.valueOf(size), String.valueOf(page), firstName, lastName);
    }
    
    private static SearchProspectQueryParameter buildSearchByFirstAndLastName(final String size, final String page,
                                                                              final String firstName, final String lastName) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(FIRST_NAME_KEY, firstName);
        searchProspectQueryParameter.put(LAST_NAME_KEY, lastName);
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByOfferCode(final int size, final int page, final String offerCode) {
        return buildSearchByOfferCode(String.valueOf(size), String.valueOf(page), offerCode);
    }
    
    private static SearchProspectQueryParameter buildSearchByOfferCode(final String size, final String page,
                                                                       final String offerCode) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(OFFER_CODE_KEY, offerCode);
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByEmail(final int size, final int page, final String email) {
        return buildSearchByEmail(String.valueOf(size), String.valueOf(page), email);
    }
    
    private static SearchProspectQueryParameter buildSearchByEmail(final String size, final String page, final String email) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(EMAIL_KEY, email);
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchBySsn(final int size, final int page, final String ssn) {
        return buildSearchBySsn(String.valueOf(size), String.valueOf(page), ssn);
    }
    
    public static SearchProspectQueryParameter buildSearchBySsn(final String size, final String page, final String ssn) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(SSN_KEY, ssn);
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByOfferCodeSortedByFirstName(final int size, final int page,
                                                                                       final String offerCode,
                                                                                       final String sortOrder) {
        return buildSearchByOfferCodeSortedByFirstName(String.valueOf(size), String.valueOf(page), offerCode, sortOrder);
    }
    
    public static SearchProspectQueryParameter buildSearchByOfferCodeSortedByFirstName(final String size, final String page,
                                                                                       final String offerCode,
                                                                                       final String sortOrder) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(OFFER_CODE_KEY, offerCode);
        searchProspectQueryParameter.put(SORT_KEY, String.format(SORT_KEY_TEMPLATE, ProspectSortOrder.FIRST_NAME, sortOrder));
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByOfferCodeSortedByLastName(final int size, final int page,
                                                                                      final String offerCode, String sortOrder) {
        return buildSearchByOfferCodeSortedByLastName(String.valueOf(size), String.valueOf(page), offerCode, sortOrder);
    }
    
    public static SearchProspectQueryParameter buildSearchByOfferCodeSortedByLastName(final String size, final String page,
                                                                                      final String offerCode, String sortOrder) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(OFFER_CODE_KEY, offerCode);
        searchProspectQueryParameter.put(SORT_KEY, String.format(SORT_KEY_TEMPLATE, ProspectSortOrder.LAST_NAME, sortOrder));
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstLastNameSortedByOfferCode(final int size, final int page,
                                                                                           final String firstName,
                                                                                           final String lastName,
                                                                                           final String sortOrder) {
        return buildSearchByFirstLastNameSortedByOfferCode(String.valueOf(size), String.valueOf(page), firstName, lastName,
                sortOrder);
    }
    
    public static SearchProspectQueryParameter buildSearchByFirstLastNameSortedByOfferCode(final String size, final String page,
                                                                                           final String firstName,
                                                                                           final String lastName,
                                                                                           final String sortOrder) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(FIRST_NAME_KEY, firstName);
        searchProspectQueryParameter.put(LAST_NAME_KEY, lastName);
        searchProspectQueryParameter.put(SORT_KEY, String.format(SORT_KEY_TEMPLATE, ProspectSortOrder.OFFER_CODE, sortOrder));
        return searchProspectQueryParameter;
    }
    
    public static SearchProspectQueryParameter buildSearchByPhoneNumber(final int size, final int page,
                                                                        final PhoneNumber phoneNumber) {
        return buildSearchByPhoneNumber(String.valueOf(size), String.valueOf(page), phoneNumber.getPhoneType(),
                phoneNumber.getPhoneNumber().replace("-", ""));
    }
    
    public static SearchProspectQueryParameter buildSearchByPhoneNumber(final String size, final String page,
                                                                        final String phoneType, final String phoneNumber) {
        final SearchProspectQueryParameter searchProspectQueryParameter = new SearchProspectQueryParameter();
        searchProspectQueryParameter.put(SIZE_KEY, size);
        searchProspectQueryParameter.put(OFFSET_KEY, page);
        searchProspectQueryParameter.put(PHONE_TYPE_KEY, phoneType);
        searchProspectQueryParameter.put(PHONE_NUMBER_KEY, phoneNumber);
        return searchProspectQueryParameter;
    }
    
    
    private enum ProspectSortOrder {
        
        LAST_NAME, FIRST_NAME, OFFER_CODE;
        
        @Override
        public String toString() {
            return this.name().toLowerCase();
        }
    }
}
