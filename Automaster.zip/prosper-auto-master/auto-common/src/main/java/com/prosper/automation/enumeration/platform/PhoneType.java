
package com.prosper.automation.enumeration.platform;

/**
 * A phone type enumeration.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum PhoneType {
    
    UNSPECIFIED(0), RESIDENTIAL(1), EMPLOYER(2), MOBILE(3), WORK(4);
    
    private int phoneTypeId;
    
    
    PhoneType(final int phoneTypeId) {
        this.phoneTypeId = phoneTypeId;
    }
    
    public int getPhoneTypeId() {
        return phoneTypeId;
    }
    
    public String getPhoneType() {
        return this.toString();
    }
}
