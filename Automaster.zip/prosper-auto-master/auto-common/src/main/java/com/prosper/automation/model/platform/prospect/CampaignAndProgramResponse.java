package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;
import com.prosper.automation.model.platform.marketplace.response.CampaignProgram;
import com.prosper.automation.model.platform.marketplace.response.Campaign;
/**
 * Created by rsubramanyam on 4/21/16.
 */
public final class CampaignAndProgramResponse {

    @JsonProperty("campaignVO")
    Campaign campaign;
    @JsonProperty("programVO")
    CampaignProgram campaignProgram;

    public CampaignAndProgramResponse(){}

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public CampaignProgram getCampaignProgram() {
        return campaignProgram;
    }

    public void setCampaignProgram(CampaignProgram campaignProgram) {
        this.campaignProgram = campaignProgram;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CampaignAndProgramResponse that = (CampaignAndProgramResponse) o;
        return Objects.equal(campaign, that.campaign) && Objects.equal(campaignProgram, that.campaignProgram);
    }

    @Override public int hashCode() {
        return Objects.hashCode(campaign, campaignProgram);
    }
}
