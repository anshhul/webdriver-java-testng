package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by ppatil on 12/7/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScoreVariable {

    @JsonProperty("pmi_variable_name")
    private ScoreVarType scoreVarType;
    @JsonProperty("weight")
    private Double weight = null;

    @JsonProperty("value")
    private String value;

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public ScoreVarType getScoreVarType() {
        return scoreVarType;
    }

    public void setScoreVarType(ScoreVarType scoreVarType) {
        this.scoreVarType = scoreVarType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
