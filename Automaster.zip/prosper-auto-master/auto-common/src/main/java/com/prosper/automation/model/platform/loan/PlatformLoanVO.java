
package com.prosper.automation.model.platform.loan;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class PlatformLoanVO {

    @JsonProperty("loan_number")
    private Integer loanNumber;

    @JsonProperty("amount_borrowed")
    private Double amountBorrowed;

    @JsonProperty("borrower_rate")
    private Double borrowerRate;

    @JsonProperty("prosper_rating")
    private String prosperRating;

    @JsonProperty("term")
    private Integer term;

    @JsonProperty("age_in_months")
    private Integer ageInMonths;

    @JsonProperty("origination_date")
    private String originationDate;

    @JsonProperty("days_past_due")
    private Integer daysPastDue;

    @JsonProperty("principal_balance")
    private Double principalBalance;

    @JsonProperty("service_fees_paid")
    private Double serviceFeesPaid;

    @JsonProperty("principal_paid")
    private Double principalPaid;

    @JsonProperty("interest_paid")
    private Double interestPaid;

    @JsonProperty("prosper_fees_paid")
    private Double prosperFeesPaid;

    @JsonProperty("late_fees_paid")
    private Double lateFeesPaid;

    @JsonProperty("debt_sale_proceeds_received")
    private Double debtSaleProceedsReceived;

    @JsonProperty("loan_status")
    private Integer loanStatus;
    
    @JsonProperty("loan_status_description")
    private String loanStatusDescription;

    @JsonProperty("loan_default_reason")
    private Integer loanDefaultReason;

    @JsonProperty("loan_default_reason_description")
    private String loanDefaultReasonDescription;

    @JsonProperty("next_payment_due_date")
    private String nextPaymentDueDate;

    @JsonProperty("next_payment_due_amount")
    private Double nextPaymentDueAmount;


    public static class PlatformLoanVOBuilder {

        private Integer ageInMonths;
        private Double amountBorrowed;
        private Double borrowerRate;
        private Integer daysPastDue;
        private Double debtSaleProceedsReceived;
        private Double interestPaid;
        private Double lateFeesPaid;
        private Integer loanDefaultReason;
        private String loanDefaultReasonDescription;
        private Integer loanNumber;
        private Integer loanStatus;
        private String loanStatusDescription;
        private Double nextPaymentDueAmount;
        private String nextPaymentDueDate;
        private String originationDate;
        private Double principalBalance;
        private Double principalPaid;
        private Double prosperFeesPaid;
        private String prosperRating;
        private Double serviceFeesPaid;
        private Integer term;


        public PlatformLoanVOBuilder ageInMonths(final Integer value) {
            this.ageInMonths = value;
            return this;
        }

        public PlatformLoanVOBuilder amountBorrowed(final Double value) {
            this.amountBorrowed = value;
            return this;
        }

        public PlatformLoanVOBuilder borrowerRate(final Double value) {
            this.borrowerRate = value;
            return this;
        }

        public PlatformLoanVO build() {
            final PlatformLoanVO result = new PlatformLoanVO();

            result.setAgeInMonths(ageInMonths);
            result.setAmountBorrowed(amountBorrowed);
            result.setBorrowerRate(borrowerRate);
            result.setDaysPastDue(daysPastDue);
            result.setDebtSaleProceedsReceived(debtSaleProceedsReceived);
            result.setInterestPaid(interestPaid);
            result.setLateFeesPaid(lateFeesPaid);
            result.setLoanDefaultReason(loanDefaultReason);
            result.setLoanDefaultReasonDescription(loanDefaultReasonDescription);
            result.setLoanNumber(loanNumber);
            result.setLoanStatus(loanStatus);
            result.setLoanStatusDescription(loanStatusDescription);
            result.setNextPaymentDueAmount(nextPaymentDueAmount);
            result.setNextPaymentDueDate(nextPaymentDueDate);
            result.setOriginationDate(originationDate);
            result.setPrincipalBalance(principalBalance);
            result.setPrincipalPaid(principalPaid);
            result.setProsperFeesPaid(prosperFeesPaid);
            result.setProsperRating(prosperRating);
            result.setServiceFeesPaid(serviceFeesPaid);
            result.setTerm(term);
            return result;
        }

        public PlatformLoanVOBuilder daysPastDue(final Integer value) {
            this.daysPastDue = value;
            return this;
        }

        public PlatformLoanVOBuilder debtSaleProceedsReceived(final Double value) {
            this.debtSaleProceedsReceived = value;
            return this;
        }

        public PlatformLoanVOBuilder interestPaid(final Double value) {
            this.interestPaid = value;
            return this;
        }

        public PlatformLoanVOBuilder lateFeesPaid(final Double value) {
            this.lateFeesPaid = value;
            return this;
        }

        public PlatformLoanVOBuilder loanDefaultReason(final Integer value) {
            this.loanDefaultReason = value;
            return this;
        }

        public PlatformLoanVOBuilder loanDefaultReasonDescription(final String value) {
            this.loanDefaultReasonDescription = value;
            return this;
        }

        public PlatformLoanVOBuilder loanNumber(final Integer value) {
            this.loanNumber = value;
            return this;
        }

        public PlatformLoanVOBuilder loanStatus(final Integer value) {
            this.loanStatus = value;
            return this;
        }

        public PlatformLoanVOBuilder loanStatusDescription(final String value) {
            this.loanStatusDescription = value;
            return this;
        }

        public PlatformLoanVOBuilder nextPaymentDueAmount(final Double value) {
            this.nextPaymentDueAmount = value;
            return this;
        }

        public PlatformLoanVOBuilder nextPaymentDueDate(final String value) {
            this.nextPaymentDueDate = value;
            return this;
        }

        public PlatformLoanVOBuilder originationDate(final String value) {
            this.originationDate = value;
            return this;
        }

        public PlatformLoanVOBuilder principalBalance(final Double value) {
            this.principalBalance = value;
            return this;
        }

        public PlatformLoanVOBuilder principalPaid(final Double value) {
            this.principalPaid = value;
            return this;
        }

        public PlatformLoanVOBuilder prosperFeesPaid(final Double value) {
            this.prosperFeesPaid = value;
            return this;
        }

        public PlatformLoanVOBuilder prosperRating(final String value) {
            this.prosperRating = value;
            return this;
        }

        public PlatformLoanVOBuilder serviceFeesPaid(final Double value) {
            this.serviceFeesPaid = value;
            return this;
        }

        public PlatformLoanVOBuilder term(final Integer value) {
            this.term = value;
            return this;
        }
    }
    
    
    public static PlatformLoanVOBuilder buildUpon(final PlatformLoanVO original) {
        final PlatformLoanVOBuilder builder = newBuilder();
        builder.ageInMonths(original.getAgeInMonths());
        builder.amountBorrowed(original.getAmountBorrowed());
        builder.borrowerRate(original.getBorrowerRate());
        builder.daysPastDue(original.getDaysPastDue());
        builder.debtSaleProceedsReceived(original.getDebtSaleProceedsReceived());
        builder.interestPaid(original.getInterestPaid());
        builder.lateFeesPaid(original.getLateFeesPaid());
        builder.loanDefaultReason(original.getLoanDefaultReason());
        builder.loanDefaultReasonDescription(original.getLoanDefaultReasonDescription());
        builder.loanNumber(original.getLoanNumber());
        builder.loanStatus(original.getLoanStatus());
        builder.loanStatusDescription(original.getLoanStatusDescription());
        builder.nextPaymentDueAmount(original.getNextPaymentDueAmount());
        builder.nextPaymentDueDate(original.getNextPaymentDueDate());
        builder.originationDate(original.getOriginationDate());
        builder.principalBalance(original.getPrincipalBalance());
        builder.principalPaid(original.getPrincipalPaid());
        builder.prosperFeesPaid(original.getProsperFeesPaid());
        builder.prosperRating(original.getProsperRating());
        builder.serviceFeesPaid(original.getServiceFeesPaid());
        builder.term(original.getTerm());
        return builder;
    }

    public static PlatformLoanVOBuilder newBuilder() {
        return new PlatformLoanVOBuilder();
    }

    public Integer getAgeInMonths() {
        return ageInMonths;
    }

    public Double getAmountBorrowed() {
        return amountBorrowed;
    }

    public Double getBorrowerRate() {
        return borrowerRate;
    }

    public Integer getDaysPastDue() {
        return daysPastDue;
    }

    public Double getDebtSaleProceedsReceived() {
        return debtSaleProceedsReceived;
    }

    public Double getInterestPaid() {
        return interestPaid;
    }

    public Double getLateFeesPaid() {
        return lateFeesPaid;
    }

    public Integer getLoanDefaultReason() {
        return loanDefaultReason;
    }

    public String getLoanDefaultReasonDescription() {
        return loanDefaultReasonDescription;
    }

    public Integer getLoanNumber() {
        return loanNumber;
    }

    public Integer getLoanStatus() {
        return loanStatus;
    }

    public String getLoanStatusDescription() {
        return loanStatusDescription;
    }

    public Double getNextPaymentDueAmount() {
        return nextPaymentDueAmount;
    }

    public String getNextPaymentDueDate() {
        return nextPaymentDueDate;
    }

    public String getOriginationDate() {
        return originationDate;
    }

    public Double getPrincipalBalance() {
        return principalBalance;
    }

    public Double getPrincipalPaid() {
        return principalPaid;
    }

    public Double getProsperFeesPaid() {
        return prosperFeesPaid;
    }

    public String getProsperRating() {
        return prosperRating;
    }

    public Double getServiceFeesPaid() {
        return serviceFeesPaid;
    }

    public Integer getTerm() {
        return term;
    }

    public void setAgeInMonths(final Integer ageInMonths) {
        this.ageInMonths = ageInMonths;
    }

    public void setAmountBorrowed(final Double amountBorrowed) {
        this.amountBorrowed = amountBorrowed;
    }

    public void setBorrowerRate(final Double borrowerRate) {
        this.borrowerRate = borrowerRate;
    }

    public void setDaysPastDue(final Integer daysPastDue) {
        this.daysPastDue = daysPastDue;
    }

    public void setDebtSaleProceedsReceived(final Double debtSaleProceedsReceived) {
        this.debtSaleProceedsReceived = debtSaleProceedsReceived;
    }

    public void setInterestPaid(final Double interestPaid) {
        this.interestPaid = interestPaid;
    }

    public void setLateFeesPaid(final Double lateFeesPaid) {
        this.lateFeesPaid = lateFeesPaid;
    }

    public void setLoanDefaultReason(final Integer loanDefaultReason) {
        this.loanDefaultReason = loanDefaultReason;
    }

    public void setLoanDefaultReasonDescription(final String loanDefaultReasonDescription) {
        this.loanDefaultReasonDescription = loanDefaultReasonDescription;
    }

    public void setLoanNumber(final Integer loanNumber) {
        this.loanNumber = loanNumber;
    }

    public void setLoanStatus(final Integer loanStatus) {
        this.loanStatus = loanStatus;
    }

    public void setLoanStatusDescription(final String loanStatusDescription) {
        this.loanStatusDescription = loanStatusDescription;
    }

    public void setNextPaymentDueAmount(final Double nextPaymentDueAmount) {
        this.nextPaymentDueAmount = nextPaymentDueAmount;
    }

    public void setNextPaymentDueDate(final String nextPaymentDueDate) {
        this.nextPaymentDueDate = nextPaymentDueDate;
    }

    public void setOriginationDate(final String originationDate) {
        this.originationDate = originationDate;
    }

    public void setPrincipalBalance(final Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    public void setPrincipalPaid(final Double principalPaid) {
        this.principalPaid = principalPaid;
    }

    public void setProsperFeesPaid(final Double prosperFeesPaid) {
        this.prosperFeesPaid = prosperFeesPaid;
    }
    
    public void setProsperRating(final String prosperRating) {
        this.prosperRating = prosperRating;
    }
    
    public void setServiceFeesPaid(final Double serviceFeesPaid) {
        this.serviceFeesPaid = serviceFeesPaid;
    }
    
    public void setTerm(final Integer term) {
        this.term = term;
    }

}
