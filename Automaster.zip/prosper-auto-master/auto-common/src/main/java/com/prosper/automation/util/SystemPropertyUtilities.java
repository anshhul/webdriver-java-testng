package com.prosper.automation.util;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class SystemPropertyUtilities {

    public static String getProperty(String key) {
        return System.getProperty(key);
    }
}
