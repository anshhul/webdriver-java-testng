
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ValidatePartnerCodeResponse {

    @JsonProperty("exists")
    private Boolean exists;


    @JsonIgnore
    public Boolean getExists() {
        return exists;
    }
}
