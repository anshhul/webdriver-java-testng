
package com.prosper.automation.constant;


import com.prosper.automation.model.platform.ContactInfo;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ContactInfoConstant {
    
    public static final ContactInfo PROSPER_CONTACT_INFO = new ContactInfo.Builder().withPhoneNumbers(
            PhoneNumberConstant.PROSPER_PHONE_NUMBERS).build();
    public static final ContactInfo WA_PHONE_NUMBERS = new ContactInfo.Builder().withPhoneNumbers(
            PhoneNumberConstant.WA_PHONE_NUMBERS).build();
    
    public static final ContactInfo INVALID_PHONE_NUMBERS = new ContactInfo.Builder().withPhoneNumbers(
            PhoneNumberConstant.INVALID_PHONE_NUMBERS).build();
    
    
    private ContactInfoConstant() {
    }
    
    public static ContactInfo buildPhoneNumbersContactInfo(final List<String> phoneNumbers) {
        return new ContactInfo.Builder().withPhoneNumbers(PhoneNumberConstant.buildPhoneNumbers(phoneNumbers)).build();
    }
}
