
package com.prosper.automation.model.platform.marketplace.util;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rsubramanyam on 4/1/16.
 */
public class CSVWriterUtil {

    public static void write(String filePath, List<PartnerCsvRow> partnerRows) throws IOException {
        // Create the CSVFormat object
        Writer writer = new OutputStreamWriter(new FileOutputStream(filePath), Charset.forName("UTF-8")); //$NON-NLS-1$
        CSVFormat format = CSVFormat.RFC4180.withHeader().withDelimiter(',');
        CSVPrinter printer = new CSVPrinter(writer, format.withDelimiter(','));
        printer.printRecord("partner_name", "legacy_id", "oauth_client_id", "oauth_client_secret");
        for (PartnerCsvRow row : partnerRows) {
            List<String> rowData = new ArrayList<String>();
            rowData.add(row.getId());
            rowData.add(row.getName());
            rowData.add(row.getOauthClientId());
            rowData.add(row.getOauthClientSecret());
            printer.printRecord(rowData);
        }
        writer.close();
        // close the printer
        printer.close();
    }
}
