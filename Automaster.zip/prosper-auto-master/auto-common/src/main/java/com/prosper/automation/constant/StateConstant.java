
package com.prosper.automation.constant;

import com.google.common.collect.ImmutableList;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class StateConstant {
    
    public static final ImmutableList<String> ELIGIBLE_LENDER_STATE = new ImmutableList.Builder().add("AK").add("CA").add("CO")
            .add("CT").add("DE").add("DC").add("FL").add("GA").add("HI").add("ID").add("IL").add("IN").add("LA").add("ME")
            .add("MI").add("MN").add("MS").add("MO").add("MT").add("NV").add("NH").add("NY").add("OR").add("RI").add("SC")
            .add("SD").add("UT").add("VT").add("VA").add("WA").add("WV").add("WI").add("WY").build();
    public static final ImmutableList<String> INELIGIBLE_LENDER_STATE = new ImmutableList.Builder().add("AL").add("AZ").add("AR")
            .add("IA").add("KS").add("KY").add("MD").add("MA").add("NE").add("NJ").add("NM").add("NC").add("ND").add("OH")
            .add("OK").add("PA").add("TN").add("TX").build();
    
    public static final ImmutableList<String> ELIGIBLE_BORROWER_STATE = new ImmutableList.Builder().add("AK").add("CA").add("CO")
            .add("CT").add("DE").add("DC").add("FL").add("GA").add("HI").add("ID").add("IL").add("LA").add("MI").add("MN")
            .add("MS").add("MO").add("MT").add("NV").add("NH").add("NY").add("OR").add("RI").add("SC").add("SD").add("UT")
            .add("VT").add("VA").add("WA").add("WV").add("WI").add("WY").add("AL").add("AZ").add("AR").add("IN").add("KS")
            .add("KY").add("MD").add("MA").add("NE").add("NJ").add("NM").add("NC").add("OH").add("OK").add("PA").add("TN")
            .add("TX").build();
    
    public static final ImmutableList<String> INELIGIBLE_BORROWER_STATE = new ImmutableList.Builder().add("ND").add("ME")
            .add("IA").build();
    
    
    private StateConstant() {
    }
}
