
package com.prosper.automation.model.platform.search;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class ListingHistorical implements Serializable {
    
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("member_key")
    private String memberKey;

    @JsonProperty("borrower_apr")
    private Double borrowerApr;

    @JsonProperty("listing_number")
    private Integer listingNumber;

    @JsonProperty("verification_stage")
    private Integer verificationStage;

    @JsonProperty("credit_pull_date")
    private String creditPullDate;

    @JsonProperty("listing_start_date")
    private String listingStartDate;

    @JsonProperty("listing_end_date")
    private String listingEndDate;

    @JsonProperty("listing_creation_date")
    private String listingCreationDate;

    @JsonProperty("loan_origination_date")
    private String loanOriginationDate;

    @JsonProperty("listing_status")
    private Integer listingStatus;

    @JsonProperty("listing_status_reason")
    private String listingStatusReason;

    @JsonProperty("listing_amount")
    private Double listingAmount;
    
    @JsonProperty("amount_funded")
    private Double amountFunded;

    @JsonProperty("amount_remaining")
    private Double amountRemaining;

    @JsonProperty("percent_funded")
    private Double percentFunded;

    @JsonProperty("partial_funding_indicator")
    private Boolean partialFundingIndicator;

    @JsonProperty("funding_threshold")
    private Double fundingThreshold;

    @JsonProperty("prosper_rating")
    private String prosperRating;

    @JsonProperty("estimated_return")
    private Double estimatedReturn;

    @JsonProperty("estimated_loss_rate")
    private Double estimatedLossRate;

    @JsonProperty("lender_yield")
    private Double lenderYield;

    @JsonProperty("effective_yield")
    private Double effectiveYield;

    @JsonProperty("borrower_rate")
    private Double borrowerRate;

    @JsonProperty("borrowerapr")
    private Double borrowerapr;

    @JsonProperty("listing_term")
    private Integer listingTerm;

    @JsonProperty("listing_monthly_payment")
    private Double listingMonthlyPayment;

    @JsonProperty("scorex")
    private String scorex;

    @JsonProperty("scorex_change")
    private String scorexChange;

    @JsonProperty("fico_score")
    private String ficoScore;

    @JsonProperty("prosper_score")
    private Integer prosperScore;

    @JsonProperty("listing_category_id")
    private Integer listingCategoryId;

    @JsonProperty("listing_purpose")
    private String listingPurpose;

    @JsonProperty("listing_title")
    private String listingTitle;

    @JsonProperty("borrower_listing_description")
    private String borrowerListingDescription;

    @JsonProperty("income_range")
    private Double incomeRange;

    @JsonProperty("income_range_description")
    private String incomeRangedescription;

    @JsonProperty("stated_monthly_income")
    private Double statedMonthlyIncome;

    @JsonProperty("income_verifiable")
    private Boolean incomeVerifiable;
    
    @JsonProperty("dt_iwprosper_loan")
    private Integer dtIwprosperLoan;

    @JsonProperty("employment_status_description")
    private String employmentStatusDescription;

    @JsonProperty("occupation")
    private String occupation;

    @JsonProperty("months_employed")
    private Integer monthsEmployed;
    
    @JsonProperty("borrower_state")
    private String borrowerState;
    
    @JsonProperty("borrower_city")
    private String borrowerCity;
    
    @JsonProperty("borrower_metropolitan_area")
    private String borrowerMetropolitanArea;

    @JsonProperty("prior_prosper_loans_active")
    private Integer priorProsperLoansActive;

    @JsonProperty("prior_prosper_loans")
    private Integer priorProsperLoans;

    @JsonProperty("prior_prosper_loans_principal_borrowed")
    private Double priorProsperLoansPrincipalBorrowed;

    @JsonProperty("prior_prosper_loans_principal_outstanding")
    private Double priorProsperLoansPrincipalOutstanding;
    
    @JsonProperty("prior_prosper_loans_balance_outstanding")
    private Double priorProsperLoansBalanceOutstanding;

    @JsonProperty("prior_prosper_loans_cycles_billed")
    private Integer priorProsperLoansCyclesBilled;
    
    @JsonProperty("prior_prosper_loans_ontime_payments")
    private Integer priorProsperLoansOntimePayments;

    @JsonProperty("prior_prosper_loans_late_cycles")
    private Integer priorProsperLoansLateCycles;

    @JsonProperty("prior_prosper_loans_late_payments_one_month_plus")
    private Integer priorProsperLoansLatePaymentsOneMonthPlus;
    
    @JsonProperty("max_prior_prosper_loan")
    private Double maxPriorProsperLoan;
    
    @JsonProperty("min_prior_prosper_loan")
    private Double minPriorProsperLoan;
    
    @JsonProperty("prior_prosper_loan_earliest_pay_off")
    private Integer priorProsperLoanEarliestPayOff;
    
    @JsonProperty("prior_prosper_loans31dpd")
    private Integer priorProsperLoans31dpd;
    
    @JsonProperty("prior_prosper_loans61dpd")
    private Integer priorProsperLoans61dpd;
    
    @JsonProperty("lender_indicator")
    private Integer lenderIndicator;
    
    @JsonProperty("group_indicator")
    private Boolean groupIndicator;
    
    @JsonProperty("group_name")
    private String groupName;
    
    @JsonProperty("channel_code")
    private String channelCode;
    
    @JsonProperty("amount_participation")
    private Double amountParticipation;
    
    @JsonProperty("all001")
    private Integer all001;
    
    @JsonProperty("all002")
    private Integer all002;
    
    @JsonProperty("all003")
    private Integer all003;
    
    @JsonProperty("all005")
    private Integer all005;

    @JsonProperty("all006")
    private Integer all006;
    
    @JsonProperty("all007")
    private Integer all007;

    @JsonProperty("all010")
    private Integer all010;
    
    @JsonProperty("all021")
    private Integer all021;
    
    @JsonProperty("all022")
    private Integer all022;
    
    @JsonProperty("all023")
    private Integer all023;
    
    @JsonProperty("all024")
    private Integer all024;
    
    @JsonProperty("all026")
    private Integer all026;
    
    @JsonProperty("all051")
    private Integer all051;
    
    @JsonProperty("all052")
    private Integer all052;
    
    @JsonProperty("all062")
    private Integer all062;
    
    @JsonProperty("all064")
    private Integer all064;
    
    @JsonProperty("all067")
    private Integer all067;
    
    @JsonProperty("all071")
    private Integer all071;
    
    @JsonProperty("all081")
    private Integer all081;
    
    @JsonProperty("all082")
    private Integer all082;
    
    @JsonProperty("all090")
    private Integer all090;
    
    @JsonProperty("all101")
    private Integer all101;
    
    @JsonProperty("all102")
    private Integer all102;
    
    @JsonProperty("all106")
    private Integer all106;
    
    @JsonProperty("all108")
    private Integer all108;
    
    @JsonProperty("all118")
    private Integer all118;

    @JsonProperty("all124")
    private Integer all124;
    
    @JsonProperty("all126")
    private Integer all126;
    
    @JsonProperty("all127")
    private Integer all127;
    
    @JsonProperty("all130")
    private Integer all130;
    
    @JsonProperty("all134")
    private Integer all134;
    
    @JsonProperty("all136")
    private Integer all136;
    
    @JsonProperty("all141")
    private Integer all141;
    
    @JsonProperty("all142")
    private Integer all142;
    
    @JsonProperty("all144")
    private Integer all144;
    
    @JsonProperty("all145")
    private Integer all145;
    
    @JsonProperty("all146")
    private Integer all146;
    
    @JsonProperty("all151")
    private Integer all151;
    
    @JsonProperty("all155")
    private Integer all155;
    
    @JsonProperty("all156")
    private Integer all156;
    
    @JsonProperty("all201")
    private Integer all201;
    
    @JsonProperty("all202")
    private Integer all202;
    
    @JsonProperty("all207")
    private Integer all207;
    
    @JsonProperty("all208")
    private Integer all208;
    
    @JsonProperty("all301")
    private Integer all301;
    
    @JsonProperty("all403")
    private Integer all403;
    
    @JsonProperty("all501")
    private Integer all501;
    
    @JsonProperty("all502")
    private Integer all502;
    
    @JsonProperty("all503")
    private Integer all503;
    
    @JsonProperty("all504")
    private Integer all504;
    
    @JsonProperty("all505")
    private Integer all505;
    
    @JsonProperty("all524")
    private Integer all524;
    
    @JsonProperty("all601")
    private Integer all601;
    
    @JsonProperty("all701")
    private Integer all701;
    
    @JsonProperty("all702")
    private Integer all702;
    
    @JsonProperty("all703")
    private Integer all703;
    
    @JsonProperty("all720")
    private Integer all720;
    
    @JsonProperty("all740")
    private Integer all740;
    
    @JsonProperty("all780")
    private Integer all780;
    
    @JsonProperty("all790")
    private Integer all790;
    
    @JsonProperty("all801")
    private Integer all801;
    
    @JsonProperty("all803")
    private Integer all803;
    
    @JsonProperty("all804")
    private Integer all804;
    
    @JsonProperty("all805")
    private Integer all805;
    
    @JsonProperty("all806")
    private Integer all806;
    
    @JsonProperty("all807")
    private Integer all807;
    
    @JsonProperty("all901")
    private Integer all901;
    
    @JsonProperty("all903")
    private Integer all903;
    
    @JsonProperty("all904")
    private Integer all904;
    
    @JsonProperty("all905")
    private Integer all905;

    @JsonProperty("all906")
    private Integer all906;
    
    @JsonProperty("bac001")
    private Integer bac001;
    
    @JsonProperty("bac002")
    private Integer bac002;
    
    @JsonProperty("bac005")
    private Integer bac005;
    
    @JsonProperty("bac007")
    private Integer bac007;
    
    @JsonProperty("bac022")
    private Integer bac022;
    
    @JsonProperty("bac026")
    private Integer bac026;
    
    @JsonProperty("bac028")
    private Integer bac028;
    
    @JsonProperty("bac031")
    private Integer bac031;
    
    @JsonProperty("bac035")
    private Integer bac035;
    
    @JsonProperty("bac042")
    private Integer bac042;
    
    @JsonProperty("bac044")
    private Integer bac044;
    
    @JsonProperty("bac045")
    private Integer bac045;
    
    @JsonProperty("bac071")
    private Integer bac071;
    
    @JsonProperty("bac081")
    private Integer bac081;
    
    @JsonProperty("bac084")
    private Integer bac084;
    
    @JsonProperty("bac159")
    private Integer bac159;
    
    @JsonProperty("bac302")
    private Integer bac302;
    
    @JsonProperty("bac303")
    private Integer bac303;
    
    @JsonProperty("bac401")
    private Integer bac401;
    
    @JsonProperty("bac403")
    private Integer bac403;
    
    @JsonProperty("bac501")
    private Integer bac501;
    
    @JsonProperty("bac502")
    private Integer bac502;
    
    @JsonProperty("bac503")
    private Integer bac503;
    
    @JsonProperty("bac550")
    private Integer bac550;
    
    @JsonProperty("bac584")
    private Integer bac584;
    
    @JsonProperty("bac589")
    private Integer bac589;
    
    @JsonProperty("bac601")
    private Integer bac601;
    
    @JsonProperty("bac751")
    private Integer bac751;
    
    @JsonProperty("bac752")
    private Integer bac752;
    
    @JsonProperty("bac804")
    private Integer bac804;
    
    @JsonProperty("bac901")
    private Integer bac901;
    
    @JsonProperty("bac908")
    private Integer bac908;
    
    @JsonProperty("bnk026")
    private Integer bnk026;
    
    @JsonProperty("brr026")
    private Integer brr026;
    
    @JsonProperty("fil022")
    private Integer fil022;
    
    @JsonProperty("fin601")
    private Integer fin601;
    
    @JsonProperty("heq001")
    private Integer heq001;
    
    @JsonProperty("iln002")
    private Integer iln002;
    
    @JsonProperty("iln007")
    private Integer iln007;
    
    @JsonProperty("iln022")
    private Integer iln022;
    
    @JsonProperty("iln023")
    private Integer iln023;
    
    @JsonProperty("iln071")
    private Integer iln071;
    
    @JsonProperty("iln075")
    private Integer iln075;
    
    @JsonProperty("iln081")
    private Integer iln081;
    
    @JsonProperty("iln101")
    private Integer iln101;
    
    @JsonProperty("iln102")
    private Integer iln102;
    
    @JsonProperty("iln112")
    private Integer iln112;
    
    @JsonProperty("iln126")
    private Integer iln126;
    
    @JsonProperty("iln127")
    private Integer iln127;
    
    @JsonProperty("iln201")
    private Integer iln201;
    
    @JsonProperty("iln301")
    private Integer iln301;
    
    @JsonProperty("iln403")
    private Integer iln403;
    
    @JsonProperty("iln502")
    private Integer iln502;
    
    @JsonProperty("iln503")
    private Integer iln503;
    
    @JsonProperty("iln601")
    private Integer iln601;
    
    @JsonProperty("iln701")
    private Integer iln701;
    
    @JsonProperty("iln702")
    private Integer iln702;
    
    @JsonProperty("iln804")
    private Integer iln804;
    
    @JsonProperty("iln901")
    private Integer iln901;
    
    @JsonProperty("iln903")
    private Integer iln903;
    
    @JsonProperty("iln908")
    private Integer iln908;
    
    @JsonProperty("iln914")
    private Integer iln914;
    
    @JsonProperty("ref001")
    private Integer ref001;
    
    @JsonProperty("rep001")
    private Integer rep001;
    
    @JsonProperty("rep002")
    private Integer rep002;
    
    @JsonProperty("rep026")
    private Integer rep026;
    
    @JsonProperty("rep075")
    private Integer rep075;
    
    @JsonProperty("rep302")
    private Integer rep302;
    
    @JsonProperty("rep503")
    private Integer rep503;
    
    @JsonProperty("rep601")
    private Integer rep601;
    
    @JsonProperty("rep904")
    private Integer rep904;
    
    @JsonProperty("rep908")
    private Integer rep908;
    
    @JsonProperty("rev001")
    private Integer rev001;
    
    @JsonProperty("rev002")
    private Integer rev002;
    
    @JsonProperty("rev006")
    private Integer rev006;
    
    @JsonProperty("rev007")
    private Integer rev007;
    
    @JsonProperty("rev022")
    private Integer rev022;
    
    @JsonProperty("rev024")
    private Integer rev024;
    
    @JsonProperty("rev026")
    private Integer rev026;
    
    @JsonProperty("rev028")
    private Integer rev028;
    
    @JsonProperty("rev038")
    private Integer rev038;
    
    @JsonProperty("rev071")
    private Integer rev071;
    
    @JsonProperty("rev081")
    private Integer rev081;
    
    @JsonProperty("rev086")
    private Integer rev086;
    
    @JsonProperty("rev101")
    private Integer rev101;
    
    @JsonProperty("rev102")
    private Integer rev102;
    
    @JsonProperty("rev106")
    private Integer rev106;
    
    @JsonProperty("rev115")
    private Integer rev115;
    
    @JsonProperty("rev125")
    private Integer rev125;
    
    @JsonProperty("rev126")
    private Integer rev126;
    
    @JsonProperty("rev130")
    private Integer rev130;
    
    @JsonProperty("rev159")
    private Integer rev159;
    
    @JsonProperty("rev201")
    private Integer rev201;
    
    @JsonProperty("rev202")
    private Integer rev202;
    
    @JsonProperty("rev301")
    private Integer rev301;
    
    @JsonProperty("rev302")
    private Integer rev302;
    
    @JsonProperty("rev401")
    private Integer rev401;
    
    @JsonProperty("rev403")
    private Integer rev403;
    
    @JsonProperty("rev502")
    private Integer rev502;
    
    @JsonProperty("rev503")
    private Integer rev503;
    
    @JsonProperty("rev524")
    private Integer rev524;
    
    @JsonProperty("rev550")
    private Integer rev550;
    
    @JsonProperty("rev584")
    private Integer rev584;
    
    @JsonProperty("rev585")
    private Integer rev585;
    
    @JsonProperty("rev589")
    private Integer rev589;
    
    @JsonProperty("rev590")
    private Integer rev590;
    
    @JsonProperty("rev601")
    private Integer rev601;
    
    @JsonProperty("rev701")
    private Integer rev701;
    
    @JsonProperty("rev702")
    private Integer rev702;
    
    @JsonProperty("rev703")
    private Integer rev703;
    
    @JsonProperty("rev720")
    private Integer rev720;
    
    @JsonProperty("rev740")
    private Integer rev740;
    
    @JsonProperty("rev751")
    private Integer rev751;
    
    @JsonProperty("rev752")
    private Integer rev752;
    
    @JsonProperty("rev901")
    private Integer rev901;
    
    @JsonProperty("rev904")
    private Integer rev904;
    
    @JsonProperty("rev908")
    private Integer rev908;
    
    @JsonProperty("rtl001")
    private Integer rtl001;

    @JsonProperty("rtl002")
    private Integer rtl002;
    
    @JsonProperty("rtr001")
    private Integer rtr001;
    
    @JsonProperty("rtr002")
    private Integer rtr002;
    
    @JsonProperty("rtr005")
    private Integer rtr005;
    
    @JsonProperty("rtr026")
    private Integer rtr026;
    
    @JsonProperty("rtr159")
    private Integer rtr159;
    
    @JsonProperty("rtr303")
    private Integer rtr303;
    
    @JsonProperty("rtr401")
    private Integer rtr401;
    
    @JsonProperty("rtr403")
    private Integer rtr403;
    
    @JsonProperty("rtr501")
    private Integer rtr501;
    
    @JsonProperty("rtr903")
    private Integer rtr903;
    
    @JsonProperty("ale001")
    private Integer ale001;
    
    @JsonProperty("ale002")
    private Integer ale002;
    
    @JsonProperty("ale005")
    private Integer ale005;
    
    @JsonProperty("ale007")
    private Integer ale007;
    
    @JsonProperty("ale022")
    private Integer ale022;
    
    @JsonProperty("ale023")
    private Integer ale023;
    
    @JsonProperty("ale026")
    private Integer ale026;
    
    @JsonProperty("ale071")
    private Integer ale071;
    
    @JsonProperty("ale074")
    private Integer ale074;
    
    @JsonProperty("ale075")
    private Integer ale075;
    
    @JsonProperty("ale076")
    private Integer ale076;
    
    @JsonProperty("ale077")
    private Integer ale077;
    
    @JsonProperty("ale078")
    private Integer ale078;
    
    @JsonProperty("ale080")
    private Integer ale080;
    
    @JsonProperty("ale081")
    private Integer ale081;
    
    @JsonProperty("ale084")
    private Integer ale084;
    
    @JsonProperty("ale403")
    private Integer ale403;
    
    @JsonProperty("ale501")
    private Integer ale501;
    
    @JsonProperty("ale502")
    private Integer ale502;
    
    @JsonProperty("ale503")
    private Integer ale503;
    
    @JsonProperty("ale601")
    private Integer ale601;
    
    @JsonProperty("ale720")
    private Integer ale720;
    
    @JsonProperty("ale724")
    private Integer ale724;
    
    @JsonProperty("ale740")
    private Integer ale740;
    
    @JsonProperty("ale801")
    private Integer ale801;
    
    @JsonProperty("ale804")
    private Integer ale804;
    
    @JsonProperty("ale901")
    private Integer ale901;
    
    @JsonProperty("ale903")
    private Integer ale903;
    
    @JsonProperty("ale904")
    private Integer ale904;
    
    @JsonProperty("ale905")
    private Integer ale905;
    
    @JsonProperty("ale906")
    private Integer ale906;
    
    @JsonProperty("ale908")
    private Integer ale908;
    
    @JsonProperty("all074")
    private Integer all074;
    
    @JsonProperty("all075")
    private Integer all075;
    
    @JsonProperty("all076")
    private Integer all076;
    
    @JsonProperty("all077")
    private Integer all077;
    
    @JsonProperty("all078")
    private Integer all078;
    
    @JsonProperty("all080")
    private Integer all080;
    
    @JsonProperty("all084")
    private Integer all084;
    
    @JsonProperty("all085")
    private Integer all085;
    
    @JsonProperty("all086")
    private Integer all086;
    
    @JsonProperty("all091")
    private Integer all091;
    
    @JsonProperty("all092")
    private Integer all092;
    
    @JsonProperty("all103")
    private Integer all103;
    
    @JsonProperty("all104")
    private Integer all104;
    
    @JsonProperty("all105")
    private Integer all105;
    
    @JsonProperty("all107")
    private Integer all107;
    
    @JsonProperty("all109")
    private Integer all109;
    
    @JsonProperty("all110")
    private Integer all110;
    
    @JsonProperty("all111")
    private Integer all111;
    
    @JsonProperty("all112")
    private Integer all112;
    
    @JsonProperty("all113")
    private Integer all113;
    
    @JsonProperty("all114")
    private Integer all114;
    
    @JsonProperty("all115")
    private Integer all115;
    
    @JsonProperty("all116")
    private Integer all116;
    
    @JsonProperty("all117")
    private Integer all117;
    
    @JsonProperty("all119")
    private Integer all119;
    
    @JsonProperty("all121")
    private Integer all121;

    @JsonProperty("all122")
    private Integer all122;

    @JsonProperty("all123")
    private Integer all123;

    @JsonProperty("all125")
    private Integer all125;

    @JsonProperty("all128")
    private Integer all128;

    @JsonProperty("all129")
    private Integer all129;

    @JsonProperty("all131")
    private Integer all131;

    @JsonProperty("all143")
    private Integer all143;

    @JsonProperty("all152")
    private Integer all152;

    @JsonProperty("all153")
    private Integer all153;

    @JsonProperty("all602")
    private Integer all602;

    @JsonProperty("all724")
    private Integer all724;

    @JsonProperty("all760")
    private Integer all760;

    @JsonProperty("all907")
    private Integer all907;

    @JsonProperty("aut001")
    private Integer aut001;

    @JsonProperty("aut071")
    private Integer aut071;

    @JsonProperty("aut720")
    private Integer aut720;

    @JsonProperty("bac023")
    private Integer bac023;

    @JsonProperty("bac037")
    private Integer bac037;

    @JsonProperty("bac074")
    private Integer bac074;

    @JsonProperty("bac075")
    private Integer bac075;

    @JsonProperty("bac076")
    private Integer bac076;

    @JsonProperty("bac077")
    private Integer bac077;

    @JsonProperty("bac078")
    private Integer bac078;

    @JsonProperty("bac080")
    private Integer bac080;

    @JsonProperty("bac801")
    private Integer bac801;

    @JsonProperty("bac903")
    private Integer bac903;

    @JsonProperty("bac904")
    private Integer bac904;

    @JsonProperty("bac905")
    private Integer bac905;

    @JsonProperty("bac906")
    private Integer bac906;

    @JsonProperty("bnk001")
    private Integer bnk001;

    @JsonProperty("cap026")
    private Integer cap026;

    @JsonProperty("cap801")
    private Integer cap801;

    @JsonProperty("cru001")
    private Integer cru001;

    @JsonProperty("fil001")
    private Integer fil001;

    @JsonProperty("fil023")
    private Integer fil023;

    @JsonProperty("fin001")
    private Integer fin001;

    @JsonProperty("fin026")
    private Integer fin026;

    @JsonProperty("fin801")
    private Integer fin801;

    @JsonProperty("gbl007")
    private Integer gbl007;

    @JsonProperty("iln001")
    private Integer iln001;

    @JsonProperty("iln005")
    private Integer iln005;

    @JsonProperty("iln006")
    private Integer iln006;

    @JsonProperty("iln026")
    private Integer iln026;

    @JsonProperty("iln064")
    private Integer iln064;

    @JsonProperty("iln067")
    private Integer iln067;

    @JsonProperty("iln074")
    private Integer iln074;

    @JsonProperty("iln076")
    private Integer iln076;

    @JsonProperty("iln077")
    private Integer iln077;

    @JsonProperty("iln078")
    private Integer iln078;

    @JsonProperty("iln080")
    private Integer iln080;

    @JsonProperty("iln084")
    private Integer iln084;

    @JsonProperty("iln085")
    private Integer iln085;

    @JsonProperty("iln086")
    private Integer iln086;

    @JsonProperty("iln103")
    private Integer iln103;

    @JsonProperty("iln104")
    private Integer iln104;

    @JsonProperty("iln105")
    private Integer iln105;

    @JsonProperty("iln106")
    private Integer iln106;

    @JsonProperty("iln107")
    private Integer iln107;

    @JsonProperty("iln108")
    private Integer iln108;

    @JsonProperty("iln109")
    private Integer iln109;

    @JsonProperty("iln110")
    private Integer iln110;

    @JsonProperty("iln111")
    private Integer iln111;

    @JsonProperty("iln113")
    private Integer iln113;

    @JsonProperty("iln114")
    private Integer iln114;

    @JsonProperty("iln115")
    private Integer iln115;

    @JsonProperty("iln116")
    private Integer iln116;

    @JsonProperty("iln117")
    private Integer iln117;

    @JsonProperty("iln118")
    private Integer iln118;

    @JsonProperty("iln119")
    private Integer iln119;

    @JsonProperty("iln122")
    private Integer iln122;

    @JsonProperty("iln124")
    private Integer iln124;

    @JsonProperty("iln125")
    private Integer iln125;

    @JsonProperty("iln128")
    private Integer iln128;

    @JsonProperty("iln129")
    private Integer iln129;

    @JsonProperty("iln130")
    private Integer iln130;

    @JsonProperty("iln302")
    private Integer iln302;

    @JsonProperty("iln501")
    private Integer iln501;

    @JsonProperty("iln504")
    private Integer iln504;

    @JsonProperty("iln703")
    private Integer iln703;

    @JsonProperty("iln720")
    private Integer iln720;

    @JsonProperty("iln724")
    private Integer iln724;

    @JsonProperty("iln740")
    private Integer iln740;

    @JsonProperty("iln801")
    private Integer iln801;

    @JsonProperty("iln904")
    private Integer iln904;

    @JsonProperty("iln905")
    private Integer iln905;

    @JsonProperty("iln906")
    private Integer iln906;

    @JsonProperty("lfi801")
    private Integer lfi801;

    @JsonProperty("rep005")
    private Integer rep005;

    @JsonProperty("rep071")
    private Integer rep071;

    @JsonProperty("rep074")
    private Integer rep074;

    @JsonProperty("rep076")
    private Integer rep076;

    @JsonProperty("rep077")
    private Integer rep077;

    @JsonProperty("rep078")
    private Integer rep078;

    @JsonProperty("rep080")
    private Integer rep080;

    @JsonProperty("rep081")
    private Integer rep081;

    @JsonProperty("rep084")
    private Integer rep084;

    @JsonProperty("rep501")
    private Integer rep501;

    @JsonProperty("rep901")
    private Integer rep901;

    @JsonProperty("rep903")
    private Integer rep903;

    @JsonProperty("rep905")
    private Integer rep905;

    @JsonProperty("rep906")
    private Integer rep906;

    @JsonProperty("rev005")
    private Integer rev005;

    @JsonProperty("rev023")
    private Integer rev023;

    @JsonProperty("rev044")
    private Integer rev044;

    @JsonProperty("rev064")
    private Integer rev064;

    @JsonProperty("rev067")
    private Integer rev067;

    @JsonProperty("rev074")
    private Integer rev074;

    @JsonProperty("rev075")
    private Integer rev075;

    @JsonProperty("rev076")
    private Integer rev076;

    @JsonProperty("rev077")
    private Integer rev077;

    @JsonProperty("rev078")
    private Integer rev078;

    @JsonProperty("rev080")
    private Integer rev080;

    @JsonProperty("rev084")
    private Integer rev084;

    @JsonProperty("rev085")
    private Integer rev085;

    @JsonProperty("rev103")
    private Integer rev103;

    @JsonProperty("rev104")
    private Integer rev104;

    @JsonProperty("rev105")
    private Integer rev105;

    @JsonProperty("rev107")
    private Integer rev107;

    @JsonProperty("rev108")
    private Integer rev108;

    @JsonProperty("rev109")
    private Integer rev109;

    @JsonProperty("rev110")
    private Integer rev110;

    @JsonProperty("rev111")
    private Integer rev111;

    @JsonProperty("rev112")
    private Integer rev112;

    @JsonProperty("rev113")
    private Integer rev113;

    @JsonProperty("rev114")
    private Integer rev114;

    @JsonProperty("rev116")
    private Integer rev116;

    @JsonProperty("rev117")
    private Integer rev117;

    @JsonProperty("rev118")
    private Integer rev118;

    @JsonProperty("rev119")
    private Integer rev119;

    @JsonProperty("rev122")
    private Integer rev122;

    @JsonProperty("rev124")
    private Integer rev124;

    @JsonProperty("rev127")
    private Integer rev127;

    @JsonProperty("rev128")
    private Integer rev128;

    @JsonProperty("rev129")
    private Integer rev129;

    @JsonProperty("rev404")
    private Integer rev404;

    @JsonProperty("rev501")
    private Integer rev501;

    @JsonProperty("rev504")
    private Integer rev504;

    @JsonProperty("rev724")
    private Integer rev724;

    @JsonProperty("rev903")
    private Integer rev903;

    @JsonProperty("rev905")
    private Integer rev905;

    @JsonProperty("rev906")
    private Integer rev906;

    @JsonProperty("rti026")
    private Integer rti026;

    @JsonProperty("rtl005")
    private Integer rtl005;

    @JsonProperty("rtl026")
    private Integer rtl026;

    @JsonProperty("rtl071")
    private Integer rtl071;

    @JsonProperty("rtl074")
    private Integer rtl074;

    @JsonProperty("rtl075")
    private Integer rtl075;

    @JsonProperty("rtl076")
    private Integer rtl076;

    @JsonProperty("rtl077")
    private Integer rtl077;

    @JsonProperty("rtl078")
    private Integer rtl078;

    @JsonProperty("rtl080")
    private Integer rtl080;

    @JsonProperty("rtl081")
    private Integer rtl081;

    @JsonProperty("rtl084")
    private Integer rtl084;

    @JsonProperty("rtl501")
    private Integer rtl501;

    @JsonProperty("rtl502")
    private Integer rtl502;

    @JsonProperty("rtl503")
    private Integer rtl503;

    @JsonProperty("rtl901")
    private Integer rtl901;
    
    @JsonProperty("rtl903")
    private Integer rtl903;

    @JsonProperty("rtl904")
    private Integer rtl904;

    @JsonProperty("rtl905")
    private Integer rtl905;

    @JsonProperty("rtl906")
    private Integer rtl906;

    @JsonProperty("rtl908")
    private Integer rtl908;

    @JsonProperty("rtr007")
    private Integer rtr007;

    @JsonProperty("rtr022")
    private Integer rtr022;

    @JsonProperty("rtr023")
    private Integer rtr023;

    @JsonProperty("rtr028")
    private Integer rtr028;

    @JsonProperty("rtr031")
    private Integer rtr031;

    @JsonProperty("rtr035")
    private Integer rtr035;

    @JsonProperty("rtr044")
    private Integer rtr044;

    @JsonProperty("rtr071")
    private Integer rtr071;

    @JsonProperty("rtr074")
    private Integer rtr074;

    @JsonProperty("rtr075")
    private Integer rtr075;

    @JsonProperty("rtr076")
    private Integer rtr076;

    @JsonProperty("rtr077")
    private Integer rtr077;

    @JsonProperty("rtr078")
    private Integer rtr078;

    @JsonProperty("rtr080")
    private Integer rtr080;

    @JsonProperty("rtr081")
    private Integer rtr081;

    @JsonProperty("rtr084")
    private Integer rtr084;

    @JsonProperty("rtr584")
    private Integer rtr584;

    @JsonProperty("rtr585")
    private Integer rtr585;

    @JsonProperty("rtr589")
    private Integer rtr589;

    @JsonProperty("rtr590")
    private Integer rtr590;

    @JsonProperty("rtr601")
    private Integer rtr601;

    @JsonProperty("rtr751")
    private Integer rtr751;

    @JsonProperty("rtr752")
    private Integer rtr752;

    @JsonProperty("rtr901")
    private Integer rtr901;

    @JsonProperty("rtr904")
    private Integer rtr904;

    @JsonProperty("rtr905")
    private Integer rtr905;

    @JsonProperty("rtr906")
    private Integer rtr906;

    @JsonProperty("rtr908")
    private Integer rtr908;

    @JsonProperty("monthly_debt")
    private Integer monthlyDebt;

    @JsonProperty("current_delinquencies")
    private Integer currentDelinquencies;

    @JsonProperty("delinquencies_last7_years")
    private Integer delinquenciesLast7Years;

    @JsonProperty("public_records_last10_years")
    private Integer publicRecordsLast10Years;

    @JsonProperty("public_records_last12_months")
    private Integer publicRecordsLast12Months;

    @JsonProperty("first_recorded_credit_line")
    private String firstRecordedCreditLine;
    
    @JsonProperty("credit_lines_last7_years")
    private Integer creditLinesLast7Years;

    @JsonProperty("inquiries_last6_months")
    private Integer inquiriesLast6Months;

    @JsonProperty("amount_delinquent")
    private Integer amountDelinquent;

    @JsonProperty("current_credit_lines")
    private Integer currentCreditLines;

    @JsonProperty("open_credit_lines")
    private Integer openCreditLines;

    @JsonProperty("bankcard_utilization")
    private Integer bankcardUtilization;

    @JsonProperty("total_open_revolving_accounts")
    private Integer totalOpenRevolvingAccounts;

    @JsonProperty("installment_balance")
    private Integer installmentBalance;

    @JsonProperty("real_estate_balance")
    private Integer realEstateBalance;

    @JsonProperty("revolving_balance")
    private Integer revolvingBalance;

    @JsonProperty("real_estate_payment")
    private Integer realEstatePayment;

    @JsonProperty("revolving_available_percent")
    private Integer revolvingAvailablePercent;

    @JsonProperty("total_inquiries")
    private Integer totalInquiries;

    @JsonProperty("total_trade_items")
    private Integer totalTradeItems;

    @JsonProperty("satisfactory_accounts")
    private Integer satisfactoryAccounts;

    @JsonProperty("now_delinquent_derog")
    private Integer nowDelinquentDerog;

    @JsonProperty("was_delinquent_derog")
    private Integer wasDelinquentDerog;

    @JsonProperty("oldest_trade_open_date")
    private String oldestTradeOpenDate;

    @JsonProperty("delinquencies_over30_days")
    private Integer delinquenciesOver30Days;

    @JsonProperty("delinquencies_over60_days")
    private Integer delinquenciesOver60Days;

    @JsonProperty("delinquencies_over90_days")
    private Integer delinquenciesOver90Days;

    @JsonProperty("investment_typeid")
    private Integer investmentTypeid;

    @JsonProperty("investment_type_description")
    private String investmentTypeDescription;

    @JsonProperty("whole_loan_start_date")
    private String wholeLoanStartDate;
    
    @JsonProperty("is_homeowner")
    private Boolean isHomeowner;
    
    @JsonProperty("last_updated_date")
    private String lastUpdatedDate;
    
    
    public Integer getAle001() {
        return ale001;
    }

    public Integer getAle002() {
        return ale002;
    }

    public Integer getAle005() {
        return ale005;
    }

    public Integer getAle007() {
        return ale007;
    }

    public Integer getAle022() {
        return ale022;
    }

    public Integer getAle023() {
        return ale023;
    }

    public Integer getAle026() {
        return ale026;
    }

    public Integer getAle071() {
        return ale071;
    }

    public Integer getAle074() {
        return ale074;
    }

    public Integer getAle075() {
        return ale075;
    }

    public Integer getAle076() {
        return ale076;
    }

    public Integer getAle077() {
        return ale077;
    }

    public Integer getAle078() {
        return ale078;
    }

    public Integer getAle080() {
        return ale080;
    }

    public Integer getAle081() {
        return ale081;
    }

    public Integer getAle084() {
        return ale084;
    }

    public Integer getAle403() {
        return ale403;
    }

    public Integer getAle501() {
        return ale501;
    }

    public Integer getAle502() {
        return ale502;
    }

    public Integer getAle503() {
        return ale503;
    }

    public Integer getAle601() {
        return ale601;
    }

    public Integer getAle720() {
        return ale720;
    }

    public Integer getAle724() {
        return ale724;
    }

    public Integer getAle740() {
        return ale740;
    }

    public Integer getAle801() {
        return ale801;
    }

    public Integer getAle804() {
        return ale804;
    }

    public Integer getAle901() {
        return ale901;
    }

    public Integer getAle903() {
        return ale903;
    }

    public Integer getAle904() {
        return ale904;
    }

    public Integer getAle905() {
        return ale905;
    }

    public Integer getAle906() {
        return ale906;
    }

    public Integer getAle908() {
        return ale908;
    }

    public Integer getAll001() {
        return all001;
    }

    public Integer getAll002() {
        return all002;
    }

    public Integer getAll003() {
        return all003;
    }

    public Integer getAll005() {
        return all005;
    }

    public Integer getAll006() {
        return all006;
    }

    public Integer getAll007() {
        return all007;
    }

    public Integer getAll010() {
        return all010;
    }

    public Integer getAll021() {
        return all021;
    }

    public Integer getAll022() {
        return all022;
    }

    public Integer getAll023() {
        return all023;
    }

    public Integer getAll024() {
        return all024;
    }

    public Integer getAll026() {
        return all026;
    }

    public Integer getAll051() {
        return all051;
    }

    public Integer getAll052() {
        return all052;
    }

    public Integer getAll062() {
        return all062;
    }

    public Integer getAll064() {
        return all064;
    }

    public Integer getAll067() {
        return all067;
    }

    public Integer getAll071() {
        return all071;
    }

    public Integer getAll074() {
        return all074;
    }

    public Integer getAll075() {
        return all075;
    }

    public Integer getAll076() {
        return all076;
    }

    public Integer getAll077() {
        return all077;
    }

    public Integer getAll078() {
        return all078;
    }

    public Integer getAll080() {
        return all080;
    }

    public Integer getAll081() {
        return all081;
    }

    public Integer getAll082() {
        return all082;
    }

    public Integer getAll084() {
        return all084;
    }

    public Integer getAll085() {
        return all085;
    }

    public Integer getAll086() {
        return all086;
    }

    public Integer getAll090() {
        return all090;
    }

    public Integer getAll091() {
        return all091;
    }

    public Integer getAll092() {
        return all092;
    }

    public Integer getAll101() {
        return all101;
    }

    public Integer getAll102() {
        return all102;
    }

    public Integer getAll103() {
        return all103;
    }

    public Integer getAll104() {
        return all104;
    }

    public Integer getAll105() {
        return all105;
    }

    public Integer getAll106() {
        return all106;
    }

    public Integer getAll107() {
        return all107;
    }

    public Integer getAll108() {
        return all108;
    }

    public Integer getAll109() {
        return all109;
    }

    public Integer getAll110() {
        return all110;
    }

    public Integer getAll111() {
        return all111;
    }

    public Integer getAll112() {
        return all112;
    }

    public Integer getAll113() {
        return all113;
    }

    public Integer getAll114() {
        return all114;
    }

    public Integer getAll115() {
        return all115;
    }

    public Integer getAll116() {
        return all116;
    }

    public Integer getAll117() {
        return all117;
    }

    public Integer getAll118() {
        return all118;
    }

    public Integer getAll119() {
        return all119;
    }

    public Integer getAll121() {
        return all121;
    }

    public Integer getAll122() {
        return all122;
    }

    public Integer getAll123() {
        return all123;
    }

    public Integer getAll124() {
        return all124;
    }

    public Integer getAll125() {
        return all125;
    }

    public Integer getAll126() {
        return all126;
    }

    public Integer getAll127() {
        return all127;
    }

    public Integer getAll128() {
        return all128;
    }

    public Integer getAll129() {
        return all129;
    }

    public Integer getAll130() {
        return all130;
    }

    public Integer getAll131() {
        return all131;
    }

    public Integer getAll134() {
        return all134;
    }

    public Integer getAll136() {
        return all136;
    }

    public Integer getAll141() {
        return all141;
    }

    public Integer getAll142() {
        return all142;
    }

    public Integer getAll143() {
        return all143;
    }

    public Integer getAll144() {
        return all144;
    }

    public Integer getAll145() {
        return all145;
    }

    public Integer getAll146() {
        return all146;
    }

    public Integer getAll151() {
        return all151;
    }

    public Integer getAll152() {
        return all152;
    }

    public Integer getAll153() {
        return all153;
    }

    public Integer getAll155() {
        return all155;
    }

    public Integer getAll156() {
        return all156;
    }

    public Integer getAll201() {
        return all201;
    }

    public Integer getAll202() {
        return all202;
    }

    public Integer getAll207() {
        return all207;
    }

    public Integer getAll208() {
        return all208;
    }

    public Integer getAll301() {
        return all301;
    }

    public Integer getAll403() {
        return all403;
    }

    public Integer getAll501() {
        return all501;
    }

    public Integer getAll502() {
        return all502;
    }

    public Integer getAll503() {
        return all503;
    }

    public Integer getAll504() {
        return all504;
    }

    public Integer getAll505() {
        return all505;
    }

    public Integer getAll524() {
        return all524;
    }

    public Integer getAll601() {
        return all601;
    }

    public Integer getAll602() {
        return all602;
    }

    public Integer getAll701() {
        return all701;
    }

    public Integer getAll702() {
        return all702;
    }

    public Integer getAll703() {
        return all703;
    }

    public Integer getAll720() {
        return all720;
    }

    public Integer getAll724() {
        return all724;
    }

    public Integer getAll740() {
        return all740;
    }

    public Integer getAll760() {
        return all760;
    }

    public Integer getAll780() {
        return all780;
    }

    public Integer getAll790() {
        return all790;
    }

    public Integer getAll801() {
        return all801;
    }

    public Integer getAll803() {
        return all803;
    }

    public Integer getAll804() {
        return all804;
    }

    public Integer getAll805() {
        return all805;
    }

    public Integer getAll806() {
        return all806;
    }

    public Integer getAll807() {
        return all807;
    }

    public Integer getAll901() {
        return all901;
    }

    public Integer getAll903() {
        return all903;
    }

    public Integer getAll904() {
        return all904;
    }

    public Integer getAll905() {
        return all905;
    }

    public Integer getAll906() {
        return all906;
    }

    public Integer getAll907() {
        return all907;
    }

    public Integer getAmountDelinquent() {
        return amountDelinquent;
    }

    public Double getAmountFunded() {
        return amountFunded;
    }

    public Double getAmountParticipation() {
        return amountParticipation;
    }

    public Double getAmountRemaining() {
        return amountRemaining;
    }

    public Integer getAut001() {
        return aut001;
    }

    public Integer getAut071() {
        return aut071;
    }

    public Integer getAut720() {
        return aut720;
    }

    public Integer getBac001() {
        return bac001;
    }

    public Integer getBac002() {
        return bac002;
    }

    public Integer getBac005() {
        return bac005;
    }

    public Integer getBac007() {
        return bac007;
    }

    public Integer getBac022() {
        return bac022;
    }

    public Integer getBac023() {
        return bac023;
    }

    public Integer getBac026() {
        return bac026;
    }

    public Integer getBac028() {
        return bac028;
    }

    public Integer getBac031() {
        return bac031;
    }

    public Integer getBac035() {
        return bac035;
    }

    public Integer getBac037() {
        return bac037;
    }

    public Integer getBac042() {
        return bac042;
    }

    public Integer getBac044() {
        return bac044;
    }

    public Integer getBac045() {
        return bac045;
    }

    public Integer getBac071() {
        return bac071;
    }

    public Integer getBac074() {
        return bac074;
    }

    public Integer getBac075() {
        return bac075;
    }

    public Integer getBac076() {
        return bac076;
    }

    public Integer getBac077() {
        return bac077;
    }

    public Integer getBac078() {
        return bac078;
    }

    public Integer getBac080() {
        return bac080;
    }

    public Integer getBac081() {
        return bac081;
    }

    public Integer getBac084() {
        return bac084;
    }

    public Integer getBac159() {
        return bac159;
    }

    public Integer getBac302() {
        return bac302;
    }

    public Integer getBac303() {
        return bac303;
    }

    public Integer getBac401() {
        return bac401;
    }

    public Integer getBac403() {
        return bac403;
    }

    public Integer getBac501() {
        return bac501;
    }

    public Integer getBac502() {
        return bac502;
    }

    public Integer getBac503() {
        return bac503;
    }

    public Integer getBac550() {
        return bac550;
    }

    public Integer getBac584() {
        return bac584;
    }

    public Integer getBac589() {
        return bac589;
    }

    public Integer getBac601() {
        return bac601;
    }

    public Integer getBac751() {
        return bac751;
    }

    public Integer getBac752() {
        return bac752;
    }

    public Integer getBac801() {
        return bac801;
    }

    public Integer getBac804() {
        return bac804;
    }

    public Integer getBac901() {
        return bac901;
    }

    public Integer getBac903() {
        return bac903;
    }

    public Integer getBac904() {
        return bac904;
    }

    public Integer getBac905() {
        return bac905;
    }

    public Integer getBac906() {
        return bac906;
    }

    public Integer getBac908() {
        return bac908;
    }

    public Integer getBankcardUtilization() {
        return bankcardUtilization;
    }

    public Integer getBnk001() {
        return bnk001;
    }

    public Integer getBnk026() {
        return bnk026;
    }

    public Double getBorrowerapr() {
        return borrowerapr;
    }

    public Double getBorrowerApr() {
        return borrowerApr;
    }

    public String getBorrowerCity() {
        return borrowerCity;
    }

    public String getBorrowerListingDescription() {
        return borrowerListingDescription;
    }

    public String getBorrowerMetropolitanArea() {
        return borrowerMetropolitanArea;
    }

    public Double getBorrowerRate() {
        return borrowerRate;
    }

    public String getBorrowerState() {
        return borrowerState;
    }

    public Integer getBrr026() {
        return brr026;
    }

    public Integer getCap026() {
        return cap026;
    }

    public Integer getCap801() {
        return cap801;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public Integer getCreditLinesLast7Years() {
        return creditLinesLast7Years;
    }

    public String getCreditPullDate() {
        return creditPullDate;
    }

    public Integer getCru001() {
        return cru001;
    }

    public Integer getCurrentCreditLines() {
        return currentCreditLines;
    }

    public Integer getCurrentDelinquencies() {
        return currentDelinquencies;
    }

    public Integer getDelinquenciesLast7Years() {
        return delinquenciesLast7Years;
    }

    public Integer getDelinquenciesOver30Days() {
        return delinquenciesOver30Days;
    }

    public Integer getDelinquenciesOver60Days() {
        return delinquenciesOver60Days;
    }

    public Integer getDelinquenciesOver90Days() {
        return delinquenciesOver90Days;
    }

    public Integer getDtIwprosperLoan() {
        return dtIwprosperLoan;
    }

    public Double getEffectiveYield() {
        return effectiveYield;
    }

    public String getEmploymentStatusDescription() {
        return employmentStatusDescription;
    }

    public Double getEstimatedLossRate() {
        return estimatedLossRate;
    }

    public Double getEstimatedReturn() {
        return estimatedReturn;
    }

    public String getFicoScore() {
        return ficoScore;
    }

    public Integer getFil001() {
        return fil001;
    }

    public Integer getFil022() {
        return fil022;
    }

    public Integer getFil023() {
        return fil023;
    }

    public Integer getFin001() {
        return fin001;
    }

    public Integer getFin026() {
        return fin026;
    }

    public Integer getFin601() {
        return fin601;
    }

    public Integer getFin801() {
        return fin801;
    }

    public String getFirstRecordedCreditLine() {
        return firstRecordedCreditLine;
    }

    public Double getFundingThreshold() {
        return fundingThreshold;
    }

    public Integer getGbl007() {
        return gbl007;
    }

    public Boolean getGroupIndicator() {
        return groupIndicator;
    }

    public String getGroupName() {
        return groupName;
    }

    public Integer getHeq001() {
        return heq001;
    }

    public Integer getIln001() {
        return iln001;
    }

    public Integer getIln002() {
        return iln002;
    }

    public Integer getIln005() {
        return iln005;
    }

    public Integer getIln006() {
        return iln006;
    }

    public Integer getIln007() {
        return iln007;
    }

    public Integer getIln022() {
        return iln022;
    }

    public Integer getIln023() {
        return iln023;
    }

    public Integer getIln026() {
        return iln026;
    }

    public Integer getIln064() {
        return iln064;
    }

    public Integer getIln067() {
        return iln067;
    }

    public Integer getIln071() {
        return iln071;
    }

    public Integer getIln074() {
        return iln074;
    }

    public Integer getIln075() {
        return iln075;
    }

    public Integer getIln076() {
        return iln076;
    }

    public Integer getIln077() {
        return iln077;
    }

    public Integer getIln078() {
        return iln078;
    }

    public Integer getIln080() {
        return iln080;
    }

    public Integer getIln081() {
        return iln081;
    }

    public Integer getIln084() {
        return iln084;
    }

    public Integer getIln085() {
        return iln085;
    }

    public Integer getIln086() {
        return iln086;
    }

    public Integer getIln101() {
        return iln101;
    }

    public Integer getIln102() {
        return iln102;
    }

    public Integer getIln103() {
        return iln103;
    }

    public Integer getIln104() {
        return iln104;
    }

    public Integer getIln105() {
        return iln105;
    }

    public Integer getIln106() {
        return iln106;
    }

    public Integer getIln107() {
        return iln107;
    }

    public Integer getIln108() {
        return iln108;
    }

    public Integer getIln109() {
        return iln109;
    }

    public Integer getIln110() {
        return iln110;
    }

    public Integer getIln111() {
        return iln111;
    }

    public Integer getIln112() {
        return iln112;
    }

    public Integer getIln113() {
        return iln113;
    }

    public Integer getIln114() {
        return iln114;
    }

    public Integer getIln115() {
        return iln115;
    }

    public Integer getIln116() {
        return iln116;
    }

    public Integer getIln117() {
        return iln117;
    }

    public Integer getIln118() {
        return iln118;
    }

    public Integer getIln119() {
        return iln119;
    }

    public Integer getIln122() {
        return iln122;
    }

    public Integer getIln124() {
        return iln124;
    }

    public Integer getIln125() {
        return iln125;
    }

    public Integer getIln126() {
        return iln126;
    }

    public Integer getIln127() {
        return iln127;
    }

    public Integer getIln128() {
        return iln128;
    }

    public Integer getIln129() {
        return iln129;
    }

    public Integer getIln130() {
        return iln130;
    }

    public Integer getIln201() {
        return iln201;
    }

    public Integer getIln301() {
        return iln301;
    }

    public Integer getIln302() {
        return iln302;
    }

    public Integer getIln403() {
        return iln403;
    }

    public Integer getIln501() {
        return iln501;
    }

    public Integer getIln502() {
        return iln502;
    }

    public Integer getIln503() {
        return iln503;
    }

    public Integer getIln504() {
        return iln504;
    }

    public Integer getIln601() {
        return iln601;
    }

    public Integer getIln701() {
        return iln701;
    }

    public Integer getIln702() {
        return iln702;
    }

    public Integer getIln703() {
        return iln703;
    }

    public Integer getIln720() {
        return iln720;
    }

    public Integer getIln724() {
        return iln724;
    }

    public Integer getIln740() {
        return iln740;
    }

    public Integer getIln801() {
        return iln801;
    }

    public Integer getIln804() {
        return iln804;
    }

    public Integer getIln901() {
        return iln901;
    }

    public Integer getIln903() {
        return iln903;
    }

    public Integer getIln904() {
        return iln904;
    }

    public Integer getIln905() {
        return iln905;
    }

    public Integer getIln906() {
        return iln906;
    }

    public Integer getIln908() {
        return iln908;
    }

    public Integer getIln914() {
        return iln914;
    }

    public Double getIncomeRange() {
        return incomeRange;
    }

    public String getIncomeRangedescription() {
        return incomeRangedescription;
    }

    public Boolean getIncomeVerifiable() {
        return incomeVerifiable;
    }

    public Integer getInquiriesLast6Months() {
        return inquiriesLast6Months;
    }

    public Integer getInstallmentBalance() {
        return installmentBalance;
    }

    public String getInvestmentTypeDescription() {
        return investmentTypeDescription;
    }

    public Integer getInvestmentTypeid() {
        return investmentTypeid;
    }

    public Boolean getIsHomeowner() {
        return isHomeowner;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public Integer getLenderIndicator() {
        return lenderIndicator;
    }

    public Double getLenderYield() {
        return lenderYield;
    }

    public Integer getLfi801() {
        return lfi801;
    }

    public Double getListingAmount() {
        return listingAmount;
    }

    public Integer getListingCategoryId() {
        return listingCategoryId;
    }

    public String getListingCreationDate() {
        return listingCreationDate;
    }

    public String getListingEndDate() {
        return listingEndDate;
    }

    public Double getListingMonthlyPayment() {
        return listingMonthlyPayment;
    }

    public Integer getListingNumber() {
        return listingNumber;
    }

    public String getListingPurpose() {
        return listingPurpose;
    }

    public String getListingStartDate() {
        return listingStartDate;
    }

    public Integer getListingStatus() {
        return listingStatus;
    }

    public String getListingStatusReason() {
        return listingStatusReason;
    }

    public Integer getListingTerm() {
        return listingTerm;
    }

    public String getListingTitle() {
        return listingTitle;
    }

    public String getLoanOriginationDate() {
        return loanOriginationDate;
    }

    public Double getMaxPriorProsperLoan() {
        return maxPriorProsperLoan;
    }

    public String getMemberKey() {
        return memberKey;
    }

    public Double getMinPriorProsperLoan() {
        return minPriorProsperLoan;
    }

    public Integer getMonthlyDebt() {
        return monthlyDebt;
    }

    public Integer getMonthsEmployed() {
        return monthsEmployed;
    }

    public Integer getNowDelinquentDerog() {
        return nowDelinquentDerog;
    }

    public String getOccupation() {
        return occupation;
    }

    public String getOldestTradeOpenDate() {
        return oldestTradeOpenDate;
    }
    
    public Integer getOpenCreditLines() {
        return openCreditLines;
    }

    public Boolean getPartialFundingIndicator() {
        return partialFundingIndicator;
    }

    public Double getPercentFunded() {
        return percentFunded;
    }

    public Integer getPriorProsperLoanEarliestPayOff() {
        return priorProsperLoanEarliestPayOff;
    }

    public Integer getPriorProsperLoans() {
        return priorProsperLoans;
    }

    public Integer getPriorProsperLoans31dpd() {
        return priorProsperLoans31dpd;
    }

    public Integer getPriorProsperLoans61dpd() {
        return priorProsperLoans61dpd;
    }

    public Integer getPriorProsperLoansActive() {
        return priorProsperLoansActive;
    }

    public Double getPriorProsperLoansBalanceOutstanding() {
        return priorProsperLoansBalanceOutstanding;
    }

    public Integer getPriorProsperLoansCyclesBilled() {
        return priorProsperLoansCyclesBilled;
    }

    public Integer getPriorProsperLoansLateCycles() {
        return priorProsperLoansLateCycles;
    }

    public Integer getPriorProsperLoansLatePaymentsOneMonthPlus() {
        return priorProsperLoansLatePaymentsOneMonthPlus;
    }

    public Integer getPriorProsperLoansOntimePayments() {
        return priorProsperLoansOntimePayments;
    }

    public Double getPriorProsperLoansPrincipalBorrowed() {
        return priorProsperLoansPrincipalBorrowed;
    }

    public Double getPriorProsperLoansPrincipalOutstanding() {
        return priorProsperLoansPrincipalOutstanding;
    }

    public String getProsperRating() {
        return prosperRating;
    }

    public Integer getProsperScore() {
        return prosperScore;
    }

    public Integer getPublicRecordsLast10Years() {
        return publicRecordsLast10Years;
    }

    public Integer getPublicRecordsLast12Months() {
        return publicRecordsLast12Months;
    }

    public Integer getRealEstateBalance() {
        return realEstateBalance;
    }

    public Integer getRealEstatePayment() {
        return realEstatePayment;
    }

    public Integer getRef001() {
        return ref001;
    }

    public Integer getRep001() {
        return rep001;
    }

    public Integer getRep002() {
        return rep002;
    }

    public Integer getRep005() {
        return rep005;
    }

    public Integer getRep026() {
        return rep026;
    }

    public Integer getRep071() {
        return rep071;
    }

    public Integer getRep074() {
        return rep074;
    }

    public Integer getRep075() {
        return rep075;
    }

    public Integer getRep076() {
        return rep076;
    }

    public Integer getRep077() {
        return rep077;
    }

    public Integer getRep078() {
        return rep078;
    }

    public Integer getRep080() {
        return rep080;
    }

    public Integer getRep081() {
        return rep081;
    }

    public Integer getRep084() {
        return rep084;
    }

    public Integer getRep302() {
        return rep302;
    }

    public Integer getRep501() {
        return rep501;
    }

    public Integer getRep503() {
        return rep503;
    }

    public Integer getRep601() {
        return rep601;
    }

    public Integer getRep901() {
        return rep901;
    }

    public Integer getRep903() {
        return rep903;
    }

    public Integer getRep904() {
        return rep904;
    }

    public Integer getRep905() {
        return rep905;
    }

    public Integer getRep906() {
        return rep906;
    }

    public Integer getRep908() {
        return rep908;
    }

    public Integer getRev001() {
        return rev001;
    }

    public Integer getRev002() {
        return rev002;
    }

    public Integer getRev005() {
        return rev005;
    }

    public Integer getRev006() {
        return rev006;
    }

    public Integer getRev007() {
        return rev007;
    }

    public Integer getRev022() {
        return rev022;
    }

    public Integer getRev023() {
        return rev023;
    }

    public Integer getRev024() {
        return rev024;
    }

    public Integer getRev026() {
        return rev026;
    }

    public Integer getRev028() {
        return rev028;
    }

    public Integer getRev038() {
        return rev038;
    }

    public Integer getRev044() {
        return rev044;
    }

    public Integer getRev064() {
        return rev064;
    }

    public Integer getRev067() {
        return rev067;
    }

    public Integer getRev071() {
        return rev071;
    }

    public Integer getRev074() {
        return rev074;
    }

    public Integer getRev075() {
        return rev075;
    }

    public Integer getRev076() {
        return rev076;
    }

    public Integer getRev077() {
        return rev077;
    }

    public Integer getRev078() {
        return rev078;
    }

    public Integer getRev080() {
        return rev080;
    }

    public Integer getRev081() {
        return rev081;
    }

    public Integer getRev084() {
        return rev084;
    }

    public Integer getRev085() {
        return rev085;
    }

    public Integer getRev086() {
        return rev086;
    }

    public Integer getRev101() {
        return rev101;
    }

    public Integer getRev102() {
        return rev102;
    }

    public Integer getRev103() {
        return rev103;
    }

    public Integer getRev104() {
        return rev104;
    }

    public Integer getRev105() {
        return rev105;
    }

    public Integer getRev106() {
        return rev106;
    }

    public Integer getRev107() {
        return rev107;
    }

    public Integer getRev108() {
        return rev108;
    }

    public Integer getRev109() {
        return rev109;
    }

    public Integer getRev110() {
        return rev110;
    }

    public Integer getRev111() {
        return rev111;
    }

    public Integer getRev112() {
        return rev112;
    }

    public Integer getRev113() {
        return rev113;
    }

    public Integer getRev114() {
        return rev114;
    }

    public Integer getRev115() {
        return rev115;
    }

    public Integer getRev116() {
        return rev116;
    }

    public Integer getRev117() {
        return rev117;
    }

    public Integer getRev118() {
        return rev118;
    }

    public Integer getRev119() {
        return rev119;
    }

    public Integer getRev122() {
        return rev122;
    }

    public Integer getRev124() {
        return rev124;
    }

    public Integer getRev125() {
        return rev125;
    }

    public Integer getRev126() {
        return rev126;
    }

    public Integer getRev127() {
        return rev127;
    }

    public Integer getRev128() {
        return rev128;
    }

    public Integer getRev129() {
        return rev129;
    }

    public Integer getRev130() {
        return rev130;
    }

    public Integer getRev159() {
        return rev159;
    }

    public Integer getRev201() {
        return rev201;
    }

    public Integer getRev202() {
        return rev202;
    }

    public Integer getRev301() {
        return rev301;
    }

    public Integer getRev302() {
        return rev302;
    }

    public Integer getRev401() {
        return rev401;
    }

    public Integer getRev403() {
        return rev403;
    }

    public Integer getRev404() {
        return rev404;
    }

    public Integer getRev501() {
        return rev501;
    }

    public Integer getRev502() {
        return rev502;
    }

    public Integer getRev503() {
        return rev503;
    }

    public Integer getRev504() {
        return rev504;
    }

    public Integer getRev524() {
        return rev524;
    }

    public Integer getRev550() {
        return rev550;
    }

    public Integer getRev584() {
        return rev584;
    }

    public Integer getRev585() {
        return rev585;
    }

    public Integer getRev589() {
        return rev589;
    }

    public Integer getRev590() {
        return rev590;
    }

    public Integer getRev601() {
        return rev601;
    }

    public Integer getRev701() {
        return rev701;
    }

    public Integer getRev702() {
        return rev702;
    }

    public Integer getRev703() {
        return rev703;
    }

    public Integer getRev720() {
        return rev720;
    }

    public Integer getRev724() {
        return rev724;
    }

    public Integer getRev740() {
        return rev740;
    }

    public Integer getRev751() {
        return rev751;
    }

    public Integer getRev752() {
        return rev752;
    }

    public Integer getRev901() {
        return rev901;
    }

    public Integer getRev903() {
        return rev903;
    }

    public Integer getRev904() {
        return rev904;
    }

    public Integer getRev905() {
        return rev905;
    }

    public Integer getRev906() {
        return rev906;
    }

    public Integer getRev908() {
        return rev908;
    }

    public Integer getRevolvingAvailablePercent() {
        return revolvingAvailablePercent;
    }

    public Integer getRevolvingBalance() {
        return revolvingBalance;
    }

    public Integer getRti026() {
        return rti026;
    }

    public Integer getRtl001() {
        return rtl001;
    }

    public Integer getRtl002() {
        return rtl002;
    }

    public Integer getRtl005() {
        return rtl005;
    }

    public Integer getRtl026() {
        return rtl026;
    }

    public Integer getRtl071() {
        return rtl071;
    }

    public Integer getRtl074() {
        return rtl074;
    }

    public Integer getRtl075() {
        return rtl075;
    }

    public Integer getRtl076() {
        return rtl076;
    }

    public Integer getRtl077() {
        return rtl077;
    }

    public Integer getRtl078() {
        return rtl078;
    }

    public Integer getRtl080() {
        return rtl080;
    }

    public Integer getRtl081() {
        return rtl081;
    }

    public Integer getRtl084() {
        return rtl084;
    }

    public Integer getRtl501() {
        return rtl501;
    }

    public Integer getRtl502() {
        return rtl502;
    }

    public Integer getRtl503() {
        return rtl503;
    }

    public Integer getRtl901() {
        return rtl901;
    }

    public Integer getRtl903() {
        return rtl903;
    }

    public Integer getRtl904() {
        return rtl904;
    }

    public Integer getRtl905() {
        return rtl905;
    }

    public Integer getRtl906() {
        return rtl906;
    }

    public Integer getRtl908() {
        return rtl908;
    }

    public Integer getRtr001() {
        return rtr001;
    }

    public Integer getRtr002() {
        return rtr002;
    }

    public Integer getRtr005() {
        return rtr005;
    }

    public Integer getRtr007() {
        return rtr007;
    }

    public Integer getRtr022() {
        return rtr022;
    }

    public Integer getRtr023() {
        return rtr023;
    }

    public Integer getRtr026() {
        return rtr026;
    }

    public Integer getRtr028() {
        return rtr028;
    }

    public Integer getRtr031() {
        return rtr031;
    }

    public Integer getRtr035() {
        return rtr035;
    }

    public Integer getRtr044() {
        return rtr044;
    }

    public Integer getRtr071() {
        return rtr071;
    }

    public Integer getRtr074() {
        return rtr074;
    }

    public Integer getRtr075() {
        return rtr075;
    }

    public Integer getRtr076() {
        return rtr076;
    }

    public Integer getRtr077() {
        return rtr077;
    }

    public Integer getRtr078() {
        return rtr078;
    }

    public Integer getRtr080() {
        return rtr080;
    }

    public Integer getRtr081() {
        return rtr081;
    }

    public Integer getRtr084() {
        return rtr084;
    }

    public Integer getRtr159() {
        return rtr159;
    }

    public Integer getRtr303() {
        return rtr303;
    }

    public Integer getRtr401() {
        return rtr401;
    }

    public Integer getRtr403() {
        return rtr403;
    }

    public Integer getRtr501() {
        return rtr501;
    }

    public Integer getRtr584() {
        return rtr584;
    }

    public Integer getRtr585() {
        return rtr585;
    }

    public Integer getRtr589() {
        return rtr589;
    }

    public Integer getRtr590() {
        return rtr590;
    }

    public Integer getRtr601() {
        return rtr601;
    }

    public Integer getRtr751() {
        return rtr751;
    }

    public Integer getRtr752() {
        return rtr752;
    }

    public Integer getRtr901() {
        return rtr901;
    }

    public Integer getRtr903() {
        return rtr903;
    }

    public Integer getRtr904() {
        return rtr904;
    }

    public Integer getRtr905() {
        return rtr905;
    }

    public Integer getRtr906() {
        return rtr906;
    }

    public Integer getRtr908() {
        return rtr908;
    }

    public Integer getSatisfactoryAccounts() {
        return satisfactoryAccounts;
    }

    public String getScorex() {
        return scorex;
    }

    public String getScorexChange() {
        return scorexChange;
    }

    public Double getStatedMonthlyIncome() {
        return statedMonthlyIncome;
    }

    public Integer getTotalInquiries() {
        return totalInquiries;
    }

    public Integer getTotalOpenRevolvingAccounts() {
        return totalOpenRevolvingAccounts;
    }

    public Integer getTotalTradeItems() {
        return totalTradeItems;
    }

    public Integer getVerificationStage() {
        return verificationStage;
    }

    public Integer getWasDelinquentDerog() {
        return wasDelinquentDerog;
    }
    
    public String getWholeLoanStartDate() {
        return wholeLoanStartDate;
    }

    public void setAle001(final Integer ale001) {
        this.ale001 = ale001;
    }

    public void setAle002(final Integer ale002) {
        this.ale002 = ale002;
    }

    public void setAle005(final Integer ale005) {
        this.ale005 = ale005;
    }

    public void setAle007(final Integer ale007) {
        this.ale007 = ale007;
    }

    public void setAle022(final Integer ale022) {
        this.ale022 = ale022;
    }

    public void setAle023(final Integer ale023) {
        this.ale023 = ale023;
    }

    public void setAle026(final Integer ale026) {
        this.ale026 = ale026;
    }

    public void setAle071(final Integer ale071) {
        this.ale071 = ale071;
    }

    public void setAle074(final Integer ale074) {
        this.ale074 = ale074;
    }

    public void setAle075(final Integer ale075) {
        this.ale075 = ale075;
    }

    public void setAle076(final Integer ale076) {
        this.ale076 = ale076;
    }

    public void setAle077(final Integer ale077) {
        this.ale077 = ale077;
    }

    public void setAle078(final Integer ale078) {
        this.ale078 = ale078;
    }

    public void setAle080(final Integer ale080) {
        this.ale080 = ale080;
    }

    public void setAle081(final Integer ale081) {
        this.ale081 = ale081;
    }

    public void setAle084(final Integer ale084) {
        this.ale084 = ale084;
    }

    public void setAle403(final Integer ale403) {
        this.ale403 = ale403;
    }

    public void setAle501(final Integer ale501) {
        this.ale501 = ale501;
    }

    public void setAle502(final Integer ale502) {
        this.ale502 = ale502;
    }

    public void setAle503(final Integer ale503) {
        this.ale503 = ale503;
    }

    public void setAle601(final Integer ale601) {
        this.ale601 = ale601;
    }

    public void setAle720(final Integer ale720) {
        this.ale720 = ale720;
    }

    public void setAle724(final Integer ale724) {
        this.ale724 = ale724;
    }

    public void setAle740(final Integer ale740) {
        this.ale740 = ale740;
    }

    public void setAle801(final Integer ale801) {
        this.ale801 = ale801;
    }

    public void setAle804(final Integer ale804) {
        this.ale804 = ale804;
    }

    public void setAle901(final Integer ale901) {
        this.ale901 = ale901;
    }

    public void setAle903(final Integer ale903) {
        this.ale903 = ale903;
    }

    public void setAle904(final Integer ale904) {
        this.ale904 = ale904;
    }

    public void setAle905(final Integer ale905) {
        this.ale905 = ale905;
    }

    public void setAle906(final Integer ale906) {
        this.ale906 = ale906;
    }

    public void setAle908(final Integer ale908) {
        this.ale908 = ale908;
    }

    public void setAll001(final Integer all001) {
        this.all001 = all001;
    }

    public void setAll002(final Integer all002) {
        this.all002 = all002;
    }

    public void setAll003(final Integer all003) {
        this.all003 = all003;
    }

    public void setAll005(final Integer all005) {
        this.all005 = all005;
    }

    public void setAll006(final Integer all006) {
        this.all006 = all006;
    }

    public void setAll007(final Integer all007) {
        this.all007 = all007;
    }

    public void setAll010(final Integer all010) {
        this.all010 = all010;
    }

    public void setAll021(final Integer all021) {
        this.all021 = all021;
    }

    public void setAll022(final Integer all022) {
        this.all022 = all022;
    }

    public void setAll023(final Integer all023) {
        this.all023 = all023;
    }

    public void setAll024(final Integer all024) {
        this.all024 = all024;
    }

    public void setAll026(final Integer all026) {
        this.all026 = all026;
    }

    public void setAll051(final Integer all051) {
        this.all051 = all051;
    }

    public void setAll052(final Integer all052) {
        this.all052 = all052;
    }

    public void setAll062(final Integer all062) {
        this.all062 = all062;
    }

    public void setAll064(final Integer all064) {
        this.all064 = all064;
    }

    public void setAll067(final Integer all067) {
        this.all067 = all067;
    }

    public void setAll071(final Integer all071) {
        this.all071 = all071;
    }

    public void setAll074(final Integer all074) {
        this.all074 = all074;
    }

    public void setAll075(final Integer all075) {
        this.all075 = all075;
    }

    public void setAll076(final Integer all076) {
        this.all076 = all076;
    }

    public void setAll077(final Integer all077) {
        this.all077 = all077;
    }

    public void setAll078(final Integer all078) {
        this.all078 = all078;
    }

    public void setAll080(final Integer all080) {
        this.all080 = all080;
    }

    public void setAll081(final Integer all081) {
        this.all081 = all081;
    }

    public void setAll082(final Integer all082) {
        this.all082 = all082;
    }

    public void setAll084(final Integer all084) {
        this.all084 = all084;
    }

    public void setAll085(final Integer all085) {
        this.all085 = all085;
    }

    public void setAll086(final Integer all086) {
        this.all086 = all086;
    }

    public void setAll090(final Integer all090) {
        this.all090 = all090;
    }

    public void setAll091(final Integer all091) {
        this.all091 = all091;
    }

    public void setAll092(final Integer all092) {
        this.all092 = all092;
    }

    public void setAll101(final Integer all101) {
        this.all101 = all101;
    }

    public void setAll102(final Integer all102) {
        this.all102 = all102;
    }

    public void setAll103(final Integer all103) {
        this.all103 = all103;
    }

    public void setAll104(final Integer all104) {
        this.all104 = all104;
    }

    public void setAll105(final Integer all105) {
        this.all105 = all105;
    }

    public void setAll106(final Integer all106) {
        this.all106 = all106;
    }

    public void setAll107(final Integer all107) {
        this.all107 = all107;
    }

    public void setAll108(final Integer all108) {
        this.all108 = all108;
    }

    public void setAll109(final Integer all109) {
        this.all109 = all109;
    }

    public void setAll110(final Integer all110) {
        this.all110 = all110;
    }

    public void setAll111(final Integer all111) {
        this.all111 = all111;
    }

    public void setAll112(final Integer all112) {
        this.all112 = all112;
    }

    public void setAll113(final Integer all113) {
        this.all113 = all113;
    }

    public void setAll114(final Integer all114) {
        this.all114 = all114;
    }

    public void setAll115(final Integer all115) {
        this.all115 = all115;
    }

    public void setAll116(final Integer all116) {
        this.all116 = all116;
    }

    public void setAll117(final Integer all117) {
        this.all117 = all117;
    }

    public void setAll118(final Integer all118) {
        this.all118 = all118;
    }

    public void setAll119(final Integer all119) {
        this.all119 = all119;
    }

    public void setAll121(final Integer all121) {
        this.all121 = all121;
    }

    public void setAll122(final Integer all122) {
        this.all122 = all122;
    }

    public void setAll123(final Integer all123) {
        this.all123 = all123;
    }

    public void setAll124(final Integer all124) {
        this.all124 = all124;
    }

    public void setAll125(final Integer all125) {
        this.all125 = all125;
    }

    public void setAll126(final Integer all126) {
        this.all126 = all126;
    }

    public void setAll127(final Integer all127) {
        this.all127 = all127;
    }

    public void setAll128(final Integer all128) {
        this.all128 = all128;
    }

    public void setAll129(final Integer all129) {
        this.all129 = all129;
    }

    public void setAll130(final Integer all130) {
        this.all130 = all130;
    }

    public void setAll131(final Integer all131) {
        this.all131 = all131;
    }

    public void setAll134(final Integer all134) {
        this.all134 = all134;
    }

    public void setAll136(final Integer all136) {
        this.all136 = all136;
    }

    public void setAll141(final Integer all141) {
        this.all141 = all141;
    }

    public void setAll142(final Integer all142) {
        this.all142 = all142;
    }

    public void setAll143(final Integer all143) {
        this.all143 = all143;
    }

    public void setAll144(final Integer all144) {
        this.all144 = all144;
    }

    public void setAll145(final Integer all145) {
        this.all145 = all145;
    }

    public void setAll146(final Integer all146) {
        this.all146 = all146;
    }

    public void setAll151(final Integer all151) {
        this.all151 = all151;
    }

    public void setAll152(final Integer all152) {
        this.all152 = all152;
    }

    public void setAll153(final Integer all153) {
        this.all153 = all153;
    }

    public void setAll155(final Integer all155) {
        this.all155 = all155;
    }

    public void setAll156(final Integer all156) {
        this.all156 = all156;
    }

    public void setAll201(final Integer all201) {
        this.all201 = all201;
    }

    public void setAll202(final Integer all202) {
        this.all202 = all202;
    }

    public void setAll207(final Integer all207) {
        this.all207 = all207;
    }

    public void setAll208(final Integer all208) {
        this.all208 = all208;
    }

    public void setAll301(final Integer all301) {
        this.all301 = all301;
    }

    public void setAll403(final Integer all403) {
        this.all403 = all403;
    }

    public void setAll501(final Integer all501) {
        this.all501 = all501;
    }

    public void setAll502(final Integer all502) {
        this.all502 = all502;
    }

    public void setAll503(final Integer all503) {
        this.all503 = all503;
    }

    public void setAll504(final Integer all504) {
        this.all504 = all504;
    }

    public void setAll505(final Integer all505) {
        this.all505 = all505;
    }

    public void setAll524(final Integer all524) {
        this.all524 = all524;
    }

    public void setAll601(final Integer all601) {
        this.all601 = all601;
    }

    public void setAll602(final Integer all602) {
        this.all602 = all602;
    }

    public void setAll701(final Integer all701) {
        this.all701 = all701;
    }

    public void setAll702(final Integer all702) {
        this.all702 = all702;
    }

    public void setAll703(final Integer all703) {
        this.all703 = all703;
    }

    public void setAll720(final Integer all720) {
        this.all720 = all720;
    }

    public void setAll724(final Integer all724) {
        this.all724 = all724;
    }

    public void setAll740(final Integer all740) {
        this.all740 = all740;
    }

    public void setAll760(final Integer all760) {
        this.all760 = all760;
    }

    public void setAll780(final Integer all780) {
        this.all780 = all780;
    }

    public void setAll790(final Integer all790) {
        this.all790 = all790;
    }

    public void setAll801(final Integer all801) {
        this.all801 = all801;
    }

    public void setAll803(final Integer all803) {
        this.all803 = all803;
    }

    public void setAll804(final Integer all804) {
        this.all804 = all804;
    }

    public void setAll805(final Integer all805) {
        this.all805 = all805;
    }

    public void setAll806(final Integer all806) {
        this.all806 = all806;
    }

    public void setAll807(final Integer all807) {
        this.all807 = all807;
    }

    public void setAll901(final Integer all901) {
        this.all901 = all901;
    }

    public void setAll903(final Integer all903) {
        this.all903 = all903;
    }

    public void setAll904(final Integer all904) {
        this.all904 = all904;
    }

    public void setAll905(final Integer all905) {
        this.all905 = all905;
    }

    public void setAll906(final Integer all906) {
        this.all906 = all906;
    }

    public void setAll907(final Integer all907) {
        this.all907 = all907;
    }

    public void setAmountDelinquent(final Integer amountDelinquent) {
        this.amountDelinquent = amountDelinquent;
    }

    public void setAmountFunded(final Double amountFunded) {
        this.amountFunded = amountFunded;
    }

    public void setAmountParticipation(final Double amountParticipation) {
        this.amountParticipation = amountParticipation;
    }

    public void setAmountRemaining(final Double amountRemaining) {
        this.amountRemaining = amountRemaining;
    }

    public void setAut001(final Integer aut001) {
        this.aut001 = aut001;
    }

    public void setAut071(final Integer aut071) {
        this.aut071 = aut071;
    }

    public void setAut720(final Integer aut720) {
        this.aut720 = aut720;
    }

    public void setBac001(final Integer bac001) {
        this.bac001 = bac001;
    }

    public void setBac002(final Integer bac002) {
        this.bac002 = bac002;
    }

    public void setBac005(final Integer bac005) {
        this.bac005 = bac005;
    }

    public void setBac007(final Integer bac007) {
        this.bac007 = bac007;
    }

    public void setBac022(final Integer bac022) {
        this.bac022 = bac022;
    }

    public void setBac023(final Integer bac023) {
        this.bac023 = bac023;
    }

    public void setBac026(final Integer bac026) {
        this.bac026 = bac026;
    }

    public void setBac028(final Integer bac028) {
        this.bac028 = bac028;
    }

    public void setBac031(final Integer bac031) {
        this.bac031 = bac031;
    }

    public void setBac035(final Integer bac035) {
        this.bac035 = bac035;
    }

    public void setBac037(final Integer bac037) {
        this.bac037 = bac037;
    }

    public void setBac042(final Integer bac042) {
        this.bac042 = bac042;
    }

    public void setBac044(final Integer bac044) {
        this.bac044 = bac044;
    }

    public void setBac045(final Integer bac045) {
        this.bac045 = bac045;
    }

    public void setBac071(final Integer bac071) {
        this.bac071 = bac071;
    }

    public void setBac074(final Integer bac074) {
        this.bac074 = bac074;
    }

    public void setBac075(final Integer bac075) {
        this.bac075 = bac075;
    }

    public void setBac076(final Integer bac076) {
        this.bac076 = bac076;
    }

    public void setBac077(final Integer bac077) {
        this.bac077 = bac077;
    }

    public void setBac078(final Integer bac078) {
        this.bac078 = bac078;
    }

    public void setBac080(final Integer bac080) {
        this.bac080 = bac080;
    }

    public void setBac081(final Integer bac081) {
        this.bac081 = bac081;
    }

    public void setBac084(final Integer bac084) {
        this.bac084 = bac084;
    }

    public void setBac159(final Integer bac159) {
        this.bac159 = bac159;
    }

    public void setBac302(final Integer bac302) {
        this.bac302 = bac302;
    }

    public void setBac303(final Integer bac303) {
        this.bac303 = bac303;
    }

    public void setBac401(final Integer bac401) {
        this.bac401 = bac401;
    }

    public void setBac403(final Integer bac403) {
        this.bac403 = bac403;
    }

    public void setBac501(final Integer bac501) {
        this.bac501 = bac501;
    }

    public void setBac502(final Integer bac502) {
        this.bac502 = bac502;
    }

    public void setBac503(final Integer bac503) {
        this.bac503 = bac503;
    }

    public void setBac550(final Integer bac550) {
        this.bac550 = bac550;
    }

    public void setBac584(final Integer bac584) {
        this.bac584 = bac584;
    }

    public void setBac589(final Integer bac589) {
        this.bac589 = bac589;
    }

    public void setBac601(final Integer bac601) {
        this.bac601 = bac601;
    }

    public void setBac751(final Integer bac751) {
        this.bac751 = bac751;
    }

    public void setBac752(final Integer bac752) {
        this.bac752 = bac752;
    }

    public void setBac801(final Integer bac801) {
        this.bac801 = bac801;
    }

    public void setBac804(final Integer bac804) {
        this.bac804 = bac804;
    }

    public void setBac901(final Integer bac901) {
        this.bac901 = bac901;
    }

    public void setBac903(final Integer bac903) {
        this.bac903 = bac903;
    }

    public void setBac904(final Integer bac904) {
        this.bac904 = bac904;
    }

    public void setBac905(final Integer bac905) {
        this.bac905 = bac905;
    }

    public void setBac906(final Integer bac906) {
        this.bac906 = bac906;
    }

    public void setBac908(final Integer bac908) {
        this.bac908 = bac908;
    }

    public void setBankcardUtilization(final Integer bankcardUtilization) {
        this.bankcardUtilization = bankcardUtilization;
    }

    public void setBnk001(final Integer bnk001) {
        this.bnk001 = bnk001;
    }

    public void setBnk026(final Integer bnk026) {
        this.bnk026 = bnk026;
    }

    public void setBorrowerapr(final Double borrowerapr) {
        this.borrowerapr = borrowerapr;
    }

    public void setBorrowerApr(final Double borrowerApr) {
        this.borrowerApr = borrowerApr;
    }

    public void setBorrowerCity(final String borrowerCity) {
        this.borrowerCity = borrowerCity;
    }

    public void setBorrowerListingDescription(final String borrowerListingDescription) {
        this.borrowerListingDescription = borrowerListingDescription;
    }

    public void setBorrowerMetropolitanArea(final String borrowerMetropolitanArea) {
        this.borrowerMetropolitanArea = borrowerMetropolitanArea;
    }

    public void setBorrowerRate(final Double borrowerRate) {
        this.borrowerRate = borrowerRate;
    }

    public void setBorrowerState(final String borrowerState) {
        this.borrowerState = borrowerState;
    }

    public void setBrr026(final Integer brr026) {
        this.brr026 = brr026;
    }

    public void setCap026(final Integer cap026) {
        this.cap026 = cap026;
    }

    public void setCap801(final Integer cap801) {
        this.cap801 = cap801;
    }

    public void setChannelCode(final String channelCode) {
        this.channelCode = channelCode;
    }

    public void setCreditLinesLast7Years(final Integer creditLinesLast7Years) {
        this.creditLinesLast7Years = creditLinesLast7Years;
    }

    public void setCreditPullDate(final String creditPullDate) {
        this.creditPullDate = creditPullDate;
    }

    public void setCru001(final Integer cru001) {
        this.cru001 = cru001;
    }

    public void setCurrentCreditLines(final Integer currentCreditLines) {
        this.currentCreditLines = currentCreditLines;
    }

    public void setCurrentDelinquencies(final Integer currentDelinquencies) {
        this.currentDelinquencies = currentDelinquencies;
    }

    public void setDelinquenciesLast7Years(final Integer delinquenciesLast7Years) {
        this.delinquenciesLast7Years = delinquenciesLast7Years;
    }

    public void setDelinquenciesOver30Days(final Integer delinquenciesOver30Days) {
        this.delinquenciesOver30Days = delinquenciesOver30Days;
    }

    public void setDelinquenciesOver60Days(final Integer delinquenciesOver60Days) {
        this.delinquenciesOver60Days = delinquenciesOver60Days;
    }

    public void setDelinquenciesOver90Days(final Integer delinquenciesOver90Days) {
        this.delinquenciesOver90Days = delinquenciesOver90Days;
    }

    public void setDtIwprosperLoan(final Integer dtIwprosperLoan) {
        this.dtIwprosperLoan = dtIwprosperLoan;
    }

    public void setEffectiveYield(final Double effectiveYield) {
        this.effectiveYield = effectiveYield;
    }

    public void setEmploymentStatusDescription(final String employmentStatusDescription) {
        this.employmentStatusDescription = employmentStatusDescription;
    }

    public void setEstimatedLossRate(final Double estimatedLossRate) {
        this.estimatedLossRate = estimatedLossRate;
    }

    public void setEstimatedReturn(final Double estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public void setFicoScore(final String ficoScore) {
        this.ficoScore = ficoScore;
    }

    public void setFil001(final Integer fil001) {
        this.fil001 = fil001;
    }

    public void setFil022(final Integer fil022) {
        this.fil022 = fil022;
    }

    public void setFil023(final Integer fil023) {
        this.fil023 = fil023;
    }

    public void setFin001(final Integer fin001) {
        this.fin001 = fin001;
    }

    public void setFin026(final Integer fin026) {
        this.fin026 = fin026;
    }

    public void setFin601(final Integer fin601) {
        this.fin601 = fin601;
    }

    public void setFin801(final Integer fin801) {
        this.fin801 = fin801;
    }

    public void setFirstRecordedCreditLine(final String firstRecordedCreditLine) {
        this.firstRecordedCreditLine = firstRecordedCreditLine;
    }

    public void setFundingThreshold(final Double fundingThreshold) {
        this.fundingThreshold = fundingThreshold;
    }

    public void setGbl007(final Integer gbl007) {
        this.gbl007 = gbl007;
    }

    public void setGroupIndicator(final Boolean groupIndicator) {
        this.groupIndicator = groupIndicator;
    }

    public void setGroupName(final String groupName) {
        this.groupName = groupName;
    }

    public void setHeq001(final Integer heq001) {
        this.heq001 = heq001;
    }

    public void setIln001(final Integer iln001) {
        this.iln001 = iln001;
    }

    public void setIln002(final Integer iln002) {
        this.iln002 = iln002;
    }

    public void setIln005(final Integer iln005) {
        this.iln005 = iln005;
    }

    public void setIln006(final Integer iln006) {
        this.iln006 = iln006;
    }

    public void setIln007(final Integer iln007) {
        this.iln007 = iln007;
    }

    public void setIln022(final Integer iln022) {
        this.iln022 = iln022;
    }

    public void setIln023(final Integer iln023) {
        this.iln023 = iln023;
    }

    public void setIln026(final Integer iln026) {
        this.iln026 = iln026;
    }

    public void setIln064(final Integer iln064) {
        this.iln064 = iln064;
    }

    public void setIln067(final Integer iln067) {
        this.iln067 = iln067;
    }

    public void setIln071(final Integer iln071) {
        this.iln071 = iln071;
    }

    public void setIln074(final Integer iln074) {
        this.iln074 = iln074;
    }

    public void setIln075(final Integer iln075) {
        this.iln075 = iln075;
    }

    public void setIln076(final Integer iln076) {
        this.iln076 = iln076;
    }

    public void setIln077(final Integer iln077) {
        this.iln077 = iln077;
    }

    public void setIln078(final Integer iln078) {
        this.iln078 = iln078;
    }

    public void setIln080(final Integer iln080) {
        this.iln080 = iln080;
    }

    public void setIln081(final Integer iln081) {
        this.iln081 = iln081;
    }

    public void setIln084(final Integer iln084) {
        this.iln084 = iln084;
    }

    public void setIln085(final Integer iln085) {
        this.iln085 = iln085;
    }

    public void setIln086(final Integer iln086) {
        this.iln086 = iln086;
    }

    public void setIln101(final Integer iln101) {
        this.iln101 = iln101;
    }

    public void setIln102(final Integer iln102) {
        this.iln102 = iln102;
    }

    public void setIln103(final Integer iln103) {
        this.iln103 = iln103;
    }

    public void setIln104(final Integer iln104) {
        this.iln104 = iln104;
    }

    public void setIln105(final Integer iln105) {
        this.iln105 = iln105;
    }

    public void setIln106(final Integer iln106) {
        this.iln106 = iln106;
    }

    public void setIln107(final Integer iln107) {
        this.iln107 = iln107;
    }

    public void setIln108(final Integer iln108) {
        this.iln108 = iln108;
    }

    public void setIln109(final Integer iln109) {
        this.iln109 = iln109;
    }

    public void setIln110(final Integer iln110) {
        this.iln110 = iln110;
    }

    public void setIln111(final Integer iln111) {
        this.iln111 = iln111;
    }

    public void setIln112(final Integer iln112) {
        this.iln112 = iln112;
    }

    public void setIln113(final Integer iln113) {
        this.iln113 = iln113;
    }

    public void setIln114(final Integer iln114) {
        this.iln114 = iln114;
    }

    public void setIln115(final Integer iln115) {
        this.iln115 = iln115;
    }

    public void setIln116(final Integer iln116) {
        this.iln116 = iln116;
    }

    public void setIln117(final Integer iln117) {
        this.iln117 = iln117;
    }

    public void setIln118(final Integer iln118) {
        this.iln118 = iln118;
    }

    public void setIln119(final Integer iln119) {
        this.iln119 = iln119;
    }

    public void setIln122(final Integer iln122) {
        this.iln122 = iln122;
    }

    public void setIln124(final Integer iln124) {
        this.iln124 = iln124;
    }

    public void setIln125(final Integer iln125) {
        this.iln125 = iln125;
    }

    public void setIln126(final Integer iln126) {
        this.iln126 = iln126;
    }

    public void setIln127(final Integer iln127) {
        this.iln127 = iln127;
    }

    public void setIln128(final Integer iln128) {
        this.iln128 = iln128;
    }

    public void setIln129(final Integer iln129) {
        this.iln129 = iln129;
    }

    public void setIln130(final Integer iln130) {
        this.iln130 = iln130;
    }

    public void setIln201(final Integer iln201) {
        this.iln201 = iln201;
    }

    public void setIln301(final Integer iln301) {
        this.iln301 = iln301;
    }

    public void setIln302(final Integer iln302) {
        this.iln302 = iln302;
    }

    public void setIln403(final Integer iln403) {
        this.iln403 = iln403;
    }

    public void setIln501(final Integer iln501) {
        this.iln501 = iln501;
    }

    public void setIln502(final Integer iln502) {
        this.iln502 = iln502;
    }

    public void setIln503(final Integer iln503) {
        this.iln503 = iln503;
    }

    public void setIln504(final Integer iln504) {
        this.iln504 = iln504;
    }

    public void setIln601(final Integer iln601) {
        this.iln601 = iln601;
    }

    public void setIln701(final Integer iln701) {
        this.iln701 = iln701;
    }

    public void setIln702(final Integer iln702) {
        this.iln702 = iln702;
    }

    public void setIln703(final Integer iln703) {
        this.iln703 = iln703;
    }

    public void setIln720(final Integer iln720) {
        this.iln720 = iln720;
    }

    public void setIln724(final Integer iln724) {
        this.iln724 = iln724;
    }

    public void setIln740(final Integer iln740) {
        this.iln740 = iln740;
    }

    public void setIln801(final Integer iln801) {
        this.iln801 = iln801;
    }

    public void setIln804(final Integer iln804) {
        this.iln804 = iln804;
    }

    public void setIln901(final Integer iln901) {
        this.iln901 = iln901;
    }

    public void setIln903(final Integer iln903) {
        this.iln903 = iln903;
    }

    public void setIln904(final Integer iln904) {
        this.iln904 = iln904;
    }

    public void setIln905(final Integer iln905) {
        this.iln905 = iln905;
    }

    public void setIln906(final Integer iln906) {
        this.iln906 = iln906;
    }

    public void setIln908(final Integer iln908) {
        this.iln908 = iln908;
    }

    public void setIln914(final Integer iln914) {
        this.iln914 = iln914;
    }

    public void setIncomeRange(final Double incomeRange) {
        this.incomeRange = incomeRange;
    }

    public void setIncomeRangedescription(final String incomeRangedescription) {
        this.incomeRangedescription = incomeRangedescription;
    }

    public void setIncomeVerifiable(final Boolean incomeVerifiable) {
        this.incomeVerifiable = incomeVerifiable;
    }

    public void setInquiriesLast6Months(final Integer inquiriesLast6Months) {
        this.inquiriesLast6Months = inquiriesLast6Months;
    }

    public void setInstallmentBalance(final Integer installmentBalance) {
        this.installmentBalance = installmentBalance;
    }

    public void setInvestmentTypeDescription(final String investmentTypeDescription) {
        this.investmentTypeDescription = investmentTypeDescription;
    }

    public void setInvestmentTypeid(final Integer investmentTypeid) {
        this.investmentTypeid = investmentTypeid;
    }

    public void setIsHomeowner(final Boolean isHomeowner) {
        this.isHomeowner = isHomeowner;
    }

    public void setLastUpdatedDate(final String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public void setLenderIndicator(final Integer lenderIndicator) {
        this.lenderIndicator = lenderIndicator;
    }

    public void setLenderYield(final Double lenderYield) {
        this.lenderYield = lenderYield;
    }

    public void setLfi801(final Integer lfi801) {
        this.lfi801 = lfi801;
    }

    public void setListingAmount(final Double listingAmount) {
        this.listingAmount = listingAmount;
    }

    public void setListingCategoryId(final Integer listingCategoryId) {
        this.listingCategoryId = listingCategoryId;
    }

    public void setListingCreationDate(final String listingCreationDate) {
        this.listingCreationDate = listingCreationDate;
    }

    public void setListingEndDate(final String listingEndDate) {
        this.listingEndDate = listingEndDate;
    }

    public void setListingMonthlyPayment(final Double listingMonthlyPayment) {
        this.listingMonthlyPayment = listingMonthlyPayment;
    }

    public void setListingNumber(final Integer listingNumber) {
        this.listingNumber = listingNumber;
    }

    public void setListingPurpose(final String listingPurpose) {
        this.listingPurpose = listingPurpose;
    }

    public void setListingStartDate(final String listingStartDate) {
        this.listingStartDate = listingStartDate;
    }

    public void setListingStatus(final Integer listingStatus) {
        this.listingStatus = listingStatus;
    }

    public void setListingStatusReason(final String listingStatusReason) {
        this.listingStatusReason = listingStatusReason;
    }

    public void setListingTerm(final Integer listingTerm) {
        this.listingTerm = listingTerm;
    }

    public void setListingTitle(final String listingTitle) {
        this.listingTitle = listingTitle;
    }

    public void setLoanOriginationDate(final String loanOriginationDate) {
        this.loanOriginationDate = loanOriginationDate;
    }

    public void setMaxPriorProsperLoan(final Double maxPriorProsperLoan) {
        this.maxPriorProsperLoan = maxPriorProsperLoan;
    }

    public void setMemberKey(final String memberKey) {
        this.memberKey = memberKey;
    }

    public void setMinPriorProsperLoan(final Double minPriorProsperLoan) {
        this.minPriorProsperLoan = minPriorProsperLoan;
    }

    public void setMonthlyDebt(final Integer monthlyDebt) {
        this.monthlyDebt = monthlyDebt;
    }

    public void setMonthsEmployed(final Integer monthsEmployed) {
        this.monthsEmployed = monthsEmployed;
    }

    public void setNowDelinquentDerog(final Integer nowDelinquentDerog) {
        this.nowDelinquentDerog = nowDelinquentDerog;
    }

    public void setOccupation(final String occupation) {
        this.occupation = occupation;
    }

    public void setOldestTradeOpenDate(final String oldestTradeOpenDate) {
        this.oldestTradeOpenDate = oldestTradeOpenDate;
    }

    public void setOpenCreditLines(final Integer openCreditLines) {
        this.openCreditLines = openCreditLines;
    }

    public void setPartialFundingIndicator(final Boolean partialFundingIndicator) {
        this.partialFundingIndicator = partialFundingIndicator;
    }

    public void setPercentFunded(final Double percentFunded) {
        this.percentFunded = percentFunded;
    }

    public void setPriorProsperLoanEarliestPayOff(final Integer priorProsperLoanEarliestPayOff) {
        this.priorProsperLoanEarliestPayOff = priorProsperLoanEarliestPayOff;
    }

    public void setPriorProsperLoans(final Integer priorProsperLoans) {
        this.priorProsperLoans = priorProsperLoans;
    }

    public void setPriorProsperLoans31dpd(final Integer priorProsperLoans31dpd) {
        this.priorProsperLoans31dpd = priorProsperLoans31dpd;
    }

    public void setPriorProsperLoans61dpd(final Integer priorProsperLoans61dpd) {
        this.priorProsperLoans61dpd = priorProsperLoans61dpd;
    }

    public void setPriorProsperLoansActive(final Integer priorProsperLoansActive) {
        this.priorProsperLoansActive = priorProsperLoansActive;
    }

    public void setPriorProsperLoansBalanceOutstanding(final Double priorProsperLoansBalanceOutstanding) {
        this.priorProsperLoansBalanceOutstanding = priorProsperLoansBalanceOutstanding;
    }

    public void setPriorProsperLoansCyclesBilled(final Integer priorProsperLoansCyclesBilled) {
        this.priorProsperLoansCyclesBilled = priorProsperLoansCyclesBilled;
    }

    public void setPriorProsperLoansLateCycles(final Integer priorProsperLoansLateCycles) {
        this.priorProsperLoansLateCycles = priorProsperLoansLateCycles;
    }

    public void setPriorProsperLoansLatePaymentsOneMonthPlus(final Integer priorProsperLoansLatePaymentsOneMonthPlus) {
        this.priorProsperLoansLatePaymentsOneMonthPlus = priorProsperLoansLatePaymentsOneMonthPlus;
    }

    public void setPriorProsperLoansOntimePayments(final Integer priorProsperLoansOntimePayments) {
        this.priorProsperLoansOntimePayments = priorProsperLoansOntimePayments;
    }

    public void setPriorProsperLoansPrincipalBorrowed(final Double priorProsperLoansPrincipalBorrowed) {
        this.priorProsperLoansPrincipalBorrowed = priorProsperLoansPrincipalBorrowed;
    }

    public void setPriorProsperLoansPrincipalOutstanding(final Double priorProsperLoansPrincipalOutstanding) {
        this.priorProsperLoansPrincipalOutstanding = priorProsperLoansPrincipalOutstanding;
    }

    public void setProsperRating(final String prosperRating) {
        this.prosperRating = prosperRating;
    }

    public void setProsperScore(final Integer prosperScore) {
        this.prosperScore = prosperScore;
    }

    public void setPublicRecordsLast10Years(final Integer publicRecordsLast10Years) {
        this.publicRecordsLast10Years = publicRecordsLast10Years;
    }

    public void setPublicRecordsLast12Months(final Integer publicRecordsLast12Months) {
        this.publicRecordsLast12Months = publicRecordsLast12Months;
    }

    public void setRealEstateBalance(final Integer realEstateBalance) {
        this.realEstateBalance = realEstateBalance;
    }

    public void setRealEstatePayment(final Integer realEstatePayment) {
        this.realEstatePayment = realEstatePayment;
    }

    public void setRef001(final Integer ref001) {
        this.ref001 = ref001;
    }

    public void setRep001(final Integer rep001) {
        this.rep001 = rep001;
    }

    public void setRep002(final Integer rep002) {
        this.rep002 = rep002;
    }

    public void setRep005(final Integer rep005) {
        this.rep005 = rep005;
    }

    public void setRep026(final Integer rep026) {
        this.rep026 = rep026;
    }

    public void setRep071(final Integer rep071) {
        this.rep071 = rep071;
    }

    public void setRep074(final Integer rep074) {
        this.rep074 = rep074;
    }

    public void setRep075(final Integer rep075) {
        this.rep075 = rep075;
    }

    public void setRep076(final Integer rep076) {
        this.rep076 = rep076;
    }

    public void setRep077(final Integer rep077) {
        this.rep077 = rep077;
    }

    public void setRep078(final Integer rep078) {
        this.rep078 = rep078;
    }

    public void setRep080(final Integer rep080) {
        this.rep080 = rep080;
    }

    public void setRep081(final Integer rep081) {
        this.rep081 = rep081;
    }

    public void setRep084(final Integer rep084) {
        this.rep084 = rep084;
    }

    public void setRep302(final Integer rep302) {
        this.rep302 = rep302;
    }

    public void setRep501(final Integer rep501) {
        this.rep501 = rep501;
    }

    public void setRep503(final Integer rep503) {
        this.rep503 = rep503;
    }

    public void setRep601(final Integer rep601) {
        this.rep601 = rep601;
    }

    public void setRep901(final Integer rep901) {
        this.rep901 = rep901;
    }

    public void setRep903(final Integer rep903) {
        this.rep903 = rep903;
    }

    public void setRep904(final Integer rep904) {
        this.rep904 = rep904;
    }

    public void setRep905(final Integer rep905) {
        this.rep905 = rep905;
    }

    public void setRep906(final Integer rep906) {
        this.rep906 = rep906;
    }

    public void setRep908(final Integer rep908) {
        this.rep908 = rep908;
    }

    public void setRev001(final Integer rev001) {
        this.rev001 = rev001;
    }

    public void setRev002(final Integer rev002) {
        this.rev002 = rev002;
    }

    public void setRev005(final Integer rev005) {
        this.rev005 = rev005;
    }

    public void setRev006(final Integer rev006) {
        this.rev006 = rev006;
    }

    public void setRev007(final Integer rev007) {
        this.rev007 = rev007;
    }

    public void setRev022(final Integer rev022) {
        this.rev022 = rev022;
    }

    public void setRev023(final Integer rev023) {
        this.rev023 = rev023;
    }

    public void setRev024(final Integer rev024) {
        this.rev024 = rev024;
    }

    public void setRev026(final Integer rev026) {
        this.rev026 = rev026;
    }

    public void setRev028(final Integer rev028) {
        this.rev028 = rev028;
    }

    public void setRev038(final Integer rev038) {
        this.rev038 = rev038;
    }

    public void setRev044(final Integer rev044) {
        this.rev044 = rev044;
    }

    public void setRev064(final Integer rev064) {
        this.rev064 = rev064;
    }

    public void setRev067(final Integer rev067) {
        this.rev067 = rev067;
    }

    public void setRev071(final Integer rev071) {
        this.rev071 = rev071;
    }

    public void setRev074(final Integer rev074) {
        this.rev074 = rev074;
    }

    public void setRev075(final Integer rev075) {
        this.rev075 = rev075;
    }

    public void setRev076(final Integer rev076) {
        this.rev076 = rev076;
    }

    public void setRev077(final Integer rev077) {
        this.rev077 = rev077;
    }

    public void setRev078(final Integer rev078) {
        this.rev078 = rev078;
    }

    public void setRev080(final Integer rev080) {
        this.rev080 = rev080;
    }

    public void setRev081(final Integer rev081) {
        this.rev081 = rev081;
    }

    public void setRev084(final Integer rev084) {
        this.rev084 = rev084;
    }

    public void setRev085(final Integer rev085) {
        this.rev085 = rev085;
    }

    public void setRev086(final Integer rev086) {
        this.rev086 = rev086;
    }

    public void setRev101(final Integer rev101) {
        this.rev101 = rev101;
    }

    public void setRev102(final Integer rev102) {
        this.rev102 = rev102;
    }

    public void setRev103(final Integer rev103) {
        this.rev103 = rev103;
    }

    public void setRev104(final Integer rev104) {
        this.rev104 = rev104;
    }

    public void setRev105(final Integer rev105) {
        this.rev105 = rev105;
    }

    public void setRev106(final Integer rev106) {
        this.rev106 = rev106;
    }

    public void setRev107(final Integer rev107) {
        this.rev107 = rev107;
    }

    public void setRev108(final Integer rev108) {
        this.rev108 = rev108;
    }

    public void setRev109(final Integer rev109) {
        this.rev109 = rev109;
    }

    public void setRev110(final Integer rev110) {
        this.rev110 = rev110;
    }

    public void setRev111(final Integer rev111) {
        this.rev111 = rev111;
    }

    public void setRev112(final Integer rev112) {
        this.rev112 = rev112;
    }

    public void setRev113(final Integer rev113) {
        this.rev113 = rev113;
    }

    public void setRev114(final Integer rev114) {
        this.rev114 = rev114;
    }

    public void setRev115(final Integer rev115) {
        this.rev115 = rev115;
    }

    public void setRev116(final Integer rev116) {
        this.rev116 = rev116;
    }

    public void setRev117(final Integer rev117) {
        this.rev117 = rev117;
    }

    public void setRev118(final Integer rev118) {
        this.rev118 = rev118;
    }

    public void setRev119(final Integer rev119) {
        this.rev119 = rev119;
    }

    public void setRev122(final Integer rev122) {
        this.rev122 = rev122;
    }

    public void setRev124(final Integer rev124) {
        this.rev124 = rev124;
    }

    public void setRev125(final Integer rev125) {
        this.rev125 = rev125;
    }

    public void setRev126(final Integer rev126) {
        this.rev126 = rev126;
    }

    public void setRev127(final Integer rev127) {
        this.rev127 = rev127;
    }

    public void setRev128(final Integer rev128) {
        this.rev128 = rev128;
    }

    public void setRev129(final Integer rev129) {
        this.rev129 = rev129;
    }

    public void setRev130(final Integer rev130) {
        this.rev130 = rev130;
    }

    public void setRev159(final Integer rev159) {
        this.rev159 = rev159;
    }

    public void setRev201(final Integer rev201) {
        this.rev201 = rev201;
    }

    public void setRev202(final Integer rev202) {
        this.rev202 = rev202;
    }

    public void setRev301(final Integer rev301) {
        this.rev301 = rev301;
    }

    public void setRev302(final Integer rev302) {
        this.rev302 = rev302;
    }

    public void setRev401(final Integer rev401) {
        this.rev401 = rev401;
    }

    public void setRev403(final Integer rev403) {
        this.rev403 = rev403;
    }

    public void setRev404(final Integer rev404) {
        this.rev404 = rev404;
    }

    public void setRev501(final Integer rev501) {
        this.rev501 = rev501;
    }

    public void setRev502(final Integer rev502) {
        this.rev502 = rev502;
    }

    public void setRev503(final Integer rev503) {
        this.rev503 = rev503;
    }

    public void setRev504(final Integer rev504) {
        this.rev504 = rev504;
    }

    public void setRev524(final Integer rev524) {
        this.rev524 = rev524;
    }

    public void setRev550(final Integer rev550) {
        this.rev550 = rev550;
    }

    public void setRev584(final Integer rev584) {
        this.rev584 = rev584;
    }

    public void setRev585(final Integer rev585) {
        this.rev585 = rev585;
    }

    public void setRev589(final Integer rev589) {
        this.rev589 = rev589;
    }

    public void setRev590(final Integer rev590) {
        this.rev590 = rev590;
    }

    public void setRev601(final Integer rev601) {
        this.rev601 = rev601;
    }

    public void setRev701(final Integer rev701) {
        this.rev701 = rev701;
    }

    public void setRev702(final Integer rev702) {
        this.rev702 = rev702;
    }

    public void setRev703(final Integer rev703) {
        this.rev703 = rev703;
    }

    public void setRev720(final Integer rev720) {
        this.rev720 = rev720;
    }

    public void setRev724(final Integer rev724) {
        this.rev724 = rev724;
    }

    public void setRev740(final Integer rev740) {
        this.rev740 = rev740;
    }

    public void setRev751(final Integer rev751) {
        this.rev751 = rev751;
    }

    public void setRev752(final Integer rev752) {
        this.rev752 = rev752;
    }

    public void setRev901(final Integer rev901) {
        this.rev901 = rev901;
    }

    public void setRev903(final Integer rev903) {
        this.rev903 = rev903;
    }

    public void setRev904(final Integer rev904) {
        this.rev904 = rev904;
    }

    public void setRev905(final Integer rev905) {
        this.rev905 = rev905;
    }

    public void setRev906(final Integer rev906) {
        this.rev906 = rev906;
    }

    public void setRev908(final Integer rev908) {
        this.rev908 = rev908;
    }

    public void setRevolvingAvailablePercent(final Integer revolvingAvailablePercent) {
        this.revolvingAvailablePercent = revolvingAvailablePercent;
    }

    public void setRevolvingBalance(final Integer revolvingBalance) {
        this.revolvingBalance = revolvingBalance;
    }

    public void setRti026(final Integer rti026) {
        this.rti026 = rti026;
    }

    public void setRtl001(final Integer rtl001) {
        this.rtl001 = rtl001;
    }

    public void setRtl002(final Integer rtl002) {
        this.rtl002 = rtl002;
    }

    public void setRtl005(final Integer rtl005) {
        this.rtl005 = rtl005;
    }

    public void setRtl026(final Integer rtl026) {
        this.rtl026 = rtl026;
    }

    public void setRtl071(final Integer rtl071) {
        this.rtl071 = rtl071;
    }

    public void setRtl074(final Integer rtl074) {
        this.rtl074 = rtl074;
    }

    public void setRtl075(final Integer rtl075) {
        this.rtl075 = rtl075;
    }

    public void setRtl076(final Integer rtl076) {
        this.rtl076 = rtl076;
    }

    public void setRtl077(final Integer rtl077) {
        this.rtl077 = rtl077;
    }

    public void setRtl078(final Integer rtl078) {
        this.rtl078 = rtl078;
    }

    public void setRtl080(final Integer rtl080) {
        this.rtl080 = rtl080;
    }

    public void setRtl081(final Integer rtl081) {
        this.rtl081 = rtl081;
    }

    public void setRtl084(final Integer rtl084) {
        this.rtl084 = rtl084;
    }

    public void setRtl501(final Integer rtl501) {
        this.rtl501 = rtl501;
    }

    public void setRtl502(final Integer rtl502) {
        this.rtl502 = rtl502;
    }

    public void setRtl503(final Integer rtl503) {
        this.rtl503 = rtl503;
    }

    public void setRtl901(final Integer rtl901) {
        this.rtl901 = rtl901;
    }

    public void setRtl903(final Integer rtl903) {
        this.rtl903 = rtl903;
    }

    public void setRtl904(final Integer rtl904) {
        this.rtl904 = rtl904;
    }

    public void setRtl905(final Integer rtl905) {
        this.rtl905 = rtl905;
    }

    public void setRtl906(final Integer rtl906) {
        this.rtl906 = rtl906;
    }

    public void setRtl908(final Integer rtl908) {
        this.rtl908 = rtl908;
    }

    public void setRtr001(final Integer rtr001) {
        this.rtr001 = rtr001;
    }

    public void setRtr002(final Integer rtr002) {
        this.rtr002 = rtr002;
    }

    public void setRtr005(final Integer rtr005) {
        this.rtr005 = rtr005;
    }

    public void setRtr007(final Integer rtr007) {
        this.rtr007 = rtr007;
    }

    public void setRtr022(final Integer rtr022) {
        this.rtr022 = rtr022;
    }

    public void setRtr023(final Integer rtr023) {
        this.rtr023 = rtr023;
    }

    public void setRtr026(final Integer rtr026) {
        this.rtr026 = rtr026;
    }

    public void setRtr028(final Integer rtr028) {
        this.rtr028 = rtr028;
    }

    public void setRtr031(final Integer rtr031) {
        this.rtr031 = rtr031;
    }

    public void setRtr035(final Integer rtr035) {
        this.rtr035 = rtr035;
    }

    public void setRtr044(final Integer rtr044) {
        this.rtr044 = rtr044;
    }

    public void setRtr071(final Integer rtr071) {
        this.rtr071 = rtr071;
    }

    public void setRtr074(final Integer rtr074) {
        this.rtr074 = rtr074;
    }

    public void setRtr075(final Integer rtr075) {
        this.rtr075 = rtr075;
    }

    public void setRtr076(final Integer rtr076) {
        this.rtr076 = rtr076;
    }

    public void setRtr077(final Integer rtr077) {
        this.rtr077 = rtr077;
    }

    public void setRtr078(final Integer rtr078) {
        this.rtr078 = rtr078;
    }

    public void setRtr080(final Integer rtr080) {
        this.rtr080 = rtr080;
    }

    public void setRtr081(final Integer rtr081) {
        this.rtr081 = rtr081;
    }

    public void setRtr084(final Integer rtr084) {
        this.rtr084 = rtr084;
    }

    public void setRtr159(final Integer rtr159) {
        this.rtr159 = rtr159;
    }

    public void setRtr303(final Integer rtr303) {
        this.rtr303 = rtr303;
    }

    public void setRtr401(final Integer rtr401) {
        this.rtr401 = rtr401;
    }

    public void setRtr403(final Integer rtr403) {
        this.rtr403 = rtr403;
    }

    public void setRtr501(final Integer rtr501) {
        this.rtr501 = rtr501;
    }

    public void setRtr584(final Integer rtr584) {
        this.rtr584 = rtr584;
    }

    public void setRtr585(final Integer rtr585) {
        this.rtr585 = rtr585;
    }

    public void setRtr589(final Integer rtr589) {
        this.rtr589 = rtr589;
    }

    public void setRtr590(final Integer rtr590) {
        this.rtr590 = rtr590;
    }

    public void setRtr601(final Integer rtr601) {
        this.rtr601 = rtr601;
    }

    public void setRtr751(final Integer rtr751) {
        this.rtr751 = rtr751;
    }

    public void setRtr752(final Integer rtr752) {
        this.rtr752 = rtr752;
    }

    public void setRtr901(final Integer rtr901) {
        this.rtr901 = rtr901;
    }

    public void setRtr903(final Integer rtr903) {
        this.rtr903 = rtr903;
    }

    public void setRtr904(final Integer rtr904) {
        this.rtr904 = rtr904;
    }

    public void setRtr905(final Integer rtr905) {
        this.rtr905 = rtr905;
    }

    public void setRtr906(final Integer rtr906) {
        this.rtr906 = rtr906;
    }

    public void setRtr908(final Integer rtr908) {
        this.rtr908 = rtr908;
    }

    public void setSatisfactoryAccounts(final Integer satisfactoryAccounts) {
        this.satisfactoryAccounts = satisfactoryAccounts;
    }

    public void setScorex(final String scorex) {
        this.scorex = scorex;
    }

    public void setScorexChange(final String scorexChange) {
        this.scorexChange = scorexChange;
    }

    public void setStatedMonthlyIncome(final Double statedMonthlyIncome) {
        this.statedMonthlyIncome = statedMonthlyIncome;
    }

    public void setTotalInquiries(final Integer totalInquiries) {
        this.totalInquiries = totalInquiries;
    }

    public void setTotalOpenRevolvingAccounts(final Integer totalOpenRevolvingAccounts) {
        this.totalOpenRevolvingAccounts = totalOpenRevolvingAccounts;
    }

    public void setTotalTradeItems(final Integer totalTradeItems) {
        this.totalTradeItems = totalTradeItems;
    }

    public void setVerificationStage(final Integer verificationStage) {
        this.verificationStage = verificationStage;
    }

    public void setWasDelinquentDerog(final Integer wasDelinquentDerog) {
        this.wasDelinquentDerog = wasDelinquentDerog;
    }

    public void setWholeLoanStartDate(final String wholeLoanStartDate) {
        this.wholeLoanStartDate = wholeLoanStartDate;
    }

}
