
package com.prosper.automation.model.platform.merchant;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class MerchantOfferedProductSpecs {

	@JsonProperty("term_in_months")
	private Integer termInMonths;

	@JsonProperty("promo_length_months")
	private Integer promoLengthMonths;

	@JsonProperty("upper_threshold")
	private Integer upperThreshold;

	@JsonProperty("lower_threshold")
	private Integer lowerThreshold;

	@JsonProperty("product_spec_id")
	private Integer productSpecId;

	@JsonProperty("funding_destination_type_id")
	private Integer fundingDestinationTypeId;

	private MerchantOfferedProductSpecs(Builder builder) {
		termInMonths = builder.termInMonths;
		promoLengthMonths = builder.promoLengthMonths;
		upperThreshold = builder.upperThreshold;
		lowerThreshold = builder.lowerThreshold;
		productSpecId = builder.productSpecId;
		fundingDestinationTypeId = builder.fundingDestinationTypeId;
	}

	public static final class Builder {

		private Integer termInMonths;
		private Integer promoLengthMonths;
		private Integer upperThreshold;
		private Integer lowerThreshold;
		private Integer productSpecId;
		private Integer fundingDestinationTypeId;

		public Builder() {
		}

		public Builder withTermInMonths(Integer val) {
			termInMonths = val;
			return this;
		}

		public Builder withPromoLengthMonths(Integer val) {
			promoLengthMonths = val;
			return this;
		}

		public Builder withUpperThreshold(Integer val) {
			upperThreshold = val;
			return this;
		}

		public Builder withLowerThreshold(Integer val) {
			lowerThreshold = val;
			return this;
		}

		public Builder withProductSpecid(Integer val) {
			productSpecId = val;
			return this;
		}

		public Builder withFundingDestinationTypeId(Integer val) {
			fundingDestinationTypeId = val;
			return this;
		}

		public MerchantOfferedProductSpecs build() {
			return new MerchantOfferedProductSpecs(this);
		}
	}
}
