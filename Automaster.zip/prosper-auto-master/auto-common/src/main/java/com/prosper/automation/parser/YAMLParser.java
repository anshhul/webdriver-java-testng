package com.prosper.automation.parser;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.esotericsoftware.yamlbeans.YamlReader;
import com.esotericsoftware.yamlbeans.YamlWriter;
import com.prosper.automation.exception.AutomationException;

/**
 * Created by pbudiono on 6/13/16.
 */
public final class YAMLParser {

	private static final String UNABLE_TO_PARSE_CONFIGURATION_FILE = "Unable to deserialize configuration file.";
	private static final String UNABLE_TO_WRITE_CONFIGURATION_FILE = "Unable to serialize configuration file.";

	private YAMLParser() {
	}

	public static <T> T deserialize(final String filePath, final Class<T> classType) throws AutomationException {
		try (final FileReader fileReader = new FileReader(filePath)) {
			YamlReader reader = new YamlReader(fileReader);
			return reader.read(classType);
		} catch (IOException ioe) {
			throw new AutomationException(UNABLE_TO_PARSE_CONFIGURATION_FILE, ioe);
		}
	}

	public static <T> T deserialize(final File file, final Class<T> classType) throws AutomationException {
		try (final FileReader fileReader = new FileReader(file)) {
			YamlReader reader = new YamlReader(fileReader);
			return reader.read(classType);
		} catch (IOException ioe) {
			throw new AutomationException(UNABLE_TO_PARSE_CONFIGURATION_FILE, ioe);
		}
	}

	public static <T> void serialize(final String filePath, final T entity) throws AutomationException {
		try (final FileWriter fileWriter = new FileWriter(filePath)) {
			final YamlWriter yamlWriter = new YamlWriter(fileWriter);
			yamlWriter.write(entity);
			yamlWriter.close();
		} catch (IOException ioe) {
			throw new AutomationException(UNABLE_TO_WRITE_CONFIGURATION_FILE, ioe);
		}
	}
}
