package com.prosper.automation.model.platform.bankValidation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public final class GetBankAccountInformationResponse {
    @JsonProperty("BankName")
    private String bankName;
    @JsonProperty("BankAccounts")
    private List<BankAccount> bankAccounts;
}
