
package com.prosper.automation.model.platform.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public final class PlatformResponse {

    @JsonProperty("status")
    private Status status;


    @JsonIgnore
    public int getStatusCode() {
        return status.getCode();
    }

    @JsonIgnore
    public String getStatusMessage() {
        return status.getMessage();
    }


    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public final class Status {

        @JsonProperty("code")
        private Integer code;
        @JsonProperty("message")
        private String message;


        @JsonIgnore
        public Integer getCode() {
            return code;
        }

        @JsonIgnore
        public String getMessage() {
            return message;
        }
    }
}
