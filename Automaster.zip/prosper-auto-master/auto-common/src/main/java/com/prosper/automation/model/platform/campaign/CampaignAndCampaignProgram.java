package com.prosper.automation.model.platform.campaign;

import com.prosper.automation.model.platform.prospect.Campaign;
import com.prosper.automation.model.platform.prospect.CampaignProgram;

/**
 * Created by rsubramanyam on 6/2/16.
 */
public class CampaignAndCampaignProgram {

    private Campaign campaign;
    private CampaignProgram campaignProgram;

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public CampaignProgram getCampaignProgram() {
        return campaignProgram;
    }

    public void setCampaignProgram(CampaignProgram campaignProgram) {
        this.campaignProgram = campaignProgram;
    }
}
