package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.prospect.Prospect;
import org.testng.Assert;

import java.util.Comparator;
import java.util.logging.Logger;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class MarketplaceProspectComparator implements Comparator<Prospect> {

    private ProspectAddressInfoComparator aInfoComparator = new ProspectAddressInfoComparator();
    private ProspectBankAccountInfoComparator bInfoComparator = new ProspectBankAccountInfoComparator();
    private ProspectContactInfoComparator cInfoComparator = new ProspectContactInfoComparator();
    private ProspectEmploymentInfoComparator eInfoComparator = new ProspectEmploymentInfoComparator();
    ;
    private ProspectLoanInfoComparator lInfoComparator = new ProspectLoanInfoComparator();
    ;
    private ProspectPersonalInfoComparator pInfoComparator = new ProspectPersonalInfoComparator();

    @Override public int compare(Prospect otherResponse, Prospect expectedResponse) {
        LoanInfo expectedLoanInfo =
                new LoanInfo.LoanInfoBuilder().withLoanAmount(String.valueOf(expectedResponse.getLoanAmount()))
                        .withLoanPurpose(String.valueOf(expectedResponse.getLoanPurposeId())).build();
        LoanInfo otherLoanInfo = new LoanInfo.LoanInfoBuilder().withLoanAmount(String.valueOf(otherResponse.getLoanAmount()))
                .withLoanPurpose(String.valueOf(otherResponse.getLoanPurposeId())).build();
        if (aInfoComparator.compare(otherResponse.getAddressInfo(), expectedResponse.getAddressInfo()) == 1) {
            Assert.fail(otherResponse.getAddressInfo() + " does not match expected " + expectedResponse.getAddressInfo());
        }
        if (bInfoComparator.compare(otherResponse.getBankAccountInfo(), expectedResponse.getBankAccountInfo()) == 1) {
            Assert.fail(otherResponse.getBankAccountInfo() + " does not match expected " + expectedResponse.getBankAccountInfo());
        }
        if (cInfoComparator.compare(otherResponse.getContactInfo(), expectedResponse.getContactInfo()) == 1) {
            Assert.fail(otherResponse.getBankAccountInfo() + " does not match expected " + expectedResponse.getContactInfo());
        }
        if (eInfoComparator.compare(otherResponse.getEmploymentInfo(), expectedResponse.getEmploymentInfo()) == 1) {
            Assert.fail(otherResponse.getEmploymentInfo() + " does not match expected " + expectedResponse.getEmploymentInfo());
        }
        if (lInfoComparator.compare(otherLoanInfo, expectedLoanInfo) == 1) {
            Assert.fail(otherLoanInfo + " does not match expected " + expectedLoanInfo);
        }
        if (pInfoComparator.compare(otherResponse.getPersonalInfo(), expectedResponse.getPersonalInfo()) == 1) {
            Assert.fail(otherResponse.getPersonalInfo() + " does not match expected " + expectedResponse.getPersonalInfo());
        }
        return 0;
    }
}