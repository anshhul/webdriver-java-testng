package com.prosper.automation.constant.test;

/**
 * @author pbudiono
 */
public final class TestGroup {


	public static final String SANITY = "SANITY";
	public static final String ACCEPTANCE = "ACCEPTANCE";
	public static final String NIGHTLY = "NIGHTLY";
	public static final String PROD_SANITY = "PROD_SANITY";
	public static final String REGRESSION ="REGRESSION";
}
