package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.user.UserCreditReportMappingRequestDTO;

import java.util.List;

/**
 * Created by rchintapalli on 12/06/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProspectCreditReportMappingRequest {

    @JsonProperty("entities")
    private  List<ProspectCreditReportMappingDTO> prospectCRMappingRequest;

    public List<ProspectCreditReportMappingDTO> getProspectMappingResponse() {
        return prospectCRMappingRequest;
    }

    public void setProspectCRMappingRequest(List<ProspectCreditReportMappingDTO> prospectCRMappingRequest) {
        this.prospectCRMappingRequest = prospectCRMappingRequest;
    }

    public ProspectCreditReportMappingRequest(Builder builder){
        setProspectCRMappingRequest(builder.prospectCRMappingRequest);
    }

    public static final class Builder {
        private List<ProspectCreditReportMappingDTO> prospectCRMappingRequest;

        public Builder(){
        }

        public Builder withProspectCreditReportMappingDTO(List<ProspectCreditReportMappingDTO> val){
            prospectCRMappingRequest =val;
            return this;
        }

        public ProspectCreditReportMappingRequest build() {
            return new ProspectCreditReportMappingRequest(this);
        }
    }
}
