package com.prosper.automation.constant.web;

/**
 * Created by ppatil on 9/22/16.
 */
public class LoanDetailsPageConstants {


    public static final String LOAN_DETAILS_TITLE = "Active Listings and Loans";
    public static final String LATEST_LISTING = "Debt Consolidation";
    public static final String DROPPEDOFF_LOAN_DETAILS_TITLE = "Finish creating the listing that you saved earlier. ";
}
