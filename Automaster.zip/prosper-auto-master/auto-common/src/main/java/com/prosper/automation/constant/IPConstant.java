
package com.prosper.automation.constant;

/**
 * Created by pbudiono on 7/19/16.
 */
public final class IPConstant {

    public static final String LOCAL_IP = "127.0.0.1";
}
