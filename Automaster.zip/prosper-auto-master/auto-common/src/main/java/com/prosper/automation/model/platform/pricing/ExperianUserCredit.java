
package com.prosper.automation.model.platform.pricing;

import java.util.Calendar;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.experian.ExperianCreditProfileData;
import com.prosper.automation.model.platform.offer.StaggMap;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ExperianUserCredit {

    @JsonProperty("bankcardUtilization")
    private Double bankcardUtilization;
    @JsonProperty("credit_profile_id")
    private Integer creditProfileId;
    @JsonProperty("credit_grade_id")
    private Integer creditGradeId;
    @JsonProperty("monthly_debt")
    private Double monthlyDebt;
    @JsonProperty("current_delinquencies")
    private Integer currentDelinquencies;
    @JsonProperty("delinquencies_last_7_years")
    private Integer delinquenciesLast7Years;
    @JsonProperty("public_records_last_10_years")
    private Integer publicRecordsLast10Years;
    @JsonProperty("first_recorded_credit_line")
    private Long firstRecordedCreditLine;
    @JsonProperty("credit_lines_last_7_years")
    private Integer creditLinesLast7Years;
    @JsonProperty("inquiries_last_6_months")
    private Integer inquiriesLast6Months;
    @JsonProperty("experian_document_id")
    private Integer experianDocumentId;
    @JsonProperty("amount_delinquent")
    private Double amountDelinquent;
    @JsonProperty("public_records_last_12_months")
    private Integer publicRecordsLast12Months;
    @JsonProperty("current_credit_lines")
    private Integer currentCreditLines;
    @JsonProperty("open_credit_lines")
    private Integer openCreditLines;
    @JsonProperty("revolving_credit_balance")
    private Double revolvingCreditBalance;
    @JsonProperty("total_open_revolving_accounts")
    private Integer totalOpenRevolvingAccounts;
    @JsonProperty("bank_card_utilization")
    private Double bankCardUtilization;
    @JsonProperty("credit_score_type")
    private String creditScoreType;
    @JsonProperty("credit_reporting_agency_id")
    private Integer creditReportingAgencyId;
    @JsonProperty("credit_pull_date")
    private Long creditPullDate;
    @JsonProperty("raw_score")
    private Integer rawScore;
    @JsonProperty("marked_as_error")
    private Boolean markedAsError;
    @JsonProperty("score")
    private Integer score;
    @JsonProperty("fico")
    private Integer fico;
    @JsonProperty("score_x")
    private Integer scoreX;
    @JsonProperty("experian_credit_profile_data")
    private ExperianCreditProfileData experianCreditProfileData;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("available_credit")
    private Double availableCredit;
    @JsonProperty("total_inquiries")
    private Integer totalInquiries;
    @JsonProperty("real_estate_balance")
    private Integer realEstateBalance;
    @JsonProperty("real_estate_payment")
    private Integer realEstatePayment;
    @JsonProperty("tradelines_opened_last_6_months")
    private Integer tradelinesOpenedLast6Months;
    @JsonProperty("total_credit_lines")
    private Integer totalCreditLines;
    @JsonProperty("trades_never_delinquent_percent")
    private Integer tradesNeverDelinquentPercent;
    @JsonProperty("total_bank_cards_open")
    private Integer totalBankCardsOpen;
    @JsonProperty("trades_open_last_12_months")
    private Integer tradesOpenLast12Months;
    @JsonProperty("trades_never_delinquent_6_months")
    private Integer tradesNeverDelinquent6Months;
    @JsonProperty("trades_dpd_30_plus_or_derog_12_months")
    private Integer tradesDpd30PlusOrDerog12Months;
    @JsonProperty("aggregate_balance_on_trades_6_months")
    private Double aggregateBalanceOnTrades6Months;
    @JsonProperty("aggregate_monthly_payment_on_trades_6_months")
    private Integer aggregateMonthlyPaymentOnTrades6Months;
    @JsonProperty("mr_30_to_180_delinquent_or_derog_trades")
    private Integer mr30To180DelinquentOrDerogTrades;
    @JsonProperty("inquiries_6_months")
    private Integer inquiries6Months;
    @JsonProperty("open_bc_6_months")
    private Integer openBc6Months;
    @JsonProperty("sum_available_credit_open_bc")
    private Integer sumAvailableCreditOpenBc;
    @JsonProperty("open_paid_closed_inactive_install_trades")
    private Integer openPaidClosedInactiveInstallTrades;
    @JsonProperty("install_trades_opened_12_months")
    private Integer installTradesOpened12Months;
    @JsonProperty("open_real_property_trades_6_months")
    private Integer openRealPropertyTrades6Months;
    @JsonProperty("avg_credit_or_loan_amt_open_real_property_6_months")
    private Integer avgCreditOrLoanAmtOpenRealProperty6Months;
    @JsonProperty("aggregate_balance_credit_ratio_on_all_trades_6_months")
    private Integer aggregateBalanceCreditRatioOnAllTrades6Months;
    @JsonProperty("iln_201_agg_bal_open_install_trds")
    private Double iln201AggBalOpenInstallTrds;
    @JsonProperty("avg_age_rev_trades")
    private Integer avgAgeRevTrades;
    @JsonProperty("rev_to_total_trades")
    private Integer revToTotalTrades;
    @JsonProperty("num_trades_open")
    private Integer numTradesOpen;
    @JsonProperty("num_bankruptcies")
    private Integer numBankruptcies;
    @JsonProperty("months_since_last_bankruptcy")
    private Integer monthsSinceLastBankruptcy;
    @JsonProperty("credit_pull_status_id")
    private String creditPullStatusId;
    @JsonProperty("credit_pull_status_reason_id")
    private String creditPullStatusReasonId;
    @JsonProperty("credit_report_id")
    private Integer creditReportId;
    @JsonProperty("all_804_inq_last_12_months")
    private Integer all804InqLast12Months;
    @JsonProperty("iln_908_perc_install_total_trades")
    private Integer iln908PercInstallTotalTrades;
    @JsonProperty("iln_403_install_util")
    private Integer iln403InstallUtil;
    @JsonProperty("rtr_035_num_retail_trades_bal_ge_1k")
    private Integer rtr035NumRetailTradesBalGe1k;
    @JsonProperty("rev_028_num_rev_trades_open_min_6_months")
    private Integer rev028NumRevTradesOpenMin6Months;
    @JsonProperty("all_805_age_mr_inq")
    private Integer all805AgeMrInq;
    @JsonProperty("bac_044_num_open_bc_util_ge_90p")
    private Integer bac044NumOpenBcUtilGe90p;
    @JsonProperty("bac_002_num_bc_open_paid_closed")
    private Integer bac002NumBcOpenPaidClosed;
    @JsonProperty("all_702_age_mr_open_trade")
    private Integer all702AgeMrOpenTrade;
    @JsonProperty("rev_404_rev_util_trades_opened_last_12_months")
    private Integer rev404RevUtilTradesOpenedLast12Months;
    @JsonProperty("bac_035_num_open_bc_bal_ge_1k")
    private Integer bac035NumOpenBcBalGe1k;
    @JsonProperty("all_082_num_trades_open_24_months_ever_30p")
    private Integer all082NumTradesOpen24MonthsEver30p;
    @JsonProperty("rtr_401_sum_avail_credit_open_retail")
    private Integer rtr401SumAvailCreditOpenRetail;
    @JsonProperty("rep_005_num_re_trades")
    private Integer rep005NumReTrades;
    @JsonProperty("rev_038_num_rev_trades_bal_ge_1k")
    private Integer rev038NumRevTradesBalGe1k;
    @JsonProperty("iln_023_num_install_open_last_24_months")
    private Integer iln023NumInstallOpenLast24Months;
    @JsonProperty("all_010_num_trds_open_paid_closed")
    private Integer all010NumTrdsOpenPaidClosed;
    @JsonProperty("rev_071_num_rev_trades_not_dqor_derog")
    private Integer rev071NumRevTradesNotDqorDerog;
    @JsonProperty("lfi_801_fil_inq_ever")
    private Integer lfi801FilInqEver;
    @JsonProperty("all_104_num_trades_30p_last_6months")
    private Integer all104NumTrades30pLast6months;
    @JsonProperty("all0_67_num_trds_curr_90p_dpd_6_months")
    private Integer all067NumTrdsCurr90pDpd6Months;
    @JsonProperty("all_002_num_trades_open_paid_clos_in_act")
    private Integer all002NumTradesOpenPaidClosInAct;
    @JsonProperty("satisfactory_revolving_trades")
    private Integer satisfactoryRevolvingTrades;
    @JsonProperty("stagg_map")
    private StaggMap staggMap;
    @JsonProperty("last_unsecure_trade_line_open_date_le_60m_term")
    private Date lastUnsecureTradeLineOpenDateBelow60MonthTerm;
    @JsonProperty("total_trade_lines_available")
    private Integer totalTradeLinesAvailable;

    public ExperianUserCredit() {
    }

    private ExperianUserCredit(final Builder builder) {
        bankcardUtilization = builder.bankcardUtilization;
        creditProfileId = builder.creditProfileId;
        creditGradeId = builder.creditGradeId;
        monthlyDebt = builder.monthlyDebt;
        currentDelinquencies = builder.currentDelinquencies;
        delinquenciesLast7Years = builder.delinquenciesLast7Years;
        publicRecordsLast10Years = builder.publicRecordsLast10Years;
        firstRecordedCreditLine = builder.firstRecordedCreditLine;
        creditLinesLast7Years = builder.creditLinesLast7Years;
        inquiriesLast6Months = builder.inquiriesLast6Months;
        experianDocumentId = builder.experianDocumentId;
        amountDelinquent = builder.amountDelinquent;
        publicRecordsLast12Months = builder.publicRecordsLast12Months;
        currentCreditLines = builder.currentCreditLines;
        openCreditLines = builder.openCreditLines;
        revolvingCreditBalance = builder.revolvingCreditBalance;
        totalOpenRevolvingAccounts = builder.totalOpenRevolvingAccounts;
        bankCardUtilization = builder.bankCardUtilization;
        creditScoreType = builder.creditScoreType;
        creditReportingAgencyId = builder.creditReportingAgencyId;
        creditPullDate = builder.creditPullDate;
        rawScore = builder.rawScore;
        markedAsError = builder.markedAsError;
        score = builder.score;
        fico = builder.fico;
        scoreX = builder.scoreX;
        experianCreditProfileData = builder.experianCreditProfileData;
        ssn = builder.ssn;
        availableCredit = builder.availableCredit;
        totalInquiries = builder.totalInquiries;
        realEstateBalance = builder.realEstateBalance;
        realEstatePayment = builder.realEstatePayment;
        tradelinesOpenedLast6Months = builder.tradelinesOpenedLast6Months;
        totalCreditLines = builder.totalCreditLines;
        tradesNeverDelinquentPercent = builder.tradesNeverDelinquentPercent;
        totalBankCardsOpen = builder.totalBankCardsOpen;
        tradesOpenLast12Months = builder.tradesOpenLast12Months;
        tradesNeverDelinquent6Months = builder.tradesNeverDelinquent6Months;
        tradesDpd30PlusOrDerog12Months = builder.tradesDpd30PlusOrDerog12Months;
        aggregateBalanceOnTrades6Months = builder.aggregateBalanceOnTrades6Months;
        aggregateMonthlyPaymentOnTrades6Months = builder.aggregateMonthlyPaymentOnTrades6Months;
        mr30To180DelinquentOrDerogTrades = builder.mr30To180DelinquentOrDerogTrades;
        inquiries6Months = builder.inquiries6Months;
        openBc6Months = builder.openBc6Months;
        sumAvailableCreditOpenBc = builder.sumAvailableCreditOpenBc;
        openPaidClosedInactiveInstallTrades = builder.openPaidClosedInactiveInstallTrades;
        installTradesOpened12Months = builder.installTradesOpened12Months;
        openRealPropertyTrades6Months = builder.openRealPropertyTrades6Months;
        avgCreditOrLoanAmtOpenRealProperty6Months = builder.avgCreditOrLoanAmtOpenRealProperty6Months;
        aggregateBalanceCreditRatioOnAllTrades6Months = builder.aggregateBalanceCreditRatioOnAllTrades6Months;
        iln201AggBalOpenInstallTrds = builder.iln201AggBalOpenInstallTrds;
        avgAgeRevTrades = builder.avgAgeRevTrades;
        revToTotalTrades = builder.revToTotalTrades;
        numTradesOpen = builder.numTradesOpen;
        numBankruptcies = builder.numBankruptcies;
        monthsSinceLastBankruptcy = builder.monthsSinceLastBankruptcy;
        creditPullStatusId = builder.creditPullStatusId;
        creditPullStatusReasonId = builder.creditPullStatusReasonId;
        creditReportId = builder.creditReportId;
        all804InqLast12Months = builder.all804InqLast12Months;
        iln908PercInstallTotalTrades = builder.iln908PercInstallTotalTrades;
        iln403InstallUtil = builder.iln403InstallUtil;
        rtr035NumRetailTradesBalGe1k = builder.rtr035NumRetailTradesBalGe1k;
        rev028NumRevTradesOpenMin6Months = builder.rev028NumRevTradesOpenMin6Months;
        all805AgeMrInq = builder.all805AgeMrInq;
        bac044NumOpenBcUtilGe90p = builder.bac044NumOpenBcUtilGe90p;
        bac002NumBcOpenPaidClosed = builder.bac002NumBcOpenPaidClosed;
        all702AgeMrOpenTrade = builder.all702AgeMrOpenTrade;
        rev404RevUtilTradesOpenedLast12Months = builder.rev404RevUtilTradesOpenedLast12Months;
        bac035NumOpenBcBalGe1k = builder.bac035NumOpenBcBalGe1k;
        all082NumTradesOpen24MonthsEver30p = builder.all082NumTradesOpen24MonthsEver30p;
        rtr401SumAvailCreditOpenRetail = builder.rtr401SumAvailCreditOpenRetail;
        rep005NumReTrades = builder.rep005NumReTrades;
        rev038NumRevTradesBalGe1k = builder.rev038NumRevTradesBalGe1k;
        iln023NumInstallOpenLast24Months = builder.iln023NumInstallOpenLast24Months;
        all010NumTrdsOpenPaidClosed = builder.all010NumTrdsOpenPaidClosed;
        rev071NumRevTradesNotDqorDerog = builder.rev071NumRevTradesNotDqorDerog;
        lfi801FilInqEver = builder.lfi801FilInqEver;
        all104NumTrades30pLast6months = builder.all104NumTrades30pLast6months;
        all067NumTrdsCurr90pDpd6Months = builder.all067NumTrdsCurr90pDpd6Months;
        all002NumTradesOpenPaidClosInAct = builder.all002NumTradesOpenPaidClosInAct;
        satisfactoryRevolvingTrades = builder.satisfactoryRevolvingTrades;
        staggMap = builder.staggMap;
        lastUnsecureTradeLineOpenDateBelow60MonthTerm = builder.lastUnsecureTradeLineOpenDateBelow60MonthTerm;
        totalTradeLinesAvailable = builder.totalTradeLinesAvailable;
    }

    public static final class Builder {

        private Double bankcardUtilization;
        private Integer creditProfileId;
        private Integer creditGradeId;
        private Double monthlyDebt;
        private Integer currentDelinquencies;
        private Integer delinquenciesLast7Years;
        private Integer publicRecordsLast10Years;
        private Long firstRecordedCreditLine;
        private Integer creditLinesLast7Years;
        private Integer inquiriesLast6Months;
        private Integer experianDocumentId;
        private Double amountDelinquent;
        private Integer publicRecordsLast12Months;
        private Integer currentCreditLines;
        private Integer openCreditLines;
        private Double revolvingCreditBalance;
        private Integer totalOpenRevolvingAccounts;
        private Double bankCardUtilization;
        private String creditScoreType;
        private Integer creditReportingAgencyId;
        private Long creditPullDate;
        private Integer rawScore;
        private Boolean markedAsError;
        private Integer score;
        private Integer fico;
        private Integer scoreX;
        private ExperianCreditProfileData experianCreditProfileData;
        private String ssn;
        private Double availableCredit;
        private Integer totalInquiries;
        private Integer realEstateBalance;
        private Integer realEstatePayment;
        private Integer tradelinesOpenedLast6Months;
        private Integer totalCreditLines;
        private Integer tradesNeverDelinquentPercent;
        private Integer totalBankCardsOpen;
        private Integer tradesOpenLast12Months;
        private Integer tradesNeverDelinquent6Months;
        private Integer tradesDpd30PlusOrDerog12Months;
        private Double aggregateBalanceOnTrades6Months;
        private Integer aggregateMonthlyPaymentOnTrades6Months;
        private Integer mr30To180DelinquentOrDerogTrades;
        private Integer inquiries6Months;
        private Integer openBc6Months;
        private Integer sumAvailableCreditOpenBc;
        private Integer openPaidClosedInactiveInstallTrades;
        private Integer installTradesOpened12Months;
        private Integer openRealPropertyTrades6Months;
        private Integer avgCreditOrLoanAmtOpenRealProperty6Months;
        private Integer aggregateBalanceCreditRatioOnAllTrades6Months;
        private Double iln201AggBalOpenInstallTrds;
        private Integer avgAgeRevTrades;
        private Integer revToTotalTrades;
        private Integer numTradesOpen;
        private Integer numBankruptcies;
        private Integer monthsSinceLastBankruptcy;
        private String creditPullStatusId;
        private String creditPullStatusReasonId;
        private Integer creditReportId;
        private Integer all804InqLast12Months;
        private Integer iln908PercInstallTotalTrades;
        private Integer iln403InstallUtil;
        private Integer rtr035NumRetailTradesBalGe1k;
        private Integer rev028NumRevTradesOpenMin6Months;
        private Integer all805AgeMrInq;
        private Integer bac044NumOpenBcUtilGe90p;
        private Integer bac002NumBcOpenPaidClosed;
        private Integer all702AgeMrOpenTrade;
        private Integer rev404RevUtilTradesOpenedLast12Months;
        private Integer bac035NumOpenBcBalGe1k;
        private Integer all082NumTradesOpen24MonthsEver30p;
        private Integer rtr401SumAvailCreditOpenRetail;
        private Integer rep005NumReTrades;
        private Integer rev038NumRevTradesBalGe1k;
        private Integer iln023NumInstallOpenLast24Months;
        private Integer all010NumTrdsOpenPaidClosed;
        private Integer rev071NumRevTradesNotDqorDerog;
        private Integer lfi801FilInqEver;
        private Integer all104NumTrades30pLast6months;
        private Integer all067NumTrdsCurr90pDpd6Months;
        private Integer all002NumTradesOpenPaidClosInAct;
        private Integer satisfactoryRevolvingTrades;
        private StaggMap staggMap;
        private Date lastUnsecureTradeLineOpenDateBelow60MonthTerm;
        private Integer totalTradeLinesAvailable;

        public Builder() {
        }

        public Builder withLastUnsecureTradeLineOpenDateBelow60MonthTerm(
                final Integer lastUnsecureTradeLineOpenDateBelow60MonthTerm) {
            if (lastUnsecureTradeLineOpenDateBelow60MonthTerm == null) {
                return this;
            }

            final Calendar today = Calendar.getInstance();
            today.add(Calendar.MONTH, -(lastUnsecureTradeLineOpenDateBelow60MonthTerm));
            // return String.format(INVALID_DAY_DATE_TEMPLATE,
            // today.get(Calendar.YEAR));
            this.lastUnsecureTradeLineOpenDateBelow60MonthTerm = today.getTime();
            return this;
        }

        public Builder withTotalTradeLinesAvailable(final Integer totalTradeLinesAvailable) {
            this.totalTradeLinesAvailable = totalTradeLinesAvailable;
            return this;
        }

        public Builder withBankcardUtilization(final Double bankcardUtilization) {
            this.bankcardUtilization = bankcardUtilization;
            return this;
        }

        public Builder withCreditProfileId(final Integer creditProfileId) {
            this.creditProfileId = creditProfileId;
            return this;
        }

        public Builder withCreditGradeId(final Integer creditGradeId) {
            this.creditGradeId = creditGradeId;
            return this;
        }

        public Builder withMonthlyDebt(final Double monthlyDebt) {
            this.monthlyDebt = monthlyDebt;
            return this;
        }

        public Builder withCurrentDelinquencies(final Integer currentDelinquencies) {
            this.currentDelinquencies = currentDelinquencies;
            return this;
        }

        public Builder withDelinquenciesLast7Years(final Integer delinquenciesLast7Years) {
            this.delinquenciesLast7Years = delinquenciesLast7Years;
            return this;
        }

        public Builder withPublicRecordsLast10Years(final Integer publicRecordsLast10Years) {
            this.publicRecordsLast10Years = publicRecordsLast10Years;
            return this;
        }

        public Builder withFirstRecordedCreditLine(final Long firstRecordedCreditLine) {
            this.firstRecordedCreditLine = firstRecordedCreditLine;
            return this;
        }

        public Builder withCreditLinesLast7Years(final Integer creditLinesLast7Years) {
            this.creditLinesLast7Years = creditLinesLast7Years;
            return this;
        }

        public Builder withInquiriesLast6Months(final Integer inquiriesLast6Months) {
            this.inquiriesLast6Months = inquiriesLast6Months;
            return this;
        }

        public Builder withExperianDocumentId(final Integer experianDocumentId) {
            this.experianDocumentId = experianDocumentId;
            return this;
        }

        public Builder withAmountDelinquent(final Double amountDelinquent) {
            this.amountDelinquent = amountDelinquent;
            return this;
        }

        public Builder withPublicRecordsLast12Months(final Integer publicRecordsLast12Months) {
            this.publicRecordsLast12Months = publicRecordsLast12Months;
            return this;
        }

        public Builder withCurrentCreditLines(final Integer currentCreditLines) {
            this.currentCreditLines = currentCreditLines;
            return this;
        }

        public Builder withOpenCreditLines(final Integer openCreditLines) {
            this.openCreditLines = openCreditLines;
            return this;
        }

        public Builder withRevolvingCreditBalance(final Double revolvingCreditBalance) {
            this.revolvingCreditBalance = revolvingCreditBalance;
            return this;
        }

        public Builder withTotalOpenRevolvingAccounts(final Integer totalOpenRevolvingAccounts) {
            this.totalOpenRevolvingAccounts = totalOpenRevolvingAccounts;
            return this;
        }

        public Builder withBankCardUtilization(final Double bankCardUtilization) {
            this.bankCardUtilization = bankCardUtilization;
            return this;
        }

        public Builder withCreditScoreType(final String creditScoreType) {
            this.creditScoreType = creditScoreType;
            return this;
        }

        public Builder withCreditReportingAgencyId(final Integer creditReportingAgencyId) {
            this.creditReportingAgencyId = creditReportingAgencyId;
            return this;
        }

        public Builder withCreditPullDate(final Long creditPullDate) {
            this.creditPullDate = creditPullDate;
            return this;
        }

        public Builder withRawScore(final Integer rawScore) {
            this.rawScore = rawScore;
            return this;
        }

        public Builder withMarkedAsError(final Boolean markedAsError) {
            this.markedAsError = markedAsError;
            return this;
        }

        public Builder withScore(final Integer score) {
            this.score = score;
            return this;
        }

        public Builder withFico(final Integer fico) {
            this.fico = fico;
            return this;
        }

        public Builder withScoreX(final Integer scoreX) {
            this.scoreX = scoreX;
            return this;
        }

        public Builder withExperianCreditProfileData(final ExperianCreditProfileData experianCreditProfileData) {
            this.experianCreditProfileData = experianCreditProfileData;
            return this;
        }

        public Builder withSsn(final String ssn) {
            this.ssn = ssn;
            return this;
        }

        public Builder withAvailableCredit(final Double availableCredit) {
            this.availableCredit = availableCredit;
            return this;
        }

        public Builder withTotalInquiries(final Integer totalInquiries) {
            this.totalInquiries = totalInquiries;
            return this;
        }

        public Builder withRealEstateBalance(final Integer realEstateBalance) {
            this.realEstateBalance = realEstateBalance;
            return this;
        }

        public Builder withRealEstatePayment(final Integer realEstatePayment) {
            this.realEstatePayment = realEstatePayment;
            return this;
        }

        public Builder withTradelinesOpenedLast6Months(final Integer tradelinesOpenedLast6Months) {
            this.tradelinesOpenedLast6Months = tradelinesOpenedLast6Months;
            return this;
        }

        public Builder withTotalCreditLines(final Integer totalCreditLines) {
            this.totalCreditLines = totalCreditLines;
            return this;
        }

        public Builder withTradesNeverDelinquentPercent(final Integer tradesNeverDelinquentPercent) {
            this.tradesNeverDelinquentPercent = tradesNeverDelinquentPercent;
            return this;
        }

        public Builder withTotalBankCardsOpen(final Integer totalBankCardsOpen) {
            this.totalBankCardsOpen = totalBankCardsOpen;
            return this;
        }

        public Builder withTradesOpenLast12Months(final Integer tradesOpenLast12Months) {
            this.tradesOpenLast12Months = tradesOpenLast12Months;
            return this;
        }

        public Builder withTradesNeverDelinquent6Months(final Integer tradesNeverDelinquent6Months) {
            this.tradesNeverDelinquent6Months = tradesNeverDelinquent6Months;
            return this;
        }

        public Builder withTradesDpd30PlusOrDerog12Months(final Integer tradesDpd30PlusOrDerog12Months) {
            this.tradesDpd30PlusOrDerog12Months = tradesDpd30PlusOrDerog12Months;
            return this;
        }

        public Builder withAggregateBalanceOnTrades6Months(final Double aggregateBalanceOnTrades6Months) {
            this.aggregateBalanceOnTrades6Months = aggregateBalanceOnTrades6Months;
            return this;
        }

        public Builder withAggregateMonthlyPaymentOnTrades6Months(final Integer aggregateMonthlyPaymentOnTrades6Months) {
            this.aggregateMonthlyPaymentOnTrades6Months = aggregateMonthlyPaymentOnTrades6Months;
            return this;
        }

        public Builder withMr30To180DelinquentOrDerogTrades(final Integer mr30To180DelinquentOrDerogTrades) {
            this.mr30To180DelinquentOrDerogTrades = mr30To180DelinquentOrDerogTrades;
            return this;
        }

        public Builder withInquiries6Months(final Integer inquiries6Months) {
            this.inquiries6Months = inquiries6Months;
            return this;
        }

        public Builder withOpenBc6Months(final Integer openBc6Months) {
            this.openBc6Months = openBc6Months;
            return this;
        }

        public Builder withSumAvailableCreditOpenBc(final Integer sumAvailableCreditOpenBc) {
            this.sumAvailableCreditOpenBc = sumAvailableCreditOpenBc;
            return this;
        }

        public Builder withOpenPaidClosedInactiveInstallTrades(final Integer openPaidClosedInactiveInstallTrades) {
            this.openPaidClosedInactiveInstallTrades = openPaidClosedInactiveInstallTrades;
            return this;
        }

        public Builder withInstallTradesOpened12Months(final Integer installTradesOpened12Months) {
            this.installTradesOpened12Months = installTradesOpened12Months;
            return this;
        }

        public Builder withOpenRealPropertyTrades6Months(final Integer openRealPropertyTrades6Months) {
            this.openRealPropertyTrades6Months = openRealPropertyTrades6Months;
            return this;
        }

        public Builder withAvgCreditOrLoanAmtOpenRealProperty6Months(final Integer avgCreditOrLoanAmtOpenRealProperty6Months) {
            this.avgCreditOrLoanAmtOpenRealProperty6Months = avgCreditOrLoanAmtOpenRealProperty6Months;
            return this;
        }

        public Builder withAggregateBalanceCreditRatioOnAllTrades6Months(
                final Integer aggregateBalanceCreditRatioOnAllTrades6Months) {
            this.aggregateBalanceCreditRatioOnAllTrades6Months = aggregateBalanceCreditRatioOnAllTrades6Months;
            return this;
        }

        public Builder withIln201AggBalOpenInstallTrds(final Double iln201AggBalOpenInstallTrds) {
            this.iln201AggBalOpenInstallTrds = iln201AggBalOpenInstallTrds;
            return this;
        }

        public Builder withAvgAgeRevTrades(final Integer avgAgeRevTrades) {
            this.avgAgeRevTrades = avgAgeRevTrades;
            return this;
        }

        public Builder withRevToTotalTrades(final Integer revToTotalTrades) {
            this.revToTotalTrades = revToTotalTrades;
            return this;
        }

        public Builder withNumTradesOpen(final Integer numTradesOpen) {
            this.numTradesOpen = numTradesOpen;
            return this;
        }

        public Builder withNumBankruptcies(final Integer numBankruptcies) {
            this.numBankruptcies = numBankruptcies;
            return this;
        }

        public Builder withMonthsSinceLastBankruptcy(final Integer monthsSinceLastBankruptcy) {
            this.monthsSinceLastBankruptcy = monthsSinceLastBankruptcy;
            return this;
        }

        public Builder withCreditPullStatusId(final String creditPullStatusId) {
            this.creditPullStatusId = creditPullStatusId;
            return this;
        }

        public Builder withCreditPullStatusReasonId(final String creditPullStatusReasonId) {
            this.creditPullStatusReasonId = creditPullStatusReasonId;
            return this;
        }

        public Builder withCreditReportId(final Integer creditReportId) {
            this.creditReportId = creditReportId;
            return this;
        }

        public Builder withAll804InqLast12Months(final Integer all804InqLast12Months) {
            this.all804InqLast12Months = all804InqLast12Months;
            return this;
        }

        public Builder withIln908PercInstallTotalTrades(final Integer iln908PercInstallTotalTrades) {
            this.iln908PercInstallTotalTrades = iln908PercInstallTotalTrades;
            return this;
        }

        public Builder withIln403InstallUtil(final Integer iln403InstallUtil) {
            this.iln403InstallUtil = iln403InstallUtil;
            return this;
        }

        public Builder withRtr035NumRetailTradesBalGe1k(final Integer rtr035NumRetailTradesBalGe1k) {
            this.rtr035NumRetailTradesBalGe1k = rtr035NumRetailTradesBalGe1k;
            return this;
        }

        public Builder withRev028NumRevTradesOpenMin6Months(final Integer rev028NumRevTradesOpenMin6Months) {
            this.rev028NumRevTradesOpenMin6Months = rev028NumRevTradesOpenMin6Months;
            return this;
        }

        public Builder withAll805AgeMrInq(final Integer all805AgeMrInq) {
            this.all805AgeMrInq = all805AgeMrInq;
            return this;
        }

        public Builder withBac044NumOpenBcUtilGe90p(final Integer bac044NumOpenBcUtilGe90p) {
            this.bac044NumOpenBcUtilGe90p = bac044NumOpenBcUtilGe90p;
            return this;
        }

        public Builder withBac002NumBcOpenPaidClosed(final Integer bac002NumBcOpenPaidClosed) {
            this.bac002NumBcOpenPaidClosed = bac002NumBcOpenPaidClosed;
            return this;
        }

        public Builder withAll702AgeMrOpenTrade(final Integer all702AgeMrOpenTrade) {
            this.all702AgeMrOpenTrade = all702AgeMrOpenTrade;
            return this;
        }

        public Builder withRev404RevUtilTradesOpenedLast12Months(final Integer rev404RevUtilTradesOpenedLast12Months) {
            this.rev404RevUtilTradesOpenedLast12Months = rev404RevUtilTradesOpenedLast12Months;
            return this;
        }

        public Builder withBac035NumOpenBcBalGe1k(final Integer bac035NumOpenBcBalGe1k) {
            this.bac035NumOpenBcBalGe1k = bac035NumOpenBcBalGe1k;
            return this;
        }

        public Builder withAll082NumTradesOpen24MonthsEver30p(final Integer all082NumTradesOpen24MonthsEver30p) {
            this.all082NumTradesOpen24MonthsEver30p = all082NumTradesOpen24MonthsEver30p;
            return this;
        }

        public Builder withRtr401SumAvailCreditOpenRetail(final Integer rtr401SumAvailCreditOpenRetail) {
            this.rtr401SumAvailCreditOpenRetail = rtr401SumAvailCreditOpenRetail;
            return this;
        }

        public Builder withRep005NumReTrades(final Integer rep005NumReTrades) {
            this.rep005NumReTrades = rep005NumReTrades;
            return this;
        }

        public Builder withRev038NumRevTradesBalGe1k(final Integer rev038NumRevTradesBalGe1k) {
            this.rev038NumRevTradesBalGe1k = rev038NumRevTradesBalGe1k;
            return this;
        }

        public Builder withIln023NumInstallOpenLast24Months(final Integer iln023NumInstallOpenLast24Months) {
            this.iln023NumInstallOpenLast24Months = iln023NumInstallOpenLast24Months;
            return this;
        }

        public Builder withAll010NumTrdsOpenPaidClosed(final Integer all010NumTrdsOpenPaidClosed) {
            this.all010NumTrdsOpenPaidClosed = all010NumTrdsOpenPaidClosed;
            return this;
        }

        public Builder withRev071NumRevTradesNotDqorDerog(final Integer rev071NumRevTradesNotDqorDerog) {
            this.rev071NumRevTradesNotDqorDerog = rev071NumRevTradesNotDqorDerog;
            return this;
        }

        public Builder withLfi801FilInqEver(final Integer lfi801FilInqEver) {
            this.lfi801FilInqEver = lfi801FilInqEver;
            return this;
        }

        public Builder withAll104NumTrades30pLast6months(final Integer all104NumTrades30pLast6months) {
            this.all104NumTrades30pLast6months = all104NumTrades30pLast6months;
            return this;
        }

        public Builder withAll067NumTrdsCurr90pDpd6Months(final Integer all067NumTrdsCurr90pDpd6Months) {
            this.all067NumTrdsCurr90pDpd6Months = all067NumTrdsCurr90pDpd6Months;
            return this;
        }

        public Builder withAll002NumTradesOpenPaidClosInAct(final Integer all002NumTradesOpenPaidClosInAct) {
            this.all002NumTradesOpenPaidClosInAct = all002NumTradesOpenPaidClosInAct;
            return this;
        }

        public Builder withSatisfactoryRevolvingTrades(final Integer satisfactoryRevolvingTrades) {
            this.satisfactoryRevolvingTrades = satisfactoryRevolvingTrades;
            return this;
        }

        public Builder withStaggMap(final StaggMap staggMap) {
            this.staggMap = staggMap;
            return this;
        }

        public ExperianUserCredit build() {
            return new ExperianUserCredit(this);
        }
    }
}
