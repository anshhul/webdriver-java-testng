
package com.prosper.automation.configuration;

/**
 * @author grajasekar
 * @since 0.0.1
 */
public final class FileUpload {

    private String sourcePath;
    private String destinationDirectory;
    private String destinationFileName;
    private String fileContent;


    private FileUpload(final Builder builder) {
        sourcePath = builder.sourcePath;
        destinationDirectory = builder.destinationDirectory;
        destinationFileName = builder.destinationFileName;
        fileContent = builder.fileContent;
    }

    public String getFileContent() {
        return fileContent;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public String getDestinationDirectory() {
        return destinationDirectory;
    }

    public String getDestinationFileName() {
        return destinationFileName;
    }


    public static final class Builder {

        private String sourcePath;
        private String fileContent;
        private String destinationDirectory;
        private String destinationFileName;


        public Builder() {
        }

        public Builder withFileContent(final String fileContent) {
            this.fileContent = fileContent;
            return this;
        }

        public Builder withSourcePath(final String sourcePath) {
            this.sourcePath = sourcePath;
            return this;
        }

        public Builder withDestinationDirectory(final String destinationDirectory) {
            this.destinationDirectory = destinationDirectory;
            return this;
        }

        public Builder withDestinationFileName(final String destinationFileName) {
            this.destinationFileName = destinationFileName;
            return this;
        }

        public FileUpload build() {
            return new FileUpload(this);
        }
    }
}
