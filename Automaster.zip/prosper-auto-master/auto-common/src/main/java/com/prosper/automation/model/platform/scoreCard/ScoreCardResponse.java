
package com.prosper.automation.model.platform.scoreCard;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ScoreCardResponse {
    
    @JsonProperty("score_card_type")
    private String scoreCardType;
    @JsonProperty("probability_score")
    private Double probabilityScore;
}
