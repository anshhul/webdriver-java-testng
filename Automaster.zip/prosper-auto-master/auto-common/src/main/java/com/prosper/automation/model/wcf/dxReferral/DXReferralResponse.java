
package com.prosper.automation.model.wcf.dxReferral;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JacksonXmlRootElement(localName = "OfferResponse")
public final class DXReferralResponse {

    @JacksonXmlProperty(localName = "StatusCode")
    private Integer statusCode;
    @JacksonXmlProperty(localName = "EligibilityStatus")
    private String eligibilityStatus;
    @JacksonXmlProperty(localName = "IneligibilityReason")
    private String ineligibilityReason;
    @JacksonXmlProperty(localName = "Errors")
    private String errors;
    @JacksonXmlProperty(localName = "LoanOffers")
    private List<OfferDto> loanOffers;
    @JsonIgnore
    public String getIneligibilityReason() {
        return ineligibilityReason;
    }

    @JsonIgnore
    public List<OfferDto> getLoanOffers() {
        return loanOffers;
    }
}
