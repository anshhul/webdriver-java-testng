
package com.prosper.automation.model.platform.marketplace.properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.PhoneNumber;

/**
 * Created by rsubramanyam on 2/20/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ContactInfo {

    @JsonProperty("email")
    private String emailAddress;

    @JsonProperty("home_phone")
    private PhoneNumber homePhone;

    @JsonProperty("mobile_phone")
    private PhoneNumber mobilePhone;

    @JsonProperty("work_phone")
    private PhoneNumber workPhone;


    public ContactInfo() {
    }

    private ContactInfo(ContactInfoBuilder builder) {
        emailAddress = builder.emailAddress;
        homePhone = builder.homePhone;
        mobilePhone = builder.mobilePhone;
        workPhone = builder.workPhone;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public PhoneNumber getHomePhone() {
        return homePhone;
    }

    public PhoneNumber getMobilePhone() {
        return mobilePhone;
    }

    public PhoneNumber getWorkPhone() {
        return workPhone;
    }

    @Override
    public String toString() {
        return "ContactInfo{" +
                "emailAddress='" + emailAddress + '\'' +
                ", homePhone=" + homePhone +
                ", mobilePhone=" + mobilePhone +
                ", workPhone=" + workPhone +
                '}';
    }


    public static class ContactInfoBuilder {

        private String emailAddress;
        private PhoneNumber homePhone;
        private PhoneNumber mobilePhone;
        private PhoneNumber workPhone;


        public ContactInfoBuilder() {
        }

        public ContactInfoBuilder withEmailAddress(String val) {
            emailAddress = val;
            return this;
        }

        public ContactInfoBuilder withHomePhoneNumber(PhoneNumber homePhone) {
            this.homePhone = new PhoneNumber();
            this.homePhone.setPhoneNumber(homePhone.getPhoneNumber());
            this.homePhone.setAreaCode(homePhone.getAreaCode());
            return this;
        }

        public ContactInfoBuilder withWorkPhoneNumber(PhoneNumber workPhone) {
            this.workPhone = new PhoneNumber();
            this.workPhone.setPhoneNumber(workPhone.getPhoneNumber());
            this.workPhone.setAreaCode(workPhone.getAreaCode());
            return this;
        }

        public ContactInfoBuilder withMobilePhoneNumber(PhoneNumber mobilePhone) {
            this.mobilePhone = new PhoneNumber();
            this.mobilePhone.setPhoneNumber(mobilePhone.getPhoneNumber());
            this.mobilePhone.setAreaCode(mobilePhone.getAreaCode());
            return this;
        }

        public ContactInfo build() {
            return new ContactInfo(this);
        }
    }

}
