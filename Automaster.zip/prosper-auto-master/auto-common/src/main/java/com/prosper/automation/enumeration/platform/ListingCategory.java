
package com.prosper.automation.enumeration.platform;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum ListingCategory {
    
    NOT_AVAILABLE(0), DEBT_CONSOLIDATION(1), HOME_IMPROVEMENT(2), BUSINESS(3), PERSONAL_LOAN(4), STUDENT_USE(5), AUTO(6),
    OTHER(7), BABY_AND_ADOPTION_LOANS(8), BOAT(9), COSMETIC_PROCEDURES(10), ENGAGEMENT_RING_FINANCING(11), GREEN_LOANS(12),
    HOUSEHOLD_EXPENSES(13), LARGE_PURCHASES(14), MEDICAL_OR_DENTAL(15), MOTORCYCLE(16), RV(17), TAXES(18), VACATION(19),
    WEDDING_LOANS(20), SPECIAL_OCCASION_LOANS(21);
    
    private final int id;
    
    
    ListingCategory(final int id) {
        this.id = id;
    }
    
    public static int getInvalidId() {
        return values().length + 1;
    }
    
    public int getId() {
        return id;
    }
}
