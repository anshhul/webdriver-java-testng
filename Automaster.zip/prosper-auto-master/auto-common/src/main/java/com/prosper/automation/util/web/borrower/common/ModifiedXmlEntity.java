
package com.prosper.automation.util.web.borrower.common;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class ModifiedXmlEntity {

    private String emailAddress;
    private String requestBody;


    ModifiedXmlEntity(String emailAddress, String requestBody) {
        this.emailAddress = emailAddress;
        this.requestBody = requestBody;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }
}
