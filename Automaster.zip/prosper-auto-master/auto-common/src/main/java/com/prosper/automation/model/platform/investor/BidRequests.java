
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public class BidRequests {
    
    @JsonProperty("bid_requests")
    private List<Bids> bidRequests;
    
    
    public List<Bids> getBidRequests() {
        return bidRequests;
    }
    
    public void setBidRequests(List<Bids> bidRequests) {
        this.bidRequests = bidRequests;
    }
    
    
    public static class BidRequestsBuilder {

        private List<Bids> bidRequests;


        public BidRequestsBuilder bidRequests(List<Bids> value) {
            this.bidRequests = value;
            return this;
        }

        public BidRequests build() {
            final BidRequests result = new BidRequests();

            result.setBidRequests(bidRequests);
            return result;
        }
    }
    
    
    public static BidRequestsBuilder newBuilder() {
        return new BidRequestsBuilder();
    }
    
    public static BidRequestsBuilder buildUpon(BidRequests original) {
        final BidRequestsBuilder builder = newBuilder();
        builder.bidRequests(original.getBidRequests());
        return builder;
    }
    
}
