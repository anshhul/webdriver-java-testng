
package com.prosper.automation.model.platform.pmiAttributes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CalculatedPmiAttributes {
    
    @JsonProperty("dti_chg_4k_loan")
    private Double dtiChg4kLoan;
    @JsonProperty("dti_wo_prospLoan")
    private Double dtiWoProspLoan;
    @JsonProperty("dti_wo_prosp_loan_all_emp")
    private Double dtiWoProspLoanAllEmp;
    @JsonProperty("dti_leverage_stag_no_mg")
    private Double dtiLeverageStagNoMg;
    @JsonProperty("dti_chg_10k_36_mo_loan_all_emp")
    private Double dtiChg10K36MoLoanAllEmp;
    @JsonProperty("dti_leverage_stag")
    private Double dtiLeverageStag;
    @JsonProperty("score_x_drift")
    private Double scoreXDrift;


    public CalculatedPmiAttributes() {
    }
    
    private CalculatedPmiAttributes(final Builder builder) {
        dtiChg4kLoan = builder.dtiChg4kLoan;
        dtiWoProspLoan = builder.dtiWoProspLoan;
        dtiWoProspLoanAllEmp = builder.dtiWoProspLoanAllEmp;
        dtiLeverageStagNoMg = builder.dtiLeverageStagNoMg;
        dtiChg10K36MoLoanAllEmp = builder.dtiChg10K36MoLoanAllEmp;
        dtiLeverageStag = builder.dtiLeverageStag;
        scoreXDrift = builder.scoreXDrift;
    }
    
    
    public static final class Builder {
        
        private Double dtiChg4kLoan;
        private Double dtiWoProspLoan;
        private Double dtiWoProspLoanAllEmp;
        private Double dtiLeverageStagNoMg;
        private Double dtiChg10K36MoLoanAllEmp;
        private Double dtiLeverageStag;
        private Double scoreXDrift;
        
        
        public Builder() {
        }
        
        public Builder withDtiChg4kLoan(final Double dtiChg4kLoan) {
            this.dtiChg4kLoan = dtiChg4kLoan;
            return this;
        }
        
        public Builder withDtiWoProspLoan(final Double dtiWoProspLoan) {
            this.dtiWoProspLoan = dtiWoProspLoan;
            return this;
        }
        
        public Builder withDtiWoProspLoanAllEmp(final Double dtiWoProspLoanAllEmp) {
            this.dtiWoProspLoanAllEmp = dtiWoProspLoanAllEmp;
            return this;
        }
        
        public Builder withDtiLeverageStagNoMg(final Double dtiLeverageStagNoMg) {
            this.dtiLeverageStagNoMg = dtiLeverageStagNoMg;
            return this;
        }
        
        public Builder withDtiChg10K36MoLoanAllEmp(final Double dtiChg10K36MoLoanAllEmp) {
            this.dtiChg10K36MoLoanAllEmp = dtiChg10K36MoLoanAllEmp;
            return this;
        }
        
        public Builder withDtiLeverageStag(final Double dtiLeverageStag) {
            this.dtiLeverageStag = dtiLeverageStag;
            return this;
        }
        
        public Builder withScoreXDrift(final Double scoreXDrift) {
            this.scoreXDrift = scoreXDrift;
            return this;
        }
        
        public CalculatedPmiAttributes build() {
            return new CalculatedPmiAttributes(this);
        }
    }
}
