
package com.prosper.automation.enumeration.platform;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum UserType {
    USER(1), PROSPECT(2), LENDER(3);
    
    private final long userTypeId;
    
    
    UserType(final long userTypeId) {
        this.userTypeId = userTypeId;
    }
    
    public long getUserTypeId() {
        return userTypeId;
    }
}
