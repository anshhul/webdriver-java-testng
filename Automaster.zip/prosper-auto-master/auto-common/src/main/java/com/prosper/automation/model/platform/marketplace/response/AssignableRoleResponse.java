package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by rsubramanyam on 3/15/16.
 */

public class AssignableRoleResponse {

    @JsonProperty("role_name")
    private String role_name;

    @JsonProperty("role_id")
    private int role_id;

    @JsonProperty("role_description")
    private String role_description;

    @JsonProperty("is_role_active")
    private boolean is_role_active;
    @JsonIgnore
    public int getRole_id() {
        return role_id;
    }

    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }
    @JsonIgnore
    public String getRole_description() {
        return role_description;
    }

    public void setRole_description(String role_description) {
        this.role_description = role_description;
    }
    @JsonIgnore
    public boolean is_role_active() {
        return is_role_active;
    }

    public void setIs_role_active(boolean is_role_active) {
        this.is_role_active = is_role_active;
    }

    @JsonIgnore
    public String getRole_name() {
        return this.role_name;
    }

    public void setRole_name(String role_name) {
        this.role_name = role_name;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AssignableRoleResponse that = (AssignableRoleResponse) o;
        return role_id == that.role_id &&
                is_role_active == that.is_role_active &&
                Objects.equal(role_name, that.role_name) &&
                Objects.equal(role_description, that.role_description);
    }

    @Override public int hashCode() {
        return Objects.hashCode(role_name, role_id, role_description, is_role_active);
    }
}
