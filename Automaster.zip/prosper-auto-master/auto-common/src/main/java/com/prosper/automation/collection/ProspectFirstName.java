
package com.prosper.automation.collection;

import com.prosper.automation.model.platform.prospect.Prospect;

import org.apache.commons.collections.Transformer;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public class ProspectFirstName implements Transformer {
    
    @Override
    public Object transform(Object input) {
        return ((Prospect) input).getPersonalInfo().getFirstName();
    }
}
