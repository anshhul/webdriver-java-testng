
package com.prosper.automation.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class TimeUtilities {

    /**
     * Get current date and time in specified format and timezone
     *
     * @param format Desired format for e.g. MM-DD-YYYY
     * @param timeZone Desired TimeZone e.g America/Los_Angeles
     * @return Current date in the format specified
     */
    public static String getCurrentTimeInFormat(String format, String timeZone) {
        DateFormat df = new SimpleDateFormat(format);
        df.setTimeZone(TimeZone.getTimeZone(timeZone));
        String date = df.format(new Date());
        return date;
    }
}
