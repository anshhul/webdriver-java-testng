package com.prosper.automation.model.platform.prospect;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 8/2/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CoBranding {
	@JsonProperty("plp_content_id")
	private Integer plpContentId;

	@JsonProperty("campaign_program_id")
	private String campaignProgramId;

	@JsonProperty("plp_content")
	private String plpContent;

	@JsonProperty("content_type")
	private String contentType;

	@JsonProperty("plp_content_label_id")
	private Integer plpContentLabelId;

	@JsonProperty("plp_content_label")
	private String plpContentLabel;

	@JsonProperty("is_visa_promotion")
	private Boolean isVisaPromotion;

	@JsonProperty("is_active")
	private Boolean isActive;

	@JsonProperty("campaign_source_id")
	private String campaignSourceId;

	@JsonProperty("ref_ac")
	private String refAc;

	@JsonProperty("ref_mc")
	private String refMc;

	@JsonProperty("campaign_id")
	private String campaignId;

	@JsonProperty("created_date")
	private Date createdDate;

	@JsonProperty("modified_date")
	private Date modifiedDate;

	public CoBranding() {
	}

	private CoBranding(Builder builder) {
		plpContentId = builder.plpContentId;
		campaignProgramId = builder.campaignProgramId;
		plpContent = builder.plpContent;
		contentType = builder.contentType;
		plpContentLabelId = builder.plpContentLabelId;
		plpContentLabel = builder.plpContentLabel;
		isVisaPromotion = builder.isVisaPromotion;
		isActive = builder.isActive;
		campaignSourceId = builder.campaignSourceId;
		refAc = builder.refAc;
		refMc = builder.refMc;
		campaignId = builder.campaignId;
		createdDate = builder.createdDate;
		modifiedDate = builder.modifiedDate;
	}

	public static final class Builder {

		private Integer plpContentId;
		private String campaignProgramId;
		private String plpContent;
		private String contentType;
		private Integer plpContentLabelId;
		private String plpContentLabel;
		private Boolean isVisaPromotion;
		private Boolean isActive;
		private String campaignSourceId;
		private String refAc;
		private String refMc;
		private String campaignId;
		private Date createdDate;
		private Date modifiedDate;

		public Builder() {
		}

		public Builder withPlpContentId(Integer val) {
			plpContentId = val;
			return this;
		}

		public Builder withCampaignProgramId(String val) {
			campaignProgramId = val;
			return this;
		}

		public Builder withPlpContent(String val) {
			plpContent = val;
			return this;
		}

		public Builder withContentType(String val) {
			contentType = val;
			return this;
		}

		public Builder withPlpContentLabelId(Integer val) {
			plpContentLabelId = val;
			return this;
		}

		public Builder withPlpContentLabel(String val) {
			plpContentLabel = val;
			return this;
		}

		public Builder withIsVisaPromotion(Boolean val) {
			isVisaPromotion = val;
			return this;
		}

		public Builder withIsActive(Boolean val) {
			isActive = val;
			return this;
		}

		public Builder withCampaignSourceId(String val) {
			campaignSourceId = val;
			return this;
		}

		public Builder withRefAc(String val) {
			refAc = val;
			return this;
		}

		public Builder withRefMc(String val) {
			refMc = val;
			return this;
		}

		public Builder withCampaignId(String val) {
			campaignId = val;
			return this;
		}

		public Builder withCreatedDate(Date val) {
			createdDate = val;
			return this;
		}

		public Builder withModifiedDate(Date val) {
			modifiedDate = val;
			return this;
		}

		public CoBranding build() {
			return new CoBranding(this);
		}
	}
}
