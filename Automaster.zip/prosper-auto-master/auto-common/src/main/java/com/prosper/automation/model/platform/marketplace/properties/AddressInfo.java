
package com.prosper.automation.model.platform.marketplace.properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by rsubramanyam on 2/21/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressInfo {

    @JsonProperty("ownership_type")
    private String ownershipType;

    @JsonProperty("address_verification_enabled")
    private Boolean addressVerificationEnabled;

    @JsonProperty("street")
    private String street;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("zip_code")
    private String zipCode;

    @JsonProperty("time_at_address")
    private Duration timeAtAddress;

    @JsonProperty("monthly_housing_payment")
    private Double monthlyHousingPayment;


    public AddressInfo() {
    }

    private AddressInfo(AddressForMarketplaceinfoBuilder builder) {
        addressVerificationEnabled = builder.addressVerificationEnabled;
        street = builder.street;
        city = builder.city;
        state = builder.state;
        zipCode = builder.zipCode;
        timeAtAddress = builder.timeAtAddress;
        ownershipType = builder.ownershipType;
        monthlyHousingPayment = builder.monthlyHousingPayment;
    }

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AddressInfo that = (AddressInfo) o;
        return Objects.equal(street.trim().toLowerCase(), that.street.trim().toLowerCase())
                && Objects.equal(city.toLowerCase(), that.city.toLowerCase())
                && Objects.equal(state.toLowerCase(), that.state.toLowerCase())
                && Objects.equal(zipCode, that.zipCode);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(city, street, state, zipCode);
    }

    @Override
    public String toString() {
        return "AddressInfo{" +
                "street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zipCode='" + zipCode + '\'' +
                '}';
    }


    public static class AddressForMarketplaceinfoBuilder {

        private String street;
        private String city;
        private String state;
        private String zipCode;
        private Boolean addressVerificationEnabled;
        private Duration timeAtAddress;
        private String ownershipType;
        private Double monthlyHousingPayment;


        public AddressForMarketplaceinfoBuilder() {
        }

        public AddressForMarketplaceinfoBuilder withAddressVerificationEnabled(Boolean val) {
            addressVerificationEnabled = val;
            return this;
        }

        public AddressForMarketplaceinfoBuilder withStreet(String val) {
            street = val;
            return this;
        }

        public AddressForMarketplaceinfoBuilder withCity(String val) {
            city = val;
            return this;
        }

        public AddressForMarketplaceinfoBuilder withState(String val) {
            state = val;
            return this;
        }

        public AddressForMarketplaceinfoBuilder withZip(String val) {
            zipCode = val;
            return this;
        }

        public AddressForMarketplaceinfoBuilder withTimeAtAddress(String months, String years) {
            timeAtAddress = new Duration(months, years);
            return this;
        }

        public AddressForMarketplaceinfoBuilder withMonthlyHousingPayment(Double val) {
            monthlyHousingPayment = val;
            return this;
        }

        public AddressInfo build() {
            return new AddressInfo(this);
        }

        public AddressForMarketplaceinfoBuilder withOwnershipType(String ownershipType) {
            this.ownershipType = ownershipType;
            return this;
        }
    }
}
