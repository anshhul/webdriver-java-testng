
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.Date;
import java.util.List;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CampaignSource {

    @JsonProperty("campaign_source_id")
    private String campaignSourceId;
    @JsonProperty("business_contact_id")
    private Integer businessContactId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("partner_code")
    private String partnerCode;
    @JsonProperty("legacy_id")
    private Integer legacyId;
    @JsonProperty("legacy_channel")
    private String legacyChannel;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("modified_date")
    private String modifiedDate;
    @JsonProperty("company_name")
    private String companyName;
    @JsonProperty("contact_name")
    private String contactName;
    @JsonProperty("contact_email")
    private String contactEmail;
    @JsonProperty("contact_phone")
    private String contactPhone;
    @JsonProperty("business_contact_legacy_id")
    private Integer businessContactLegacyId;
    @JsonProperty("campaign_source_type_id")
    private Integer campaignSourceTypeId;
    @JsonProperty("cobranding_info")
    private List<CoBranding> plpContent;


    public CampaignSource() {
    }

    private CampaignSource(Builder builder) {
        campaignSourceId = builder.campaignSourceId;
        businessContactId = builder.businessContactId;
        name = builder.name;
        partnerCode = builder.partnerCode;
        legacyId = builder.legacyId;
        legacyChannel = builder.legacyChannel;
        createdDate = builder.createdDate;
        modifiedDate = builder.modifiedDate;
        companyName = builder.companyName;
        contactName = builder.contactName;
        contactEmail = builder.contactEmail;
        contactPhone = builder.contactPhone;
        businessContactLegacyId = builder.businessContactLegacyId;
        campaignSourceTypeId = builder.campaignSourceTypeId;
        plpContent = builder.plpContent;
    }

    @JsonIgnore
    public String getCampaignSourceId() {
        return campaignSourceId;
    }

    @JsonIgnore
    public Integer getBusinessContactId() {
        return businessContactId;
    }

    @JsonIgnore
    public String getName() {
        return name;
    }

    @JsonIgnore
    public String getPartnerCode() {
        return partnerCode;
    }

    @JsonIgnore
    public Integer getLegacyId() {
        return legacyId;
    }

    @JsonIgnore
    public String getLegacyChannel() {
        return legacyChannel;
    }

    @JsonIgnore
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonIgnore
    public String getModifiedDate() {
        return modifiedDate;
    }

    @JsonIgnore
    public String getCompanyName() {
        return companyName;
    }

    @JsonIgnore
    public String getContactName() {
        return contactName;
    }

    @JsonIgnore
    public String getContactEmail() {
        return contactEmail;
    }

    @JsonIgnore
    public String getContactPhone() {
        return contactPhone;
    }

    @JsonIgnore
    public Integer getBusinessContactLegacyId() {
        return businessContactLegacyId;
    }

    @JsonIgnore
    public Integer getCampaignSourceTypeId() {
        return campaignSourceTypeId;
    }

    @JsonIgnore
    public List<CoBranding> getPlpContent() {
        return plpContent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CampaignSource that = (CampaignSource) o;
        return Objects.equal(getName(), that.getName()) &&
                Objects.equal(getCompanyName(), that.getCompanyName()) &&
                Objects.equal(getContactName(), that.getContactName()) &&
                Objects.equal(getContactEmail(), that.getContactEmail()) &&
                Objects.equal(getContactPhone(), that.getContactPhone());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getName(), getCompanyName(), getContactName(), getContactEmail(), getContactPhone());
    }


    public static final class Builder {

        private String campaignSourceId;
        private Integer businessContactId;
        private String name;
        private String partnerCode;
        private Integer legacyId;
        private String legacyChannel;
        private String createdDate;
        private String modifiedDate;
        private String companyName;
        private String contactName;
        private String contactEmail;
        private String contactPhone;
        private Integer businessContactLegacyId;
        private Integer campaignSourceTypeId;
        private List<CoBranding> plpContent;


        public Builder() {
        }

        public Builder withCampaignSourceId(String val) {
            campaignSourceId = val;
            return this;
        }

        public Builder withBusinessContactId(Integer val) {
            businessContactId = val;
            return this;
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withPartnerCode(String val) {
            partnerCode = val;
            return this;
        }

        public Builder withLegacyId(Integer val) {
            legacyId = val;
            return this;
        }

        public Builder withLegacyChannel(String val) {
            legacyChannel = val;
            return this;
        }

        public Builder withCreatedDate(String val) {
            createdDate = val;
            return this;
        }

        public Builder withModifiedDate(String val) {
            modifiedDate = val;
            return this;
        }

        public Builder withCompanyName(String val) {
            companyName = val;
            return this;
        }

        public Builder withContactName(String val) {
            contactName = val;
            return this;
        }

        public Builder withContactEmail(String val) {
            contactEmail = val;
            return this;
        }

        public Builder withContactPhone(String val) {
            contactPhone = val;
            return this;
        }

        public Builder withBusinessContactLegacyId(Integer val) {
            businessContactLegacyId = val;
            return this;
        }

        public Builder withCampaignSourceTypeId(Integer val) {
            campaignSourceTypeId = val;
            return this;
        }

        public Builder withPlpContent(List<CoBranding> val) {
            plpContent = val;
            return this;
        }

        public CampaignSource build() {
            return new CampaignSource(this);
        }
    }
}
