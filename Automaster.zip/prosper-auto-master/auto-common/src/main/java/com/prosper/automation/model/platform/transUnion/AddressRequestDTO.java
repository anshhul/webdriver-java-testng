
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class AddressRequestDTO {

    @JsonProperty("address_status")
    private String addressStatus;
    @JsonProperty("unit_type")
    private String unitType;
    @JsonProperty("unit_number")
    private String unitNumber;
    @JsonProperty("po_box")
    private String poBox;
    @JsonProperty("street_number")
    private String streetNumber;
    @JsonProperty("street_name")
    private String streetName;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip_code")
    private String zipCode;
    @JsonProperty("zip_extension")
    private String zipExtension;
    @JsonProperty("country")
    private String country;
    @JsonProperty("county")
    private County county;


    public AddressRequestDTO() {
    }

    private AddressRequestDTO(Builder builder) {
        setAddressStatus(builder.addressStatus);
        setUnitType(builder.unitType);
        setUnitNumber(builder.unitNumber);
        setPoBox(builder.poBox);
        setStreetNumber(builder.number);
        setStreetName(builder.streetName);
        setCity(builder.city);
        setState(builder.state);
        setZipCode(builder.zipCode);
        setZipExtension(builder.zipExtension);
        setCountry(builder.country);
        setCounty(builder.county);
    }

    @JsonIgnore
    public String getAddressStatus() {
        return addressStatus;
    }

    public void setAddressStatus(String addressStatus) {
        this.addressStatus = addressStatus;
    }

    @JsonIgnore
    public String getUnitType() {
        return unitType;
    }

    public void setUnitType(String unitType) {
        this.unitType = unitType;
    }

    @JsonIgnore
    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    @JsonIgnore
    public String getPoBox() {
        return poBox;
    }

    public void setPoBox(String poBox) {
        this.poBox = poBox;
    }

    @JsonIgnore
    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    @JsonIgnore
    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @JsonIgnore
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @JsonIgnore
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @JsonIgnore
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @JsonIgnore
    public String getZipExtension() {
        return zipExtension;
    }

    public void setZipExtension(String zipExtension) {
        this.zipExtension = zipExtension;
    }

    @JsonIgnore
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @JsonIgnore
    public County getCounty() {
        return county;
    }

    public void setCounty(County county) {
        this.county = county;
    }


    public static final class Builder {

        private String addressStatus;
        private String unitType;
        private String unitNumber;
        private String poBox;
        private String number;
        private String streetName;
        private String city;
        private String state;
        private String zipCode;
        private String zipExtension;
        private String country;
        private County county;


        public Builder() {
        }

        public Builder withAddressStatus(String val) {
            addressStatus = val;
            return this;
        }

        public Builder withUnitType(String val) {
            unitType = val;
            return this;
        }

        public Builder withUnitNumber(String val) {
            unitNumber = val;
            return this;
        }

        public Builder withPoBox(String val) {
            poBox = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withStreetName(String val) {
            streetName = val;
            return this;
        }

        public Builder withCity(String val) {
            city = val;
            return this;
        }

        public Builder withState(String val) {
            state = val;
            return this;
        }

        public Builder withZipCode(String val) {
            zipCode = val;
            return this;
        }

        public Builder withZipExtension(String val) {
            zipExtension = val;
            return this;
        }

        public Builder withCountry(String val) {
            country = val;
            return this;
        }

        public Builder withCounty(County val) {
            county = val;
            return this;
        }

        public AddressRequestDTO build() {
            return new AddressRequestDTO(this);
        }
    }
}
