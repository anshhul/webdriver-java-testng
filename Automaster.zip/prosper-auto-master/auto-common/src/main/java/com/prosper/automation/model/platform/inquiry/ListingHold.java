
package com.prosper.automation.model.platform.inquiry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"workflow_type_id", "description", "mnemonic"})
public final class ListingHold {
    
    @JsonProperty("workflow_type_id")
    private Integer workflowTypeId;
    @JsonProperty("description")
    private String description;
    @JsonProperty("mnemonic")
    private String mnemonic;
    
    
    public ListingHold() {
    }
    
    private ListingHold(final Builder builder) {
        workflowTypeId = builder.workflowTypeId;
        description = builder.description;
        mnemonic = builder.mnemonic;
    }
    
    @Override
    public String toString() {
        return "ListingHold{" + "workflowTypeId=" + workflowTypeId + ", description='" + description + '\'' + ", mnemonic='"
                + mnemonic + '\'' + '}';
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final ListingHold that = (ListingHold) o;
        return Objects.equal(workflowTypeId, that.workflowTypeId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(workflowTypeId, description, mnemonic);
    }
    
    
    public static final class Builder {
        
        private Integer workflowTypeId;
        private String description;
        private String mnemonic;
        
        
        public Builder() {
        }
        
        public Builder withWorkflowTypeId(final Integer workflowTypeId) {
            this.workflowTypeId = workflowTypeId;
            return this;
        }
        
        public Builder withDescription(final String description) {
            this.description = description;
            return this;
        }
        
        public Builder withMnemonic(final String mnemonic) {
            this.mnemonic = mnemonic;
            return this;
        }
        
        public ListingHold build() {
            return new ListingHold(this);
        }
    }
}
