
package com.prosper.automation.model.platform.experian;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ExperianCreditProfileData {

    @JsonProperty("completionCode")
    private String completionCode;
    @JsonProperty("experianAAReasons")
    private List<Integer> experianAAR;
}
