
package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;

import java.util.List;

/**
 * Created by rsubramanyam on 2/24/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetOffersResponse {

    @JsonProperty("identification")
    private IdentificationInfo identififcation;
    @JsonProperty("referral_code")
    private String referralCode;
    @JsonProperty("errors")
    private List<ValidationErrorResponse> errors;
    @JsonProperty("offers")
    private List<OfferDetails> offers;
    @JsonProperty("status")
    private String status;


    @JsonIgnore
    public IdentificationInfo getIdentification() {
        return identififcation;
    }

    @JsonIgnore
    public String getReferralCode() {
        return referralCode;
    }

    @JsonIgnore
    public List<OfferDetails> getOffers() {
        return offers;
    }

    @JsonIgnore
    public String getStatus() {
        return status;
    }

    @JsonIgnore
    public List<ValidationErrorResponse> getErrors() {
        return errors;
    }
}
