package com.prosper.automation.util;

/**
 * Created by rsubramanyam on 6/3/16.
 */
public final class MonthlyPaymentCalculator {
    public static Double calculateMonthlyPayment(Double loanAmount, Double borrowerRate, int termMonths) {
        Double monthlyPayment = null;

        if (borrowerRate == null || borrowerRate.compareTo(0d) == 0) {
            monthlyPayment = loanAmount / termMonths;
        } else {

            // Monthly interest rate
            // is the yearly rate divided by 12
            double monthlyRate = borrowerRate / 12.0;
            monthlyPayment = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, 0 - termMonths));
        }

        return monthlyPayment;
    }
}
