package com.prosper.automation.enumeration.platform;

/**
 * 
 * @author Sonali Phatak
 *
 */
public enum ProviderStatus {
	ACTIVE, PROBATIONARY, INACTIVE, DEFAULT_COMPLIANCE_STATUS, UNDER_REVIEW
}
