
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.google.common.base.Objects;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class BankAccountInfo {

    @JsonProperty("account_id")
    private Long accountId;
    @JsonProperty("bank_name")
    private String bankName;
    @JsonProperty("bank_account_ownership_type")
    private BankAccountOwnershipType bankAccountOwnershipType;
    @JsonProperty("bank_account_type")
    private BankAccountType bankAccountType;
    @JsonProperty("is_primary")
    private Boolean isPrimary;
    @JsonProperty("withdrawal_type")
    private PaymentOption withdrawalType;
    @JsonProperty("routing_number")
    private String routingNumber;
    @JsonProperty("account_number")
    private String accountNumber;
    @JsonProperty("first_account_holder_name")
    private String firstAccountHolderName;
    @JsonProperty("second_account_holder_name")
    private String secondAccountHolderName;


    public BankAccountInfo() {
    }

    private BankAccountInfo(final Builder builder) {
        accountId = builder.accountId;
        setBankName(builder.bankName);
        setBankAccountOwnershipType(builder.bankAccountOwnershipType);
        setBankAccountType(builder.bankAccountType);
        setIsPrimary(builder.isPrimary);
        setWithdrawalType(builder.withdrawalType);
        setRoutingNumber(builder.routingNumber);
        setAccountNumber(builder.accountNumber);
        setFirstAccountHolderName(builder.firstAccountHolderName);
        setSecondAccountHolderName(builder.secondAccountHolderName);
    }

    public PaymentOption getWithdrawalType() {
        return withdrawalType;
    }

    public void setWithdrawalType(PaymentOption withdrawalType) {
        this.withdrawalType = withdrawalType;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getRoutingNumber() {
        return routingNumber;
    }

    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }

    public Boolean getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(Boolean isPrimary) {
        this.isPrimary = isPrimary;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getSecondAccountHolderName() {
        return secondAccountHolderName;
    }

    public void setSecondAccountHolderName(String secondAccountHolderName) {
        this.secondAccountHolderName = secondAccountHolderName;
    }

    public BankAccountOwnershipType getBankAccountOwnershipType() {
        return bankAccountOwnershipType;
    }

    public void setBankAccountOwnershipType(
                                            BankAccountOwnershipType bankAccountOwnershipType) {
        this.bankAccountOwnershipType = bankAccountOwnershipType;
    }

    public BankAccountType getBankAccountType() {
        return bankAccountType;
    }

    public void setBankAccountType(BankAccountType bankAccountType) {
        this.bankAccountType = bankAccountType;
    }

    public String getFirstAccountHolderName() {
        return firstAccountHolderName;
    }

    public void setFirstAccountHolderName(String firstAccountHolderName) {
        this.firstAccountHolderName = firstAccountHolderName;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BankAccountInfo that = (BankAccountInfo) o;
        return Objects.equal(bankName, that.bankName) && Objects.equal(secondAccountHolderName, that.secondAccountHolderName)
                && Objects.equal(bankAccountOwnershipType, that.bankAccountOwnershipType)
                && Objects.equal(bankAccountType, that.bankAccountType)
                && Objects.equal(firstAccountHolderName, that.firstAccountHolderName);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(bankName, secondAccountHolderName, bankAccountOwnershipType, bankAccountType,
                firstAccountHolderName);
    }

    @Override public String toString() {
        return "BankAccountInfo{" +
                "accountId=" + accountId +
                ", bankName='" + bankName + '\'' +
                ", bankAccountOwnershipType=" + bankAccountOwnershipType +
                ", bankAccountType=" + bankAccountType +
                ", isPrimary=" + isPrimary +
                ", withdrawalType=" + withdrawalType +
                ", routingNumber='" + routingNumber + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", firstAccountHolderName='" + firstAccountHolderName + '\'' +
                ", secondAccountHolderName='" + secondAccountHolderName + '\'' +
                '}';
    }

    public void setAccountId(final Long accountId) {
        this.accountId = accountId;
    }


    public enum PaymentOption {

        EFT("EFT"), DRAFT("DRAFT"), MANUAL("MANUAL");

        private final String value;


        PaymentOption(final String value) {
            this.value = value;
        }
    }

    public enum BankAccountOwnershipType {

        INDIVIDUAL("INDIVIDUAL"), JOINT("JOINT"), BUSINESS("BUSINESS"), ;

        private static Map<String, BankAccountOwnershipType> constants = new HashMap();


        static {
            for (BankAccountInfo.BankAccountOwnershipType c : values()) {
                constants.put(c.value, c);
            }
        }


        private final String value;


        private BankAccountOwnershipType(final String value) {
            this.value = value;
        }

        @JsonCreator
        public static BankAccountInfo.BankAccountOwnershipType fromValue(final String value) {
            BankAccountInfo.BankAccountOwnershipType constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @JsonValue
        @Override
        public String toString() {
            return this.value;
        }

    }

    public enum BankAccountType {

        CHECKING("CHECKING"), SAVINGS("SAVINGS"), PREPAID_CARD("PREPAID_CARD");

        private static Map<String, BankAccountType> constants = new HashMap();


        static {
            for (BankAccountInfo.BankAccountType c : values()) {
                constants.put(c.value, c);
            }
        }


        private final String value;


        private BankAccountType(final String value) {
            this.value = value;
        }

        @JsonCreator
        public static BankAccountInfo.BankAccountType fromValue(final String value) {
            BankAccountInfo.BankAccountType constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @JsonValue
        @Override
        public String toString() {
            return this.value;
        }
    }

    public static final class Builder {

        private Long accountId;
        private String bankName;
        private BankAccountOwnershipType bankAccountOwnershipType;
        private BankAccountType bankAccountType;
        private Boolean isPrimary;
        private PaymentOption withdrawalType;
        private String routingNumber;
        private String accountNumber;
        private String firstAccountHolderName;
        private String secondAccountHolderName;


        public Builder() {
        }

        public Builder withAccountId(final Long accountId) {
            this.accountId = accountId;
            return this;
        }

        public Builder withBankName(final String bankName) {
            this.bankName = bankName;
            return this;
        }

        public Builder withBankAccountOwnershipType(final BankAccountOwnershipType bankAccountOwnershipType) {
            this.bankAccountOwnershipType = bankAccountOwnershipType;
            return this;
        }

        public Builder withBankAccountType(final BankAccountType bankAccountType) {
            this.bankAccountType = bankAccountType;
            return this;
        }

        public Builder withIsPrimary(final Boolean isPrimary) {
            this.isPrimary = isPrimary;
            return this;
        }

        public Builder withWithdrawalType(final PaymentOption withdrawalType) {
            this.withdrawalType = withdrawalType;
            return this;
        }

        public Builder withRoutingNumber(final String routingNumber) {
            this.routingNumber = routingNumber;
            return this;
        }

        public Builder withAccountNumber(final String accountNumber) {
            this.accountNumber = accountNumber;
            return this;
        }

        public Builder withFirstAccountHolderName(final String firstAccountHolderName) {
            this.firstAccountHolderName = firstAccountHolderName;
            return this;
        }

        public Builder withSecondAccountHolderName(final String secondAccountHolderName) {
            this.secondAccountHolderName = secondAccountHolderName;
            return this;
        }

        public BankAccountInfo build() {
            return new BankAccountInfo(this);
        }
    }
}
