
package com.prosper.automation.model.wcf.dxReferral;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JacksonXmlRootElement(localName = "OfferRequestDto")
public final class DXReferralRequest {

    @JacksonXmlProperty(localName = "SubProgramId")
    private Long subProgramId;
    @JacksonXmlProperty(localName = "FirstName")
    private String firstName;
    @JacksonXmlProperty(localName = "MiddleInitial")
    private String middleInitial;
    @JacksonXmlProperty(localName = "LastName")
    private String lastName;
    @JacksonXmlProperty(localName = "Suffix")
    private String suffix;
    @JacksonXmlProperty(localName = "EmailAddress")
    private String emailAddress;
    @JacksonXmlProperty(localName = "DateOfBirth")
    private String dateOfBirth;
    @JacksonXmlProperty(localName = "Street")
    private String street;
    @JacksonXmlProperty(localName = "City")
    private String city;
    @JacksonXmlProperty(localName = "State")
    private String state;
    @JacksonXmlProperty(localName = "Zipcode")
    private String zipCode;
    @JacksonXmlProperty(localName = "LoanAmount")
    private String loanAmount;
    @JacksonXmlProperty(localName = "LoanPurposeId")
    private Long loanPurposeId;
    @JacksonXmlProperty(localName = "YearlyIncome")
    private String yearlyIncome;
    @JacksonXmlProperty(localName = "YearlyIncomeVerifiable")
    private Boolean yearlyIncomeVerifiable;
    @JacksonXmlProperty(localName = "EmploymentStatusId")
    private Long employmentStatusId;
    @JacksonXmlProperty(localName = "SelfReportedCreditScore")
    private Long selfReportedCreditScore;
    @JacksonXmlProperty(localName = "HomePhoneAreaCode")
    private String homePhoneAreaCode;
    @JacksonXmlProperty(localName = "HomePhoneNumber")
    private String homePhoneNumber;
    @JacksonXmlProperty(localName = "MobilePhoneAreaCode")
    private String mobilePhoneAreaCode;
    @JacksonXmlProperty(localName = "MobilePhoneNumber")
    private String mobilePhoneNumber;
    @JacksonXmlProperty(localName = "WorkPhoneAreaCode")
    private String workPhoneAreaCode;
    @JacksonXmlProperty(localName = "WorkPhoneNumber")
    private String workPhoneNumber;
    @JacksonXmlProperty(localName = "SSN")
    private String ssn;
    @JacksonXmlProperty(localName = "EmployerName")
    private String employerName;
    @JacksonXmlProperty(localName = "EmployerPhoneAreaCode")
    private String employerPhoneAreaCode;
    @JacksonXmlProperty(localName = "EmployerPhoneNumber")
    private String employerPhoneNumber;
    @JacksonXmlProperty(localName = "EmploymentMonth")
    private Integer employmentMonth;
    @JacksonXmlProperty(localName = "EmploymentYear")
    private Integer employmentYear;
    @JacksonXmlProperty(localName = "OccupationalId")
    private Long occupationalId;
    @JacksonXmlProperty(localName = "BankName")
    private String bankName;
    @JacksonXmlProperty(localName = "FirstAccountHolderName")
    private String firstAccountHolderName;
    @JacksonXmlProperty(localName = "AccountNumber")
    private String accountNumber;
    @JacksonXmlProperty(localName = "RoutingNumber")
    private String routingNumber;

    public DXReferralRequest() {}
    public String getBankName() {
        return bankName;
    }

    public String getLoanAmount() {
        return loanAmount;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getSsn() {
        return ssn;
    }

    public Integer getEmploymentMonth() {
        return employmentMonth;
    }

    public Integer getEmploymentYear() {
        return employmentYear;
    }

    public String getEmployerName() {
        return employerName;
    }

    public Long getOccupationalId() {
        return occupationalId;
    }

    public String getHomePhoneAreaCode() {
        return homePhoneAreaCode;
    }

    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    public String getMobilePhoneAreaCode() {
        return mobilePhoneAreaCode;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public String getWorkPhoneAreaCode() {
        return workPhoneAreaCode;
    }

    public String getWorkPhoneNumber() {
        return workPhoneNumber;
    }

    public String getEmployerPhoneAreaCode() {
        return employerPhoneAreaCode;
    }

    public String getEmployerPhoneNumber() {
        return employerPhoneNumber;
    }

    private DXReferralRequest(final Builder builder) {
        subProgramId = builder.subProgramId;
        firstName = builder.firstName;
        middleInitial = builder.middleInitial;
        lastName = builder.lastName;
        suffix = builder.suffix;
        emailAddress = builder.emailAddress;
        dateOfBirth = builder.dateOfBirth;
        street = builder.street;
        city = builder.city;
        state = builder.state;
        zipCode = builder.zipCode;
        loanAmount = builder.loanAmount;
        loanPurposeId = builder.loanPurposeId;
        yearlyIncome = builder.yearlyIncome;
        yearlyIncomeVerifiable = builder.yearlyIncomeVerifiable;
        employmentStatusId = builder.employmentStatusId;
        selfReportedCreditScore = builder.selfReportedCreditScore;
        homePhoneAreaCode = builder.homePhoneAreaCode;
        homePhoneNumber = builder.homePhoneNumber;
        mobilePhoneAreaCode = builder.mobilePhoneAreaCode;
        mobilePhoneNumber = builder.mobilePhoneNumber;
        workPhoneAreaCode = builder.workPhoneAreaCode;
        workPhoneNumber = builder.workPhoneNumber;
        ssn = builder.ssn;
        employerName = builder.employerName;
        employerPhoneAreaCode = builder.employerPhoneAreaCode;
        employerPhoneNumber = builder.employerPhoneNumber;
        employmentMonth = builder.employmentMonth;
        employmentYear = builder.employmentYear;
        occupationalId = builder.occupationalId;
        bankName = builder.bankName;
        firstAccountHolderName = builder.firstAccountHolderName;
        accountNumber = builder.accountNumber;
        routingNumber = builder.routingNumber;
    }


    public static final class Builder {

        private Long subProgramId;
        private String firstName;
        private String middleInitial;
        private String lastName;
        private String suffix;
        private String emailAddress;
        private String dateOfBirth;
        private String street;
        private String city;
        private String state;
        private String zipCode;
        private String loanAmount;
        private Long loanPurposeId;
        private String yearlyIncome;
        private Boolean yearlyIncomeVerifiable;
        private Long employmentStatusId;
        private Long selfReportedCreditScore;
        private String homePhoneAreaCode;
        private String homePhoneNumber;
        private String mobilePhoneAreaCode;
        private String mobilePhoneNumber;
        private String workPhoneAreaCode;
        private String workPhoneNumber;
        private String ssn;
        private String employerName;
        private String employerPhoneAreaCode;
        private String employerPhoneNumber;
        private Integer employmentMonth;
        private Integer employmentYear;
        private Long occupationalId;
        private String bankName;
        private String firstAccountHolderName;
        private String accountNumber;
        private String routingNumber;


        public Builder() {
        }

        public Builder withSubProgramId(final Long subProgramId) {
            this.subProgramId = subProgramId;
            return this;
        }

        public Builder withFirstName(final String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withMiddleInitial(final String middleInitial) {
            this.middleInitial = middleInitial;
            return this;
        }

        public Builder withLastName(final String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withSuffix(final String suffix) {
            this.suffix = suffix;
            return this;
        }

        public Builder withEmailAddress(final String emailAddress) {
            this.emailAddress = emailAddress;
            return this;
        }

        public Builder withDateOfBirth(final String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
            return this;
        }

        public Builder withStreet(final String street) {
            this.street = street;
            return this;
        }

        public Builder withCity(final String city) {
            this.city = city;
            return this;
        }

        public Builder withState(final String state) {
            this.state = state;
            return this;
        }

        public Builder withZipCode(final String zipCode) {
            this.zipCode = zipCode;
            return this;
        }

        public Builder withLoanAmount(final String loanAmount) {
            this.loanAmount = loanAmount;
            return this;
        }

        public Builder withLoanPurposeId(final Long loanPurposeId) {
            this.loanPurposeId = loanPurposeId;
            return this;
        }

        public Builder withYearlyIncome(final String yearlyIncome) {
            this.yearlyIncome = yearlyIncome;
            return this;
        }

        public Builder withYearlyIncomeVerifiable(final Boolean yearlyIncomeVerifiable) {
            this.yearlyIncomeVerifiable = yearlyIncomeVerifiable;
            return this;
        }

        public Builder withEmploymentStatusId(final Long employmentStatusId) {
            this.employmentStatusId = employmentStatusId;
            return this;
        }

        public Builder withSelfReportedCreditScore(final Long selfReportedCreditScore) {
            this.selfReportedCreditScore = selfReportedCreditScore;
            return this;
        }

        public Builder withHomePhoneAreaCode(final String homePhoneAreaCode) {
            this.homePhoneAreaCode = homePhoneAreaCode;
            return this;
        }

        public Builder withHomePhoneNumber(final String homePhoneNumber) {
            this.homePhoneNumber = homePhoneNumber;
            return this;
        }

        public Builder withMobilePhoneAreaCode(final String mobilePhoneAreaCode) {
            this.mobilePhoneAreaCode = mobilePhoneAreaCode;
            return this;
        }

        public Builder withMobilePhoneNumber(final String mobilePhoneNumber) {
            this.mobilePhoneNumber = mobilePhoneNumber;
            return this;
        }

        public Builder withWorkPhoneAreaCode(final String workPhoneAreaCode) {
            this.workPhoneAreaCode = workPhoneAreaCode;
            return this;
        }

        public Builder withWorkPhoneNumber(final String workPhoneNumber) {
            this.workPhoneNumber = workPhoneNumber;
            return this;
        }

        public Builder withSsn(final String ssn) {
            this.ssn = ssn;
            return this;
        }

        public Builder withEmployerName(final String employerName) {
            this.employerName = employerName;
            return this;
        }

        public Builder withEmployerPhoneAreaCode(final String employerPhoneAreaCode) {
            this.employerPhoneAreaCode = employerPhoneAreaCode;
            return this;
        }

        public Builder withEmployerPhoneNumber(final String employerPhoneNumber) {
            this.employerPhoneNumber = employerPhoneNumber;
            return this;
        }

        public Builder withEmploymentMonth(final Integer employmentMonth) {
            this.employmentMonth = employmentMonth;
            return this;
        }

        public Builder withEmploymentYear(final Integer employmentYear) {
            this.employmentYear = employmentYear;
            return this;
        }

        public Builder withOccupationalId(final Long occupationalId) {
            this.occupationalId = occupationalId;
            return this;
        }

        public Builder withBankName(final String bankName) {
            this.bankName = bankName;
            return this;
        }

        public Builder withFirstAccountHolderName(final String firstAccountHolderName) {
            this.firstAccountHolderName = firstAccountHolderName;
            return this;
        }

        public Builder withAccountNumber(final String accountNumber) {
            this.accountNumber = accountNumber;
            return this;
        }

        public Builder withRoutingNumber(final String routingNumber) {
            this.routingNumber = routingNumber;
            return this;
        }

        public DXReferralRequest build() {
            return new DXReferralRequest(this);
        }
    }
}
