
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.UserRequest;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class UserConstant {
    
    private UserConstant() {
    }
    
    /**
     * Creates basic user request object for investor.
     *
     * @return UserRequest
     */
    public static UserRequest buildInvestorPersonalInfoRequest() {
        final User user =
                new User.Builder().withType(Constant.LENDER_USER_TYPE).withPersonalInfo(new PersonalInfo.Builder().build())
                        .build();
        return new UserRequest.Builder().withUser(user).build();
    }
    
    /**
     * Creates basic update user request object for investor.
     *
     * @return UserRequest
     */
    public static UserRequest buildInvestorUpdateRequestBase(final boolean isRegistrationComplete) {
        final User user =
                new User.Builder().withType(Constant.LENDER_USER_TYPE).withIsRegistrationComplete(isRegistrationComplete).build();
        return new UserRequest.Builder().withUser(user).build();
    }

    /**
     * Creates Rick Nick user request.
     *
     * @return UserRequest
     */
    public static UserRequest buildRickNickUserRequest(final String lenderUserType, final String email, final String password,
                                                       final boolean isRegistrationComplete) {
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();
        final User user =
                new User.Builder()
                        .withType(lenderUserType)
                        // LEN-1564
                        // .withSsn(Constant.RICK_NICK_SSN)
                        .withStateOfResidence(AddressInfoConstant.RICK_NICK_STATE).withContactInfo(contactInfo)
                        .withPassword(password).withPersonalInfo(PersonalInfoConstant.buildRickNickPersonalInfo())
                        .withAddressInfo(AddressInfoConstant.buildRickNickAddressInfo())
                        .withIsRegistrationComplete(isRegistrationComplete).build();
        return new UserRequest.Builder().withUser(user).build();
    }

    /**
     * Creates Fred Ruiz Cruz user request.
     *
     * @return UserRequest
     */
    public static UserRequest buildFredRuizCruzUserRequest(final String lenderUserType, final String email,
                                                           final String password, final boolean isRegistrationComplete) {
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();
        final User user =
                new User.Builder()
                        .withType(lenderUserType)
                        // LEN-1564
                        // .withSsn(Constant.FRED_RUIZ_CRUZ_SSN)
                        .withStateOfResidence(AddressInfoConstant.FRED_RUIZ_CRUZ_STATE).withContactInfo(contactInfo)
                        .withPassword(password).withPersonalInfo(PersonalInfoConstant.buildFredRuizCruzPersonalInfo())
                        .withAddressInfo(AddressInfoConstant.buildFredRuizCruzAddressInfo())
                        .withIsRegistrationComplete(isRegistrationComplete).build();
        return new UserRequest.Builder().withUser(user).build();
    }
}
