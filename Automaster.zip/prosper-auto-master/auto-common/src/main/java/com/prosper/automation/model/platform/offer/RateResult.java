
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by pbudiono on 5/31/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class RateResult {

    @JsonProperty("min_score")
    private Integer minimumScore;
    @JsonProperty("max_score")
    private Integer maximumScore;
    @JsonProperty("offer_rate_detail")
    private List<OfferRateDetail> offerRateDetail;


    @JsonIgnore
    public Integer getMinimumScore() {
        return minimumScore;
    }

    @JsonIgnore
    public Integer getMaximumScore() {
        return maximumScore;
    }

    @JsonIgnore
    public List<OfferRateDetail> getOfferRateDetail() {
        return offerRateDetail;
    }
}
