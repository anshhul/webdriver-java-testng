
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonValue;
import com.google.common.base.Objects;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"dayOfWeek", "month", "hour", "year", "dayOfMonth", "dayOfYear", "monthValue", "nano", "chronology",
        "minute", "second"})
public final class VersionStartDate {
    
    @JsonProperty("dayOfWeek")
    private DayOfWeek dayOfWeek;
    @JsonProperty("month")
    private Month month;
    @JsonProperty("hour")
    private Integer hour;
    @JsonProperty("year")
    private Integer year;
    @JsonProperty("dayOfMonth")
    private Integer dayOfMonth;
    @JsonProperty("dayOfYear")
    private Integer dayOfYear;
    @JsonProperty("monthValue")
    private Integer monthValue;
    @JsonProperty("nano")
    private Integer nano;
    @JsonProperty("chronology")
    private Chronology chronology;
    @JsonProperty("minute")
    private Integer minute;
    @JsonProperty("second")
    private Integer second;
    
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        VersionStartDate that = (VersionStartDate) o;
        return Objects.equal(dayOfWeek, that.dayOfWeek) && Objects.equal(month, that.month) && Objects.equal(hour, that.hour)
                && Objects.equal(year, that.year) && Objects.equal(dayOfMonth, that.dayOfMonth)
                && Objects.equal(dayOfYear, that.dayOfYear) && Objects.equal(monthValue, that.monthValue)
                && Objects.equal(nano, that.nano) && Objects.equal(chronology, that.chronology)
                && Objects.equal(minute, that.minute) && Objects.equal(second, that.second);
    }
    
    @Override
    public int hashCode() {
        return Objects
                .hashCode(dayOfWeek, month, hour, year, dayOfMonth, dayOfYear, monthValue, nano, chronology, minute, second);
    }
    
    
    public static enum DayOfWeek {
        
        MONDAY("MONDAY"), TUESDAY("TUESDAY"), WEDNESDAY("WEDNESDAY"), THURSDAY("THURSDAY"), FRIDAY("FRIDAY"),
        SATURDAY("SATURDAY"), SUNDAY("SUNDAY");
        
        private static Map<String, DayOfWeek> constants = new HashMap();
        
        static {
            for (VersionStartDate.DayOfWeek c : values()) {
                constants.put(c.value, c);
            }
        }
        
        private final String value;
        
        
        private DayOfWeek(final String value) {
            this.value = value;
        }
        
        @JsonCreator
        public static VersionStartDate.DayOfWeek fromValue(final String value) {
            VersionStartDate.DayOfWeek constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }
        
        @JsonValue
        @Override
        public String toString() {
            return this.value;
        }
        
    }
    
    public static enum Month {
        
        JANUARY("JANUARY"), FEBRUARY("FEBRUARY"), MARCH("MARCH"), APRIL("APRIL"), MAY("MAY"), JUNE("JUNE"), JULY("JULY"), AUGUST(
                "AUGUST"), SEPTEMBER("SEPTEMBER"), OCTOBER("OCTOBER"), NOVEMBER("NOVEMBER"), DECEMBER("DECEMBER");
        
        private static Map<String, Month> constants = new HashMap();
        
        static {
            for (VersionStartDate.Month c : values()) {
                constants.put(c.value, c);
            }
        }
        
        private final String value;
        
        
        private Month(final String value) {
            this.value = value;
        }
        
        @JsonCreator
        public static Month fromValue(final String value) {
            VersionStartDate.Month constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }
        
        @JsonValue
        @Override
        public String toString() {
            return this.value;
        }
        
    }
    
}
