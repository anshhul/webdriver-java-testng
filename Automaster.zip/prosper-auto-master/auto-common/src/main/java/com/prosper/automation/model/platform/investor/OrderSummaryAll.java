
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public final class OrderSummaryAll {

    @JsonProperty("result")
    List<OrderSummaryByOrderIDResponse> result;
    
    @JsonProperty("result_count")
    private Integer resultCount;
    
    @JsonProperty("total_count")
    private Integer totalCount;
}
