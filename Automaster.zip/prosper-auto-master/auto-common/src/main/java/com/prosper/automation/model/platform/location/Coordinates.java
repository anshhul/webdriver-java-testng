
package com.prosper.automation.model.platform.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * A coordinate representation.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Coordinates {
    
    @JsonProperty("latitude")
    private Float latitude;
    @JsonProperty("longitude")
    private Float longitude;
    
    
    public Coordinates() {
    }
    
    private Coordinates(final Builder builder) {
        latitude = builder.latitude;
        longitude = builder.longitude;
    }
    
    @JsonIgnore
    public Float getLongitude() {
        return longitude;
    }
    
    @JsonIgnore
    public Float getLatitude() {
        return latitude;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Coordinates that = (Coordinates) o;
        return Objects.equal(latitude, that.latitude) && Objects.equal(longitude, that.longitude);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(latitude, longitude);
    }
    
    
    public static final class Builder {
        
        private Float latitude;
        private Float longitude;
        
        
        public Builder() {
        }
        
        public Builder withLatitude(final float latitude) {
            this.latitude = latitude;
            return this;
        }
        
        public Builder withLongitude(final float longitude) {
            this.longitude = longitude;
            return this;
        }
        
        public Coordinates build() {
            return new Coordinates(this);
        }
    }
}
