
package com.prosper.automation.enumeration;

/**
 * Enumeration for sorting order; ascending & descending.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum SortOrder {
    ASC, DESC;
    
    @Override
    public String toString() {
        return this.name().toLowerCase();
    }
}
