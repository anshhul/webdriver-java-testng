package com.prosper.automation.constant;

import com.google.common.collect.ImmutableMap;
import com.prosper.automation.model.platform.AddressInfo;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class AddressInfoConstant {

    public static final String TEST_STATE_CA = "CA";
    public static final AddressInfo ADDRESS_INFO_CA_STATE = new AddressInfo.Builder().withState(TEST_STATE_CA).build();
    public static final int ADDRESS_TYPE_ID = 1;
    // Rick Nick's address
    public static final String RICK_NICK_ADDRESS_1 = "721 Sartori Ave";
    public static final String RICK_NICK_CITY = "Torrance";
    public static final String RICK_NICK_STATE = "CA";
    public static final String RICK_NICK_ZIP_CODE = "90501";

    public static final String FRED_RUIZ_CRUZ_ADDRESS_1 = "508 Lander";
    public static final String FRED_RUIZ_CRUZ_CITY = "Carson City";
    public static final String FRED_RUIZ_CRUZ_STATE = "NV";
    public static final String FRED_RUIZ_CRUZ_ZIP_CODE = "89701";
    public static final AddressInfo ADDRESS_WITHOUT_BLANK_ZIP_CODE = new AddressInfo.Builder().withAddress1("37 Southpine CT")
            .withAddress2("Apt 1").withCity("San Jose").withState("CA").withZipCode("").withAddressTypeId(ADDRESS_TYPE_ID)
            .build();
    // valid AddressInfo test data
    public static final String TEST_ADDRESS_1 = "14511 Star Cross Trl";
    public static final String TEST_CITY = "Helotes";
    public static final String TEST_STATE_GA = "TX";
    public static final String TEST_ZIP_CODE = "780234050";
    public static final AddressInfo ADDRESS_INFO = new AddressInfo.Builder().withAddress1(TEST_ADDRESS_1).withCity(TEST_CITY)
            .withState(TEST_STATE_GA).withZipCode(TEST_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build();

    public static final String PROSPER_ADDRESS = "221 MAIN STREET";
    public static final String PROSPER_CITY = "SAN FRANCISCO";
    public static final String PROSPER_STATE = "CA";
    public static final String PROSPER_ZIP_CODE = "94105";
    private static final String TEST_ADDRESS_2 = "Apt 33";
    public static final AddressInfo ADDRESS1_WITH_APARTMENT_NUMBER = new AddressInfo.Builder()
            .withAddress1(String.format("%s %s", TEST_ADDRESS_1, TEST_ADDRESS_2)).withCity(TEST_CITY).withState(TEST_STATE_GA)
            .withZipCode(TEST_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build();
    // fake AddressInfo test data
    private static final String TEST_FAKE_ADDRESS = "1 Heaven Blvd";
    private static final String TEST_FAKE_CITY = "London";
    public static final AddressInfo ADDRESS_WITH_USPS_CORRECTION = new AddressInfo.Builder().withAddress1(TEST_ADDRESS_1)
            .withCity(TEST_FAKE_CITY).withState(TEST_STATE_GA).withZipCode(TEST_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID)
            .build();
    public static final AddressInfo ADDRESS_DOES_NOT_EXIST = new AddressInfo.Builder().withAddress1(TEST_FAKE_ADDRESS)
            .withCity(TEST_FAKE_CITY).withState(TEST_STATE_GA).withZipCode(TEST_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID)
            .build();
    // Tuscaloosa city hall
    private static final String AL_ADDRESS_1 = "2201 University Blvd";
    private static final String AL_CITY = "Tuscaloosa";
    private static final String AL_STATE = "AL";
    private static final String AL_ZIP_CODE = "35401";
    // Dover city hall
    private static final String DE_ADDRESS_1 = "15 Loockerman Plaza";
    private static final String DE_CITY = "Dover";
    private static final String DE_STATE = "DE";
    private static final String DE_ZIP_CODE = "19901";
    // Montpelier city public works
    private static final String VT_ADDRESS_1 = "949 Dog River Rd";
    private static final String VT_CITY = "Montpelier";
    private static final String VT_STATE = "VT";
    private static final String VT_ZIP_CODE = "05602";
    // Charleston court
    private static final String WV_ADDRESS_1 = "501 Virginia St E";
    private static final String WV_CITY = "Charleston";
    private static final String WV_STATE = "WV";
    private static final String WV_ZIP_CODE = "25301";
    // James Butt
    private static final String LA_ADDRESS_1 = "6649 N Blue Gum St";
    private static final String LA_CITY = "New Orleans";
    private static final String LA_STATE = "LA";
    private static final String LA_ZIP_CODE = "70116";
    // Josephine Darakjy
    private static final String MI_ADDRESS_1 = "4 B Blue Ridge Blvd";
    private static final String MI_CITY = "Brighton";
    private static final String MI_STATE = "MI";
    private static final String MI_ZIP_CODE = "48116";
    // Art Venere
    private static final String NJ_ADDRESS_1 = "8 W Cerritos Ave #54";
    private static final String NJ_CITY = "Bridgeport";
    private static final String NJ_STATE = "NJ";
    private static final String NJ_ZIP_CODE = "08014";
    // Lenna Paprocki
    private static final String AK_ADDRESS_1 = "639 Main St";
    private static final String AK_CITY = "Anchorage";
    private static final String AK_STATE = "AK";
    private static final String AK_ZIP_CODE = "99501";
    // Donette Foller
    private static final String OH_ADDRESS_1 = "34 Center St";
    private static final String OH_CITY = "Hamilton";
    private static final String OH_STATE = "OH";
    private static final String OH_ZIP_CODE = "45011";
    // Mitsue Tollner
    private static final String IL_ADDRESS_1 = "7 Eads St";
    private static final String IL_CITY = "Chicago";
    private static final String IL_STATE = "IL";
    private static final String IL_ZIP_CODE = "60632";
    // Leota Dilliard
    private static final String CA_ADDRESS_1 = "7 W Jackson Blvd";
    private static final String CA_CITY = "San Jose";
    private static final String CA_STATE = "CA";
    private static final String CA_ZIP_CODE = "95111";
    // Sage Wieser
    private static final String SD_ADDRESS_1 = "5 Boston Ave #88";
    private static final String SD_CITY = "Sioux Falls";
    private static final String SD_STATE = "SD";
    private static final String SD_ZIP_CODE = "57105";
    // Kris Marrier
    private static final String MD_ADDRESS_1 = "228 Runamuck Pl #2808";
    private static final String MD_CITY = "Baltimore";
    private static final String MD_STATE = "MD";
    private static final String MD_ZIP_CODE = "21224";
    // Minna Amigon
    private static final String PA_ADDRESS_1 = "2371 Jerrold Ave";
    private static final String PA_CITY = "Kulpsville";
    private static final String PA_STATE = "PA";
    private static final String PA_ZIP_CODE = "19443";
    // Abel Maclead
    private static final String NY_ADDRESS_1 = "37275 St  Rt 17m M";
    private static final String NY_CITY = "Middle Island";
    private static final String NY_STATE = "NY";
    private static final String NY_ZIP_CODE = "11953";
    // Cammy Albares
    private static final String TX_ADDRESS_1 = "56 E Morehead St";
    private static final String TX_CITY = "Laredo";
    private static final String TX_STATE = "TX";
    private static final String TX_ZIP_CODE = "78045";
    // Mattie Poquette
    private static final String AZ_ADDRESS_1 = "73 State Road 434 E";
    private static final String AZ_CITY = "Phoenix";
    private static final String AZ_STATE = "AZ";
    private static final String AZ_ZIP_CODE = "85013";
    // Meaghan Garufi
    private static final String TN_ADDRESS_1 = "69734 E Carrillo St";
    private static final String TN_CITY = "Mc Minnville";
    private static final String TN_STATE = "TN";
    private static final String TN_ZIP_CODE = "37110";
    // Gladys Rim
    private static final String WI_ADDRESS_1 = "322 New Horizon Blvd";
    private static final String WI_CITY = "Milwaukee";
    private static final String WI_STATE = "WI";
    private static final String WI_ZIP_CODE = "53207";
    // Chanel Caudy
    private static final String KS_ADDRESS_1 = "86 Nw 66th St #8673";
    private static final String KS_CITY = "Shawnee";
    private static final String KS_STATE = "KS";
    private static final String KS_ZIP_CODE = "66218";
    // Francine Vocelka
    private static final String NM_ADDRESS_1 = "366 South Dr";
    private static final String NM_CITY = "Las Cruces";
    private static final String NM_STATE = "NM";
    private static final String NM_ZIP_CODE = "88011";
    // Youlanda Schemmer
    private static final String OR_ADDRESS_1 = "2881 Lewis Rd";
    private static final String OR_CITY = "Prineville";
    private static final String OR_STATE = "OR";
    private static final String OR_ZIP_CODE = "97754";
    // Lavera Perin
    private static final String FL_ADDRESS_1 = "678 3rd Ave";
    private static final String FL_CITY = "Miami";
    private static final String FL_STATE = "FL";
    private static final String FL_ZIP_CODE = "33196";
    // Fatima Saylors
    private static final String MN_ADDRESS_1 = "2 Lighthouse Ave";
    private static final String MN_CITY = "Hopkins";
    private static final String MN_STATE = "MN";
    private static final String MN_ZIP_CODE = "55343";
    // Jina Briddick
    private static final String MA_ADDRESS_1 = "38938 Park Blvd";
    private static final String MA_CITY = "Boston";
    private static final String MA_STATE = "MA";
    private static final String MA_ZIP_CODE = "02128";
    // Sabra Uyetake
    private static final String SC_ADDRESS_1 = "98839 Hawthorne Blvd #6101";
    private static final String SC_CITY = "Columbia";
    private static final String SC_STATE = "SC";
    private static final String SC_ZIP_CODE = "29201";
    // Delmy Ahle
    private static final String RI_ADDRESS_1 = "65895 S 16th St";
    private static final String RI_CITY = "Providence";
    private static final String RI_STATE = "RI";
    private static final String RI_ZIP_CODE = "02909";
    // Carmelina Lindall
    private static final String CO_ADDRESS_1 = "2664 Lewis Rd";
    private static final String CO_CITY = "Littleton";
    private static final String CO_STATE = "CO";
    private static final String CO_ZIP_CODE = "80126";
    // Vallie Mondella
    private static final String ID_ADDRESS_1 = "74 W College St";
    private static final String ID_CITY = "Boise";
    private static final String ID_STATE = "ID";
    private static final String ID_ZIP_CODE = "83707";
    // Johnetta Abdallah
    private static final String NC_ADDRESS_1 = "1088 Pinehurst St";
    private static final String NC_CITY = "Chapel Hill";
    private static final String NC_STATE = "NC";
    private static final String NC_ZIP_CODE = "27514";
    // Malinda Hochard
    private static final String IN_ADDRESS_1 = "55 Riverside Ave";
    private static final String IN_CITY = "Indianapolis";
    private static final String IN_STATE = "IN";
    private static final String IN_ZIP_CODE = "46202";
    // Natalie Fern
    private static final String WY_ADDRESS_1 = "7140 University Ave";
    private static final String WY_CITY = "Rock Springs";
    private static final String WY_STATE = "WY";
    private static final String WY_ZIP_CODE = "82901";
    // Lisha Centini
    private static final String VA_ADDRESS_1 = "64 5th Ave #1153";
    private static final String VA_CITY = "Mc Lean";
    private static final String VA_STATE = "VA";
    private static final String VA_ZIP_CODE = "22102";
    // Angella Cetta
    private static final String HI_ADDRESS_1 = "185 Blackstone Bldge";
    private static final String HI_CITY = "Honolulu";
    private static final String HI_STATE = "HI";
    private static final String HI_ZIP_CODE = "96817";
    // Scarlet Cartan
    private static final String GA_ADDRESS_1 = "9390 S Howell Ave";
    private static final String GA_CITY = "Albany";
    private static final String GA_STATE = "GA";
    private static final String GA_ZIP_CODE = "31701";
    // Carin Deleo
    private static final String AR_ADDRESS_1 = "1844 Southern Blvd";
    private static final String AR_CITY = "Little Rock";
    private static final String AR_STATE = "AR";
    private static final String AR_ZIP_CODE = "72202";
    // Clay Hoa
    private static final String NV_ADDRESS_1 = "73 Saint Ann St #86";
    private static final String NV_CITY = "Reno";
    private static final String NV_STATE = "NV";
    private static final String NV_ZIP_CODE = "89502";
    // Jolanda Hanafan
    private static final String ME_ADDRESS_1 = "37855 Nolan Rd";
    private static final String ME_CITY = "Bangor";
    private static final String ME_STATE = "ME";
    private static final String ME_ZIP_CODE = "04401";
    // Glen Bartolet
    private static final String WA_ADDRESS_1 = "8739 Hudson St";
    private static final String WA_CITY = "Vashon";
    private static final String WA_STATE = "WA";
    private static final String WA_ZIP_CODE = "98070";
    // Leonida Gobern
    private static final String MS_ADDRESS_1 = "5 Elmwood Park Blvd";
    private static final String MS_CITY = "Biloxi";
    private static final String MS_STATE = "MS";
    private static final String MS_ZIP_CODE = "39530";
    // Yoko Fishburne
    private static final String CT_ADDRESS_1 = "9122 Carpenter Ave";
    private static final String CT_CITY = "New Haven";
    private static final String CT_STATE = "CT";
    private static final String CT_ZIP_CODE = "06511";
    // Benedict Sama
    private static final String MO_ADDRESS_1 = "4923 Carey Ave";
    private static final String MO_CITY = "Saint Louis";
    private static final String MO_STATE = "MO";
    private static final String MO_ZIP_CODE = "63104";
    // Dalene Riden
    private static final String NH_ADDRESS_1 = "66552 Malone Rd";
    private static final String NH_CITY = "Plaistow";
    private static final String NH_STATE = "NH";
    private static final String NH_ZIP_CODE = "03865";
    // Lavonda Hengel
    private static final String ND_ADDRESS_1 = "87 Imperial Ct #79";
    private static final String ND_CITY = "Fargo";
    private static final String ND_STATE = "ND";
    private static final String ND_ZIP_CODE = "58102";
    // Raina Brachle
    private static final String MT_ADDRESS_1 = "3829 Ventura Blvd";
    private static final String MT_CITY = "Butte";
    private static final String MT_STATE = "MT";
    private static final String MT_ZIP_CODE = "59701";
    // Glenn Berray
    private static final String IA_ADDRESS_1 = "29 Cherry St #7073";
    private static final String IA_CITY = "Des Moines";
    private static final String IA_STATE = "IA";
    private static final String IA_ZIP_CODE = "50315";
    // Sylvie Ryser
    private static final String OK_ADDRESS_1 = "649 Tulane Ave";
    private static final String OK_CITY = "Tulsa";
    private static final String OK_STATE = "OK";
    private static final String OK_ZIP_CODE = "74105";
    // Stephane Myricks
    private static final String KY_ADDRESS_1 = "9 Tower Ave";
    private static final String KY_CITY = "Burlington";
    private static final String KY_STATE = "KY";
    private static final String KY_ZIP_CODE = "41005";
    // Lonny Weglarz
    private static final String UT_ADDRESS_1 = "51120 State Route 18";
    private static final String UT_CITY = "Salt Lake City";
    private static final String UT_STATE = "UT";
    private static final String UT_ZIP_CODE = "84115";
    // Colette Kardas
    private static final String NE_ADDRESS_1 = "21575 S Apple Creek Rd";
    private static final String NE_CITY = "Omaha";
    private static final String NE_STATE = "NE";
    private static final String NE_ZIP_CODE = "68124";
    // Alesia Hixenbaugh
    private static final String DC_ADDRESS_1 = "9 Front St";
    private static final String DC_CITY = "Washington";
    private static final String DC_STATE = "DC";
    private static final String DC_ZIP_CODE = "20001";
    public static final ImmutableMap<String, AddressInfo> VALID_ADDRESSES = new ImmutableMap.Builder()
            .put("AL",
                    new AddressInfo.Builder().withAddress1(AL_ADDRESS_1).withCity(AL_CITY).withState(AL_STATE)
                            .withZipCode(AL_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("DE",
                    new AddressInfo.Builder().withAddress1(DE_ADDRESS_1).withCity(DE_CITY).withState(DE_STATE)
                            .withZipCode(DE_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("VT",
                    new AddressInfo.Builder().withAddress1(VT_ADDRESS_1).withCity(VT_CITY).withState(VT_STATE)
                            .withZipCode(VT_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("WV",
                    new AddressInfo.Builder().withAddress1(WV_ADDRESS_1).withCity(WV_CITY).withState(WV_STATE)
                            .withZipCode(WV_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("LA",
                    new AddressInfo.Builder().withAddress1(LA_ADDRESS_1).withCity(LA_CITY).withState(LA_STATE)
                            .withZipCode(LA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MI",
                    new AddressInfo.Builder().withAddress1(MI_ADDRESS_1).withCity(MI_CITY).withState(MI_STATE)
                            .withZipCode(MI_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NJ",
                    new AddressInfo.Builder().withAddress1(NJ_ADDRESS_1).withCity(NJ_CITY).withState(NJ_STATE)
                            .withZipCode(NJ_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("AK",
                    new AddressInfo.Builder().withAddress1(AK_ADDRESS_1).withCity(AK_CITY).withState(AK_STATE)
                            .withZipCode(AK_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("OH",
                    new AddressInfo.Builder().withAddress1(OH_ADDRESS_1).withCity(OH_CITY).withState(OH_STATE)
                            .withZipCode(OH_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("IL",
                    new AddressInfo.Builder().withAddress1(IL_ADDRESS_1).withCity(IL_CITY).withState(IL_STATE)
                            .withZipCode(IL_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("CA",
                    new AddressInfo.Builder().withAddress1(CA_ADDRESS_1).withCity(CA_CITY).withState(CA_STATE)
                            .withZipCode(CA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("SD",
                    new AddressInfo.Builder().withAddress1(SD_ADDRESS_1).withCity(SD_CITY).withState(SD_STATE)
                            .withZipCode(SD_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MD",
                    new AddressInfo.Builder().withAddress1(MD_ADDRESS_1).withCity(MD_CITY).withState(MD_STATE)
                            .withZipCode(MD_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("PA",
                    new AddressInfo.Builder().withAddress1(PA_ADDRESS_1).withCity(PA_CITY).withState(PA_STATE)
                            .withZipCode(PA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NY",
                    new AddressInfo.Builder().withAddress1(NY_ADDRESS_1).withCity(NY_CITY).withState(NY_STATE)
                            .withZipCode(NY_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("TX",
                    new AddressInfo.Builder().withAddress1(TX_ADDRESS_1).withCity(TX_CITY).withState(TX_STATE)
                            .withZipCode(TX_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("AZ",
                    new AddressInfo.Builder().withAddress1(AZ_ADDRESS_1).withCity(AZ_CITY).withState(AZ_STATE)
                            .withZipCode(AZ_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("TN",
                    new AddressInfo.Builder().withAddress1(TN_ADDRESS_1).withCity(TN_CITY).withState(TN_STATE)
                            .withZipCode(TN_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("WI",
                    new AddressInfo.Builder().withAddress1(WI_ADDRESS_1).withCity(WI_CITY).withState(WI_STATE)
                            .withZipCode(WI_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("KS",
                    new AddressInfo.Builder().withAddress1(KS_ADDRESS_1).withCity(KS_CITY).withState(KS_STATE)
                            .withZipCode(KS_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NM",
                    new AddressInfo.Builder().withAddress1(NM_ADDRESS_1).withCity(NM_CITY).withState(NM_STATE)
                            .withZipCode(NM_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("OR",
                    new AddressInfo.Builder().withAddress1(OR_ADDRESS_1).withCity(OR_CITY).withState(OR_STATE)
                            .withZipCode(OR_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("FL",
                    new AddressInfo.Builder().withAddress1(FL_ADDRESS_1).withCity(FL_CITY).withState(FL_STATE)
                            .withZipCode(FL_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MN",
                    new AddressInfo.Builder().withAddress1(MN_ADDRESS_1).withCity(MN_CITY).withState(MN_STATE)
                            .withZipCode(MN_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MA",
                    new AddressInfo.Builder().withAddress1(MA_ADDRESS_1).withCity(MA_CITY).withState(MA_STATE)
                            .withZipCode(MA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("SC",
                    new AddressInfo.Builder().withAddress1(SC_ADDRESS_1).withCity(SC_CITY).withState(SC_STATE)
                            .withZipCode(SC_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("RI",
                    new AddressInfo.Builder().withAddress1(RI_ADDRESS_1).withCity(RI_CITY).withState(RI_STATE)
                            .withZipCode(RI_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("CO",
                    new AddressInfo.Builder().withAddress1(CO_ADDRESS_1).withCity(CO_CITY).withState(CO_STATE)
                            .withZipCode(CO_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("ID",
                    new AddressInfo.Builder().withAddress1(ID_ADDRESS_1).withCity(ID_CITY).withState(ID_STATE)
                            .withZipCode(ID_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NC",
                    new AddressInfo.Builder().withAddress1(NC_ADDRESS_1).withCity(NC_CITY).withState(NC_STATE)
                            .withZipCode(NC_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("IN",
                    new AddressInfo.Builder().withAddress1(IN_ADDRESS_1).withCity(IN_CITY).withState(IN_STATE)
                            .withZipCode(IN_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("WY",
                    new AddressInfo.Builder().withAddress1(WY_ADDRESS_1).withCity(WY_CITY).withState(WY_STATE)
                            .withZipCode(WY_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("VA",
                    new AddressInfo.Builder().withAddress1(VA_ADDRESS_1).withCity(VA_CITY).withState(VA_STATE)
                            .withZipCode(VA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("HI",
                    new AddressInfo.Builder().withAddress1(HI_ADDRESS_1).withCity(HI_CITY).withState(HI_STATE)
                            .withZipCode(HI_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("GA",
                    new AddressInfo.Builder().withAddress1(GA_ADDRESS_1).withCity(GA_CITY).withState(GA_STATE)
                            .withZipCode(GA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("AR",
                    new AddressInfo.Builder().withAddress1(AR_ADDRESS_1).withCity(AR_CITY).withState(AR_STATE)
                            .withZipCode(AR_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NV",
                    new AddressInfo.Builder().withAddress1(NV_ADDRESS_1).withCity(NV_CITY).withState(NV_STATE)
                            .withZipCode(NV_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("ME",
                    new AddressInfo.Builder().withAddress1(ME_ADDRESS_1).withCity(ME_CITY).withState(ME_STATE)
                            .withZipCode(ME_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("WA",
                    new AddressInfo.Builder().withAddress1(WA_ADDRESS_1).withCity(WA_CITY).withState(WA_STATE)
                            .withZipCode(WA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MS",
                    new AddressInfo.Builder().withAddress1(MS_ADDRESS_1).withCity(MS_CITY).withState(MS_STATE)
                            .withZipCode(MS_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("CT",
                    new AddressInfo.Builder().withAddress1(CT_ADDRESS_1).withCity(CT_CITY).withState(CT_STATE)
                            .withZipCode(CT_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MO",
                    new AddressInfo.Builder().withAddress1(MO_ADDRESS_1).withCity(MO_CITY).withState(MO_STATE)
                            .withZipCode(MO_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NH",
                    new AddressInfo.Builder().withAddress1(NH_ADDRESS_1).withCity(NH_CITY).withState(NH_STATE)
                            .withZipCode(NH_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("ND",
                    new AddressInfo.Builder().withAddress1(ND_ADDRESS_1).withCity(ND_CITY).withState(ND_STATE)
                            .withZipCode(ND_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("MT",
                    new AddressInfo.Builder().withAddress1(MT_ADDRESS_1).withCity(MT_CITY).withState(MT_STATE)
                            .withZipCode(MT_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("IA",
                    new AddressInfo.Builder().withAddress1(IA_ADDRESS_1).withCity(IA_CITY).withState(IA_STATE)
                            .withZipCode(IA_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("OK",
                    new AddressInfo.Builder().withAddress1(OK_ADDRESS_1).withCity(OK_CITY).withState(OK_STATE)
                            .withZipCode(OK_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("KY",
                    new AddressInfo.Builder().withAddress1(KY_ADDRESS_1).withCity(KY_CITY).withState(KY_STATE)
                            .withZipCode(KY_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("UT",
                    new AddressInfo.Builder().withAddress1(UT_ADDRESS_1).withCity(UT_CITY).withState(UT_STATE)
                            .withZipCode(UT_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("NE",
                    new AddressInfo.Builder().withAddress1(NE_ADDRESS_1).withCity(NE_CITY).withState(NE_STATE)
                            .withZipCode(NE_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .put("DC",
                    new AddressInfo.Builder().withAddress1(DC_ADDRESS_1).withCity(DC_CITY).withState(DC_STATE)
                            .withZipCode(DC_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build())
            .build();

    public static final String RENT_OWNERSHIP_TYPE = "RENT";
    public static final String OWN_OWNERSHIP_TYPE = "OWN";
    public static final String OTHER_OWNERSHIP_TYPE = "OTHER";


    private AddressInfoConstant() {
    }

    public static AddressInfo buildDefaultAddressInfo() {
        return new AddressInfo.Builder().withAddress1(RICK_NICK_ADDRESS_1).withCity(RICK_NICK_CITY).withState(RICK_NICK_STATE)
                .withZipCode(RICK_NICK_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build();
    }

    public static AddressInfo buildRickNickAddressInfo() {
        return new AddressInfo.Builder().withAddress1(RICK_NICK_ADDRESS_1).withCity(RICK_NICK_CITY).withState(RICK_NICK_STATE)
                .withZipCode(RICK_NICK_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build();
    }

    public static AddressInfo buildFredRuizCruzAddressInfo() {
        return new AddressInfo.Builder().withAddress1(FRED_RUIZ_CRUZ_ADDRESS_1).withCity(FRED_RUIZ_CRUZ_CITY)
                .withState(FRED_RUIZ_CRUZ_STATE).withZipCode(FRED_RUIZ_CRUZ_ZIP_CODE).withAddressTypeId(ADDRESS_TYPE_ID).build();
    }
}
