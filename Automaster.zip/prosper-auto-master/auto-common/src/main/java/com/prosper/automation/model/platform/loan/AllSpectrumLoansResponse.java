package com.prosper.automation.model.platform.loan;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Sonali Phatak
 *
 */
public class AllSpectrumLoansResponse {

	@JsonProperty("status")
	private Boolean status;
	@JsonProperty("message")
	private String message;
	@JsonProperty("result")
	private List<PlatformLoanResult> result;
	@JsonProperty("total_count")
	private Integer totalCount;
	@JsonProperty("show_payment_policy")
	private boolean showPaymentPolicy;

	public boolean isShowPaymentPolicy() {
		return showPaymentPolicy;
	}

	public void setShowPaymentPolicy(boolean showPaymentPolicy) {
		this.showPaymentPolicy = showPaymentPolicy;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<PlatformLoanResult> getResult() {
		return result;
	}

	public void setResult(List<PlatformLoanResult> result) {
		this.result = result;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
}
