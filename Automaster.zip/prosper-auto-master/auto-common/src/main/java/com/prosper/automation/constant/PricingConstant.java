
package com.prosper.automation.constant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PricingConstant {
    
    public static final double ZERO_MONTHLY_INCOME = 0;
    
    public static final String INVALID_PRICING_VERSION = "1.0";
    
    
    private PricingConstant() {
    }
}
