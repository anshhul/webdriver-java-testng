package com.prosper.automation.constant.web;

/**
 * Created by rsubramanyam on 5/20/16.
 */
public enum SuppressableJSError {
    XML_HTTP_REQUEST_DEPRECATED(SuppressableJavascriptErrorConstants.JS_ERROR_XML_HTTP_REQUEST),
    JS_ERROR_GOOGLE_MAPS_API_REQUEST(SuppressableJavascriptErrorConstants.JS_ERROR_GOOGLE_MAPS_API_REQUEST),
    SATELLITE_ERRORS(SuppressableJavascriptErrorConstants.SATELLITE_ERRORS);
    private String message;
    SuppressableJSError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
