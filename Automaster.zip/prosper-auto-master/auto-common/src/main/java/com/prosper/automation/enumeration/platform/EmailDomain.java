
package com.prosper.automation.enumeration.platform;

/**
 * Created by rsubramanyam on 5/10/16.
 */
public enum EmailDomain {

    C1DEV("@c1.dev"), C1STG("@c1.stg"), P2P_CREDIT("@p2pcredit.com");

    EmailDomain(final String name) {
        this.name = name;
    }


    private final String name;

    public String getName() {
        return this.name;
    }

}
