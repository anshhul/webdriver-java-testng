
package com.prosper.automation.model.platform.inquiry;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"listing_id"})
public final class ListingHoldRequest {

    @JsonProperty("listing_id")
    private Long listingId;


    private ListingHoldRequest(final Builder builder) {
        listingId = builder.listingId;
    }

    @JsonIgnore
    public Long getListingId() {
        return listingId;
    }


    public static final class Builder {

        private Long listingId;


        public Builder() {
        }

        public Builder withListingId(final Long listingId) {
            this.listingId = listingId;
            return this;
        }

        public ListingHoldRequest build() {
            return new ListingHoldRequest(this);
        }
    }
}
