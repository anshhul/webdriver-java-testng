
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"campaign_program_id", "campaign_id", "name", "ref_mc", "program_rule_set_id", "rank", "pricing_id",
        "description", "created_date", "modified_date", "legacy_id", "legacy_channel", "fall_back_program_used",
        "work_flow_type_id", "is_abp_eligible"})
public final class ProgramVo {
    
    @JsonProperty("campaign_program_id")
    private UUID campaignProgramId;
    @JsonProperty("campaign_id")
    private UUID campaignId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("ref_mc")
    private String refMc;
    @JsonProperty("program_rule_set_id")
    private Long programRuleSetId;
    @JsonProperty("rank")
    private Integer rank;
    @JsonProperty("pricing_id")
    private Long pricingId;
    @JsonProperty("description")
    private String description;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("modified_date")
    private String modifiedDate;
    @JsonProperty("legacy_id")
    private Long legacyId;
    @JsonProperty("legacy_channel")
    private String legacyChannel;
    @JsonProperty("fall_back_program_used")
    private String fallBackProgramUsed;
    @JsonProperty("work_flow_type_id")
    private Long workFlowTypeId;
    @JsonProperty("is_abp_eligible")
    private boolean isAbpEligible;

    public void setLegacyId(Long legacyId) {
        this.legacyId = legacyId;
    }

    public UUID getCampaignProgramId() {
        return campaignProgramId;
    }

    public UUID getCampaignId() {
        return campaignId;
    }

    public String getName() {
        return name;
    }

    public String getRefMc() {
        return refMc;
    }

    public Long getProgramRuleSetId() {
        return programRuleSetId;
    }

    public Integer getRank() {
        return rank;
    }

    public Long getPricingId() {
        return pricingId;
    }

    public String getDescription() {
        return description;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setLegacyChannel(String legacyChannel) {
        this.legacyChannel = legacyChannel;
    }

    public void setFallBackProgramUsed(String fallBackProgramUsed) {
        this.fallBackProgramUsed = fallBackProgramUsed;
    }

    public void setWorkFlowTypeId(Long workFlowTypeId) {
        this.workFlowTypeId = workFlowTypeId;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ProgramVo programVo = (ProgramVo) o;
        return isAbpEligible == programVo.isAbpEligible &&
                Objects.equal(campaignProgramId, programVo.campaignProgramId) &&
                Objects.equal(campaignId, programVo.campaignId) &&
                Objects.equal(name, programVo.name) &&
                Objects.equal(refMc, programVo.refMc) &&
                Objects.equal(programRuleSetId, programVo.programRuleSetId) &&
                Objects.equal(rank, programVo.rank) &&
                Objects.equal(pricingId, programVo.pricingId) &&
                Objects.equal(description, programVo.description) &&
                Objects.equal(createdDate, programVo.createdDate) &&
                Objects.equal(modifiedDate, programVo.modifiedDate) &&
                Objects.equal(legacyId, programVo.legacyId) &&
                Objects.equal(legacyChannel, programVo.legacyChannel) &&
                Objects.equal(fallBackProgramUsed, programVo.fallBackProgramUsed) &&
                Objects.equal(workFlowTypeId, programVo.workFlowTypeId);
    }

    @Override public int hashCode() {
        return Objects
                .hashCode(campaignProgramId, campaignId, name, refMc, programRuleSetId, rank, pricingId, description, createdDate,
                        modifiedDate, legacyId, legacyChannel, fallBackProgramUsed, workFlowTypeId, isAbpEligible);
    }

    @Override public String toString() {
        return "ProgramVo{" +
                "campaignProgramId=" + campaignProgramId +
                ", campaignId=" + campaignId +
                ", name='" + name + '\'' +
                ", refMc='" + refMc + '\'' +
                ", programRuleSetId=" + programRuleSetId +
                ", rank=" + rank +
                ", pricingId=" + pricingId +
                ", description='" + description + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                ", legacyId=" + legacyId +
                ", legacyChannel='" + legacyChannel + '\'' +
                ", fallBackProgramUsed='" + fallBackProgramUsed + '\'' +
                ", workFlowTypeId=" + workFlowTypeId +
                ", isAbpEligible=" + isAbpEligible +
                '}';
    }
}
