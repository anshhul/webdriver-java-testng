
package com.prosper.automation.util.web.borrower.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.xmlbeans.XmlException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 19-Jun-2016
 *
 */
public final class DocParserUtil {

    private String documentContent;


    public String getDocumentContent() {
        return documentContent;
    }

    public DocParserUtil(String filePath) throws IOException, XmlException, OpenXML4JException {
        StringBuffer paragraphbuffer=   new StringBuffer();
        try (FileInputStream fis = new FileInputStream(filePath);) {
            XWPFDocument docx = new XWPFDocument(fis);

            List<XWPFParagraph> paraList = docx.getParagraphs();
            for (XWPFParagraph xwpfParagraph : paraList) {

                paragraphbuffer.append(xwpfParagraph.getText());

            }
            documentContent = paragraphbuffer.toString();
        }
    }


}
