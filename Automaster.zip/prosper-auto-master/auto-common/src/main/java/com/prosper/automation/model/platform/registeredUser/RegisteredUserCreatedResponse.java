package com.prosper.automation.model.platform.registeredUser;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by aamalraj on 12/21/15.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({"anonymousToken", "user", "lending_accreditation", "til_accepted"})

public class RegisteredUserCreatedResponse {

    @JsonProperty("anonymousToken") private Boolean anonymousToken;
    @JsonProperty("user") private RegisteredUserResponse registeredUserResponse;

    public Boolean getAnonymousToken() {
        return anonymousToken;
    }

    public RegisteredUserResponse getRegisteredUserResponse() {
        return registeredUserResponse;
    }

}
