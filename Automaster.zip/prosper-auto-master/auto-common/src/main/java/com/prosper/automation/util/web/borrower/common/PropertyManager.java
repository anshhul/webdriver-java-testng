package com.prosper.automation.util.web.borrower.common;

import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyManager {
	static final Logger logger = Logger.getLogger(PropertyManager.class);

	private  Properties props = null;

	public PropertyManager() {

	}
	static String propertyFileName;


	public String getPropertyFileName() {
		return propertyFileName;
	}

	@SuppressWarnings("static-access")
	public void setPropertyFileName(String propertyFileName) {
		this.propertyFileName = propertyFileName;
	}
	public  String getProperty(String key) {
		try {
			String value = System.getProperty(key);

			if (props == null) {
				props = new Properties();
				try {
					InputStream fis = ClassLoader.getSystemClassLoader().getResourceAsStream(propertyFileName);
					props.load(fis);
				} catch (FileNotFoundException fne) {
					fne.printStackTrace();

				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}

			if (value == null) {
				value = props.getProperty(key);

			}
            logger.info("key: " + key + " value: " + value);
			return value;
		} catch (Exception e) {
			logger.info("Inside Property Manager Class: "
					+ e.getMessage());
		}
		return null;
	}
}
