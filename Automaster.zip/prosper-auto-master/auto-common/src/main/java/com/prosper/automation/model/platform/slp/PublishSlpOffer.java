
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public  class PublishSlpOffer {

    @JsonProperty("offer_date")
    private String offerDate;
    
    @JsonProperty("offer_status")
    private String offerStatus;
    
    
    /**
     * CLASS / TYPE DESCRIPTION GOES HERE.
     *
     * @author pchaturvedi
     */
    public static class PublishSlpOfferBuilder {

        private String offerDate;
        private String offerStatus;


        /**
         * @return
         */
        public PublishSlpOffer build() {
            final PublishSlpOffer result = new PublishSlpOffer();

            result.setOfferDate(offerDate);
            result.setOfferStatus(offerStatus);
            return result;
        }

        /**
         * @param value
         * @return
         */
        public PublishSlpOfferBuilder offerDate(final String value) {
            this.offerDate = value;
            return this;
        }

        /**
         * @param value
         * @return
         */
        public PublishSlpOfferBuilder offerStatus(final String value) {
            this.offerStatus = value;
            return this;
        }
    }
    
    
    /**
     * @param original
     * @return
     */
    public static PublishSlpOfferBuilder buildUpon(final PublishSlpOffer original) {
        final PublishSlpOfferBuilder builder = newBuilder();
        builder.offerDate(original.getOfferDate());
        builder.offerStatus(original.getOfferStatus());
        return builder;
    }
    
    /**
     * @return
     */
    public static PublishSlpOfferBuilder newBuilder() {
        return new PublishSlpOfferBuilder();
    }
    
    /**
     * @return
     */
    public String getOfferDate() {
        return offerDate;
    }
    
    /**
     * @return
     */
    public String getOfferStatus() {
        return offerStatus;
    }
    
    /**
     * @param offerDate
     */
    public void setOfferDate(final String offerDate) {
        this.offerDate = offerDate;
    }
    
    /**
     * @param offerStatus
     */
    public void setOfferStatus(final String offerStatus) {
        this.offerStatus = offerStatus;
    }

}
