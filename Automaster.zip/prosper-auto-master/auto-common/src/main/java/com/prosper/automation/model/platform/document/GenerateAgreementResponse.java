
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"agreement_transaction_id", "agreement_html"})
public final class GenerateAgreementResponse {
    
    @JsonProperty("agreement_transaction_id")
    private UUID agreementTransactionId;
    @JsonProperty("agreement_html")
    private String agreementHtml;
    
    
    @JsonIgnore
    public UUID getAgreementTransactionId() {
        return agreementTransactionId;
    }
}
