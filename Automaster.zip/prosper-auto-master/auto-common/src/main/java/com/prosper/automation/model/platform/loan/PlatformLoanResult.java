package com.prosper.automation.model.platform.loan;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Sonali Phatak
 * 
 * Updated by @author agarg on 3rd March 2017
 *
 */
public class PlatformLoanResult {

	@JsonProperty("loan_description")
	private String loanDescription;

	@JsonProperty("origination_date")
	private Date originationDate;

	@JsonProperty("amount_borrowed")
	private BigDecimal amountBorrowed;

	@JsonProperty("maturity_date")
	private Date maturityDate;

	@JsonProperty("borrower_rate")
	private BigDecimal borrowerRate;

	@JsonProperty("term")
	private Short term;

	@JsonProperty("current_principal_balance")
	private BigDecimal currentPrincipalBalance;

	@JsonProperty("payoff_amount")
	private BigDecimal payOffAmount;

	@JsonProperty("past_due_amount")
	private BigDecimal pastDueAmount;

	@JsonProperty("loan_status")
	private String loanStatus;

	@JsonProperty("next_payment_scheduled_amount")
	private BigDecimal nextPaymentScheduledAmount;

	@JsonProperty("next_payment_due_date")
	private Date nextPaymentDueDate;

	@JsonProperty("late_fee_amount")
	private BigDecimal lateFeeAmount;

	@JsonProperty("days_past_due")
	private Short daysPastDue;
	
	@JsonProperty("due_in_days")
	private Short dueInDays;

	@JsonProperty("loan_number")
	private Integer loanNumber;

	@JsonProperty("auto_ach_req_inprogress")
	private boolean autoAchReqInprogress;

	@JsonProperty("auto_ach_req_date")
	private String autoAchReqDate;

	@JsonProperty("payment_history")
	private boolean paymentHistory;

	@JsonProperty("last_payment_amount")
	private BigDecimal lastPaymentAmount;

	@JsonProperty("last_payment_date")
	private Date lastPaymentDate;

	@JsonProperty("last_payment_account")
	private String lastPaymentAccount;

	@JsonProperty("last_payment_mode")
	private String lastPaymentMode;

	@JsonProperty("next_schedule_payment_amount")
	private BigDecimal nextScheduledPaymentAmount;

	@JsonProperty("next_schedule_payment_date")
	private Date nextScheduledPaymentDate;

	@JsonProperty("minimum_payment_due_amount")
	private BigDecimal minimumPaymentDue;

	@JsonProperty("monthly_due_date")
	private Integer paymentDueDateInMonth;

	@JsonProperty("auto_ach")
	private boolean autoAch;

	@JsonProperty("monthly_amount_due")
	private BigDecimal montlyAmountDue;

	@JsonProperty("total_payment_due")
	private BigDecimal totalPaymentDue;

	@JsonProperty("auto_pay_bank_name")
	private String autoPayBankName;

	@JsonProperty("auto_pay_account")
	private String autoPayAccount;

	@JsonProperty("paided_percentage")
	private BigDecimal paidedPercentage;
	
	@JsonProperty("total_missed_payments")
	private BigDecimal totalMissedPayments;
	
	@JsonProperty("nsf_fee")
	private BigDecimal nsfFee;

	@JsonProperty("prosper_rating")
	private String prosperRating;

	@JsonProperty("age_in_months")
	private Integer ageInMonths;

	@JsonProperty("principal_balance")
	private BigDecimal principalBalance;

	@JsonProperty("service_fees_paid")
	private BigDecimal serviceFeesPaid;

	@JsonProperty("principal_paid")
	private BigDecimal principalPaid;

	@JsonProperty("interest_paid")
	private BigDecimal interestPaid;

	@JsonProperty("prosper_fees_paid")
	private BigDecimal prosperFeesPaid;

	@JsonProperty("late_fees_paid")
	private BigDecimal lateFeesPaid;

	@JsonProperty("group_leader_reward")
	private BigDecimal groupLeaderReward;

	@JsonProperty("debt_sale_proceeds_received")
	private BigDecimal debtSaleProceedsReceived;

	@JsonProperty("loan_status_description")
	private String loanStatusDescription;

	@JsonProperty("loan_default_reason")
	private Integer loanDefaultReason;

	@JsonProperty("has_next_scheduled_payments")
	private boolean hasNextScheduledPayments;

	@JsonProperty("next_payment_due_amount")
	private BigDecimal nextPaymentDueAmount;

	@JsonProperty("total_count")
	private Integer totalRowCount;

	public Integer getTotalRowCount() {
		return totalRowCount;
	}

	@JsonProperty("in_scra")
	private boolean inScra;

	@JsonProperty("in_bankruptcy")
	private boolean inBankruptcy;

	@JsonProperty("is_paid_off")
	private boolean isPaidOff;
	
	@JsonProperty("is_prior_loan")
	private boolean isPriorLoan;
	
	@JsonProperty("fraud_indicator")
	private String fraudIndicator;

	@JsonProperty("in_debt_sale")
	private String inDebtSale;

	@JsonProperty("charge_off_status")
	private String chargeOffStatus;

	@JsonProperty("auto_ach_req_status")
	private String autoAchReqStatus;

	@JsonProperty("auto_ach_req_completed_date")
	private String autoAchReqCompletedDate;

	@JsonProperty("auto_ach_effective_date")
	private String autoAchEffectiveDate;

	@JsonProperty("is_first_bill")
	private Boolean isFirstBill;
	
	public static class PlatformLoanResultBuilder {
		private String loanDescription;
		private Date originationDate;
		private BigDecimal amountBorrowed;
		private Date maturityDate;
		private BigDecimal borrowerRate;
		private Short term;
		private BigDecimal currentPrincipalBalance;
		private BigDecimal payOffAmount;
		private BigDecimal pastDueAmount;
		private String loanStatus;
		private BigDecimal nextPaymentScheduledAmount;
		private Date nextPaymentDueDate;
		private BigDecimal lateFeeAmount;
		private Short daysPastDue;
		private Short dueInDays;
		private Integer loanNumber;
		private boolean autoAchReqInprogress;
		private String autoAchReqDate;
		private boolean paymentHistory;
		private BigDecimal lastPaymentAmount;
		private Date lastPaymentDate;
		private String lastPaymentAccount;
		private String lastPaymentMode;
		private BigDecimal nextScheduledPaymentAmount;
		private Date nextScheduledPaymentDate;
		private BigDecimal minimumPaymentDue;
		private Integer paymentDueDateInMonth;
		private boolean autoAch;
		private BigDecimal monthlyAmountDue;
		private BigDecimal totalPaymentDue;
		private String autoPayBankName;
		private String autoPayAccount;
		private BigDecimal paidedPercentage;
		private BigDecimal totalMissedPayments;
		private BigDecimal nsfFee;
		private String prosperRating;
		private Integer ageInMonths;
		private BigDecimal principalBalance;
		private BigDecimal serviceFeesPaid;
		private BigDecimal principalPaid;
		private BigDecimal interestPaid;
		private BigDecimal prosperFeesPaid;
		private BigDecimal lateFeesPaid;
		private BigDecimal groupLeaderReward;
		private BigDecimal debtSaleProceedsReceived;
		private String loanStatusDescription;
		private Integer loanDefaultReason;
		private boolean hasNextScheduledPayments;
		private BigDecimal nextPaymentDueAmount;
		private Integer totalRowCount;
		private boolean inScra;
		private boolean inBankruptcy;
		private boolean isPaidOff;
		private boolean isPriorLoan;
		private String fraudIndicator;
		private String inDebtSale;
		private String chargeOffStatus;
		private String autoAchReqStatus;
		private String autoAchReqCompletedDate;
        private String autoAchEffectiveDate;
		private Boolean isFirstBill;

		public PlatformLoanResult build() {
			final PlatformLoanResult result = new PlatformLoanResult();
			result.setOriginationDate(originationDate);
			result.setAmountBorrowed(amountBorrowed);
			result.setBorrowerRate(borrowerRate);
			result.setTerm(term);
			result.setCurrentPrincipalBalance(currentPrincipalBalance);
			result.setCurrentPrincipalBalance(currentPrincipalBalance);
			result.setPayoffAmount(payOffAmount);
			result.setPastDueDmount(pastDueAmount);
			result.setLoanStatus(loanStatus);
			result.setNextPaymentDueDate(nextPaymentDueDate);
			result.setLateFeeAmount(lateFeeAmount);
			result.setDaysPastDue(daysPastDue);
			result.setDueInDays(dueInDays);
			result.setLoanNumber(loanNumber);
			result.setAutoAchReqInprogress(autoAchReqInprogress);
			result.setAutoAchReqDate(autoAchReqDate);
			result.setPaymentHistory(paymentHistory);
			result.setLastPaymentAmount(lastPaymentAmount);
			result.setLastPaymentMode(lastPaymentMode);
			// result.setNextSchedulePaymentAmount(nextSchedulePaymentAmount);
			result.setAutoAch(autoAch);
			result.setMonthlyDmountDue(monthlyAmountDue);
			result.setTotalPaymentDue(totalPaymentDue);
			result.setAutoPayAccount(autoPayAccount);
			result.setAutoPayBankName(autoPayBankName);
			result.setPaidedPercentage(paidedPercentage);
			result.setTotalMissedPayments(totalMissedPayments);
			result.setNsfFee(nsfFee);
			result.setChargeOffStatus(chargeOffStatus);
			result.setInBankruptcy(inBankruptcy);
			result.setIsPaidOff(isPaidOff);
			result.setIsPriorLoan(isPriorLoan);
			result.setFraudIndicator(fraudIndicator);
			result.setInScra(inScra);
			result.setAutoAchReqStatus(autoAchReqStatus);
            result.setAutoAchEffectiveDate(autoAchEffectiveDate);
			return result;
		}

		public PlatformLoanResultBuilder loanDescription(String loanDescription) {
			this.loanDescription = loanDescription;
			return this;
		}

		public PlatformLoanResultBuilder originationDate(Date originationDate) {
			this.originationDate = originationDate;
			return this;
		}

		public PlatformLoanResultBuilder amountBorrowed(
				BigDecimal amountBorrowed) {
			this.amountBorrowed = amountBorrowed;
			return this;
		}

		public PlatformLoanResultBuilder borrowerRate(BigDecimal borrowerRate) {
			this.borrowerRate = borrowerRate;
			return this;
		}

		public PlatformLoanResultBuilder term(Short term) {
			this.term = term;
			return this;
		}

		public PlatformLoanResultBuilder currentPrincipalBalance(
				BigDecimal currentPrincipalBalance) {
			this.currentPrincipalBalance = currentPrincipalBalance;
			return this;
		}

		public PlatformLoanResultBuilder payoffAmount(BigDecimal payoffAmount) {
			this.payOffAmount = payoffAmount;
			return this;
		}

		public PlatformLoanResultBuilder pastDueDmount(BigDecimal pastDueDmount) {
			this.pastDueAmount = pastDueAmount;
			return this;
		}

		public PlatformLoanResultBuilder loanStatus(String loanStatus) {
			this.loanStatus = loanStatus;
			return this;
		}

		public PlatformLoanResultBuilder nextPaymentDueDate(
				Date nextPaymentDueDate) {
			this.nextPaymentDueDate = nextPaymentDueDate;
			return this;
		}

		public PlatformLoanResultBuilder lateFeeAmount(BigDecimal lateFeeAmount) {
			this.lateFeeAmount = lateFeeAmount;
			return this;
		}

		public PlatformLoanResultBuilder daysPastDue(Short daysPastDue) {
			this.daysPastDue = daysPastDue;
			return this;
		}

		public PlatformLoanResultBuilder dueInDays(Short dueInDays) {
			this.dueInDays = dueInDays;
			return this;
		}
		
		public PlatformLoanResultBuilder loanNumber(Integer loanNumber) {
			this.loanNumber = loanNumber;
			return this;
		}

		public PlatformLoanResultBuilder autoAchReqInprogress(
				Boolean autoAchReqInprogress) {
			this.autoAchReqInprogress = autoAchReqInprogress;
			return this;
		}

		public PlatformLoanResultBuilder autoAchReqDate(String autoAchReqDate) {
			this.autoAchReqDate = autoAchReqDate;
			return this;
		}

		public PlatformLoanResultBuilder paymentHistory(Boolean paymentHistory) {
			this.paymentHistory = paymentHistory;
			return this;
		}

		public PlatformLoanResultBuilder lastPaymentAmount(
				BigDecimal lastPaymentAmount) {
			this.lastPaymentAmount = lastPaymentAmount;
			return this;
		}

		public PlatformLoanResultBuilder lastPaymentMode(String lastPaymentMode) {
			this.lastPaymentMode = lastPaymentMode;
			return this;
		}

		public PlatformLoanResultBuilder autoAch(Boolean autoAch) {
			this.autoAch = autoAch;
			return this;
		}

		public PlatformLoanResultBuilder monthlyDmountDue(
				BigDecimal monthlyDmountDue) {
			this.monthlyAmountDue = monthlyAmountDue;
			return this;
		}

		public PlatformLoanResultBuilder totalPaymentDue(
				BigDecimal totalPaymentDue) {
			this.totalPaymentDue = totalPaymentDue;
			return this;
		}

		public PlatformLoanResultBuilder autoPayBankName(String autoPayBankName) {
			this.autoPayBankName = autoPayBankName;
			return this;
		}

		public PlatformLoanResultBuilder autoPayAccount(String autoPayAccount) {
			this.autoPayAccount = autoPayAccount;
			return this;
		}

		public PlatformLoanResultBuilder paidedPercentage(
				BigDecimal paidedPercentage) {
			this.paidedPercentage = paidedPercentage;
			return this;
		}

		public PlatformLoanResultBuilder totalMissedPayments(
				BigDecimal totalMissedPayments) {
			this.totalMissedPayments = totalMissedPayments;
			return this;
		}
		
		public PlatformLoanResultBuilder nsfFee(BigDecimal nsfFee) {
			this.nsfFee = nsfFee;
			return this;
		}

		public PlatformLoanResultBuilder inScra(boolean inScra) {
			this.inScra = inScra;
			return this;
		}

		public PlatformLoanResultBuilder inBankruptcy(boolean inBankruptcy) {
			this.inBankruptcy = inBankruptcy;
			return this;
		}

		public PlatformLoanResultBuilder isPaidOff(boolean isPaidOff) {
			this.isPaidOff = isPaidOff;
			return this;
		}
		
		public PlatformLoanResultBuilder isPriorLoan(boolean isPriorLoan) {
			this.isPriorLoan = isPriorLoan;
			return this;
		}

		public PlatformLoanResultBuilder fraudIndicator(String fraudIndicator) {
			this.fraudIndicator = fraudIndicator;
			return this;
		}

		public PlatformLoanResultBuilder inDebtSale(String inDebtSale) {
			this.inDebtSale = inDebtSale;
			return this;
		}

		public PlatformLoanResultBuilder chargeOffStatus(String chargeOffStatus) {
			this.chargeOffStatus = chargeOffStatus;
			return this;
		}

		public PlatformLoanResultBuilder autoAchReqStatus(
				String autoAchReqStatus) {
			this.autoAchReqStatus = autoAchReqStatus;
			return this;
		}
        public PlatformLoanResultBuilder autoAchEffectiveDate(String autoAchEffectiveDate) {
            this.autoAchEffectiveDate = autoAchEffectiveDate;
            return this;
        }

		public PlatformLoanResultBuilder autoAchReqCompletedDate(
				String autoAchReqCompletedDate) {
			this.autoAchReqCompletedDate = autoAchReqCompletedDate;
			return this;
		}

		public PlatformLoanResultBuilder isFirstBill(Boolean isFirstBill) {
			this.isFirstBill = isFirstBill;
			return this;
		}
		public static PlatformLoanResultBuilder newBuilder() {
			return new PlatformLoanResultBuilder();
		}

		public PlatformLoanResultBuilder buildUpon(
				final PlatformLoanResultBuilder original) {

			PlatformLoanResultBuilder builder = newBuilder();
			builder.originationDate(originationDate);
			builder.amountBorrowed(amountBorrowed);
			builder.borrowerRate(borrowerRate);
			builder.term(term);
			builder.currentPrincipalBalance(currentPrincipalBalance);
			builder.currentPrincipalBalance(currentPrincipalBalance);
			builder.payoffAmount(payOffAmount);
			builder.pastDueDmount(pastDueAmount);
			builder.loanStatus(loanStatus);
			builder.nextPaymentDueDate(nextPaymentDueDate);
			builder.lateFeeAmount(lateFeeAmount);
			builder.daysPastDue(daysPastDue);
			builder.dueInDays(dueInDays);
			builder.loanNumber(loanNumber);
			builder.autoAchReqInprogress(autoAchReqInprogress);
			builder.autoAchReqDate(autoAchReqDate);
			builder.paymentHistory(paymentHistory);
			builder.lastPaymentAmount(lastPaymentAmount);
			builder.lastPaymentMode(lastPaymentMode);
			builder.autoAch(autoAch);
			builder.monthlyDmountDue(monthlyAmountDue);
			builder.totalPaymentDue(totalPaymentDue);
			builder.autoPayAccount(autoPayAccount);
			builder.autoPayBankName(autoPayBankName);
			builder.paidedPercentage(paidedPercentage);
			builder.totalMissedPayments(totalMissedPayments);
			builder.nsfFee(nsfFee);
			builder.inScra(inScra);
			builder.chargeOffStatus(chargeOffStatus);
			builder.inDebtSale(inDebtSale);
			builder.fraudIndicator(fraudIndicator);
			builder.autoAchReqStatus(autoAchReqStatus);
            builder.autoAchEffectiveDate(autoAchEffectiveDate);
			builder.isFirstBill(isFirstBill);
			return builder;
		}
	}

	public String getLoanDescription() {
		return loanDescription;
	}

	public void setPayoffAmount(BigDecimal payOffAmount2) {
		// TODO Auto-generated method stub
	}

	public void setLoanDescription(String loanDescription) {
		this.loanDescription = loanDescription;
	}

	public Date getOriginationDate() {
		return originationDate;
	}

	public void setOriginationDate(Date originationDate) {
		this.originationDate = originationDate;
	}

	public BigDecimal getAmountBorrowed() {
		return amountBorrowed;
	}

	public void setAmountBorrowed(BigDecimal amountBorrowed) {
		this.amountBorrowed = amountBorrowed;
	}

	public BigDecimal getBorrowerRate() {
		return borrowerRate;
	}

	public void setBorrowerRate(BigDecimal borrowerRate) {
		this.borrowerRate = borrowerRate;
	}

	public short getTerm() {
		return term;
	}

	public void setTerm(short term) {
		this.term = term;
	}

	public BigDecimal getCurrentPrincipalBalance() {
		return currentPrincipalBalance;
	}

	public void setCurrentPrincipalBalance(BigDecimal currentPrincipalBalance) {
		this.currentPrincipalBalance = currentPrincipalBalance;
	}

	public BigDecimal getPastDueAmount() {
		return pastDueAmount;
	}

	public void setPastDueDmount(BigDecimal pastDueAmount) {
		this.pastDueAmount = pastDueAmount;
	}

	public String getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	public Date getNextPaymentDueDate() {
		return nextPaymentDueDate;
	}

	public void setNextPaymentDueDate(Date nextPaymentDueDate) {
		this.nextPaymentDueDate = nextPaymentDueDate;
	}

	public BigDecimal getLateFeeAmount() {
		return lateFeeAmount;
	}

	public void setLateFeeAmount(BigDecimal lateFeeAmount) {
		this.lateFeeAmount = lateFeeAmount;
	}

	public Short getDaysPastDue() {
		return daysPastDue;
	}

	public Short getDueInDays() {
		return dueInDays;
	}
	
	public void setDaysPastDue(Short daysPastDue) {
		this.daysPastDue = daysPastDue;
	}
	
	public void setDueInDays(Short dueInDays) {
		this.dueInDays = dueInDays;
	}

	public Integer getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(Integer loanNumber) {
		this.loanNumber = loanNumber;
	}

	public Boolean getAutoAchReqInprogress() {
		return autoAchReqInprogress;
	}

	public void setAutoAchReqInprogress(Boolean autoAchReqInprogress) {
		this.autoAchReqInprogress = autoAchReqInprogress;
	}

	public String getAutoAchReqDate() {
		return autoAchReqDate;
	}

	public void setAutoAchReqDate(String autoAchReqDate) {
		this.autoAchReqDate = autoAchReqDate;
	}

	public Boolean getPaymentHistory() {
		return paymentHistory;
	}

	public void setPaymentHistory(Boolean paymentHistory) {
		this.paymentHistory = paymentHistory;
	}

	public BigDecimal getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(BigDecimal lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public String getLastPaymentMode() {
		return lastPaymentMode;
	}

	public void setLastPaymentMode(String lastPaymentMode) {
		this.lastPaymentMode = lastPaymentMode;
	}

	/*
	 * public BigDecimal getNextSchedulePaymentAmount() { return
	 * nextSchedulePaymentAmount; }
	 * 
	 * public void setNextSchedulePaymentAmount(Double
	 * nextSchedulePaymentAmount) { this.nextSchedulePaymentAmount =
	 * nextSchedulePaymentAmount; }
	 */
	public Boolean getAutoAch() {
		return autoAch;
	}

	public void setAutoAch(Boolean autoAch) {
		this.autoAch = autoAch;
	}

	public BigDecimal getMonthlyAmountDue() {
		return montlyAmountDue;
	}

	public void setMonthlyDmountDue(BigDecimal monthlyAmountDue) {
		this.montlyAmountDue = monthlyAmountDue;
	}

	public BigDecimal getTotalPaymentDue() {
		return totalPaymentDue;
	}

	public void setTotalPaymentDue(BigDecimal totalPaymentDue) {
		this.totalPaymentDue = totalPaymentDue;
	}

	public String getAutoPayBankName() {
		return autoPayBankName;
	}

	public void setAutoPayBankName(String autoPayBankName) {
		this.autoPayBankName = autoPayBankName;
	}

	public String getAutoPayAccount() {
		return autoPayAccount;
	}

	public void setAutoPayAccount(String autoPayAccount) {
		this.autoPayAccount = autoPayAccount;
	}

	public BigDecimal getPaidedPercentage() {
		return paidedPercentage;
	}
	
	public BigDecimal getTotalMissedPayments() {
		return totalMissedPayments;
	}

	public void setPaidedPercentage(BigDecimal paidedPercentage) {
		this.paidedPercentage = paidedPercentage;
	}

	public void setTotalMissedPayments(BigDecimal totalMissedPayments) {
		this.totalMissedPayments = totalMissedPayments;
	}
	
	public BigDecimal getNsfFee() {
		return nsfFee;
	}

	public void setNsfFee(BigDecimal nsfFee) {
		this.nsfFee = nsfFee;
	}

	public boolean isInScra() {
		return inScra;
	}

	public void setInScra(boolean inScra) {
		this.inScra = inScra;
	}

	public boolean isInBankruptcy() {
		return inBankruptcy;
	}

	public boolean isPaidOff() {
		return isPaidOff;
	}
	
	public boolean isPriorLoan() {
		return isPriorLoan;
	}

	public void setInBankruptcy(boolean inBankruptcy) {
		this.inBankruptcy = inBankruptcy;
	}

	public void setIsPriorLoan(boolean isPriorLoan) {
		this.isPriorLoan = isPriorLoan;
	}
	
	public void setIsPaidOff(boolean isPaidOff) {
		this.isPaidOff = isPaidOff;
	}
	
	public String getFraudIndicator() {
		return fraudIndicator;
	}

	public void setFraudIndicator(String fraudIndicator) {
		this.fraudIndicator = fraudIndicator;
	}

	public String getInDebtSale() {
		return inDebtSale;
	}

	public void setInDebtSale(String inDebtSale) {
		this.inDebtSale = inDebtSale;
	}

	public String getChargeOffStatus() {
		return chargeOffStatus;
	}

	public void setChargeOffStatus(String chargeOffStatus) {
		this.chargeOffStatus = chargeOffStatus;
	}

	public String getAutoAchReqStatus() {
		return autoAchReqStatus;
	}

	public void setAutoAchReqStatus(String autoAchReqStatus) {
		this.autoAchReqStatus = autoAchReqStatus;
	}

	public String getAutoAchReqCompletedDate() {
		return autoAchReqCompletedDate;
	}

	public void setAutoAchReqCompletedDate(String autoAchReqCompletedDate) {
		this.autoAchReqCompletedDate = autoAchReqCompletedDate;
	}

    public String getAutoAchEffectiveDate() {
        return autoAchEffectiveDate;
    }

    public void setAutoAchEffectiveDate(String autoAchEffectiveDate) {
        this.autoAchEffectiveDate = autoAchEffectiveDate;
    }

	public Boolean getIsFirstBill() {
		return isFirstBill;
	}

	public void setIsFirstBill(Boolean isFirstBill) {
		this.isFirstBill = isFirstBill;
	}
}
