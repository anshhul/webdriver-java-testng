package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ValidationErrorResponse {

    @JsonProperty("code") private String errorCode;
    @JsonProperty("message") private String message;
    @JsonInclude(JsonInclude.Include.NON_NULL) @JsonProperty("assertions") private List<IndividualErrorResponse> allErrors = new ArrayList<IndividualErrorResponse>();;

    public String getErrorCode() {
        return errorCode;
    }

    public String getMessage() {
        return message;
    }

    public List<IndividualErrorResponse> getAllErrors() {
        return allErrors;
    }

    public ValidationErrorResponse() {
    }

    public ValidationErrorResponse(ValidationErrorResponseBuilder builder) {
        this.errorCode = builder.code;
        this.message = builder.message;
        this.allErrors.addAll(builder.allErrors);
    }

    public static class ValidationErrorResponseBuilder {

        public String code;
        public String message;
        public List<IndividualErrorResponse> allErrors = new ArrayList<IndividualErrorResponse>();
        ;

        public ValidationErrorResponseBuilder() {
        }

        public ValidationErrorResponseBuilder setErrorCode(String code) {
            this.code = code;
            return this;
        }

        public ValidationErrorResponseBuilder setMessage(String message) {
            this.message = message;
            return this;
        }

        public ValidationErrorResponseBuilder setAllErrors(List<IndividualErrorResponse> errors) {
            this.allErrors.addAll(errors);
            return this;
        }

        public ValidationErrorResponse build() {
            return new ValidationErrorResponse(this);
        }
    }

}
