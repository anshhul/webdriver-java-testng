
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class IDAnalytics {

    @JsonProperty("IDAnalytics_PullFlag")
    private String idAnalyticsPullFlag;
    @JsonProperty("IDAnalytics_HitFlag")
    private String idAnalyticsHitFlag;


    @JsonIgnore
    public String getIDAnalyticsPullFlag() {
        return idAnalyticsPullFlag;
    }

    @JsonIgnore
    public String getIDAnalyticsHitFlag() {
        return idAnalyticsHitFlag;
    }
}
