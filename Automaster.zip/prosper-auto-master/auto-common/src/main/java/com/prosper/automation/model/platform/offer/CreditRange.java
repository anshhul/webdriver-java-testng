
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"credit_grade_high", "credit_grade_low", "credit_range_name", "credit_range_id", "credit_range_value"})
public final class CreditRange {
    
    @JsonProperty("credit_grade_high")
    private Integer creditGradeHigh;
    @JsonProperty("credit_grade_low")
    private Integer creditGradeLow;
    @JsonProperty("credit_range_name")
    private String creditRangeName;
    @JsonProperty("credit_range_id")
    private Integer creditRangeId;
    @JsonProperty("credit_range_value")
    private Integer creditRangeValue;
}
