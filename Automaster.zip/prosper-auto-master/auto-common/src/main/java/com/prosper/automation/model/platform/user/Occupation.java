
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Occupation {
    
    @JsonProperty("occupationID")
    private Integer occupationId;
    @JsonProperty("occupationName")
    private String occupationName;
    
    
    public Occupation() {
    }
    
    public Occupation(final Integer occupationId, final String occupationName) {
        this.occupationId = occupationId;
        this.occupationName = occupationName;
    }
    
    @Override
    public String toString() {
        return "OccupationType{" +
                "occupationId=" + occupationId +
                ", occupationName='" + occupationName + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Occupation that = (Occupation) o;
        return Objects.equal(occupationId, that.occupationId) && Objects.equal(occupationName, that.occupationName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(occupationId, occupationName);
    }
    
    @JsonIgnore
    public Integer getOccupationId() {
        return occupationId;
    }
    
    @JsonIgnore
    public String getOccupationName() {
        return occupationName;
    }
}
