
package com.prosper.automation.constant;

import com.google.common.collect.ImmutableMap;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ListingHoldConstant {
    
    // public static final int DRIVER_LICENSE_BY_MAIL_1301 = 1301;
    public static final int IDENTITY_VERIFICATION_VALID_GOVERNMENT_IDENTIFICATION_CARD_WITH_PICTURE_1401 = 1401;
    // public static final int SSN_BY_MAIL_1501 = 1501;
    public static final int SOCIAL_SECURITY_VERIFICATION_SOCIAL_SECURITY_CARD_1601 = 1601;
    // public static final int UTILITY_BILL_BY_MAIL_1701 = 1701;
    public static final int UTILITY_BILL_ADDRESS_VERIFICATION_1801 = 1801;
    // public static final int BANK_CHECK_BY_MAIL_1901 = 1901;
    public static final int BANK_OWNERSHIP_VERIFICATION_BANK_OWNERSHIP_2001 = 2001;
    // public static final int PAY_STUB_BY_MAIL_2101 = 2101;
    public static final int INCOME_VERIFICATION_END_OF_YEAR_TAX_DOCUMENT_2201 = 2201;
    // public static final int YEAR_END_TAX_STATEMENT_BY_MAIL_2301 = 2301;
    // public static final int YEAR_END_TAX_STATEMENT_BY_FAX_2401 = 2401;
    // public static final int ORDERS_OF_DEPLOYMENT_BY_MAIL_2501 = 2501;
    // public static final int ORDERS_OF_DEPLOYMENT_BY_FAX_2601 = 2601;
    // public static final int BUSINESS_IN_BY_MAIL_2701 = 2701;
    // public static final int BUSINESS_INBYFAX_2801 = 2801;
    public static final int FRAUD_SCREEN_FRAUD_SCREEN_2901 = 2901;
    // public static final int VICTIM_STATEMENT_VICTIM_STATEMENT_3001 = 3001;
    public static final int EMPLOYMENT_VERIFICATION_PROOF_OF_CURRENT_INCOME_3101 = 3101;
    // public static final int UPDATE_CONTACT_NUMBER_3201 = 3201;
    // public static final int UPDATE_EMPLOYMENT_PHONE_NUMBER_3301 = 3301;
    // public static final int UPDATE_LEGAL_ADDRESS_3401 = 3401;
    public static final int PHONE_VERIFICATION_PHONE_VERIFICATION_3501 = 3501;
    public static final int SECURITY_ALERT_SECURITY_ALERT_3601 = 3601;
    // public static final int MILITARY_ID_BY_MAIL_MILITARY_ID_BY_MAIL_3701 = 3701;
    public static final int MILITARY_VERIFICATION_MILITARY_IDENTIFICATION_CARD_3801 = 3801;
    public static final int ADDRESS_VERIFICATION_ADDRESS_VERIFICATION_4401 = 4401;
    
    // public static final int DRIVER_LICENSE_BY_FAX_4402 = 4402;
    // public static final int APPROVAL_REVIEW_OVERALL_APPROVAL_REVIEW_5001 = 5001;
    public static final ImmutableMap<Integer, String> LISTING_HOLDS_INFO =
            new ImmutableMap.Builder()
                    // .put(1301, "DRIVER_LICENSE_BY_MAIL")
                    .put(IDENTITY_VERIFICATION_VALID_GOVERNMENT_IDENTIFICATION_CARD_WITH_PICTURE_1401,
                            "IDENTITY_VERIFICATION_VALID_GOVERNMENT_IDENTIFICATION_CARD_WITH_PICTURE")
                    // .put(1501, "SSN_BY_MAIL")
                    .put(SOCIAL_SECURITY_VERIFICATION_SOCIAL_SECURITY_CARD_1601,
                            "SOCIAL_SECURITY_VERIFICATION_SOCIAL_SECURITY_CARD")
                    // .put(1701, "UTILITY_BILL_BY_MAIL")
                    .put(UTILITY_BILL_ADDRESS_VERIFICATION_1801,
                            "UTILITY_BILL_ADDRESS_VERIFICATION_UTILITY_BILL_WITHIN_THE_LAST_30_DAYS")
                    // .put(1901, "BANK_CHECK_BY_MAIL")
                    .put(BANK_OWNERSHIP_VERIFICATION_BANK_OWNERSHIP_2001, "BANK_OWNERSHIP_VERIFICATION_BANK_OWNERSHIP")
                    // .put(2101, "PAY_STUB_BY_MAIL")
                    // .put(INCOME_VERIFICATION_END_OF_YEAR_TAX_DOCUMENT_2201
                    // , "INCOME_VERIFICATION_END_OF_YEAR_TAX_DOCUMENT")
                    // .put(2301, "YEAR_END_TAX_STATEMENT_BY_MAIL")
                    // .put(2401, "YEAR_END_TAX_STATEMENT_BY_FAX")
                    // .put(2501, "ORDERS_OF_DEPLOYMENT_BY_MAIL")
                    // .put(2601, "ORDERS_OF_DEPLOYMENT_BY_FAX")
                    // .put(2701, "BUSINESS_IN_BY_MAIL")
                    // .put(2801, "BUSINESS_IN_BY_FAX")
                    // .put(FRAUD_SCREEN_FRAUD_SCREEN_2901, "FRAUD_SCREEN_FRAUD_SCREEN")
                    // .put(3001, "VICTIM_STATEMENT_VICTIM_STATEMENT")
                    // .put(EMPLOYMENT_VERIFICATION_PROOF_OF_CURRENT_INCOME_3101
                    // , "EMPLOYMENT_VERIFICATION_PROOF_OF_CURRENT_INCOME")
                    // .put(3201, "UPDATE_CONTACT_NUMBER")
                    // .put(3301, "UPDATE_EMPLOYMENT_PHONE_NUMBER")
                    // .put(3401, "UPDATE_LEGAL_ADDRESS")
                    // .put(PHONE_VERIFICATION_PHONE_VERIFICATION_3501,
                    // "PHONE_VERIFICATION_PHONE_VERIFICATION")
                    .put(SECURITY_ALERT_SECURITY_ALERT_3601, "SECURITY_ALERT_SECURITY_ALERT")
                    // .put(3701, "MILITARY_ID_BY_MAIL_MILITARY_ID_BY_MAIL")
                    .put(MILITARY_VERIFICATION_MILITARY_IDENTIFICATION_CARD_3801,
                            "MILITARY_VERIFICATION_MILITARY_IDENTIFICATION_CARD")
                    .put(ADDRESS_VERIFICATION_ADDRESS_VERIFICATION_4401, "ADDRESS_VERIFICATION_ADDRESS_VERIFICATION")
                    // .put(4402, "DRIVER_LICENSE_BY_FAX")
                    // .put(5001, "APPROVAL_REVIEW_OVERALL_APPROVAL_REVIEW")
                    .build();
    
    
    private ListingHoldConstant() {
    }
}
