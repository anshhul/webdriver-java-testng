
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"listing_id", "requested_loan_amount", "minimum_loan_cap_amount", "maximum_loan_cap_amount",
        "has_loan_cap_restriction", "has_valid_offers", "offers"})
public final class ListedOffers {

    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("requested_loan_amount")
    private Integer requestedLoanAmount;
    @JsonProperty("minimum_loan_cap_amount")
    private Integer minimumLoanCapAmount;
    @JsonProperty("maximum_loan_cap_amount")
    private Integer maximumLoanCapAmount;
    @JsonProperty("has_loan_cap_restriction")
    private Boolean hasLoanCapRestriction;
    @JsonProperty("has_valid_offers")
    private Boolean hasValidOffers;
    @JsonProperty("offers")
    private List<Offer> offers;

    public void setListingId(Long listingId) {
        this.listingId = listingId;
    }

    public Integer getRequestedLoanAmount() {
        return requestedLoanAmount;
    }

    public void setRequestedLoanAmount(Integer requestedLoanAmount) {
        this.requestedLoanAmount = requestedLoanAmount;
    }

    public Integer getMinimumLoanCapAmount() {
        return minimumLoanCapAmount;
    }

    public void setMinimumLoanCapAmount(Integer minimumLoanCapAmount) {
        this.minimumLoanCapAmount = minimumLoanCapAmount;
    }

    public Integer getMaximumLoanCapAmount() {
        return maximumLoanCapAmount;
    }

    public void setMaximumLoanCapAmount(Integer maximumLoanCapAmount) {
        this.maximumLoanCapAmount = maximumLoanCapAmount;
    }

    public Boolean getHasLoanCapRestriction() {
        return hasLoanCapRestriction;
    }

    public void setHasLoanCapRestriction(Boolean hasLoanCapRestriction) {
        this.hasLoanCapRestriction = hasLoanCapRestriction;
    }

    public Boolean getHasValidOffers() {
        return hasValidOffers;
    }

    public void setHasValidOffers(Boolean hasValidOffers) {
        this.hasValidOffers = hasValidOffers;
    }

    public void setOffers(List<Offer> offers) {
        this.offers = offers;
    }

    @JsonIgnore
    public Long getListingId() {
        return listingId;
    }

    @JsonIgnore
    public List<Offer> getOffers() {
        return offers;
    }
}
