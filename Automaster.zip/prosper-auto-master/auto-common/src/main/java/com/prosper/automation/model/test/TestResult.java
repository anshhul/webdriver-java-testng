
package com.prosper.automation.model.test;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.prosper.automation.enumeration.test.TestStatus;

import java.util.List;

/**
 * @author pbudiono
 */
public class TestResult extends TestCase {

    private static final String UNEXPECTED_PARSING_LOG_MSG = "Unexpected parsing error occurs.";

    private TestStatus testStatus;


    private TestResult(Builder builder) {
        projectName = builder.projectName;
        ticketId = builder.ticketId;
        ticketNumber = builder.ticketNumber;
        testCaseName = builder.testCaseName;
        testMethodName = builder.testMethodName;
        testStatus = builder.testStatus;
        labels = builder.labels;
    }

    public static TestResult buildFromTestNGDescriptionString(final String testNGDescription, final TestStatus testStatus) {
        final String[] testDescriptions = testNGDescription.split(FIELD_DELIMITER);
        Preconditions.checkArgument(testDescriptions.length == 6, UNEXPECTED_PARSING_LOG_MSG);

        return new Builder().withProjectName(testDescriptions[0]).withTicketId(testDescriptions[1])
                .withTicketNumber(testDescriptions[2]).withTestCaseName(testDescriptions[3])
                .withTestMethodName(testDescriptions[4]).withTestStatus(testStatus).withLabels(null).build();
    }

    public TestStatus getTestStatus() {
        return testStatus;
    }

    @Override
    public String toString() {
        final StringBuilder stringBuilder = new StringBuilder();
        if (!Strings.isNullOrEmpty(testStatus.toString())) {
            stringBuilder.append(String.format("[%s]", testStatus));
        }
        if (!Strings.isNullOrEmpty(testMethodName)) {
            stringBuilder.append(String.format("%s", testMethodName));
        }
        return stringBuilder.toString();
    }


    public static final class Builder {

        private String projectName;

        private String ticketId;
        private String ticketNumber;

        private String testCaseName;
        private String testMethodName;

        private TestStatus testStatus;

        private List<String> labels;


        public Builder withProjectName(final String projectName) {
            this.projectName = projectName;
            return this;
        }

        public Builder withTicketId(final String ticketId) {
            this.ticketId = ticketId;
            return this;
        }

        public Builder withTicketNumber(final String ticketNumber) {
            this.ticketNumber = ticketNumber;
            return this;
        }

        public Builder withTestCaseName(final String testCaseName) {
            this.testCaseName = testCaseName;
            return this;
        }

        public Builder withTestStatus(final TestStatus testStatus) {
            this.testStatus = testStatus;
            return this;
        }

        public Builder withLabels(final List<String> labels) {
            this.labels = labels;
            return this;
        }

        public TestResult build() {
            return new TestResult(this);
        }

        public Builder withTestMethodName(final String testMethodName) {
            this.testMethodName = testMethodName;
            return this;
        }
    }
}
