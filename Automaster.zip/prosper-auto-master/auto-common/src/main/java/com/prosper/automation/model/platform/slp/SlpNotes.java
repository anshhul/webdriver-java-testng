
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SlpNotes {

    @JsonProperty("loan_note_id")
    private Long loanNoteId;

    @JsonProperty("seller_id")
    private Long sellerId;

    @JsonProperty("buyer_id")
    private Long buyerId;

    @JsonProperty("price")
    private Double price;

    @JsonProperty("fees")
    private Double fees;
    
    @JsonProperty("note_transfer_status")
    private String noteTransferStatus;
    
    
    public Long getBuyerId() {
        return buyerId;
    }
    
    public Double getFees() {
        return fees;
    }
    
    public Long getLoanNoteId() {
        return loanNoteId;
    }
    
    public String getNoteTransferStatus() {
        return noteTransferStatus;
    }
    
    public Double getPrice() {
        return price;
    }
    
    public Long getSellerId() {
        return sellerId;
    }
    
    public void setBuyerId(final Long buyerId) {
        this.buyerId = buyerId;
    }
    
    public void setFees(final Double fees) {
        this.fees = fees;
    }
    
    public void setLoanNoteId(final Long loanNoteId) {
        this.loanNoteId = loanNoteId;
    }
    
    public void setNoteTransferStatus(final String noteTransferStatus) {
        this.noteTransferStatus = noteTransferStatus;
    }
    
    public void setPrice(final Double price) {
        this.price = price;
    }
    
    public void setSellerId(final Long sellerId) {
        this.sellerId = sellerId;
    }
    
}
