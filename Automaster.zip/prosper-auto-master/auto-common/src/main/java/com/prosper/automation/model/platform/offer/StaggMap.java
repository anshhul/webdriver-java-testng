
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class StaggMap {

    @JsonProperty("REV201")
    private String rev201;
    @JsonProperty("ALL803")
    private String all803;
    @JsonProperty("BAC302")
    private String bac302;
    @JsonProperty("BAC042")
    private String bac042;
    @JsonProperty("ALL201")
    private String all201;


    private StaggMap(final Builder builder) {
        rev201 = builder.rev201;
        all803 = builder.all803;
        bac302 = builder.bac302;
        bac042 = builder.bac042;
        all201 = builder.all201;
    }


    public static final class Builder {

        private String rev201;
        private String all803;
        private String bac302;
        private String bac042;
        private String all201;


        public Builder() {
        }

        public Builder withRev201(final String rev201) {
            this.rev201 = rev201;
            return this;
        }

        public Builder withAll803(final String all803) {
            this.all803 = all803;
            return this;
        }

        public Builder withBac302(final String bac302) {
            this.bac302 = bac302;
            return this;
        }

        public Builder withBac042(final String bac042) {
            this.bac042 = bac042;
            return this;
        }

        public Builder withAll201(final String all201) {
            this.all201 = all201;
            return this;
        }

        public StaggMap build() {
            return new StaggMap(this);
        }
    }
}
