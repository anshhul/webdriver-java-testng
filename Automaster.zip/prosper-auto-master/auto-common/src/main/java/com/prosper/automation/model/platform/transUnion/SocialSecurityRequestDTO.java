
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class SocialSecurityRequestDTO {

    @JsonProperty("number")
    private String number;
    @JsonProperty("is_masked")
    private Boolean masked;


    public SocialSecurityRequestDTO() {
    }

    private SocialSecurityRequestDTO(Builder builder) {
        setNumber(builder.number);
        setMasked(builder.masked);
    }

    @JsonIgnore
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @JsonIgnore
    public Boolean getMasked() {
        return masked;
    }

    public void setMasked(Boolean masked) {
        this.masked = masked;
    }


    public static final class Builder {

        private String number;
        private Boolean masked;


        public Builder() {
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withMasked(Boolean val) {
            masked = val;
            return this;
        }

        public SocialSecurityRequestDTO build() {
            return new SocialSecurityRequestDTO(this);
        }
    }
}
