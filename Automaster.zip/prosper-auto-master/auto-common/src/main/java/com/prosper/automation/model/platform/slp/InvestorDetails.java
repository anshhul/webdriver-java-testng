
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class InvestorDetails {
    
    @JsonProperty("allocated_month_to_date")
    private List<InvestorLoanGroupings> allocatedMonthToDate;

    @JsonProperty("purchased_month_to_date")
    private List<InvestorLoanGroupings> purchasedMonthToDate;
    
    @JsonProperty("total_allocated")
    private Double totalAllocated;
    
    @JsonProperty("total_purchased")
    private Double totalPurchased;
    
    
    public List<InvestorLoanGroupings> getAllocatedMonthToDate() {
        return allocatedMonthToDate;
    }
    
    public List<InvestorLoanGroupings> getPurchasedMonthToDate() {
        return purchasedMonthToDate;
    }
    
    public Double getTotalAllocated() {
        return totalAllocated;
    }
    
    public Double getTotalPurchased() {
        return totalPurchased;
    }
    
    public void setAllocatedMonthToDate(final List<InvestorLoanGroupings> allocatedMonthToDate) {
        this.allocatedMonthToDate = allocatedMonthToDate;
    }
    
    public void setPurchasedMonthToDate(final List<InvestorLoanGroupings> purchasedMonthToDate) {
        this.purchasedMonthToDate = purchasedMonthToDate;
    }
    
    public void setTotalAllocated(final Double totalAllocated) {
        this.totalAllocated = totalAllocated;
    }
    
    public void setTotalPurchased(final Double totalPurchased) {
        this.totalPurchased = totalPurchased;
    }
    
}
