package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.BankAccountInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectBankAccountInfoComparator implements Comparator<BankAccountInfo> {
    @Override public int compare(BankAccountInfo left, BankAccountInfo right) {
        if (right != null && right.getBankName() != null ?
                !left.getBankName().equals(right.getBankName()) :
                left != null && left.getBankName() != null)
            return 1;
        if (right != null && right.getRoutingNumber() != null ?
                !left.getRoutingNumber().equals(right.getRoutingNumber()) :
                left != null && left.getRoutingNumber() != null)
            return 1;
        if (right != null && right.getFirstAccountHolderName() != null ?
                !left.getFirstAccountHolderName()
                        .equals(right.getFirstAccountHolderName()) :
                left != null && left.getFirstAccountHolderName() != null)
            return 1;
        if (right != null && right.getAccountNumber() != null?
                !left.getAccountNumber().equals(right.getAccountNumber()) :
                left != null && left.getAccountNumber() != null)
            return 1;
        return 0;
    }
}
