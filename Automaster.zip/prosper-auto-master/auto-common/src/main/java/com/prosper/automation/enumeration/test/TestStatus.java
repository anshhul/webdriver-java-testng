
package com.prosper.automation.enumeration.test;

import com.prosper.automation.exception.AutomationException;

/**
 * Enumeration representation for test status.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum TestStatus {
    PASS("1"), SKIP("4"), FAIL("2");

    private String testStatusId;


    TestStatus(final String testStatusId) {
        this.testStatusId = testStatusId;
    }

    public String getId() {
        return testStatusId;
    }

    public static TestStatus getStatus(int id) throws AutomationException {
        switch (id) {
            case 1:
                return TestStatus.PASS;
            case 2:
                return TestStatus.FAIL;
            case 4:
                return TestStatus.SKIP;
            default: {
                throw new AutomationException("Unsupported Test Status");
            }
        }
    }
}
