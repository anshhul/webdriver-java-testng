package com.prosper.automation.model.platform.listing;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.model.platform.transUnion.ScoreResponseDTO;

import java.util.UUID;

/**
 * Created by rchintapalli on 11/30/16.
 */
public class ListingCRMappingDTO {

    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("external_credit_report_id")
    private UUID externalCreditReportId;
    @JsonProperty("credit_bureau")
    private String creditBureau;
    @JsonProperty("is_decision_bureau")
    private Boolean isDecisionBureau;

    public ListingCRMappingDTO() {
    }

    private ListingCRMappingDTO(Builder builder) {
        setListingId(builder.listingId);
        setExternalCreditReportId(builder.externalCreditReportId);
        setCreditBureau(builder.creditBureau);
        setIsDecisionBureau(builder.isDecisionBureau);
    }

    public Long getListingId() {
        return listingId;
    }

    public UUID getExternalCreditReportId() {
        return externalCreditReportId;
    }

    public String getCreditBureau() {
        return creditBureau;
    }

    public Boolean getIsDecisionBureau() {
        return isDecisionBureau;
    }

    public void setListingId(Long listingId) {
        this.listingId = listingId;
    }

    public void setExternalCreditReportId(UUID externalCreditReportId) {
        this.externalCreditReportId = externalCreditReportId;
    }

    public void setCreditBureau(String creditBureau) {
        this.creditBureau = creditBureau;
    }

    public void setIsDecisionBureau(Boolean decisionBureau) {
        isDecisionBureau = decisionBureau;
    }

    public static final class Builder {
        private Long listingId;
        private UUID externalCreditReportId;
        private String creditBureau;
        private Boolean isDecisionBureau;

        public Builder(){
        }

        public Builder withListingId(Long val){
            listingId=val;
            return this;
        }

        public Builder withExternalCreditReportId(UUID val){
            externalCreditReportId = val;
            return this;
        }

        public Builder withCreditBureau(String val){
            creditBureau = val;
            return this;
        }

        public Builder withIsDecisionBureau(Boolean val){
            isDecisionBureau = val;
            return this;
        }

        public ListingCRMappingDTO build(){
            return new ListingCRMappingDTO(this);
        }

    }


}
