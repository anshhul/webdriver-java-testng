package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by aamalraj on 1/7/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder({
        "success"}) public final class UserResendVerificationEmailResponse {

    @JsonProperty("success") private Boolean response;

    @JsonIgnore public Boolean getResponse() {
        return response;
    }

}
