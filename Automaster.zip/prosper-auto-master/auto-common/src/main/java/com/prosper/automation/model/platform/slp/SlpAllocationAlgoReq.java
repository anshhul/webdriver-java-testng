
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonInclude(Include.NON_NULL)
public class SlpAllocationAlgoReq {
    
    @JsonProperty("loan_detail_filter")
    private LoanDetailFilter loanDetailFilter;

    @JsonProperty("minimum_daily_investment_amount")
    private String minimumDailyInvestmentAmount;

    @JsonProperty("test_investor_ids")
    private List<Long> testInvestorIds;
    
    @JsonProperty("dry_run")
    private Boolean dryRun;
    
    
    public static class SlpAllocationAlgoReqBuilder {
        
        private Boolean dryRun;
        private LoanDetailFilter loanDetailFilter;
        private String minimumDailyInvestmentAmount;
        private List<Long> testInvestorIds;
        
        
        public SlpAllocationAlgoReq build() {
            final SlpAllocationAlgoReq result = new SlpAllocationAlgoReq();
            
            result.setDryRun(dryRun);
            result.setLoanDetailFilter(loanDetailFilter);
            result.setMinimumDailyInvestmentAmount(minimumDailyInvestmentAmount);
            result.setTestInvestorIds(testInvestorIds);
            return result;
        }
        
        public SlpAllocationAlgoReqBuilder dryRun(final Boolean value) {
            this.dryRun = value;
            return this;
        }
        
        public SlpAllocationAlgoReqBuilder loanDetailFilter(final LoanDetailFilter value) {
            this.loanDetailFilter = value;
            return this;
        }
        
        public SlpAllocationAlgoReqBuilder minimumDailyInvestmentAmount(final String value) {
            this.minimumDailyInvestmentAmount = value;
            return this;
        }
        
        public SlpAllocationAlgoReqBuilder testInvestorIds(final List<Long> value) {
            this.testInvestorIds = value;
            return this;
        }
    }


    public static SlpAllocationAlgoReqBuilder buildUpon(final SlpAllocationAlgoReq original) {
        final SlpAllocationAlgoReqBuilder builder = newBuilder();
        builder.dryRun(original.getDryRun());
        builder.loanDetailFilter(original.getLoanDetailFilter());
        builder.minimumDailyInvestmentAmount(original.getMinimumDailyInvestmentAmount());
        builder.testInvestorIds(original.getTestInvestorIds());
        return builder;
    }
    
    public static SlpAllocationAlgoReqBuilder newBuilder() {
        return new SlpAllocationAlgoReqBuilder();
    }
    
    public Boolean getDryRun() {
        return dryRun;
    }
    
    public LoanDetailFilter getLoanDetailFilter() {
        return loanDetailFilter;
    }
    
    public String getMinimumDailyInvestmentAmount() {
        return minimumDailyInvestmentAmount;
    }
    
    public List<Long> getTestInvestorIds() {
        return testInvestorIds;
    }
    
    public void setDryRun(final Boolean dryRun) {
        this.dryRun = dryRun;
    }

    public void setLoanDetailFilter(final LoanDetailFilter loanDetailFilter) {
        this.loanDetailFilter = loanDetailFilter;
    }

    public void setMinimumDailyInvestmentAmount(final String minimumDailyInvestmentAmount) {
        this.minimumDailyInvestmentAmount = minimumDailyInvestmentAmount;
    }

    public void setTestInvestorIds(final List<Long> testInvestorIds) {
        this.testInvestorIds = testInvestorIds;
    }
    
}
