package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by rchintapalli on 12/06/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserCreditReportMappingRequest {

    @JsonProperty("entities")
    private  List<UserCreditReportMappingRequestDTO> userCRMappingRequest;
    @JsonProperty("entity_count")
    private Integer entityCount;
    @JsonProperty("entity_total_count")
    private Integer entityTotalCount;

    public List<UserCreditReportMappingRequestDTO> getUserMappingResponse() {
        return userCRMappingRequest;
    }

    public List<UserCreditReportMappingRequestDTO> getUserCRMappingRequest() {
        return userCRMappingRequest;
    }

    public void setUserCRMappingRequest(List<UserCreditReportMappingRequestDTO> userCRMappingRequest) {
        this.userCRMappingRequest = userCRMappingRequest;
    }

    public Integer getEntityCount() {
        return entityCount;
    }

    public void setEntityCount(Integer entityCount) {
        this.entityCount = entityCount;
    }

    public Integer getEntityTotalCount() {
        return entityTotalCount;
    }

    public void setEntityTotalCount(Integer entityTotalCount) {
        this.entityTotalCount = entityTotalCount;
    }

    public UserCreditReportMappingRequest(Builder builder){
        setUserCRMappingRequest(builder.userCRMappingRequest);
        setEntityCount(builder.entityCount);
        setEntityTotalCount(builder.entityTotalCount);
    }

    public static final class Builder {
        private List<UserCreditReportMappingRequestDTO> userCRMappingRequest;
        private Integer entityCount;
        private Integer entityTotalCount;

        public Builder(){
        }

        public Builder withUserCreditReportMappingRequestDTO(List<UserCreditReportMappingRequestDTO> val){
            userCRMappingRequest =val;
            return this;
        }

        public Builder withEntityCount(Integer val){
            entityCount = val;
            return this;
        }

        public Builder withEntityTotalCount(Integer val){
            entityTotalCount = val;
            return this;
        }

        public UserCreditReportMappingRequest build() {
            return new UserCreditReportMappingRequest(this);
        }
    }
}
