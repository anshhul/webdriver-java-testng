
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchProspectResponse {
    
    @JsonProperty("results")
    private List<Prospect> prospects;
    @JsonProperty("limit")
    private Integer limit;
    @JsonProperty("offset")
    private Integer offset;
    @JsonProperty("sort_by")
    private List<SortInfo> sortBy;
    @JsonProperty("total_count")
    private Integer totalCount;
    @JsonProperty("total_pages")
    private Integer totalPages;
    @JsonProperty("result_count")
    private Integer resultCount;
    
    
    @JsonIgnore
    public List<Prospect> getProspects() {
        return prospects;
    }
    
    @JsonIgnore
    public int getLimit() {
        return limit;
    }
    
    @JsonIgnore
    public int getOffset() {
        return offset;
    }
    
    @JsonIgnore
    public List<SortInfo> getSortBy() {
        return sortBy;
    }
    
    @JsonIgnore
    public int getTotalCount() {
        return totalCount;
    }
    
    @JsonIgnore
    public int getTotalPages() {
        return totalPages;
    }
    
    @JsonIgnore
    public int getResultCount() {
        return resultCount;
    }
}
