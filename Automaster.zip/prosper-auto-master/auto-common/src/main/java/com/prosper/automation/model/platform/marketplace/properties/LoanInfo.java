
package com.prosper.automation.model.platform.marketplace.properties;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by rsubramanyam on 2/20/16.
 */
public class LoanInfo {

    @JsonProperty("loan_purpose_id")
    private String loanPurpose;

    @JsonProperty("loan_amount")
    private String loanAmount;

    @JsonProperty("self_reported_credit_score")
    private String selfReportedCreditScore;

    @JsonProperty("relation_to_applicant")
    private String relationToApplicant;

    @JsonProperty("patient_name")
    private String patientName;


    public LoanInfo() {
    }

    private LoanInfo(LoanInfoBuilder builder) {
        loanPurpose = builder.loanPurpose;
        loanAmount = builder.loanAmount;
        selfReportedCreditScore = builder.selfReportedCreditScore;
        relationToApplicant = builder.relationToApplicant;
        patientName = builder.patientName;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LoanInfo that = (LoanInfo) o;
        return Objects.equal(loanAmount, that.loanAmount) && Objects.equal(loanPurpose, that.loanPurpose) && Objects
                .equal(selfReportedCreditScore, that.selfReportedCreditScore);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(loanAmount, loanPurpose, selfReportedCreditScore);
    }

    @Override
    public String toString() {
        return "LoanInfo{" +
                "loanPurpose='" + loanPurpose + '\'' +
                ", loanAmount='" + loanAmount + '\'' +
                ", selfReportedCreditScore='" + selfReportedCreditScore + '\'' +
                '}';
    }

    public String getLoanPurpose() {
        return loanPurpose;
    }

    public String getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(String loanAmount) {
        this.loanAmount = loanAmount;
    }

    public String getSelfReportedCreditScore() {
        return selfReportedCreditScore;
    }


    public static class LoanInfoBuilder {

        private String loanPurpose;
        private String loanAmount;
        private String selfReportedCreditScore;
        private String relationToApplicant;
        private String patientName;


        public LoanInfoBuilder() {
        }

        public LoanInfoBuilder withLoanPurpose(String val) {
            loanPurpose = val;
            return this;
        }

        public LoanInfoBuilder withLoanAmount(String val) {
            loanAmount = val;
            return this;
        }

        public LoanInfoBuilder withSelfReportedCreditScore(String val) {
            selfReportedCreditScore = val;
            return this;
        }

        public LoanInfoBuilder withRelationToApplicant(String val) {
            relationToApplicant = val;
            return this;
        }

        public LoanInfoBuilder withPatientName(String val) {
            patientName = val;
            return this;
        }

        public LoanInfo build() {
            return new LoanInfo(this);
        }
    }
}
