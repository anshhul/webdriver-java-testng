package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;
import java.util.UUID;

/**
 * Created by rchintapalli on 12/06/16.
 */
public class ProspectCreditReportMappingDTO {

    @JsonProperty("prospect_id")
    private UUID prospectId;
    @JsonProperty("external_credit_report_id")
    private UUID externalCreditReportId;
    @JsonProperty("credit_bureau")
    private String creditBureau;
    @JsonProperty("is_decision_bureau")
    private Boolean isDecisionBureau;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss Z", timezone = "GMT")
    @JsonProperty("credit_pull_date")
    private Date creditPullDate;


    public ProspectCreditReportMappingDTO() {
    }

    private ProspectCreditReportMappingDTO(Builder builder) {
        setProspectId(builder.prospectId);
        setExternalCreditReportId(builder.externalCreditReportId);
        setCreditBureau(builder.creditBureau);
        setIsDecisionBureau(builder.isDecisionBureau);
        setCreditPullDate(builder.creditPullDate);
    }

    public UUID getProspectId() {
        return prospectId;
    }

    public void setProspectId(UUID prospectId) {
        this.prospectId = prospectId;
    }

    public UUID getExternalCreditReportId() {
        return externalCreditReportId;
    }

    public void setExternalCreditReportId(UUID externalCreditReportId) {
        this.externalCreditReportId = externalCreditReportId;
    }

    public String getCreditBureau() {
        return creditBureau;
    }

    public void setCreditBureau(String creditBureau) {
        this.creditBureau = creditBureau;
    }

    public Boolean getIsDecisionBureau() {
        return isDecisionBureau;
    }

    public void setIsDecisionBureau(Boolean isDecisionBureau) {
        this.isDecisionBureau = isDecisionBureau;
    }

    public Date getCreditPullDate() {
        return creditPullDate;
    }

    public void setCreditPullDate(Date creditPullDate) {
        this.creditPullDate = creditPullDate;
    }

    public static final class Builder {
        private UUID prospectId;
        private UUID externalCreditReportId;
        private String creditBureau;
        private Boolean isDecisionBureau;
        private Date creditPullDate;

        public Builder(){
        }

        public Builder withProspectId(UUID val){
            this.prospectId=val;
            return this;
        }

        public Builder withExternalCreditReportId(UUID val){
            this.externalCreditReportId = val;
            return this;
        }

        public Builder withCreditBureau(String val){
            this.creditBureau = val;
            return this;
        }

        public Builder withIsDecisionBureau(Boolean val){
            this.isDecisionBureau = val;
            return this;
        }

        public Builder withCreditPullDate(Date val){
            this.creditPullDate = val;
            return this;
        }

        public ProspectCreditReportMappingDTO build(){
            return new ProspectCreditReportMappingDTO(this);
        }

    }


}
