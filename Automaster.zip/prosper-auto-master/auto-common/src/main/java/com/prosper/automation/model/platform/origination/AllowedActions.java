package com.prosper.automation.model.platform.origination;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author sphatak
 *
 */
public class AllowedActions {

	@JsonProperty("canUnwind")
	private Boolean canUnwind;
	@JsonProperty("canDelay")
	private Boolean canDelay;
	@JsonProperty("canRetry")
	private Boolean canRetry;

	public Boolean getCanUnwind() {
		return canUnwind;
	}

	public void setCanUnwind(Boolean canUnwind) {
		this.canUnwind = canUnwind;
	}

	public Boolean getCanDelay() {
		return canDelay;
	}

	public void setCanDelay(Boolean canDelay) {
		this.canDelay = canDelay;
	}

	public Boolean getCanRetry() {
		return canRetry;
	}

	public void setCanRetry(Boolean canRetry) {
		this.canRetry = canRetry;
	}
}
