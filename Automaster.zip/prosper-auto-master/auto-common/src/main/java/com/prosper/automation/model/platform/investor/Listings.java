package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class Listings {

    private String listingTitle;
    private Double investedAmount;
    private String listingAmount;
    private int loanTermMonths;
    private int currentYield;
    private float amountFunded;
    private String creditGrade;
    private int verificationStage;
    private float percentFunded;
    private float effectiveYield;
    private float estimatedLoss;
    private float estimatedReturn;
    private int listingDuration;
    private String listingNumber;
    private String status;
    private String statusReason;
    private String estimatedEndDate;
    private int listingStatus;
    private String startDate;
    private String noteNumber;

    @JsonProperty("amount_funded")
    public float getAmountFunded() {
        return amountFunded;
    }

    @JsonProperty("credit_grade")
    public String getCreditGrade() {
        return creditGrade;
    }

    @JsonProperty("current_yield")
    public int getCurrentYield() {
        return currentYield;
    }

    @JsonProperty("effective_yield")
    public float getEffectiveYield() {
        return effectiveYield;
    }

    @JsonProperty("estimated_end_date")
    public String getEstimatedEndDate() {
        return estimatedEndDate;
    }

    @JsonProperty("estimated_loss")
    public float getEstimatedLoss() {
        return estimatedLoss;
    }

    @JsonProperty("estimated_return")
    public float getEstimatedReturn() {
        return estimatedReturn;
    }

    @JsonProperty("invested_amount")
    public Double getInvestedAmount() {
        return investedAmount;
    }

    @JsonProperty("listing_amount")
    public String getListingAmount() {
        return listingAmount;
    }

    @JsonProperty("listing_duration")
    public int getListingDuration() {
        return listingDuration;
    }

    @JsonProperty("listing_number")
    public String getListingNumber() {
        return listingNumber;
    }

    @JsonProperty("listing_status")
    public int getListingStatus() {
        return listingStatus;
    }

    @JsonProperty("listing_title")
    public String getListingTitle() {
        return listingTitle;
    }

    @JsonProperty("loan_term_months")
    public int getLoanTermMonths() {
        return loanTermMonths;
    }

    @JsonProperty("note_number")
    public String getNoteNumber() {
        return noteNumber;
    }

    @JsonProperty("percent_funded")
    public float getPercentFunded() {
        return percentFunded;
    }

    @JsonProperty("start_date")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status_reason")
    public String getStatusReason() {
        return statusReason;
    }

    @JsonProperty("verification_stage")
    public int getVerificationStage() {
        return verificationStage;
    }

    public void setAmountFunded(final float amountFunded) {
        this.amountFunded = amountFunded;
    }

    public void setCreditGrade(final String creditGrade) {
        this.creditGrade = creditGrade;
    }

    public void setCurrentYield(final int currentYield) {
        this.currentYield = currentYield;
    }

    public void setEffectiveYield(final float effectiveYield) {
        this.effectiveYield = effectiveYield;
    }

    public void setEstimatedEndDate(final String estimatedEndDate) {
        this.estimatedEndDate = estimatedEndDate;
    }

    public void setEstimatedLoss(final float estimatedLoss) {
        this.estimatedLoss = estimatedLoss;
    }

    public void setEstimatedReturn(final float estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public void setInvestedAmount(final Double investedAmount) {
        this.investedAmount = investedAmount;
    }

    public void setInvestedAmountAmount(final Double investedAmount) {
        this.investedAmount = investedAmount;
    }

    public void setListingAmount(final String listingAmount) {
        this.listingAmount = listingAmount;
    }

    public void setListingDuration(final int listingDuration) {
        this.listingDuration = listingDuration;
    }

    public void setListingNumber(final String listingNumber) {
        this.listingNumber = listingNumber;
    }

    public void setListingStatus(final int listingStatus) {
        this.listingStatus = listingStatus;
    }

    public void setListingTitle(final String listingTitle) {
        this.listingTitle = listingTitle;
    }

    public void setLoanTermMonths(final int loanTermMonths) {
        this.loanTermMonths = loanTermMonths;
    }

    public void setNoteNumber(final String noteNumber) {
        this.noteNumber = noteNumber;
    }

    public void setPercentFunded(final float percentFunded) {
        this.percentFunded = percentFunded;
    }

    public void setStartDate(final String startDate) {
        this.startDate = startDate;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public void setStatusReason(final String statusReason) {
        this.statusReason = statusReason;
    }

    public void setVerificationStage(final int verificationStage) {
        this.verificationStage = verificationStage;
    }

}
