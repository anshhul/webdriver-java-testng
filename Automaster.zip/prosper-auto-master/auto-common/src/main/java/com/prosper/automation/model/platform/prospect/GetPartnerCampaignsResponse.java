package com.prosper.automation.model.platform.prospect;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 8/8/16.
 */
public final class GetPartnerCampaignsResponse {

	@JsonProperty("result")
	private List<PartnerCampaign> partnerCampaigns;
	@JsonProperty("result_count")
	private Integer resultCount;
	@JsonProperty("total_count")
	private Integer totalCount;

	public GetPartnerCampaignsResponse() {
	}

	@JsonIgnore
	public List<PartnerCampaign> getPartnerCampaigns() {
		return partnerCampaigns;
	}

	@JsonIgnore
	public Integer getResultCount() {
		return resultCount;
	}

	@JsonIgnore
	public Integer getTotalCount() {
		return totalCount;
	}
}
