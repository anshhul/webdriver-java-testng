package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectLoanInfoComparator implements Comparator<LoanInfo> {
    @Override public int compare(LoanInfo left, LoanInfo right) {
        if (!left.getLoanAmount().equalsIgnoreCase(right.getLoanAmount()))
            return 1;
        if (!left.getLoanPurpose().equalsIgnoreCase(right.getLoanPurpose()))
            return 1;
        return 0;
    }
}
