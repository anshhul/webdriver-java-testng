
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ScoreResponseDTO {

    @JsonProperty("score_model_type")
    private String scoreModelType;
    private String results;
    @JsonProperty("is_derogatory_alert")
    private Boolean derogatoryAlert;
    @JsonProperty("is_file_inquiries_impacted_score")
    private Boolean fileInquiriesImpactedScore;
    @JsonProperty("no_score_reason")
    private String noScoreReason;
    @JsonProperty("adverse_action_factors")
    private ScoreFactorResponseDTO factors;
    @JsonProperty("score_card")
    private String scoreCard;


    public ScoreResponseDTO() {
    }

    private ScoreResponseDTO(Builder builder) {
        setScoreModelType(builder.scoreModelType);
        setResults(builder.results);
        setDerogatoryAlert(builder.derogatoryAlert);
        setFileInquiriesImpactedScore(builder.fileInquiriesImpactedScore);
        setNoScoreReason(builder.noScoreReason);
        setFactors(builder.factors);
        setScoreCard(builder.scoreCard);
    }

    @JsonIgnore
    public String getScoreModelType() {
        return scoreModelType;
    }

    public void setScoreModelType(String scoreModelType) {
        this.scoreModelType = scoreModelType;
    }

    @JsonIgnore
    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }

    @JsonIgnore
    public Boolean getDerogatoryAlert() {
        return derogatoryAlert;
    }

    public void setDerogatoryAlert(Boolean derogatoryAlert) {
        this.derogatoryAlert = derogatoryAlert;
    }

    @JsonIgnore
    public Boolean getFileInquiriesImpactedScore() {
        return fileInquiriesImpactedScore;
    }

    public void setFileInquiriesImpactedScore(Boolean fileInquiriesImpactedScore) {
        this.fileInquiriesImpactedScore = fileInquiriesImpactedScore;
    }

    @JsonIgnore
    public String getNoScoreReason() {
        return noScoreReason;
    }

    public void setNoScoreReason(String noScoreReason) {
        this.noScoreReason = noScoreReason;
    }

    @JsonIgnore
    public ScoreFactorResponseDTO getFactors() {
        return factors;
    }

    public void setFactors(ScoreFactorResponseDTO factors) {
        this.factors = factors;
    }

    @JsonIgnore
    public String getScoreCard() {
        return scoreCard;
    }

    public void setScoreCard(String scoreCard) {
        this.scoreCard = scoreCard;
    }


    public static final class Builder {

        private String scoreModelType;
        private String results;
        private Boolean derogatoryAlert;
        private Boolean fileInquiriesImpactedScore;
        private String noScoreReason;
        private ScoreFactorResponseDTO factors;
        private String scoreCard;


        public Builder() {
        }

        public Builder withScoreModelType(String val) {
            scoreModelType = val;
            return this;
        }

        public Builder withResults(String val) {
            results = val;
            return this;
        }

        public Builder withDerogatoryAlert(Boolean val) {
            derogatoryAlert = val;
            return this;
        }

        public Builder withFileInquiriesImpactedScore(Boolean val) {
            fileInquiriesImpactedScore = val;
            return this;
        }

        public Builder withNoScoreReason(String val) {
            noScoreReason = val;
            return this;
        }

        public Builder withFactors(ScoreFactorResponseDTO val) {
            factors = val;
            return this;
        }

        public Builder withScoreCard(String val) {
            scoreCard = val;
            return this;
        }

        public ScoreResponseDTO build() {
            return new ScoreResponseDTO(this);
        }
    }
}
