
package com.prosper.automation.model.platform.analytics;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 7/18/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class LogEvent {

    @JsonProperty("source")
    private String source;
    @JsonProperty("application_tracking_id")
    private String applicationTrackingId;
    @JsonProperty("login_attempt_event")
    private LoginAttemptEvent loginAttemptEvent;
    @JsonProperty("browser_event")
    private BrowserEvent browserEvent;


    private LogEvent(Builder builder) {
        source = builder.source;
        applicationTrackingId = builder.applicationTrackingId;
        loginAttemptEvent = builder.loginAttemptEvent;
        browserEvent = builder.browserEvent;
    }


    public static final class Builder {

        private String source;
        private String applicationTrackingId;
        private LoginAttemptEvent loginAttemptEvent;
        private BrowserEvent browserEvent;


        public Builder() {
        }

        public Builder withSource(String val) {
            source = val;
            return this;
        }

        public Builder withApplicationTrackingId(String val) {
            applicationTrackingId = val;
            return this;
        }

        public Builder withLoginAttemptEvent(LoginAttemptEvent val) {
            loginAttemptEvent = val;
            return this;
        }

        public Builder withBrowserEvent(BrowserEvent val) {
            browserEvent = val;
            return this;
        }

        public LogEvent build() {
            return new LogEvent(this);
        }
    }
}
