package com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators;

import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class PartnerRequestAddressInfoComparator implements Comparator<AddressInfo> {

    @Override public int compare(AddressInfo left, AddressInfo right) {
        if (right != null ? !left.equals(right) :
                left != null)
            return 1;
        return 0;
    }
}