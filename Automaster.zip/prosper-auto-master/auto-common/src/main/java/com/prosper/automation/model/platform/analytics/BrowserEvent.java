
package com.prosper.automation.model.platform.analytics;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 7/19/16.
 */
public final class BrowserEvent {

    @JsonProperty("url")
    private String url;
    @JsonProperty("page_data")
    private String pageData;
    @JsonProperty("session_info_id")
    private String sessionInfoId;
    @JsonProperty("login_id")
    private String loginId;


    private BrowserEvent(Builder builder) {
        url = builder.url;
        pageData = builder.pageData;
        sessionInfoId = builder.sessionInfoId;
        loginId = builder.loginId;
    }


    public static final class Builder {

        private String url;
        private String pageData;
        private String sessionInfoId;
        private String loginId;


        public Builder() {
        }

        public Builder withUrl(String val) {
            url = val;
            return this;
        }

        public Builder withPageData(String val) {
            pageData = val;
            return this;
        }

        public Builder withSessionInfoId(String val) {
            sessionInfoId = val;
            return this;
        }

        public Builder withLoginId(String val) {
            loginId = val;
            return this;
        }

        public BrowserEvent build() {
            return new BrowserEvent(this);
        }
    }
}
