
package com.prosper.automation.model.platform.notes;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public final class NotesUserDetails {
    
    private String email;
    private Long userId;


    /**
     * @return
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * @return
     */
    public Long getUserId() {
        return userId;
    }
    
    /**
     * @param email
     */
    public void setEmail(final String email) {
        this.email = email;
    }
    
    /**
     * @param userId
     */
    public void setUserId(final Long userId) {
        this.userId = userId;
    }

}
