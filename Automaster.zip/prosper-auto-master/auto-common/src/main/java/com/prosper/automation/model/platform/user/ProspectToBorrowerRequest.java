
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.LendingAccreditation;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ProspectToBorrowerRequest {
    
    @JsonProperty("prospect_id")
    private UUID prospectId;
    @JsonProperty("offer_id")
    private String offerId;
    @JsonProperty("password")
    private String password;
    @JsonProperty("lending_accreditation")
    private LendingAccreditation lendingAccreditation;
    
    
    private ProspectToBorrowerRequest(final Builder builder) {
        prospectId = builder.prospectId;
        offerId = builder.offerId;
        password = builder.password;
        lendingAccreditation = builder.lendingAccreditation;
    }
    
    
    public static final class Builder {
        
        private UUID prospectId;
        private String offerId;
        private String password;
        private LendingAccreditation lendingAccreditation;
        
        
        public Builder() {
        }
        
        public Builder withProspectId(final UUID prospectId) {
            this.prospectId = prospectId;
            return this;
        }
        
        public Builder withOfferId(final String offerId) {
            this.offerId = offerId;
            return this;
        }
        
        public Builder withPassword(final String password) {
            this.password = password;
            return this;
        }
        
        public Builder withLendingAccreditation(final LendingAccreditation lendingAccreditation) {
            this.lendingAccreditation = lendingAccreditation;
            return this;
        }
        
        public ProspectToBorrowerRequest build() {
            return new ProspectToBorrowerRequest(this);
        }
    }
}
