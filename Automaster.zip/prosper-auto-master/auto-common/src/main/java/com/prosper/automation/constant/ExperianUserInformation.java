
package com.prosper.automation.constant;

import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import org.joda.time.DateTime;
import java.util.Date;



/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ExperianUserInformation {

    public static final String ADDRESS_KEY = "address";
    public static final String CITY_KEY = "city";
    public static final String STATE_KEY = "state";
    public static final String ZIP_KEY = "zip";
    public static final String FIRST_NAME_KEY = "firstName";
    public static final String LAST_NAME_KEY = "lastName";
    public static final String DATE_OF_BIRTH_KEY = "dateOfBirth";
    public static final String SSN_KEY = "ssn";
    public static final String STATE_OF_RESIDENCE = "stateOfResidence";
    public static final String ADDRESS_TYPE_ID_KEY = "addressTypeId";

    private static final ImmutableMap<String, String> AA_USER = ImmutableMap.<String, String> builder()
            .put(FIRST_NAME_KEY, "MONISE")
            .put(LAST_NAME_KEY, "KELLY")
            .put(DATE_OF_BIRTH_KEY, "01/01/1963")
            .put(SSN_KEY, "666302683")
            .put(ADDRESS_KEY, "14511 STAR CROSS TRL")
            .put(CITY_KEY, "HELOTES")
            .put(STATE_KEY, "TX")
            .put(ZIP_KEY, "780234050")
            .build();
    private static final ImmutableMap<String, String> NC_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "TAHIR")
            .put(LAST_NAME_KEY, "BESS")
            .put(DATE_OF_BIRTH_KEY, "01/01/1932")
            .put(SSN_KEY, "666057741")
            .put(ADDRESS_KEY, "1639 SW WITHDEAN RD")
            .put(CITY_KEY, "TOPEKA")
            .put(STATE_KEY, "KS")
            .put(ZIP_KEY, "666111634")
            .build();

    private static final ImmutableMap<String, String> HR_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "JOSEPH")
            .put(LAST_NAME_KEY, "BARRETO")
            .put(DATE_OF_BIRTH_KEY, "01/01/1966")
            .put(SSN_KEY, "666407613")
            .put(ADDRESS_KEY, "24 PAUL CT")
            .put(CITY_KEY, "TAPPAN")
            .put(STATE_KEY, "NY")
            .put(ZIP_KEY, "109832131")
            .build();
    private static final ImmutableMap<String, String> A_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "THOMAS")
            .put(LAST_NAME_KEY, "MAYER")
            .put(DATE_OF_BIRTH_KEY, "01/01/1959")
            .put(SSN_KEY, "666588816")
            .put(ADDRESS_KEY, "79 E ARCADIA AVE")
            .put(CITY_KEY, "COLUMBUS")
            .put(STATE_KEY, "OH")
            .put(ZIP_KEY, "432022623")
            .build();
    private static final ImmutableMap<String, String> B_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "SHAUNA")
            .put(LAST_NAME_KEY, "BORRON")
            .put(DATE_OF_BIRTH_KEY, "01/01/1951")
            .put(SSN_KEY, "666257958")
            .put(ADDRESS_KEY, "3601 W 25TH ST")
            .put(CITY_KEY, "PLAINVIEW")
            .put(STATE_KEY, "TX")
            .put(ZIP_KEY, "790721605")
            .build();
    private static final ImmutableMap<String, String> C_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "W")
            .put(LAST_NAME_KEY, "KNUDSON")
            .put(DATE_OF_BIRTH_KEY, "01/01/1960")
            .put(SSN_KEY, "666234417")
            .put(ADDRESS_KEY, "27805 NICK DAVIS RD")
            .put(CITY_KEY, "ATHENS")
            .put(STATE_KEY, "AL")
            .put(ZIP_KEY, "356136409")
            .build();
    private static final ImmutableMap<String, String> D_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "JEAN")
            .put(LAST_NAME_KEY, "BRIGGS")
            .put(DATE_OF_BIRTH_KEY, "01/01/1972")
            .put(SSN_KEY, "666475731")
            .put(ADDRESS_KEY, "315 E HOLMES ST")
            .put(CITY_KEY, "JANESVILLE")
            .put(STATE_KEY, "WI")
            .put(ZIP_KEY, "535454114")
            .build();
    private static final ImmutableMap<String, String> E_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "CATHY")
            .put(LAST_NAME_KEY, "BRITTLE")
            .put(DATE_OF_BIRTH_KEY, "01/01/1946")
            .put(SSN_KEY, "666673554")
            .put(ADDRESS_KEY, "717 HUNTINGTON ST")
            .put(CITY_KEY, "LAS VEGAS")
            .put(STATE_KEY, "NV")
            .put(ZIP_KEY, "891071758")
            .build();

    private static final ImmutableMap<String, String> F_USER = ImmutableMap.<String, String> builder()
            .put(FIRST_NAME_KEY, "TAHIR")
            .put(LAST_NAME_KEY, "BESS")
            .put(DATE_OF_BIRTH_KEY, "01/01/1932")
            .put(SSN_KEY, "666057741")
            .put(ADDRESS_KEY, "1639 SW Withdean Rd")
            .put(CITY_KEY, "TOPEKA")
            .put(STATE_KEY, "KS")
            .put(ZIP_KEY, "666111634")
            .build();

    private static final ImmutableMap<String, String> MILITARY_STATE_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "BRENDA")
            .put(LAST_NAME_KEY, "JUNE")
            .put(DATE_OF_BIRTH_KEY, "01/01/1943")
            .put(SSN_KEY, "666247352")
            .put(ADDRESS_KEY, "29 W STEPHEN GRVS")
            .put(CITY_KEY, "FPO")
            .put(STATE_KEY, "AA")
            .put(ZIP_KEY, "34091")
            .put(STATE_OF_RESIDENCE, "GA")
            .put(ADDRESS_TYPE_ID_KEY, "3")
            .build();

    private static final ImmutableMap<String, String> DOB_18_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "BRENDA")
            .put(LAST_NAME_KEY, "JUNE")
            .put(DATE_OF_BIRTH_KEY, "01/01/2015")
            .put(SSN_KEY, "666247352")
            .put(ADDRESS_KEY, "29 W STEPHEN GRVS")
            .put(CITY_KEY, "FPO")
            .put(STATE_KEY, "AA")
            .put(ZIP_KEY, "34091")
            .put(STATE_OF_RESIDENCE, "GA")
            .put(ADDRESS_TYPE_ID_KEY, "3")
            .build();

    private static final ImmutableMap<String, String> HIGH_INQUIRY_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "KARTEZ")
            .put(LAST_NAME_KEY, "DAVENPORT")
            .put(DATE_OF_BIRTH_KEY, "01/01/1948")
            .put(SSN_KEY, "666302683")
            .put(ADDRESS_KEY, "1108 LOCUST ST")
            .put(CITY_KEY, "PERRY")
            .put(STATE_KEY, "OK")
            .put(ZIP_KEY, "73077")
            .build();

    private static final ImmutableMap<String, String> BANKRUPTCY_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "VICTORIA")
            .put(LAST_NAME_KEY, "WARD")
            .put(DATE_OF_BIRTH_KEY, "01/01/1944")
            .put(SSN_KEY, "666642651")
            .put(ADDRESS_KEY, "4689 DONEGAL CLIFFS DR")
            .put(CITY_KEY, "DUBLIN")
            .put(STATE_KEY, "OH")
            .put(ZIP_KEY, "430179188")
            .build();

    private static final ImmutableMap<String, String> HIGH_PMI_SCORE_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "DONALD")
            .put(LAST_NAME_KEY, "MADERA")
            .put(DATE_OF_BIRTH_KEY, "01/01/1916")
            .put(SSN_KEY, "666523068")
            .put(ADDRESS_KEY, "4212 ALABAMA AVE")
            .put(CITY_KEY, "KENNER")
            .put(STATE_KEY, "LA")
            .put(ZIP_KEY, "700651305")
            .build();

    private static final ImmutableMap<String, String> TOO_FEW_TRADELINES_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "PETRA")
            .put(LAST_NAME_KEY, "BURDELL")
            .put(DATE_OF_BIRTH_KEY, "01/01/1943")
            .put(SSN_KEY, "666432915")
            .put(ADDRESS_KEY, "5108 BRANON ST")
            .put(CITY_KEY, "EL PASO")
            .put(STATE_KEY, "TX")
            .put(ZIP_KEY, "799245808")
            .build();

    private static final ImmutableMap<String, String> LOW_CREDITSCORE_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "FELIX")
            .put(LAST_NAME_KEY, "RICARD")
            .put(DATE_OF_BIRTH_KEY, "07/01/1947")
            .put(SSN_KEY, "666441713")
            .put(ADDRESS_KEY, "116 KENNERSON")
            .put(CITY_KEY, "OPELOUSAS")
            .put(STATE_KEY, "LA")
            .put(ZIP_KEY, "70570")
            .build();

    private static final ImmutableMap<String, String> MA_STATE_USER = ImmutableMap.<String, String>builder()
            .put(FIRST_NAME_KEY, "MATTHEW")
            .put(LAST_NAME_KEY, "DOUGHERTY")
            .put(DATE_OF_BIRTH_KEY, "07/01/1947")
            .put(SSN_KEY, "666728564")
            .put(ADDRESS_KEY, "14 ROCKY WOODS")
            .put(CITY_KEY, "HOPKINTON")
            .put(STATE_KEY, "MA")
            .put(ZIP_KEY, "01004")
            .build();

    private static final String NO_CREDIT_GRADE_EXPERIAN_USER = "No user information for credit grade %s.";
    private static final String NO_STATE_EXPERIAN_USER = "No user information for state %s.";

    private ExperianUserInformation() {
    }

    public static Map<String, String> getByProsperCreditGrade(final ProsperCreditGrade prosperCreditGrade)
            throws AutomationException {
        if (prosperCreditGrade == ProsperCreditGrade.AA) {
            return AA_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.A) {
            return A_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.B) {
            return B_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.C) {
            return C_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.D) {
            return D_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.E) {
            return E_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.HR) {
            return HR_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.F) {
            return F_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.NC) {
            return NC_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.HIGH_INQUIRY) {
            return HIGH_INQUIRY_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.BANKRUPTCY){
            return BANKRUPTCY_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.HIGH_PMI_SCORE){
            return HIGH_PMI_SCORE_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.TOO_FEW_TRADELINES){
            return TOO_FEW_TRADELINES_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.LOW_CREDITSCORE){
            return LOW_CREDITSCORE_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.DOB_18){
            return DOB_18_USER;
        } else if (prosperCreditGrade == ProsperCreditGrade.MA_STATE){
            return MA_STATE_USER;
        }
        else {
            throw new AutomationException(String.format(NO_CREDIT_GRADE_EXPERIAN_USER, prosperCreditGrade.toString()));
        }
    }

    public static Map<String, String> getByState(final StatesSupported state)
            throws AutomationException {
        if (state == StatesSupported.MILITARY_STATE) {
            return MILITARY_STATE_USER;
        } else {
            throw new AutomationException(String.format(NO_STATE_EXPERIAN_USER, state));
        }
    }

}
