
package com.prosper.automation.model.platform.bankValidation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public final class BankTransaction {

    @JsonProperty("Date")
    private String date;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Amount")
    private Double amount;
    @JsonProperty("Type")
    private String type;
}
