package com.prosper.automation.model.platform.merchant;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Sonali Phatak
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantResponse {

	@JsonProperty("MerchantRequest")
	private MerchantRequest merchantRequest;

	public MerchantRequest getMerchantRequest() {
		return merchantRequest;
	}
}
