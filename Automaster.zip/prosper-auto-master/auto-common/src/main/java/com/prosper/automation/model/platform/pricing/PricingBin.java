package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PricingBin {

    @JsonProperty("bin_id")
    private Integer binId;
    @JsonProperty("pricing_version")
    private Double pricingVersion;
    @JsonProperty("bin_value_cap")
    private String binValueCap;
    @JsonProperty("bin_value_input")
    private String binValueInput;
    @JsonProperty("default_value")
    private Boolean defaultValue;
    @JsonProperty("pricing_bin_type")
    private PricingBinType pricingBinType;

    public PricingBin() {
    }

    @JsonIgnore
    public PricingBinType gePricingBinType() {
        return pricingBinType;
    }

    @JsonIgnore
    public Integer getBinID() {
        return binId;
    }
}
