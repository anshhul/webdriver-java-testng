
package com.prosper.automation.model.platform.publishing;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 26/6/2016
 */
public class PublishWhole {

    @JsonProperty("batch_job_id")
    private Integer batchJobId;

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("batch_job_execution_id")
    private Integer batchJobExecutionId;


    public Integer getBatchJobExecutionId() {
        return batchJobExecutionId;
    }

    public void setBatchJobExecutionId(Integer batchJobExecutionId) {
        this.batchJobExecutionId = batchJobExecutionId;
    }

    public Integer getBatchJobId() {
        return batchJobId;
    }

    public void setBatchJobId(Integer batchJobId) {
        this.batchJobId = batchJobId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }
}
