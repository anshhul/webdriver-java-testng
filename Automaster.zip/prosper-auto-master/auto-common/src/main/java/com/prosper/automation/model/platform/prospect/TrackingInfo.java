
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"pre_populate", "engagement_date", "created_date", "send_date", "modified_date", "user_attribution_method"})
public final class TrackingInfo {
    
    // TO-DO: should we use Java DateTime library to hold these values?
    @JsonProperty("pre_populate")
    private String prePopulate;
    @JsonProperty("engagement_date")
    private String engagementDate;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("send_date")
    private String sendDate;
    @JsonProperty("modified_date")
    private String modifiedDate;
    @JsonProperty("user_attribution_method")
    private String userAttributionMethod;

    public String getUserAttributionMethod() {
        return userAttributionMethod;
    }

    public void setUserAttributionMethod(String userAttributionMethod) {
        this.userAttributionMethod = userAttributionMethod;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getEngagementDate() {
        return engagementDate;
    }

    public void setEngagementDate(String engagementDate) {
        this.engagementDate = engagementDate;
    }

    public String getPrePopulate() {
        return prePopulate;
    }

    public void setPrePopulate(String prePopulate) {
        this.prePopulate = prePopulate;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        TrackingInfo that = (TrackingInfo) o;
        return Objects.equal(prePopulate, that.prePopulate) &&
                Objects.equal(engagementDate, that.engagementDate) &&
                Objects.equal(createdDate, that.createdDate) &&
                Objects.equal(sendDate, that.sendDate) &&
                Objects.equal(modifiedDate, that.modifiedDate) &&
                Objects.equal(userAttributionMethod, that.userAttributionMethod);
    }

    @Override public int hashCode() {
        return Objects.hashCode(prePopulate, engagementDate, createdDate, sendDate, modifiedDate, userAttributionMethod);
    }

    @Override public String toString() {
        return "TrackingInfo{" +
                "prePopulate='" + prePopulate + '\'' +
                ", engagementDate='" + engagementDate + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", sendDate='" + sendDate + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                ", userAttributionMethod='" + userAttributionMethod + '\'' +
                '}';
    }
}
