
package com.prosper.automation.model;

import com.google.common.base.Objects;
import com.google.common.collect.ImmutableList;
import com.prosper.automation.constant.ListingHoldConstant;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.inquiry.ListingHold;
import com.prosper.automation.model.platform.inquiry.ListingHoldResponse;

import org.apache.commons.csv.CSVRecord;

import java.util.Iterator;
import java.util.Map;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ListingHoldData {
    
    private static boolean parseBoolean(final String booleanIntegerString) {
        if (Objects.equal(booleanIntegerString, "0") || Objects.equal(booleanIntegerString, "1")) {
            return Integer.parseInt(booleanIntegerString) == 1;
        } else {
            return false;
        }
    }
    
    
    public static final class Mapper {
        
        public static ListingHoldResponse map(final CSVRecord listingHold) throws AutomationException {
            ListingHoldResponse.Builder listingHoldResponseBuilder = new ListingHoldResponse.Builder();
            listingHoldResponseBuilder.withListingId(Long.parseLong(listingHold.get("ListingID")));
            
            ImmutableList.Builder<ListingHold> listBuilder = new ImmutableList.Builder();
            ListingHold.Builder listingHoldBuilder = new ListingHold.Builder();
            
            Iterator<Map.Entry<Integer, String>> iterator = ListingHoldConstant.LISTING_HOLDS_INFO.entrySet().iterator();
            
            while (iterator.hasNext()) {
                final Map.Entry<Integer, String> hold = iterator.next();
                if (parseBoolean(listingHold.get(String.valueOf(hold.getKey())))) {
                    listBuilder.add(listingHoldBuilder.withWorkflowTypeId(hold.getKey()).build());
                }
            }
            
            listingHoldResponseBuilder.withHolds(listBuilder.build());
            return listingHoldResponseBuilder.build();
        }
    }
}
