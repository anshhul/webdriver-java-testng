package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.PhoneNumber;

import java.util.Comparator;
import java.util.List;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectContactInfoComparator implements Comparator<ContactInfo> {
    private boolean selectiveComparePhone(List<PhoneNumber> phoneNumbers, List<PhoneNumber> phoneNumbersFromQuery) {
        for(int index=0; index < phoneNumbers.size(); index++) {
            if(phoneNumbers.get(index).getAreaCode()!= null && !phoneNumbers.get(index).getAreaCode().equalsIgnoreCase(phoneNumbersFromQuery.get(index).getAreaCode()))
                return false;
            if(phoneNumbers.get(index).getPhoneNumber()!= null && !phoneNumbers.get(index).getPhoneNumber().equalsIgnoreCase(phoneNumbersFromQuery.get(index).getPhoneNumber()))
                return false;
        }
        return true;
    }

    @Override public int compare(ContactInfo left, ContactInfo right) {
        // Contact Info
        if (left!= null && !left.getEmail().equalsIgnoreCase(right.getEmail()))
            return 1;
        if (left!= null && !selectiveComparePhone(left.getPhoneNumbers(), right.getPhoneNumbers()))
            return 1;
        return 0;
    }
}
