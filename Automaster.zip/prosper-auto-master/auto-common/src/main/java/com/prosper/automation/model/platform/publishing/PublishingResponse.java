
package com.prosper.automation.model.platform.publishing;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 23 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PublishingResponse {

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("hostname")
    private String hostName;

    @JsonProperty("completed_without_errors")
    private Boolean completedWithoutErrors;

    @JsonProperty("job_failure_message")
    private String jobFailureMessage;

    @JsonProperty("supplement_id")
    private String supplementId;

    @JsonProperty("job_start_time")
    private String jobStartTime;

    @JsonProperty("job_end_time")
    private String jobEndTime;

    @JsonProperty("job_run_time")
    private String jobRunTime;

    @JsonProperty("transaction_id")
    private String transactionId;

    @JsonProperty("listing_ids_published")
    private List<Integer> listingIdsPublished;

    @JsonProperty("listings_to_publish_count")
    private String listingsToPublishCount;

    @JsonProperty("published_listings_count")
    private String publishedListingsCount;

    @JsonProperty("publish_failure_listings_count")
    private String publishFailureListingsCount;

    @JsonProperty("listing_publish_failures")
    private List<PublishingListingFail> listingPublishFailures;


    public String getJobName() {
        return jobName;
    }

    public String getHostName() {
        return hostName;
    }

    public String getSupplementId() {
        return supplementId;
    }

    public Boolean getCompletedWithoutErrors() {
        return completedWithoutErrors;
    }

    public String getJobFailureMessage() {
        return jobFailureMessage;
    }

    public String getJobStartTime() {
        return jobStartTime;
    }

    public String getJobEndTime() {
        return jobEndTime;
    }

    public String getJobRunTime() {
        return jobRunTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public List<Integer> getListingIdsPublished() {
        return listingIdsPublished;
    }

    public String getListingsToPublishCount() {
        return listingsToPublishCount;
    }

    public String getPublishedListingsCount() {
        return publishedListingsCount;
    }

    public String getPublishFailureListingsCount() {
        return publishFailureListingsCount;
    }

    public List<PublishingListingFail> getListingPublishFailures() {
        return listingPublishFailures;
    }

}
