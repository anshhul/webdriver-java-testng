
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ViewTotalAllocationsForTheMonth {

    @JsonProperty("amt")
    private double amt;

    @JsonProperty("buyeruserid")
    private Long buyeruserid;

    @JsonProperty("MonthlyInvestmentTarget")
    private Double monthlyInvestmentTarget;


    public static class ViewTotalAllocationsForTheMonthBuilder {

        private double amt;
        private Long buyeruserid;
        private Double monthlyInvestmentTarget;


        public ViewTotalAllocationsForTheMonthBuilder amt(final double value) {
            this.amt = value;
            return this;
        }

        public ViewTotalAllocationsForTheMonth build() {
            final ViewTotalAllocationsForTheMonth result = new ViewTotalAllocationsForTheMonth();

            result.setAmt(amt);
            result.setBuyeruserid(buyeruserid);
            result.setMonthlyInvestmentTarget(monthlyInvestmentTarget);
            return result;
        }

        public ViewTotalAllocationsForTheMonthBuilder buyeruserid(final Long value) {
            this.buyeruserid = value;
            return this;
        }

        public ViewTotalAllocationsForTheMonthBuilder monthlyInvestmentTarget(final Double value) {
            this.monthlyInvestmentTarget = value;
            return this;
        }
    }
    
    
    public static ViewTotalAllocationsForTheMonthBuilder buildUpon(final ViewTotalAllocationsForTheMonth original) {
        final ViewTotalAllocationsForTheMonthBuilder builder = newBuilder();
        builder.amt(original.getAmt());
        builder.buyeruserid(original.getBuyeruserid());
        builder.monthlyInvestmentTarget(original.getMonthlyInvestmentTarget());
        return builder;
    }

    public static ViewTotalAllocationsForTheMonthBuilder newBuilder() {
        return new ViewTotalAllocationsForTheMonthBuilder();
    }

    public double getAmt() {
        return amt;
    }

    public Long getBuyeruserid() {
        return buyeruserid;
    }

    public Double getMonthlyInvestmentTarget() {
        return monthlyInvestmentTarget;
    }
    
    public void setAmt(final double amt) {
        this.amt = amt;
    }
    
    public void setBuyeruserid(final Long buyeruserid) {
        this.buyeruserid = buyeruserid;
    }
    
    public void setMonthlyInvestmentTarget(final Double monthlyInvestmentTarget) {
        this.monthlyInvestmentTarget = monthlyInvestmentTarget;
    }

}
