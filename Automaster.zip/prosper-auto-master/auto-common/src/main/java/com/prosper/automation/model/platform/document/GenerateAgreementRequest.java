
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"agreement_type_id", "map_template_arguments"})
public final class GenerateAgreementRequest {
    
    @JsonProperty("agreement_type_id")
    private Integer agreementTypeId;
    @JsonProperty("map_template_arguments")
    private MapTemplateArguments mapTemplateArguments;
    
    
    public GenerateAgreementRequest() {
    }
    
    private GenerateAgreementRequest(final Builder builder) {
        agreementTypeId = builder.agreementTypeId;
        mapTemplateArguments = builder.mapTemplateArguments;
    }
    
    
    public static final class Builder {
        
        private Integer agreementTypeId;
        private MapTemplateArguments mapTemplateArguments;
        
        
        public Builder() {
        }
        
        public Builder withAgreementTypeId(final Integer agreementTypeId) {
            this.agreementTypeId = agreementTypeId;
            return this;
        }
        
        public Builder withMapTemplateArguments(final MapTemplateArguments mapTemplateArguments) {
            this.mapTemplateArguments = mapTemplateArguments;
            return this;
        }
        
        public GenerateAgreementRequest build() {
            return new GenerateAgreementRequest(this);
        }
    }
}
