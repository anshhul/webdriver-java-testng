
package com.prosper.automation.model.platform.notes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * @author Avneet Dhanoa
 * @since 0.0.1
 * @updateBy: Prateek on 8.12.15
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Notes {

    @JsonProperty("loan_number")
    private Integer loanNumber;
    
    @JsonProperty("total_amount_borrowed")
    private Double totalAmountBorrowed;
    
    @JsonProperty("borrower_rate")
    private Double borrowerRate;
    
    @JsonProperty("prosper_rating")
    private String prosperRating;
    
    @JsonProperty("term")
    private Integer term;
    
    @JsonProperty("age_in_months")
    private Integer ageInMonths;
    
    @JsonProperty("origination_date")
    private Date originationDate;
    
    @JsonProperty("days_past_due")
    private Integer daysPastDue;
    
    @JsonProperty("principal_balance")
    private Double principalBalance;
    
    @JsonProperty("service_fees")
    private Double serviceFees;
    
    @JsonProperty("principal_repaid")
    private Double principalRepaid;
    
    @JsonProperty("interest_paid")
    private Double interestPaid;
    
    @JsonProperty("prosper_fees")
    private Double prosperFees;
    
    @JsonProperty("late_fees")
    private Double lateFees;
    
    @JsonProperty("debt_sale_proceeds_received")
    private Double debtSaleProceedsReceived;
    
    @JsonProperty("next_payment_due_date")
    private Date nextPaymentDueDate;
    
    @JsonProperty("next_payment_due_amount")
    private Double nextPaymentDueAmount;
    
    @JsonProperty("loan_note_id")
    private String loanNoteId;
    
    @JsonProperty("listing_number")
    private Integer listingNumber;
    
    @JsonProperty("amount_participation")
    private Double amountParticipation;
    
    @JsonProperty("platform_proceeds_gross_received")
    private Double platformProceedsGrossReceived;
    
    @JsonProperty("platform_fees_paid")
    private Double platformFeesPaid;
    
    @JsonProperty("note_status")
    private Integer noteStatus;
    
    @JsonProperty("note_status_description")
    private String noteStatusDescription;
    
    @JsonProperty("is_sold")
    private Boolean isSold;


    public Integer getAgeInMonths() {
        return ageInMonths;
    }

    public Double getAmountParticipation() {
        return amountParticipation;
    }

    public Double getBorrowerRate() {
        return borrowerRate;
    }

    public Integer getDaysPastDue() {
        return daysPastDue;
    }

    public Double getDebtSaleProceedsReceived() {
        return debtSaleProceedsReceived;
    }

    public Double getInterestPaid() {
        return interestPaid;
    }

    public Boolean getIsSold() {
        return isSold;
    }

    public Double getLateFees() {
        return lateFees;
    }

    public Integer getListingNumber() {
        return listingNumber;
    }

    public String getLoanNoteId() {
        return loanNoteId;
    }

    public Integer getLoanNumber() {
        return loanNumber;
    }

    public Double getNextPaymentDueAmount() {
        return nextPaymentDueAmount;
    }

    public Date getNextPaymentDueDate() {
        return nextPaymentDueDate;
    }

    public Integer getNoteStatus() {
        return noteStatus;
    }

    public String getNoteStatusDescription() {
        return noteStatusDescription;
    }

    public Date getOriginationDate() {
        return originationDate;
    }

    public Double getPlatformFeesPaid() {
        return platformFeesPaid;
    }

    public Double getPlatformProceedsGrossReceived() {
        return platformProceedsGrossReceived;
    }

    public Double getPrincipalBalance() {
        return principalBalance;
    }

    public Double getPrincipalRepaid() {
        return principalRepaid;
    }

    public Double getProsperFees() {
        return prosperFees;
    }

    public String getProsperRating() {
        return prosperRating;
    }

    public Double getServiceFees() {
        return serviceFees;
    }

    public Integer getTerm() {
        return term;
    }

    public Double getTotalAmountBorrowed() {
        return totalAmountBorrowed;
    }

    public void setAgeInMonths(final Integer ageInMonths) {
        this.ageInMonths = ageInMonths;
    }

    public void setAmountParticipation(final Double amountParticipation) {
        this.amountParticipation = amountParticipation;
    }

    public void setBorrowerRate(final Double borrowerRate) {
        this.borrowerRate = borrowerRate;
    }

    public void setDaysPastDue(final Integer daysPastDue) {
        this.daysPastDue = daysPastDue;
    }

    public void setDebtSaleProceedsReceived(final Double debtSaleProceedsReceived) {
        this.debtSaleProceedsReceived = debtSaleProceedsReceived;
    }

    public void setInterestPaid(final Double interestPaid) {
        this.interestPaid = interestPaid;
    }

    public void setIsSold(final Boolean isSold) {
        this.isSold = isSold;
    }

    public void setLateFees(final Double lateFees) {
        this.lateFees = lateFees;
    }

    public void setListingNumber(final Integer listingNumber) {
        this.listingNumber = listingNumber;
    }

    public void setLoanNoteId(final String loanNoteId) {
        this.loanNoteId = loanNoteId;
    }

    public void setLoanNumber(final Integer loanNumber) {
        this.loanNumber = loanNumber;
    }

    public void setNextPaymentDueAmount(final Double nextPaymentDueAmount) {
        this.nextPaymentDueAmount = nextPaymentDueAmount;
    }

    public void setNextPaymentDueDate(final Date nextPaymentDueDate) {
        this.nextPaymentDueDate = nextPaymentDueDate;
    }

    public void setNoteStatus(final Integer noteStatus) {
        this.noteStatus = noteStatus;
    }

    public void setNoteStatusDescription(final String noteStatusDescription) {
        this.noteStatusDescription = noteStatusDescription;
    }

    public void setOriginationDate(final Date originationDate) {
        this.originationDate = originationDate;
    }

    public void setPlatformFeesPaid(final Double platformFeesPaid) {
        this.platformFeesPaid = platformFeesPaid;
    }

    public void setPlatformProceedsGrossReceived(final Double platformProceedsGrossReceived) {
        this.platformProceedsGrossReceived = platformProceedsGrossReceived;
    }

    public void setPrincipalBalance(final Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    public void setPrincipalRepaid(final Double principalRepaid) {
        this.principalRepaid = principalRepaid;
    }

    public void setProsperFees(final Double prosperFees) {
        this.prosperFees = prosperFees;
    }

    public void setProsperRating(final String prosperRating) {
        this.prosperRating = prosperRating;
    }

    public void setServiceFees(final Double serviceFees) {
        this.serviceFees = serviceFees;
    }

    public void setTerm(final Integer term) {
        this.term = term;
    }

    public void setTotalAmountBorrowed(final Double totalAmountBorrowed) {
        this.totalAmountBorrowed = totalAmountBorrowed;
    }
    
}
