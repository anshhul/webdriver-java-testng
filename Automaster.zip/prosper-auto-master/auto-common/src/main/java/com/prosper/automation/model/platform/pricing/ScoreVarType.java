package com.prosper.automation.model.platform.pricing;

/**
 * Created by ppatil on 12/7/16.
 */
public class ScoreVarType {

    public Integer getVariableId() {
        return variableId;
    }

    public void setVariableId(Integer variableId) {
        this.variableId = variableId;
    }

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Integer getDataTypeId() {
        return dataTypeId;
    }

    public void setDataTypeId(Integer dataTypeId) {
        this.dataTypeId = dataTypeId;
    }

    public Integer getReasonCodeId() {
        return reasonCodeId;
    }

    public void setReasonCodeId(Integer reasonCodeId) {
        this.reasonCodeId = reasonCodeId;
    }

    private Integer variableId;
    private String variableName;
    private Boolean isActive;
    private Integer dataTypeId;
    private Integer reasonCodeId;
}
