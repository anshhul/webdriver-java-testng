
package com.prosper.automation.model.platform.publishing;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 24 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SECResults {

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("hostname")
    private String hostName;

    @JsonProperty("completed_without_errors")
    private Boolean completedWithoutErrors;

    @JsonProperty("job_failure_message")
    private String jobFailureMessage;

    @JsonProperty("job_start_time")
    private String jobStartTime;

    @JsonProperty("job_end_time")
    private String jobEndTime;

    @JsonProperty("job_run_time")
    private String jobRunTime;

    @JsonProperty("supplement_id")
    private Integer supplementId;

    @JsonProperty("supplement_number")
    private Integer supplementNumber;

    @JsonProperty("prospectus_id")
    private Integer prospectusId;

    @JsonProperty("transaction_id")
    private Integer transactionId;

    @JsonProperty("batch_job_id")
    private Integer batchJobId;

    @JsonProperty("supplement_status")
    private String supplementStatus;

    @JsonProperty("sec_file_created")
    private Boolean secFileCreated;

    @JsonProperty("sec_file_move_success")
    private Boolean secFileMoveSuccess;

    @JsonProperty("sec_file_path")
    private String secFilePath;

    @JsonProperty("sec_hold_removal_failures_count")
    private Integer secHoldRemovalFailuresCount;

    @JsonProperty("listings_in_report_count")
    private Integer listingsInReportCount;

    @JsonProperty("listing_failures_count")
    private Integer listingFailuresCount;

    @JsonProperty("sec_report_listing_ids")
    private List<Integer> secReportListingIds;

    @JsonProperty("fileMoveSuccess")
    private Boolean fileMoveSuccess;


    public String getJobName() {
        return jobName;
    }

    public String getHostName() {
        return hostName;
    }

    public Boolean getCompletedWithoutErrors() {
        return completedWithoutErrors;
    }

    public String getJobStartTime() {
        return jobStartTime;
    }

    public Integer getSupplementNumber() {
        return supplementNumber;
    }

    public String getJobEndTime() {
        return jobEndTime;
    }

    public String getJobRunTime() {
        return jobRunTime;
    }

    public Integer getSupplementId() {
        return supplementId;
    }

    public Integer getProspectusId() {
        return prospectusId;
    }

    public Integer getTransactionId() {
        return transactionId;
    }

    public Integer getBatchJobId() {
        return batchJobId;
    }

    public String getSupplementStatus() {
        return supplementStatus;
    }

    public Boolean getSecFileCreated() {
        return secFileCreated;
    }

    public Boolean getSecFileMoveSuccess() {
        return secFileMoveSuccess;
    }

    public String getSecFilePath() {
        return secFilePath;
    }

    public Integer getSecHoldRemovalFailuresCount() {
        return secHoldRemovalFailuresCount;
    }

    public Integer getListingsInReportCount() {
        return listingsInReportCount;
    }

    public Integer getListingFailuresCount() {
        return listingFailuresCount;
    }

    public List<Integer> getSecReportListingIds() {
        return secReportListingIds;
    }

    public Boolean getFileMoveSuccess() {
        return fileMoveSuccess;
    }
}
