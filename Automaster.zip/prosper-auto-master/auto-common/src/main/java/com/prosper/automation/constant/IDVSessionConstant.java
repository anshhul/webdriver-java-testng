
package com.prosper.automation.constant;

/**
 * Created by pbudiono on 7/19/16.
 */
public final class IDVSessionConstant {

    public static final String SESSION_INFO_ID = "62622075";
}
