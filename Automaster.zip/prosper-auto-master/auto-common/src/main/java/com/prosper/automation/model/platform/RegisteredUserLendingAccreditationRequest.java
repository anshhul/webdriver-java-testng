package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * Created by aamalraj on 12/21/15.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({"credit_profile_auth", "terms_of_use", "privacy_policies_agreement", "data_terms_of_use"})

public final class RegisteredUserLendingAccreditationRequest {

    @JsonProperty("credit_profile_auth") private Boolean creditProfileAuth;
    @JsonProperty("terms_of_use") private Boolean termsOfUse;
    @JsonProperty("privacy_policies_agreement") private Boolean privacyPoliciesAgreement;
    @JsonProperty("data_terms_of_use") private Boolean dataTermsOfUse;

    public RegisteredUserLendingAccreditationRequest() {
    }

    private RegisteredUserLendingAccreditationRequest(final Builder builder) {
        creditProfileAuth = builder.creditProfileAuth;
        termsOfUse = builder.termsOfUse;
        privacyPoliciesAgreement = builder.privacyPoliciesAgreement;
        dataTermsOfUse = builder.dataTermsOfUse;
    }

    public Boolean getPrivacyPoliciesAgreement() {
        return privacyPoliciesAgreement;
    }

    public void setPrivacyPoliciesAgreement(final Boolean privacyPoliciesAgreement) {
        this.privacyPoliciesAgreement = privacyPoliciesAgreement;
    }

    public Boolean getTermsOfUse() {
        return termsOfUse;
    }

    public void setTermsOfUse(final Boolean termsOfUse) {
        this.termsOfUse = termsOfUse;
    }

    public Boolean getCreditProfileAuth() {
        return creditProfileAuth;
    }

    public Boolean getDataTermsOfUse() {
        return dataTermsOfUse;
    }

    public void setDataTermsOfUse(final Boolean dataTermsOfUse) {
        this.dataTermsOfUse = dataTermsOfUse;
    }

    @Override public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegisteredUserLendingAccreditationRequest that = (RegisteredUserLendingAccreditationRequest) o;
        return Objects.equal(creditProfileAuth, that.creditProfileAuth) && Objects.equal(termsOfUse, that.termsOfUse) && Objects
                .equal(privacyPoliciesAgreement, that.privacyPoliciesAgreement) && Objects
                .equal(dataTermsOfUse, that.dataTermsOfUse);
    }

    @Override public int hashCode() {
        return Objects.hashCode(creditProfileAuth, termsOfUse, privacyPoliciesAgreement, dataTermsOfUse);
    }

    public static final class Builder {

        private Boolean creditProfileAuth;
        private Boolean termsOfUse;
        private Boolean privacyPoliciesAgreement;
        private Boolean dataTermsOfUse;

        public Builder() {
        }

        public Builder withCreditProfileAuth(final Boolean creditProfileAuth) {
            this.creditProfileAuth = creditProfileAuth;
            return this;
        }

        public Builder withTermsOfUse(final Boolean termsOfUse) {
            this.termsOfUse = termsOfUse;
            return this;
        }

        public Builder withPrivacyPoliciesAgreement(final Boolean privacyPoliciesAgreement) {
            this.privacyPoliciesAgreement = privacyPoliciesAgreement;
            return this;
        }

        public Builder withDataTermsOfUse(final Boolean dataTermsOfUse) {
            this.dataTermsOfUse = dataTermsOfUse;
            return this;
        }

        public RegisteredUserLendingAccreditationRequest build() {
            return new RegisteredUserLendingAccreditationRequest(this);
        }
    }
}
