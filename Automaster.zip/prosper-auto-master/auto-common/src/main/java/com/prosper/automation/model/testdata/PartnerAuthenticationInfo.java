package com.prosper.automation.model.testdata;

/**
 * @author pbudiono
 */
public final class PartnerAuthenticationInfo {

    private String partnerName;
    private String legacyId;
    private String oauthClientId;
    private String oauthClientSecret;

    private PartnerAuthenticationInfo(Builder builder) {
        partnerName = builder.partnerName;
        legacyId = builder.legacyId;
        oauthClientId = builder.oauthClientId;
        oauthClientSecret = builder.oauthClientSecret;
    }

    @Override public String toString() {
        return partnerName;
    }

    public String getOAuthClientId() {
        return oauthClientId;
    }

    public String getOAuthClientSecret() {
        return oauthClientSecret;
    }

    public String getLegacyId() {
        return legacyId;
    }

    public static final class Builder {

        private String partnerName;
        private String legacyId;
        private String oauthClientId;
        private String oauthClientSecret;

        public Builder() {
        }

        public Builder withPartnerName(String val) {
            partnerName = val;
            return this;
        }

        public Builder withLegacyId(String val) {
            legacyId = val;
            return this;
        }

        public Builder withOauthClientId(String val) {
            oauthClientId = val;
            return this;
        }

        public Builder withOauthClientSecret(String val) {
            oauthClientSecret = val;
            return this;
        }

        public PartnerAuthenticationInfo build() {
            return new PartnerAuthenticationInfo(this);
        }
    }
}
