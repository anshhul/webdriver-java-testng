
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.EmploymentInfo;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class EmploymentInfoConstant {

    public static final String EMPLOYER_NAME = "ABCD Corporation";
    public static final int EMPLOYMENT_YEAR = 2010;
    public static final int EMPLOYMENT_MONTH = 4;
    public static final String OCCUPATION_ID = "1";
    public static final String EMPLOYMENT_STATUS_ID = "1";

    private static final Double ONE_HUNDRED_THOUSANDS = 100000.;


    private EmploymentInfoConstant() {
    }

    public static EmploymentInfo buildEmployementInfoWithDefaultMonthlyIncome() {
        return new EmploymentInfo.Builder().withAnnualIncome(ONE_HUNDRED_THOUSANDS).withIsIncomeVerifiable(true).build();
    }
}
