
package com.prosper.automation.model.platform.loan;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class AllLoansResponse {

    @JsonProperty("result")
    private List<PlatformLoanVO> result;
    
    @JsonProperty("result_count")
    private Integer resultCount;

    @JsonProperty("total_count")
    private Integer totalCount;
    
    
    public List<PlatformLoanVO> getResult() {
        return result;
    }
    
    public Integer getResultCount() {
        return resultCount;
    }
    
    public Integer getTotalCount() {
        return totalCount;
    }
    
    public void setResult(final List<PlatformLoanVO> result) {
        this.result = result;
    }
    
    public void setResultCount(final Integer resultCount) {
        this.resultCount = resultCount;
    }
    
    public void setTotalCount(final Integer totalCount) {
        this.totalCount = totalCount;
    }
    
}
