package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 4/15/16.
 */
public class Partner {
    @JsonProperty("campaign_source_id")
    String campaignSourceId;

    public String getCampaignSourceId() {
        return campaignSourceId;
    }

    public void setCampaignSourceId(String campaignSourceId) {
        this.campaignSourceId = campaignSourceId;
    }
}
