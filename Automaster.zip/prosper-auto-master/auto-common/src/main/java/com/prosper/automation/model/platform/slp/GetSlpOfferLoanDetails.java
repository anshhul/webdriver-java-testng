
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class GetSlpOfferLoanDetails {

    @JsonProperty("offer_id")
    private String offerID;
    
    @JsonProperty("offer_date")
    private String offerDate;
    
    @JsonProperty("offer_expiration_date")
    private String offerExpirationDate;
    
    @JsonProperty("total_principal_balance")
    private String totalPrincipalBalance;
    
    @JsonProperty("total_dirty_price")
    private double totalDirtyPrice;
    
    @JsonProperty("total_fees")
    private double totalFees;
    
    @JsonProperty("total_wire_amount")
    private double totalWireAmount;
    
    @JsonProperty("purchase_date")
    private String purchaseDate;
    
    @JsonProperty("purchase_id")
    private String purchaseId;
    
    @JsonProperty("offer_status")
    private String offerStatus;
    
    @JsonProperty("offer_rating_summary")
    private List<SlpOfferRatingSummary> offerRatingSummary;


    /**
     * @return the offerDate
     */
    public String getOfferDate() {
        return offerDate;
    }
    
    /**
     * @return the offerExpirationDate
     */
    public String getOfferExpirationDate() {
        return offerExpirationDate;
    }
    
    /**
     * @return the offerID
     */
    public String getOfferID() {
        return offerID;
    }
    
    public List<SlpOfferRatingSummary> getOfferRatingSummary() {
        return offerRatingSummary;
    }
    
    /**
     * @return the offerStatus
     */
    public String getOfferStatus() {
        return offerStatus;
    }
    
    /**
     * @return the purchaseDate
     */
    public String getPurchaseDate() {
        return purchaseDate;
    }
    
    /**
     * @return the purchaseId
     */
    public String getPurchaseId() {
        return purchaseId;
    }
    
    /**
     * @return the totalDirtyPrice
     */
    public double getTotalDirtyPrice() {
        return totalDirtyPrice;
    }
    
    /**
     * @return the totalFees
     */
    public double getTotalFees() {
        return totalFees;
    }
    
    /**
     * @return the totalPrincipalBalance
     */
    public String getTotalPrincipalBalance() {
        return totalPrincipalBalance;
    }
    
    /**
     * @return the totalWireAmount
     */
    public double getTotalWireAmount() {
        return totalWireAmount;
    }
    
    /**
     * @param offerDate the offerDate to set
     */
    public void setOfferDate(final String offerDate) {
        this.offerDate = offerDate;
    }
    
    /**
     * @param offerExpirationDate the offerExpirationDate to set
     */
    public void setOfferExpirationDate(final String offerExpirationDate) {
        this.offerExpirationDate = offerExpirationDate;
    }
    
    /**
     * @param offerID the offerID to set
     */
    public void setOfferID(final String offerID) {
        this.offerID = offerID;
    }
    
    public void setOfferRatingSummary(final List<SlpOfferRatingSummary> offerRatingSummary) {
        this.offerRatingSummary = offerRatingSummary;
    }
    
    /**
     * @param offerStatus the offerStatus to set
     */
    public void setOfferStatus(final String offerStatus) {
        this.offerStatus = offerStatus;
    }

    /**
     * @param purchaseDate the purchaseDate to set
     */
    public void setPurchaseDate(final String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    /**
     * @param purchaseId the purchaseId to set
     */
    public void setPurchaseId(final String purchaseId) {
        this.purchaseId = purchaseId;
    }
    
    /**
     * @param totalDirtyPrice the totalDirtyPrice to set
     */
    public void setTotalDirtyPrice(final double totalDirtyPrice) {
        this.totalDirtyPrice = totalDirtyPrice;
    }

    /**
     * @param totalFees the totalFees to set
     */
    public void setTotalFees(final double totalFees) {
        this.totalFees = totalFees;
    }

    /**
     * @param totalPrincipalBalance the totalPrincipalBalance to set
     */
    public void setTotalPrincipalBalance(final String totalPrincipalBalance) {
        this.totalPrincipalBalance = totalPrincipalBalance;
    }

    /**
     * @param totalWireAmount the totalWireAmount to set
     */
    public void setTotalWireAmount(final double totalWireAmount) {
        this.totalWireAmount = totalWireAmount;
    }

}
