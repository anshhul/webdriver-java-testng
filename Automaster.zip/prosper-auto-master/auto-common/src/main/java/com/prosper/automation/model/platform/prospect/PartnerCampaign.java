
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 8/3/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PartnerCampaign {

	@JsonProperty("campaign_id")
	private String campaignId;
	@JsonProperty("campaign_source_id")
	private String campaignSourceId;
	@JsonProperty("campaign_channel_id")
	private String campaignChannelId;
	@JsonProperty("campaign_channel_name")
	private String campaignChannelName;
	@JsonProperty("ref_ac")
	private String refAc;
	@JsonProperty("campaign_program_id")
	private String campaignProgramId;
	@JsonProperty("ref_mc")
	private String refMc;
	@JsonProperty("refac_refmc_name")
	private String refAcRefMcName;
	@JsonProperty("is_abp_eligible")
	private Boolean isABPEligible;
	@JsonProperty("start_date")
	private String startDate;
	@JsonProperty("end_date")
	private String endDate;
	@JsonProperty("duration")
	private Integer duration;

	public PartnerCampaign() {
	}

	private PartnerCampaign(Builder builder) {
		campaignId = builder.campaignId;
		campaignSourceId = builder.campaignSourceId;
		campaignChannelId = builder.campaignChannelId;
		campaignChannelName = builder.campaignChannelName;
		refAc = builder.refAc;
		campaignProgramId = builder.campaignProgramId;
		refMc = builder.refMc;
		refAcRefMcName = builder.refAcRefMcName;
		isABPEligible = builder.isABPEligible;
		startDate = builder.startDate;
		endDate = builder.endDate;
		duration = builder.duration;
	}

	@JsonIgnore
	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	@JsonIgnore
	public String getCampaignSourceId() {
		return campaignSourceId;
	}

	public void setCampaignSourceId(String campaignSourceId) {
		this.campaignSourceId = campaignSourceId;
	}

	@JsonIgnore
	public String getCampaignChannelId() {
		return campaignChannelId;
	}

	public void setCampaignChannelId(String campaignChannelId) {
		this.campaignChannelId = campaignChannelId;
	}

	@JsonIgnore
	public String getCampaignChannelName() {
		return campaignChannelName;
	}

	public void setCampaignChannelName(String campaignChannelName) {
		this.campaignChannelName = campaignChannelName;
	}

	@JsonIgnore
	public String getRefAc() {
		return refAc;
	}

	public void setRefAc(String refAc) {
		this.refAc = refAc;
	}

	@JsonIgnore
	public String getCampaignProgramId() {
		return campaignProgramId;
	}

	public void setCampaignProgramId(String campaignProgramId) {
		this.campaignProgramId = campaignProgramId;
	}

	@JsonIgnore
	public String getRefMc() {
		return refMc;
	}

	public void setRefMc(String refMc) {
		this.refMc = refMc;
	}

	@JsonIgnore
	public String getRefAcRefMcName() {
		return refAcRefMcName;
	}

	public void setRefAcRefMcName(String refAcRefMcName) {
		this.refAcRefMcName = refAcRefMcName;
	}

	@JsonIgnore
	public Boolean getABPEligible() {
		return isABPEligible;
	}

	public void setABPEligible(Boolean ABPEligible) {
		isABPEligible = ABPEligible;
	}

	@JsonIgnore
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	@JsonIgnore
	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@JsonIgnore
	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public static final class Builder {

		private String campaignId;
		private String campaignSourceId;
		private String campaignChannelId;
		private String campaignChannelName;
		private String refAc;
		private String campaignProgramId;
		private String refMc;
		private String refAcRefMcName;
		private Boolean isABPEligible;
		private String startDate;
		private String endDate;
		private Integer duration;

		public Builder() {
		}

		public Builder withCampaignId(String val) {
			campaignId = val;
			return this;
		}

		public Builder withCampaignSourceId(String val) {
			campaignSourceId = val;
			return this;
		}

		public Builder withCampaignChannelId(String val) {
			campaignChannelId = val;
			return this;
		}

		public Builder withCampaignChannelName(String val) {
			campaignChannelName = val;
			return this;
		}

		public Builder withRefAc(String val) {
			refAc = val;
			return this;
		}

		public Builder withCampaignProgramId(String val) {
			campaignProgramId = val;
			return this;
		}

		public Builder withRefMc(String val) {
			refMc = val;
			return this;
		}

		public Builder withRefAcRefMcName(String val) {
			refAcRefMcName = val;
			return this;
		}

		public Builder withIsABPEligible(Boolean val) {
			isABPEligible = val;
			return this;
		}

		public Builder withStartDate(String val) {
			startDate = val;
			return this;
		}

		public Builder withEndDate(String val) {
			endDate = val;
			return this;
		}

		public Builder withDuration(Integer val) {
			duration = val;
			return this;
		}

		public PartnerCampaign build() {
			return new PartnerCampaign(this);
		}
	}
}
