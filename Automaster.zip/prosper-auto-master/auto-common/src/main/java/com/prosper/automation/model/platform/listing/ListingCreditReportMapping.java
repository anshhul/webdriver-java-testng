package com.prosper.automation.model.platform.listing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by rchintapalli on 11/30/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListingCreditReportMapping {

    protected List<Error> error;
    @JsonProperty("entities")
    private  List<ListingCRMappingDTO> listingMappingResponse;
    @JsonProperty("entity_count")
    private Integer entityCount;
    @JsonProperty("entity_total_count")
    private Integer entityTotalCount;

    public List<ListingCRMappingDTO> getListingMappingResponse() {
        return listingMappingResponse;
    }
}
