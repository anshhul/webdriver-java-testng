package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by aamalraj on 1/7/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder({"user_id", "email",
        "old_email"}) public final class ChangeEmailUserInfo {

    @JsonProperty("user_id") private Long userId;
    @JsonProperty("email") private String currentEmailAddress;
    @JsonProperty("old_email") private String oldEmailAddress;

    @JsonIgnore public Long getUserId() {
        return userId;
    }

    @JsonIgnore public String getCurrentEmail() {
        return currentEmailAddress;
    }

    @JsonIgnore public String getOldEmail() {
        return oldEmailAddress;
    }

}
