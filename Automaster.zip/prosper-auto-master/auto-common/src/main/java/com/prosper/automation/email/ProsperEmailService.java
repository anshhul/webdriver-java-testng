
package com.prosper.automation.email;

import com.prosper.automation.exception.AutomationException;

import org.apache.log4j.Logger;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.search.AndTerm;
import javax.mail.search.RecipientTerm;
import javax.mail.search.SubjectTerm;

import java.io.Closeable;
import java.io.IOException;
import java.util.Objects;
import java.util.Properties;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ProsperEmailService implements Closeable {

    private static final Logger LOG = Logger.getLogger(ProsperEmailService.class.getSimpleName());

    private static final String FOLDER_NAME = "INBOX";

    private static final String MAIL_STORE_PROTOCOL_NAME = "mail.store.protocol";
    private static final String MAIL_STORE_PROTOCOL_VALUE = "imaps";

    private static final String ERROR_MESSAGE_TEMPLATAE = "There are %d identical e-mails";

    private final Store store;

    private Folder inboxFolder;


    public ProsperEmailService(final ProsperEmailServiceConfig config) throws AutomationException {
        LOG.info("Initializing connection to the e-mail server.");

        final Properties props = new Properties();
        props.setProperty(MAIL_STORE_PROTOCOL_NAME, MAIL_STORE_PROTOCOL_VALUE);

        final Session session = Session.getInstance(props);
        try {
            store = session.getStore();
            store.connect(config.getServerHost(), config.getUserEmail(), config.getUserPassword());
        } catch (MessagingException ex) {
            throw new AutomationException(ex.getMessage());
        }
    }

    public String getUniqueEmail(final String toAddress, final String emailSubject) throws AutomationException {
        try {
            inboxFolder = store.getFolder(FOLDER_NAME);
            inboxFolder.open(Folder.READ_ONLY);
        } catch (MessagingException ex) {
            throw new AutomationException(ex.getMessage());
        }

        final Address address;
        try {
            address = new InternetAddress(toAddress);
        } catch (AddressException ex) {
            throw new AutomationException(ex.getMessage());
        }

        final RecipientTerm rt = new RecipientTerm(Message.RecipientType.TO, address);
        final SubjectTerm st = new SubjectTerm(emailSubject);

        final AndTerm terms = new AndTerm(rt, st);

        Message[] messages;
        try {
            messages = inboxFolder.search(terms);
        } catch (MessagingException ex) {
            throw new AutomationException(ex.getMessage());
        }

        if (messages.length > 1) {
            throw new AutomationException(String.format(ERROR_MESSAGE_TEMPLATAE, messages.length));
        }

        String emailMessage = null;
        if (messages.length == 1 && Objects.nonNull(messages[0])) {
            try {
                emailMessage = messages[0].getContent().toString();
                inboxFolder.close(false);
            } catch (IOException | MessagingException ex) {
                throw new AutomationException(ex.getMessage());
            }
        }

        return emailMessage;
    }

    @Override
    public void close() {
        LOG.info("Closing connection to the e-mail server.");

        try {
            store.close();
        } catch (MessagingException ex) {
            try {
                throw new AutomationException(ex.toString());
            } catch (AutomationException e) {
                e.printStackTrace();
            }
        }
    }
}
