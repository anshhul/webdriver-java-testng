package com.prosper.automation.model.platform.prospect;

import com.google.common.base.Objects;
import com.prosper.automation.model.platform.appDb.ApplicantMatch;

import java.util.List;

/**
 * Created by rsubramanyam on 3/28/16.
 */
public class ApplicantMatchList {
    public List<ApplicantMatch> matches;

    public List<ApplicantMatch> getMatches() {
        return matches;
    }

    public void setMatches(List<ApplicantMatch> matches) {
        this.matches = matches;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ApplicantMatchList that = (ApplicantMatchList) o;
        return Objects.equal(matches, that.matches);
    }

    @Override public int hashCode() {
        return Objects.hashCode(matches);
    }
}
