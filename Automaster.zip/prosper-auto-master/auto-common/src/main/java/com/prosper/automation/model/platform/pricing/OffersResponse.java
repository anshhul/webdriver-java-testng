
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prosper.automation.model.platform.User;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"user", "user_type", "listed_offers"})
public final class OffersResponse {

    @JsonProperty("user")
    private User user;
    @JsonProperty("user_type")
    private String userType;
    @JsonProperty("listed_offers")
    private ListedOffers listedOffers;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public void setListedOffers(ListedOffers listedOffers) {
        this.listedOffers = listedOffers;
    }

    public OffersResponse() {
    }

    public ListedOffers getListedOffers() {
        return listedOffers;
    }

}
