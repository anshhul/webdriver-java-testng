package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 2/21/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) public class GetOffersValidationErrorResponse {

    @JsonProperty("code") private String code;
    @JsonProperty("message") private String message;
    @JsonProperty("errors") private ValidationErrorResponse errors;

    public GetOffersValidationErrorResponse() {}
    public GetOffersValidationErrorResponse(GetOffersValidationErrorResponseBuilder builder) {
        code = builder.code;
        message = builder.message;
        errors = builder.errors;
    }

    public ValidationErrorResponse getErrors() {
        return this.errors;
    }

    public String getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public class GetOffersValidationErrorResponseBuilder {

        public String code;
        public String message;
        public ValidationErrorResponse errors;

        public GetOffersValidationErrorResponseBuilder() {
        }

        public GetOffersValidationErrorResponseBuilder setErrorCode(String code) {
            this.code = code;
            return this;
        }

        public GetOffersValidationErrorResponseBuilder setMessage(String message) {
            this.message = message;
            return this;
        }

        public GetOffersValidationErrorResponseBuilder setErrors(ValidationErrorResponse errors) {
            this.errors = errors;
            return this;
        }

        public GetOffersValidationErrorResponse build() {
            return new GetOffersValidationErrorResponse(this);
        }
    }
}
