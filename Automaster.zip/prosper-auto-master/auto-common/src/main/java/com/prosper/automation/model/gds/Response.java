
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * @author grajasekar
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response {

    @JsonProperty("DV360EnvironmentName")
    private String dV360EnvironmentName;
    @JsonProperty("DV360SequenceID")
    private String dV360SequenceID;
    @JsonProperty("Errors")
    private List<Error> errors = new ArrayList<Error>();
    @JsonProperty("Bureau")
    private Bureau bureau;
    @JsonProperty("DecisionEngine")
    private DecisionEngine decisionEngine;


    @JsonIgnore
    public String getEquTWNHitFlag() {
        return bureau.getEquTWNHitFlag();
    }

    @JsonIgnore
    public String getEquTWNPullFlag() {
        return bureau.getEquTWNPullFlag();
    }

    @JsonIgnore
    public String getGiactPIHitFlag() {
        return bureau.getGiactPIHitFlag();
    }

    @JsonIgnore
    public String getGiactPIPullFlag() {
        return bureau.getGiactPIPullFlag();
    }

    @JsonIgnore
    public String getIDAnalyticsHitFlag() {
        return bureau.getIDAnalyticsHitFlag();
    }

    @JsonIgnore
    public String getIDAnalyticsPullFlag() {
        return bureau.getIDAnalyticsPullFlag();
    }

    @JsonIgnore
    public String getLNFlexIDHitFlag() {
        return bureau.getLNFlexIDHitFlag();
    }

    @JsonIgnore
    public String getLNFlexIDPullFlag() {
        return bureau.getLNFlexIDPullFlag();
    }

    @JsonIgnore
    public String getDV360EnvironmentName() {
        return dV360EnvironmentName;
    }

    @JsonIgnore
    public String getDV360SequenceID() {
        return dV360SequenceID;
    }

    @JsonIgnore
    public DecisionEngine getDecisionEngine() {
        return decisionEngine;
    }
}
