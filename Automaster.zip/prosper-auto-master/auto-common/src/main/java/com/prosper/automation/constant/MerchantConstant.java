package com.prosper.automation.constant;

import com.prosper.automation.enumeration.platform.Industry;
import com.prosper.automation.enumeration.platform.ProviderStatus;

public final class MerchantConstant {

	public static final String DEFAULT_ROLE = "MERCHANT";
	public static final String DEFAULT_PARTNER_NAME = "PHL";
	public static final String DEFAULT_MERCHANT_FIRST_NAME = "AUTO_MERCHANT_FIRST_NAME";
	public static final String DEFAULT_MERCHANT_LAST_NAME = "AUTO_MERCHANT_LAST_NAME";
	public static final String DEFAULT_SALUTATION = "SALUTATION";
	public static final String DEFAULT_SIGNER_DOB = "1980-01-01";
	public static final String DEFAULT_ADDRESS = "221 MAIN STREET";
	public static final String DEFAULT_TITLE = "MR";
	public static final String DEFAULT_EMAIL = "DEFAULT_MERCHANT_EMAIL@c1.dev";
	public static final String DEFAULT_PHONE_NUMBER = "8666156319";
	public static final String DEFAULT_CONTACT_THIRD_PARTY_ID = "AUTO_MERCHANT_THIRD_PARTY_CONTACT";
	public static final String DEFAULT_LEGAL_NAME = "AUTO_MERCHANT_LEGAL_NAME";
	public static final String DEFAULT_PURPOSE = "AUTO_MERCHANT_DEFAULT_PURPOSE";
	public static final Industry DEFAULT_INDUSTRY = Industry.HOSPITAL;
	public static final String DEFAULT_MERCHANT_FUNNEL_NAME = "DEFAULT_MERCHANT_FUNNEL_NAME";
	public static final String DEFAULT_PROMO_OPTION = "B";
	public static final String DEFAULT_NEXT_REVIEW_DATE = "2030-01-01";
	public static final Integer DEFAULT_UPPER_THRESHOLD = 3000;
	public static final Integer DEFAULT_LOWER_THRESHOLD = 2000;
	public static final Integer DEFAULT_TERMS_IN_MONTH = 36;
	public static final Integer DEFAULT_PROMO_LENGTH = 6;
	public static final Integer DEFAULT_FUNDING_DESTINATION_ID = 2;
	public static final Integer DEFAULT_INTENDED_ROLE = 4096;
	public static final ProviderStatus DEFAULT_COMPLIANCE_STATUS = ProviderStatus.PROBATIONARY;

	private MerchantConstant() {
	}
}
