
package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;
import com.prosper.automation.constant.Constant;

/**
 * Created by rsubramanyam on 4/15/16.
 */
public class CampaignProgram {

    @JsonProperty("campaign_program_id")
    public String campaignProgramId;
    @JsonProperty("campaign_id")
    public String campaignId;
    @JsonProperty("name")
    public String name;
    @JsonProperty("program_rule_set_id")
    public String programRuleSetId;
    @JsonProperty("ref_mc")
    public String refMc;
    @JsonProperty("rank")
    public Integer rank;
    @JsonProperty("pricing_id")
    public Integer pricingId;
    @JsonProperty("description")
    public String description;
    @JsonProperty("legacy_id")
    public Integer legacyId;
    @JsonProperty("legacy_channel")
    public String legacyChannel;
    @JsonProperty("fall_back_program_used")
    public String fallBackProgramUsed;
    @JsonProperty("work_flow_type_id")
    public int workFlowTypeId;
    @JsonProperty("is_abp_eligible")
    public Boolean isABPEligible;
    @JsonProperty("partner_source_code")
    public int partnerSourceCode;


    public CampaignProgram() {
    }

    private CampaignProgram(Builder builder) {
        campaignProgramId = builder.campaignProgramId;
        campaignId = builder.campaignId;
        name = builder.name;
        refMc = builder.refMc;
        rank = builder.rank;
        pricingId = builder.pricingId;
        description = builder.description;
        legacyId = builder.legacyId;
        legacyChannel = builder.legacyChannel;
        fallBackProgramUsed = builder.fallBackProgramUsed;
        workFlowTypeId = builder.workFlowTypeId;
        isABPEligible = builder.isABPEligible;
    }

    public static CampaignProgram createCampaignProgram(String name, String description, String campaignProgramId,
                                                        String campaignId, int campaignProgramRank,
                                                        int campaignProgramPricingId, int campaignProgramLegacyId,
                                                        String campaignProgramLegacyChannel, String refMc,
                                                        String fallBackProgramUsed, int workFlowTypeId, boolean isABPEligible,
                                                        String partnerSourceCode) {
        return new Builder().withCampaignProgramId(campaignProgramId).withCampaignId(campaignId)
                .withName(name)
                .withRefMc(refMc)
                .withPricingId(campaignProgramPricingId).withDescription(description)
                .withLegacyId(campaignProgramLegacyId).withLegacyChannel(campaignProgramLegacyChannel)
                .withFallBackProgramUsed(fallBackProgramUsed).withWorkFlowTypeId(workFlowTypeId).withIsABPEligible(isABPEligible)
                .withPartnerSourceCode(partnerSourceCode).withRank(campaignProgramRank)
                .build();
    }

    public String getCampaignProgramId() {
        return campaignProgramId;
    }

    public String getName() {
        return name;
    }

    public String getRefMc() {
        return refMc;
    }

    public Integer getRank() {
        return rank;
    }

    public Integer getPricingId() {
        return pricingId;
    }

    public String getDescription() {
        return description;
    }

    public Integer getLegacyId() {
        return legacyId;
    }

    public String getLegacyChannel() {
        return legacyChannel;
    }

    public String getFallBackProgramUsed() {
        return fallBackProgramUsed;
    }

    public int getWorkFlowTypeId() {
        return workFlowTypeId;
    }

    public Boolean getIsABPEligible() {
        return isABPEligible;
    }

    public String getCampaignId() {
        return campaignId;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CampaignProgram that = (CampaignProgram) o;
        return workFlowTypeId == that.workFlowTypeId &&
                partnerSourceCode == that.partnerSourceCode &&
                Objects.equal(campaignProgramId, that.campaignProgramId) &&
                Objects.equal(campaignId, that.campaignId) &&
                Objects.equal(name, that.name) &&
                Objects.equal(programRuleSetId, that.programRuleSetId) &&
                Objects.equal(refMc, that.refMc) &&
                Objects.equal(rank, that.rank) &&
                Objects.equal(pricingId, that.pricingId) &&
                Objects.equal(description, that.description) &&
                Objects.equal(legacyId, that.legacyId) &&
                Objects.equal(legacyChannel, that.legacyChannel) &&
                Objects.equal(fallBackProgramUsed, that.fallBackProgramUsed) &&
                Objects.equal(isABPEligible, that.isABPEligible);
    }

    @Override public int hashCode() {
        return Objects
                .hashCode(campaignProgramId, campaignId, name, programRuleSetId, refMc, rank, pricingId, description, legacyId,
                        legacyChannel, fallBackProgramUsed, workFlowTypeId, isABPEligible, partnerSourceCode);
    }

    public static final class Builder {

        private String campaignProgramId;
        private String campaignId;
        private String name;
        private String refMc;
        private Integer rank;
        private Integer pricingId;
        private String description;
        private Integer legacyId;
        private String legacyChannel;
        private String fallBackProgramUsed;
        private int workFlowTypeId;
        private String partnerSourceCode;
        private Boolean isABPEligible;


        public Builder() {
        }

        public Builder withCampaignProgramId(String val) {
            campaignProgramId = val;
            return this;
        }

        public Builder withCampaignId(String val) {
            campaignId = val;
            return this;
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withRefMc(String val) {
            refMc = val;
            return this;
        }

        public Builder withRank(Integer val) {
            rank = val;
            return this;
        }

        public Builder withPricingId(Integer val) {
            pricingId = val;
            return this;
        }

        public Builder withDescription(String val) {
            description = val;
            return this;
        }

        public Builder withLegacyId(Integer val) {
            legacyId = val;
            return this;
        }

        public Builder withLegacyChannel(String val) {
            legacyChannel = val;
            return this;
        }

        public Builder withFallBackProgramUsed(String val) {
            fallBackProgramUsed = val;
            return this;
        }

        public Builder withWorkFlowTypeId(int val) {
            workFlowTypeId = val;
            return this;
        }

        public Builder withIsABPEligible(Boolean val) {
            isABPEligible = val;
            return this;
        }

        public Builder withPartnerSourceCode(String code) {
            partnerSourceCode = code;
            return this;
        }

        public CampaignProgram build() {
            return new CampaignProgram(this);
        }
    }
}
