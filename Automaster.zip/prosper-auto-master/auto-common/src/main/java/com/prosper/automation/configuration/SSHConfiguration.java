
package com.prosper.automation.configuration;

/**
 * @author grajasekar
 * @since 0.0.1
 */
public final class SSHConfiguration {

    public static final int PORT = 22;

    private String hostName;
    private String user;
    private String password;


    public SSHConfiguration(final String hostName, final String user, final String password) {
        this.hostName = hostName;
        this.user = user;
        this.password = password;
    }

    private SSHConfiguration(final Builder builder) {
        this.hostName = builder.hostName;
        this.user = builder.user;
        this.password = builder.password;
    }

    public String getHostName() {
        return hostName;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }


    public static final class Builder {

        private String hostName;
        private String user;
        private String password;


        public Builder() {
        }

        public Builder withHostName(final String hostName) {
            this.hostName = hostName;
            return this;
        }

        public Builder withUser(final String user) {
            this.user = user;
            return this;
        }

        public Builder withPassword(final String password) {
            this.password = password;
            return this;
        }

        public SSHConfiguration build() {
            return new SSHConfiguration(this);
        }
    }
}
