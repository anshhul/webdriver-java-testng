package com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators;

import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class PartnerRequestLoanInfoComparator implements Comparator<LoanInfo> {
    public int compare(LoanInfo left, LoanInfo right) {
        if (right != null ? !left.equals(right) : left != null)
            return 1;
        return 0;
    }
}
