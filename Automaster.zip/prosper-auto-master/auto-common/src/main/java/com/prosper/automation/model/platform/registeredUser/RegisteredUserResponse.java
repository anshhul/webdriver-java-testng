package com.prosper.automation.model.platform.registeredUser;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prosper.automation.model.platform.RegisteredUserContactInfo;
import com.prosper.automation.model.platform.RegisteredUserLendingAccreditationResponse;

/**
 * Created by aamalraj on 12/21/15.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({"tilaccepted", "is_registration_complete", "user_id", "alt_key", "roles", "contact_info"})

public class RegisteredUserResponse {

    @JsonProperty("tilaccepted") private Boolean tilAccepted;
    @JsonProperty("is_registration_complete") private Boolean isRegistrationComplete;
    @JsonProperty("user_id") private String userId;
    @JsonProperty("alt_key") private String altKey;
    @JsonProperty("roles") private String roles;
    @JsonProperty("contact_info") private RegisteredUserContactInfo registeredUserContactInfo;
    @JsonProperty("lending_accreditation") private RegisteredUserLendingAccreditationResponse
            registeredUserLendingAccreditationResponse;
    @JsonProperty("til_accepted") private Boolean til_Accepted;

    public Boolean getTilAccepted() {
        return tilAccepted;
    }

    public Boolean getIsRegistrationComplete() {
        return isRegistrationComplete;
    }

    public String getUserId() {
        return userId;
    }

    public String getAltKey() {
        return altKey;
    }

    public String getRoles() {
        return roles;
    }

    public RegisteredUserLendingAccreditationResponse getRegisteredUserLendingAccreditationResponse() {
        return registeredUserLendingAccreditationResponse;
    }

    public Boolean getTil_Accepted() {
        return til_Accepted;
    }

    public RegisteredUserContactInfo getRegisteredUserContactInfo() {
        return registeredUserContactInfo;
    }
}
