package com.prosper.automation.model.platform.schedule;

import java.util.Objects;

/**
 * Created by sphatak on 3/27/17.
 */
public class SftpInfo {
    private String hostname;
    private int sftpPortNumber;
    private String sftpUsername;
    private String sftpPassword;
    private String uploadFolderName;
    private String downloadFolderName;
    private String filenameRegexPattern;
    private String acknowledgeDownloadFolderName;
    private String acknowledgeFilenameRegexPattern;

    private SftpInfo(String hostname, int sftpPortNumber, String sftpUsername, String sftpPassword,
                     String uploadFolderName, String downloadFolderName, String filenameRegexPattern,
                     String acknowledgeDownloadFolderName, String acknowledgeFilenameRegexPattern) {
        this.hostname = hostname;
        this.sftpPortNumber = sftpPortNumber;
        this.sftpUsername = sftpUsername;
        this.sftpPassword = sftpPassword;
        this.uploadFolderName = uploadFolderName;
        this.downloadFolderName = downloadFolderName;
        this.filenameRegexPattern = filenameRegexPattern;
        this.acknowledgeDownloadFolderName = acknowledgeDownloadFolderName;
        this.acknowledgeFilenameRegexPattern = acknowledgeFilenameRegexPattern;
    }

    public String getHostname() {
        return hostname;
    }

    public int getSftpPortNumber() {
        return sftpPortNumber;
    }

    public String getSftpUsername() {
        return sftpUsername;
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public String getUploadFolderName() {
        return uploadFolderName;
    }

    public String getDownloadFolderName() {
        return downloadFolderName;
    }

    public String getFilenameRegexPattern() {
        return filenameRegexPattern;
    }

    public String getAcknowledgeDownloadFolderName() {
        return acknowledgeDownloadFolderName;
    }

    public String getAcknowledgeFilenameRegexPattern() {
        return acknowledgeFilenameRegexPattern;
    }

    public static class Builder {
        private String hostname;
        private int sftpPortNumber;
        private String sftpUsername;
        private String sftpPassword;
        private String uploadFolderName;
        private String downloadFolderName;
        private String filenameRegexPattern;
        private String acknowledgeDownloadFolderName;
        private String acknowledgeFilenameRegexPattern;

        public Builder withHostname(String hostname) {
            this.hostname = hostname;
            return this;
        }

        public Builder withSftpPortNumber(int sftpPortNumber) {
            this.sftpPortNumber = sftpPortNumber;
            return this;
        }

        public Builder withSftpUsername(String sftpUsername) {
            this.sftpUsername = sftpUsername;
            return this;
        }

        public Builder withSftpPassword(String sftpPassword) {
            this.sftpPassword = sftpPassword;
            return this;
        }

        public Builder withUploadFolderName(String uploadFolderName) {
            this.uploadFolderName = uploadFolderName;
            return this;
        }

        public Builder withDownloadFolderName(String downloadFolderName) {
            this.downloadFolderName = downloadFolderName;
            return this;
        }

        public Builder withFilenameRegexPattern(String filenameRegexPattern) {
            this.filenameRegexPattern = filenameRegexPattern;
            return this;
        }

        public Builder withAcknowledgeDownloadFolderName(String acknowledgeDownloadFolderName) {
            this.acknowledgeDownloadFolderName = acknowledgeDownloadFolderName;
            return this;
        }

        public Builder withAcknowledgeFilenameRegexPattern(String acknowledgeFilenameRegexPattern) {
            this.acknowledgeFilenameRegexPattern = acknowledgeFilenameRegexPattern;
            return this;
        }

        public SftpInfo build() {
            return new SftpInfo(hostname, sftpPortNumber, sftpUsername, sftpPassword, uploadFolderName, downloadFolderName,
                    filenameRegexPattern, acknowledgeDownloadFolderName, acknowledgeFilenameRegexPattern);
        }
        @Override
        public int hashCode() {
            return Objects.hash(hostname, sftpPortNumber, sftpUsername, sftpPassword, uploadFolderName, downloadFolderName,
                    filenameRegexPattern, acknowledgeDownloadFolderName, acknowledgeFilenameRegexPattern);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            final SftpInfo other = (SftpInfo) obj;
            return Objects.equals(this.hostname, other.hostname)
                    && Objects.equals(this.sftpPortNumber, other.sftpPortNumber)
                    && Objects.equals(this.sftpUsername, other.sftpUsername)
                    && Objects.equals(this.sftpPassword, other.sftpPassword)
                    && Objects.equals(this.uploadFolderName, other.uploadFolderName)
                    && Objects.equals(this.downloadFolderName, other.downloadFolderName)
                    && Objects.equals(this.filenameRegexPattern, other.filenameRegexPattern)
                    && Objects.equals(this.acknowledgeDownloadFolderName, other.acknowledgeDownloadFolderName)
                    && Objects.equals(this.acknowledgeFilenameRegexPattern, other.acknowledgeFilenameRegexPattern);
        }

    }

}
