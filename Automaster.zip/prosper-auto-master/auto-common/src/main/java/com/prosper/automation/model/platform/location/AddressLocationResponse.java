
package com.prosper.automation.model.platform.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * A location service response class representation.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class AddressLocationResponse {
    
    @JsonProperty("results")
    private List<Location> results;
    
    
    @JsonIgnore
    public List<Location> getResults() {
        return results;
    }
}
