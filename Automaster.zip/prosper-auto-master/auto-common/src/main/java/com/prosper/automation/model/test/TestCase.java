
package com.prosper.automation.model.test;

import com.prosper.automation.annotation.test.ProsperZephyr;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * A class for test case representation.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class TestCase implements Serializable {
    
    protected static final String FIELD_DELIMITER = ";";
    protected static final String FIELD_STRING_LOG_TEMPLATE = "%s;%s;%s;%s;%s;%s";
    public static final TestCase NOT_DEFINED = null;

    protected String projectName;
    
    protected String ticketId;
    protected String ticketNumber;
    protected String testMethodName;
    protected String testCaseName;
    protected String testPriority;
    protected TestDescription testDescription;
    protected List<String> labels;
    
    
    public TestCase() {
    }
    
    public TestCase(final String testMethodName, final ProsperZephyr prosperZephyrAnnotation) {
        projectName = prosperZephyrAnnotation.project();
        
        ticketId = prosperZephyrAnnotation.ticketId();
        ticketNumber = prosperZephyrAnnotation.ticketNumber();
        
        this.testMethodName = testMethodName;
        
        testCaseName = prosperZephyrAnnotation.testTitle();
        testPriority = prosperZephyrAnnotation.priority();
        
        labels = Arrays.asList(prosperZephyrAnnotation.labels());
        testDescription = new TestDescription.Builder().withStepToTests(Arrays.asList(prosperZephyrAnnotation.stepToTests()))
                .withExpectedResult(prosperZephyrAnnotation.expectedResult()).build();
    }
    
    public String getTestMethodName() {
        return testMethodName;
    }
    
    public String getProjectName() {
        return projectName;
    }
    
    public String getTestCaseName() {
        return testCaseName;
    }
    
    public TestDescription getTestDescription() {
        return testDescription;
    }
    
    public List<String> getLabels() {
        return labels;
    }
    
    public String getTestPriority() {
        return testPriority;
    }

    public void setTestMethodName(String testMethodName) {
        this.testMethodName = testMethodName;
    }

    public void setTestCaseName(String testCaseName) {
        this.testCaseName = testCaseName;
    }

    @Override
    public String toString() {
        // TODO: this is a hack to the current TestNG reporting schema; need to figure out a more elegant way of doing this.
        return String.format(FIELD_STRING_LOG_TEMPLATE, projectName, ticketId, ticketNumber, testCaseName, testMethodName,
                labels);
    }
    
    public String getTicketNumber() {
        return ticketNumber;
    }
}
