
package com.prosper.automation.util;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum Rounding {
    NONE(0.0), ONE_FIFTH(0.2), ONE_TEN_THOUSANDTH(0.0001);
    
    private final double maxAbsoluteDelta;
    
    
    Rounding(final double maxAbsoluteDelta) {
        this.maxAbsoluteDelta = maxAbsoluteDelta;
    }
    
    public boolean isAcceptable(final double value1, final double value2) {
        return Math.abs(value1 - value2) <= maxAbsoluteDelta;
    }
}
