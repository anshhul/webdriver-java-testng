package com.prosper.automation.model.platform.pricing;

import com.prosper.automation.exception.AutomationException;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.csv.CSVRecord;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;

/**
 * Created by ppatil on 12/6/16.
 */
public class ScoreCardData {

    private Double annualIncome;
    //    private Integer creditReportId;
    private Double pmi7Score;
    private Double AA_Weights_Var1;
    private Double AA_Weights_Var2;
    private Double AA_Weights_Var3;
    private Double AA_Weights_Var4;
    private String AA_Vars_Var1;
    private String AA_Vars_Var2;
    private String AA_Vars_Var3;
    private String AA_Vars_Var4;
    private int rowId;
    private Map<String, String> bureauData;

    public ScoreCardData() {

    }

//    public Integer getCreditReportId() {
//        return creditReportId;
//    }

    public Double getPmi7Score() {
        return pmi7Score;
    }

    public int getRowId() {
        return rowId;
    }

    public Double getAnnualIncome() {
        return annualIncome;
    }

    public Map getbureauDataMap() {
        return bureauData;
    }

    public String getAA_Vars_Var4() {
        return AA_Vars_Var4;
    }

    public void setAA_Vars_Var4(String AA_Vars_Var4) {
        this.AA_Vars_Var4 = AA_Vars_Var4;
    }

    public String getAA_Vars_Var3() {
        return AA_Vars_Var3;
    }

    public void setAA_Vars_Var3(String AA_Vars_Var3) {
        this.AA_Vars_Var3 = AA_Vars_Var3;
    }

    public String getAA_Vars_Var2() {
        return AA_Vars_Var2;
    }

    public void setAA_Vars_Var2(String AA_Vars_Var2) {
        this.AA_Vars_Var2 = AA_Vars_Var2;
    }

    public String getAA_Vars_Var1() {
        return AA_Vars_Var1;
    }

    public void setAA_Vars_Var1(String AA_Vars_Var1) {
        this.AA_Vars_Var1 = AA_Vars_Var1;
    }


    public Double getAA_Weights_Var3() {
        return AA_Weights_Var3;
    }

    public void setAA_Weights_Var3(Double AA_Weights_Var3) {
        this.AA_Weights_Var3 = AA_Weights_Var3;
    }

    public Double getAA_Weights_Var4() {
        return AA_Weights_Var4;
    }

    public void setAA_Weights_Var4(Double AA_Weights_Var4) {
        this.AA_Weights_Var4 = AA_Weights_Var4;
    }

    public Double getAA_Weights_Var1() {
        return AA_Weights_Var1;
    }

    public void setAA_Weights_Var1(Double AA_Weights_Var1) {
        this.AA_Weights_Var1 = AA_Weights_Var1;
    }

    public Double getAA_Weights_Var2() {
        return AA_Weights_Var2;
    }

    public void setAA_Weights_Var2(Double AA_Weights_Var2) {
        this.AA_Weights_Var2 = AA_Weights_Var2;
    }


    private ScoreCardData(final Builder builder) {

        annualIncome = builder.annualIncome;
//        creditReportId = builder.creditReportId;
        pmi7Score = builder.pmi7Score;
        bureauData = builder.bureauData;
        AA_Weights_Var1 = builder.AA_Weights_Var1;
        AA_Weights_Var2 = builder.AA_Weights_Var2;
        AA_Weights_Var3 = builder.AA_Weights_Var3;
        AA_Weights_Var4 = builder.AA_Weights_Var4;
        AA_Vars_Var1 = builder.AA_Vars_Var1;
        AA_Vars_Var2 = builder.AA_Vars_Var2;
        AA_Vars_Var3 = builder.AA_Vars_Var3;
        AA_Vars_Var4 = builder.AA_Vars_Var4;
        rowId = builder.rowId;
    }


    public static final class Builder {
        private Double annualIncome;
        //        private Integer creditReportId;
        public Double pmi7Score;
        private Double AA_Weights_Var1;
        private Double AA_Weights_Var2;
        private Double AA_Weights_Var3;
        private Double AA_Weights_Var4;
        private String AA_Vars_Var1;
        private String AA_Vars_Var2;
        private String AA_Vars_Var3;
        private String AA_Vars_Var4;
        private int rowId;
        private Map<String, String> bureauData;


        public Builder() {
        }

        public Builder withAnnualIncome(final Double annualIncome) {
            this.annualIncome = annualIncome;
            return this;
        }

        public Builder withRowId(final int rowId) {
            this.rowId = rowId;
            return this;
        }

        public Builder withPmi7Score(final Double pmi7Score) {
            this.pmi7Score = pmi7Score;
            return this;
        }

        public Builder withAAWeightsVar1(final Double AA_Weights_Var1) {
            this.AA_Weights_Var1 = AA_Weights_Var1;
            return this;
        }

        public Builder withAAWeightsVar2(final Double AA_Weights_Var2) {
            this.AA_Weights_Var2 = AA_Weights_Var2;
            return this;
        }

        public Builder withAAWeightsVar3(final Double AA_Weights_Var3) {
            this.AA_Weights_Var3 = AA_Weights_Var3;
            return this;
        }

        public Builder withAAWeightsVar4(final Double AA_Weights_Var4) {
            this.AA_Weights_Var4 = AA_Weights_Var4;
            return this;
        }

        public Builder withAAVarsVar1(final String AA_Vars_Var1) {
            this.AA_Vars_Var1 = AA_Vars_Var1;
            return this;
        }

        public Builder withAAVarsVar2(final String AA_Vars_Var2) {
            this.AA_Vars_Var2 = AA_Vars_Var2;
            return this;
        }

        public Builder withAAVarsVar3(final String AA_Vars_Var3) {
            this.AA_Vars_Var3 = AA_Vars_Var3;
            return this;
        }

        public Builder withAAVarsVar4(final String AA_Vars_Var4) {
            this.AA_Vars_Var4 = AA_Vars_Var4;
            return this;
        }

//        public Builder withcreditReportId(final Integer creditReportId) {
//            this.creditReportId = creditReportId;
//            return this;
//        }

        public Builder withBureauDataMap(final Map bureauData) {
            this.bureauData = bureauData;
            return this;
        }

        public ScoreCardData build() {
            return new ScoreCardData(this);
        }

    }


    public static final class Mapper {

        public static ScoreCardData map(int rowId, final CSVRecord applicant) throws AutomationException {


            final ScoreCardData.Builder builder = new ScoreCardData.Builder()
                    .withAnnualIncome("NULL".equals(applicant.get("BWRSTATEDANNUALINC")) ? null : Double.valueOf(applicant.get("BWRSTATEDANNUALINC")))
                    .withPmi7Score("NULL".equals(applicant.get("PMI7")) ? null : Double.valueOf(applicant.get("PMI7")))
                    .withRowId(rowId)
                    .withAAWeightsVar1(Double.valueOf(String.valueOf(applicant.get("AA_Weights_Var1"))))
                    .withAAWeightsVar2(Double.valueOf(String.valueOf(applicant.get("AA_Weights_Var2"))))
                    .withAAWeightsVar3(Double.valueOf(String.valueOf(applicant.get("AA_Weights_Var3"))))
                    .withAAWeightsVar4(Double.valueOf(String.valueOf(applicant.get("AA_Weights_Var4"))))
                    .withAAVarsVar1(applicant.get("AA_Vars_Var1"))
                    .withAAVarsVar2(applicant.get("AA_Vars_Var2"))
                    .withAAVarsVar3(applicant.get("AA_Vars_Var3"))
                    .withAAVarsVar4(applicant.get("AA_Vars_Var4"));

            Map<String, String> ba = new HashedMap();
            ba.putAll(applicant.toMap());
            builder.withBureauDataMap(processAttributes(ba));


            return builder.build();
        }

        private static Map processAttributes(Map<String, String> ba) {

            for (Map.Entry<String, String> entry : ba.entrySet()) {
                if (entry.getKey() != null && "NULL".equalsIgnoreCase(entry.getValue())) {
                    entry.setValue(null);
                }

            }


            return ba;
        }

    }

}
