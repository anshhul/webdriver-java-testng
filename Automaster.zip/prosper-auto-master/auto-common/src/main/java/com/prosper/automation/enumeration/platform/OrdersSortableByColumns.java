package com.prosper.automation.enumeration.platform;

public enum OrdersSortableByColumns {

    order_id,
    order_source_type,
    saved_search_name,
    submitted_order_amount,
    submitted_loan_count,
    submitted_estimated_return,
    order_number,
    invested_estimated_return,
    created_date

}
