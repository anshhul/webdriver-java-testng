package com.prosper.automation.model.platform.registeredUser;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prosper.automation.model.platform.RegisteredUserContactInfo;
import com.prosper.automation.model.platform.RegisteredUserLendingAccreditationRequest;

/**
 * Created by aamalraj on 12/21/15.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({"type", "password", "intended_role", "contact_info", "lending_accreditation"})

public final class RegisteredUserRequest {

    @JsonProperty("type") private String type;
    @JsonProperty("password") private String password;
    @JsonProperty("intended_role") private String intendedRole;
    @JsonProperty("contact_info") private RegisteredUserContactInfo registeredUserContactInfo;
    @JsonProperty("lending_accreditation") private RegisteredUserLendingAccreditationRequest
            registeredUserLendingAccreditationRequest;

    public RegisteredUserRequest() {
    }

    private RegisteredUserRequest(final Builder builder) {
        type = builder.type;
        password = builder.password;
        intendedRole = builder.intendedRole;
        registeredUserContactInfo = builder.registeredUserContactInfo;
        registeredUserLendingAccreditationRequest = builder.registeredUserLendingAccreditationRequest;
    }

    @JsonIgnore public String getType() {
        return type;
    }

    @JsonIgnore public String getPassword() {
        return password;
    }

    @JsonIgnore public String getIntendedRole() {
        return intendedRole;
    }

    @JsonIgnore public RegisteredUserContactInfo getRegisteredUserContactInfo() {
        return registeredUserContactInfo;
    }

    @JsonIgnore public RegisteredUserLendingAccreditationRequest getRegisteredUserLendingAccreditationRequest() {
        return registeredUserLendingAccreditationRequest;
    }

    public static final class Builder {

        private String type;
        private String password;
        private String intendedRole;
        private RegisteredUserContactInfo registeredUserContactInfo;
        private RegisteredUserLendingAccreditationRequest registeredUserLendingAccreditationRequest;

        public Builder() {
        }

        public Builder withType(final String type) {
            this.type = type;
            return this;
        }

        public Builder withPassword(final String password) {
            this.password = password;
            return this;
        }

        public Builder withIntendedRole(final String intendedRole) {
            this.intendedRole = intendedRole;
            return this;
        }

        public Builder withRegisteredUserContactInfo(final RegisteredUserContactInfo registeredUserContactInfo) {
            this.registeredUserContactInfo = registeredUserContactInfo;
            return this;
        }

        public Builder withRegisteredUserLendingAccreditation(
                final RegisteredUserLendingAccreditationRequest registeredUserLendingAccreditationRequest) {
            this.registeredUserLendingAccreditationRequest = registeredUserLendingAccreditationRequest;
            return this;
        }

        public RegisteredUserRequest build() {
            return new RegisteredUserRequest(this);
        }
    }
}
