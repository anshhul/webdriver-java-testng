package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * @author pbudiono
 */
public final class SecretQuestion {

	@JsonProperty("secret_question_id")
	private Long secretQuestionId;

	@JsonProperty("secrete_question")
	private String secretQuestion;

	public SecretQuestion(final long secretQuestionId, final String secretQuestion) {
		this.secretQuestionId = secretQuestionId;
		this.secretQuestion = secretQuestion;
	}

	public SecretQuestion() {
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		SecretQuestion that = (SecretQuestion) o;
		return Objects.equal(secretQuestionId, that.secretQuestionId) && Objects.equal(secretQuestion, that.secretQuestion);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(secretQuestionId, secretQuestion);
	}
}
