
package com.prosper.automation.model.platform.passiveInvest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 25 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PassiveInvestmentResponse {

    @JsonProperty("job_name")
    private String jobName;

    @JsonProperty("hostname")
    private String hostName;

    @JsonProperty("completed_without_errors")
    private Boolean completedWithoutErrors;

    @JsonProperty("job_failure_message")
    private String jobFailureMessage;

    @JsonProperty("job_start_time")
    private String jobStartTime;

    @JsonProperty("job_end_time")
    private String jobEndTime;

    @JsonProperty("job_run_time")
    private String jobRunTime;

    @JsonProperty("listings_to_invest_count")
    private Integer listingsToInvestCount;

    @JsonProperty("order_success_count")
    private Integer orderSuccessCount;

    @JsonProperty("total_bid_success_count")
    private Integer totalBidSuccessCount;

    @JsonProperty("order_failure_count")
    private Integer orderFailureCount;

    @JsonProperty("total_bid_failure_count")
    private Integer totalBidFailureCount;

    @JsonProperty("orders_failed")
    private List<OrdersFailed> ordersFailed;

    @JsonProperty("orders_successful")
    private List<OrdersSuccess> ordersSuccessful;


    public String getJobName() {
        return jobName;
    }

    public String getHostName() {
        return hostName;
    }

    public Boolean getCompletedWithoutErrors() {
        return completedWithoutErrors;
    }

    public String getJobFailureMessage() {
        return jobFailureMessage;
    }

    public String getJobStartTime() {
        return jobStartTime;
    }

    public String getJobEndTime() {
        return jobEndTime;
    }

    public String getJobRunTime() {
        return jobRunTime;
    }

    public Integer getListingsToInvestCount() {
        return listingsToInvestCount;
    }

    public Integer getOrderSuccessCount() {
        return orderSuccessCount;
    }

    public Integer getTotalBidSuccessCount() {
        return totalBidSuccessCount;
    }

    public Integer getOrderFailureCount() {
        return orderFailureCount;
    }

    public Integer getTotalBidFailureCount() {
        return totalBidFailureCount;
    }

    public List<OrdersFailed> getOrdersFailed() {
        return ordersFailed;
    }

    public List<OrdersSuccess> getOrdersSuccessful() {
        return ordersSuccessful;
    }

}
