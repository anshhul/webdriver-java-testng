package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rchintapalli on 4/6/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PartnerData {

    @JsonProperty("partner_name")
    private String partnerName;
   @JsonProperty("contact_name")
    private String contactName;
    @JsonProperty("partner_email")
    private String partnerEmail;
    @JsonProperty("contact_contact_number")
    private String contactNumber;
    @JsonProperty("refAc")
    private String refAc;
    @JsonProperty("refMc")
    private String refMc;

    public PartnerData(){
    }

    public PartnerData(Builder builder) {
        setPartnerName(builder.partnerName);
        setContactName(builder.contactName);
        setPartnerEmail(builder.partnerEmail);
        setContactNumber(builder.contactNumber);
        setRefAc(builder.refAc);
        setRefMc(builder.refMc);
    }


    public String getPartnerName() { return partnerName; }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getPartnerEmail() {
        return partnerEmail;
    }

    public void setPartnerEmail(String partnerEmail) {
        this.partnerEmail = partnerEmail;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactContactNumber) {
        this.contactNumber = contactContactNumber;
    }

    public String getRefAc() {
        return refAc;
    }

    public void setRefAc(String refAc) {
        this.refAc = refAc;
    }

    public String getRefMc() {
        return refMc;
    }

    public void setRefMc(String refMc) {
        this.refMc = refMc;
    }

    @Override
    public String toString() {
        return "PartnerData{" +
                "partnerName='" + partnerName + '\'' +
                ", contactName='" + contactName + '\'' +
                ", partnerEmail='" + partnerEmail + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", refAc='" + refAc + '\'' +
                ", refMc='" + refMc + '\'' +
                '}';
    }

    public static final class Builder{
        private String partnerName;
        private String contactName;
        private String partnerEmail;
        private String contactNumber;
        private String refAc;
        private String refMc;

        public Builder(){
        }

        public Builder withPartnerName(final String partnerName){
            this.partnerName = partnerName;
            return this;
        }

        public Builder withContactName(final String ContactName){
            this.contactName = ContactName;
            return this;
        }

        public Builder withPartnerEmail(final String partnerEmail){
            this.partnerEmail = partnerEmail;
            return this;
        }

        public Builder withContactNumber(final String ContactNumber){
            this.contactNumber = ContactNumber;
            return this;
        }

        public Builder withRefAc(final String refAc){
            this.refAc = refAc;
            return this;
        }

        public Builder withRefMc(final String refMc){
            this.refMc = refMc;
            return this;
        }

        public PartnerData build(){
            return new PartnerData(this);
        }

    }
}
