
package com.prosper.automation.email;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ProsperEmailServiceConfig {

    private String serverHost;
    private String userEmail;
    private String userPassword;


    public ProsperEmailServiceConfig(final String exchangeHost, final String userEmail, final String userPassword) {
        this.serverHost = exchangeHost;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }

    private ProsperEmailServiceConfig(final Builder builder) {
        serverHost = builder.exchangeHost;
        userEmail = builder.userEmail;
        userPassword = builder.userPassword;
    }

    public String getServerHost() {
        return serverHost;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }


    public static final class Builder {

        private String exchangeHost;
        private String userEmail;
        private String userPassword;


        public Builder() {
        }

        public Builder withExchangeHost(final String exchangeHost) {
            this.exchangeHost = exchangeHost;
            return this;
        }

        public Builder withUserEmail(final String userEmail) {
            this.userEmail = userEmail;
            return this;
        }

        public Builder withUserPassword(final String userPassword) {
            this.userPassword = userPassword;
            return this;
        }

        public ProsperEmailServiceConfig build() {
            return new ProsperEmailServiceConfig(this);
        }
    }
}
