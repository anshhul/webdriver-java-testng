
package com.prosper.automation.util;

/**
 * Created by rsubramanyam on 4/12/16.
 */
public enum Colorize {
    RED("\033[31m"),
    RESET("\033[0m"),
    BLUE("\033[34m");

    private String color = null;

    Colorize(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
}
