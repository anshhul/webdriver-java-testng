
package com.prosper.automation.model.wcf.allocateListing;

public class AllocateWholePrivateRequest {

    public static String requestStr =
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">" +
                    "<soapenv:Header/>" +
                    "<soapenv:Body>" +
                    "<tem:ConvertListingsToWLoans>" +
                    "<tem:request>" +
                    "<pros:LoansToConvert xmlns:pros=\"http://schemas.datacontract.org/2004/07/Prosper.Reporting.Publication.DataContract\">"
                    + "<pros:WholeLoanConversionObject>" +
                    "<pros:ListingID>%s</pros:ListingID>" +
                    "<pros:TypeOfInvestment>%s</pros:TypeOfInvestment>" +
                    "<pros:StartDate>%s</pros:StartDate>" +
                    "<pros:UserID>%s</pros:UserID>" +
                    "</pros:WholeLoanConversionObject>" +
                    "</pros:LoansToConvert>" +
                    "</tem:request>" +
                    "</tem:ConvertListingsToWLoans>" +
                    "</soapenv:Body>" +
                    "</soapenv:Envelope>";


    public static final class Builder {

        private String listingID;
        private String investmentType;
        private String lenderID;
        private String startDate;


        public Builder withListingID(final String listingID) {
            this.listingID = listingID;
            return this;
        }

        public Builder withInvestmentType(final String investmentType) {
            this.investmentType = investmentType;
            return this;
        }

        public Builder withLenderID(final String lenderID) {
            this.lenderID = lenderID;
            return this;
        }

        public Builder withStartDate(final String date) {
            this.startDate = date;
            return this;
        }

        public String build() {
            return String.format(requestStr, listingID, investmentType, startDate, lenderID);
        }
    }
}
