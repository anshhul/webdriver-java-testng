package com.prosper.automation.model.platform.merchant;

/**
 * Created by pbudiono on 6/6/16.
 */
public enum MerchantType {

	PRD("prd"), PAD_LS("pad_ls"), PAD_NO_LS("pad_no_ls");

	private final String type;

	MerchantType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}
}
