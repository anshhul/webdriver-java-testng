package com.prosper.automation.constant;

/**
 * Created by rsubramanyam on 7/8/16.
 */
public enum StatesSupported {
    MILITARY_STATE;
}
