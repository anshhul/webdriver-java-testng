
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SlpAllocationAlgoResponse {
    
    private String jobName;
    private String jobId;
    private String status;
    private String createdDate;
    private JobParameters jobParameters;


    @JsonProperty("created_date")
    public String getCreatedDate() {
        return createdDate;
    }
    
    @JsonProperty("job_id")
    public String getJobId() {
        return jobId;
    }
    
    @JsonProperty("job_name")
    public String getJobName() {
        return jobName;
    }

    @JsonProperty("job_parameters")
    public JobParameters getJobParameters() {
        return jobParameters;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }

    public void setJobId(final String jobId) {
        this.jobId = jobId;
    }

    public void setJobName(final String jobName) {
        this.jobName = jobName;
    }

    public void setJobParameters(final JobParameters jobParameters) {
        this.jobParameters = jobParameters;
    }

    public void setStatus(final String status) {
        this.status = status;
    }
    
}
