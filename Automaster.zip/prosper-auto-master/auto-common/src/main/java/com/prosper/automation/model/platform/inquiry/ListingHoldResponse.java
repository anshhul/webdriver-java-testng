
package com.prosper.automation.model.platform.inquiry;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"Error", "ListingId", "Holds"})
public final class ListingHoldResponse {

    @JsonProperty("Error")
    private String error;
    @JsonProperty("ListingId")
    private Long listingId;
    @JsonProperty("Holds")
    private List<ListingHold> holds;


    public ListingHoldResponse() {
    }

    private ListingHoldResponse(final Builder builder) {
        error = builder.error;
        listingId = builder.listingId;
        holds = builder.holds;
    }

    @JsonIgnore
    public String getError() {
        return error;
    }

    @JsonIgnore
    public List<ListingHold> getHolds() {
        return holds;
    }

    @JsonIgnore
    public Long getListingId() {
        return listingId;
    }


    public static final class Builder {

        private String error;
        private Long listingId;
        private List<ListingHold> holds;


        public Builder() {
        }

        public Builder withError(final String error) {
            this.error = error;
            return this;
        }

        public Builder withListingId(final Long listingId) {
            this.listingId = listingId;
            return this;
        }

        public Builder withHolds(final List<ListingHold> holds) {
            this.holds = holds;
            return this;
        }

        public ListingHoldResponse build() {
            return new ListingHoldResponse(this);
        }
    }
}
