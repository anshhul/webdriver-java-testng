
package com.prosper.automation.model.platform.merchant;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 6/2/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class SearchMerchantResponse {

	@JsonProperty("name")
	private String merchantName;
	@JsonProperty("third_party_id")
	private String thirdPartyID;
	@JsonProperty("street_address")
	private String streetAddress;
	@JsonProperty("city")
	private String city;
	@JsonProperty("state_code")
	private String stateCode;

	@JsonIgnore
	public String getMerchantName() {
		return merchantName;
	}

	@JsonIgnore
	public String getThirdPartyID() {
		return thirdPartyID;
	}

	@JsonIgnore
	public String getStreetAddress() {
		return streetAddress;
	}

	@JsonIgnore
	public String getCity() {
		return city;
	}

	@JsonIgnore
	public String getStateCode() {
		return stateCode;
	}
}
