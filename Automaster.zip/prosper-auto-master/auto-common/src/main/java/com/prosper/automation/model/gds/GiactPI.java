
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class GiactPI {

    @JsonProperty("GiactPI_PullFlag")
    private String giactPIPullFlag;
    @JsonProperty("GiactPI_HitFlag")
    private String giactPIHitFlag;


    @JsonIgnore
    public String getGiactPIPullFlag() {
        return giactPIPullFlag;
    }

    @JsonIgnore
    public String getGiactPIHitFlag() {
        return giactPIHitFlag;
    }
}
