    package com.prosper.automation.constant.web;

    /**
     * Created by bhirani on 8/17/16.
     */
    public class SupportSitePageMessageConstants {

        public static final String AAPageHeader = "Listing Adverse Action Reasons";
        public static final String ExperianAAHeader = "Experian Adverse Action Reasons";
        public static final String ProsperModelAAReasonHeader = "Prosper Risk Model Adverse Action Reasons";
        public static final String FinalAAReasonHeader = "Final Adverse Action Reasons";
    }
