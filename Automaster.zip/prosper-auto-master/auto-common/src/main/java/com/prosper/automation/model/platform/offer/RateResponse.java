
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by pbudiono on 5/31/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class RateResponse {

    @JsonProperty("result")
    private List<RateResult> rateResult;
    @JsonProperty("result_count")
    private Integer resultCount;
    @JsonProperty("total_count")
    private Integer totalCount;


    @JsonIgnore
    public List<RateResult> getRateResult() {
        return rateResult;
    }

    @JsonIgnore
    public int getResultCount() {
        return resultCount;
    }

    @JsonIgnore
    public int getTotalCount() {
        return totalCount;
    }
}
