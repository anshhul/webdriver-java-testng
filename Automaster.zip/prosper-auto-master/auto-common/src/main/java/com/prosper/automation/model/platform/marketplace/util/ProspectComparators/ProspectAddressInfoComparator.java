package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.AddressInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectAddressInfoComparator implements Comparator<AddressInfo> {
    @Override public int compare(AddressInfo left, AddressInfo right) {
        if (left!= null && !left.getZipCode().equalsIgnoreCase(right.getZipCode()))
            return 1;
        if (left!= null && !left.getState().equalsIgnoreCase(right.getState()))
            return 1;
        if (left!= null && !left.getCity().equalsIgnoreCase(right.getCity()))
            return 1;
        if (left!= null && !left.getAddress1().trim().equalsIgnoreCase(right.getAddress1().trim()))
            return 1;
        return 0;
    }
}
