package com.prosper.automation.model.platform.user;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author sphatak
 *
 */
public final class UserClickThroughResponse {

	@JsonProperty("status")
	private Boolean status;

	@JsonProperty("message")
	private String message;

	@JsonProperty("result")
	private List<UserClickThrough> result;

	@JsonProperty("total_count")
	private Integer totalCount;

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<UserClickThrough> getResult() {
		return result;
	}

	public void setResult(List<UserClickThrough> result) {
		this.result = result;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

}
