
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ProspectToBorrowerResponse {
    
    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("listing_id")
    private Long listingId;

    public Long getUserId() {
        return userId;
    }

    public Long getListingId() {
        return listingId;
    }
}
