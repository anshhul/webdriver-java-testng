package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


import java.util.List;
import java.util.Map;

/**
 * Created by ppatil on 11/22/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class TransunionUserCredit {


    @JsonProperty("social_security_number")
    private SocialSecurityNumber ssn;
    @JsonProperty("score_model")
    private List<ScoreModel> scoreModel;
    @JsonProperty("bureau_attributes")
    private Map bureauAttributes;

    public Map getBureauAttributes() {
        return bureauAttributes;
    }

    public void setBureauAttributes(Map bureauAttributes) {
        this.bureauAttributes = bureauAttributes;
    }

    public List<ScoreModel> getScoreModel() {
        return scoreModel;
    }

    public void setScoreModel(List<ScoreModel> scoreModel) {
        this.scoreModel = scoreModel;
    }


    public void setSsn(SocialSecurityNumber ssn) {
        this.ssn = ssn;
    }


    public TransunionUserCredit() {
    }


    private TransunionUserCredit(final Builder builder) {
        ssn = builder.ssn;
        scoreModel = builder.scoreModel;
        bureauAttributes = builder.bureauAttributes;
    }

    public static final class Builder {

        private SocialSecurityNumber ssn;
        private List<ScoreModel> scoreModel;
        private Map bureauAttributes;

        public Builder() {
        }

        public Builder withSsn(final SocialSecurityNumber ssn) {
            this.ssn = ssn;
            return this;
        }

        public Builder withScoreModel(final List<ScoreModel> scoreModel) {
            this.scoreModel = scoreModel;
            return this;
        }

        public Builder withBureauAttributes(final Map bureauAttributes) {
            this.bureauAttributes = bureauAttributes;
            return this;
        }

        public TransunionUserCredit build() {
            return new TransunionUserCredit(this);
        }
    }
}
