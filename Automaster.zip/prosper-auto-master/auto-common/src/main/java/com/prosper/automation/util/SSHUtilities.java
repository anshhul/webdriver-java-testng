
package com.prosper.automation.util;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.google.common.collect.Lists;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.prosper.automation.configuration.SSHConfiguration;
import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.exception.AutomationException;

/**
 * @author grajasekar
 * @since 0.0.1
 */
public final class SSHUtilities implements Closeable {

    private static final Logger LOG = Logger.getLogger(SSHUtilities.class.getSimpleName());

    private static final String STRICT_HOST_KEY_CHECKING_KEY = "StrictHostKeyChecking";
    private static final String STRICT_HOST_KEY_CHECKING_VALUE = "no";

    private static final String EXEC_CHANNEL_NAME = "exec";
    private static final String SFTP_CHANNEL_NAME = "sftp";

    private static final String SEARCH_FILE_CMD = "ls %s | grep %s";

    private static final String INITIATING_SSH_CONNECTION_LOG = "Initiating remote ssh connection to %s.";
    private static final String UNABLE_TO_INITIATE_SSH_CONNECTION_LOG = "Unable to establish ssh connection to remote server.";
    private static final String UNABLE_TO_READ_FILE_CONTENT_FROM_REMOTE_SERVER_LOG = "Unable to read files from remote server.";
    private static final String UNABLE_TO_SEARCH_FILE_FROM_REMOTE_SERVER_LOG = "Unable to search file from remote server.";
    private static final String UNABLE_TO_EXCUTE_COMMAND_OVER_REMOTE_SERVER_LOG =
            "Unable to execute command over remote server.";
    private static final String CLOSING_REMOTE_SSH_SESSION_LOG = "Closing ssh connection to remote host.";
    private static final String SESSION_IS_NULL_LOG = "Session object is null.";
    private static final String READING_FILE_LOG = "Reading file content %s from remote server.";
    private static final String SEARCH_FILE_LOG = "Searching file with key word %s in %s directory.";
    private static final String COMMAND_LOG = "Running command %s in directory.";

    private final SSHConfiguration sshConfiguration;

    private final Session session;

    // TODO: there can only be ten channels open at a time; this limits the number of concurrency.
    public SSHUtilities(final SSHConfiguration sshConfiguration) throws AutomationException {
        LOG.info(String.format(INITIATING_SSH_CONNECTION_LOG, sshConfiguration.getHostName()));

        final Properties properties = new Properties();
        properties.put(STRICT_HOST_KEY_CHECKING_KEY, STRICT_HOST_KEY_CHECKING_VALUE);

        this.sshConfiguration = sshConfiguration;

        try {
            session = new JSch().getSession(sshConfiguration.getUser(), sshConfiguration.getHostName(), SSHConfiguration.PORT);
            session.setPassword(sshConfiguration.getPassword());
            session.setConfig(properties);
            session.connect();
        } catch (final JSchException jse) {
            throw new AutomationException(UNABLE_TO_INITIATE_SSH_CONNECTION_LOG, jse);
        }
    }

    public List<String> searchFiles(String remoteDirectory, String searchKey) throws AutomationException {

        try {
            LOG.info(String.format(SEARCH_FILE_LOG, searchKey, remoteDirectory));

            final ChannelExec channelExec = (ChannelExec) session.openChannel(EXEC_CHANNEL_NAME);

            String resultString;
            try (InputStream inputStream = channelExec.getInputStream()) {
                final String remoteCommand = String.format(SEARCH_FILE_CMD, remoteDirectory, searchKey);

                channelExec.setCommand(remoteCommand);
                channelExec.connect();

                resultString = IOUtils.toString(inputStream);
            }

            channelExec.disconnect();

            return resultString.equals(StringConstant.EMPTY) ? Lists.newArrayList()
                    : Arrays.asList(resultString.split(StringConstant.NEW_LINE));
        } catch (JSchException | IOException ex) {
            throw new AutomationException(UNABLE_TO_SEARCH_FILE_FROM_REMOTE_SERVER_LOG, ex);
        }
    }

    public String readFiles(String remoteFilePath) throws AutomationException {

        try {
            LOG.info(String.format(READING_FILE_LOG, remoteFilePath));

            final Channel channel = session.openChannel(SFTP_CHANNEL_NAME);
            final ChannelSftp sftpChannel = (ChannelSftp) channel;

            sftpChannel.connect();

            String returnString;
            try (final InputStream inputStream = sftpChannel.get(remoteFilePath)) {
                returnString = IOUtils.toString(inputStream);
            }

            sftpChannel.disconnect();

            return returnString;
        } catch (JSchException | SftpException | IOException ex) {
            throw new AutomationException(UNABLE_TO_READ_FILE_CONTENT_FROM_REMOTE_SERVER_LOG, ex);
        }
    }

    public String runCommand(String command) throws JSchException, IOException, AutomationException {

        LOG.info(String.format(COMMAND_LOG, command));

        String commandResult = "";
        Channel channel = session.openChannel(EXEC_CHANNEL_NAME);
        ((ChannelExec) channel).setCommand(command);
        channel.setInputStream(null);
        ((ChannelExec) channel).setErrStream(System.err);

        InputStream in = channel.getInputStream();
        channel.connect();
        byte[] tmp = new byte[1024];
        while (true) {
            while (in.available() > 0) {
                int i = in.read(tmp, 0, 1024);
                if (i < 0) {
                    break;
                }
                commandResult += new String(tmp, 0, i);
            }
            if (channel.isClosed()) {
                break;
            }
            try {
            } catch (Exception ex) {
                throw new AutomationException(UNABLE_TO_EXCUTE_COMMAND_OVER_REMOTE_SERVER_LOG, ex);
            }
        }
        channel.disconnect();
        session.disconnect();
        return commandResult;
    }

    @Override
    public void close() throws IOException {
        LOG.info(CLOSING_REMOTE_SSH_SESSION_LOG);

        try {
            session.disconnect();
        } catch (final Exception e) {
            LOG.warn(SESSION_IS_NULL_LOG, e);
        }
    }
}
