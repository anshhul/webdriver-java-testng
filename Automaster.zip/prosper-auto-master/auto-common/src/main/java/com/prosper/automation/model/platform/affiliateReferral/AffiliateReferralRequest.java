
package com.prosper.automation.model.platform.affiliateReferral;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class AffiliateReferralRequest {
    
    @JsonProperty("affiliate_alt_key")
    private String affiliateAltKey;
    @JsonProperty("affiliate_marketing_campaign_alt_key")
    private String affiliateMarketingCampaignAltKey;
    @JsonProperty("affiliate_data")
    private String affiliateData;
    @JsonProperty("referrer_url")
    private String referrerUrl;
    @JsonProperty("landing_url")
    private String landingUrl;
    
    
    private AffiliateReferralRequest(final Builder builder) {
        affiliateAltKey = builder.affiliateAltKey;
        affiliateMarketingCampaignAltKey = builder.affiliateMarketingCampaignAltKey;
        affiliateData = builder.affiliateData;
        referrerUrl = builder.referrerUrl;
        landingUrl = builder.landingUrl;
    }
    
    
    public static final class Builder {
        
        private String affiliateAltKey;
        private String affiliateMarketingCampaignAltKey;
        private String affiliateData;
        private String referrerUrl;
        private String landingUrl;
        
        
        public Builder() {
        }
        
        public Builder withAffiliateAltKey(final String affiliateAltKey) {
            this.affiliateAltKey = affiliateAltKey;
            return this;
        }
        
        public Builder withAffiliateMarketingCampaignAltKey(final String affiliateMarketingCampaignAltKey) {
            this.affiliateMarketingCampaignAltKey = affiliateMarketingCampaignAltKey;
            return this;
        }
        
        public Builder withAffiliateData(final String affiliateData) {
            this.affiliateData = affiliateData;
            return this;
        }
        
        public Builder withReferrerUrl(final String referrerUrl) {
            this.referrerUrl = referrerUrl;
            return this;
        }
        
        public Builder withLandingUrl(final String landingUrl) {
            this.landingUrl = landingUrl;
            return this;
        }
        
        public AffiliateReferralRequest build() {
            return new AffiliateReferralRequest(this);
        }
    }
}
