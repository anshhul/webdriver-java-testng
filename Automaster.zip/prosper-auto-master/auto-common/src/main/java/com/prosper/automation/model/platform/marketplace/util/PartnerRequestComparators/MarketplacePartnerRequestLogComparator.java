package com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators;

import com.prosper.automation.model.platform.prospect.PartnerRequestGetResponse;
import org.apache.log4j.Logger;
import org.testng.Assert;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class MarketplacePartnerRequestLogComparator implements Comparator<PartnerRequestGetResponse> {

    private PartnerRequestGetResponse response;
    private PartnerRequestAddressInfoComparator aInfoComparator = new PartnerRequestAddressInfoComparator();
    private PartnerRequestBankAccountInfoComparator bInfoComparator = new PartnerRequestBankAccountInfoComparator();
    private PartnerRequestContactInfoComparator cInfoComparator = new PartnerRequestContactInfoComparator();
    private PartnerRequestEmploymentInfoComparator eInfoComparator = new PartnerRequestEmploymentInfoComparator();
    private PartnerRequestLoanInfoComparator lInfoComparator = new PartnerRequestLoanInfoComparator();
    private PartnerRequestPersonalInfoComparator pInfoComparator = new PartnerRequestPersonalInfoComparator();
    private PartnerRequestIdInfoComparator idInfoComparator = new PartnerRequestIdInfoComparator();

    @Override public int compare(PartnerRequestGetResponse otherResponse, PartnerRequestGetResponse expectedResponse) {
        if (aInfoComparator.compare(otherResponse.getAddressInfo(), expectedResponse.getAddressInfo()) == 1) {
            Assert.fail(otherResponse.getAddressInfo() + " does not match expected " + expectedResponse.getAddressInfo());
        }
        if (bInfoComparator.compare(otherResponse.getBankAccountInfo(), expectedResponse.getBankAccountInfo()) == 1) {
            Assert.fail(otherResponse.getBankAccountInfo() + " does not match expected " + expectedResponse.getBankAccountInfo());
        }
        if (cInfoComparator.compare(otherResponse.getContactInfo(), expectedResponse.getContactInfo()) == 1) {
            Assert.fail(otherResponse.getBankAccountInfo() + " does not match expected " + expectedResponse.getContactInfo());
        }
        if (eInfoComparator.compare(otherResponse.getEmploymentInfo(), expectedResponse.getEmploymentInfo()) == 1) {
            Assert.fail(otherResponse.getEmploymentInfo() + " does not match expected " + expectedResponse.getEmploymentInfo());
        }
        if (lInfoComparator.compare(otherResponse.getLoanInfo(), expectedResponse.getLoanInfo()) == 1) {
            Assert.fail(otherResponse.getLoanInfo() + " does not match expected " + expectedResponse.getLoanInfo());
        }
        if (pInfoComparator.compare(otherResponse.getPersonalInfo(), expectedResponse.getPersonalInfo()) == 1) {
            Assert.fail(otherResponse.getPersonalInfo() + " does not match expected " + expectedResponse.getPersonalInfo());
        }
        if (idInfoComparator.compare(otherResponse.getIdentification(), expectedResponse.getIdentification()) == 1) {
            Assert.fail(otherResponse.getIdentification() + " does not match expected " + expectedResponse.getIdentification());
        }
        return 0;
    }
}
