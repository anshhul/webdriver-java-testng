package com.prosper.automation.model.platform.origination;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by sphatak on 4/10/17.
 *
 */
public class OriginationActionRequest {
    @JsonProperty("action")
    private String action;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public static class OriginationActionRequestBuilder{

        private String action;

        public OriginationActionRequest build() {
            OriginationActionRequest request  = new OriginationActionRequest();
            request.setAction(action);
            return request;
        }

        public OriginationActionRequestBuilder action(String action){
            this.action = action;
            return this;
        }

    }
}
