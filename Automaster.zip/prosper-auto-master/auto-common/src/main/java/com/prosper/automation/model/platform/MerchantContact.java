
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantContact {

    @JsonProperty("signer_date_of_birth")
    private String signerDateOfBirth;
    @JsonProperty("office_roles")
    private OfficeRolesName items;
    @JsonProperty("address_info")
    private AddressInfo addressinfo;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("phone_number")
    private PhoneNumber phoneNumber;
    @JsonProperty("is_main_point_of_contact")
    private boolean isMainPointofContact;
    @JsonProperty("salutation")
    private String salutation;
    @JsonProperty("title")
    private String title;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("email")
    private String email;

}
