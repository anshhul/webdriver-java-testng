
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

/**
 * @author grajasekar
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class DecisionEngine {

    @JsonProperty("DE_PullGiactPIInd")
    private String dePullGiactPIInd;
    @JsonProperty("DE_PullEquTWNInd")
    private String dePullEquTWNInd;
    @JsonProperty("DE_PullLNFlexIdInd")
    private String dePullLNFlexIdInd;
    @JsonProperty("DE_PullIDAnalyticsInd")
    private String dePullIDAnalyticsInd;
    @JsonProperty("DE_DecisionReasonCode1")
    private String deDecisionReasonCode1;
    @JsonProperty("DE_DecisionReasonCode2")
    private String deDecisionReasonCode2;
    @JsonProperty("DE_DecisionReasonCode3")
    private String deDecisionReasonCode3;
    @JsonProperty("DE_SystemId")
    private String deSystemId;
    @JsonProperty("Holds")
    private List<GDSHold> holds;
    @JsonProperty("CalculatedAttributes")
    private Map<String, String> calculatedAttributes;


    @JsonIgnore
    public String getDePullGiactPIInd() {
        return dePullGiactPIInd;
    }

    @JsonIgnore
    public String getDePullEquTWNInd() {
        return dePullEquTWNInd;
    }

    @JsonIgnore
    public String getDePullLNFlexIdInd() {
        return dePullLNFlexIdInd;
    }

    @JsonIgnore
    public String getDePullIDAnalyticsInd() {
        return dePullIDAnalyticsInd;
    }

    @JsonIgnore
    public String getDeDecisionReasonCode1() {
        return deDecisionReasonCode1;
    }

    @JsonIgnore
    public String getDeDecisionReasonCode2() {
        return deDecisionReasonCode2;
    }

    @JsonIgnore
    public String getDeDecisionReasonCode3() {
        return deDecisionReasonCode3;
    }

    @JsonIgnore
    public String getDeSystemId() {
        return deSystemId;
    }

    @JsonIgnore
    public List<GDSHold> getHolds() {
        return holds;
    }

    @JsonIgnore
    public Map<String, String> getCalculatedAttributes() {
        return calculatedAttributes;
    }
}
