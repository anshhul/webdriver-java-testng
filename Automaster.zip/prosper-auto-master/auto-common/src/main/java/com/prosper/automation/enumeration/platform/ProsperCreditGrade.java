
package com.prosper.automation.enumeration.platform;

/**
 * An enumeration for credit grade.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum ProsperCreditGrade {

    NC(0),
    HR(1),
    E(2),
    D(3),
    C(4),
    B(5),
    A(6),
    AA(7),
    F(8),
    HIGH_INQUIRY(9),
    BANKRUPTCY(10),
    HIGH_PMI_SCORE(11), TOO_FEW_TRADELINES(12), LOW_CREDITSCORE(13), DOB_18(14), MA_STATE(15);


    

    private int id;
    
    ProsperCreditGrade(final int id) {
        this.id = id;
    }
}
