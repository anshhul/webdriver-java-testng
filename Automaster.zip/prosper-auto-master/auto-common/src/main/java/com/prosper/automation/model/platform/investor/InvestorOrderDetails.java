package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class InvestorOrderDetails {

    private double orderAmount;
    private int loanCount;
    private double estimatedReturn;

    @JsonProperty("estimated_return")
    public double getEstimatedReturn() {
        return estimatedReturn;
    }

    @JsonProperty("loan_count")
    public int getLoanCount() {
        return loanCount;
    }

    @JsonProperty("order_amount")
    public double getOrderAmount() {
        return orderAmount;
    }

    public void setEstimatedReturn(final double estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public void setLoanCount(final int loanCount) {
        this.loanCount = loanCount;
    }

    public void setOrderAmount(final double orderAmount) {
        this.orderAmount = orderAmount;
    }

}
