
package com.prosper.automation.model.platform.publishing;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author ramkaur on 24 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"result", "result_count", "total_count"})
public class SECReportResponse {

    @JsonProperty("result")
    private List<SECResults> result;

    @JsonProperty("result_count")
    private Integer resultCount;

    @JsonProperty("total_count")
    private Integer totalCount;


    public List<SECResults> getResult() {
        return result;
    }

    public Integer getResultCount() {
        return resultCount;
    }

    public Integer getTotalCount() {
        return totalCount;
    }
}
