
package com.prosper.automation.model.testdata;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class TUUserCreditProfile {

    private String ssn;
    private String ficoScore8;
    private String ficoAutoScore8;
    private String ficoScore4;
    private String ficoAutoScore4;
    private String vantageScore;
    private String vantageScore2;
    private String ficoInsuranceScorePG2;
    private String ficoInsuranceScoreH32;
    private String tuirsProperty;
    private String tuirsAuto;
    private String tuirsAutoPropertyScore;
    private String totalNumberOfAccounts;
    private String totalNumberOfBankcardAccounts;
    private String totalNumberOfRevolvingAccounts;
    private String totalNumberOfInstallmentAccounts;
    private String totalNumberOfMortgageAccounts;
    private String totalNumberOfBankruptcyPublicRecords;
    private String totalNumberOfPublicRecords;

    private TUUserCreditProfile(Builder builder) {
        setSsn(builder.ssn);
        setFicoScore8(builder.ficoScore8);
        setFicoAutoScore8(builder.ficoAutoScore8);
        setFicoScore4(builder.ficoScore4);
        setFicoAutoScore4(builder.ficoAutoScore4);
        setVantageScore(builder.vantageScore);
        setVantageScore2(builder.vantageScore2);
        setFicoInsuranceScorePG2(builder.ficoInsuranceScorePG2);
        setFicoInsuranceScoreH32(builder.ficoInsuranceScoreH32);
        setTuirsProperty(builder.tuirsProperty);
        setTuirsAuto(builder.tuirsAuto);
        setTuirsAutoPropertyScore(builder.tuirsAutoPropertyScore);
        setTotalNumberOfAccounts(builder.totalNumberOfAccounts);
        setTotalNumberOfBankcardAccounts(builder.totalNumberOfBankcardAccounts);
        setTotalNumberOfRevolvingAccounts(builder.totalNumberOfRevolvingAccounts);
        setTotalNumberOfInstallmentAccounts(builder.totalNumberOfInstallmentAccounts);
        setTotalNumberOfMortgageAccounts(builder.totalNumberOfMortgageAccounts);
        setTotalNumberOfBankruptcyPublicRecords(builder.totalNumberOfBankruptcyPublicRecords);
        setTotalNumberOfPublicRecords(builder.totalNumberOfPublicRecords);
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getFicoScore8() {
        return ficoScore8;
    }

    public void setFicoScore8(String ficoScore8) {
        this.ficoScore8 = ficoScore8;
    }

    public String getFicoAutoScore8() {
        return ficoAutoScore8;
    }

    public void setFicoAutoScore8(String ficoAutoScore8) {
        this.ficoAutoScore8 = ficoAutoScore8;
    }

    public String getFicoScore4() {
        return ficoScore4;
    }

    public void setFicoScore4(String ficoScore4) {
        this.ficoScore4 = ficoScore4;
    }

    public String getFicoAutoScore4() {
        return ficoAutoScore4;
    }

    public void setFicoAutoScore4(String ficoAutoScore4) {
        this.ficoAutoScore4 = ficoAutoScore4;
    }

    public String getVantageScore() {
        return vantageScore;
    }

    public void setVantageScore(String vantageScore) {
        this.vantageScore = vantageScore;
    }

    public String getVantageScore2() {
        return vantageScore2;
    }

    public void setVantageScore2(String vantageScore2) {
        this.vantageScore2 = vantageScore2;
    }

    public String getFicoInsuranceScorePG2() {
        return ficoInsuranceScorePG2;
    }

    public void setFicoInsuranceScorePG2(String ficoInsuranceScorePG2) {
        this.ficoInsuranceScorePG2 = ficoInsuranceScorePG2;
    }

    public String getFicoInsuranceScoreH32() {
        return ficoInsuranceScoreH32;
    }

    public void setFicoInsuranceScoreH32(String ficoInsuranceScoreH32) {
        this.ficoInsuranceScoreH32 = ficoInsuranceScoreH32;
    }

    public String getTuirsProperty() {
        return tuirsProperty;
    }

    public void setTuirsProperty(String tuirsProperty) {
        this.tuirsProperty = tuirsProperty;
    }

    public String getTuirsAuto() {
        return tuirsAuto;
    }

    public void setTuirsAuto(String tuirsAuto) {
        this.tuirsAuto = tuirsAuto;
    }

    public String getTuirsAutoPropertyScore() {
        return tuirsAutoPropertyScore;
    }

    public void setTuirsAutoPropertyScore(String tuirsAutoPropertyScore) {
        this.tuirsAutoPropertyScore = tuirsAutoPropertyScore;
    }

    public String getTotalNumberOfAccounts() {
        return totalNumberOfAccounts;
    }

    public void setTotalNumberOfAccounts(String totalNumberOfAccounts) {
        this.totalNumberOfAccounts = totalNumberOfAccounts;
    }

    public String getTotalNumberOfBankcardAccounts() {
        return totalNumberOfBankcardAccounts;
    }

    public void setTotalNumberOfBankcardAccounts(String totalNumberOfBankcardAccounts) {
        this.totalNumberOfBankcardAccounts = totalNumberOfBankcardAccounts;
    }

    public String getTotalNumberOfRevolvingAccounts() {
        return totalNumberOfRevolvingAccounts;
    }

    public void setTotalNumberOfRevolvingAccounts(String totalNumberOfRevolvingAccounts) {
        this.totalNumberOfRevolvingAccounts = totalNumberOfRevolvingAccounts;
    }

    public String getTotalNumberOfInstallmentAccounts() {
        return totalNumberOfInstallmentAccounts;
    }

    public void setTotalNumberOfInstallmentAccounts(String totalNumberOfInstallmentAccounts) {
        this.totalNumberOfInstallmentAccounts = totalNumberOfInstallmentAccounts;
    }

    public String getTotalNumberOfMortgageAccounts() {
        return totalNumberOfMortgageAccounts;
    }

    public void setTotalNumberOfMortgageAccounts(String totalNumberOfMortgageAccounts) {
        this.totalNumberOfMortgageAccounts = totalNumberOfMortgageAccounts;
    }

    public String getTotalNumberOfBankruptcyPublicRecords() {
        return totalNumberOfBankruptcyPublicRecords;
    }

    public void setTotalNumberOfBankruptcyPublicRecords(String totalNumberOfBankruptcyPublicRecords) {
        this.totalNumberOfBankruptcyPublicRecords = totalNumberOfBankruptcyPublicRecords;
    }

    public String getTotalNumberOfPublicRecords() {
        return totalNumberOfPublicRecords;
    }

    public void setTotalNumberOfPublicRecords(String totalNumberOfPublicRecords) {
        this.totalNumberOfPublicRecords = totalNumberOfPublicRecords;
    }

    public static final class Builder {

        private String ssn;
        private String ficoScore8;
        private String ficoAutoScore8;
        private String ficoScore4;
        private String ficoAutoScore4;
        private String vantageScore;
        private String vantageScore2;
        private String ficoInsuranceScorePG2;
        private String ficoInsuranceScoreH32;
        private String tuirsProperty;
        private String tuirsAuto;
        private String tuirsAutoPropertyScore;
        private String totalNumberOfAccounts;
        private String totalNumberOfBankcardAccounts;
        private String totalNumberOfRevolvingAccounts;
        private String totalNumberOfInstallmentAccounts;
        private String totalNumberOfMortgageAccounts;
        private String totalNumberOfBankruptcyPublicRecords;
        private String totalNumberOfPublicRecords;

        public Builder() {
        }

        public Builder withSsn(String val) {
            ssn = val;
            return this;
        }

        public Builder withFicoScore8(String val) {
            ficoScore8 = val;
            return this;
        }

        public Builder withFicoAutoScore8(String val) {
            ficoAutoScore8 = val;
            return this;
        }

        public Builder withFicoScore4(String val) {
            ficoScore4 = val;
            return this;
        }

        public Builder withFicoAutoScore4(String val) {
            ficoAutoScore4 = val;
            return this;
        }

        public Builder withVantageScore(String val) {
            vantageScore = val;
            return this;
        }

        public Builder withVantageScore2(String val) {
            vantageScore2 = val;
            return this;
        }

        public Builder withFicoInsuranceScorePG2(String val) {
            ficoInsuranceScorePG2 = val;
            return this;
        }

        public Builder withFicoInsuranceScoreH32(String val) {
            ficoInsuranceScoreH32 = val;
            return this;
        }

        public Builder withTuirsProperty(String val) {
            tuirsProperty = val;
            return this;
        }

        public Builder withTuirsAuto(String val) {
            tuirsAuto = val;
            return this;
        }

        public Builder withTuirsAutoPropertyScore(String val) {
            tuirsAutoPropertyScore = val;
            return this;
        }

        public Builder withTotalNumberOfAccounts(String val) {
            totalNumberOfAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfBankcardAccounts(String val) {
            totalNumberOfBankcardAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfRevolvingAccounts(String val) {
            totalNumberOfRevolvingAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfInstallmentAccounts(String val) {
            totalNumberOfInstallmentAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfMortgageAccounts(String val) {
            totalNumberOfMortgageAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfBankruptcyPublicRecords(String val) {
            totalNumberOfBankruptcyPublicRecords = val;
            return this;
        }

        public Builder withTotalNumberOfPublicRecords(String val) {
            totalNumberOfPublicRecords = val;
            return this;
        }

        public TUUserCreditProfile build() {
            return new TUUserCreditProfile(this);
        }
    }
}
