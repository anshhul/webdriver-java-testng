
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"application_id", "partner_tracking_id", "external_prospect_id", "ref_d", "validated_membership_date",
        "eligibility_status", "ineligibility_reason"})
public final class PartnerInfo {
    
    @JsonProperty("application_id")
    private Long applicationId;
    @JsonProperty("partner_tracking_id")
    private Long partnerTrackingId;
    @JsonProperty("external_prospect_id")
    private Long externalProspectId;
    @JsonProperty("ref_d")
    private String refD;
    @JsonProperty("validated_membership_date")
    private String validatedMembershipDate;
    @JsonProperty("eligibility_status")
    private String eligibilityStatus;
    @JsonProperty("ineligibility_reason")
    private String ineligibilityReason;

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getIneligibilityReason() {
        return ineligibilityReason;
    }

    public void setIneligibilityReason(String ineligibilityReason) {
        this.ineligibilityReason = ineligibilityReason;
    }

    public String getEligibilityStatus() {
        return eligibilityStatus;
    }

    public void setEligibilityStatus(String eligibilityStatus) {
        this.eligibilityStatus = eligibilityStatus;
    }

    public String getValidatedMembershipDate() {
        return validatedMembershipDate;
    }

    public void setValidatedMembershipDate(String validatedMembershipDate) {
        this.validatedMembershipDate = validatedMembershipDate;
    }

    public Long getExternalProspectId() {
        return externalProspectId;
    }

    public void setExternalProspectId(Long externalProspectId) {
        this.externalProspectId = externalProspectId;
    }

    public Long getPartnerTrackingId() {
        return partnerTrackingId;
    }

    public void setPartnerTrackingId(Long partnerTrackingId) {
        this.partnerTrackingId = partnerTrackingId;
    }

    public String getRefD() {
        return refD;
    }

    public void setRefD(String refD) {
        this.refD = refD;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PartnerInfo that = (PartnerInfo) o;
        return Objects.equal(applicationId, that.applicationId) &&
                Objects.equal(partnerTrackingId, that.partnerTrackingId) &&
                Objects.equal(externalProspectId, that.externalProspectId) &&
                Objects.equal(refD, that.refD) &&
                Objects.equal(validatedMembershipDate, that.validatedMembershipDate) &&
                Objects.equal(eligibilityStatus, that.eligibilityStatus) &&
                Objects.equal(ineligibilityReason, that.ineligibilityReason);
    }

    @Override public int hashCode() {
        return Objects
                .hashCode(applicationId, partnerTrackingId, externalProspectId, refD, validatedMembershipDate, eligibilityStatus,
                        ineligibilityReason);
    }

    @Override public String toString() {
        return "PartnerInfo{" +
                "applicationId=" + applicationId +
                ", partnerTrackingId=" + partnerTrackingId +
                ", externalProspectId=" + externalProspectId +
                ", refD='" + refD + '\'' +
                ", validatedMembershipDate='" + validatedMembershipDate + '\'' +
                ", eligibilityStatus='" + eligibilityStatus + '\'' +
                ", ineligibilityReason='" + ineligibilityReason + '\'' +
                '}';
    }
}
