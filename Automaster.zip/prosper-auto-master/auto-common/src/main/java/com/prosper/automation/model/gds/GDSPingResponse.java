
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by grajasekar on 7/30/15.
 */
public final class GDSPingResponse {

    @JsonProperty("ping")
    private String directPing;


    @JsonIgnore
    public String getDirectPing() {
        return directPing;
    }
}
