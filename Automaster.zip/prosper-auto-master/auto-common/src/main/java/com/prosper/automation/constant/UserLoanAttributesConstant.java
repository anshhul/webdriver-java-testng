package com.prosper.automation.constant;

import com.prosper.automation.model.platform.pricing.UserLoanAttributes;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class UserLoanAttributesConstant {

    private static final int ZERO = 0;
    private static final int MINUS_ONE = -1;

    public static final UserLoanAttributes CALCULATE_PMI_ATTR_TEST =
            new UserLoanAttributes.Builder().withIsPriorBorrower(false).withActiveLoanCount(ZERO).withOriginalAmountBorrowed(0.0)
                                            .withCurrentPrincipalBalance(0.0).withLatestCreditScore(MINUS_ONE).build();

    private UserLoanAttributesConstant() {
    }
}
