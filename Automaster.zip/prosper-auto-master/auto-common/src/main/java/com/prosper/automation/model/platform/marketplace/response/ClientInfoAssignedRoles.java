package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.List;

/**
 * Created by rsubramanyam on 4/15/16.
 */
public class ClientInfoAssignedRoles {
    @JsonProperty("client_info")
    ClientInfo clientInfo;
    @JsonProperty("assigned_roles")
    List<AssignableRoleResponse> assignedRoles;

    public ClientInfo getClientInfo() {
        return clientInfo;
    }

    public void setClientInfo(ClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }

    public List<AssignableRoleResponse> getAssignedRoles() {
        return assignedRoles;
    }

    public void setAssignedRoles(List<AssignableRoleResponse> assignedRoles) {
        this.assignedRoles = assignedRoles;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ClientInfoAssignedRoles that = (ClientInfoAssignedRoles) o;
        return Objects.equal(clientInfo, that.clientInfo) && Objects.equal(assignedRoles, that.assignedRoles);
    }

    @Override public int hashCode() {
        return Objects.hashCode(clientInfo, assignedRoles);
    }
}
