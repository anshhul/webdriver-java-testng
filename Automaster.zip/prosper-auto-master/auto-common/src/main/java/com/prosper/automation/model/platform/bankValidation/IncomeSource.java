
package com.prosper.automation.model.platform.bankValidation;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */
public class IncomeSource {
    
    @JsonProperty("type")
    private String type;
    @JsonProperty("identifier")
    private String identifier;
    @JsonProperty("averageIncome")
    private Integer averageIncome;
    @JsonProperty("frequency")
    private String frequency;
    
    
    /**
     *
     * @return The type
     */
    @JsonProperty("type")
    public String getType() {
        return type;
    }
    
    /**
     *
     * @return The identifier
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }
    
    /**
     *
     * @return The averageIncome
     */
    @JsonProperty("averageIncome")
    public Integer getAverageIncome() {
        return averageIncome;
    }
    
    /**
     *
     * @return The frequency
     */
    @JsonProperty("frequency")
    public String getFrequency() {
        return frequency;
    }
    
}
