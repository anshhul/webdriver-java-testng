
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ProspectResponse {

    @JsonProperty("prospect")
    private Prospect prospect;
    @JsonProperty("channel")
    private Channel channel;
    @JsonProperty("campaign")
    private Campaign campaign;
    @JsonProperty("program")
    private ProgramVo program;
    @JsonProperty("pricing")
    private Pricing pricing;
    //@JsonProperty("partner")
    //private Partner partner;

    public Campaign getCampaign() {
        return campaign;
    }

    public ProgramVo getProgram() {
        return program;
    }

    public Pricing getPricing() {
        return pricing;
    }

    @JsonIgnore
    public Prospect getProspect() {
        return prospect;
    }

    @JsonIgnore
    public Channel getChannel() {
        return channel;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ProspectResponse that = (ProspectResponse) o;
        return Objects.equal(prospect, that.prospect) &&
                Objects.equal(channel, that.channel) &&
                Objects.equal(campaign, that.campaign) &&
                Objects.equal(program, that.program) &&
                Objects.equal(pricing, that.pricing);
    }

    @Override public int hashCode() {
        return Objects.hashCode(prospect, channel, campaign, program, pricing);
    }

    @Override public String toString() {
        return "ProspectResponse{" +
                "prospect=" + prospect +
                ", channel=" + channel +
                ", campaign=" + campaign +
                ", program=" + program +
                ", pricing=" + pricing +
                '}';
    }
}
