
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class InvestorLoanGroupings {

    @JsonProperty("principal")
    private Double principal;
    
    @JsonProperty("percentage")
    private Double percentage;
    
    @JsonProperty("prosperRating")
    private String prosperRating;


    public Double getPercentage() {
        return percentage;
    }

    public Double getPrincipal() {
        return principal;
    }

    public String getProsperRating() {
        return prosperRating;
    }

    public void setPercentage(final Double percentage) {
        this.percentage = percentage;
    }

    public void setPrincipal(final Double principal) {
        this.principal = principal;
    }

    public void setProsperRating(final String prosperRating) {
        this.prosperRating = prosperRating;
    }

}
