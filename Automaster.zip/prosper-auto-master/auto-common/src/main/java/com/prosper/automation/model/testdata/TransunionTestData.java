
package com.prosper.automation.model.testdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.exception.AutomationException;

import org.apache.commons.csv.CSVRecord;

import java.io.Serializable;
import java.sql.Date;
import java.util.UUID;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public final class TransunionTestData implements Serializable {

    @JsonProperty("test_id")
    private UUID testID;
    @JsonProperty("test_description")
    private String testDescription;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("prefix")
    private String prefix;
    @JsonProperty("suffix")
    private String suffix;
    @JsonProperty("house_number")
    private String houseNumber;
    @JsonProperty("direction")
    private String direction;
    @JsonProperty("street_name")
    private String streetName;
    @JsonProperty("post_dir")
    private String postDir;
    @JsonProperty("street_type")
    private String streetType;
    @JsonProperty("apartment_number")
    private String apartmentNumber;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip_code")
    private String zipCode;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("fico_score_8")
    private Integer ficoScore8;
    @JsonProperty("fico_auto_score_8")
    private Integer ficoAutoScore8;
    @JsonProperty("fico_score_4")
    private Integer ficoScore4;
    @JsonProperty("fico_auto_score_4")
    private Integer ficoAutoScore4;
    @JsonProperty("vantage_score")
    private Integer vantageScore;
    @JsonProperty("vantage_score_2")
    private Integer vantageScore2;
    @JsonProperty("fico_insurance_score_pg2")
    private Integer ficoInsuranceScorePG2;
    @JsonProperty("fico_insurance_score_h32")
    private Integer ficoInsuranceScoreH32;
    @JsonProperty("tuirs_property")
    private Integer tuirsProperty;
    @JsonProperty("tuirs_auto")
    private Integer tuirsAuto;
    @JsonProperty("tuirs_auto_property_score")
    private Integer tuirsAutoPropertyScore;
    @JsonProperty("total_number_of_accounts")
    private Integer totalNumberOfAccounts;
    @JsonProperty("total_number_of_bankcard_accounts")
    private Integer totalNumberOfBankcardAccounts;
    @JsonProperty("total_number_of_revolving_accounts")
    private Integer totalNumberOfRevolvingAccounts;
    @JsonProperty("total_number_of_installment_accounts")
    private Integer totalNumberOfInstallmentAccounts;
    @JsonProperty("total_number_of_mortgage_accounts")
    private Integer totalNumberOfMortgageAccounts;
    @JsonProperty("total_number_of_bankruptcy_public_records")
    private Integer totalNumberOfBankruptcyPublicRecords;
    @JsonProperty("total_number_of_public_records")
    private Integer totalNumberOfPublicRecords;
    @JsonProperty("created_at")
    private Date createdAt;
    @JsonProperty("updated_at")
    private Date updatedAt;


    public TransunionTestData() {
    }

    private TransunionTestData(Builder builder) {
        setTestID(builder.testID);
        setTestDescription(builder.testDescription);
        setFirstName(builder.firstName);
        setMiddleName(builder.middleName);
        setLastName(builder.lastName);
        setPrefix(builder.prefix);
        setSuffix(builder.suffix);
        setHouseNumber(builder.houseNumber);
        setDirection(builder.direction);
        setStreetName(builder.streetName);
        setPostDir(builder.postDir);
        setStreetType(builder.streetType);
        setApartmentNumber(builder.apartmentNumber);
        setCity(builder.city);
        setState(builder.state);
        setZipCode(builder.zipCode);
        setSsn(builder.ssn);
        setFicoScore8(builder.ficoScore8);
        setFicoAutoScore8(builder.ficoAutoScore8);
        setFicoScore4(builder.ficoScore4);
        setFicoAutoScore4(builder.ficoAutoScore4);
        setVantageScore(builder.vantageScore);
        setVantageScore2(builder.vantageScore2);
        setFicoInsuranceScorePG2(builder.ficoInsuranceScorePG2);
        setFicoInsuranceScoreH32(builder.ficoInsuranceScoreH32);
        setTuirsProperty(builder.tuirsProperty);
        setTuirsAuto(builder.tuirsAuto);
        setTuirsAutoPropertyScore(builder.tuirsAutoPropertyScore);
        setTotalNumberOfAccounts(builder.totalNumberOfAccounts);
        setTotalNumberOfBankcardAccounts(builder.totalNumberOfBankcardAccounts);
        setTotalNumberOfRevolvingAccounts(builder.totalNumberOfRevolvingAccounts);
        setTotalNumberOfInstallmentAccounts(builder.totalNumberOfInstallmentAccounts);
        setTotalNumberOfMortgageAccounts(builder.totalNumberOfMortgageAccounts);
        setTotalNumberOfBankruptcyPublicRecords(builder.totalNumberOfBankruptcyPublicRecords);
        setTotalNumberOfPublicRecords(builder.totalNumberOfPublicRecords);
        setCreatedAt(builder.createdAt);
        setUpdatedAt(builder.updatedAt);
    }

    @JsonIgnore
    public UUID getTestID() {
        return testID;
    }

    public void setTestID(UUID testID) {
        this.testID = testID;
    }

    @JsonIgnore
    public String getTestDescription() {
        return testDescription;
    }

    public void setTestDescription(String testDescription) {
        this.testDescription = testDescription;
    }

    @JsonIgnore
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonIgnore
    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonIgnore
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonIgnore
    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    @JsonIgnore
    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    @JsonIgnore
    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    @JsonIgnore
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    @JsonIgnore
    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @JsonIgnore
    public String getPostDir() {
        return postDir;
    }

    public void setPostDir(String postDir) {
        this.postDir = postDir;
    }

    @JsonIgnore
    public String getStreetType() {
        return streetType;
    }

    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }

    @JsonIgnore
    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    @JsonIgnore
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @JsonIgnore
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @JsonIgnore
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @JsonIgnore
    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    @JsonIgnore
    public Integer getFicoScore8() {
        return ficoScore8;
    }

    public void setFicoScore8(Integer ficoScore8) {
        this.ficoScore8 = ficoScore8;
    }

    @JsonIgnore
    public Integer getFicoAutoScore8() {
        return ficoAutoScore8;
    }

    public void setFicoAutoScore8(Integer ficoAutoScore8) {
        this.ficoAutoScore8 = ficoAutoScore8;
    }

    @JsonIgnore
    public Integer getFicoScore4() {
        return ficoScore4;
    }

    public void setFicoScore4(Integer ficoScore4) {
        this.ficoScore4 = ficoScore4;
    }

    @JsonIgnore
    public Integer getFicoAutoScore4() {
        return ficoAutoScore4;
    }

    public void setFicoAutoScore4(Integer ficoAutoScore4) {
        this.ficoAutoScore4 = ficoAutoScore4;
    }

    @JsonIgnore
    public Integer getVantageScore() {
        return vantageScore;
    }

    public void setVantageScore(Integer vantageScore) {
        this.vantageScore = vantageScore;
    }

    @JsonIgnore
    public Integer getVantageScore2() {
        return vantageScore2;
    }

    public void setVantageScore2(Integer vantageScore2) {
        this.vantageScore2 = vantageScore2;
    }

    @JsonIgnore
    public Integer getFicoInsuranceScorePG2() {
        return ficoInsuranceScorePG2;
    }

    public void setFicoInsuranceScorePG2(Integer ficoInsuranceScorePG2) {
        this.ficoInsuranceScorePG2 = ficoInsuranceScorePG2;
    }

    @JsonIgnore
    public Integer getFicoInsuranceScoreH32() {
        return ficoInsuranceScoreH32;
    }

    public void setFicoInsuranceScoreH32(Integer ficoInsuranceScoreH32) {
        this.ficoInsuranceScoreH32 = ficoInsuranceScoreH32;
    }

    @JsonIgnore
    public Integer getTuirsProperty() {
        return tuirsProperty;
    }

    public void setTuirsProperty(Integer tuirsProperty) {
        this.tuirsProperty = tuirsProperty;
    }

    @JsonIgnore
    public Integer getTuirsAuto() {
        return tuirsAuto;
    }

    public void setTuirsAuto(Integer tuirsAuto) {
        this.tuirsAuto = tuirsAuto;
    }

    @JsonIgnore
    public Integer getTuirsAutoPropertyScore() {
        return tuirsAutoPropertyScore;
    }

    public void setTuirsAutoPropertyScore(Integer tuirsAutoPropertyScore) {
        this.tuirsAutoPropertyScore = tuirsAutoPropertyScore;
    }

    @JsonIgnore
    public Integer getTotalNumberOfAccounts() {
        return totalNumberOfAccounts;
    }

    public void setTotalNumberOfAccounts(Integer totalNumberOfAccounts) {
        this.totalNumberOfAccounts = totalNumberOfAccounts;
    }

    @JsonIgnore
    public Integer getTotalNumberOfBankcardAccounts() {
        return totalNumberOfBankcardAccounts;
    }

    public void setTotalNumberOfBankcardAccounts(Integer totalNumberOfBankcardAccounts) {
        this.totalNumberOfBankcardAccounts = totalNumberOfBankcardAccounts;
    }

    @JsonIgnore
    public Integer getTotalNumberOfRevolvingAccounts() {
        return totalNumberOfRevolvingAccounts;
    }

    public void setTotalNumberOfRevolvingAccounts(Integer totalNumberOfRevolvingAccounts) {
        this.totalNumberOfRevolvingAccounts = totalNumberOfRevolvingAccounts;
    }

    @JsonIgnore
    public Integer getTotalNumberOfInstallmentAccounts() {
        return totalNumberOfInstallmentAccounts;
    }

    public void setTotalNumberOfInstallmentAccounts(Integer totalNumberOfInstallmentAccounts) {
        this.totalNumberOfInstallmentAccounts = totalNumberOfInstallmentAccounts;
    }

    @JsonIgnore
    public Integer getTotalNumberOfMortgageAccounts() {
        return totalNumberOfMortgageAccounts;
    }

    public void setTotalNumberOfMortgageAccounts(Integer totalNumberOfMortgageAccounts) {
        this.totalNumberOfMortgageAccounts = totalNumberOfMortgageAccounts;
    }

    @JsonIgnore
    public Integer getTotalNumberOfBankruptcyPublicRecords() {
        return totalNumberOfBankruptcyPublicRecords;
    }

    public void setTotalNumberOfBankruptcyPublicRecords(Integer totalNumberOfBankruptcyPublicRecords) {
        this.totalNumberOfBankruptcyPublicRecords = totalNumberOfBankruptcyPublicRecords;
    }

    @JsonIgnore
    public Integer getTotalNumberOfPublicRecords() {
        return totalNumberOfPublicRecords;
    }

    public void setTotalNumberOfPublicRecords(Integer totalNumberOfPublicRecords) {
        this.totalNumberOfPublicRecords = totalNumberOfPublicRecords;
    }

    @JsonIgnore
    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @JsonIgnore
    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }


    public static final class Mapper {

        public static TransunionTestData map(final CSVRecord transunionUser) throws AutomationException {
            return new Builder()
                    .withLastName(transunionUser.get("Last Name"))
                    .withFirstName(transunionUser.get("First Name"))
                    .withMiddleName(transunionUser.get("Middle Name"))
                    .withPrefix(transunionUser.get("Prefix"))
                    .withSuffix(transunionUser.get("Suffix"))
                    .withHouseNumber(transunionUser.get("House#"))
                    .withDirection(transunionUser.get("Direction"))
                    .withStreetName(transunionUser.get("Street Name"))
                    .withApartmentNumber(transunionUser.get("Apt#"))
                    .withCity(transunionUser.get("City"))
                    .withState(transunionUser.get("State"))
                    .withZipCode(transunionUser.get("Zip Code"))
                    .withSsn(transunionUser.get("SSN"))
                    .withFicoScore8(parseInt(transunionUser.get("FICO Score 8 (00Q88)")))
                    .withFicoAutoScore8(parseInt(transunionUser.get("FICO  Auto Score 8 (00N20)")))
                    .withFicoScore4(parseInt(transunionUser.get("FICO Score 4 (00P02)")))
                    .withFicoAutoScore4(parseInt(transunionUser.get("FICO  Auto Score 4 (00P12)")))
                    .withVantageScore(parseInt(transunionUser.get("VantageScore (00P94)")))
                    .withVantageScore2(parseInt(transunionUser.get("VantageScore 2 (00N94)")))
                    .withFicoInsuranceScorePG2(parseInt(transunionUser.get("FICO Insurance Score PG 2.0 (00872)")))
                    .withFicoInsuranceScoreH32(parseInt(transunionUser.get("FICO Insurance Score H3 2.0 (00877)")))
                    .withTuirsProperty(parseInt(transunionUser.get("TUIRS Property (00R95)")))
                    .withTuirsAuto(parseInt(transunionUser.get("TUIRS Auto (00R96)")))
                    .withTuirsAutoPropertyScore(parseInt(transunionUser.get("TUIRS Auto Property Score (00R99)")))
                    .withTotalNumberOfAccounts(parseInt(transunionUser.get("Total # of Accounts")))
                    .withTotalNumberOfBankcardAccounts(parseInt(transunionUser.get("Total # of Bankcard Accounts")))
                    .withTotalNumberOfRevolvingAccounts(parseInt(transunionUser.get("Total # of Revolving Accounts")))
                    .withTotalNumberOfInstallmentAccounts(
                            parseInt(transunionUser.get("Total # of Installment Accounts")))
                    .withTotalNumberOfMortgageAccounts(parseInt(transunionUser.get("Total # of Mortgage Accounts")))
                    .withTotalNumberOfBankruptcyPublicRecords(parseInt("Total # of Bankruptcy Public Records"))
                    .withTotalNumberOfPublicRecords(parseInt(transunionUser.get("Total # of Public Records")))
                    .build();
        }

        private static Integer parseInt(final String stringInteger) {
            try {
                return Integer.valueOf(stringInteger);
            } catch (NumberFormatException nfe) {
                return null;
            }
        }

    }

    public static final class Builder {

        private UUID testID;
        private String testDescription;
        private String firstName;
        private String middleName;
        private String lastName;
        private String prefix;
        private String suffix;
        private String houseNumber;
        private String direction;
        private String streetName;
        private String postDir;
        private String streetType;
        private String apartmentNumber;
        private String city;
        private String state;
        private String zipCode;
        private String ssn;
        private Integer ficoScore8;
        private Integer ficoAutoScore8;
        private Integer ficoScore4;
        private Integer ficoAutoScore4;
        private Integer vantageScore;
        private Integer vantageScore2;
        private Integer ficoInsuranceScorePG2;
        private Integer ficoInsuranceScoreH32;
        private Integer tuirsProperty;
        private Integer tuirsAuto;
        private Integer tuirsAutoPropertyScore;
        private Integer totalNumberOfAccounts;
        private Integer totalNumberOfBankcardAccounts;
        private Integer totalNumberOfRevolvingAccounts;
        private Integer totalNumberOfInstallmentAccounts;
        private Integer totalNumberOfMortgageAccounts;
        private Integer totalNumberOfBankruptcyPublicRecords;
        private Integer totalNumberOfPublicRecords;
        private Date createdAt;
        private Date updatedAt;


        public Builder() {
        }

        public Builder withTestID(UUID val) {
            testID = val;
            return this;
        }

        public Builder withTestDescription(String val) {
            testDescription = val;
            return this;
        }

        public Builder withFirstName(String val) {
            firstName = val;
            return this;
        }

        public Builder withMiddleName(String val) {
            middleName = val;
            return this;
        }

        public Builder withLastName(String val) {
            lastName = val;
            return this;
        }

        public Builder withPrefix(String val) {
            prefix = val;
            return this;
        }

        public Builder withSuffix(String val) {
            suffix = val;
            return this;
        }

        public Builder withHouseNumber(String val) {
            houseNumber = val;
            return this;
        }

        public Builder withDirection(String val) {
            direction = val;
            return this;
        }

        public Builder withStreetName(String val) {
            streetName = val;
            return this;
        }

        public Builder withPostDir(String val) {
            postDir = val;
            return this;
        }

        public Builder withStreetType(String val) {
            streetType = val;
            return this;
        }

        public Builder withApartmentNumber(String val) {
            apartmentNumber = val;
            return this;
        }

        public Builder withCity(String val) {
            city = val;
            return this;
        }

        public Builder withState(String val) {
            state = val;
            return this;
        }

        public Builder withZipCode(String val) {
            zipCode = val;
            return this;
        }

        public Builder withSsn(String val) {
            ssn = val;
            return this;
        }

        public Builder withFicoScore8(Integer val) {
            ficoScore8 = val;
            return this;
        }

        public Builder withFicoAutoScore8(Integer val) {
            ficoAutoScore8 = val;
            return this;
        }

        public Builder withFicoScore4(Integer val) {
            ficoScore4 = val;
            return this;
        }

        public Builder withFicoAutoScore4(Integer val) {
            ficoAutoScore4 = val;
            return this;
        }

        public Builder withVantageScore(Integer val) {
            vantageScore = val;
            return this;
        }

        public Builder withVantageScore2(Integer val) {
            vantageScore2 = val;
            return this;
        }

        public Builder withFicoInsuranceScorePG2(Integer val) {
            ficoInsuranceScorePG2 = val;
            return this;
        }

        public Builder withFicoInsuranceScoreH32(Integer val) {
            ficoInsuranceScoreH32 = val;
            return this;
        }

        public Builder withTuirsProperty(Integer val) {
            tuirsProperty = val;
            return this;
        }

        public Builder withTuirsAuto(Integer val) {
            tuirsAuto = val;
            return this;
        }

        public Builder withTuirsAutoPropertyScore(Integer val) {
            tuirsAutoPropertyScore = val;
            return this;
        }

        public Builder withTotalNumberOfAccounts(Integer val) {
            totalNumberOfAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfBankcardAccounts(Integer val) {
            totalNumberOfBankcardAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfRevolvingAccounts(Integer val) {
            totalNumberOfRevolvingAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfInstallmentAccounts(Integer val) {
            totalNumberOfInstallmentAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfMortgageAccounts(Integer val) {
            totalNumberOfMortgageAccounts = val;
            return this;
        }

        public Builder withTotalNumberOfBankruptcyPublicRecords(Integer val) {
            totalNumberOfBankruptcyPublicRecords = val;
            return this;
        }

        public Builder withTotalNumberOfPublicRecords(Integer val) {
            totalNumberOfPublicRecords = val;
            return this;
        }

        public Builder withCreatedAt(Date val) {
            createdAt = val;
            return this;
        }

        public Builder withUpdatedAt(Date val) {
            updatedAt = val;
            return this;
        }

        public TransunionTestData build() {
            return new TransunionTestData(this);
        }
    }
}
