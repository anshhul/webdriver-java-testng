package com.prosper.automation.model.platform.bankValidation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public final class BankAccount {
    @JsonProperty("AccountID")
    private Long accountId;
    @JsonProperty("AccountName")
    private String accountName;
    @JsonProperty("AccountHolder")
    private String accountHolder;
    @JsonProperty("AccountType")
    private String accountType;
    @JsonProperty("AccountNumber")
    private String accountNumber;
    @JsonProperty("RoutingNumber")
    private String routingNumber;
    @JsonProperty("Balance")
    private Double balance;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
}
