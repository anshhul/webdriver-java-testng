
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SlpOfferDetails {
    
    @JsonProperty("offer_id")
    private String offerID;
    
    @JsonProperty("offer_date")
    private String offerDate;
    
    @JsonProperty("offer_expiration_date")
    private String offerExpirationDate;

    @JsonProperty("total_principal_balance")
    private double totalPrincipalBalance;

    @JsonProperty("total_dirty_price")
    private double totalDirtyPrice;

    @JsonProperty("total_fees")
    private Double totalFee;
    
    @JsonProperty("total_wire_amount")
    private double totalWireAmount;

    @JsonProperty("purchase_date")
    private String purchaseDate;

    @JsonProperty("purchase_id")
    private String purchaseID;

    @JsonProperty("offer_status")
    private String offerStatus;
    
    
    public String getOfferDate() {
        return offerDate;
    }
    
    public String getOfferExpirationDate() {
        return offerExpirationDate;
    }
    
    public String getOfferID() {
        return offerID;
    }
    
    public String getOfferStatus() {
        return offerStatus;
    }
    
    public String getPurchaseDate() {
        return purchaseDate;
    }
    
    public String getPurchaseID() {
        return purchaseID;
    }
    
    public double getTotalDirtyPrice() {
        return totalDirtyPrice;
    }
    
    public Double getTotalFee() {
        return totalFee;
    }
    
    public double getTotalPrincipalBalance() {
        return totalPrincipalBalance;
    }
    
    public double getTotalWireAmount() {
        return totalWireAmount;
    }
    
    public void setOfferDate(final String offerDate) {
        this.offerDate = offerDate;
    }
    
    public void setOfferExpirationDate(final String offerExpirationDate) {
        this.offerExpirationDate = offerExpirationDate;
    }
    
    public void setOfferID(final String offerID) {
        this.offerID = offerID;
    }
    
    public void setOfferStatus(final String offerStatus) {
        this.offerStatus = offerStatus;
    }
    
    public void setPurchaseDate(final String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }
    
    public void setPurchaseID(final String purchaseID) {
        this.purchaseID = purchaseID;
    }
    
    public void setTotalDirtyPrice(final double totalDirtyPrice) {
        this.totalDirtyPrice = totalDirtyPrice;
    }
    
    public void setTotalFee(final Double totalFee) {
        this.totalFee = totalFee;
    }
    
    public void setTotalPrincipalBalance(final double totalPrincipalBalance) {
        this.totalPrincipalBalance = totalPrincipalBalance;
    }
    
    public void setTotalWireAmount(final double totalWireAmount) {
        this.totalWireAmount = totalWireAmount;
    }
    
}
