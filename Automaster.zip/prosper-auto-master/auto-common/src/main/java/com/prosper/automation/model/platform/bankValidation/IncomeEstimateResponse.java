
package com.prosper.automation.model.platform.bankValidation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class IncomeEstimateResponse {
    
    @JsonProperty("bankId")
    private Object bankId;
    @JsonProperty("userId")
    private Integer userId;
    @JsonProperty("transactionCount")
    private Integer transactionCount;
    @JsonProperty("transactionDays")
    private Integer transactionDays;
    @JsonProperty("incomeSources")
    private List<IncomeSource> incomeSources = new ArrayList<IncomeSource>();
    @JsonProperty("transactionDateRange")
    private Integer transactionDateRange;
    @JsonProperty("bvsaccountNumber")
    private String bvsaccountNumber;
    @JsonProperty("bvsaccountNumberStatus")
    private Object bvsaccountNumberStatus;
    @JsonProperty("bvsroutingNumber")
    private String bvsroutingNumber;
    @JsonProperty("bvsroutingNumberStatus")
    private String bvsroutingNumberStatus;
    @JsonProperty("bvsfirstName")
    private String bvsfirstName;
    @JsonProperty("bvslastName")
    private String bvslastName;
    
    
    /**
     *
     * @return The bankId
     */
    @JsonProperty("bankId")
    public Object getBankId() {
        return bankId;
    }
    
    /**
     *
     * @return The userId
     */
    @JsonProperty("userId")
    public Integer getUserId() {
        return userId;
    }
    
    /**
     *
     * @return The transactionCount
     */
    @JsonProperty("transactionCount")
    public Integer getTransactionCount() {
        return transactionCount;
    }
    
    /**
     *
     * @return The transactionDays
     */
    @JsonProperty("transactionDays")
    public Integer getTransactionDays() {
        return transactionDays;
    }
    
    /**
     *
     * @return The incomeSources
     */
    @JsonProperty("incomeSources")
    public List<IncomeSource> getIncomeSources() {
        return incomeSources;
    }
    
    /**
     *
     * @return The transactionDateRange
     */
    @JsonProperty("transactionDateRange")
    public Integer getTransactionDateRange() {
        return transactionDateRange;
    }
    
    /**
     *
     * @return The bvsaccountNumber
     */
    @JsonProperty("bvsaccountNumber")
    public String getBvsaccountNumber() {
        return bvsaccountNumber;
    }
    
    /**
     *
     * @return The bvsaccountNumberStatus
     */
    @JsonProperty("bvsaccountNumberStatus")
    public Object getBvsaccountNumberStatus() {
        return bvsaccountNumberStatus;
    }
    
    /**
     *
     * @return The bvsroutingNumber
     */
    @JsonProperty("bvsroutingNumber")
    public String getBvsroutingNumber() {
        return bvsroutingNumber;
    }
    
    /**
     *
     * @return The bvsroutingNumberStatus
     */
    @JsonProperty("bvsroutingNumberStatus")
    public String getBvsroutingNumberStatus() {
        return bvsroutingNumberStatus;
    }
    
    /**
     *
     * @return The bvsfirstName
     */
    @JsonProperty("bvsfirstName")
    public String getBvsfirstName() {
        return bvsfirstName;
    }
    
    /**
     *
     * @return The bvslastName
     */
    @JsonProperty("bvslastName")
    public String getBvslastName() {
        return bvslastName;
    }
    
}
