
package com.prosper.automation.enumeration.platform;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum UserStatus {
    DUPLICATE, ACTIVE, INACTIVE;
}
