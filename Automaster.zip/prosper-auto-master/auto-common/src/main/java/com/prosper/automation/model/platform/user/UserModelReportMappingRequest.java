package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 * Created by rchintapalli on 12/06/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserModelReportMappingRequest {

    @JsonProperty("external_model_report_id")
    private UUID externalModelReportId;
    @JsonProperty("external_credit_report_id")
    private UUID externalCreditReportId;

    public UUID getExternalModelReportId() {
        return externalModelReportId;
    }

    public void setExternalModelReportId(UUID externalModelReportId) {
        this.externalModelReportId = externalModelReportId;
    }

    public UUID getExternalCreditReportId() {
        return externalCreditReportId;
    }

    public void setExternalCreditReportId(UUID externalCreditReportId) {
        this.externalCreditReportId = externalCreditReportId;
    }

    public UserModelReportMappingRequest(Builder builder){
        setExternalModelReportId(builder.externalModelReportId);
        setExternalCreditReportId(builder.externalCreditReportId);
    }

    public static final class Builder {
        private UUID externalModelReportId;
        private UUID externalCreditReportId;

        public Builder(){
        }

        public Builder withExternalModelReportId(UUID val){
            this.externalModelReportId =val;
            return this;
        }

        public Builder withExternalCreditReportId(UUID val){
            this.externalCreditReportId = val;
            return this;
        }

        public UserModelReportMappingRequest build() {
            return new UserModelReportMappingRequest(this);
        }
    }
}
