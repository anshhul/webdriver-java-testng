
package com.prosper.automation.model.platform.pmiAttributes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.pricing.ExperianUserCredit;
import com.prosper.automation.model.platform.pricing.UserLoanAttributes;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CalculatedPMIAttributesRequest {
    
    @JsonProperty("user")
    private User user;
    @JsonProperty("experian_user_credit")
    private ExperianUserCredit experianUserCredit;
    @JsonProperty("user_loan_attributes")
    private UserLoanAttributes userLoanAttributes;
    
    
    private CalculatedPMIAttributesRequest(final Builder builder) {
        user = builder.user;
        experianUserCredit = builder.experianUserCredit;
        userLoanAttributes = builder.userLoanAttributes;
    }
    
    
    public static final class Builder {
        
        private User user;
        private ExperianUserCredit experianUserCredit;
        private UserLoanAttributes userLoanAttributes;
        
        
        public Builder() {
        }
        
        public Builder withUser(final User user) {
            this.user = user;
            return this;
        }
        
        public Builder withExperianUserCredit(final ExperianUserCredit experianUserCredit) {
            this.experianUserCredit = experianUserCredit;
            return this;
        }
        
        public Builder withUserLoanAttributes(final UserLoanAttributes userLoanAttributes) {
            this.userLoanAttributes = userLoanAttributes;
            return this;
        }
        
        public CalculatedPMIAttributesRequest build() {
            return new CalculatedPMIAttributesRequest(this);
        }
    }
}
