
package com.prosper.automation.model.testdata;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class TUTestUser {

    private TUUserAddress tuUserAddress;
    private TUUserInformation tuUserInformation;
    private TUUserCreditProfile tuUserCreditProfile;


    private TUTestUser(Builder builder) {
        setTuUserAddress(builder.tuUserAddress);
        setTuUserInformation(builder.tuUserInformation);
        setTuUserCreditProfile(builder.tuUserCreditProfile);
    }

    public TUUserAddress getTuUserAddress() {
        return tuUserAddress;
    }

    public void setTuUserAddress(TUUserAddress tuUserAddress) {
        this.tuUserAddress = tuUserAddress;
    }

    public TUUserInformation getTuUserInformation() {
        return tuUserInformation;
    }

    public void setTuUserInformation(TUUserInformation tuUserInformation) {
        this.tuUserInformation = tuUserInformation;
    }

    public TUUserCreditProfile getTuUserCreditProfile() {
        return tuUserCreditProfile;
    }

    public void setTuUserCreditProfile(TUUserCreditProfile tuUserCreditProfile) {
        this.tuUserCreditProfile = tuUserCreditProfile;
    }


    public static final class Builder {

        private TUUserAddress tuUserAddress;
        private TUUserInformation tuUserInformation;
        private TUUserCreditProfile tuUserCreditProfile;


        public Builder() {
        }

        public Builder withTuUserAddress(TUUserAddress val) {
            tuUserAddress = val;
            return this;
        }

        public Builder withTuUserInformation(TUUserInformation val) {
            tuUserInformation = val;
            return this;
        }

        public Builder withTuUserCreditProfile(TUUserCreditProfile val) {
            tuUserCreditProfile = val;
            return this;
        }

        public TUTestUser build() {
            return new TUTestUser(this);
        }
    }
}
