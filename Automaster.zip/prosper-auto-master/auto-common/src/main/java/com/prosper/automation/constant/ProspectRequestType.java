
package com.prosper.automation.constant;

/**
 * Created by rsubramanyam on 5/3/16.
 */
public enum ProspectRequestType {

    OFFER_CODE("OFFER_CODE");

    private String type;

    ProspectRequestType(String type) {
        this.type = type;
    }
}
