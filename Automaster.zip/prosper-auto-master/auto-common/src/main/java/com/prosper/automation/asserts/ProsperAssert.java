
package com.prosper.automation.asserts;

import com.google.common.collect.Ordering;
import com.prosper.automation.enumeration.SortOrder;

import org.testng.Assert;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author Prateek
 */
public class ProsperAssert extends Assert {

    private static final String ERROR_MESSAGE = "Object class do not match.";


    /**
     *
     * @param actual
     * @param expected
     */
    public static void assertResponseEquals(final List<?> actual, final List<?> expected) {
        if (actual == expected) {
            return;
        } else if (actual.getClass() != expected.getClass()) {
            fail(ERROR_MESSAGE);
        } else {
            assertEquals(actual, expected);
        }
    }

    public static void assertEquals(final String actual, final String expected, final boolean isCaseSensitive) {
        if (isCaseSensitive) {
            Assert.assertEquals(actual, expected);
        } else {
            Assert.assertEquals(actual.toLowerCase(), expected.toLowerCase());
        }
    }

    public static <T extends Collection> void assertIsSorted(final T collection, final SortOrder sortOrder) {
        if (sortOrder == SortOrder.ASC) {
            Assert.assertTrue(Ordering.natural().isOrdered(collection));
        } else if (sortOrder == SortOrder.DESC) {
            Assert.assertTrue(Ordering.natural().reverse().isOrdered(collection));
        } else {
            Assert.fail("No assertion occurs.");
        }
    }

    public static void assertTimestampWithinRange(final Timestamp actualTimeStamp, final int deltaInMillisecond) {
        final long actualDelta = Math.abs(new Date().getTime() - actualTimeStamp.getTime());
        Assert.assertTrue(actualDelta < (deltaInMillisecond * 1000000), String.format("%d", actualDelta));
    }

    public static <T extends Object> void assertListIsNotEmpty(final List<T> list) {
        Assert.assertNotNull(list, "List is null.");
        Assert.assertFalse(list.isEmpty(), "List is empty.");
    }

    public static void assertCountGreaterThanZero(final int transactionCount) {
        Assert.assertTrue(transactionCount > 0, "Count is not greater than zero.");
    }

    public static <T> void assertListContains(final List<T> list, final T expectedObject) {
        Assert.assertTrue(list.contains(expectedObject));
    }
}
