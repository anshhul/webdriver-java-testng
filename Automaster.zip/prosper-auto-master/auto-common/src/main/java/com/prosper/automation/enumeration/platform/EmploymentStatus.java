
package com.prosper.automation.enumeration.platform;

/**
 * An enumeration for employment status type.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum EmploymentStatus {

    NOT_AVAILABLE(0, "Not available"),
    FULL_TIME(1, "Full-time"),
    PART_TIME(2, "Part-time"),
    SELF_EMPLOYED(3, "Self-employed"),
    RETIRED(4, "Retired"),
    NOT_EMPLOYED(5, "Not employed"),
    OTHER(6, "Other"),
    EMPLOYED(7, "Employed");

    private int id;
    private String description;


    EmploymentStatus(final int id, final String description) {
        this.id = id;
        this.description = description;
    }

    public String getId() {
        return String.valueOf(id);
    }

    public String getDescription() {
        return description;
    }
}
