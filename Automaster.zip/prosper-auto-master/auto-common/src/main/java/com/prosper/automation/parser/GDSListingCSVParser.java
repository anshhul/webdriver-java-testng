
package com.prosper.automation.parser;

import com.google.common.collect.Lists;
import com.prosper.automation.exception.AutomationException;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class GDSListingCSVParser {

    private static final String LISTING_ID_HEADER_NAME = "listingid";


    private GDSListingCSVParser() {
    }

    public static List<String> parse(final String filepath) throws AutomationException {
        try (final FileInputStream fileInputStream = new FileInputStream(filepath);
                final Reader reader = new InputStreamReader(fileInputStream);
                final CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader())) {
            final List<CSVRecord> records = parser.getRecords();

            final List<String> lines = Lists.newArrayList();
            for (int i = 0; i < records.size(); i++) {
                lines.add(records.get(i).get(LISTING_ID_HEADER_NAME));
            }
            return lines;
        } catch (final IOException e) {
            throw new AutomationException(e.getMessage());
        }
    }
}
