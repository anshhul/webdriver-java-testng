
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SlpInvestorConfig {

    @JsonProperty("slp_investor_config_id")
    private long slpInvestorConfigId;

    @JsonProperty("created_by")
    private Integer createdBy;

    @JsonProperty("user_id")
    private Long userId;

    @JsonProperty("is_active")
    private boolean isActive;

    @JsonProperty("monthly_investment_target")
    private Double monthlyInvestmentTarget;

    @JsonProperty("fee_percentage")
    private Double feePercentage;

    @JsonProperty("created_date")
    private String createdDate;

    @JsonProperty("modified_by")
    private Integer modifiedBy;

    @JsonProperty("modified_date")
    private String modifiedDate;
    
    
    public Integer getCreatedBy() {
        return createdBy;
    }
    
    public String getCreatedDate() {
        return createdDate;
    }
    
    public Double getFeePercentage() {
        return feePercentage;
    }
    
    public Integer getModifiedBy() {
        return modifiedBy;
    }
    
    public String getModifiedDate() {
        return modifiedDate;
    }

    public Double getMonthlyInvestmentTarget() {
        return monthlyInvestmentTarget;
    }

    public long getSlpInvestorConfigId() {
        return slpInvestorConfigId;
    }

    public Long getUserId() {
        return userId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(final boolean isActive) {
        this.isActive = isActive;
    }

    public void setCreatedBy(final Integer createdBy) {
        this.createdBy = createdBy;
    }

    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }

    public void setFeePercentage(final Double feePercentage) {
        this.feePercentage = feePercentage;
    }

    public void setModifiedBy(final Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public void setModifiedDate(final String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public void setMonthlyInvestmentTarget(final Double monthlyInvestmentTarget) {
        this.monthlyInvestmentTarget = monthlyInvestmentTarget;
    }

    public void setSlpInvestorConfigId(final long slpInvestorConfigId) {
        this.slpInvestorConfigId = slpInvestorConfigId;
    }

    public void setUserId(final Long userId) {
        this.userId = userId;
    }

}
