
package com.prosper.automation.constant.web;

/**
 * Created by rsubramanyam on 5/11/16.
 */
public class RegistrationPageMessageConstants {

    public static final Double LOAN_AMOUNT = 5000.0;
    public static final String LOAN_PURPOSE_BUSINESS = "Business";
    public static final String LOAN_PURPOSE_DEBT_CONSOLIDATION = "Debt Consolidation";
    public static final String OTHER_LOAN_PURPOSE = "Other";
    public static final String OTHER_LOAN_PURPOSE_MESSAGE_TEXT =
            "No part of your loan proceeds can be used for post-secondary educational expenses (i.e., tuition, fees, required equipment or supplies, or room and board) at a college/university/vocational school. Learn more.";
    public static final String LOAN_PURPOSE_MESSAGE_TEXT =
            "A loan through Prosper for small businesses is considered a personal loan for business expenses. Individual borrowers will be personally liable for the debt and loans are not related to or guaranteed by the Small Business Administration.";
    public static final String INVALID_NAME = "Please remove any numbers or special characters.";
    public static final String EMAIL_ADDRESS_INVALID = "Please provide a valid email address. (Ex: hello@prosper.com)";
    public static final String LOAN_AMOUNT_INVALID = "Please enter an amount between $2,000 and $35,000.";
    public static final String ZIP_CODE_NOT_ALLOWED_BY_PROSPER = "Loans through Prosper are not available in your area.";
    public static final String ZIP_CODE_ALLOWED_BY_PROSPER = "Yeah! Loans through Prosper are available in your area";
    public static final String UNIDENTIFIED_ZIPCODE = "Hmm, we don't recognize that ZIP code. Please enter a valid one.";
    public static final String ZIP_CODE_TOOLTIP = "Please fill out this field";
    public static final String CREDIT_QUALITY = "Excellent Credit (760+)";
    public static final String ZIP_CODE_INVALID = "Please enter your 5 or 9-digit ZIP code";
    public static final String LOAN_AMOUNT_TEXT = "Tell Us About Your Loan";
    public static final String LOCK_IN_RATE_MESSAGE = "Lock In Your Rate For 30 Days";
    public static final String CUSTOM_RATE_MESSAGE_TEXT =
            "To provide you with a custom rate, we'll run a soft credit pull. This will not affect your credit score.";
    public static final String USER_NOTICE_NO_EFFECT_ON_CREDIT_SCORE = "Checking your rate will not affect your credit score.";
    public static final String PROSPER_DAILY = "Prosper Daily";
    public static final String HIW_CHECK_RATE = "Check your rate";
    public static final String HIW_CHECK_RATE_SUMMARY = "Answer a few questions and get your lowest eligible rate in minutes.";
    public static final String HIW_CHOOSE_YOUR_TERM = "Choose your term";
    public static final String HIW_CHOOSE_YOUR_TERM_SUMMARY = "Get a fixed term for 3 or 5 years*. No hidden fees, early payment penalties or tricky fine print.";
    public static final String HIW_GET_YOUR_FUNDS = "Get your funds";
    public static final String HIW_GET_YOUR_FUNDS_SUMMARY = "Your money goes straight to your bank account via direct deposit.";
    public static final String DOB_MESSAGE_IDENTIFIER = "18 years old";
    public static final String INCORRECT_PASSWORD_ERROR_MESSAGE =
            "Password must be at least 8 characters and contain 1 number, 1 uppercase letter, 1 lowercase letter and 1 symbol.";
}
