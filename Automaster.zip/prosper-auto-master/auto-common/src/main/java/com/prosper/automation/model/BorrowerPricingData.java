
package com.prosper.automation.model;

import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.exception.AutomationException;
import org.apache.commons.csv.CSVRecord;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.util.Date;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class BorrowerPricingData {

    private Integer cateBin;
    private Integer at34B_Rand;
    private Integer utlBin;
    private Integer pmi9PctBin;
    private Integer re27sRand;
    private String thirdPartyIdRand;
    private Integer useridRand;
    private Double  g066sRand;
    private Integer fraBin;
    private Integer fraTcBinRand;
    private Integer pTflagBin;
    private Integer superPrimeTCBin;
    private Integer superPrimeBin;
    private Integer tdcBin;
    private Integer dti10KChgBin;
    private Integer zip3Bin;
    private Integer pmi61Bin;
    private Integer loanTermBin;
    private Integer ficoBin;
    private Integer previousLoanBin;
    private Integer loanAmountBin;
    private Integer dtiWoProspLoanBin;
    private Integer partnershipBin;
    private Integer inquiryBin;
    private Integer monthlyIncomeBin;
    private Integer revbalBin;
    private Integer employBin;
    private Integer vantageBin;
    private long applicantId;
    private int loanTerm;
    private int ficoValueRand;
    private double pmi61ValueRand;
    private Boolean previousLoanValueRand;
    private Double loanAmountRand;
    private double dtiWoProspLoanValueRand;
    private String partnershipChannelRand;
    private String inquiryRand;
    private String revbalRand;
    private double monthlyIncomeRand;

    private Boolean partialFundingElig;
    private Date originationDate;
    private double lossRate;
    private double borrowerApr;
    private double originationFee;
    private double loanCap;
    private boolean valid;
    private double monthlyPayment;
    private double financeCharge;
    private double finalPaymentAmount;
    private String zip3Rand;
    private double dti10KchgRand;
    private String loanProduct;
    private String superPrimeRules;
    private String all201Rand;
    private String bac042Rand;
    private String bac302Rand;
    private String ssnRand;
    private String employRand;
    private Integer vantageRand;
    private Integer bc102sRand;
    private Integer re33sRand;
    private String inCateRand;
    private Double inLoanAmountRand;
    private Integer moLastTradeRand;
    private Integer moLastTradeBin;

    private BorrowerPricingData(final Builder builder) {
        at34B_Rand = builder.at34B_Rand;
        utlBin = builder.utlBin;
        pmi9PctBin = builder.pmi9PctBin;
        re27sRand = builder.re27sRand;
        g066sRand = builder.g066sRand;
        fraBin = builder.fraBin;
        fraTcBinRand = builder.fraTcBinRand;
        moLastTradeBin = builder.moLastTradeBin;
        applicantId = builder.applicantId;
        loanTerm = builder.loanTerm;
        ficoBin = builder.ficoBin;
        loanTermBin = builder.loanTermBin;
        previousLoanBin = builder.previousLoanBin;
        loanAmountBin = builder.loanAmountBin;
        dtiWoProspLoanBin = builder.dtiWoProspLoanBin;
        partnershipBin = builder.partnershipBin;
        pmi61Bin = builder.pmi61Bin;
        zip3Bin = builder.zip3Bin;
        dti10KChgBin = builder.dti10KChgBin;
        inquiryBin = builder.inquiryBin;
        superPrimeBin = builder.superPrimeBin;
        superPrimeTCBin = builder.superPrimeTCBin;
        monthlyIncomeBin = builder.monthlyIncomeBin;
        employBin = builder.employBin;
        vantageBin = builder.vantageBin;
        bc102sRand = builder.bc102sRand;
        re33sRand = builder.re33sRand;
        revbalBin = builder.revbalBin;
        tdcBin = builder.tdcBin;
        pTflagBin = builder.pTflagBin;
        cateBin = builder.cateBin;
        ficoValueRand = builder.ficoValueRand;
        pmi61ValueRand = builder.pmi61ValueRand;
        // probabilityBad = builder.probabilityBad;
        previousLoanValueRand = builder.previousLoanValueRand;
        loanAmountRand = builder.loanAmountRand;
        inLoanAmountRand = builder.inLoanAmountRand;
        dtiWoProspLoanValueRand = builder.dtiWoProspLoanValueRand;
        partnershipChannelRand = builder.partnershipChannelRand;
        // partnershipProgramRand = builder.partnershipProgramRand;
        // partnershipSubProgramRand = builder.partnershipSubProgramRand;
        inquiryRand = builder.inquiryRand;
        monthlyIncomeRand = builder.monthlyIncomeRand;
        employRand = builder.employRand;
        vantageRand = builder.vantageRand;
        revbalRand = builder.revbalRand;
        partialFundingElig = builder.partialFundingElig;
        originationDate = builder.originationDate;
        lossRate = builder.lossRate;
        // rating = builder.rating;
        // borrowerRate = builder.borrowerRate;
        // baseRate = builder.baseRate;
        borrowerApr = builder.borrowerApr;
        // lenderExpectedReturn = builder.lenderExpectedReturn;
        originationFee = builder.originationFee;
        // servicingFee = builder.servicingFee;
        // adjInt = builder.adjInt;
        loanCap = builder.loanCap;
        valid = builder.valid;
        // invalidReasons = builder.invalidReasons;
        // origFeeAmt = builder.origFeeAmt;
        monthlyPayment = builder.monthlyPayment;
        // lenderYield = builder.lenderYield;
        // effectiveYield = builder.effectiveYield;
        // cumulativeIPmt = builder.cumulativeIPmt;
        financeCharge = builder.financeCharge;
        // totalPaidBack = builder.totalPaidBack;
        finalPaymentAmount = builder.finalPaymentAmount;
        // amountFinanced = builder.amountFinanced;
        zip3Rand = builder.zip3Rand;
        loanProduct = builder.loanProduct;
        dti10KchgRand = builder.dti10KchgRand;
        superPrimeRules = builder.superPrimeRules;
        all201Rand = builder.all201Rand;
        bac042Rand = builder.bac042Rand;
        bac302Rand = builder.bac302Rand;
        ssnRand = builder.ssnRand;
        inCateRand = builder.inCateRand;
        inLoanAmountRand = builder.inLoanAmountRand;
        thirdPartyIdRand = builder.thirdPartyIdRand;
        useridRand = builder.useridRand;

    }



    public Integer getAt34B_Rand() {return at34B_Rand;}

    public Integer getUtlBin() {return utlBin;}

    public Integer getPmi9PctBin() {return pmi9PctBin;}

    public String getThirdPartyIdRand() {
        return thirdPartyIdRand;
    }

    public Integer getUseridRand() {
        return useridRand;
    }

    public Integer getFraTcBinRand() {
        return fraTcBinRand;
    }

    public Integer getFraBin() {
        return fraBin;
    }

    public Integer getRe27sRand() {
        return re27sRand;
    }

    public Double getG066sRand() {
        return g066sRand;
    }

    public Integer getMoLastTradeRand() {
        return moLastTradeRand;
    }

    public Integer getMoLastTradeBin() {
        return moLastTradeBin;
    }

    public Integer getCateBin() {
        return cateBin;
    }

    public Integer getpTflagBin() {
        return pTflagBin;
    }

    public Integer getSuperPrimeTCBin() {
        return superPrimeTCBin;
    }

    public Integer getSuperPrimeBin() {
        return superPrimeBin;
    }

    public Integer getTdcBin() {
        return tdcBin;
    }

    public Integer getDti10KChgBin() {
        return dti10KChgBin;
    }

    public Integer getZip3Bin() {
        return zip3Bin;
    }

    public Integer getPmi61Bin() {
        return pmi61Bin;
    }

    public Integer getLoanTermBin() {
        return loanTermBin;
    }

    public Integer getFicoBin() {
        return ficoBin;
    }

    public Integer getPreviousLoanBin() {
        return previousLoanBin;
    }

    public Integer getLoanAmountBin() {
        return loanAmountBin;
    }

    public Integer getDtiWoProspLoanBin() {
        return dtiWoProspLoanBin;
    }

    public Integer getPartnershipBin() {
        return partnershipBin;
    }

    public Integer getInquiryBin() {
        return inquiryBin;
    }

    public Integer getMonthlyIncomeBin() {
        return monthlyIncomeBin;
    }

    public Integer getRevbalBin() {
        return revbalBin;
    }

    public String getLoanProduct() {
        return loanProduct;
    }

    public long getApplicantId() {
        return applicantId;
    }

    public int getLoanTerm() {
        return loanTerm;
    }

    public int getFicoValueRand() {
        return ficoValueRand;
    }

    public double getPmi61ValueRand() {
        return pmi61ValueRand;
    }

    public Boolean getPreviousLoanValueRand() {
        return previousLoanValueRand;
    }

    public Double getLoanAmountRand() {
        return loanAmountRand;
    }

    public double getDtiWoProspLoanValueRand() {
        return dtiWoProspLoanValueRand;
    }

    public String getPartnershipChannelRand() {
        return partnershipChannelRand;
    }

    public String getInquiryRand() {
        return inquiryRand;
    }

    public String getEmployRand() {
        return employRand;
    }

    public Integer getVantageRand() {
        return vantageRand;
    }

    public Integer getBc102sRand() {
        return bc102sRand;
    }

    public Integer getRe33sRand() {
        return re33sRand;
    }

    public double getMonthlyIncomeRand() {
        return monthlyIncomeRand;
    }

    public String getRevbalRand() {
        return revbalRand;
    }

    public Boolean getPartialFundingElig() {
        return partialFundingElig;
    }

    public Date getOriginationDate() {
        return originationDate;
    }

    public double getLossRate() {
        return lossRate;
    }

    public double getBorrowerApr() {
        return borrowerApr;
    }

    public double getOriginationFee() {
        return originationFee;
    }

    public double getLoanCap() {
        return loanCap;
    }

    public boolean isValid() {
        return valid;
    }

    public double getMonthlyPayment() {
        return monthlyPayment;
    }

    public double getFinanceCharge() {
        return financeCharge;
    }

    public double getFinalPaymentAmount() {
        return finalPaymentAmount;
    }

    @Override
    public String toString() {
        return "applicantId=" + applicantId + '}';
    }

    public String getZip3Rand() {
        return zip3Rand;
    }

    public Integer getEmployBin() {
        return employBin;
    }

    public Integer getVantageBin() {
        return vantageBin;
    }

    public double getDti10KchgRand() {
        return dti10KchgRand;
    }

    public String getSuperPrimeRules() {
        return superPrimeRules;
    }

    public String getAll201Rand() {
        return all201Rand;
    }

    public String getBac042Rand() {
        return bac042Rand;
    }

    public String getBac302Rand() {
        return bac302Rand;
    }

    public String getSSNRand() {
        return ssnRand;
    }

    public String getInCateRand() {
        return inCateRand;
    }

    public Double getInitialLoanAmount() {
        return inLoanAmountRand;
    }

    public static final class Builder {

        private Integer at34B_Rand;
        private Integer utlBin;
        private Integer pmi9PctBin;
        private String thirdPartyIdRand;
        private Integer useridRand;
        public String all201Rand;
        private Integer re27sRand;
        private Double g066sRand;
        private Integer fraBin;
        private Integer fraTcBinRand;
        private long applicantId;
        private Integer loanTerm;
        private Integer bc102sRand;
        private Integer re33sRand;
        private Integer loanTermBin;
        private Integer ficoBin;
        private Integer previousLoanBin;
        private Integer loanAmountBin;
        private Integer dtiWoProspLoanBin;
        private Integer partnershipBin;
        private Integer inquiryBin;
        private Integer monthlyIncomeBin;
        private Integer employBin;
        private Integer vantageBin;
        private Integer revbalBin;
        private Integer pmi61Bin;
        private Integer zip3Bin;
        private Integer dti10KChgBin;
        private Integer tdcBin;
        private Integer superPrimeBin;
        private Integer superPrimeTCBin;
        private Integer pTflagBin;
        private Integer cateBin;

        private int ficoValueRand;
        private double pmi61ValueRand;
        private double probabilityBad;
        private Boolean previousLoanValueRand;
        private Double loanAmountRand;
        private double dtiWoProspLoanValueRand;
        private String partnershipChannelRand;
        private String partnershipProgramRand;
        private String partnershipSubProgramRand;
        private String inquiryRand;
        private double monthlyIncomeRand;
        private String employRand;
        private Integer vantageRand;

        private String revbalRand;
        private Boolean partialFundingElig;
        private Date originationDate;
        private double lossRate;
        private String rating;
        private double borrowerRate;
        private int baseRate;
        private double borrowerApr;
        private double lenderExpectedReturn;
        private double originationFee;
        private double servicingFee;
        private double adjInt;
        private double loanCap;
        private boolean valid;
        private int invalidReasons;
        private int origFeeAmt;
        private double monthlyPayment;
        private double lenderYield;
        private double effectiveYield;
        private double cumulativeIPmt;
        private double financeCharge;
        private double totalPaidBack;
        private double finalPaymentAmount;
        private double amountFinanced;
        private String zip3Rand;
        private double dti10KchgRand;
        private String loanProduct;
        private String superPrimeRules;
        private String bac042Rand;
        private String bac302Rand;
        private String ssnRand;
        private String inCateRand;
        private Double inLoanAmountRand;
        private Integer moLastTradeRand;
        private Integer moLastTradeBin;


        public Builder() {
        }

        public Builder withAT34BRand(final Integer at34B_Rand)
        {
            this.at34B_Rand = at34B_Rand;
            return this;
        }

        public Builder withUTLBin(final Integer utlBin)
        {
            this.utlBin = utlBin;
            return this;
        }

        public Builder withPMI9PCTBin(final Integer pmi9PctBin)
        {
            this.pmi9PctBin = pmi9PctBin;
            return this;
        }

        public Builder withThirdPartyIdRand(final String thirdPartyIdRand) {
            this.thirdPartyIdRand = thirdPartyIdRand;
            return this;
        }

        public Builder withUseridRand(final Integer useridRand) {
            this.useridRand = useridRand;
            return this;
        }

        public Builder withMoLastTradeRand(final Integer moLastTradeRand) {
            this.moLastTradeRand = moLastTradeRand;
            return this;
        }

        public Builder withMoLastTradeBin(final Integer moLastTradeBin) {
            this.moLastTradeBin = moLastTradeBin;
            return this;
        }

        public Builder withRe27sRand(final Integer re27sRand)
        {
            this.re27sRand = re27sRand;
            return this;
        }

        public Builder withG066sRand(final Double g066sRand)
        {
            this.g066sRand = g066sRand;
            return this;
        }


        public Builder withFraBin(final Integer fraBin) {
            this.fraBin = fraBin;
            return this;
        }

        public Builder withFraTcBinRand(final Integer fraTcBinRand) {
            this.fraTcBinRand = fraTcBinRand;
            return this;
        }

        public Builder withApplicantId(final long applicantId) {
            this.applicantId = applicantId;
            return this;
        }

        public Builder withLoanTerm(final int loanTerm) {
            this.loanTerm = loanTerm;
            return this;
        }

        public Builder withFicoValueRand(final int ficoValueRand) {
            this.ficoValueRand = ficoValueRand;
            return this;
        }

        public Builder withPmi61ValueRand(final double pmi61ValueRand) {
            this.pmi61ValueRand = pmi61ValueRand;
            return this;
        }

        public Builder withProbabilityBad(final double probabilityBad) {
            this.probabilityBad = probabilityBad;
            return this;
        }

        public Builder withPreviousLoanValueRand(final Boolean previousLoanValueRand) {
            this.previousLoanValueRand = previousLoanValueRand;
            return this;
        }

        public Builder withLoanAmountRand(final Double loanAmountRand) {
            this.loanAmountRand = loanAmountRand;
            return this;
        }

        public Builder withInLoanAmount(final Double inLoanAmount) {
            this.inLoanAmountRand = inLoanAmountRand;
            return this;
        }

        public Builder withDtiWoProspLoanValueRand(final double dtiWoProspLoanValueRand) {
            this.dtiWoProspLoanValueRand = dtiWoProspLoanValueRand;
            return this;
        }

        public Builder withPartnershipChannelRand(final String partnershipChannelRand) {
            this.partnershipChannelRand = partnershipChannelRand;
            return this;
        }

        public Builder withPartnershipProgramRand(final String partnershipProgramRand) {
            this.partnershipProgramRand = partnershipProgramRand;
            return this;
        }

        public Builder withPartnershipSubProgramRand(final String partnershipSubProgramRand) {
            this.partnershipSubProgramRand = partnershipSubProgramRand;
            return this;
        }

        public Builder withInquiryRand(final String inquiryRand) {
            this.inquiryRand = inquiryRand;
            return this;
        }

        public Builder withMonthlyIncomeRand(final double monthlyIncomeRand) {
            this.monthlyIncomeRand = monthlyIncomeRand;
            return this;
        }

        public Builder withRevbalRand(final String revbalRand) {
            this.revbalRand = revbalRand;
            return this;
        }

        public Builder withPartialFundingElig(final Boolean partialFundingElig) {
            this.partialFundingElig = partialFundingElig;
            return this;
        }

        /**
         * Set borrower pricing data origination date.
         *
         * @param originationDate
         * @return BorrowerPricingData.Builder
         */
        public Builder withOriginationDate(final Date originationDate) {
            this.originationDate = originationDate;
            return this;
        }

        public Builder withLossRate(final double lossRate) {
            this.lossRate = lossRate;
            return this;
        }

        public Builder withRating(final String rating) {
            this.rating = rating;
            return this;
        }

        public Builder withBorrowerRate(final double borrowerRate) {
            this.borrowerRate = borrowerRate;
            return this;
        }

        public Builder withBaseRate(final int baseRate) {
            this.baseRate = baseRate;
            return this;
        }

        public Builder withBorrowerApr(final double borrowerApr) {
            this.borrowerApr = borrowerApr;
            return this;
        }

        public Builder withLenderExpectedReturn(final double lenderExpectedReturn) {
            this.lenderExpectedReturn = lenderExpectedReturn;
            return this;
        }

        public Builder withOriginationFee(final double originationFee) {
            this.originationFee = originationFee;
            return this;
        }

        public Builder withServicingFee(final double servicingFee) {
            this.servicingFee = servicingFee;
            return this;
        }

        public Builder withAdjInt(final double adjInt) {
            this.adjInt = adjInt;
            return this;
        }

        public Builder withLoanCap(final double loanCap) {
            this.loanCap = loanCap;
            return this;
        }

        public Builder withValid(final boolean valid) {
            this.valid = valid;
            return this;
        }

        public Builder withInvalidReasons(final int invalidReasons) {
            this.invalidReasons = invalidReasons;
            return this;
        }

        public Builder withOrigFeeAmt(final int origFeeAmt) {
            this.origFeeAmt = origFeeAmt;
            return this;
        }

        public Builder withMonthlyPayment(final double monthlyPayment) {
            this.monthlyPayment = monthlyPayment;
            return this;
        }

        public Builder withLenderYield(final double lenderYield) {
            this.lenderYield = lenderYield;
            return this;
        }

        public Builder withEffectiveYield(final double effectiveYield) {
            this.effectiveYield = effectiveYield;
            return this;
        }

        public Builder withCumulativeIPmt(final double cumulativeIPmt) {
            this.cumulativeIPmt = cumulativeIPmt;
            return this;
        }

        public Builder withFinanceCharge(final double financeCharge) {
            this.financeCharge = financeCharge;
            return this;
        }

        public Builder withTotalPaidBack(final double totalPaidBack) {
            this.totalPaidBack = totalPaidBack;
            return this;
        }

        public Builder withFinalPaymentAmount(final double finalPaymentAmount) {
            this.finalPaymentAmount = finalPaymentAmount;
            return this;
        }

        public Builder withAmountFinanced(final double amountFinanced) {
            this.amountFinanced = amountFinanced;
            return this;
        }

        public Builder withZip3Rand(final String zip3Rand) {
            this.zip3Rand = zip3Rand;
            return this;
        }

        public Builder withLoanProduct(final String loanProduct) {
            this.loanProduct = loanProduct;
            return this;
        }

        public Builder withDti10KchgRand(final double dti10KchgRand) {
            this.dti10KchgRand = dti10KchgRand;
            return this;
        }

        public BorrowerPricingData build() {
            return new BorrowerPricingData(this);
        }

        public Builder withSuperPrimeRules(String superPrimeRules) {
            this.superPrimeRules = superPrimeRules;
            return this;
        }

        public Builder withAll201Rand(String all201Rand) {
            this.all201Rand = all201Rand;
            return this;
        }

        public Builder withBac042Rand(String bac042Rand) {
            this.bac042Rand = bac042Rand;
            return this;
        }

        public Builder withBac302Rand(String bac302Rand) {
            this.bac302Rand = bac302Rand;
            return this;
        }

        public Builder withBc102sRand(Integer bc102sRand) {
            this.bc102sRand = bc102sRand;
            return this;
        }

        public Builder withRe33sRand(Integer re33sRand) {
            this.re33sRand = re33sRand;
            return this;
        }

        public Builder withSsnRand(String ssnRand) {
            this.ssnRand = ssnRand;
            return this;
        }

        public Builder withEmployRand(String employRand) {
            this.employRand = employRand;
            return this;
        }

        public Builder withVantageRand(Integer vantageRand) {
            this.vantageRand = vantageRand;
            return this;
        }

        public Builder withInCateRand(String inCateRand) {
            this.inCateRand = inCateRand;
            return this;
        }

        public Builder withInLoanAmountRand(Double inLoanAmountRand) {
            this.inLoanAmountRand = inLoanAmountRand;
            return this;
        }

        public Builder withPMI6Bin(int pmi61Bin) {
            this.pmi61Bin = pmi61Bin;
            return this;
        }

        public Builder withZip3Bin(int zip3Bin) {
            this.zip3Bin = zip3Bin;
            return this;
        }

        public Builder withDTI10KChgBin(int dti10KChgBin) {
            this.dti10KChgBin = dti10KChgBin;
            return this;
        }

        public Builder withTDCBin(int tdcBin) {
            this.tdcBin = tdcBin;
            return this;
        }

        public Builder withSuperPrimeBin(int superPrimeBin) {
            this.superPrimeBin = superPrimeBin;
            return this;
        }

        public Builder withSuperPrimeTCBin(int superPrimeTCBin) {
            this.superPrimeTCBin = superPrimeTCBin;
            return this;
        }

        public Builder withPTflagBin(int pTflagBin) {
            this.pTflagBin = pTflagBin;
            return this;
        }

        public Builder withCateBin(int cateBin) {
            this.cateBin = cateBin;
            return this;
        }

        public Builder withLoanTermBin(final int loanTermBin) {
            this.loanTermBin = loanTermBin;
            return this;
        }

        public Builder withFicoBin(final int ficoBin) {
            this.ficoBin = ficoBin;
            return this;
        }

        public Builder withPreviousLoanBin(final int previousLoanBin) {
            this.previousLoanBin = previousLoanBin;
            return this;
        }

        public Builder withLoanAmountBin(final int loanAmountBin) {
            this.loanAmountBin = loanAmountBin;
            return this;
        }

        public Builder withDtiWoProspLoanBin(final int dtiWoProspLoanBin) {
            this.dtiWoProspLoanBin = dtiWoProspLoanBin;
            return this;
        }

        public Builder withPartnershipBin(final int partnershipBin) {
            this.partnershipBin = partnershipBin;
            return this;
        }

        public Builder withInquiryBin(final int inquiryBin) {
            this.inquiryBin = inquiryBin;
            return this;
        }

        public Builder withMonthlyIncomeBin(final int monthlyIncomeBin) {
            this.monthlyIncomeBin = monthlyIncomeBin;
            return this;
        }

        public Builder withEmployBin(final Integer employBin) {
            this.employBin = employBin;
            return this;
        }

        public Builder withVantageBin(Integer vantageBin) {
            this.vantageBin = vantageBin;
            return this;
        }

        public Builder withRevbalBin(final int revbalBin) {
            this.revbalBin = revbalBin;
            return this;
        }

        public Builder withPTFlagBin(final int pTflagBin) {
            this.pTflagBin = pTflagBin;
            return this;
        }
    }

    public static final class Mapper {

        /**
         * Map the pricing request values from the CSV file to the
         * BorrowerPricingData object.
         *
         * @param applicant
         * @return
         * @throws AutomationException
         */
        public static BorrowerPricingData map(final CSVRecord applicant) throws AutomationException {
            try {

                // TODO: this is a hack to avoid service error (we need to
                // standardize the
                // input format).
                String zipCode = applicant.get("Zip3_Rand");
                if (zipCode.length() < 3) {
                    return null;
                }

                // TODO: this is a hack to avoid service error (we need to
                // standardize the
                // input format).
                String dtiRan = applicant.get("DTIwoProspLoanValue_Rand");
                //Commented below check for TU Pricing
//                if (dtiRan.length() < 6 && !dtiRan.contains(".")) {
//                    return null;
//                }

                // TODO: this is a hack to avoid service error (we need to
                // standardize the
                // input format).
                String lossRate = applicant.get("LossRate");
                if (lossRate.equals("NA")) {
                    lossRate = "0";
                }

                // TODO: this is a hack to avoid service error (we need to
                // standardize the
                // input format).
                String effectiveYield = applicant.get("EffectiveYield");
                if (effectiveYield.equals("NA")) {
                    effectiveYield = "0";
                }

                BorrowerPricingData.Builder builder = new BorrowerPricingData.Builder()
                        .withApplicantId(Long.parseLong(applicant.get("ApplicantID")))
                        .withLoanTerm(Integer.parseInt(applicant.get("LoanTerm")))
                        .withFicoValueRand(Integer.parseInt(applicant.get("FICOValue_Rand")))
                        .withPmi61ValueRand(Double.parseDouble(applicant.get("PMI6_1Value_Rand")))
                        .withProbabilityBad(Double.parseDouble(applicant.get("ProbabilityBad")))
                        .withPreviousLoanValueRand(Integer.parseInt(applicant.get("PreviousLoanValue_Rand")) == 1)
                        .withLoanAmountRand(Double.parseDouble(applicant.get("LoanAmount_Rand")))
                        .withDtiWoProspLoanValueRand(Double.parseDouble(dtiRan))
                        .withPartnershipProgramRand(applicant.get("PartnershipProgram_Rand"))
                        .withPartnershipSubProgramRand(applicant.get("PartnershipSubProgram_Rand"))
                        .withInquiryRand(applicant.get("Inquiry_Rand"))
                        .withInLoanAmountRand(Double.parseDouble(applicant.get("InLoanAmount_Rand")))
                        .withDtiWoProspLoanValueRand(Double.parseDouble(dtiRan))
                        .withPartnershipProgramRand(applicant.get("PartnershipProgram_Rand"))
                        .withPartnershipSubProgramRand(applicant.get("PartnershipSubProgram_Rand"))
                        .withMonthlyIncomeRand(Double.parseDouble(applicant.get("MonthlyIncome_Rand")))
                        .withRevbalRand(applicant.get("Revbal_Rand"))
                        .withPartialFundingElig(Integer.parseInt(applicant.get("PartialFundingElig")) == 1)
                        .withOriginationDate(DateConstant.PRICING_DATE_FORMAT.parse(applicant.get("OriginationDate")))
                        .withLossRate(Double.parseDouble(lossRate)).withRating(applicant.get("Rating"))
                        .withBorrowerRate(Double.parseDouble(applicant.get("BorrowerRate")))
                        .withBaseRate(Integer.parseInt(applicant.get("BaseRate")))
                        .withBorrowerApr(Double.parseDouble(applicant.get("BorrowerAPR")))
                        .withLenderExpectedReturn(Double.parseDouble(applicant.get("LenderExpectedReturn")))
                        .withOriginationFee(Double.parseDouble(applicant.get("OriginationFee")))
                        .withServicingFee(Double.parseDouble(applicant.get("ServicingFee")))
                        .withAdjInt(Double.parseDouble(applicant.get("AdjInt")))
                        .withLoanCap(Double.parseDouble(applicant.get("LoanCap")))
                        .withValid(Integer.parseInt(applicant.get("Valid")) == 1)
                        .withInvalidReasons(Integer.parseInt(applicant.get("InvalidReasons")))
                        .withOrigFeeAmt(Integer.parseInt(applicant.get("OrigFeeAmt")))
                        .withMonthlyPayment(Double.parseDouble(applicant.get("MonthlyPayment")))
                        .withLenderYield(Double.parseDouble(applicant.get("LenderYield")))
                        .withEffectiveYield(Double.parseDouble(effectiveYield))
                        .withCumulativeIPmt(Double.parseDouble(applicant.get("CumulativeIPMT")))
                        .withFinanceCharge(Double.parseDouble(applicant.get("FinanceCharge")))
                        .withTotalPaidBack(Double.parseDouble(applicant.get("TotalPaidBack")))
                        .withFinalPaymentAmount(Double.parseDouble(applicant.get("FinalPaymentAmount")))
                        .withAmountFinanced(Double.parseDouble(applicant.get("AmountFinanced"))).withZip3Rand(zipCode)
                        .withLoanProduct(applicant.get("LoanProduct")).withSuperPrimeRules(applicant.get("SuperPrimeRules"))
                        .withInquiryRand(applicant.get("Inquiry_Rand")).withAll201Rand(applicant.get("ALL201_Rand"))
                        .withBac042Rand(applicant.get("BAC042_Rand")).withBac302Rand(applicant.get("BAC302_Rand"))
                        .withDti10KchgRand(Double.parseDouble(applicant.get("DTI10KChg_Rand")))
                        .withSsnRand(applicant.get("SSN_Rand")).withInCateRand(applicant.get("InCate_Rand"))
                        .withEmployRand(applicant.toMap().get("Employ_Rand"))
                        .withFraTcBinRand(Integer.parseInt(applicant.get("FRATCBin")))
                        .withVantageRand(Integer.parseInt(applicant.get("Vantage_Rand")))
                        .withBc102sRand(Integer.parseInt(applicant.get("BC102S_Rand")))
                        .withRe33sRand(Integer.parseInt(applicant.get("RE33S_Rand")))
                        .withG066sRand(Double.parseDouble(applicant.get("G066S_Rand")))
                        .withRe27sRand(Integer.parseInt(applicant.get("re27s_Rand")))
                        .withThirdPartyIdRand(applicant.get("Third_Party_ID_Rand"))
                        .withUseridRand(Integer.parseInt(applicant.get("UserID_Rand")))
                        .withAT34BRand(Integer.parseInt(applicant.get("AT34B_Rand")))





                // reading all the attribute bins
                        .withPMI6Bin(Integer.parseInt(applicant.get("PMI6_1Bin")))
                        .withZip3Bin(Integer.parseInt(applicant.get("Zip3Bin")))
                        .withDTI10KChgBin(Integer.parseInt(applicant.get("DTI10KChgBin")))
                        .withTDCBin(Integer.parseInt(applicant.get("TDCBin")))
                        .withSuperPrimeBin(Integer.parseInt(applicant.get("SuperPrimeBin")))
                        .withSuperPrimeTCBin(Integer.parseInt(applicant.get("SuperPrimeTCBin")))
                        .withPTflagBin(Integer.parseInt(applicant.get("PTflagBin")))
                        .withCateBin(Integer.parseInt(applicant.get("CateBin")))
                        .withLoanTermBin(Integer.parseInt(applicant.get("LoanTermBin")))
                        .withFicoBin(Integer.parseInt(applicant.get("FICOBin")))
                        .withPreviousLoanBin(Integer.parseInt(applicant.get("PreviousLoanBin")))
                        .withLoanAmountBin(Integer.parseInt(applicant.get("LoanAmountBin")))
                        .withDtiWoProspLoanBin(Integer.parseInt(applicant.get("DTIwoProspLoanBin")))
                        .withPartnershipBin(Integer.parseInt(applicant.get("PartnershipBin")))
                        .withInquiryBin(Integer.parseInt(applicant.get("InquiryBin")))
                        .withMonthlyIncomeBin(Integer.parseInt(applicant.get("MonthlyIncomeBin")))
                        .withEmployBin(Integer.parseInt(applicant.toMap().get("EmployBin") == null ? "1" : applicant.get("EmployBin")))
                        .withVantageBin(Integer.parseInt(applicant.get("VantageBin")))
                        .withFraBin(Integer.parseInt(applicant.get("FRABin")))
                        .withUTLBin(Integer.parseInt(applicant.get("UTLBin")))
                        .withPMI9PCTBin(Integer.parseInt(applicant.get("PMI9PCTBin")))
                        .withRevbalBin(Integer.parseInt(applicant.get("RevbalBin")));
//                 .withMoLastTradeBin(Integer.parseInt(applicant.get("MoLastTradeBin")));


                // MoLastTrade_Rand MoLastTradeBin
                final String rawLastTradeInMonth = applicant.get("MoLastTrade_Rand");
                final Integer lastTradeInMonth = ((StringUtils.isEmpty(rawLastTradeInMonth) || rawLastTradeInMonth.equals("NA")) ? null : Integer.parseInt(rawLastTradeInMonth));

                builder.withMoLastTradeRand(lastTradeInMonth);
                builder.withMoLastTradeBin(Integer.parseInt(applicant.get("MoLastTradeBin")));

                // AUT-22: Clarification for the logic below; this is so error
                // prone.
                // PartnershipChannel_Rand value is surrounded by quotation
                // mark; we are
                // trimming it here.
                final String partnershipChannelRand = applicant.get("PartnershipChannel_Rand").replace("\"", "");

                return builder.withPartnershipChannelRand(partnershipChannelRand).build();
            } catch (ParseException ex) {
                throw new AutomationException(ex.getMessage());
            }
        }
    }
}
