package com.prosper.automation.model.platform.origination;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author sphatak
 *
 */
public class OriginationFundingStatus {

	@JsonProperty("id")
	private int id;
	@JsonProperty("loanId")
	private Integer loanId;
	@JsonProperty("prosperStatus")
	private String prosperStatus;
	@JsonProperty("spectrumStatus")
	private String spectrumStatus;
	@JsonProperty("originationDate")
	private String originationDate;
	@JsonProperty("createdDate")
	private String createdDate;
	@JsonProperty("createdUser")
	private String createdUser;
	@JsonProperty("modifiedDate")
	private String modifiedDate;
	@JsonProperty("modifiedUser")
	private String modifiedUser;
	@JsonProperty("isInOriginationNacha")
	private Boolean isInOriginationNacha;
	@JsonProperty("isInReoriginationNacha")
	private Boolean isInReoriginationNacha;
	@JsonProperty("isUnwound")
	private Boolean isUnwound;
	@JsonProperty("isDelayed")
	private Boolean isDelayed;
	@JsonProperty("allowedActions")
	private AllowedActions allowedActions;
	@JsonProperty("netFundingTransfer")
	private NetFundingTransfer netFundingTransfer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getLoanId() {
		return loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}

	public String getProsperStatus() {
		return prosperStatus;
	}

	public void setProsperStatus(String prosperStatus) {
		this.prosperStatus = prosperStatus;
	}

	public String getSpectrumStatus() {
		return spectrumStatus;
	}

	public void setSpectrumStatus(String spectrumStatus) {
		this.spectrumStatus = spectrumStatus;
	}

	public String getOriginationDate() {
		return originationDate;
	}

	public void setOriginationDate(String originationDate) {
		this.originationDate = originationDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public Boolean getIsInOriginationNacha() {
		return isInOriginationNacha;
	}

	public void setIsInOriginationNacha(Boolean isInOriginationNacha) {
		this.isInOriginationNacha = isInOriginationNacha;
	}

	public Boolean getIsInReoriginationNacha() {
		return isInReoriginationNacha;
	}

	public void setIsInReoriginationNacha(Boolean isInReoriginationNacha) {
		this.isInReoriginationNacha = isInReoriginationNacha;
	}

	public Boolean getIsUnwound() {
		return isUnwound;
	}

	public void setIsUnwound(Boolean isUnwound) {
		this.isUnwound = isUnwound;
	}

	public Boolean getIsDelayed() {
		return isDelayed;
	}

	public void setIsDelayed(Boolean isDelayed) {
		this.isDelayed = isDelayed;
	}

	public AllowedActions getAllowedActions() {
		return allowedActions;
	}

	public void setAllowedActions(AllowedActions allowedActions) {
		this.allowedActions = allowedActions;
	}

	public NetFundingTransfer getNetFundingTransfer() {
		return netFundingTransfer;
	}

	public void setNetFundingTransfer(NetFundingTransfer netFundingTransfer) {
		this.netFundingTransfer = netFundingTransfer;
	}

	public static class OriginationFundingStatusBuilder {
		private int id;
		private Integer loanId;
		private String prosperStatus;
		private String spectrumStatus;
		private String originationDate;
		private String createdDate;
		private String createdUser;
		private String modifiedDate;
		private String modifiedUser;
		private Boolean isInOriginationNacha;
		private Boolean isInReoriginationNacha;
		private Boolean isUnwound;
		private Boolean isDelayed;
		private AllowedActions allowedActions;
		private NetFundingTransfer netFundingTransfer;

		public OriginationFundingStatus builder() {
			OriginationFundingStatus result = new OriginationFundingStatus();
			result.setId(id);
			result.setLoanId(loanId);
			result.setProsperStatus(prosperStatus);
			result.setSpectrumStatus(spectrumStatus);
			result.setOriginationDate(originationDate);
			result.setOriginationDate(originationDate);
			result.setCreatedDate(createdDate);
			result.setCreatedUser(createdUser);
			result.setModifiedDate(modifiedDate);
			result.setModifiedUser(modifiedUser);
			result.setIsInOriginationNacha(isInOriginationNacha);
			result.setIsInReoriginationNacha(isInReoriginationNacha);
			result.setIsUnwound(isUnwound);
			result.setIsDelayed(isDelayed);
			result.setAllowedActions(allowedActions);
			result.setNetFundingTransfer(netFundingTransfer);
			return result;

		}

		public OriginationFundingStatusBuilder id(int id) {
			this.id = id;
			return this;
		}

		public OriginationFundingStatusBuilder loanId(Integer loanId) {
			this.loanId = loanId;
			return this;
		}

		public OriginationFundingStatusBuilder prosperStatus(
				String prosperStatus) {
			this.prosperStatus = prosperStatus;
			return this;
		}

		public OriginationFundingStatusBuilder spectrumStatus(
				String spectrumStatus) {
			this.spectrumStatus = spectrumStatus;
			return this;
		}

		public OriginationFundingStatusBuilder originationDate(
				String originationDate) {
			this.originationDate = originationDate;
			return this;
		}

		public OriginationFundingStatusBuilder createdDate(String createdDate) {
			this.createdDate = createdDate;
			return this;
		}

		public OriginationFundingStatusBuilder createdUser(String createdUser) {
			this.createdUser = createdUser;
			return this;
		}

		public OriginationFundingStatusBuilder modifiedDate(String modifiedDate) {
			this.modifiedDate = modifiedDate;
			return this;
		}

		public OriginationFundingStatusBuilder modifiedUser(String modifiedUser) {
			this.modifiedUser = modifiedUser;
			return this;
		}

		public OriginationFundingStatusBuilder isInOriginationNacha(
				Boolean isInOriginationNacha) {
			this.isInOriginationNacha = isInOriginationNacha;
			return this;
		}

		public OriginationFundingStatusBuilder isInReoriginationNacha(
				Boolean isInReoriginationNacha) {
			this.isInReoriginationNacha = isInReoriginationNacha;
			return this;
		}

		public OriginationFundingStatusBuilder isUnwound(Boolean isUnwound) {
			this.isUnwound = isUnwound;
			return this;
		}

		public OriginationFundingStatusBuilder isDelayed(Boolean isDelayed) {
			this.isDelayed = isDelayed;
			return this;
		}

		public OriginationFundingStatusBuilder allowedActions(
				AllowedActions allowedActions) {
			this.allowedActions = allowedActions;
			return this;
		}

		public OriginationFundingStatusBuilder netFundingTransfer(
				NetFundingTransfer netFundingTransfer) {
			this.netFundingTransfer = netFundingTransfer;
			return this;
		}
	}

}
