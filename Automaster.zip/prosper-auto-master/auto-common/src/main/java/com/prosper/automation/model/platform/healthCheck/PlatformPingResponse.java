package com.prosper.automation.model.platform.healthCheck;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 6/13/16.
 */
public final class PlatformPingResponse {

    @JsonProperty("hostname") private String hostName;

    @JsonIgnore public String getHostName() {
        return hostName;
    }
}
