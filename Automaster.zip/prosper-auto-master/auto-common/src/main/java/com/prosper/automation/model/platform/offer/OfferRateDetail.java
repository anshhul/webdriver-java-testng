
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 5/31/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class OfferRateDetail {

    @JsonProperty("min_amount")
    private Double minimumAmount;
    @JsonProperty("max_amount")
    private Double maximumAmount;
    @JsonProperty("min_apr")
    private Double minimumAPR;
    @JsonProperty("max_apr")
    private Double maximumAPR;


    @JsonIgnore
    public Double getMinimumAmount() {
        return minimumAmount;
    }

    @JsonIgnore
    public Double getMaximumAmount() {
        return maximumAmount;
    }

    @JsonIgnore
    public Double getMinimumAPR() {
        return minimumAPR;
    }

    @JsonIgnore
    public Double getMaximumAPR() {
        return maximumAPR;
    }
}
