package com.prosper.automation.model.platform.email;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by pbudiono on 9/26/16.
 */
public final class Message {

	@JsonProperty("message_key")
	private String messageKey;
	@JsonProperty("message_subject")
	private String messageSubject;
	@JsonProperty("message_content")
	private String messageContent;
	@JsonProperty("message_template_code")
	private String messageTemplateCode;
	@JsonProperty("delivery_type_code")
	private String deliveryTypeCode;
	@JsonProperty("content_type_code")
	private String contentTypeCode;
	@JsonProperty("tokens")
	private List<MessageToken> messageTokens;

	public Message() {
	}

	private Message(Builder builder) {
		messageKey = builder.messageKey;
		messageSubject = builder.messageSubject;
		messageContent = builder.messageContent;
		messageTemplateCode = builder.messageTemplateCode;
		deliveryTypeCode = builder.deliveryTypeCode;
		contentTypeCode = builder.contentTypeCode;
		messageTokens = builder.messageTokens;
	}

	public String getMessageKey() {
		return messageKey;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public String getMessageTemplateCode() {
		return messageTemplateCode;
	}

	public String getDeliveryTypeCode() {
		return deliveryTypeCode;
	}

	public String getContentTypeCode() {
		return contentTypeCode;
	}

	public List<MessageToken> getMessageTokens() {
		return messageTokens;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Message message = (Message) o;
		return Objects.equal(getMessageTemplateCode(), message.getMessageTemplateCode())
				&& Objects.equal(getDeliveryTypeCode(), message.getDeliveryTypeCode())
				&& Objects.equal(getContentTypeCode(), message.getContentTypeCode());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getMessageKey(), getMessageContent(), getMessageTemplateCode(), getDeliveryTypeCode(),
				getContentTypeCode(), getMessageTokens());
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public static final class Builder {

		private String messageKey;
		private String messageSubject;
		private String messageContent;
		private String messageTemplateCode;
		private String deliveryTypeCode;
		private String contentTypeCode;
		private List<MessageToken> messageTokens;

		public Builder() {
		}

		public Builder withMessageKey(String val) {
			messageKey = val;
			return this;
		}

		public Builder withMessageSubject(String val) {
			messageSubject = val;
			return this;
		}

		public Builder withMessageContent(String val) {
			messageContent = val;
			return this;
		}

		public Builder withMessageTemplateCode(String val) {
			messageTemplateCode = val;
			return this;
		}

		public Builder withDeliveryTypeCode(String val) {
			deliveryTypeCode = val;
			return this;
		}

		public Builder withContentTypeCode(String val) {
			contentTypeCode = val;
			return this;
		}

		public Builder withMessageTokens(List<MessageToken> val) {
			messageTokens = val;
			return this;
		}

		public Message build() {
			return new Message(this);
		}
	}
}
