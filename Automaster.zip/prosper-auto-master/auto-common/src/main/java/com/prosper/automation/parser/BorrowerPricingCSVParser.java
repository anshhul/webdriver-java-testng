
package com.prosper.automation.parser;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.BorrowerPricingData;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class BorrowerPricingCSVParser {

    private BorrowerPricingCSVParser() {
    }

    public static Object[][] parse(final String csvFilePath) throws AutomationException {
        try (FileInputStream fileInputStream = new FileInputStream(csvFilePath);
             Reader reader = new InputStreamReader(fileInputStream);
             CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader())) {
            final List<CSVRecord> records = parser.getRecords();
            final int recordSize = records.size();
            final Object[][] pricingData = new Object[recordSize][1];
            for (int i = 0; i < recordSize  ; i++) {
                pricingData[i][0] = BorrowerPricingData.Mapper.map(records.get(i));
            }
            return pricingData;
        } catch (IOException e) {
            throw new AutomationException(e.getMessage());
        }
    }

}
