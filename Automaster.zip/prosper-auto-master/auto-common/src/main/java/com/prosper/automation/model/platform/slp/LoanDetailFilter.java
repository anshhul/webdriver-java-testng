
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonInclude(Include.NON_NULL)
public class LoanDetailFilter {

    @JsonProperty("spv_account_ids")
    private List<String> spvAccountIds;
    
    @JsonProperty("min_seasoning_days")
    private Integer minSeasoningDays;
    
    @JsonProperty("cut_off_time")
    private String cutOffTime;

    @JsonProperty("max_seasoning_days")
    private String maxSeasoningPeriod;
    
    
    public List<String> getSpvAccountIds() {
        return spvAccountIds;
    }
    
    public void setSpvAccountIds(List<String> spvAccountIds) {
        this.spvAccountIds = spvAccountIds;
    }
    
    public Integer getMinSeasoningDays() {
        return minSeasoningDays;
    }
    
    public void setMinSeasoningDays(Integer minSeasoningDays) {
        this.minSeasoningDays = minSeasoningDays;
    }
    
    public String getCutOffTime() {
        return cutOffTime;
    }
    
    public void setCutOffTime(String cutOffTime) {
        this.cutOffTime = cutOffTime;
    }
    
    public String getMaxSeasoningPeriod() {
        return maxSeasoningPeriod;
    }
    
    public void setMaxSeasoningPeriod(String maxSeasoningPeriod) {
        this.maxSeasoningPeriod = maxSeasoningPeriod;
    }
    
    
    public static class LoanDetailFilterBuilder {
        
        private List<String> spvAccountIds;
        private Integer minSeasoningDays;
        private String cutOffTime;
        private String maxSeasoningPeriod;
        
        
        public LoanDetailFilterBuilder spvAccountIds(List<String> value) {
            this.spvAccountIds = value;
            return this;
        }
        
        public LoanDetailFilterBuilder minSeasoningDays(Integer value) {
            this.minSeasoningDays = value;
            return this;
        }
        
        public LoanDetailFilterBuilder cutOffTime(String value) {
            this.cutOffTime = value;
            return this;
        }
        
        public LoanDetailFilterBuilder maxSeasoningPeriod(String value) {
            this.maxSeasoningPeriod = value;
            return this;
        }
        
        public LoanDetailFilter build() {
            final LoanDetailFilter result = new LoanDetailFilter();
            
            result.setSpvAccountIds(spvAccountIds);
            result.setMinSeasoningDays(minSeasoningDays);
            result.setCutOffTime(cutOffTime);
            result.setMaxSeasoningPeriod(maxSeasoningPeriod);
            return result;
        }
    }
    
    
    public static LoanDetailFilterBuilder newBuilder() {
        return new LoanDetailFilterBuilder();
    }
    
    public static LoanDetailFilterBuilder buildUpon(LoanDetailFilter original) {
        final LoanDetailFilterBuilder builder = newBuilder();
        builder.spvAccountIds(original.getSpvAccountIds());
        builder.minSeasoningDays(original.getMinSeasoningDays());
        builder.cutOffTime(original.getCutOffTime());
        builder.maxSeasoningPeriod(original.getMaxSeasoningPeriod());
        return builder;
    }
    
}
