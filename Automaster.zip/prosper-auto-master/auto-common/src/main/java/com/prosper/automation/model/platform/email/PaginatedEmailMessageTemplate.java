package com.prosper.automation.model.platform.email;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 8/11/16.
 */
public final class PaginatedEmailMessageTemplate {

	@JsonProperty("results")
	private List<EmailMessageTemplate> results;
	@JsonProperty("limit")
	private Integer limit;
	@JsonProperty("offset")
	private Integer offset;

	public List<EmailMessageTemplate> getResults() {
		return results;
	}
}
