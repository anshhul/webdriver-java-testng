
package com.prosper.automation.model.platform.marketplace;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
public final class MarketplaceOffer {

    @JsonProperty("id")
    private Integer id;
    @JsonProperty("apr")
    private Double borrowerAPR;
    @JsonProperty("loan_amount")
    private Double loanAmount;
    @JsonProperty("origination_fee")
    private Double originationFee;
    @JsonProperty("monthly_payment")
    private Double monthlyPayment;
    @JsonProperty("loan_term_in_months")
    private Integer loanTermInMonths;
    @JsonProperty("loan_term_in_years")
    private Double loanTermInYears;
    @JsonProperty("loan_rate")
    private Double loanRate;
    @JsonProperty("offer_url")
    private String offerURL;
    @JsonProperty("offer_type")
    private String offerType;


    public MarketplaceOffer() {
    }

    private MarketplaceOffer(Builder builder) {
        id = builder.id;
        borrowerAPR = builder.borrowerAPR;
        loanAmount = builder.loanAmount;
        originationFee = builder.originationFee;
        monthlyPayment = builder.monthlyPayment;
        loanTermInMonths = builder.loanTermInMonths;
        loanTermInYears = builder.loanTermInYears;
        loanRate = builder.loanRate;
        offerURL = builder.offerURL;
        offerType = builder.offerType;
    }

    public Integer getId() {
        return id;
    }

    public Double getBorrowerAPR() {
        return borrowerAPR;
    }

    public Double getLoanAmount() {
        return loanAmount;
    }

    public Double getOriginationFee() {
        return originationFee;
    }

    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    public Integer getLoanTermInMonths() {
        return loanTermInMonths;
    }

    public Double getLoanTermInYears() {
        return loanTermInYears;
    }

    public Double getLoanRate() {
        return loanRate;
    }

    public String getOfferURL() {
        return offerURL;
    }

    public String getOfferType() {
        return offerType;
    }


    public static final class Builder {

        private Integer id;
        private Double borrowerAPR;
        private Double loanAmount;
        private Double originationFee;
        private Double monthlyPayment;
        private Integer loanTermInMonths;
        private Double loanTermInYears;
        private Double loanRate;
        private String offerURL;
        private String offerType;


        public Builder() {
        }

        public Builder withId(Integer val) {
            id = val;
            return this;
        }

        public Builder withBorrowerAPR(Double val) {
            borrowerAPR = val;
            return this;
        }

        public Builder withLoanAmount(Double val) {
            loanAmount = val;
            return this;
        }

        public Builder withOriginationFee(Double val) {
            originationFee = val;
            return this;
        }

        public Builder withMonthlyPayment(Double val) {
            monthlyPayment = val;
            return this;
        }

        public Builder withLoanTermInMonths(Integer val) {
            loanTermInMonths = val;
            return this;
        }

        public Builder withLoanTermInYears(Double val) {
            loanTermInYears = val;
            return this;
        }

        public Builder withLoanRate(Double val) {
            loanRate = val;
            return this;
        }

        public Builder withOfferURL(String val) {
            offerURL = val;
            return this;
        }

        public Builder withOfferType(String val) {
            offerType = val;
            return this;
        }

        public MarketplaceOffer build() {
            return new MarketplaceOffer(this);
        }
    }
}
