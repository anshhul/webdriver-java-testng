package com.prosper.automation.model.platform.healthCheck;

import java.util.List;

/**
 * Created by pbudiono on 6/13/16.
 */
public final class HealthCheckConfiguration {

	public String environment;
	public List<Cluster> clusters;

	public HealthCheckConfiguration() {
	}

	private HealthCheckConfiguration(Builder builder) {
		environment = builder.environment;
		clusters = builder.clusters;
	}

	public Object[][] toTestDataProvider() {
		final String[][] testData = new String[getNumberOfServices()][7];

		int index = 0;
		for (final Cluster cluster : this.clusters) {

			final String clusterName = cluster.getName();
			final String clusterScheme = cluster.getScheme();
			final String clusterHostName = cluster.getHostName();
			final String connectTimeout = cluster.getConnectTimeout();
			final String socketTimeout = cluster.getSocketTimeout();

			for (final String serviceName : cluster.getServices()) {
				testData[index][0] = this.environment;
				testData[index][1] = clusterName;
				testData[index][2] = clusterScheme;
				testData[index][3] = clusterHostName;
				testData[index][4] = connectTimeout;
				testData[index][5] = socketTimeout;
				testData[index][6] = serviceName;

				index++;
			}
		}
		return testData;
	}

	private int getNumberOfServices() {
		int numberOfTestData = 0;
		for (final Cluster cluster : this.clusters) {
			for (final String serviceName : cluster.getServices()) {
				numberOfTestData++;
			}
		}
		return numberOfTestData;
	}

	public List<Cluster> getClusters() {
		return clusters;
	}

	public String getEnvironment() {
		return environment;
	}

	public static final class Builder {

		private String environment;
		private List<Cluster> clusters;

		public Builder() {
		}

		public Builder withEnvironment(String val) {
			environment = val;
			return this;
		}

		public Builder withClusters(List<Cluster> val) {
			clusters = val;
			return this;
		}

		public HealthCheckConfiguration build() {
			return new HealthCheckConfiguration(this);
		}
	}
}
