
package com.prosper.automation.model.platform.marketplace;

import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public final class MarketplaceApplicationOffersTestDataHelper {

    public static final String TEST_DATA_LOAN_AMOUNT = "3000.50";
    public static final String TEST_DATA_LOAN_PURPOSE = "1";
    public static final String TEST_DATA_CREDIT_SCORE = "1";
    public static final String TEST_DATA_ADDRESS_STREET = "221 Main Street";
    public static final String TEST_DATA_ADDRESS__NON_EXISTING_STREET = "221 Main Street";
    public static final String TEST_DATA_ADDRESS_CITY = "SF";
    public static final String TEST_DATA_ADDRESS_STATE = "CA";
    public static final String TEST_DATA_ADDRESS_ZIP = "94105";
    public static final String TEST_DATA_ADDRESS_LONG_ZIP = "94105-1234";
    public static final String TEST_DATA_ADDRESS_LONG_ZIP_NO_DASH = "941051234";
    public static final String TEST_DATA_MIDDLE_INITIAL = "H";
    public static final String TEST_DATA_SUFFIX = "SIR";
    public static final String TEST_DATA_CLIENT_REFERENCE = "APP101";
    public static final String TEST_DATA_OCCUPATION_ID = "17";
    public static final String TEST_DATA_OCCUPATION_CHAR_ID = "17";
    public static final int TEST_DATA_EMP_YEAR = 1999;
    public static final int TEST_DATA_EMP_MONTH = 3;
    public static final String TEST_DATA_EMP_NAME = "ABC";
    public static final String TEST_DATA_PARTNER_CODE = "22";
    public static final String UNSUPPORTED_STATE = "ND";
    public static final String TEST_DATA_NUMERIC_FNAME = "1222";
    public static final Double TEST_DATA_NEGATIVE_INCOME = -12222.;


    private MarketplaceApplicationOffersTestDataHelper() {
    }

    public static LoanInfo getValidLoanInfo() {
        return new LoanInfo.LoanInfoBuilder().withLoanAmount(TEST_DATA_LOAN_AMOUNT).withLoanPurpose(TEST_DATA_LOAN_PURPOSE)
                .withSelfReportedCreditScore(TEST_DATA_CREDIT_SCORE).build();
    }

    public static AddressInfo getValidAddressInfo() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(TEST_DATA_ADDRESS_STATE)
                .withStreet(TEST_DATA_ADDRESS_STREET).withCity(TEST_DATA_ADDRESS_CITY).withZip(TEST_DATA_ADDRESS_ZIP).build();
    }

    public static AddressInfo getValidAddressInfoWithUnsupportedState() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(UNSUPPORTED_STATE)
                .withStreet(TEST_DATA_ADDRESS_STREET).withCity(TEST_DATA_ADDRESS_CITY).withZip(TEST_DATA_ADDRESS_ZIP).build();
    }

    public static EmploymentInfo getValidEmploymentInfo() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithCharOccId() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(TEST_DATA_NEGATIVE_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_CHAR_ID).build();
    }

    public static ContactInfo getValidContactInfo() {
        return new ContactInfo.ContactInfoBuilder().withEmailAddress(Constant.getGloballyUniqueEmail(true))
                .withHomePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).build();
    }

    public static IdentificationInfo getValidIdentificationInfo(int partnerCode) {
        return new IdentificationInfo.Builder().withPartnerSourceCode(String.valueOf(partnerCode))
                .withClientReferenceId(TEST_DATA_CLIENT_REFERENCE).build();
    }

    public static BankAccountInfo getValidBankInfo() {
        return BankAccountConstant.BANK_OF_AMERICA_BANK_ACCOUNT_1;
    }

    public static PersonalInfo getValidPersonalInfo() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                .withMiddleInitial(TEST_DATA_MIDDLE_INITIAL).withSuffix(TEST_DATA_SUFFIX)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
    }

    public static PersonalInfo getValidPersonalInfoWithNumericFirstName() {
        return new PersonalInfo.Builder().withFirstName(TEST_DATA_NUMERIC_FNAME).withLastName(Constant.TEST_LAST_NAME)
                .withMiddleInitial(TEST_DATA_MIDDLE_INITIAL).withSuffix(TEST_DATA_SUFFIX)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithNegativeIncome() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(TEST_DATA_NEGATIVE_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_ID).build();
    }
}
