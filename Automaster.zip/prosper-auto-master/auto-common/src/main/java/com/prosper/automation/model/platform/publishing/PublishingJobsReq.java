
package com.prosper.automation.model.platform.publishing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 26/6/2016
 */
@JsonInclude(Include.NON_NULL)
public class PublishingJobsReq {

    @JsonProperty("@class")
    private String className;

    @JsonProperty("job_name")
    private String jobName;


    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public static PublishingJobsReqBuilder newBuilder() {
        return new PublishingJobsReqBuilder();
    }


    public static class PublishingJobsReqBuilder {

        private String className;
        private String jobName;


        public PublishingJobsReqBuilder className(String value) {
            this.className = value;
            return this;
        }

        public PublishingJobsReqBuilder jobName(String value) {
            this.jobName = value;
            return this;
        }

        public PublishingJobsReq build() {
            final PublishingJobsReq result = new PublishingJobsReq();
            result.setClassName(className);
            result.setJobName(jobName);
            return result;
        }
    }
}
