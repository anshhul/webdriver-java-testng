
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public final class EmploymentInfo {

    @JsonProperty("employer_id")
    private String employerId;
    @JsonProperty("employer_name")
    private String employerName;
    @JsonProperty("employment_month")
    private Integer employmentMonth;
    @JsonProperty("employment_year")
    private Integer employmentYear;
    @JsonProperty("employment_status_id")
    private String employmentStatusId;
    @JsonProperty("occupation_id")
    private String occupationId;
    @JsonProperty("occupation")
    private String occupation;
    @JsonProperty("annual_income")
    private Double annualIncome;
    @JsonProperty("monthly_income")
    private Double monthlyIncome;
    @JsonProperty("is_self_employed")
    private Boolean isSelfEmployed;
    @JsonProperty("is_income_verifiable")
    private Boolean isIncomeVerifiable;
    @JsonProperty("employer_phone")
    private PhoneNumber employerPhone;
    @JsonProperty("employment_status_months")
    private String employmentStatusMonths;
    @JsonProperty("job_title")
    private String jobTitle;
    @JsonProperty("employer_address_info")
    private AddressInfo employerAddressInfo;


    public EmploymentInfo() {
    }

    public EmploymentInfo(final String employmentStatusId) {
        this.employmentStatusId = employmentStatusId;
    }

    private EmploymentInfo(Builder builder) {
        employerId = builder.employerId;
        setEmployerName(builder.employerName);
        setEmploymentMonth(builder.employmentMonth);
        setEmploymentYear(builder.employmentYear);
        employmentStatusId = builder.employmentStatusId;
        occupationId = builder.occupationId;
        setAnnualIncome(builder.annualIncome);
        monthlyIncome = builder.monthlyIncome;
        setIsSelfEmployed(builder.isSelfEmployed);
        setIsIncomeVerifiable(builder.isIncomeVerifiable);
        setEmployerPhone(builder.employerPhone);
        employmentStatusMonths = builder.employmentStatusMonths;
        jobTitle = builder.jobTitle;
        employerAddressInfo = builder.employerAddressInfo;
        occupation = builder.occupation;
    }

    public String getOccupationId() {
        return occupationId;
    }

    @JsonIgnore
    public String getEmploymentStatusId() {
        return employmentStatusId;
    }

    @JsonIgnore
    public PhoneNumber getEmployerPhone() {
        return employerPhone;
    }

    public void setEmployerPhone(final PhoneNumber employerPhone) {
        this.employerPhone = employerPhone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        EmploymentInfo that = (EmploymentInfo) o;
        return Objects.equal(employerId, that.employerId) &&
                Objects.equal(employerName, that.employerName) &&
                Objects.equal(employmentMonth, that.employmentMonth) &&
                Objects.equal(employmentYear, that.employmentYear) &&
                Objects.equal(employmentStatusId, that.employmentStatusId) &&
                Objects.equal(occupationId, that.occupationId) &&
                Objects.equal(annualIncome, that.annualIncome) &&
                Objects.equal(monthlyIncome, that.monthlyIncome) &&
                Objects.equal(isSelfEmployed, that.isSelfEmployed) &&
                Objects.equal(isIncomeVerifiable, that.isIncomeVerifiable) &&
                Objects.equal(employerPhone, that.employerPhone) &&
                Objects.equal(employmentStatusMonths, that.employmentStatusMonths) &&
                Objects.equal(jobTitle, that.jobTitle);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(employerId, employerName, employmentMonth, employmentYear, employmentStatusId, occupationId,
                annualIncome, monthlyIncome, isSelfEmployed, isIncomeVerifiable, employerPhone, employmentStatusMonths, jobTitle);
    }

    @Override
    public String toString() {
        return "EmploymentInfo{" +
                "employerId='" + employerId + '\'' +
                ", employerName='" + employerName + '\'' +
                ", employmentMonth=" + employmentMonth +
                ", employmentYear=" + employmentYear +
                ", employmentStatusId='" + employmentStatusId + '\'' +
                ", occupationId='" + occupationId + '\'' +
                ", annualIncome=" + annualIncome +
                ", monthlyIncome=" + monthlyIncome +
                ", isSelfEmployed=" + isSelfEmployed +
                ", isIncomeVerifiable=" + isIncomeVerifiable +
                ", employerPhone=" + employerPhone +
                ", employmentStatusMonths='" + employmentStatusMonths + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                '}';
    }

    @JsonIgnore
    public Double getAnnualIncome() {
        return annualIncome;
    }

    @JsonIgnore
    public void setAnnualIncome(final Double annualIncome) {
        this.annualIncome = annualIncome;
    }

    @JsonIgnore
    public Double getMonthlyIncome() {
        return monthlyIncome;
    }

    @JsonIgnore
    public void setMonthlyIncome(final double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    @JsonIgnore
    public String getEmployerName() {
        return employerName;
    }

    @JsonIgnore
    public void setEmployerName(final String employerName) {
        this.employerName = employerName;
    }

    @JsonIgnore
    public void setEmploymentMonth(final int employmentMonth) {
        this.employmentMonth = employmentMonth;
    }

    @JsonIgnore
    public Integer getEmploymentYear() {
        return employmentYear;
    }

    @JsonIgnore
    public void setEmploymentYear(final Integer employmentYear) {
        this.employmentYear = employmentYear;
    }

    public Integer getEmploymentMonth() {
        return employmentMonth;
    }

    @JsonIgnore
    public void setEmploymentMonth(Integer employmentMonth) {
        this.employmentMonth = employmentMonth;
    }

    @JsonIgnore
    public Boolean getIsSelfEmployed() {
        return isSelfEmployed;
    }

    public void setIsSelfEmployed(final Boolean isSelfEmployed) {
        this.isSelfEmployed = isSelfEmployed;
    }

    @JsonIgnore
    public Boolean getIsIncomeVerifiable() {
        return isIncomeVerifiable;
    }

    public void setIsIncomeVerifiable(final Boolean isIncomeVerifiable) {
        this.isIncomeVerifiable = isIncomeVerifiable;
    }


    public static final class Builder {

        private String employerId;
        private String employerName;
        private Integer employmentMonth;
        private Integer employmentYear;
        private String employmentStatusId;
        private String occupationId;
        private Double annualIncome;
        private Double monthlyIncome;
        private Boolean isSelfEmployed;
        private Boolean isIncomeVerifiable;
        private PhoneNumber employerPhone;
        private String employmentStatusMonths;
        private String jobTitle;
        private AddressInfo employerAddressInfo;
        private String occupation;


        public Builder() {
        }

        public Builder withEmployerId(String val) {
            employerId = val;
            return this;
        }

        public Builder withEmployerName(String val) {
            employerName = val;
            return this;
        }

        public Builder withEmploymentMonth(Integer val) {
            employmentMonth = val;
            return this;
        }

        public Builder withEmploymentYear(Integer val) {
            employmentYear = val;
            return this;
        }

        public Builder withEmploymentStatusId(String val) {
            employmentStatusId = val;
            return this;
        }

        public Builder withOccupationId(String val) {
            occupationId = val;
            return this;
        }

        public Builder withAnnualIncome(Double val) {
            annualIncome = val;
            return this;
        }

        public Builder withMonthlyIncome(Double val) {
            monthlyIncome = val;
            return this;
        }

        public Builder withIsSelfEmployed(Boolean val) {
            isSelfEmployed = val;
            return this;
        }

        public Builder withIsIncomeVerifiable(Boolean val) {
            isIncomeVerifiable = val;
            return this;
        }

        public Builder withEmployerPhone(PhoneNumber val) {
            employerPhone = val;
            return this;
        }

        public Builder withEmploymentStatusMonths(String val) {
            employmentStatusMonths = val;
            return this;
        }

        public Builder withJobTitle(String val) {
            jobTitle = val;
            return this;
        }

        public Builder withEmployerAddressInfo(AddressInfo val) {
            employerAddressInfo = val;
            return this;
        }

        public EmploymentInfo build() {
            return new EmploymentInfo(this);
        }

        public Builder withOccupation(String occupation) {
            this.occupation = occupation;
            return this;
        }
    }
}
