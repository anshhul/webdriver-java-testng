
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

import java.util.Date;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"date_of_death", "user_name_type_id", "date_of_birth", "last_name", "middle_initial", "search_last_name",
        "source_type_id", "middle_name", "suffix", "first_name", "is_verified"})
public final class PersonalInfo {

    @JsonProperty("date_of_death")
    private String dateOfDeath;
    @JsonProperty("user_name_type_id")
    private Integer userNameTypeId;
    @JsonProperty("date_of_birth")
    private String dateOfBirth;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("middle_initial")
    private String middleInitial;
    @JsonProperty("search_last_name")
    private String searchLastName;
    @JsonProperty("source_type_id")
    private Integer sourceTypeId;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("suffix")
    private String suffix;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("is_verified")
    private Boolean isVerified;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("driver_license")
    private String driverLicense;


    public PersonalInfo() {
    }

    private PersonalInfo(final Builder builder) {
        dateOfDeath = builder.dateOfDeath;
        userNameTypeId = builder.userNameTypeId;
        dateOfBirth = builder.dateOfBirth;
        lastName = builder.lastName;
        middleInitial = builder.middleInitial;
        searchLastName = builder.searchLastName;
        sourceTypeId = builder.sourceTypeId;
        middleName = builder.middleName;
        suffix = builder.suffix;
        firstName = builder.firstName;
        isVerified = builder.isVerified;
        ssn = builder.ssn;
        driverLicense = builder.driverLicense;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PersonalInfo that = (PersonalInfo) o;
        return Objects.equal(dateOfDeath, that.dateOfDeath) && Objects.equal(userNameTypeId, that.userNameTypeId)
                && Objects.equal(dateOfBirth, that.dateOfBirth) && Objects.equal(lastName, that.lastName)
                && Objects.equal(middleInitial, that.middleInitial) && Objects.equal(searchLastName, that.searchLastName)
                && Objects.equal(sourceTypeId, that.sourceTypeId) && Objects.equal(middleName, that.middleName)
                && Objects.equal(suffix, that.suffix) && Objects.equal(firstName, that.firstName)
                && Objects.equal(isVerified, that.isVerified);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(dateOfDeath, userNameTypeId, dateOfBirth, lastName, middleInitial, searchLastName, sourceTypeId,
                middleName, suffix, firstName, isVerified);
    }

    @Override
    public String toString() {
        return "PersonalInfo{" +
                "dateOfDeath='" + dateOfDeath + '\'' +
                ", userNameTypeId=" + userNameTypeId +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleInitial='" + middleInitial + '\'' +
                ", searchLastName='" + searchLastName + '\'' +
                ", sourceTypeId=" + sourceTypeId +
                ", middleName='" + middleName + '\'' +
                ", suffix='" + suffix + '\'' +
                ", firstName='" + firstName + '\'' +
                ", isVerified=" + isVerified +
                ", ssn='" + ssn + '\'' +
                '}';
    }

    @JsonIgnore
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    @JsonIgnore
    public String getLastName() {
        return lastName;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    @JsonIgnore
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(final String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getMiddleName() {
        return middleName;
    }


    public static final class Builder {

        private String dateOfDeath;
        private Integer userNameTypeId;
        private String dateOfBirth;
        private String lastName;
        private String middleInitial;
        private String searchLastName;
        private Integer sourceTypeId;
        private String middleName;
        private String suffix;
        private String firstName;
        private Boolean isVerified;
        private String ssn;
        private String driverLicense;


        public Builder() {
        }

        public Builder withDateOfDeath(final String dateOfDeath) {
            this.dateOfDeath = dateOfDeath;
            return this;
        }

        public Builder withUserNameTypeId(final Integer userNameTypeId) {
            this.userNameTypeId = userNameTypeId;
            return this;
        }

        public Builder withDateOfBirth(final String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
            return this;
        }

        public Builder withLastName(final String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withMiddleInitial(final String middleInitial) {
            this.middleInitial = middleInitial;
            return this;
        }

        public Builder withSearchLastName(final String searchLastName) {
            this.searchLastName = searchLastName;
            return this;
        }

        public Builder withSourceTypeId(final Integer sourceTypeId) {
            this.sourceTypeId = sourceTypeId;
            return this;
        }

        public Builder withMiddleName(final String middleName) {
            this.middleName = middleName;
            return this;
        }

        public Builder withSuffix(final String suffix) {
            this.suffix = suffix;
            return this;
        }

        public Builder withFirstName(final String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withIsVerified(final Boolean isVerified) {
            this.isVerified = isVerified;
            return this;
        }

        public Builder withSsn(final String ssn) {
            this.ssn = ssn;
            return this;
        }

        public PersonalInfo build() {
            return new PersonalInfo(this);
        }

        public Builder withDriverLicense(String driverLicense) {
            this.driverLicense = driverLicense;
            return this;
        }
    }
}
