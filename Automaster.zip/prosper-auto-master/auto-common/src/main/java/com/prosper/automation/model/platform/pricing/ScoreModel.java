package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by ppatil on 11/22/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScoreModel {

    @JsonProperty("score_model_type")
    private String scoreModelType;
    @JsonProperty("results")
    private Integer resultsVal;
//    @JsonProperty("FICO_SCORE_KEY_PAIRS");
//    private Integer FICO_SCORE_KEY_PAIRS;
//    @JsonProperty("VANTAGE_SCORE_KEY_PAIRS");
//    private Integer VANTAGE_SCORE_KEY_PAIRS;

    private ScoreModel(final Builder builder) {
        scoreModelType = builder.scoreModelType;
        resultsVal = builder.resultsVal;
    }

    @Override
    public String toString() {
        return "ScoreModel{" +
                "scoreModelType='" + scoreModelType + '\'' +
                ", resultsVal=" + resultsVal +
                '}';
    }

    public static final class Builder {
        private String scoreModelType;
        private Integer resultsVal;


        public Builder() {
        }

        public Builder withScoreModelType(final String scoreModelType) {
            this.scoreModelType = scoreModelType;
            return this;
        }

        public Builder withResults(final int resultsVal) {
            this.resultsVal = resultsVal;
            return this;
        }

        public ScoreModel build() {
            return new ScoreModel(this);
        }
    }
}
