
package com.prosper.automation.util.web.borrower.common;

import org.testng.annotations.DataProvider;

import java.lang.reflect.Method;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class DXTestDataProvider {

    @DataProvider(name = "dXTestDataProvider")
    public static Object[][] getDxOfferRequestData(Method m)
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        String excelFileName = ModifyXMLUtil.COMMON_TEST_DATA_ENVIRONMENT + "dxUserTestData.xlsx";
        Xls_Reader xls1 = new Xls_Reader(excelFileName);

        return Utility.getData(m.getName(), xls1);
    }
}
