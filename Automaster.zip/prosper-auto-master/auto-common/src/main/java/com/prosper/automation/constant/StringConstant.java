package com.prosper.automation.constant;

/**
 * Created by pbudiono on 5/27/16.
 */
public final class StringConstant {

    public static final String EMPTY = "";
    public static final String NEW_LINE = "\n";
    public static final String PATH_DELIMITER = "%s/%s";
    public static final String UNDER_SCORE_DELIMITER = "%s_%s";
    public static final String HYPHEN = "-";
}
