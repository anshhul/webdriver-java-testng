
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.enumeration.platform.Industry;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PricingRequest {

    @JsonProperty("user_info")
    private UserInfo userInfo;

    @Override
    public String toString() {
        return "PricingRequest{" +
                "userInfo=" + userInfo +
                ", calculatedPmiAttributes=" + calculatedPmiAttributes +
                ", scoreCard=" + scoreCard +
                ", pricingInfo=" + pricingInfo +
                ", pricingVersion='" + pricingVersion + '\'' +
                ", experianUserCredit=" + experianUserCredit +
                ", userLoanAttributes=" + userLoanAttributes +
                ", requestedLoanAmount=" + requestedLoanAmount +
                ", loanTerm='" + loanTerm + '\'' +
                ", originationDate='" + originationDate + '\'' +
                ", loanProduct='" + loanProduct + '\'' +
                ", tranunionUserCredit=" + tranunionUserCredit +
                ", industry=" + industry +
                '}';
    }

    @JsonProperty("calculated_pmi_attributes")
    private CalculatedPmiAttributes calculatedPmiAttributes;
    @JsonProperty("score_card")
    private ScoreCard scoreCard;
    @JsonProperty("pricing_info")
    private PricingInfo pricingInfo;
    @JsonProperty("pricing_version")
    private String pricingVersion;
    @JsonProperty("experian_user_credit")
    private ExperianUserCredit experianUserCredit;
    @JsonProperty("user_loan_attributes")
    private UserLoanAttributes userLoanAttributes;
    @JsonProperty("requested_loan_amount")
    private double requestedLoanAmount;
    @JsonProperty("loan_term")
    private String loanTerm;
    @JsonProperty("origination_date")
    private String originationDate;
    @JsonProperty("loan_product")
    private String loanProduct;
    @JsonProperty("transunion_user_credit")
    private TransunionUserCredit tranunionUserCredit;
    @JsonProperty("industry")
    private Industry industry;

    public PricingRequest() {
    }

    private PricingRequest(final Builder builder) {
        userInfo = builder.userInfo;
        calculatedPmiAttributes = builder.calculatedPmiAttributes;
        scoreCard = builder.scoreCard;
        pricingInfo = builder.pricingInfo;
        pricingVersion = builder.pricingVersion;
        experianUserCredit = builder.experianUserCredit;
        userLoanAttributes = builder.userLoanAttributes;
        requestedLoanAmount = builder.requestedLoanAmount;
        originationDate = builder.originationDate;
        loanTerm = builder.loanTerm;
        loanProduct = builder.loanProduct;
        tranunionUserCredit = builder.tranunionUserCredit;
        industry = builder.industry;
    }

    public void setPricingVersion(final String pricingVersion) {
        this.pricingVersion = pricingVersion;
    }


    public static final class Builder {

        private UserInfo userInfo;
        private CalculatedPmiAttributes calculatedPmiAttributes;
        private ScoreCard scoreCard;
        private PricingInfo pricingInfo;
        private String pricingVersion;
        private ExperianUserCredit experianUserCredit;
        private UserLoanAttributes userLoanAttributes;
        private double requestedLoanAmount;
        private String loanTerm;
        private String originationDate;
        private String loanProduct;
        private TransunionUserCredit tranunionUserCredit;
        private Industry industry;


        public Builder() {
        }

        public Builder withIndustry(final Industry industry) {
            this.industry = industry;
            return this;
        }


        public Builder withLoanProduct(final String loanProduct) {
            this.loanProduct = loanProduct;
            return this;
        }

        public Builder withUserInfo(final UserInfo userInfo) {
            this.userInfo = userInfo;
            return this;
        }

        public Builder withCalculatedPmiAttributes(final CalculatedPmiAttributes calculatedPmiAttributes) {
            this.calculatedPmiAttributes = calculatedPmiAttributes;
            return this;
        }

        public Builder withScoreCard(final ScoreCard scoreCard) {
            this.scoreCard = scoreCard;
            return this;
        }

        public Builder withPricingInfo(final PricingInfo pricingInfo) {
            this.pricingInfo = pricingInfo;
            return this;
        }

        public Builder withPricingVersion(final String pricingVersion) {
            this.pricingVersion = pricingVersion;
            return this;
        }

        public Builder withExperianUserCredit(final ExperianUserCredit experianUserCredit) {
            this.experianUserCredit = experianUserCredit;
            return this;
        }

        public Builder withTransunionUserCredit(final TransunionUserCredit tranunionUserCredit) {
            this.tranunionUserCredit = tranunionUserCredit;
            return this;
        }

        public Builder withUserLoanAttributes(final UserLoanAttributes userLoanAttributes) {
            this.userLoanAttributes = userLoanAttributes;
            return this;
        }

        public Builder withRequestedLoanAmount(final double requestedLoanAmount) {
            this.requestedLoanAmount = requestedLoanAmount;
            return this;
        }

        public Builder withLoanTerm(final int loanTerm) throws AutomationException {
            final int threeYear = 3;
            final int fiveYear = 5;
            switch (loanTerm) {
                case threeYear:
                    this.loanTerm = "ThreeYear";
                    break;
                case fiveYear:
                    this.loanTerm = "FiveYear";
                    break;
                default:
                    throw new AutomationException("Invalid parsing assumption!");
            }
            return this;
        }

        public Builder withOriginationDate(final String originationDate) {
            this.originationDate = originationDate;
            return this;
        }

        public PricingRequest build() {
            return new PricingRequest(this);
        }
    }
}
