
package com.prosper.automation.model.platform.email;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

/**
 * Created by pbudiono on 7/21/16.
 */
public final class EmailResponse {

    @JsonProperty("message_response_key")
    private UUID messageResponseKey;
    @JsonProperty("status")
    private String status;
    @JsonProperty("status_message")
    private String statusMessage;
    @JsonProperty("send_date")
    private String sendDate;
}
