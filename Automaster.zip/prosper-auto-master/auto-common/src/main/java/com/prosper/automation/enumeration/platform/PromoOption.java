package com.prosper.automation.enumeration.platform;
/**
 * 
 * @author sphatak
 *
 */
public enum PromoOption {
	A,B,C,CUSTOM

}
