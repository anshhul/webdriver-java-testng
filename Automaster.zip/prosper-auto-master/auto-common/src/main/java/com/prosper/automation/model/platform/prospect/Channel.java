
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Channel {

    @JsonProperty("campaign_channel_id")
    private UUID campaignChannelId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("channel_group_id")
    private Long channelGroupId;
    @JsonProperty("rank")
    private Integer rank;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("modified_date")
    private String modifiedDate;


    @JsonIgnore
    public String getName() {
        return name;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Channel channel = (Channel) o;
        return Objects.equal(campaignChannelId, channel.campaignChannelId) &&
                Objects.equal(name, channel.name) &&
                Objects.equal(channelGroupId, channel.channelGroupId) &&
                Objects.equal(rank, channel.rank) &&
                Objects.equal(createdDate, channel.createdDate) &&
                Objects.equal(modifiedDate, channel.modifiedDate);
    }

    @Override public int hashCode() {
        return Objects.hashCode(campaignChannelId, name, channelGroupId, rank, createdDate, modifiedDate);
    }

    @Override public String toString() {
        return "Channel{" +
                "campaignChannelId=" + campaignChannelId +
                ", name='" + name + '\'' +
                ", channelGroupId=" + channelGroupId +
                ", rank=" + rank +
                ", createdDate='" + createdDate + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                '}';
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public void setCampaignChannelId(UUID campaignChannelId) {
        this.campaignChannelId = campaignChannelId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setChannelGroupId(Long channelGroupId) {
        this.channelGroupId = channelGroupId;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public UUID getCampaignChannelId() {
        return campaignChannelId;
    }

    public Integer getRank() {
        return rank;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }
}
