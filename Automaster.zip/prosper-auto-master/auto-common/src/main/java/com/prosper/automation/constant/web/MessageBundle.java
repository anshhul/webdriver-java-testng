
package com.prosper.automation.constant.web;

/**
 * Created by rsubramanyam on 4/6/16.
 */

import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

public class MessageBundle {

    static Logger logger = Logger.getLogger(MessageBundle.class);


    public static String getMessageFrom(Locale currentLocale, String key) {

        ResourceBundle labels = ResourceBundle.getBundle("messageBundle", currentLocale);
        String value = labels.getString(key);
        logger.info("Locale = " + currentLocale.toString() + ", " + "key = " + key + ", " + "value = " + value);
        return value;
    }

    public static String getMessage(String key) {
        return getMessageFrom(Locale.ENGLISH, key);
    }

    public static void main(String[] args) {

    }

}
