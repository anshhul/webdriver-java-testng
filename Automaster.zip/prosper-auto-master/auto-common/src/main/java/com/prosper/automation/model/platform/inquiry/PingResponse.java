
package com.prosper.automation.model.platform.inquiry;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PingResponse {
    
    @JsonProperty("ping")
    private String ping;
    
    
    public String getPing() {
        return ping;
    }
}
