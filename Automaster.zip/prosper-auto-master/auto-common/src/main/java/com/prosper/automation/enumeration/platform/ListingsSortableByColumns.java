package com.prosper.automation.enumeration.platform;

public enum ListingsSortableByColumns {
    listing_title, credit_grade, listing_amount, loan_term_months, estimated_end_date
}
