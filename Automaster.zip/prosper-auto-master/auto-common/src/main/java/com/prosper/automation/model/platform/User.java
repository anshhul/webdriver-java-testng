
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;
import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"address_info", "is_api_bid_enabled", "roles", "contact_info", "public_handler", "bank_account_info",
        "lending_accreditation", "dealer_code", "personal_info", "acquisition_channel", "user_id", "acquisition_program",
        "direct_pay_partner_id", "is_whole_loans_investor", "acquisition_sub_program", "status", "state_of_residence"})
public final class User {

    @JsonProperty("type")
    private String type;
    @JsonProperty("password")
    private String password;
    @JsonProperty("intended_role")
    private String intendedRole;
    @JsonProperty("credit_grade")
    private Integer creditGrade;
    @JsonProperty("monthly_debt")
    private Integer monthlyDebt;
    @JsonProperty("employment_info")
    private EmploymentInfo employmentInfo;
    @JsonProperty("address_info")
    private AddressInfo addressInfo;
    @JsonProperty("is_api_bid_enabled")
    private Boolean isApiBidEnabled;
    @JsonProperty("roles")
    private String roles;
    @JsonProperty("contact_info")
    private ContactInfo contactInfo;
    @JsonProperty("public_handler")
    private String publicHandler;
    @JsonProperty("bank_account_info")
    private List<BankAccountInfo> bankAccountInfo;
    @JsonProperty("lending_accreditation")
    private LendingAccreditation lendingAccreditation;
    @JsonProperty("dealer_code")
    private String dealerCode;
    @JsonProperty("personal_info")
    private PersonalInfo personalInfo;
    @JsonProperty("acquisition_channel")
    private String acquisitionChannel;
    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("acquisition_program")
    private String acquisitionProgram;
    @JsonProperty("direct_pay_partner_id")
    private Integer directPayPartnerId;
    @JsonProperty("is_whole_loans_investor")
    private Boolean isWholeLoansInvestor;
    @JsonProperty("acquisition_sub_program")
    private String acquisitionSubProgram;
    @JsonProperty("status")
    private String status;
    @JsonProperty("state_of_residence")
    private String stateOfResidence;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("is_registration_complete")
    private Boolean isRegistrationComplete;
    @JsonProperty("alt_key")
    private String altKey;


    // TO-DO: hack!
    @JsonProperty("addressInfo")
    private AddressInfo pmiAttrAddressInfo;
    @JsonProperty("employmentInfo")
    private EmploymentInfo pmiAttrEmploymentInfo;


    public User() {
    }

    private User(final Builder builder) {
        type = builder.type;
        password = builder.password;
        intendedRole = builder.intendedRole;
        creditGrade = builder.creditGrade;
        monthlyDebt = builder.monthlyDebt;
        employmentInfo = builder.employmentInfo;
        addressInfo = builder.addressInfo;
        isApiBidEnabled = builder.isApiBidEnabled;
        roles = builder.roles;
        contactInfo = builder.contactInfo;
        publicHandler = builder.publicHandler;
        bankAccountInfo = builder.bankAccountInfo;
        lendingAccreditation = builder.lendingAccreditation;
        dealerCode = builder.dealerCode;
        personalInfo = builder.personalInfo;
        acquisitionChannel = builder.acquisitionChannel;
        userId = builder.userId;
        acquisitionProgram = builder.acquisitionProgram;
        directPayPartnerId = builder.directPayPartnerId;
        isWholeLoansInvestor = builder.isWholeLoansInvestor;
        acquisitionSubProgram = builder.acquisitionSubProgram;
        status = builder.status;
        stateOfResidence = builder.stateOfResidence;
        ssn = builder.ssn;
        pmiAttrAddressInfo = builder.pmiAttrAddressInfo;
        pmiAttrEmploymentInfo = builder.pmiAttrEmploymentInfo;
        isRegistrationComplete = builder.isRegistrationComplete;
    }

    public List<BankAccountInfo> getBankAccountInfo() {
 		return bankAccountInfo;
 	}

 	public void setBankAccountInfo(List<BankAccountInfo> bankAccountInfo) {
 		this.bankAccountInfo = bankAccountInfo;
 	}
    public PersonalInfo getPersonalInfo() {
        return personalInfo;
    }

    public void setPersonalInfo(final PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    @JsonIgnore
    public AddressInfo getAddressInfo() {
        return addressInfo;
    }

    @JsonIgnore
    public String getAltKey() {
        return altKey;
    }
    public void setAddressInfo(final AddressInfo addressInfo) {
        this.addressInfo = addressInfo;
    }

    @JsonIgnore
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(final ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public Long getUserId() {
        return userId;
    }

    @JsonIgnore public String getRoles() {
        return roles;
    }

    @JsonIgnore public String getStatus() {
        return status;
    }

    @JsonIgnore
    public LendingAccreditation getLendingAccreditation() {
        return lendingAccreditation;
    }

    public void setLendingAccreditation(final LendingAccreditation lendingAccreditation) {
        this.lendingAccreditation = lendingAccreditation;
    }

    @JsonIgnore
    public String getUserSsn() {
        return ssn;
    }

    public void setSsn(final String ssn) {
        this.ssn = ssn;
    }

    public void setRegistrationComplete(final Boolean registrationComplete) {
        isRegistrationComplete = registrationComplete;
    }

    public void setStateOfResidence(final String stateOfResidence) {
        this.stateOfResidence = stateOfResidence;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        User user = (User) o;
        return Objects.equal(creditGrade, user.creditGrade)
                && Objects.equal(monthlyDebt, user.monthlyDebt)
                // && Objects.equal(intendedRole, user.intendedRole)
                && Objects.equal(employmentInfo, user.employmentInfo)
                && Objects.equal(addressInfo, user.addressInfo)
                && Objects.equal(isApiBidEnabled, user.isApiBidEnabled)
                // && Objects.equal(roles, user.roles)
                // && Objects.equal(contactInfo, user.contactInfo)
                // && Objects.equal(publicHandler, user.publicHandler)
                && Objects.equal(bankAccountInfo, user.bankAccountInfo)
                && Objects.equal(lendingAccreditation, user.lendingAccreditation)
                && Objects.equal(dealerCode, user.dealerCode)
                && Objects.equal(personalInfo, user.personalInfo)
                && Objects.equal(acquisitionChannel, user.acquisitionChannel)
                // && Objects.equal(userId, user.userId)
                && Objects.equal(acquisitionProgram, user.acquisitionProgram)
                && Objects.equal(directPayPartnerId, user.directPayPartnerId)
                && Objects.equal(isWholeLoansInvestor, user.isWholeLoansInvestor)
                && Objects.equal(acquisitionSubProgram, user.acquisitionSubProgram) && Objects.equal(status, user.status)
                && Objects.equal(stateOfResidence, user.stateOfResidence);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(password, intendedRole, creditGrade, monthlyDebt, employmentInfo, addressInfo, isApiBidEnabled,
                roles, contactInfo, publicHandler, bankAccountInfo, lendingAccreditation, dealerCode, personalInfo,
                acquisitionChannel, userId, acquisitionProgram, directPayPartnerId, isWholeLoansInvestor, acquisitionSubProgram,
                status, stateOfResidence);
    }

    @Override
    public String toString() {
        return "User{" + "password='" + password + '\'' + ", intendedRole='" + intendedRole + '\'' + ", creditGrade="
                + creditGrade + ", monthlyDebt=" + monthlyDebt + ", employmentInfo=" + employmentInfo + ", addressInfo="
                + addressInfo + ", isApiBidEnabled=" + isApiBidEnabled + ", roles='" + roles + '\'' + ", contactInfo="
                + contactInfo + ", publicHandler='" + publicHandler + '\'' + ", bankAccountInfo=" + bankAccountInfo
                + ", lendingAccreditation=" + lendingAccreditation + ", dealerCode='" + dealerCode + '\'' + ", personalInfo="
                + personalInfo + ", acquisitionChannel='" + acquisitionChannel + '\'' + ", userId=" + userId
                + ", acquisitionProgram='" + acquisitionProgram + '\'' + ", directPayPartnerId=" + directPayPartnerId
                + ", isWholeLoansInvestor=" + isWholeLoansInvestor + ", acquisitionSubProgram='" + acquisitionSubProgram + '\''
                + ", status='" + status + '\'' + ", stateOfResidence='" + stateOfResidence + '\'' + '}';
    }

    @JsonIgnore
    public EmploymentInfo getEmploymentInfo() {
        return employmentInfo;
    }

    @JsonIgnore
    public String geUserEmail() {
        return contactInfo.getEmail();
    }

    public static final class Builder {

        private String type;
        private String password;
        private String intendedRole;
        private Integer creditGrade;
        private Integer monthlyDebt;
        private EmploymentInfo employmentInfo;
        private AddressInfo addressInfo;
        private Boolean isApiBidEnabled;
        private String roles;
        private ContactInfo contactInfo;
        private String publicHandler;
        private List<BankAccountInfo> bankAccountInfo;
        private LendingAccreditation lendingAccreditation;
        private String dealerCode;
        private PersonalInfo personalInfo;
        private String acquisitionChannel;
        private Long userId;
        private String acquisitionProgram;
        private Integer directPayPartnerId;
        private Boolean isWholeLoansInvestor;
        private String acquisitionSubProgram;
        private String status;
        private String stateOfResidence;
        private String ssn;
        private Boolean isRegistrationComplete;

        // TO-DO: hack!
        private AddressInfo pmiAttrAddressInfo;
        private EmploymentInfo pmiAttrEmploymentInfo;


        public Builder() {
        }

        public Builder withType(final String type) {
            this.type = type;
            return this;
        }

        public Builder withPassword(final String password) {
            this.password = password;
            return this;
        }

        public Builder withIntendedRole(final String intendedRole) {
            this.intendedRole = intendedRole;
            return this;
        }

        public Builder withCreditGrade(final Integer creditGrade) {
            this.creditGrade = creditGrade;
            return this;
        }

        public Builder withMonthlyDebt(final Integer monthlyDebt) {
            this.monthlyDebt = monthlyDebt;
            return this;
        }

        public Builder withEmploymentInfo(final EmploymentInfo employmentInfo) {
            this.employmentInfo = employmentInfo;
            return this;
        }

        public Builder withAddressInfo(final AddressInfo addressInfo) {
            this.addressInfo = addressInfo;
            return this;
        }

        public Builder withIsApiBidEnabled(final Boolean isApiBidEnabled) {
            this.isApiBidEnabled = isApiBidEnabled;
            return this;
        }

        public Builder withRoles(final String roles) {
            this.roles = roles;
            return this;
        }

        public Builder withContactInfo(final ContactInfo contactInfo) {
            this.contactInfo = contactInfo;
            return this;
        }

        public Builder withPublicHandler(final String publicHandler) {
            this.publicHandler = publicHandler;
            return this;
        }

        public Builder withBankAccountInfo(final List<BankAccountInfo> bankAccountInfo) {
            this.bankAccountInfo = bankAccountInfo;
            return this;
        }

        public Builder withLendingAccreditation(final LendingAccreditation lendingAccreditation) {
            this.lendingAccreditation = lendingAccreditation;
            return this;
        }

        public Builder withDealerCode(final String dealerCode) {
            this.dealerCode = dealerCode;
            return this;
        }

        public Builder withPersonalInfo(final PersonalInfo personalInfo) {
            this.personalInfo = personalInfo;
            return this;
        }

        public Builder withAcquisitionChannel(final String acquisitionChannel) {
            this.acquisitionChannel = acquisitionChannel;
            return this;
        }

        public Builder withUserId(final Long userId) {
            this.userId = userId;
            return this;
        }

        public Builder withAcquisitionProgram(final String acquisitionProgram) {
            this.acquisitionProgram = acquisitionProgram;
            return this;
        }

        public Builder withDirectPayPartnerId(final Integer directPayPartnerId) {
            this.directPayPartnerId = directPayPartnerId;
            return this;
        }

        public Builder withIsWholeLoansInvestor(final Boolean isWholeLoansInvestor) {
            this.isWholeLoansInvestor = isWholeLoansInvestor;
            return this;
        }

        public Builder withAcquisitionSubProgram(final String acquisitionSubProgram) {
            this.acquisitionSubProgram = acquisitionSubProgram;
            return this;
        }

        public Builder withStatus(final String status) {
            this.status = status;
            return this;
        }

        public Builder withStateOfResidence(final String stateOfResidence) {
            this.stateOfResidence = stateOfResidence;
            return this;
        }

        public Builder withSsn(final String ssn) {
            this.ssn = ssn;
            return this;
        }

        public Builder withIsRegistrationComplete(final Boolean isRegistrationComplete) {
            this.isRegistrationComplete = isRegistrationComplete;
            return this;
        }

        public Builder withPmiAttrAddressInfo(final AddressInfo addressInfo) {
            this.pmiAttrAddressInfo = addressInfo;
            return this;
        }

        public Builder withPmiAttrEmploymentInfo(final EmploymentInfo employmentInfo) {
            this.pmiAttrEmploymentInfo = employmentInfo;
            return this;
        }

        public User build() {
            return new User(this);
        }
    }
}
