package com.prosper.automation.model.platform.loan;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Sonali Phatak
 *
 */
public class AllPaymentResponse {

	@JsonProperty("status")
	private Boolean status;
	@JsonProperty("message")
	private String message;
	@JsonProperty("result")
	private List<PaymentsVO> result;
	@JsonProperty("total_count")
	private Integer totalCount;

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<PaymentsVO> getResult() {
		return result;
	}

	public void setResult(List<PaymentsVO> result) {
		this.result = result;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
}
