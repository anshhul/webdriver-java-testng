//
//package com.prosper.automation.model.platform.slp;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//
//public final class SlpListings {
//
//    @JsonProperty("listing_number")
//    private Integer listingNumber;
//
//    @JsonProperty("loan_id")
//    private Integer loanId;
//
//
//    public Integer getListingNumber() {
//        return listingNumber;
//    }
//
//    public Integer getLoanId() {
//        return loanId;
//    }
//
//    public void setListingNumber(final Integer listingNumber) {
//        this.listingNumber = listingNumber;
//    }
//
//    public void setLoanId(final Integer loanId) {
//        this.loanId = loanId;
//    }
//
// }
