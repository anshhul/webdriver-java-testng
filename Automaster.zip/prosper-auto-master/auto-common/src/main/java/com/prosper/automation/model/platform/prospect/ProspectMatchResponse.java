package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 7/13/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ProspectMatchResponse {
    @JsonProperty("results")
    private ProspectMatchIndividualResult[] results;
//    public int length;

    public ProspectMatchIndividualResult[] getResults() {
        return results;
    }

    public void setResults(ProspectMatchIndividualResult[] results) {
        this.results = results;
    }
}
