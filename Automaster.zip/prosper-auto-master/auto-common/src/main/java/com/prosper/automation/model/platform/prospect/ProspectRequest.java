
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"ref_mc", "ref_ac", "prospect", "channel", "campaign", "program", "pricing"})
public final class ProspectRequest implements Cloneable {
    
    @JsonProperty("ref_mc")
    private String refMc;
    @JsonProperty("ref_ac")
    private String refAc;
    @JsonProperty("prospect")
    private Prospect prospect;
    @JsonProperty("channel")
    private Channel channel;
    @JsonProperty("campaign")
    private Campaign campaign;
    @JsonProperty("program")
    private ProgramVo program;
    @JsonProperty("pricing")
    private Pricing pricing;
    
    
    private ProspectRequest(final Builder builder) {
        refMc = builder.refMc;
        refAc = builder.refAc;
        prospect = builder.prospect;
        channel = builder.channel;
        campaign = builder.campaign;
        program = builder.program;
        pricing = builder.pricing;
    }
    
    @JsonIgnore
    public Prospect getProspect() {
        return prospect;
    }

    public Channel getChannel() {
        return channel;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public ProgramVo getProgram() {
        return program;
    }

    public Pricing getPricing() {
        return pricing;
    }

    public static final class Builder {
        
        private String refMc;
        private String refAc;
        private Prospect prospect;
        private Channel channel;
        private Campaign campaign;
        private ProgramVo program;
        private Pricing pricing;
        
        
        public Builder() {
        }
        
        public Builder withRefMc(final String refMc) {
            this.refMc = refMc;
            return this;
        }
        
        public Builder withRefAc(final String refAc) {
            this.refAc = refAc;
            return this;
        }
        
        public Builder withProspect(final Prospect prospect) {
            this.prospect = prospect;
            return this;
        }
        
        public Builder withChannel(final Channel channel) {
            this.channel = channel;
            return this;
        }
        
        public Builder withCampaign(final Campaign campaign) {
            this.campaign = campaign;
            return this;
        }
        
        public Builder withProgram(final ProgramVo program) {
            this.program = program;
            return this;
        }
        
        public Builder withPricing(final Pricing pricing) {
            this.pricing = pricing;
            return this;
        }
        
        public ProspectRequest build() {
            return new ProspectRequest(this);
        }
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
