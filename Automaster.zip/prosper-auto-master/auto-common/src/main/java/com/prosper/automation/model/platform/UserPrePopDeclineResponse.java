
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UserPrePopDeclineResponse {
    
    @JsonProperty("pre_pop_declined")
    private Boolean prePopDeclined;
    
    
    public Boolean isPrePopDeclined() {
        return prePopDeclined;
    }
}
