
package com.prosper.automation.model.platform.merchant;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.OfficeRoles;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Sonali Phatak
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class MerchantsContactInformation {

	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("last_name")
	private String lastName;
	@JsonProperty("salutation")
	private String salutation;
	@JsonProperty("signer_date_of_birth")
	private String signerDateOfBirth;
	@JsonProperty("address")
	private String address;
	@JsonProperty("title")
	private String title;
	@JsonProperty("email")
	private String email;
	@JsonProperty("phone")
	private String phone;
	@JsonProperty("is_main_point_of_contact")
	private boolean isMainPointOfContact;
	@JsonProperty("contact_third_party_id")
	private String contactThirdPartyId;
	@JsonProperty("office_roles")
	private List<OfficeRoles> officeRoles;

	public MerchantsContactInformation() {
	}

	private MerchantsContactInformation(Builder builder) {
		setFirstName(builder.firstName);
		setLastName(builder.lastName);
		setSalutation(builder.salutation);
		setSignerDateOfBirth(builder.signerDateOfBirth);
		setAddress(builder.address);
		setTitle(builder.title);
		setEmail(builder.email);
		setPhone(builder.phone);
		setMainPointOfContact(builder.isMainPointOfContact);
		setContactThirdPartyId(builder.contactThirdPartyId);
		setOfficeRoles(builder.officeRoles);
	}

	public void setSignerDateOfBirth(String date) {
		this.signerDateOfBirth = date;
	}

	public void setOfficeRoles(List<OfficeRoles> officeRoles) {
		this.officeRoles = officeRoles;
	}

	public void setContactThirdPartyId(String contactThirdPartyId) {
		this.contactThirdPartyId = contactThirdPartyId;
	}

	@JsonIgnore
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonIgnore
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	@JsonIgnore
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@JsonIgnore
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonIgnore
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setMainPointOfContact(boolean isMainPointOfContact) {
		this.isMainPointOfContact = isMainPointOfContact;
	}

	public static final class Builder {

		private String firstName;
		private String lastName;
		private String salutation;
		private String signerDateOfBirth;
		private String address;
		private String title;
		private String email;
		private String phone;
		private boolean isMainPointOfContact;
		private String contactThirdPartyId;
		private List<OfficeRoles> officeRoles;

		public Builder() {
		}

		public Builder withFirstName(String val) {
			firstName = val;
			return this;
		}

		public Builder withLastName(String val) {
			lastName = val;
			return this;
		}

		public Builder withSalutation(String val) {
			salutation = val;
			return this;
		}

		public Builder withSignerDateOfBirth(String val) {
			signerDateOfBirth = val;
			return this;
		}

		public Builder withAddress(String val) {
			address = val;
			return this;
		}

		public Builder withTitle(String val) {
			title = val;
			return this;
		}

		public Builder withEmail(String val) {
			email = val;
			return this;
		}

		public Builder withPhone(String val) {
			phone = val;
			return this;
		}

		public Builder withIsMainPointOfContact(boolean val) {
			isMainPointOfContact = val;
			return this;
		}

		public Builder withContactThirdPartyId(String val) {
			contactThirdPartyId = val;
			return this;
		}

		public Builder withOfficeRoles(List<OfficeRoles> val) {
			officeRoles = val;
			return this;
		}

		public MerchantsContactInformation build() {
			return new MerchantsContactInformation(this);
		}
	}
}
