
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.bankAccount.Account;
import com.prosper.automation.model.platform.bankAccount.UserBankAccount;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class BankAccountConstant {

	public static final String BANK_OF_AMERICA = "Bank of America";
	public static final String BANK_OF_AMERICA_ROUTING_NUMBER = "121000358";

	public static final String WELLS_FARGO = "WELLS FARGO BANK";
	public static final String WELLS_FARGO_ROUTING_NUMBER = "011100106";

	public static final String BANK_OF_AMERICA_ACCOUNT_NUMBER_1 = "0012345678";
	public static final String BANK_OF_AMERICA_ACCOUNT_NUMBER_2 = "0087654321";

	public static final String DUMMY_BANK_ACCOUNT_NUMBER = "1234567890";

	public static final BankAccountInfo BANK_OF_AMERICA_RANDOM_ACCOUNT = new BankAccountInfo.Builder()
			.withBankName(BANK_OF_AMERICA).withFirstAccountHolderName(Constant.TEST_FIRST_NAME)
			.withRoutingNumber(BANK_OF_AMERICA_ROUTING_NUMBER).withAccountNumber(Constant.getRandomIntegerString(10))
			.withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
			.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();
	public static final BankAccountInfo BANK_OF_AMERICA_BANK_ACCOUNT_1 = new BankAccountInfo.Builder()
			.withBankName(BANK_OF_AMERICA).withFirstAccountHolderName(Constant.TEST_FIRST_NAME)
			.withRoutingNumber(BANK_OF_AMERICA_ROUTING_NUMBER).withAccountNumber(BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
			.withIsPrimary(true).withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
			.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();
	public static final BankAccountInfo TEST_BANK = new BankAccountInfo.Builder().withBankName("TEST BANK")
			.withFirstAccountHolderName(Constant.TEST_FIRST_NAME).withRoutingNumber("113024520")
			.withAccountNumber(BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
			.withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
			.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();

	public static final BankAccountInfo BANK_OF_AMERICA_BANK_ACCOUNT_2 = new BankAccountInfo.Builder()
			.withBankName(BANK_OF_AMERICA).withFirstAccountHolderName(Constant.TEST_FIRST_NAME)
			.withRoutingNumber(BANK_OF_AMERICA_ROUTING_NUMBER).withAccountNumber(BANK_OF_AMERICA_ACCOUNT_NUMBER_2)
			.withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
			.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();

	public static final Account BANK_OF_AMERICA_ACCOUNT = new Account.Builder().withNickName(Constant.TEST_FIRST_NAME)
			.withAccountTypeCode(Account.AccountTypeCode.BANK).withAccountStatusType(Account.AccountStatusType.CREATED)
			.withIsDefault(true).build();

	public static final Account DUMMY_BANK_ACCOUNT = new Account.Builder().withNickName(Constant.TEST_FIRST_NAME)
			.withAccountTypeCode(Account.AccountTypeCode.BANK).withAccountStatusType(Account.AccountStatusType.CREATED)
			.withIsDefault(true).build();

	public static final UserBankAccount BANK_OF_AMERICA_USER_BANK_ACCOUNT_1 = new UserBankAccount.Builder()
			.withBankAccount(BANK_OF_AMERICA_BANK_ACCOUNT_1).withAccount(BANK_OF_AMERICA_ACCOUNT).build();
	public static final UserBankAccount BANK_OF_AMERICA_USER_BANK_ACCOUNT_2 = new UserBankAccount.Builder()
			.withBankAccount(BANK_OF_AMERICA_BANK_ACCOUNT_2).withAccount(BANK_OF_AMERICA_ACCOUNT).build();
	public static final UserBankAccount RANDOM_BANK_OF_AMERICA_ACCOUNT = new UserBankAccount.Builder()
			.withBankAccount(BANK_OF_AMERICA_RANDOM_ACCOUNT).withAccount(BANK_OF_AMERICA_ACCOUNT).build();
	public static final UserBankAccount DEFAULT_USER_BANK_ACCOUNT = new UserBankAccount.Builder()
			.withBankAccount(new BankAccountInfo.Builder().build()).withAccount(new Account.Builder().build()).build();

	private BankAccountConstant() {
	}

	public static UserBankAccount buildUserBankAccountBaseRequest() {
		return new UserBankAccount.Builder().withAccount(new Account.Builder().build())
				.withBankAccount(new BankAccountInfo.Builder().build()).build();
	}

	public static UserBankAccount buildBankOfAmericaUserBankAccount1() {
		final Account bankOfAmericaAccount = new Account.Builder().withNickName(Constant.TEST_FIRST_NAME)
				.withAccountTypeCode(Account.AccountTypeCode.BANK).withAccountStatusType(Account.AccountStatusType.CREATED)
				.withIsDefault(true).build();
		final BankAccountInfo bankOfAmericaBankAccount1 = new BankAccountInfo.Builder().withBankName(BANK_OF_AMERICA)
				.withFirstAccountHolderName(Constant.TEST_FIRST_NAME).withRoutingNumber(BANK_OF_AMERICA_ROUTING_NUMBER)
				.withAccountNumber(BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
				.withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
				.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();
		return new UserBankAccount.Builder().withBankAccount(bankOfAmericaBankAccount1).withAccount(bankOfAmericaAccount).build();
	}

	public static UserBankAccount buildRandomBankOfAmericaAccount() {
		final Account bankOfAmericaAccount = new Account.Builder().withNickName(Constant.TEST_FIRST_NAME)
				.withAccountTypeCode(Account.AccountTypeCode.BANK).withAccountStatusType(Account.AccountStatusType.CREATED)
				.withIsDefault(true).build();
		final BankAccountInfo bankOfAmericaBankAccount1 = new BankAccountInfo.Builder().withBankName(BANK_OF_AMERICA)
				.withFirstAccountHolderName(Constant.TEST_FIRST_NAME).withRoutingNumber(BANK_OF_AMERICA_ROUTING_NUMBER)
				.withAccountNumber(Constant.getRandomIntegerString(10))
				.withBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.INDIVIDUAL)
				.withBankAccountType(BankAccountInfo.BankAccountType.CHECKING).build();
		return new UserBankAccount.Builder().withBankAccount(bankOfAmericaBankAccount1).withAccount(bankOfAmericaAccount).build();
	}
}
