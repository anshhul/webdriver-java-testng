
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author Prateek
 */
@JsonInclude(Include.NON_NULL)
public class InvestOrders {
    
    @JsonProperty("order_id")
    private UUID orderId;

    @JsonProperty("bid_requests")
    private List<Bids> bidRequests;
    
    @JsonProperty("effective_yield")
    private Double effectiveYield;
    
    @JsonProperty("estimated_loss")
    private Double estimatedLoss;
    
    @JsonProperty("estimated_return")
    private Double estimatedReturn;

    @JsonProperty("order_status")
    private String orderStatus;
    
    @JsonProperty("source")
    private String source;
    
    @JsonProperty("order_date")
    private String orderDate;
    
    @JsonProperty("order_amount")
    private Double orderAmount;

    @JsonProperty("order_amount_invested")
    private Double orderAmountInvested;

    @JsonProperty("order_amount_placed")
    private Double orderAmountPlaced;
    
    
    public UUID getOrderId() {
        return orderId;
    }
    
    public void setOrderId(UUID orderId) {
        this.orderId = orderId;
    }
    
    public List<Bids> getBidRequests() {
        return bidRequests;
    }
    
    public void setBidRequests(List<Bids> bidRequests) {
        this.bidRequests = bidRequests;
    }
    
    public Double getEffectiveYield() {
        return effectiveYield;
    }
    
    public void setEffectiveYield(Double effectiveYield) {
        this.effectiveYield = effectiveYield;
    }
    
    public Double getEstimatedLoss() {
        return estimatedLoss;
    }
    
    public void setEstimatedLoss(Double estimatedLoss) {
        this.estimatedLoss = estimatedLoss;
    }
    
    public Double getEstimatedReturn() {
        return estimatedReturn;
    }
    
    public void setEstimatedReturn(Double estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }
    
    public String getOrderStatus() {
        return orderStatus;
    }
    
    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
    public String getOrderDate() {
        return orderDate;
    }
    
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }
    
    public Double getOrderAmount() {
        return orderAmount;
    }
    
    public void setOrderAmount(Double orderAmount) {
        this.orderAmount = orderAmount;
    }
    
    public Double getOrderAmountInvested() {
        return orderAmountInvested;
    }
    
    public void setOrderAmountInvested(Double orderAmountInvested) {
        this.orderAmountInvested = orderAmountInvested;
    }
    
    public Double getOrderAmountPlaced() {
        return orderAmountPlaced;
    }
    
    public void setOrderAmountPlaced(Double orderAmountPlaced) {
        this.orderAmountPlaced = orderAmountPlaced;
    }
    
    
    public static class InvestOrdersBuilder {

        private UUID orderId;
        private List<Bids> bidRequests;
        private Double effectiveYield;
        private Double estimatedLoss;
        private Double estimatedReturn;
        private String orderStatus;
        private String source;
        private String orderDate;
        private Double orderAmount;
        private Double orderAmountInvested;
        private Double orderAmountPlaced;


        public InvestOrdersBuilder orderId(UUID value) {
            this.orderId = value;
            return this;
        }

        public InvestOrdersBuilder bidRequests(List<Bids> value) {
            this.bidRequests = value;
            return this;
        }

        public InvestOrdersBuilder effectiveYield(Double value) {
            this.effectiveYield = value;
            return this;
        }

        public InvestOrdersBuilder estimatedLoss(Double value) {
            this.estimatedLoss = value;
            return this;
        }

        public InvestOrdersBuilder estimatedReturn(Double value) {
            this.estimatedReturn = value;
            return this;
        }

        public InvestOrdersBuilder orderStatus(String value) {
            this.orderStatus = value;
            return this;
        }

        public InvestOrdersBuilder source(String value) {
            this.source = value;
            return this;
        }

        public InvestOrdersBuilder orderDate(String value) {
            this.orderDate = value;
            return this;
        }

        public InvestOrdersBuilder orderAmount(Double value) {
            this.orderAmount = value;
            return this;
        }

        public InvestOrdersBuilder orderAmountInvested(Double value) {
            this.orderAmountInvested = value;
            return this;
        }

        public InvestOrdersBuilder orderAmountPlaced(Double value) {
            this.orderAmountPlaced = value;
            return this;
        }

        public InvestOrders build() {
            final InvestOrders result = new InvestOrders();

            result.setOrderId(orderId);
            result.setBidRequests(bidRequests);
            result.setEffectiveYield(effectiveYield);
            result.setEstimatedLoss(estimatedLoss);
            result.setEstimatedReturn(estimatedReturn);
            result.setOrderStatus(orderStatus);
            result.setSource(source);
            result.setOrderDate(orderDate);
            result.setOrderAmount(orderAmount);
            result.setOrderAmountInvested(orderAmountInvested);
            result.setOrderAmountPlaced(orderAmountPlaced);
            return result;
        }
    }
    
    
    public static InvestOrdersBuilder newBuilder() {
        return new InvestOrdersBuilder();
    }
    
    public static InvestOrdersBuilder buildUpon(InvestOrders original) {
        final InvestOrdersBuilder builder = newBuilder();
        builder.orderId(original.getOrderId());
        builder.bidRequests(original.getBidRequests());
        builder.effectiveYield(original.getEffectiveYield());
        builder.estimatedLoss(original.getEstimatedLoss());
        builder.estimatedReturn(original.getEstimatedReturn());
        builder.orderStatus(original.getOrderStatus());
        builder.source(original.getSource());
        builder.orderDate(original.getOrderDate());
        builder.orderAmount(original.getOrderAmount());
        builder.orderAmountInvested(original.getOrderAmountInvested());
        builder.orderAmountPlaced(original.getOrderAmountPlaced());
        return builder;
    }
    
}
