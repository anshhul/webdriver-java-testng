package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public final class OrderSource {

    @JsonProperty("order_source_type")
    private String orderSourceType;

    @JsonIgnore
    @JsonProperty("saved_search")
    private SavedSearch savedSearch;

    public String getOrderSourceType() {
        return orderSourceType;
    }

    public SavedSearch getSavedSearch() {
        return savedSearch;
    }

    public void setOrderSourceType(final String orderSourceType) {
        this.orderSourceType = orderSourceType;
    }

    public void setSavedSearch(final SavedSearch savedSearch) {
        this.savedSearch = savedSearch;
    }

}
