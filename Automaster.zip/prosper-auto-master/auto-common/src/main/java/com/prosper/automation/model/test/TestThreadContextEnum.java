package com.prosper.automation.model.test;

/**
 * Created by rsubramanyam on 6/13/16.
 */
public enum TestThreadContextEnum {
    SAUCE_RUN("SAUCE_RUN_ID"),
    SAUCE_SESSION_ID("SAUCE_SESSION_ID"),
    JS_ERRORS("JS_ERRORS");
    private String name;
    TestThreadContextEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
