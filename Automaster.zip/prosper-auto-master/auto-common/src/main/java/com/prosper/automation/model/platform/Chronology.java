
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"calendarType", "id"})
public final class Chronology {
    
    @JsonProperty("calendarType")
    private String calendarType;
    @JsonProperty("id")
    private String id;
    
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Chronology that = (Chronology) o;
        return Objects.equal(calendarType, that.calendarType) && Objects.equal(id, that.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(calendarType, id);
    }
}
