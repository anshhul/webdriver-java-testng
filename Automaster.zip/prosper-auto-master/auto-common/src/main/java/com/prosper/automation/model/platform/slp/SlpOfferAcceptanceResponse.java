
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SlpOfferAcceptanceResponse {
    
    private String offerId;
    private String purchaseId;
    
    
    @JsonProperty("offer_id")
    public String getOfferId() {
        return offerId;
    }
    
    @JsonProperty("purchase_id")
    public String getPurchaseId() {
        return purchaseId;
    }
    
    public void setOfferId(final String offerId) {
        this.offerId = offerId;
    }
    
    public void setPurchaseId(final String purchaseId) {
        this.purchaseId = purchaseId;
    }
    
}
