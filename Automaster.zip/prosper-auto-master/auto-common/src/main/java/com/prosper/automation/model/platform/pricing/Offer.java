
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public final class Offer {
    @JsonProperty("external_loan_offer_id")
    private String externalLoanOfferId;
    @JsonProperty("loan_amount")
    private Integer loanAmount;
    @JsonProperty("rate_offered")
    private Double rateOffered;
    @JsonProperty("apr")
    private Double apr;
    @JsonProperty("origination_fee")
    private Integer originationFee;
    @JsonProperty("monthly_payment")
    private Double monthlyPayment;
    @JsonProperty("term")
    private Integer term;
    @JsonProperty("offer_type")
    private String offerType;
    @JsonProperty("finance_charge")
    private Double financeCharge;
    @JsonProperty("is_offer_valid")
    private Boolean isOfferValid;
    @JsonProperty("origination_fee_percent")
    private Double originationFeePercent;
    @JsonProperty("servicing_fee_percent")
    private Double servicingFeePercent;
    @JsonProperty("product_spec_id")
    private String productSpecId;
    @JsonProperty("prosper_rating_type_id")
    private Integer prosperRatingTypeId;
    @JsonProperty("lender_yield")
    private Double lenderYield;
    @JsonProperty("effective_yield")
    private Double effectiveYield;
    @JsonProperty("loan_cap")
    private Integer loanCap;
    @JsonProperty("total_paid_back")
    private Double totalPaidBack;
    @JsonProperty("last_payment")
    private Double lastPayment;
    @JsonProperty("amount_financed")
    private Double amountFinanced;
    @JsonProperty("offer_date")
    private String offerDate;
    @JsonProperty("first_payment_due_date")
    private String firstPaymentDueDate;
    @JsonProperty("final_payment_due_date")
    private String finalPaymentDueDate;
    @JsonProperty("loan_product")
    private String loanProduct;
    @JsonProperty("loan_offer_score_id")
    private String loanOfferScoreId;
    @JsonProperty("loan_offer_id")
    private String loanOfferId;
    @JsonProperty("average_apr")
    private Double averageApr;
    @JsonProperty("prospect_loan_offer_score_id")
    private String prospectLoanOfferScoreId;
    @JsonProperty("prospect_id")
    private String prospectId;
    @JsonProperty("go_to_rate")
    private Double goToRate;
    @JsonProperty("promo_monthly_payment")
    private Double promoMonthlyPayment;
    @JsonProperty("promo_term")
    private int promoTerm;
    @JsonProperty("promo_payoff_monthly_payment")
    private Double promoPayoffMonthlyPayment;
    @JsonProperty("intro_prin_pay_rate")
    private Double introPrinPayRate;
    @JsonProperty("user_id")
    private Long userId;

    public void setLoanOfferId(String loanOfferId) {
        this.loanOfferId = loanOfferId;
    }

    public Integer getLoanAmount() {
        return loanAmount;
    }

    public Double getRateOffered() {
        return rateOffered;
    }

    public Double getApr() {
        return apr;
    }

    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    public Integer getOriginationFee() {
        return originationFee;
    }

    public Integer getTerm() {
        return term;
    }

    public String getOfferType() {
        return offerType;
    }

    public Double getFinanceCharge() {
        return financeCharge;
    }

    public Boolean getOfferValid() {
        return isOfferValid;
    }

    public Double getOriginationFeePercent() {
        return originationFeePercent;
    }

    public Double getServicingFeePercent() {
        return servicingFeePercent;
    }

    public String getProductSpecId() {
        return productSpecId;
    }

    public Integer getProsperRatingTypeId() {
        return prosperRatingTypeId;
    }

    public Double getLenderYield() {
        return lenderYield;
    }

    public Double getEffectiveYield() {
        return effectiveYield;
    }

    public Integer getLoanCap() {
        return loanCap;
    }

    public String getLoanProduct() {
        return loanProduct;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @JsonIgnore
    public String getLoanOfferId() {
        return loanOfferId;
    }

    public String getExternalLoanOfferId() {
        return externalLoanOfferId;
    }

    public String getProspectLoanOfferScoreId() {
        return prospectLoanOfferScoreId;
    }

    public String getProspectId() {
        return prospectId;
    }

    public String getOfferDate() {
        return offerDate;
    }

    public void setExternalLoanOfferId(String externalLoanOfferId) {
        this.externalLoanOfferId = externalLoanOfferId;
    }

    public void setProspectLoanOfferScoreId(String prospectLoanOfferScoreId) {
        this.prospectLoanOfferScoreId = prospectLoanOfferScoreId;
    }

    public void setProspectId(String prospectId) {
        this.prospectId = prospectId;
    }

    public String getLoanOfferScoreId() {
        return loanOfferScoreId;
    }

    public void setLoanOfferScoreId(String loanOfferScoreId) {
        this.loanOfferScoreId = loanOfferScoreId;
    }
}
