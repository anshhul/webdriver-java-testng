package com.prosper.automation.util;

import com.prosper.automation.model.test.TestLogger;

/**
 * Created by rsubramanyam on 6/12/16.
 */
public final class CustomLogger {

    public static TestLogger getLogger(java.lang.String name) {
        return new TestLogger(name);
    }

}
