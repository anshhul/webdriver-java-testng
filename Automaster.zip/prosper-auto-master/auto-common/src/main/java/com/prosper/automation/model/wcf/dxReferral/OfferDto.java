
package com.prosper.automation.model.wcf.dxReferral;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JacksonXmlRootElement(localName = "TheOfferDto")
public final class OfferDto {

    @JacksonXmlProperty(localName = "Id")
    private Long id;
    @JacksonXmlProperty(localName = "APR")
    private Double apr;
    @JacksonXmlProperty(localName = "LoanAmount")
    private Double loanAmount;
    @JacksonXmlProperty(localName = "LoanRate")
    private Double loanRate;
    @JacksonXmlProperty(localName = "LoanTerm")
    private Integer loanTerm;
    @JacksonXmlProperty(localName = "MonthlyPayment")
    private Double monthlyPayment;
    @JacksonXmlProperty(localName = "ShowSelectedOfferUrl")
    private String showSelectedOfferUrl;


    public Long getId() {
        return id;
    }

    public Double getApr() {
        return apr;
    }

    public Double getLoanAmount() {
        return loanAmount;
    }

    public Double getLoanRate() {
        return loanRate;
    }

    public Integer getLoanTerm() {
        return loanTerm;
    }

    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    public String getShowSelectedOfferUrl() {
        return showSelectedOfferUrl;
    }
}
