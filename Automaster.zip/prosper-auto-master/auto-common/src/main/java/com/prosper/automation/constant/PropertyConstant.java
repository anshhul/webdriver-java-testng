
package com.prosper.automation.constant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PropertyConstant {
    
    public static final String TIER = "tier";
    
    public static final String HTTP_CLIENT_CONNECTION_TIMEOUT = "http.client.connection.timeout";
    public static final String HTTP_CLIENT_SOCKET_TIMEOUT = "http.client.socket.timeout";
    
    public static final String GDS_CLIENT_CONNECTION_TIMEOUT = "http.gds.client.connection.timeout";
    public static final String GDS_CLIENT_SOCKET_TIMEOUT = "http.gds.socket.timeout";
    public static final String GDS_STANDALONE_PROTOCOL = "gds.standalone.protocol";
    public static final String GDS_STANDALONE_HOST = "gds.standalone.host.name";
    public static final String GDS_PAYLOAD_CSV = "gds.direct.payload.csv.path";
    public static final String GDS_RESPONSE_CSV = "gds.direct.response.csv.path";
    
    public static final String PLATFORM_HOST_PROTOCOL = "platform.host.protocol";
    public static final String PLATFORM_SECURITY_HOST = "platform.security.host.name";
    public static final String PLATFORM_USER_HOST = "platform.user.host.name";
    public static final String PLATFORM_OFFER_HOST = "platform.offer.host.name";
    public static final String PLATFORM_INQUIRY_HOST = "platform.inquiry.host.name";
    public static final String PLATFORM_EMAIL_HOST = "platform.email.host.name";
    public static final String PLATFORM_ACCOUNT_HOST = "platform.account.host.name";
    public static final String PLATFORM_PROSPECT_HOST = "platform.prospect.host.name";
    public static final String PLATFORM_LISTING_HOST = "platform.listing.host.name";
    public static final String PLATFORM_AFFILIATE_REFERRAL = "platform.affiliate.referral.host.name";
    public static final String PLATFORM_DOCUMENT_HOST = "platform.document.host.name";
    public static final String PLATFORM_ORDER_HOST = "platform.order.host.name";
    public static final String PLATFORM_SLP_OFFERS_HOST = "platform.slp.host.name";
    public static final String PLATFORM_LOAN_HOST = "platform.loan.host.name";
    public static final String PLATFORM_LOCATION_HOST = "platform.location.host.name";
    public static final String PLATFORM_SEARCH_HOST = "platform.search.host.name";
    public static final String PLATFORM_BANK_VALIDATION_HOST = "platform.bank.validation.host.name";
    
    public static final String OAUTH_CLIENT_ID = "oauth.client.id";
    public static final String OAUTH_CLIENT_SECRET = "oauth.client.secret";
    public static final String OAUTH_ADMIN_CLIENT_ID = "oauth.admin.client.id";
    public static final String OAUTH_ADMIN_CLIENT_SECRET = "oauth.admin.client.secret";
    public static final String OAUTH_REGISTERED_CLIENT_ID = "oauth.registered.client.id";
    public static final String OAUTH_REGISTERED_CLIENT_SECRET = "oauth.registered.client.secret";
    
    public static final String WCF_HOST_PROTOCOL = "wcf.host.protocol";
    public static final String WCF_DX_REFERRAL_HOST = "wcf.dxReferral.host.name";
    public static final String WCF_USER_NAME = "wcf.user.name";
    public static final String WCF_USER_PASSWORD = "wcf.user.password";
    
    public static final String DB_CIRCLEONE = "db_circleone";
    public static final String DATABASE_CIRCLEONE_HOST = "database.circleone.host";
    public static final String DATABASE_CIRCLEONE_PORT = "database.circleone.port";
    public static final String DATABASE_CIRCLEONE_USER = "database.circleone.user";
    public static final String DATABASE_CIRCLEONE_PASSWORD = "database.circleone.password";
    
    public static final String DB_API = "db_api";
    public static final String DATABASE_API_HOST = "database.api.host";
    public static final String DATABASE_API_PORT = "database.api.port";
    public static final String DATABASE_API_USER = "database.api.user";
    public static final String DATABASE_API_PASSWORD = "database.api.password";
    
    public static final String DB_BANK_VALIDATION = "db_bank_validation";
    public static final String DATABASE_BANK_VALIDATION_HOST = "database.bank.validation.host";
    public static final String DATABASE_BANK_VALIDATION_PORT = "database.bank.validation.port";
    public static final String DATABASE_BANK_VALIDATION_USER = "database.bank.validation.user";
    public static final String DATABASE_BANK_VALIDATION_PASSWORD = "database.bank.validation.password";
    
    public static final String PRICING_TEST_STATE = "pricing.test.state";
    public static final String PRICING_TEST_FILE_PATH = "pricing.test.file.path";
    public static final String PRICING_TEST_FILE_VERSION = "pricing.test.file.version";
    
    public static final String SCORE_CARD_TEST_FILE_PATH = "score.card.test.file.path";
    
    public static final String LISTING_HOLD_FILE_PATH = "gds.listing.holds.file.path";
    
    public static final String EXCHANGE_SERVER_HOST = "exchange.server.host";
    public static final String EXCHANGE_EMAIL_USER = "exchange.email.user";
    public static final String EXCHANGE_EMAIL_PASSWORD = "exchange.email.password";
    
    public static final String MAX_POLL_TIME = "maximum.poll.time";
    
    // When production mode is set to true, we do not expect duplicate SSN insertion to
    // the database.
    public static final String PRODUCTION_MODE = "production.mode";
    
    public static final String METRICS_OUTPUT_DIRECTORY = "metrics.output.directory";
    
    public static final String SOLR_HOST = "solr.host.name";
    public static final String SOLR_HOST_PROTOCOL = "solr.host.protocol";
    
    
    private PropertyConstant() {
    }
}
