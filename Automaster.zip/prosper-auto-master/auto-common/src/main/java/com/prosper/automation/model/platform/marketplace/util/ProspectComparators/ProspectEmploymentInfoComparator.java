package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.EmploymentInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectEmploymentInfoComparator implements Comparator<EmploymentInfo> {

    @Override public int compare(EmploymentInfo left, EmploymentInfo right) {
        // Employment Info
        if (right != null ?
                !left.getEmployerName().equals(right.getEmployerName()) :
                left != null)
            return 1;
        if (Double.compare(left.getAnnualIncome().doubleValue(),
                right.getAnnualIncome().doubleValue()) != 0)
            return 1;
        if (right.getEmployerName() != null && !left.getEmployerName()
                .equals(right.getEmployerName()))
            return 1;
        if (right.getOccupationId() != null && !left.getOccupationId()
                .equals(right.getOccupationId()))
            return 1;
        if (left.getEmploymentMonth() != (right.getEmploymentMonth()))
            return 1;
        if (left.getEmploymentYear().intValue() != (right.getEmploymentYear().intValue()))
            return 1;
        if (right.getEmployerPhone() != null
                && right.getEmployerPhone().getPhoneNumber() != null && !left
                .getEmployerPhone().getPhoneNumber()
                .equalsIgnoreCase(right.getEmployerPhone().getPhoneNumber()))
            return 1;
        if (right.getEmployerPhone() != null
                && right.getEmployerPhone().getAreaCode() != null && !left
                .getEmployerPhone().getAreaCode()
                .equalsIgnoreCase(right.getEmployerPhone().getAreaCode()))
            return 1;
        return 0;
    }
}
