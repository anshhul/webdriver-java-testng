
package com.prosper.automation.asserts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.prosper.automation.model.BorrowerPricingData;
import com.prosper.automation.model.platform.pricing.PricingBin;
import com.prosper.automation.model.platform.pricing.PricingResponse;

/**
 * Created by pbudiono on 5/19/16.
 */
public final class PricingTestAssert extends Assert {

    private static final Logger LOG = Logger.getLogger(PricingTestAssert.class.getSimpleName());

    private static final String BIN_COMPARISON_ERROR_TEMPLATE = "Comparing %s; service response: %d; excel data: %d.\n";

    public static void assertPricing(SoftAssert softAssert, BorrowerPricingData pricingData, PricingResponse pricingResponse ,Long applicantId) {

        try {
            softAssert.assertAll();
        } catch (AssertionError ae) {
            fail(ae, pricingData, pricingResponse,applicantId);
        }
    }

    private static void fail(AssertionError error, BorrowerPricingData pricingData, PricingResponse pricingResponse, Long applicantId) {
        StringBuilder errorMessageBuilder = new StringBuilder(error.getMessage() + "\n");

        for (final PricingBin pricingBin : pricingResponse.getPricingBins()) {

            final String serviceBinName = pricingBin.gePricingBinType().getPricingTableColumnName();
            final Integer serviceBinValue = pricingBin.getBinID();

            Integer excelBinValue = null;
            if (serviceBinName.equals("DTIBin")) {
                excelBinValue = pricingData.getDtiWoProspLoanBin();
            } else if (serviceBinName.equals("PMIBin")) {
                excelBinValue = pricingData.getPmi61Bin();
            } else if (serviceBinName.equals("MonthlyIncomeBin")) {
                excelBinValue = pricingData.getMonthlyIncomeBin();
            } else if (serviceBinName.equals("PartnershipBin")) {
                excelBinValue = pricingData.getPartnershipBin();
            } else if (serviceBinName.equals("PreviousLoanBin")) {
                excelBinValue = pricingData.getPreviousLoanBin();
            } else if (serviceBinName.equals("ScoreBin")) {
                excelBinValue = pricingData.getFicoBin();
            } else if (serviceBinName.equals("InquiryBin")) {
                excelBinValue = pricingData.getInquiryBin();
            } else if (serviceBinName.equals("RevBalBin")) {
                excelBinValue = pricingData.getRevbalBin();
            } else if (serviceBinName.equals("Zip3Bin")) {
                excelBinValue = pricingData.getZip3Bin();
            } else if (serviceBinName.equals("DTI10KChgBin")) {
                excelBinValue = pricingData.getDti10KChgBin();
            } else if (serviceBinName.equals("SuperPrimeBin")) {
                excelBinValue = pricingData.getSuperPrimeBin();
            } else if (serviceBinName.equals("SuperPrimeTCBin")) {
                excelBinValue = pricingData.getSuperPrimeTCBin();
            } else if (serviceBinName.equals("TDCBin")) {
                excelBinValue = pricingData.getTdcBin();
            } else if (serviceBinName.equals("CategoryBin")) {
                excelBinValue = pricingData.getCateBin();
            } else if (serviceBinName.equals("LoanTermBin")) {
                excelBinValue = pricingData.getLoanTermBin();
            } else if (serviceBinName.equals("LoanAmountBin")) {
                excelBinValue = pricingData.getLoanAmountBin();
            } else if (serviceBinName.equals("PTFlagBin")) {
                excelBinValue = pricingData.getpTflagBin();
            } else if (serviceBinName.equals("EmployBin")) {
                excelBinValue = pricingData.getEmployBin();
            }else if (serviceBinName.equals("VantageBin")) {
                excelBinValue = pricingData.getVantageBin();
            }else if (serviceBinName.equals("FRABin")) {
                excelBinValue = pricingData.getFraBin();
            } else if (serviceBinName.equals("FRATCBin")) {
                excelBinValue = pricingData.getFraTcBinRand();
            }else if (serviceBinName.equals("UTLBin")) {
                excelBinValue = pricingData.getUtlBin();
            }else if (serviceBinName.equals("PMI9PCTBin")) {
                excelBinValue = pricingData.getPmi9PctBin();
            } else if (serviceBinName.equals("MoLastTradeBin")) {
                excelBinValue = pricingData.getMoLastTradeBin();
            } else {
                fail(String.format("Pricing bin %s is not recognized.", serviceBinName));
            }
            errorMessageBuilder
                    .append(String.format(BIN_COMPARISON_ERROR_TEMPLATE, serviceBinName, serviceBinValue, excelBinValue));
        }
        LOG.info("ApplicantId :: "+applicantId);
        LOG.info(errorMessageBuilder.toString());
        fail(errorMessageBuilder.toString());
    }

}
