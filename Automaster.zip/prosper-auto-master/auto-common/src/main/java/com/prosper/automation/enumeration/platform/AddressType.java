
package com.prosper.automation.enumeration.platform;

/**
 * An enumeration for address type.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum AddressType {
    NEW_DEFAULT(0, "New / Default"),
    UNDETERMINED(1, "Undetermined"),
    RESIDENTIAL(2, "Residential"),
    BUSINESS(3, "Business"),
    MIXED(4, "Mixed"),
    PO_BOX(5, "PO Box"),
    MILITARY(6, "Military");
    
    private int id;
    private String description;
    
    
    AddressType(final int id, final String description) {
        this.id = id;
        this.description = description;
    }
    
    public int getId() {
        return id;
    }
}
