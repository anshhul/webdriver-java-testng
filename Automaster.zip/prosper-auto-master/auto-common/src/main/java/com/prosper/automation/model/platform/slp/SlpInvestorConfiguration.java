
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public final class SlpInvestorConfiguration {

    @JsonProperty("slp_investor_config_id")
    private Long slpInvetorConfigId;
    
    @JsonProperty("user_id")
    private Long userId;
    
    @JsonProperty("monthly_investment_target")
    private Double monthlyInvestmentTarget;

    @JsonProperty("created_by")
    private Integer createdBy;
    
    @JsonProperty("buyer_first_name")
    private String buyerFirstName;
    
    @JsonProperty("buyer_last_name")
    private String buyerLastName;
    
    @JsonProperty("created_date")
    private String createdDate;
    
    @JsonProperty("modified_by")
    private Integer modifiedBy;
    
    @JsonProperty("modified_date")
    private String modifiedDate;
    
    @JsonProperty("fee_percentage")
    private Double feePercenatge;

    private Integer slpInvestorStatusId;
    
    @JsonProperty("investor_status")
    private String investorStatus;


    public static class SlpInvestorConfigurationBuilder {

        private String buyerFirstName;
        private String buyerLastName;
        private Integer createdBy;
        private String createdDate;
        private Double feePercenatge;
        private String investorStatus;
        private Integer modifiedBy;
        private String modifiedDate;
        private Double monthlyInvestmentTarget;
        private Integer slpInvestorStatusId;
        private Long slpInvetorConfigId;
        private Long userId;


        public SlpInvestorConfiguration build() {
            final SlpInvestorConfiguration result = new SlpInvestorConfiguration();

            result.setBuyerFirstName(buyerFirstName);
            result.setBuyerLastName(buyerLastName);
            result.setCreatedBy(createdBy);
            result.setCreatedDate(createdDate);
            result.setFeePercenatge(feePercenatge);
            result.setInvestorStatus(investorStatus);
            result.setModifiedBy(modifiedBy);
            result.setModifiedDate(modifiedDate);
            result.setMonthlyInvestmentTarget(monthlyInvestmentTarget);
            result.setSlpInvestorStatusId(slpInvestorStatusId);
            result.setSlpInvetorConfigId(slpInvetorConfigId);
            result.setUserId(userId);
            return result;
        }

        public SlpInvestorConfigurationBuilder buyerFirstName(final String value) {
            this.buyerFirstName = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder buyerLastName(final String value) {
            this.buyerLastName = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder createdBy(final Integer value) {
            this.createdBy = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder createdDate(final String value) {
            this.createdDate = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder feePercenatge(final Double value) {
            this.feePercenatge = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder investorStatus(final String value) {
            this.investorStatus = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder modifiedBy(final Integer value) {
            this.modifiedBy = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder modifiedDate(final String value) {
            this.modifiedDate = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder monthlyInvestmentTarget(final Double value) {
            this.monthlyInvestmentTarget = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder slpInvestorStatusId(final Integer value) {
            this.slpInvestorStatusId = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder slpInvetorConfigId(final Long value) {
            this.slpInvetorConfigId = value;
            return this;
        }

        public SlpInvestorConfigurationBuilder userId(final Long value) {
            this.userId = value;
            return this;
        }
    }
    
    
    public static SlpInvestorConfigurationBuilder buildUpon(final SlpInvestorConfiguration original) {
        final SlpInvestorConfigurationBuilder builder = newBuilder();
        builder.buyerFirstName(original.getBuyerFirstName());
        builder.buyerLastName(original.getBuyerLastName());
        builder.createdBy(original.getCreatedBy());
        builder.createdDate(original.getCreatedDate());
        builder.feePercenatge(original.getFeePercenatge());
        builder.investorStatus(original.getInvestorStatus());
        builder.modifiedBy(original.getModifiedBy());
        builder.modifiedDate(original.getModifiedDate());
        builder.monthlyInvestmentTarget(original.getMonthlyInvestmentTarget());
        builder.slpInvestorStatusId(original.getSlpInvestorStatusId());
        builder.slpInvetorConfigId(original.getSlpInvetorConfigId());
        builder.userId(original.getUserId());
        return builder;
    }

    public static SlpInvestorConfigurationBuilder newBuilder() {
        return new SlpInvestorConfigurationBuilder();
    }

    /**
     * @return the buyerFirstName
     */
    public String getBuyerFirstName() {
        return buyerFirstName;
    }

    /**
     * @return the buyerLastName
     */
    public String getBuyerLastName() {
        return buyerLastName;
    }

    /**
     * @return the createdBy
     */
    public Integer getCreatedBy() {
        return createdBy;
    }

    /**
     * @return the createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * @return the feePercenatge
     */
    public Double getFeePercenatge() {
        return feePercenatge;
    }

    /**
     * @return the investorStatus
     */
    public String getInvestorStatus() {
        return investorStatus;
    }

    /**
     * @return the modifiedBy
     */
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    /**
     * @return the modifiedDate
     */
    public String getModifiedDate() {
        return modifiedDate;
    }

    /**
     * @return the monthlyInvestmentTarget
     */
    public Double getMonthlyInvestmentTarget() {
        return monthlyInvestmentTarget;
    }

    /**
     * @return the slpInvestorStatusId
     */
    public Integer getSlpInvestorStatusId() {
        return slpInvestorStatusId;
    }

    /**
     * @return the slpInvetorConfigId
     */
    public Long getSlpInvetorConfigId() {
        return slpInvetorConfigId;
    }

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param buyerFirstName the buyerFirstName to set
     */
    public void setBuyerFirstName(final String buyerFirstName) {
        this.buyerFirstName = buyerFirstName;
    }

    /**
     * @param buyerLastName the buyerLastName to set
     */
    public void setBuyerLastName(final String buyerLastName) {
        this.buyerLastName = buyerLastName;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(final Integer createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @param feePercenatge the feePercenatge to set
     */
    public void setFeePercenatge(final Double feePercenatge) {
        this.feePercenatge = feePercenatge;
    }

    /**
     * @param investorStatus the investorStatus to set
     */
    public void setInvestorStatus(final String investorStatus) {
        this.investorStatus = investorStatus;
    }

    /**
     * @param modifiedBy the modifiedBy to set
     */
    public void setModifiedBy(final Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    /**
     * @param modifiedDate the modifiedDate to set
     */
    public void setModifiedDate(final String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    /**
     * @param monthlyInvestmentTarget the monthlyInvestmentTarget to set
     */
    public void setMonthlyInvestmentTarget(final Double monthlyInvestmentTarget) {
        this.monthlyInvestmentTarget = monthlyInvestmentTarget;
    }
    
    /**
     * @param slpInvestorStatusId the slpInvestorStatusId to set
     */
    public void setSlpInvestorStatusId(final Integer slpInvestorStatusId) {
        this.slpInvestorStatusId = slpInvestorStatusId;
    }
    
    /**
     * @param slpInvetorConfigId the slpInvetorConfigId to set
     */
    public void setSlpInvetorConfigId(final Long slpInvetorConfigId) {
        this.slpInvetorConfigId = slpInvetorConfigId;
    }
    
    /**
     * @param userId the userId to set
     */
    public void setUserId(final Long userId) {
        this.userId = userId;
    }

}
