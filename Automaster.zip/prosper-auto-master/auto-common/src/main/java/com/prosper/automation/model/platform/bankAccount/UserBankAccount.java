
package com.prosper.automation.model.platform.bankAccount;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.BankAccountInfo;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UserBankAccount {

    @JsonProperty("bank_routing")
    private BankRouting bankRouting;
    @JsonProperty("account")
    private Account account;
    @JsonProperty("bank_account")
    private BankAccountInfo bankAccount;


    public UserBankAccount() {
    }

    private UserBankAccount(final Builder builder) {
        bankRouting = builder.bankRouting;
        account = builder.account;
        bankAccount = builder.bankAccount;
    }

    public BankAccountInfo getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(final BankAccountInfo bankAccount) {
        this.bankAccount = bankAccount;
    }

    @JsonIgnore
    public Account getAccount() {
        return account;
    }

    public void setAccount(final Account account) {
        this.account = account;
    }


    public static final class Builder {

        private BankRouting bankRouting;
        private Account account;
        private BankAccountInfo bankAccount;


        public Builder() {
        }

        public Builder withBankRouting(final BankRouting bankRouting) {
            this.bankRouting = bankRouting;
            return this;
        }

        public Builder withAccount(final Account account) {
            this.account = account;
            return this;
        }

        public Builder withBankAccount(final BankAccountInfo bankAccount) {
            this.bankAccount = bankAccount;
            return this;
        }

        public UserBankAccount build() {
            return new UserBankAccount(this);
        }
    }
}
