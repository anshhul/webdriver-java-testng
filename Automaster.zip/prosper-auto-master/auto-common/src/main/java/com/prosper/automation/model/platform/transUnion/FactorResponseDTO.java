
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
public class FactorResponseDTO {

    @JsonProperty("rank")
    private String rank;
    @JsonProperty("code")
    private String code;
    @JsonProperty("description")
    private String description;


    public FactorResponseDTO() {
    }

    private FactorResponseDTO(Builder builder) {
        rank = builder.rank;
        code = builder.code;
        description = builder.description;
    }

    @JsonIgnore
    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    @JsonIgnore
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @JsonIgnore
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public static final class Builder {

        private String rank;
        private String code;
        private String description;


        public Builder() {
        }

        public Builder withRank(String val) {
            rank = val;
            return this;
        }

        public Builder withCode(String val) {
            code = val;
            return this;
        }

        public Builder withDescription(String val) {
            description = val;
            return this;
        }

        public FactorResponseDTO build() {
            return new FactorResponseDTO(this);
        }
    }
}
