package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 6/16/16.
 */
public class OffersUnfundedRequest {

    @JsonProperty("listing_id")
    private String listingId;
    @JsonProperty("user_id")
    private String userId;

    public OffersUnfundedRequest(String listingId, String userId) {
        this.listingId = listingId;
        this.userId = userId;
    }

    public String getListingId() {
        return listingId;
    }

    public String getUserId() {
        return userId;
    }
}
