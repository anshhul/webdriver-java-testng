
package com.prosper.automation.constant.web;

/**
 * Created by ramkaur on 12/6/16.
 */
public class SupportSitePageMemberConstants {



    public static final String ECOA_DESIGNATOR = "EcoaDesignator";
    public static final String DATE_OPENED = "DateOpened";
    public static final String DATE_EFFECTIVE = "DateEffective";
    public static final String CURRENT_BALANCE = "CurrentBalance";
    public static final String HIGH_CREDIT = "HighCredit";
    public static final String TERMS_PAYMENT_FREQUENCY = "TermsPaymentFrequency";
    public static final String TERMS_PAYMENT_SCHEDULED_MONTH_COUNT = "TermsPaymentScheduleMonthCount";
    public static final String TERMS_SCHEDULED_MONTHLY_PAYMENT = "TermsScheduledMonthlyPayment";
    public static final String PAST_DUE = "PastDue";
    public static final String PAYMENT_HISTORY_MAX_DELINQUENCY_EARLIEST = "PaymentHistoryMaxDelinquencyEarliest";
    public static final String PAYMENT_HISTORY_PAYMENT_PATTERN_START_DATE = "PaymentHistoryPaymentPatternStartDate";
    public static final String PAYMENT_HISTORY_HISTORICAL_COUNTERS_MONTHS_REVIEWED_COUNT =
            "PaymentHistoryHistoricalCountersMonthsReviewedCount";
    public static final String PAYMENT_HISTORY_HISTORICAL_COUNTERS_LATE_30DAYS =
            "PaymentHistoryHistoricalCountersLate30DaysTotal";
    public static final String PAYMENT_HISTORY_HISTORICAL_COUNTERS_LATE_60DAYS =
            "PaymentHistoryHistoricalCountersLate60DaysTotal";
    public static final String PAYMENT_HISTORY_HISTORICAL_COUNTERS_LATE_90DAYS =
            "PaymentHistoryHistoricalCountersLate90DaysTotal";
    public static final String PORTFOLIONAME_TYPE = "PortfolioNameType";
    public static final String ACCOUNT_NUMBER = "AccountNumber";
    public static final String REPORTING_SUBSCRIBER_NAME = "ReportingSubscriberName";
    public static final String PORTFOLIO_NAME_TYPE = "PortfolioNameType";
    public static final String ADDRESS = "Address";
    public static final String POBOX = "PoBox";
    public static final String ADDRESS_STATUS = "AddressStatus";
    public static final String FIRST_REPORTED = "First reported";
    public static final String QUALIFIER = "Qualifier";
    public static final String INQUIRY_SUBSCRIBER_INDUSTRY_CODE = "InquirySubscriberIndustryCode";
    public static final String INQUIRY_SUBSCRIBER_MEMBER_CODE = "InquirySubscriberMemberCode";
    public static final String INQUIRY_SUBSCRIBER_NAME = "InquirySubscriberName";
    public static final String INQUIRY_SUBSCRIBER_PREFIX_CODE = "InquirySubscriberPrefixCode";
    public static final String REQUESTOR = "Requestor";
    public static final String ACCOUNT_TYPE = "AccountType";
    public static final String INQUIRY_DATE = "InquiryDate";

}
