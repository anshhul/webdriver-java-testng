
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 5/26/16.
 */
public final class GDSHold {

    @JsonProperty("WorkflowId")
    private String workflowId;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Action")
    private String action;


    @JsonIgnore
    public String getWorkflowId() {
        return workflowId;
    }

    @JsonIgnore
    public String getType() {
        return type;
    }

    @JsonIgnore
    public String getAction() {
        return action;
    }
}
