
package com.prosper.automation.util;

import com.prosper.automation.exception.AutomationException;

import org.apache.log4j.Logger;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * A utility class to create output automation artifact(s).
 *
 * @author pbudiono
 * @since 0.0.1
 */
public class OutputUtilities {
    
    private static final Logger LOG = Logger.getLogger(OutputUtilities.class.getSimpleName());
    
    
    /**
     * Write a list of object into a file (line separated).
     *
     * @param outputFilePath
     * @param aList
     * @throws AutomationException
     */
    public static void writeToFile(final String outputFilePath, final List<? extends Object> aList) throws AutomationException {
        LOG.info(String.format("Outputting automation artifact to %s", outputFilePath));
        try (final FileWriter fileWriter = new FileWriter(outputFilePath)) {
            for (final Object object : aList) {
                fileWriter.append(String.format("%s\n", object.toString()));
            }
        } catch (IOException ex) {
            throw new AutomationException(ex.toString());
        }
    }
}
