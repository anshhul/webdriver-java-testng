
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.merchant.Merchant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UserInfo {

    @JsonProperty("addressInfo")
    private AddressInfo addressInfo;
    @JsonProperty("employmentInfo")
    private EmploymentInfo employmentInfo;
    @JsonProperty("initial_requested_listing_category_id")
    private String inCategory;
    @JsonProperty("initial_amount_requested")
    private Double inLoanAmount;
    @JsonProperty("merchant")
    private Merchant merchant;
    @JsonProperty("id")
    private Integer userid;

    public UserInfo() {
    }

    private UserInfo(final Builder builder) {
        addressInfo = builder.addressInfo;
        employmentInfo = builder.employmentInfo;
        inCategory = builder.inCategory;
        inLoanAmount = builder.inLoanAmount;
        merchant =  builder.merchant;
        userid = builder.userid;
    }

    @JsonIgnore
    public EmploymentInfo getEmploymentInfo() {
        return employmentInfo;
    }


    public static final class Builder {

        private AddressInfo addressInfo;
        private EmploymentInfo employmentInfo;
        private String inCategory;
        private Double inLoanAmount;
        private Merchant merchant;
        private Integer userid;
        public Builder() {
        }

        public Builder withUserId(final Integer userid) {
            this.userid = userid;
            return this;
        }

        public Builder withMerchantInfo(final Merchant merchantInfo) {
            this.merchant = merchantInfo;
            return this;
        }

        public Builder withAddressInfo(final AddressInfo addressInfo) {
            this.addressInfo = addressInfo;
            return this;
        }

        public Builder withEmploymentInfo(final EmploymentInfo employmentInfo) {
            this.employmentInfo = employmentInfo;
            return this;
        }

        public Builder withInitialAmountRequested(final Double inLoanAmount) {
            this.inLoanAmount = inLoanAmount;
            return this;
        }

        public Builder withInitialRequestedListingCategoryId(final String inCategory) {
            this.inCategory = inCategory;
            return this;
        }

        public UserInfo build() {
            return new UserInfo(this);
        }
    }
}
