
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.sql.Timestamp;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PartnerOauthInfo {

    @JsonProperty("partner_oauth_id")
    private Integer partnerOauthId;

    @JsonProperty("external_client_id")
    private String externalClientId;

    @JsonProperty("campaign_source_id")
    private String campaignSourceId;

    private String modifiedBy;
    private Timestamp createdDate;
    private Timestamp modifiedDate;
    private Timestamp versionStartDate;
    private Timestamp versionEndDate;


    public PartnerOauthInfo() {
    }

    private PartnerOauthInfo(final Builder builder) {
        partnerOauthId = builder.partnerOauthId;
        externalClientId = builder.externalClientId;
        campaignSourceId = builder.campaignSourceId;
        createdDate = builder.createdDate;
        modifiedDate = builder.modifiedDate;
        modifiedBy = builder.modifiedBy;
        versionStartDate = builder.versionStartDate;
        versionEndDate = builder.versionEndDate;
    }

    @JsonIgnore
    public Integer getPartnerOauthId() {
        return partnerOauthId;
    }

    @JsonIgnore
    public String getExternalClientId() {
        return externalClientId;
    }

    @JsonIgnore
    public String getCampaignSourceId() {
        return campaignSourceId;
    }

    @JsonIgnore
    public Timestamp getCreatedDate() {
        return createdDate;
    }

    @JsonIgnore
    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    @JsonIgnore
    public String getModifiedBy() {
        return modifiedBy;
    }

    @JsonIgnore
    public Timestamp getVersionStartDate() {
        return versionStartDate;
    }

    @JsonIgnore
    public Timestamp getVersionEndDate() {
        return versionEndDate;
    }

    @Override

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PartnerOauthInfo that = (PartnerOauthInfo) o;
        return Objects.equal(getExternalClientId(), that.getExternalClientId())
                && Objects.equal(getCampaignSourceId(), that.getCampaignSourceId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPartnerOauthId(), getExternalClientId(), getCampaignSourceId(), getCreatedDate(),
                getModifiedDate(), getModifiedBy());
    }


    public static final class Builder {

        private Integer partnerOauthId;
        private String externalClientId;
        private String campaignSourceId;
        private Timestamp createdDate;
        private Timestamp modifiedDate;
        private String modifiedBy;
        private Timestamp versionStartDate;
        private Timestamp versionEndDate;


        public Builder() {
        }

        public Builder withPartnerOauthId(Integer val) {
            partnerOauthId = val;
            return this;
        }

        public Builder withExternalClientId(String val) {
            externalClientId = val;
            return this;
        }

        public Builder withCampaignSourceId(String val) {
            campaignSourceId = val;
            return this;
        }

        public Builder withCreatedDate(Timestamp val) {
            createdDate = val;
            return this;
        }

        public Builder withModifiedDate(Timestamp val) {
            modifiedDate = val;
            return this;
        }

        public Builder withModifiedBy(String val) {
            modifiedBy = val;
            return this;
        }

        public Builder withVersionStartDate(Timestamp val) {
            versionStartDate = val;
            return this;
        }

        public Builder withVersionEndDate(Timestamp val) {
            versionEndDate = val;
            return this;
        }

        public PartnerOauthInfo build() {
            return new PartnerOauthInfo(this);
        }
    }
}
