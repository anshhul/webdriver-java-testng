
package com.prosper.automation.model.testdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prosper.automation.model.platform.pricing.Offer;

import java.util.List;
import java.util.Map;

/**
 * Created by pbudiono on 7/19/16.
 */
public final class BorrowerTestData {

    private static final String LOG_TEMPLATE = "Borrower test data. (email: %s, user_data: %s, listing_ids: %s";

    private String email;
    private Long userId;
    private Map<String, String> userData;
    private List<Offer> offers;
    private List<Long> listingIDs;


    private BorrowerTestData(Builder builder) {
        email = builder.email;
        userId = builder.userId;
        userData = builder.userData;
        offers = builder.offers;
        listingIDs = builder.listingIDs;
    }

    public List<Long> getListingId() {
        return listingIDs;
    }

    @Override
    public String toString() {
        return String.format(LOG_TEMPLATE, email, userData, listingIDs);
    }

    @JsonIgnore
    public Long getUserId() {
        return userId;
    }

    public static final class Builder {

        private String email;
        private Long userId;
        private Map<String, String> userData;
        private List<Offer> offers;
        private List<Long> listingIDs;


        public Builder() {
        }

        public Builder withEmail(String val) {
            email = val;
            return this;
        }

        public Builder withUserId(Long val) {
            userId = val;
            return this;
        }

        public Builder withUserData(Map<String, String> val) {
            userData = val;
            return this;
        }

        public Builder withOffers(List<Offer> val) {
            offers = val;
            return this;
        }

        public Builder withListingIDs(List<Long> val) {
            listingIDs = val;
            return this;
        }

        public BorrowerTestData build() {
            return new BorrowerTestData(this);
        }
    }
}
