
package com.prosper.automation.model.platform.publishing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author ramkaur on 23 Nov, 2016
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"listing_id", "error_message"})
public final class PublishingListingFail {

    @JsonProperty("listing_id")
    private Integer listingId;
    @JsonProperty("error_message")
    private String errorMessage;


    public PublishingListingFail() {
    }

    private PublishingListingFail(final Builder builder) {
        listingId = builder.listingId;
        errorMessage = builder.errorMessage;

    }
    public static final class Builder {

        private Integer listingId;
        private String errorMessage;
        public Builder() {
        }

        public Builder withWorkflowTypeId(final Integer listingId) {
            this.listingId = listingId;
            return this;
        }

        public Builder withDescription(final String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        public PublishingListingFail build() {
            return new PublishingListingFail(this);
        }
    }
}
