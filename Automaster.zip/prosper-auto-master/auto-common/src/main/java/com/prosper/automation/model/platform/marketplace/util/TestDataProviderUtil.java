
package com.prosper.automation.model.platform.marketplace.util;

import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;

import java.util.UUID;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public final class TestDataProviderUtil {

    public static final String VALIDATION_ERRORS_COMMON_MESSAGE = "The applicant's data was missing or not formatted correctly.";
    public static final String TEST_DATA_LOAN_AMOUNT = "3000";
    public static final String TEST_DATA_EMP_EMAIL = "test@brn.com";
    public static final String TEST_CORY_EMAIL = "coreymyemail03012016@email.com";
    public static final String TEST_DATA_LOAN_PURPOSE = "1";
    public static final String TEST_DATA_LOAN_PURPOSE_IN_LMITS = "3";
    public static final String TEST_DATA_CREDIT_SCORE = "3";
    public static final String TEST_DATA_CREDIT_SCORE_INVALID = "30000";
    public static final String TEST_DATA_NON_MARY_FNAME = "Casimir";
    public static final String TEST_DATA_NON_MARY_LNAME = "Fellows";
    public static final String TEST_DATA_MA_STREET = "14 Beach St";
    public static final String TEST_DATA_MA_CITY = "Milford";
    public static final String TEST_DATA_MA_STATE = "MA";
    public static final String TEST_DATA_MA_ZIP = "01757";
    public static final String TEST_DATA_MD_STREET = "6451 WISHBONE TER";
    public static final String TEST_DATA_MD_CITY = "CABIN JOHN";
    public static final String TEST_DATA_MD_STATE = "MD";
    public static final String TEST_DATA_LONG_STATE = "California";
    public static final String TEST_DATA_MD_ZIP = "208181706";
    public static final String TEST_DATA_ADDRESS_STREET = "221 MAIN ST";
    public static final String TEST_DATA_ADDRESS__NON_EXISTING_STREET = "221.3 Main Street ";
    public static final String TEST_DATA_ADDRESS_CITY = "SAN FRANCISCO";
    public static final String TEST_DATA_ADDRESS_STATE = "CA";
    public static final String TEST_DATA_ADDRESS_ZIP = "941051906";
    public static final String TEST_DATA_ADDRESS_LONG_ZIP = "94105-1234";
    public static final String TEST_DATA_ADDRESS_LONG_ZIP_NO_DASH = "941051234";
    public static final String TEST_DATA_MIDDLE_INITIAL = "H";
    public static final String TEST_DATA_SUFFIX = "SIR";
    public static final String TEST_DATA_CLIENT_REFERENCE = "APP101";
    public static final String TEST_DATA_OCCUPATION_ID = "17";
    public static final String TEST_DATA_OCCUPATION_CHAR_ID = "17";
    public static final int TEST_DATA_EMP_YEAR = 1999;
    public static final int TEST_DATA_EMP_MONTH = 3;
    public static final int TEST_BAD_DATA_EMP_MONTH = -3;
    public static final int TEST_BAD_DATA_EMP_YEAR = -3;
    public static final String TEST_DATA_EMP_NAME = "ABC";
    public static final String TEST_DATA_PARTNER_CODE = "22";
    public static final String UNSUPPORTED_STATE = "ND";
    public static final String STATE_WITH_MIN_LOAN_REQ = "MA";
    public static final String TEST_DATA_NUMERIC_FNAME = "1222";
    public static final Double TEST_DATA_NEGATIVE_INCOME = -12222.;
    public static final String TEST_DATA_PHONE_NUMBER = "967890";
    private static final String EMAIL_DOMAIN = "@c1.dev";
    private static final String TEST_ND_STREET = "6451 WISHBONE TER";
    private static final String TEST_ND_CITY = "CABIN JOHN";
    private static final String TEST_ND_ZIP = "20918";
    private static final String TEST_DOB = "01/01/1945";
    // E-mail
    private static final String EMAIL_TEMPLATE = "%s@%s.com";


    private TestDataProviderUtil() {
    }

    public static String getUniqueEmailIdForTest(String testIdentifier) {
        final long currentTime = System.nanoTime();
        final String uniqueIdentifier =
                testIdentifier + "_" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 5)
                        + Long.toString(currentTime).substring(0, 10);
        final String emailId = uniqueIdentifier + EMAIL_DOMAIN;
        return emailId;
    }

    /**
     * @param testIdentifier : method name (track user email)
     * @param localPart : (domain e.g p2pcredit, c1.dev,c1.stg)
     * @return
     */
    public static String getGloballyUniqueEmailDomain(final String testIdentifier, final String localPart) {
        final long currentTime = System.nanoTime();
        final String uniqueIdentifier =
                testIdentifier +  "_" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 5)
                        + Long.toString(currentTime).substring(0, 9);
        final String emailId = String.format(EMAIL_TEMPLATE, uniqueIdentifier, localPart);
        return emailId;
    }

    public static PersonalInfo getValidPersonalInfo() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME.toUpperCase())
                .withLastName(Constant.TEST_LAST_NAME.toUpperCase()).withMiddleInitial(TEST_DATA_MIDDLE_INITIAL)
                .withSuffix(TEST_DATA_SUFFIX).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
    }

    public static PersonalInfo getValidPersonalInfoTahir() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME.toUpperCase())
                .withLastName(Constant.TEST_LAST_NAME.toUpperCase()).withMiddleInitial(TEST_DATA_MIDDLE_INITIAL)
                .withSuffix(TEST_DATA_SUFFIX).withSsn(Constant.TEST_SSN).
                        withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
    }

    public static PersonalInfo getValidPersonalInfoWithNonMary() {
        return new PersonalInfo.Builder().withFirstName(TEST_DATA_NON_MARY_FNAME).withLastName(TEST_DATA_NON_MARY_LNAME)
                .withDateOfBirth(TEST_DOB).withMiddleInitial("H").withSuffix("").build();
    }

    public static PersonalInfo getValidPersonalInfoWithoutDOB() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                .withMiddleInitial(TEST_DATA_MIDDLE_INITIAL).withSuffix(TEST_DATA_SUFFIX).build();
    }

    public static PersonalInfo getValidPersonalInfoWithNumericFirstName() {
        return new PersonalInfo.Builder().withFirstName(TEST_DATA_NUMERIC_FNAME).withLastName(Constant.TEST_LAST_NAME)
                .withMiddleInitial(TEST_DATA_MIDDLE_INITIAL).withSuffix(TEST_DATA_SUFFIX)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
    }

    public static AddressInfo getValidAddressInfo() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(TEST_DATA_ADDRESS_STATE)
                .withStreet(TEST_DATA_ADDRESS_STREET).withCity(TEST_DATA_ADDRESS_CITY).withZip(TEST_DATA_ADDRESS_ZIP).build();
    }

    public static AddressInfo getValidAddressInfoWithUnsupportedState() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(UNSUPPORTED_STATE).withStreet(TEST_ND_STREET)
                .withCity(TEST_ND_CITY).withZip(TEST_ND_ZIP).build();
    }

    public static AddressInfo getValidAddressInfoWithMDState() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(TEST_DATA_MD_STATE).withStreet(TEST_DATA_MD_STREET)
                .withCity(TEST_DATA_MD_CITY).withZip(TEST_DATA_MD_ZIP).build();
    }

    public static BankAccountInfo getValidBankInfo() {
        return BankAccountConstant.BANK_OF_AMERICA_BANK_ACCOUNT_1;
    }

    public static ContactInfo getValidContactInfo() {
        return new ContactInfo.ContactInfoBuilder().withEmailAddress(Constant.getGloballyUniqueEmail(true))
                .withHomePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).build();
    }

    public static ContactInfo getValidContactInfoWithEmailWithPhoneWithAreaCode(String emailId) {
        return new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
    }

    public static ContactInfo getContactInfoWithEmail(String email) {
        return new ContactInfo.ContactInfoBuilder().withEmailAddress(email)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).build();
    }

    public static EmploymentInfo getValidEmploymentInfo() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithOnlyRequiredFields() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithNullAreaCode() {
        final PhoneNumber pnumber = new PhoneNumber.Builder()
                .withPhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE.getPhoneNumber()).build();
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME).withEmployerPhone(pnumber)
                .withIsIncomeVerifiable(true).withOccupationId(TEST_DATA_OCCUPATION_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithCharOccId() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_CHAR_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithBadEmploymentMonth() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(TEST_DATA_NEGATIVE_INCOME).withEmploymentMonth(TEST_BAD_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_CHAR_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithBadEmploymentYear() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(TEST_DATA_NEGATIVE_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_BAD_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_CHAR_ID).build();
    }

    public static EmploymentInfo getValidEmploymentInfoWithNegativeIncome() {
        return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(TEST_DATA_NEGATIVE_INCOME).withEmploymentMonth(TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TEST_DATA_EMP_YEAR).withEmployerName(TEST_DATA_EMP_NAME)
                .withEmployerPhone(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER).withIsIncomeVerifiable(true)
                .withOccupationId(TEST_DATA_OCCUPATION_ID).build();
    }

    public static IdentificationInfo getValidIdentificationInfo(int partnerCode) {
        return new IdentificationInfo.Builder().withPartnerSourceCode(String.valueOf(partnerCode))
                .withClientReferenceId(TEST_DATA_CLIENT_REFERENCE).build();
    }

    public static IdentificationInfo getValidIdentificationInfo(int partnerCode, String clientReferenceId) {
        return new IdentificationInfo.Builder().withPartnerSourceCode(String.valueOf(partnerCode))
                .withClientReferenceId(clientReferenceId).build();
    }

    public static IdentificationInfo getValidIdentificationInfoWithoutClientReference(int partnerCode) {
        return new IdentificationInfo.Builder().withPartnerSourceCode(String.valueOf(partnerCode)).build();
    }

    public static LoanInfo getValidLoanInfo() {
        return new LoanInfo.LoanInfoBuilder().withLoanAmount(TEST_DATA_LOAN_AMOUNT).withLoanPurpose(TEST_DATA_LOAN_PURPOSE)
                .withSelfReportedCreditScore(TEST_DATA_CREDIT_SCORE).build();
    }

    public static LoanInfo getValidLoanInfoWithInvalidCreditScore() {
        return new LoanInfo.LoanInfoBuilder().withLoanAmount(TEST_DATA_LOAN_AMOUNT).withLoanPurpose(TEST_DATA_LOAN_PURPOSE)
                .withSelfReportedCreditScore(TEST_DATA_CREDIT_SCORE_INVALID).build();
    }

    public static LoanInfo getValidLoanInfoWithLoanPurposeInLimits() {
        return new LoanInfo.LoanInfoBuilder().withLoanAmount(TEST_DATA_LOAN_AMOUNT)
                .withLoanPurpose(TEST_DATA_LOAN_PURPOSE_IN_LMITS).withSelfReportedCreditScore(TEST_DATA_CREDIT_SCORE).build();
    }

    public static AddressInfo getValidAddressInfoWithLoanAmountMinAsk() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder().withState(STATE_WITH_MIN_LOAN_REQ)
                .withStreet(TEST_DATA_MA_STREET).withCity(TEST_DATA_MA_CITY).withZip(TEST_DATA_MA_ZIP).build();
    }

    public static GetOfferRequest getValidOffersRequest(int code, String identifier) {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(code, getUniqueEmailIdForTest(identifier)))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfoWithNonMary())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfoWithMDState())
                .withContactInfo(TestDataProviderUtil.getContactInfoWithEmail(TEST_CORY_EMAIL))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfoWithOnlyRequiredFields()).build();
        return getOfferRequest;
    }
}
