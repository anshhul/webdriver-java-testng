package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public class IndividualErrorResponse {

    @JsonProperty("code") private String code;
    @JsonProperty("message") private String message;

    public String getErrorCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public IndividualErrorResponse() {}

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        IndividualErrorResponse that = (IndividualErrorResponse) o;

        if (code != null ? !code.equals(that.code) : that.code != null)
            return false;
        return message != null ? message.equals(that.message) : that.message == null;

    }

    @Override public int hashCode() {
        int result = code != null ? code.hashCode() : 0;
        result = 31 * result + (message != null ? message.hashCode() : 0);
        return result;
    }

    public IndividualErrorResponse(IndividualErrorResponseBuilder builder) {
        this.code = builder.code;
        this.message = builder.message;
    }

    public static class IndividualErrorResponseBuilder {

        public String code;
        public String message;

        public IndividualErrorResponseBuilder() {
        }

        public IndividualErrorResponseBuilder setErrorCode(String code) {
            this.code = code;
            return this;
        }

        public IndividualErrorResponseBuilder setMessage(String message) {
            this.message = message;
            return this;
        }

        public IndividualErrorResponse build() {
            return new IndividualErrorResponse(this);
        }
    }
}
