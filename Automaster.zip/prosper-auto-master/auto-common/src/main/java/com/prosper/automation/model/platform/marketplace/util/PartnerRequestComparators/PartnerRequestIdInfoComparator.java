package com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators;

import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class PartnerRequestIdInfoComparator implements Comparator<IdentificationInfo> {

    @Override public int compare(IdentificationInfo left, IdentificationInfo right) {
        if (right != null ?
                !left.getPartnerSourceCode().equals(right.getPartnerSourceCode()) :
                left != null)
            return 1;
        if (right != null && right.getClientReferenceId() != null ?
                !left.getClientReferenceId().equals(right.getClientReferenceId()) :
                left != null)
            return 1;
        return 0;
    }
}
