
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ScoreCard {

    @JsonProperty("probability_score")
    private Double probabilityScore;

    @JsonProperty("score_card_type")
    private String scoreCardType;


    public ScoreCard() {
    }

    private ScoreCard(final Builder builder) {
        probabilityScore = builder.probabilityScore;
        scoreCardType = builder.scoreCardType;
    }


    public static final class Builder {

        private Double probabilityScore;
        private String scoreCardType;


        public Builder() {
        }

        public Builder withProbabilityScore(final Double probabilityScore) {
            this.probabilityScore = probabilityScore;
            return this;
        }

        public Builder withScoreCardType(final String scoreCardType) {
            this.scoreCardType = scoreCardType;
            return this;
        }

        public ScoreCard build() {
            return new ScoreCard(this);
        }
    }
}
