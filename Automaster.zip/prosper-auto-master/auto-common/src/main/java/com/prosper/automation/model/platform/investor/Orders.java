package com.prosper.automation.model.platform.investor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class Orders {

    @JsonProperty("result")
    private List<OrdersList> result;
    @JsonProperty("result_count")
    private int resultCount;
    @JsonProperty("total_count")
    private int totalCount;

    public List<OrdersList> getResult() {
        return result;
    }

    public int getResultCount() {
        return resultCount;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setResult(final List<OrdersList> result) {
        this.result = result;
    }

    public void setResultCount(final int resultCount) {
        this.resultCount = resultCount;
    }

    public void setTotalCount(final int totalCount) {
        this.totalCount = totalCount;
    }

}
