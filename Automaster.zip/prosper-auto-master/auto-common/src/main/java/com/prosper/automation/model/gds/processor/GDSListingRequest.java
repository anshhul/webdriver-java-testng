package com.prosper.automation.model.gds.processor;

import java.util.Map;

/**
 * Created by pbudiono on 5/24/16.
 */
public class GDSListingRequest {

	private Map<String, String> request;
}
