package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by aamalraj on 1/7/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) public final class UserEmailVerifyResponse {

    @JsonProperty("email") private String email;

    @JsonIgnore public String getEmail() {
        return email;
    }

    @JsonProperty("is_verified") private Boolean isVerified;

    @JsonIgnore public Boolean getIsVerified() {
        return isVerified;
    }
}
