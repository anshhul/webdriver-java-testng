
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class JobParameters {

    @JsonProperty("loan_detail_filter")
    private LoanDetailFilter loanDetailFilter;

    @JsonProperty("minimum_daily_investment_amount")
    private String minimumDailyInvestmentAmount;
    
    @JsonProperty("expires_in_hours")
    private Integer expiresInHours;

    @JsonProperty("expires_in_mins")
    private Integer expiresInMins;

    @JsonProperty("dry_run")
    private Boolean dryRun;

    @JsonProperty("test_investor_ids")
    private List<Long> testInvestorIds;
    
    
    /**
     * @return the dryRun
     */
    public Boolean getDryRun() {
        return dryRun;
    }
    
    /**
     * @return the expiresInHours
     */
    public Integer getExpiresInHours() {
        return expiresInHours;
    }
    
    /**
     * @return the expiresInMins
     */
    public Integer getExpiresInMins() {
        return expiresInMins;
    }

    public LoanDetailFilter getLoanDetailFilter() {
        return loanDetailFilter;
    }

    public String getMinimumDailyInvestmentAmount() {
        return minimumDailyInvestmentAmount;
    }

    public List<Long> getTestInvestorIds() {
        return testInvestorIds;
    }

    /**
     * @param dryRun the dryRun to set
     */
    public void setDryRun(final Boolean dryRun) {
        this.dryRun = dryRun;
    }

    /**
     * @param expiresInHours the expiresInHours to set
     */
    public void setExpiresInHours(final Integer expiresInHours) {
        this.expiresInHours = expiresInHours;
    }

    /**
     * @param expiresInMins the expiresInMins to set
     */
    public void setExpiresInMins(final Integer expiresInMins) {
        this.expiresInMins = expiresInMins;
    }
    
    public void setLoanDetailFilter(final LoanDetailFilter loanDetailFilter) {
        this.loanDetailFilter = loanDetailFilter;
    }
    
    public void setMinimumDailyInvestmentAmount(final String minimumDailyInvestmentAmount) {
        this.minimumDailyInvestmentAmount = minimumDailyInvestmentAmount;
    }
    
    public void setTestInvestorIds(final List<Long> testInvestorIds) {
        this.testInvestorIds = testInvestorIds;
    }
    
}
