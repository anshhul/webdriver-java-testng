
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;
import com.prosper.automation.enumeration.platform.PhoneType;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"country_code", "extension", "phone_type_id", "visible", "area_code", "preferred_contact", "phone_number"})
public final class PhoneNumber implements Cloneable {
    
    @JsonProperty("country_code")
    private String countryCode;
    @JsonProperty("extension")
    private String extension;
    @JsonProperty("phone_type_id")
    private Integer phoneTypeId;
    @JsonProperty("visible")
    private Boolean visible;
    @JsonProperty("area_code")
    private String areaCode;
    @JsonProperty("preferred_contact")
    private Boolean preferredContact;
    @JsonProperty("phone_number")
    private String phoneNumber;
    
    
    public PhoneNumber() {
    }
    
    private PhoneNumber(final Builder builder) {
        countryCode = builder.countryCode;
        extension = builder.extension;
        phoneTypeId = builder.phoneTypeId;
        visible = builder.visible;
        areaCode = builder.areaCode;
        preferredContact = builder.preferredContact;
        phoneNumber = builder.phoneNumber;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public void setExtension(final String extension) {
        this.extension = extension;
    }
    
    public void setVisible(Boolean visible) {
        this.visible = visible;
    }
    
    public void setPreferredContact(final Boolean preferredContact) {
        this.preferredContact = preferredContact;
    }
    
    public void setPhoneTypeId(final Integer phoneTypeId) {
        this.phoneTypeId = phoneTypeId;
    }
    
    @JsonIgnore
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(final String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    @JsonIgnore
    public String getCountryCode() {
        return countryCode;
    }
    @JsonIgnore
    public String getExtension() {
        return extension;
    }
    @JsonIgnore
    public Boolean getVisible() {
        return visible;
    }
    @JsonIgnore
    public Boolean getPreferredContact() {
        return preferredContact;
    }
    @JsonIgnore
    public Integer getPhoneTypeId() {
        return phoneTypeId;
    }

    @JsonIgnore
    public String getPhoneType() {
        return PhoneType.values()[phoneTypeId].toString();
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        PhoneNumber that = (PhoneNumber) o;

        if (countryCode != null ? !countryCode.equals(that.countryCode) : that.countryCode != null)
            return false;
        if (extension != null ? !extension.equals(that.extension) : that.extension != null)
            return false;
        if (phoneTypeId != null ? !phoneTypeId.equals(that.phoneTypeId) : that.phoneTypeId != null)
            return false;
        if (visible != null ? !visible.equals(that.visible) : that.visible != null)
            return false;
        if (areaCode != null ? !areaCode.equals(that.areaCode) : that.areaCode != null)
            return false;
        if (preferredContact != null ? !preferredContact.equals(that.preferredContact) : that.preferredContact != null)
            return false;
        return phoneNumber != null ? phoneNumber.equals(that.phoneNumber) : that.phoneNumber == null;

    }

    @Override public int hashCode() {
        int result = countryCode != null ? countryCode.hashCode() : 0;
        result = 31 * result + (extension != null ? extension.hashCode() : 0);
        result = 31 * result + (phoneTypeId != null ? phoneTypeId.hashCode() : 0);
        result = 31 * result + (visible != null ? visible.hashCode() : 0);
        result = 31 * result + (areaCode != null ? areaCode.hashCode() : 0);
        result = 31 * result + (preferredContact != null ? preferredContact.hashCode() : 0);
        result = 31 * result + (phoneNumber != null ? phoneNumber.hashCode() : 0);
        return result;
    }

    @Override public String toString() {
        return "PhoneNumber{" +
                "countryCode='" + countryCode + '\'' +
                ", extension='" + extension + '\'' +
                ", phoneTypeId=" + phoneTypeId +
                ", visible=" + visible +
                ", areaCode='" + areaCode + '\'' +
                ", preferredContact=" + preferredContact +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }

    public void setCountryCode(final String countryCode) {
        this.countryCode = countryCode;
    }
    
    @JsonIgnore
    public String getAreaCode() {
        return areaCode;
    }
    
    
    public static final class Builder {
        
        private String countryCode;
        private String extension;
        private Integer phoneTypeId;
        private Boolean visible;
        private String areaCode;
        private Boolean preferredContact;
        private String phoneNumber;
        
        
        public Builder() {
        }
        
        public Builder withCountryCode(final String countryCode) {
            this.countryCode = countryCode;
            return this;
        }
        
        public Builder withExtension(final String extension) {
            this.extension = extension;
            return this;
        }
        
        public Builder withPhoneTypeId(final Integer phoneTypeId) {
            this.phoneTypeId = phoneTypeId;
            return this;
        }
        
        public Builder withVisible(final Boolean visible) {
            this.visible = visible;
            return this;
        }
        
        public Builder withAreaCode(final String areaCode) {
            this.areaCode = areaCode;
            return this;
        }
        
        public Builder withPreferredContact(final Boolean preferredContact) {
            this.preferredContact = preferredContact;
            return this;
        }
        
        public Builder withPhoneNumber(final String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }
        
        public PhoneNumber build() {
            return new PhoneNumber(this);
        }
    }
}
