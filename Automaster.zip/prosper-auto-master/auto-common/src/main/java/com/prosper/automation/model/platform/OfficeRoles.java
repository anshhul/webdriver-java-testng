
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */
public final class OfficeRoles {

	@JsonProperty("office_role_name")
	private OfficeRolesName officeRoleName;
	@JsonProperty("is_Primary")
	private boolean isPrimary;

	private OfficeRoles(Builder builder) {
		setOfficeRoleName(builder.officeRoleName);
		setPrimary(builder.isPrimary);
	}

	public OfficeRolesName getOfficeRoleName() {
		return officeRoleName;
	}

	public void setOfficeRoleName(OfficeRolesName officeRoleName) {
		this.officeRoleName = officeRoleName;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public static final class Builder {

		private OfficeRolesName officeRoleName;
		private boolean isPrimary;

		public Builder() {
		}

		public Builder withOfficeRoleName(OfficeRolesName val) {
			officeRoleName = val;
			return this;
		}

		public Builder withIsPrimary(boolean val) {
			isPrimary = val;
			return this;
		}

		public OfficeRoles build() {
			return new OfficeRoles(this);
		}
	}
}
