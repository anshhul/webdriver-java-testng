package com.prosper.automation.enumeration.platform;

public enum SortingIndicator {
    desc, asc
}
