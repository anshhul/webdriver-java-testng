
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class EquTWN {

    @JsonProperty("EquTWN_PullFlag")
    private String equTWNPullFlag;
    @JsonProperty("EquTWN_HitFlag")
    private String equTWNHitFlag;


    @JsonIgnore
    public String getEquTWNPullFlag() {
        return equTWNPullFlag;
    }

    @JsonIgnore
    public String getEquTWNHitFlag() {
        return equTWNHitFlag;
    }
}
