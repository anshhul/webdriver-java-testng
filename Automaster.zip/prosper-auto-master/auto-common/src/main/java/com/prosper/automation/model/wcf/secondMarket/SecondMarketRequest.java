
package com.prosper.automation.model.wcf.secondMarket;

public class SecondMarketRequest {

    public static String requestStr =
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\" xmlns:pros=\"http://schemas.datacontract.org/2004/07/Prosper.SecondMarket.Contracts\">"+
                    "<soapenv:Header/>" +
                    "<soapenv:Body>" +
                    "<tem:TransferNote>" +
                    "<tem:request> " +
                    "<pros:BuyerProsperUserId>%s</pros:BuyerProsperUserId>" +
                    "<pros:FeeTarget>%s</pros:FeeTarget>" +
                    "<pros:LoanNoteId>%s</pros:LoanNoteId>" +
                    "<pros:SaleFee>%s</pros:SaleFee>" +
                    "<pros:SalePrice>%s</pros:SalePrice>" +
                    "<pros:SaleYield>%s</pros:SaleYield>" +
                    "<pros:SellerPropserUserId>%s</pros:SellerPropserUserId>" +
                    "<pros:TransferFunds>%s</pros:TransferFunds>" +
                    "<pros:TransferType>%s</pros:TransferType>" +
                    "</tem:request>" +
                    " </tem:TransferNote>" +
                    "</soapenv:Body>" +
                    "</soapenv:Envelope>";


    public static final class Builder {

        private String buyerProsperUserId;
        private String feeTarget;
        private String loanNoteId;
        private String saleFee;
        private String salePrice;
        private String saleYield;
        private String sellerPropserUserId;
        private String transferFunds;
        private String transferType;


        public Builder withBuyerProsperUserId(final String buyerProsperUserId) {
            this.buyerProsperUserId = buyerProsperUserId;
            return this;
        }

        public Builder withFeeTarget(final String feeTarget) {
            this.feeTarget = feeTarget;
            return this;
        }

        public Builder withLoanNoteId(final String loanNoteId) {
            this.loanNoteId = loanNoteId;
            return this;
        }

        public Builder withSaleFee(final String saleFee) {
            this.saleFee = saleFee;
            return this;
        }

        public Builder withSalePrice(final String salePrice) {
            this.salePrice = salePrice;
            return this;
        }

        public Builder withSaleYield(final String saleYield) {
            this.saleYield = saleYield;
            return this;
        }

        public Builder withSellerPropserUserId(final String sellerPropserUserId) {
            this.sellerPropserUserId = sellerPropserUserId;
            return this;
        }

        public Builder withTransferFunds(final String transferFunds) {
            this.transferFunds = transferFunds;
            return this;
        }

        public Builder withTransferType(final String transferType) {
            this.transferType = transferType;
            return this;
        }

        public String build() {
            return String.format(requestStr, buyerProsperUserId, feeTarget, loanNoteId, saleFee, salePrice, saleYield,
                    sellerPropserUserId,
                    transferFunds, transferType);
        }
    }
}
