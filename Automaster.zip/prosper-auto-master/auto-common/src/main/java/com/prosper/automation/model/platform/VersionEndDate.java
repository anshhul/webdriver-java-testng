
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VersionEndDate {
}
