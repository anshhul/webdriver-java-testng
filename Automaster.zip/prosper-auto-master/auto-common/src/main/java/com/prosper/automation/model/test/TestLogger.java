package com.prosper.automation.model.test;

import com.prosper.automation.model.test.TestThreadContext;
import com.prosper.automation.model.test.TestThreadContextEnum;
import org.apache.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

/**
 * Created by rsubramanyam on 6/12/16.
 */
public class TestLogger {
    private Logger LOG;
    public TestLogger(String name) {
        LOG = Logger.getLogger(name);
    }

    public void info(String message) {
        LOG.info((String.format("[%s] %s", TestThreadContext.getValue(TestThreadContextEnum.SAUCE_RUN.getName()), message)));
    }

    public void error(String message) {
        LOG.error(String.format("[%s] %s", TestThreadContext.getValue(TestThreadContextEnum.SAUCE_RUN.getName()), message));
    }
}
