package com.prosper.automation.constant.web;

/**
 * Created by rsubramanyam on 5/20/16.
 */
public class SuppressableJavascriptErrorConstants {
    public static final String JS_ERROR_XML_HTTP_REQUEST = "Synchronous XMLHttpRequest on the main thread is deprecated";
    public static final String JS_ERROR_GOOGLE_MAPS_API_REQUEST = "Google Maps API warning: NoApiKeys";
    public static final String SATELLITE_ERRORS = "satellite";
}
