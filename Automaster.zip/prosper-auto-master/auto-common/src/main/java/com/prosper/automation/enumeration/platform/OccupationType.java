
package com.prosper.automation.enumeration.platform;

/**
 * An enumeration for user occupation.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum OccupationType {
    
    ACCOUNTANT_CPA(1, "Accountant/CPA"),
    ANALYST(2, "Analyst"),
    ARCHITECT(3, "Architect"),
    ATTORNEY(4, "Attorney"),
    BIOLOGIST(5, "Biologist"),
    BUS_DRIVER(6, "Bus Driver"),
    CAR_DEALER(7, "Car Dealer"),
    CHEMIST(8, "Chemist"),
    CIVIL_SERVICE(9, "Civil Service"),
    CLERGY(10, "Clergy"),
    CLERICAL(11, "Clerical"),
    COMPUTER_PROGRAMMER(12, "Computer Programmer"),
    CONSTRUCTION(13, "Construction"),
    DENTIST(14, "Dentist"),
    DOCTOR(16, "Doctor"),
    ENGINEER_CHEMICAL(17, "Engineer - Chemical"),
    ENGINEER_ELECTRICAL(18, "Engineer - Electrical"),
    ENGINEER_MECHANICAL(19, "Engineer - Mechanical"),
    EXECUTIVE(20, "Executive"),
    FIREMAN(21, "Fireman"),
    FLIGHT_ATTENDANT(22, "Flight Attendant"),
    FOOD_SERVICE(23, "Food Service"),
    FOOD_SERVICE_MANAGEMENT(24, "Food Service Management"),
    HOMEMAKER(25, "Homemaker"),
    JUDGE(26, "Judge"),
    LABORER(27, "Laborer"),
    LANDSCAPING(28, "Landscaping"),
    MEDICAL_TECHNICIAN(29, "Medical Technician"),
    MILITARY_ENLISTED(30, "Military Enlisted"),
    MILITARY_OFFICER(31, "Military Officer"),
    NURSE_LPN_(32, "Nurse (LPN),"),
    NURSE_RN_(33, "Nurse (RN),"),
    NURSE_S_AIDE(34, "Nurse's Aide"),
    PHARMACIST(35, "Pharmacist"),
    PILOT_PRIVATE_COMMERCIAL(36, "Pilot - Private/Commercial"),
    POLICE_OFFICER_CORRECTION_OFFICER(37, "Police Officer/Correction Officer"),
    POSTAL_SERVICE(38, "Postal Service"),
    PRINCIPAL(39, "Principal"),
    PROFESSIONAL(40, "Professional"),
    PROFESSOR(41, "Professor"),
    PSYCHOLOGIST(42, "Psychologist"),
    REALTOR(43, "Realtor"),
    RELIGIOUS(44, "Religious"),
    RETAIL_MANAGEMENT(45, "Retail Management"),
    RETIRED(46, "Retired"),
    SALES_COMMISSION(47, "Sales - Commission"),
    SALES_RETAIL(48, "Sales - Retail"),
    SCIENTIST(49, "Scientist"),
    ADMINISTRATIVE_ASSISTANT(50, "Administrative Assistant"),
    SELF_EMPLOYED(51, "Self Employed"),
    SKILLED_LABOR(52, "Skilled Labor"),
    SOCIAL_WORKER(53, "Social Worker"),
    STUDENT_COLLEGE_FRESHMAN(54, "Student - College Freshman"),
    STUDENT_COLLEGE_SOPHOMORE(55, "Student - College Sophomore"),
    STUDENT_COLLEGE_JUNIOR(56, "Student - College Junior"),
    STUDENT_COLLEGE_SENIOR(57, "Student - College Senior"),
    STUDENT_COLLEGE_GRADUATE_STUDENT(58, "Student - College Graduate Student"),
    STUDENT_COMMUNITY_COLLEGE(59, "Student - Community College"),
    STUDENT_TECHNICAL_SCHOOL(60, "Student - Technical School"),
    TEACHER(61, "Teacher"),
    TEACHER_S_AIDE(62, "Teacher's Aide"),
    TRADESMAN_CARPENTER(63, "Tradesman - Carpenter"),
    TRADESMAN_ELECTRICIAN(64, "Tradesman - Electrician"),
    TRADESMAN_MECHANIC(65, "Tradesman - Mechanic"),
    TRADESMAN_PLUMBER(66, "Tradesman - Plumber"),
    TRUCK_DRIVER(67, "Truck Driver"),
    UNEMPLOYED(68, "Unemployed"),
    WAITER_WAITRESS(69, "Waiter/Waitress"),
    OTHER(70, "Other"),
    INVESTOR(71, "Investor");
    
    private final Integer occupationId;
    private final String occupationName;
    
    
    OccupationType(final Integer occupationId, final String occupationName) {
        this.occupationId = occupationId;
        this.occupationName = occupationName;
    }
    
    public Integer getOccupationId() {
        return occupationId;
    }
    
    public String getOccupationName() {
        return occupationName;
    }
}
