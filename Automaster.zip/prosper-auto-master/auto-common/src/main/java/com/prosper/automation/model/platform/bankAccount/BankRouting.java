
package com.prosper.automation.model.platform.bankAccount;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"record_type_cd", "address", "city", "change_date", "view_cd", "office_cd", "routing_number", "zip_cd",
        "status_cd", "bank_name", "zip_cd_extn", "phone_number", "serving_frb_number", "new_routing_number", "state_cd"})
public final class BankRouting {
    
    @JsonProperty("record_type_cd")
    private Integer recordTypeCd;
    @JsonProperty("address")
    private String address;
    @JsonProperty("city")
    private String city;
    @JsonProperty("change_date")
    private String changeDate;
    @JsonProperty("view_cd")
    private Integer viewCd;
    @JsonProperty("office_cd")
    private String officeCd;
    @JsonProperty("routing_number")
    private String routingNumber;
    @JsonProperty("zip_cd")
    private String zipCd;
    @JsonProperty("status_cd")
    private Integer statusCd;
    @JsonProperty("bank_name")
    private String bankName;
    @JsonProperty("zip_cd_extn")
    private String zipCdExtn;
    @JsonProperty("phone_number")
    private String phoneNumber;
    @JsonProperty("serving_frb_number")
    private String servingFrbNumber;
    @JsonProperty("new_routing_number")
    private String newRoutingNumber;
    @JsonProperty("state_cd")
    private String stateCd;
    
    
    public BankRouting() {
    }
    
    private BankRouting(final Builder builder) {
        recordTypeCd = builder.recordTypeCd;
        address = builder.address;
        city = builder.city;
        changeDate = builder.changeDate;
        viewCd = builder.viewCd;
        officeCd = builder.officeCd;
        routingNumber = builder.routingNumber;
        zipCd = builder.zipCd;
        statusCd = builder.statusCd;
        bankName = builder.bankName;
        zipCdExtn = builder.zipCdExtn;
        phoneNumber = builder.phoneNumber;
        servingFrbNumber = builder.servingFrbNumber;
        newRoutingNumber = builder.newRoutingNumber;
        stateCd = builder.stateCd;
    }
    
    @JsonIgnore
    public String getBankName() {
        return bankName;
    }
    
    @JsonIgnore
    public String getRoutingNumber() {
        return routingNumber;
    }
    
    @Override
    public String toString() {
        return "BankRouting { bankName = " + bankName + " }";
    }
    
    
    public static final class Builder {
        
        private Integer recordTypeCd;
        private String address;
        private String city;
        private String changeDate;
        private Integer viewCd;
        private String officeCd;
        private String routingNumber;
        private String zipCd;
        private Integer statusCd;
        private String bankName;
        private String zipCdExtn;
        private String phoneNumber;
        private String servingFrbNumber;
        private String newRoutingNumber;
        private String stateCd;
        
        
        public Builder() {
        }
        
        public Builder withRecordTypeCd(final Integer recordTypeCd) {
            this.recordTypeCd = recordTypeCd;
            return this;
        }
        
        public Builder withAddress(final String address) {
            this.address = address;
            return this;
        }
        
        public Builder withCity(final String city) {
            this.city = city;
            return this;
        }
        
        public Builder withChangeDate(final String changeDate) {
            this.changeDate = changeDate;
            return this;
        }
        
        public Builder withViewCd(final Integer viewCd) {
            this.viewCd = viewCd;
            return this;
        }
        
        public Builder withOfficeCd(final String officeCd) {
            this.officeCd = officeCd;
            return this;
        }
        
        public Builder withRoutingNumber(final String routingNumber) {
            this.routingNumber = routingNumber;
            return this;
        }
        
        public Builder withZipCd(final String zipCd) {
            this.zipCd = zipCd;
            return this;
        }
        
        public Builder withStatusCd(final Integer statusCd) {
            this.statusCd = statusCd;
            return this;
        }
        
        public Builder withBankName(final String bankName) {
            this.bankName = bankName;
            return this;
        }
        
        public Builder withZipCdExtn(final String zipCdExtn) {
            this.zipCdExtn = zipCdExtn;
            return this;
        }
        
        public Builder withPhoneNumber(final String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }
        
        public Builder withServingFrbNumber(final String servingFrbNumber) {
            this.servingFrbNumber = servingFrbNumber;
            return this;
        }
        
        public Builder withNewRoutingNumber(final String newRoutingNumber) {
            this.newRoutingNumber = newRoutingNumber;
            return this;
        }
        
        public Builder withStateCd(final String stateCd) {
            this.stateCd = stateCd;
            return this;
        }
        
        public BankRouting build() {
            return new BankRouting(this);
        }
    }
}
