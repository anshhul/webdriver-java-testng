
package com.prosper.automation.model.platform.affiliateReferral;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class AffiliateReferralPixelRequest {
    
    @JsonProperty("affiliate_referral_id")
    private Long affiliateReferralId;
    @JsonProperty("listing_id")
    private Long listingId;
}
