
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ValidationCallbackRequest {

    @JsonProperty("rpUser_Id")
    private Long rpUserId;

    @JsonProperty("user_id")
    private String userId;


    private ValidationCallbackRequest(final Builder builder) {
        rpUserId = builder.rpUserId;
        userId = builder.userId;
    }


    public static final class Builder {

        private Long rpUserId;
        private String userId;


        public Builder() {
        }

        public Builder withRpUserId(final Long rpUserId) {
            this.rpUserId = rpUserId;
            return this;
        }

        public Builder withUserId(final String userId) {
            this.userId = userId;
            return this;
        }

        public ValidationCallbackRequest build() {
            return new ValidationCallbackRequest(this);
        }
    }
}
