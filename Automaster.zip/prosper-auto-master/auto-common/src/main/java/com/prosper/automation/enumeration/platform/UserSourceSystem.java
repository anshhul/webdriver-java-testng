
package com.prosper.automation.enumeration.platform;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum UserSourceSystem {
    APP_BY_PHONE, PUBLIC_SITE, PARTNER_REFERRAL, POS;
}
