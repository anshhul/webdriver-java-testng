
package com.prosper.automation.model.platform.loan;

import java.io.Serializable;

/**
 * This holds investor,borrower with maximum loans CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public class MaxOccurances implements Serializable {
    
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private Long userId;
    private Integer loanid;
    private Long totalOccurances;
    
    
    public static class MaxOccurancesBuilder {

        private Long userId;
        private Integer loanid;
        private Long totalOccurances;


        public MaxOccurances build() {
            final MaxOccurances result = new MaxOccurances();

            result.setUserId(userId);
            result.setLoanid(loanid);
            result.setTotalOccurances(totalOccurances);
            return result;
        }

        public MaxOccurancesBuilder loanid(final Integer value) {
            this.loanid = value;
            return this;
        }

        public MaxOccurancesBuilder totalOccurances(final Long value) {
            this.totalOccurances = value;
            return this;
        }

        public MaxOccurancesBuilder userId(final Long value) {
            this.userId = value;
            return this;
        }
    }
    
    
    public static MaxOccurancesBuilder buildUpon(final MaxOccurances original) {
        final MaxOccurancesBuilder builder = newBuilder();
        builder.userId(original.getUserId());
        builder.loanid(original.getLoanid());
        builder.totalOccurances(original.getTotalOccurances());
        return builder;
    }

    public static MaxOccurancesBuilder newBuilder() {
        return new MaxOccurancesBuilder();
    }

    public Integer getLoanid() {
        return loanid;
    }

    public Long getTotalOccurances() {
        return totalOccurances;
    }

    public Long getUserId() {
        return userId;
    }
    
    public void setLoanid(final Integer loanid) {
        this.loanid = loanid;
    }
    
    public void setTotalOccurances(final Long totalOccurances) {
        this.totalOccurances = totalOccurances;
    }
    
    public void setUserId(final Long userId) {
        this.userId = userId;
    }
    
}
