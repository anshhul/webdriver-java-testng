package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 4/13/16.
 */
public final class ProspectMigrationResponse {

	@JsonProperty("limit")
	private Integer limit;
	@JsonProperty("message")
	private String message;
	@JsonProperty("start_date")
	private String startDate;
	@JsonProperty("end_date")
	private String endDate;
	@JsonProperty("total_in_interval")
	private Integer totalInInterval;
	@JsonProperty("batch_size")
	private Integer batchSize;
	@JsonProperty("already_running")
	private Boolean alreadyRunning;
	@JsonProperty("feature_enabled")
	private Boolean featureEnabled;

	public Boolean getFeatureEnabled() {
		return featureEnabled;
	}

	public Integer getLimit() {
		return limit;
	}

	public String getMessage() {
		return message;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public Integer getTotalInInterval() {
		return totalInInterval;
	}

	public Integer getBatchSize() {
		return batchSize;
	}

	public Boolean getAlreadyRunning() {
		return alreadyRunning;
	}
}
