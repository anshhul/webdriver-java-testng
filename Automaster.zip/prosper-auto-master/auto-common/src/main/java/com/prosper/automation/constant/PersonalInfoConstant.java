
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.PersonalInfo;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PersonalInfoConstant {

    private PersonalInfoConstant() {
    }

    /**
     * Creates Rick Nick personal information object.
     *
     * @return PersonalInfo
     */
    public static PersonalInfo buildRickNickPersonalInfo() {
        return new PersonalInfo.Builder().withFirstName(Constant.RICK_NICK_FIRST_NAME).withLastName(Constant.RICK_NICK_LAST_NAME)
                .withDateOfBirth(Constant.RICK_NICK_DATE_OF_BIRTH).withUserNameTypeId(Constant.LEGAL_NAME_USER_TYPE_ID)
                .withSourceTypeId(Constant.USER_INPUT_TYPE_ID).build();
    }

    /**
     * Creates Fred Ruiz-Cruz personal information object.
     *
     * @return PersonalInfo
     */
    public static PersonalInfo buildFredRuizCruzPersonalInfo() {
        return new PersonalInfo.Builder().withFirstName(Constant.FRED_RUIZ_CRUZ_FIRST_NAME)
                .withLastName(Constant.FRED_RUIZ_CRUZ_LAST_NAME).withDateOfBirth(Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH)
                .withUserNameTypeId(Constant.LEGAL_NAME_USER_TYPE_ID).withSourceTypeId(Constant.USER_INPUT_TYPE_ID).build();
    }

    public static PersonalInfo getUnderEighteenPersonalInfo() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                .withDateOfBirth("01/01/2004").build();
    }

    /**
     * Creates Mary Hopkins personal information object with update first name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsFirstNameLeftPaddedWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        personalInfo.setLastName(String.format(Constant.TWO_STRING_FORMAT_TEMPLATE, aString, Constant.TEST_FIRST_NAME));
        return personalInfo;
    }

    /**
     * Creates Mary Hopkins personal information object with update first name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsFirstNameRightPaddedWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        personalInfo.setLastName(String.format(Constant.TWO_STRING_FORMAT_TEMPLATE, Constant.TEST_FIRST_NAME, aString));
        return personalInfo;
    }

    /**
     * Creates Mary Hopkins personal information object with update first name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsFirstNamePaddedInTheMiddleWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        final int firstNameLength = Constant.TEST_FIRST_NAME.length();
        final String firstHalfFirstName = Constant.TEST_FIRST_NAME.substring(0, firstNameLength / 2);
        final String secondHalfFirstName = Constant.TEST_FIRST_NAME.substring((firstNameLength / 2), firstNameLength);
        personalInfo.setFirstName(String.format(Constant.THREE_STRING_FORMAT_TEMPLATE, firstHalfFirstName, aString,
                secondHalfFirstName));
        return personalInfo;
    }

    /**
     * Creates Mary Hopkins personal information object with update last name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsLastNameLeftPaddedWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        personalInfo.setLastName(String.format(Constant.TWO_STRING_FORMAT_TEMPLATE, aString, Constant.TEST_LAST_NAME));
        return personalInfo;
    }

    /**
     * Creates Mary Hopkins personal information object with update last name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsLastNameRightPaddedWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        personalInfo.setLastName(String.format(Constant.TWO_STRING_FORMAT_TEMPLATE, Constant.TEST_LAST_NAME, aString));
        return personalInfo;
    }

    /**
     * Creates Mary Hopkins personal information object with update last name.
     *
     * @param aString
     * @return PersonalInfo
     */
    public static PersonalInfo buildMaryHopkinsLastNamePaddedInTheMiddleWith(final String aString) {
        final PersonalInfo personalInfo = buildMaryHopkins();
        final int firstNameLength = Constant.TEST_LAST_NAME.length();
        final String firstHalfFirstName = Constant.TEST_LAST_NAME.substring(0, firstNameLength / 2);
        final String secondHalfFirstName = Constant.TEST_LAST_NAME.substring((firstNameLength / 2), firstNameLength);
        personalInfo.setFirstName(String.format(Constant.THREE_STRING_FORMAT_TEMPLATE, firstHalfFirstName, aString,
                secondHalfFirstName));
        return personalInfo;
    }

    private static PersonalInfo buildMaryHopkins() {
        return new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).withUserNameTypeId(Constant.TEST_USER_NAME_TYPE_ID)
                .withSourceTypeId(Constant.TEST_SOURCE_TYPE_ID).build();
    }
}
