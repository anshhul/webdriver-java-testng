
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PricingBinType {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("pricing_type_bin")
    private String pricingTypeBin;
    @JsonProperty("pricing_version")
    private Double pricingVersion;
    @JsonProperty("bin_type_name")
    private String binTypeName;
    @JsonProperty("bin_data_store_reference")
    private String binDataStoreReference;
    @JsonProperty("pricing_table_column_name")
    private String pricingTableColumnName;
    @JsonProperty("pricing_type_bin_data_value")
    private String pricingTypeBinDataValue;
    @JsonProperty("dynamic_value")
    private Boolean dynamicValue;
    @JsonProperty("is_used")
    private Boolean isUsed;


    public PricingBinType() {
    }

    private PricingBinType(final Builder builder) {
        id = builder.id;
        pricingTypeBin = builder.pricingTypeBin;
        pricingVersion = builder.pricingVersion;
        binTypeName = builder.binTypeName;
        binDataStoreReference = builder.binDataStoreReference;
        pricingTableColumnName = builder.pricingTableColumnName;
        pricingTypeBinDataValue = builder.pricingTypeBinDataValue;
        dynamicValue = builder.dynamicValue;
        isUsed = builder.isUsed;
    }

    @JsonIgnore
    public String getPricingTableColumnName() {
        return pricingTableColumnName;
    }


    public static final class Builder {

        private Long id;
        private String pricingTypeBin;
        private Double pricingVersion;
        private String binTypeName;
        private String binDataStoreReference;
        private String pricingTableColumnName;
        private String pricingTypeBinDataValue;
        private Boolean dynamicValue;
        private Boolean isUsed;


        public Builder() {
        }

        public Builder withId(final Long id) {
            this.id = id;
            return this;
        }

        public Builder withPricingTypeBin(final String pricingTypeBin) {
            this.pricingTypeBin = pricingTypeBin;
            return this;
        }

        public Builder withPricingVersion(final Double pricingVersion) {
            this.pricingVersion = pricingVersion;
            return this;
        }

        public Builder withBinTypeName(final String binTypeName) {
            this.binTypeName = binTypeName;
            return this;
        }

        public Builder withBinDataStoreReference(final String binDataStoreReference) {
            this.binDataStoreReference = binDataStoreReference;
            return this;
        }

        public Builder withPricingTableColumnName(final String pricingTableColumnName) {
            this.pricingTableColumnName = pricingTableColumnName;
            return this;
        }

        public Builder withPricingTypeBinDataValue(final String pricingTypeBinDataValue) {
            this.pricingTypeBinDataValue = pricingTypeBinDataValue;
            return this;
        }

        public Builder withDynamicValue(final Boolean dynamicValue) {
            this.dynamicValue = dynamicValue;
            return this;
        }

        public Builder withIsUsed(final Boolean isUsed) {
            this.isUsed = isUsed;
            return this;
        }

        public PricingBinType build() {
            return new PricingBinType(this);
        }
    }
}
