
package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.List;

/**
 * Created by rsubramanyam on 3/15/16.
 */
public class AdminPartnerOauthResponse {

    @JsonProperty("client_info")
    ClientInfoAssignedRoles clientInfoAssignedRoles;
    @JsonProperty("campaign")
    Campaign campaign;
    @JsonProperty("campaign_program")
    CampaignProgram campaignProgram;
    @JsonProperty("partner")
    Partner partner;


    // @JsonProperty("assigned_roles")
    // List<AssignableRoleResponse> assigned_roles;

    @JsonIgnore
    public ClientInfoAssignedRoles getClientWithRolesInfo() {
        return this.clientInfoAssignedRoles;
    }

    public void setClientWithRolesInfo(ClientInfoAssignedRoles client_info) {
        this.clientInfoAssignedRoles = client_info;
    }

    @JsonIgnore
    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public ClientInfoAssignedRoles getClientInfoAssignedRoles() {
        return clientInfoAssignedRoles;
    }

    public void setClientInfoAssignedRoles(ClientInfoAssignedRoles clientInfoAssignedRoles) {
        this.clientInfoAssignedRoles = clientInfoAssignedRoles;
    }

    public CampaignProgram getCampaignProgram() {
        return campaignProgram;
    }

    public void setCampaignProgram(CampaignProgram campaignProgram) {
        this.campaignProgram = campaignProgram;
    }

    public Partner getPartner() {
        return partner;
    }

    public void setPartner(Partner partner) {
        this.partner = partner;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AdminPartnerOauthResponse that = (AdminPartnerOauthResponse) o;
        return Objects.equal(clientInfoAssignedRoles, that.clientInfoAssignedRoles) &&
                Objects.equal(campaign, that.campaign) &&
                Objects.equal(campaignProgram, that.campaignProgram) &&
                Objects.equal(partner, that.partner);
    }

    @Override public int hashCode() {
        return Objects.hashCode(clientInfoAssignedRoles, campaign, campaignProgram, partner);
    }
}
