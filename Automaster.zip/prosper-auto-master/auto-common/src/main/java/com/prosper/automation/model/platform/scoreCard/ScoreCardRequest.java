
package com.prosper.automation.model.platform.scoreCard;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.offer.CalculatedStaggAttributes;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;
import com.prosper.automation.model.platform.pricing.UserLoanAttributes;
import com.prosper.automation.model.platform.pricing.ExperianUserCredit;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class ScoreCardRequest {
    
    @JsonProperty("calculated_pmi_attributes")
    private CalculatedPmiAttributes calculatedPmiAttributes;
    @JsonProperty("experian_user_credit")
    private ExperianUserCredit experianUserCredit;
    @JsonProperty("user_loan_attributes")
    private UserLoanAttributes userLoanAttributes;
    @JsonProperty("calculated_stagg_attributes")
    private CalculatedStaggAttributes calculatedStaggAttributes;
    
    
    private ScoreCardRequest(final Builder builder) {
        setCalculatedPmiAttributes(builder.calculatedPmiAttributes);
        setExperianUserCredit(builder.experianUserCredit);
        setUserLoanAttributes(builder.userLoanAttributes);
        calculatedStaggAttributes = builder.calculatedStaggAttributes;
    }
    
    @JsonIgnore
    public CalculatedPmiAttributes getCalculatedPmiAttributes() {
        return calculatedPmiAttributes;
    }
    
    public void setCalculatedPmiAttributes(final CalculatedPmiAttributes calculatedPmiAttributes) {
        this.calculatedPmiAttributes = calculatedPmiAttributes;
    }
    
    @JsonIgnore
    public ExperianUserCredit getExperianUserCredit() {
        return experianUserCredit;
    }
    
    public void setExperianUserCredit(final ExperianUserCredit experianUserCredit) {
        this.experianUserCredit = experianUserCredit;
    }
    
    @JsonIgnore
    public UserLoanAttributes getUserLoanAttributes() {
        return userLoanAttributes;
    }
    
    public void setUserLoanAttributes(final UserLoanAttributes userLoanAttributes) {
        this.userLoanAttributes = userLoanAttributes;
    }
    
    
    public static final class Builder {
        
        private CalculatedPmiAttributes calculatedPmiAttributes;
        private ExperianUserCredit experianUserCredit;
        private UserLoanAttributes userLoanAttributes;
        private CalculatedStaggAttributes calculatedStaggAttributes;
        
        
        public Builder() {
        }
        
        public Builder withCalculatedPmiAttributes(final CalculatedPmiAttributes calculatedPmiAttributes) {
            this.calculatedPmiAttributes = calculatedPmiAttributes;
            return this;
        }
        
        public Builder withExperianUserCredit(final ExperianUserCredit experianUserCredit) {
            this.experianUserCredit = experianUserCredit;
            return this;
        }
        
        public Builder withUserLoanAttributes(final UserLoanAttributes userLoanAttributes) {
            this.userLoanAttributes = userLoanAttributes;
            return this;
        }
        
        public Builder withCalculatedStaggAttributes(final CalculatedStaggAttributes calculatedStaggAttributes) {
            this.calculatedStaggAttributes = calculatedStaggAttributes;
            return this;
        }
        
        public ScoreCardRequest build() {
            return new ScoreCardRequest(this);
        }
    }
}
