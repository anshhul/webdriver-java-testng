
package com.prosper.automation.model.platform.accounts;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @Description: Holds response for Users prosper Account
 * @author Prateek
 */
@JsonInclude(Include.NON_NULL)
public final class UserProsperAccount {

    @JsonProperty("available_cash_balance")
    private Double availableCashBalance;
    
    @JsonProperty("pending_investments_primary_market")
    private Double pendingInvestmentsPrimaryMarket;
    
    @JsonProperty("pending_investments_secondary_market")
    private Double pendingInvestmentsSecondaryMarket;
    
    @JsonProperty("pending_quick_invest_orders")
    private Double pendingQuickInvestOrders;
    
    @JsonProperty("total_principal_received_on_active_notes")
    private Double totalPrincipalReceivedOnActiveNotes;
    
    @JsonProperty("total_amount_invested_on_active_notes")
    private Double totalAmountInvestedOnActiveNotes;
    
    @JsonProperty("outstanding_principal_on_active_notes")
    private Double outstandingPrincipalOnActiveNotes;
    
    @JsonProperty("total_account_value")
    private Double totalAccountValue;
    
    @JsonProperty("last_deposit_amount")
    private Double lastDepositAmount;
    
    @JsonProperty("last_deposit_date")
    private String lastDepositDate;
    
    
    public Double getLastDepositAmount() {
        return lastDepositAmount;
    }
    
    public void setLastDepositAmount(Double lastDepositAmount) {
        this.lastDepositAmount = lastDepositAmount;
    }
    
    public String getLastDepositDate() {
        return lastDepositDate;
    }
    
    public void setLastDepositDate(String lastDepositDate) {
        this.lastDepositDate = lastDepositDate;
    }
    
    public Double getAvailableCashBalance() {
        return availableCashBalance;
    }
    
    public Double getOutstandingPrincipalOnActiveNotes() {
        return outstandingPrincipalOnActiveNotes;
    }
    
    public Double getPendingInvestmentsPrimaryMarket() {
        return pendingInvestmentsPrimaryMarket;
    }
    
    public Double getPendingInvestmentsSecondaryMarket() {
        return pendingInvestmentsSecondaryMarket;
    }
    
    public Double getPendingQuickInvestOrders() {
        return pendingQuickInvestOrders;
    }
    
    public Double getTotalAccountValue() {
        return totalAccountValue;
    }
    
    public Double getTotalAmountInvestedOnActiveNotes() {
        return totalAmountInvestedOnActiveNotes;
    }
    
    public Double getTotalPrincipalReceivedOnActiveNotes() {
        return totalPrincipalReceivedOnActiveNotes;
    }
    
    public void setAvailableCashBalance(final Double availableCashBalance) {
        this.availableCashBalance = availableCashBalance;
    }
    
    public void setOutstandingPrincipalOnActiveNotes(final Double outstandingPrincipalOnActiveNotes) {
        this.outstandingPrincipalOnActiveNotes = outstandingPrincipalOnActiveNotes;
    }
    
    public void setPendingInvestmentsPrimaryMarket(final Double pendingInvestmentsPrimaryMarket) {
        this.pendingInvestmentsPrimaryMarket = pendingInvestmentsPrimaryMarket;
    }
    
    public void setPendingInvestmentsSecondaryMarket(final Double pendingInvestmentsSecondaryMarket) {
        this.pendingInvestmentsSecondaryMarket = pendingInvestmentsSecondaryMarket;
    }
    
    public void setPendingQuickInvestOrders(final Double pendingQuickInvestOrders) {
        this.pendingQuickInvestOrders = pendingQuickInvestOrders;
    }
    
    public void setTotalAccountValue(final Double totalAccountValue) {
        this.totalAccountValue = totalAccountValue;
    }
    
    public void setTotalAmountInvestedOnActiveNotes(final Double totalAmountInvestedOnActiveNotes) {
        this.totalAmountInvestedOnActiveNotes = totalAmountInvestedOnActiveNotes;
    }
    
    public void setTotalPrincipalReceivedOnActiveNotes(final Double totalPrincipalReceivedOnActiveNotes) {
        this.totalPrincipalReceivedOnActiveNotes = totalPrincipalReceivedOnActiveNotes;
    }
    
}
