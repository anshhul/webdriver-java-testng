
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class LNFlexID {

    @JsonProperty("LNFlexID_PullFlag")
    private String lNFlexIDPullFlag;
    @JsonProperty("LNFlexID_HitFlag")
    private String lNFlexIDHitFlag;


    @JsonIgnore
    public String getLNFlexIDPullFlag() {
        return lNFlexIDPullFlag;
    }

    @JsonIgnore
    public String getLNFlexIDHitFlag() {
        return lNFlexIDHitFlag;
    }
}
