package com.prosper.automation.model.platform.email;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/26/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class MessageToken {

	@JsonProperty("key")
	private String key;
	@JsonProperty("value")
	private String value;

	public MessageToken() {
	}

	private MessageToken(Builder builder) {
		key = builder.key;
		value = builder.value;
	}

	public static final class Builder {

		private String key;
		private String value;

		public Builder() {
		}

		public Builder withKey(String val) {
			key = val;
			return this;
		}

		public Builder withValue(String val) {
			value = val;
			return this;
		}

		public MessageToken build() {
			return new MessageToken(this);
		}
	}
}
