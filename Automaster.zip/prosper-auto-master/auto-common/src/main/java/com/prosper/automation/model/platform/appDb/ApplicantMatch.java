package com.prosper.automation.model.platform.appDb;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

/**
 * Created by rsubramanyam on 3/27/16.
 */
public class ApplicantMatch {

    @JsonProperty("applicantId") public int applicantId;
    @JsonProperty("oldApplicantId") public int oldApplicantId;
    @JsonProperty("applicantMatchTypeId") public int applicantMatchTypeId;
    @JsonProperty("decValue") public String decValue;
    @JsonProperty("prospectId") public String prospectId;
    @JsonIgnore @JsonProperty("value1") public String value1;
    @JsonIgnore @JsonProperty("value2") public String value2;
    @JsonIgnore @JsonProperty("value3") public String value3;
    @JsonIgnore @JsonProperty("value4") public String value4;
    @JsonIgnore @JsonProperty("update") public String update;
    public ApplicantMatch(int applicantId, int applicantMatchType) {
        this.applicantId = applicantId;
        this.applicantMatchTypeId = applicantMatchType;
    }

    public ApplicantMatch(int applicantId, int oldApplicantId, int applicantMatchTypeId, String decValue, String prospectId, String update) {
        this.applicantId = applicantId;
        this.oldApplicantId = oldApplicantId;
        this.applicantMatchTypeId = applicantMatchTypeId;
        this.decValue = decValue;
        this.prospectId = prospectId;
    }

    public ApplicantMatch() {
    }

    public int getApplicantId() {
        return applicantId;
    }
    public int getOldApplicantId() {
        return oldApplicantId;
    }

    public void setApplicantId(int applicantId) {
        this.applicantId = applicantId;
    }

    public int getApplicantMatchTypeId() {
        return applicantMatchTypeId;
    }

    public void setApplicantMatchType(int applicantMatchType) {
        this.applicantMatchTypeId = applicantMatchType;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ApplicantMatch that = (ApplicantMatch) o;
        return applicantId == that.applicantId &&
                oldApplicantId == that.oldApplicantId &&
                applicantMatchTypeId == that.applicantMatchTypeId &&
                Objects.equal(decValue, that.decValue) &&
                Objects.equal(prospectId, that.prospectId) &&
                Objects.equal(value1, that.value1) &&
                Objects.equal(value2, that.value2) &&
                Objects.equal(value3, that.value3) &&
                Objects.equal(value4, that.value4) &&
                Objects.equal(update, that.update);
    }

    @Override public int hashCode() {
        return Objects
                .hashCode(applicantId, oldApplicantId, applicantMatchTypeId, decValue, prospectId, value1, value2, value3, value4,
                        update);
    }
}
