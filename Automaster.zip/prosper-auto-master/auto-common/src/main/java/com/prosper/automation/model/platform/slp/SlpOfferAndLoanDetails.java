
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class SlpOfferAndLoanDetails {

    @JsonProperty("offer_master_id")
    private Integer offerMasterId;
    
    @JsonProperty("buyer_id")
    private Long buyerId;
    
    @JsonProperty("status_date")
    private String statusDate;
    
    @JsonProperty("offer_expiration_date")
    private String offerExpirationDate;
    
    @JsonProperty("transaction_effective_date")
    private String transactionEffectiveDate;
    
    @JsonProperty("offer_status")
    private String offerStatus;
    
    @JsonProperty("offer_amount")
    private Double offerAmount;
    
    @JsonProperty("total_fees")
    private Double totalFees;
    
    @JsonProperty("loan_notes")
    private List<SlpNotes> loanNotes;


    public Long getBuyerId() {
        return buyerId;
    }

    public List<SlpNotes> getLoanNotes() {
        return loanNotes;
    }

    public Double getOfferAmount() {
        return offerAmount;
    }

    public String getOfferExpirationDate() {
        return offerExpirationDate;
    }

    public Integer getOfferMasterId() {
        return offerMasterId;
    }

    public String getOfferStatus() {
        return offerStatus;
    }

    public String getStatusDate() {
        return statusDate;
    }

    public Double getTotalFees() {
        return totalFees;
    }

    public String getTransactionEffectiveDate() {
        return transactionEffectiveDate;
    }

    public void setBuyerId(final Long buyerId) {
        this.buyerId = buyerId;
    }

    public void setLoanNotes(final List<SlpNotes> loanNotes) {
        this.loanNotes = loanNotes;
    }

    public void setOfferAmount(final Double offerAmount) {
        this.offerAmount = offerAmount;
    }

    public void setOfferExpirationDate(final String offerExpirationDate) {
        this.offerExpirationDate = offerExpirationDate;
    }

    public void setOfferMasterId(final Integer offerMasterId) {
        this.offerMasterId = offerMasterId;
    }

    public void setOfferStatus(final String offerStatus) {
        this.offerStatus = offerStatus;
    }

    public void setStatusDate(final String statusDate) {
        this.statusDate = statusDate;
    }

    public void setTotalFees(final Double totalFees) {
        this.totalFees = totalFees;
    }

    public void setTransactionEffectiveDate(final String transactionEffectiveDate) {
        this.transactionEffectiveDate = transactionEffectiveDate;
    }

}
