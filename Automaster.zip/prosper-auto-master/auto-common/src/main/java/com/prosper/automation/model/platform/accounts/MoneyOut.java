
package com.prosper.automation.model.platform.accounts;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 *
 * @Description: Account Ledger
 * @author agarg
 */
public final class MoneyOut {

    @JsonProperty("purchased_notes")
    private String purchasedNotes;

    @JsonProperty("pending_investments")
    private String pendingInvestments;

    @JsonProperty("notes_pending_bids")
    private String notesPendingBids;

    @JsonProperty("total_withdrawls")
    private long totalWithdrawls;

    @JsonProperty("adjustments_debits")
    private String adjustmentsDebits;


    public String getPurchasedNotes() {
        return purchasedNotes;
    }

    public void setPurchasedNotes(String purchasedNotes) {
        this.purchasedNotes = purchasedNotes;
    }

    public String getPendingInvestments() {
        return pendingInvestments;
    }

    public void setPendingInvestments(String pendingInvestments) {
        this.pendingInvestments = pendingInvestments;
    }

    public String getNotesPendingBids() {
        return notesPendingBids;
    }

    public void setNotesPendingBids(String notesPendingBids) {
        this.notesPendingBids = notesPendingBids;
    }

    public long getTotalWithdrawls() {
        return totalWithdrawls;
    }

    public void setTotalWithdrawls(long totalWithdrawls) {
        this.totalWithdrawls = totalWithdrawls;
    }

    public String getAdjustmentsDebits() {
        return adjustmentsDebits;
    }

    public void setAdjustmentsDebits(String adjustmentsDebits) {
        this.adjustmentsDebits = adjustmentsDebits;
    }





}
