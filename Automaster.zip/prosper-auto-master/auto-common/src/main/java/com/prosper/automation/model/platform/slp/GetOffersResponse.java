
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class GetOffersResponse {

    private List<SlpOffers> result;
    private int resultCount;
    private int totalCount;


    @JsonProperty("result")
    public List<SlpOffers> getResult() {
        return result;
    }

    public void setResult(final List<SlpOffers> result) {
        this.result = result;
    }

    @JsonProperty("result_count")
    public int getResultCount() {
        return resultCount;
    }

    public void setResultCount(final int resultCount) {
        this.resultCount = resultCount;
    }

    @JsonProperty("total_count")
    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(final int totalCount) {
        this.totalCount = totalCount;
    }
}
