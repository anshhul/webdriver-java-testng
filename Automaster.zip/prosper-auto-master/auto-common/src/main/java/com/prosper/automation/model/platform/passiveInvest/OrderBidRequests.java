
package com.prosper.automation.model.platform.passiveInvest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 25 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderBidRequests {

    @JsonProperty("listing_id")
    private Integer listingId;

    @JsonProperty("bid_amount")
    private Integer bidAmount;

    @JsonProperty("bid_status")
    private String bidStatus;


    public Integer getListingId() {
        return listingId;
    }

    public Integer getBidAmount() {
        return bidAmount;
    }

    public String getBidStatus() {
        return bidStatus;
    }
}
