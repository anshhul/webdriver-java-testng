
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"agreement_id"})
public final class CreateAgreementResponse {
    
    @JsonProperty("agreement_id")
    private String agreementId;
}
