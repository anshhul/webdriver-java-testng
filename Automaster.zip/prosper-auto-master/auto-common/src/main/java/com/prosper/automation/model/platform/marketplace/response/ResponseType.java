package com.prosper.automation.model.platform.marketplace.response;

/**
 * Created by rsubramanyam on 3/5/16.
 */
public enum ResponseType {
    VALIDATION_ERROR_WITH_ASSERTIONS("WITH_ASSERTIONS"),
    VALIDATION_ERROR_WITHOUT_ASSERTIONS("WITHOUT_ASSERTIONS"),
    UNAUTHORIZED_EXCEPTION_ERROR("UNAUTHORIZED_EXCEPTION_ERROR"),
    SUCCESS("SUCCESS");

    private String type;

    ResponseType(String errorType) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }
}
