
package com.prosper.automation.model.platform.passiveInvest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 25 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrdersSuccess {

    @JsonProperty("investor_id")
    private Integer investorId;

    @JsonProperty("order_id")
    private String orderId;

    @JsonProperty("order_bid_requests")
    private List<OrderBidRequests> orderBidRequests;

    @JsonProperty("success")
    private Boolean success;


    public Integer getInvestorId() {
        return investorId;
    }

    public String getOrderId() {
        return orderId;
    }

    public List<OrderBidRequests> getOrderBidRequests() {
        return orderBidRequests;
    }

    public Boolean getSuccess() {
        return success;
    }

}
