
package com.prosper.automation.model.platform.listing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class BidInformation {
    
    @JsonProperty("bid_id")
    private Long bidId;
    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("amount")
    private Double amount;
    @JsonProperty("participation")
    private Double participation;
    @JsonProperty("min_rate")
    private Double minRate;
    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("standing_bid_id")
    private Long standingBidId;
    @JsonProperty("funding_account_id")
    private Long fundingAccountId;
    @JsonProperty("collection_agency_id")
    private Long collectionAgencyId;
    @JsonProperty("withdrwan")
    private Boolean withdrwan;
    @JsonProperty("is_anonymous")
    private Boolean isAnonymous;
    @JsonProperty("bid_source")
    private String bidSource;
    @JsonProperty("min_yield")
    private Double minYield;
    @JsonProperty("investment_order_id")
    private Long investmentOrderId;
}
