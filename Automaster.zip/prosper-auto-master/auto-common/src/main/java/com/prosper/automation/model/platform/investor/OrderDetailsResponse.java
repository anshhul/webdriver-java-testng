package com.prosper.automation.model.platform.investor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class OrderDetailsResponse {

    private String orderNumber;
    private String createdDate;
    private String orderSource;
    private SavedSearch savedSearch;
    private int totalLoanCount;
    private int totalPendingLoanCount;
    private int totalExpiredLoanCount;
    private List<Listings> listings;
    private String orderId;
    private float investmentAmount;
    private float committedAmount;
    private double estimatedReturn;

    @JsonProperty("committed_amount")
    public float getCommittedAmount() {
        return committedAmount;
    }

    @JsonProperty("created_date")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("estimated_return")
    public double getEstimatedReturn() {
        return estimatedReturn;
    }

    @JsonProperty("investment_amount")
    public float getInvestmentAmount() {
        return investmentAmount;
    }

    @JsonProperty("listings")
    public List<Listings> getListings() {
        return listings;
    }

    @JsonProperty("orderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("order_number")
    public String getOrderNumber() {
        return orderNumber;
    }

    @JsonProperty("order_source")
    public String getOrderSource() {
        return orderSource;
    }

    @JsonProperty("saved_search")
    public SavedSearch getSavedSearch() {
        return savedSearch;
    }

    @JsonProperty("total_expired_loan_count")
    public int getTotalExpiredLoanCount() {
        return totalExpiredLoanCount;
    }

    @JsonProperty("total_loan_count")
    public int getTotalLoanCount() {
        return totalLoanCount;
    }

    @JsonProperty("total_pending_loan_count")
    public int getTotalPendingLoanCount() {
        return totalPendingLoanCount;
    }

    public void setCommittedAmount(final float committedAmount) {
        this.committedAmount = committedAmount;
    }

    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }

    public void setEstimatedReturn(final double estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public void setInvestmentAmount(final float investmentAmount) {
        this.investmentAmount = investmentAmount;
    }

    public void setListings(final List<Listings> listings) {
        this.listings = listings;
    }

    public void setOrderId(final String orderId) {
        this.orderId = orderId;
    }

    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setOrderSource(final String orderSource) {
        this.orderSource = orderSource;
    }

    public void setSavedSearch(final SavedSearch savedSearch) {
        this.savedSearch = savedSearch;
    }

    public void setTotalExpiredLoanCount(final int totalExpiredLoanCount) {
        this.totalExpiredLoanCount = totalExpiredLoanCount;
    }

    public void setTotalLoanCount(final int totalLoanCount) {
        this.totalLoanCount = totalLoanCount;
    }

    public void setTotalPendingLoanCount(final int totalPendingLoanCount) {
        this.totalPendingLoanCount = totalPendingLoanCount;
    }

}
