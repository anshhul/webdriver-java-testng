
package com.prosper.automation.model.platform.inquiry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListingInfo {
    
    @JsonProperty("txtSocialSecurityNumberResult")
    private String txtSocialSecurityNumberResult;
    @JsonProperty("ASScoreFactor2")
    private Integer asScoreFactor2;
    @JsonProperty("ASScoreFactor1")
    private Integer asScoreFactor1;
    @JsonProperty("txtSSNFormat")
    private String txtSSNFormat;
    @JsonProperty("ASScoreFactor4")
    private Integer asScoreFactor4;
    @JsonProperty("flgUserMultiBankAccounts")
    private Integer flgUserMultiBankAccounts;
    @JsonProperty("numUserTitleLength")
    private Integer numUserTitleLength;
    @JsonProperty("ASScoreFactor3")
    private Integer asScoreFactor3;
    @JsonProperty("monthsEmployed")
    private Integer monthsEmployed;
    @JsonProperty("flgChannelDM")
    private Integer flgChannelDM;
    @JsonProperty("flgSecurityAlertXML")
    private Integer flgSecurityAlertXML;
    @JsonProperty("userID")
    private Integer userID;
    @JsonProperty("flgSuspicionCriterion")
    private Integer flgSuspicionCriterion;
    @JsonProperty("txtIPZip")
    private String txtIPZip;
    @JsonProperty("state")
    private String state;
    @JsonProperty("catCheckpointScore")
    private String catCheckpointScore;
    @JsonProperty("catAcceptReferCode")
    private String catAcceptReferCode;
    @JsonProperty("numALL051")
    private Integer numALL051;
    @JsonProperty("verificationStatus")
    private String verificationStatus;
    @JsonProperty("ALL801")
    private Integer all801;
    @JsonProperty("catDLMatch")
    private String catDLMatch;
    @JsonProperty("numALL052")
    private Integer numALL052;
    @JsonProperty("numPrevOriginations")
    private Integer numPrevOriginations;
    @JsonProperty("numUserListingAmount")
    private Double numUserListingAmount;
    @JsonProperty("numBusinessAddressDetailRecords")
    private Integer numBusinessAddressDetailRecords;
    @JsonProperty("numILN701")
    private Integer numILN701;
    @JsonProperty("uUserID")
    private Integer uUserID;
    @JsonProperty("numUserRegistrationAgeMonths")
    private Integer numUserRegistrationAgeMonths;
    @JsonProperty("numCheckpointScore")
    private Integer numCheckpointScore;
    @JsonProperty("catAddressHighRiskResult")
    private String catAddressHighRiskResult;
    @JsonProperty("employmentDescription")
    private String employmentDescription;
    @JsonProperty("FSSUM")
    private Integer fsSum;
    @JsonProperty("flgFS16")
    private Integer flgFS16;
    @JsonProperty("numAddressHighRiskDetailRecords")
    private Integer numAddressHighRiskDetailRecords;
    @JsonProperty("eID")
    private Integer eID;
    @JsonProperty("flgFS15")
    private Integer flgFS15;
    @JsonProperty("flgFS14")
    private Integer flgFS14;
    @JsonProperty("flgFS13")
    private Integer flgFS13;
    @JsonProperty("numALL062")
    private Integer numALL062;
    @JsonProperty("numMinDupCreditScore")
    private Integer numMinDupCreditScore;
    @JsonProperty("flgFS19")
    private Integer flgFS19;
    @JsonProperty("flgFS18")
    private Integer flgFS18;
    @JsonProperty("numALL064")
    private Integer numALL064;
    @JsonProperty("flgFS17")
    private Integer flgFS17;
    @JsonProperty("occupationName")
    private String occupationName;
    @JsonProperty("BOVStatusID")
    private Integer bovStatusID;
    @JsonProperty("txtDLResultCode")
    private String txtDLResultCode;
    @JsonProperty("catIPCountryMatch")
    private String catIPCountryMatch;
    @JsonProperty("flgMaxDupNoLoan")
    private Integer flgMaxDupNoLoan;
    @JsonProperty("uID")
    private Integer uID;
    @JsonProperty("flgPriorUnprocessedFS")
    private String flgPriorUnprocessedFS;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("numConsumerTotal")
    private Integer numConsumerTotal;
    @JsonProperty("txtIPCity")
    private String txtIPCity;
    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;
    @JsonProperty("flgFS12")
    private Integer flgFS12;
    @JsonProperty("flgFS11")
    private Integer flgFS11;
    @JsonProperty("MILStatusID")
    private String milStatusID;
    @JsonProperty("email")
    private String email;
    @JsonProperty("flgFS10")
    private Integer flgFS10;
    @JsonProperty("DID")
    private Integer did;
    @JsonProperty("checkReviewTypeID")
    private Integer checkReviewTypeID;
    @JsonProperty("initialListingAmount")
    private Double initialListingAmount;
    @JsonProperty("flgBlockedFile")
    private Integer flgBlockedFile;
    @JsonProperty("flgFS27")
    private Integer flgFS27;
    @JsonProperty("flgMaxDupLoanDPD30Greater")
    private Integer flgMaxDupLoanDPD30Greater;
    @JsonProperty("flgFS26")
    private Integer flgFS26;
    @JsonProperty("flgFS25")
    private Integer flgFS25;
    @JsonProperty("missingData")
    private Integer missingData;
    @JsonProperty("SUserID")
    private Integer sUserID;
    @JsonProperty("numREV201")
    private Integer numREV201;
    @JsonProperty("userId")
    private Integer userId;
    @JsonProperty("catOFACValidationResult")
    private String catOFACValidationResult;
    @JsonProperty("flgMaxDupLoanPaid")
    private Integer flgMaxDupLoanPaid;
    @JsonProperty("numPhoneHighRiskDetailRecords")
    private Integer numPhoneHighRiskDetailRecords;
    @JsonProperty("numBAC403")
    private Integer numBAC403;
    @JsonProperty("catAuthenticationScore")
    private String catAuthenticationScore;
    @JsonProperty("catAlertMessage")
    private String catAlertMessage;
    @JsonProperty("percentFailLogins")
    private Integer percentFailLogins;
    @JsonProperty("numModelScore")
    private Integer numModelScore;
    @JsonProperty("hasPriorLoanFlag")
    private Integer hasPriorLoanFlag;
    @JsonProperty("IPAddress")
    private String ipAddress;
    @JsonProperty("numBAC401")
    private Integer numBAC401;
    @JsonProperty("flgFS22")
    private Integer flgFS22;
    @JsonProperty("flgFS21")
    private Integer flgFS21;
    @JsonProperty("flgFS20")
    private Integer flgFS20;
    @JsonProperty("numResidentialPhoneDetailRecords")
    private Integer numResidentialPhoneDetailRecords;
    @JsonProperty("numALL002")
    private Integer numALL002;
    @JsonProperty("homePhoneNumber")
    private String homePhoneNumber;
    @JsonProperty("txtPhoneUnitMismatchResult")
    private String txtPhoneUnitMismatchResult;
    @JsonProperty("numALL001")
    private Integer numALL001;
    @JsonProperty("catOutputTypeCode")
    private String catOutputTypeCode;
    @JsonProperty("numSSNDetailRecords")
    private Integer numSSNDetailRecords;
    @JsonProperty("catIPStateMatch")
    private String catIPStateMatch;
    @JsonProperty("eUserID")
    private Integer eUserID;
    @JsonProperty("workPhoneNumber")
    private String workPhoneNumber;
    @JsonProperty("bankRoutingNumber")
    private String bankRoutingNumber;
    @JsonProperty("flgLargeFile")
    private Integer flgLargeFile;
    @JsonProperty("flgUserMultiBankHolders")
    private Integer flgUserMultiBankHolders;
    @JsonProperty("flgFS05")
    private Integer flgFS05;
    @JsonProperty("flgFS04")
    private Integer flgFS04;
    @JsonProperty("flgFS03")
    private Integer flgFS03;
    @JsonProperty("flgFraudScreen")
    private Integer flgFraudScreen;
    @JsonProperty("listCancelLast30")
    private String listCancelLast30;
    @JsonProperty("flgFS02")
    private Integer flgFS02;
    @JsonProperty("numScoreFactorCount")
    private Integer numScoreFactorCount;
    @JsonProperty("flgFS09")
    private Integer flgFS09;
    @JsonProperty("flgFS08")
    private Integer flgFS08;
    @JsonProperty("flgFS07")
    private Integer flgFS07;
    @JsonProperty("flgFS06")
    private Integer flgFS06;
    @JsonProperty("numREP002")
    private Integer numREP002;
    @JsonProperty("numUserLogins")
    private Integer numUserLogins;
    @JsonProperty("userLoanHistorySnapshotID")
    private String userLoanHistorySnapshotID;
    @JsonProperty("SID")
    private Integer sid;
    @JsonProperty("numUserPercentFailLogins")
    private Double numUserPercentFailLogins;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("numCustomerOnlyTotal")
    private Integer numCustomerOnlyTotal;
    @JsonProperty("numBusinessPhoneDetailRecords")
    private Integer numBusinessPhoneDetailRecords;
    @JsonProperty("numALL803")
    private Integer numALL803;
    @JsonProperty("numALL806")
    private Integer numALL806;
    @JsonProperty("flgFS01")
    private Integer flgFS01;
    @JsonProperty("numBAC026")
    private Integer numBAC026;
    @JsonProperty("catLevelOneDecisionCode")
    private String catLevelOneDecisionCode;
    @JsonProperty("numUserSuccessLogins")
    private Integer numUserSuccessLogins;
    @JsonProperty("income")
    private Integer income;
    @JsonProperty("flgSSNDeceased")
    private Integer flgSSNDeceased;
    @JsonProperty("numALL021")
    private Integer numALL021;
    @JsonProperty("numALL142")
    private Integer numALL142;
    @JsonProperty("numAddressHighRiskDescriptionRecords")
    private Integer numAddressHighRiskDescriptionRecords;
    @JsonProperty("numMaxDupDateOfBirthDiff")
    private Integer numMaxDupDateOfBirthDiff;
    @JsonProperty("numUserBankCount")
    private Integer numUserBankCount;
    @JsonProperty("numALL141")
    private Integer numALL141;
    @JsonProperty("P1801")
    private String p1801;
    @JsonProperty("numALL701")
    private Integer numALL701;
    @JsonProperty("numALL026")
    private Integer numALL026;
    @JsonProperty("flgDupExistence")
    private Integer flgDupExistence;
    @JsonProperty("dUserID")
    private Integer dUserID;
    @JsonProperty("numREF001")
    private Integer numREF001;
    @JsonProperty("flgMaxDupLoanDPD0Greater")
    private Integer flgMaxDupLoanDPD0Greater;
    @JsonProperty("flgUserTitleDebt")
    private Integer flgUserTitleDebt;
    @JsonProperty("numCOADescriptionRecords")
    private Integer numCOADescriptionRecords;
    @JsonProperty("flgDupTypeCookie")
    private Integer flgDupTypeCookie;
    @JsonProperty("percentSuccessLogins")
    private Integer percentSuccessLogins;
    @JsonProperty("txtAddressTypeResult")
    private String txtAddressTypeResult;
    @JsonProperty("aggregateBalanceCreditRatioOnAllTrades6Months")
    private Double aggregateBalanceCreditRatioOnAllTrades6Months;
    @JsonProperty("numAuthenticationScore")
    private Integer numAuthenticationScore;
    @JsonProperty("catDateOfBirthMatch")
    private String catDateOfBirthMatch;
    @JsonProperty("flgMaxDupBusinessAddress")
    private Integer flgMaxDupBusinessAddress;
    @JsonProperty("flgUserTitleConsolidation")
    private Integer flgUserTitleConsolidation;
    @JsonProperty("catDLSMatch")
    private String catDLSMatch;
    @JsonProperty("catPhoneHighRiskResult")
    private String catPhoneHighRiskResult;
    @JsonProperty("numSSNIssueEndRange")
    private Integer numSSNIssueEndRange;
    @JsonProperty("flgConsumerStatement")
    private Integer flgConsumerStatement;
    @JsonProperty("flgActiveDutyXML")
    private Integer flgActiveDutyXML;
    @JsonProperty("flgMaxDupFailedPayment")
    private Integer flgMaxDupFailedPayment;
    @JsonProperty("REV702")
    private Integer rev702;
    @JsonProperty("LoanProductID")
    private Integer loanProductID;
    @JsonProperty("userCreditProfileID")
    private Integer userCreditProfileID;
    @JsonProperty("occupation")
    private String occupation;
    @JsonProperty("txtAddressVerificationResult")
    private String txtAddressVerificationResult;
    @JsonProperty("monthlyDebt")
    private Double monthlyDebt;
    @JsonProperty("flgMaxDupUserStatusNotActive")
    private Integer flgMaxDupUserStatusNotActive;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("numALL208")
    private Integer numALL208;
    @JsonProperty("listingID")
    private Integer listingID;
    @JsonProperty("numALL207")
    private Integer numALL207;
    @JsonProperty("flgDupTypePhone")
    private Integer flgDupTypePhone;
    @JsonProperty("numALL201")
    private Integer numALL201;
    @JsonProperty("isStateOfResidenceVerified")
    private String isStateOfResidenceVerified;
    @JsonProperty("numALE007")
    private Integer numALE007;
    @JsonProperty("numCOARecords")
    private Integer numCOARecords;
    @JsonProperty("flgMaxDupSameLastName")
    private Integer flgMaxDupSameLastName;
    @JsonProperty("flgFraudScreenEmail")
    private Integer flgFraudScreenEmail;
    @JsonProperty("ID")
    private Integer id;
    @JsonProperty("termsApprovalDate")
    private String termsApprovalDate;
    @JsonProperty("numPhoneHighRiskDescriptionRecords")
    private Integer numPhoneHighRiskDescriptionRecords;
    @JsonProperty("numUser30DBankChange")
    private Integer numUser30DBankChange;
    @JsonProperty("incomeLELastProspMod")
    private String incomeLELastProspMod;
    @JsonProperty("numAvgDupDateOfBirthDiff")
    private Integer numAvgDupDateOfBirthDiff;
    @JsonProperty("empStatusChgFlag")
    private String empStatusChgFlag;
    @JsonProperty("numREV023")
    private Integer numREV023;
    @JsonProperty("numDistinctDups")
    private Integer numDistinctDups;
    @JsonProperty("txtSSNIssueState")
    private String txtSSNIssueState;
    @JsonProperty("flgMaxDupLoanDPD120Greater")
    private Integer flgMaxDupLoanDPD120Greater;
    @JsonProperty("DTIwoProspLoan")
    private Double dtiWoProspLoan;
    @JsonProperty("flgFraudAlert")
    private Integer flgFraudAlert;
    @JsonProperty("numSSNIssueStartRange")
    private Integer numSSNIssueStartRange;
    @JsonProperty("flgMaxDupUserStatusSuspendedTerminated")
    private Integer flgMaxDupUserStatusSuspendedTerminated;
    @JsonProperty("flgMaxDupHighPayment")
    private Integer flgMaxDupHighPayment;
    @JsonProperty("flgUserPrePaidBankAccount")
    private Integer flgUserPrePaidBankAccount;
    @JsonProperty("catSSNMatch")
    private String catSSNMatch;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("city")
    private String city;
    @JsonProperty("P1601")
    private String p1601;
    @JsonProperty("numALL901")
    private Integer numALL901;
    @JsonProperty("txtPhoneVerificationResult")
    private String txtPhoneVerificationResult;
    @JsonProperty("flgMaxDupRecentListing")
    private Integer flgMaxDupRecentListing;
    @JsonProperty("pendingStartDate")
    private String pendingStartDate;
    @JsonProperty("dupes")
    private String dupes;
    @JsonProperty("numUserEmploymentLengthMonths")
    private Integer numUserEmploymentLengthMonths;
    @JsonProperty("numFailLogins")
    private Integer numFailLogins;
    @JsonProperty("txtSSNIssueResultCode")
    private String txtSSNIssueResultCode;
    @JsonProperty("mobilePhoneNumber")
    private String mobilePhoneNumber;
    @JsonProperty("flgMaxDupHighAgeDiff")
    private Integer flgMaxDupHighAgeDiff;
    @JsonProperty("numUser30DBankCount")
    private Integer numUser30DBankCount;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("catModelScore")
    private String catModelScore;
    @JsonProperty("numResidentialAddressDetailRecords")
    private Integer numResidentialAddressDetailRecords;
    @JsonProperty("txtIPState")
    private String txtIPState;
    @JsonProperty("DTIChg20k36MoLoan")
    private Double dtiChg20k36MoLoan;
    @JsonProperty("numAvgDupCreditScore")
    private Integer numAvgDupCreditScore;
    @JsonProperty("numILN201")
    private Integer numILN201;
    @JsonProperty("flgDupTypeBank")
    private Integer flgDupTypeBank;
    @JsonProperty("numPrevWithdrawals")
    private Integer numPrevWithdrawals;
    @JsonProperty("catSSNIssueStartRange")
    private String catSSNIssueStartRange;
    @JsonProperty("flgFraudVictimXML")
    private Integer flgFraudVictimXML;
    @JsonProperty("userLogins")
    private Integer userLogins;
    @JsonProperty("MRProspModIncomeDate")
    private String mrProspModIncomeDate;
    @JsonProperty("numUserAgeYears")
    private Integer numUserAgeYears;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("numALL084")
    private Integer numALL084;
    @JsonProperty("flgMaxDupLoanChargeoffDefault")
    private Integer flgMaxDupLoanChargeoffDefault;
    @JsonProperty("flgMaxDupLatePayment")
    private Integer flgMaxDupLatePayment;
    @JsonProperty("suffix")
    private String suffix;
    @JsonProperty("catIPCityMatch")
    private String catIPCityMatch;
    @JsonProperty("flgMaxDupSameFirstName")
    private Integer flgMaxDupSameFirstName;
    @JsonProperty("numALL081")
    private Integer numALL081;
    @JsonProperty("bankContactResultTypeID")
    private Integer bankContactResultTypeID;
    @JsonProperty("flgUserSuspicion")
    private Integer flgUserSuspicion;
    @JsonProperty("listingTitle")
    private String listingTitle;
    @JsonProperty("catYOBMatch")
    private String catYOBMatch;
    @JsonProperty("numILN108")
    private Integer numILN108;
    @JsonProperty("flgMaxDupLoanDPD60Greater")
    private Integer flgMaxDupLoanDPD60Greater;
    @JsonProperty("flgVictimStatement")
    private Integer flgVictimStatement;
    @JsonProperty("IPAddressEncoded")
    private Integer ipAddressEncoded;
    @JsonProperty("flgMaxDupCreditScoreLow")
    private Integer flgMaxDupCreditScoreLow;
    @JsonProperty("numPrevCancellations")
    private Integer numPrevCancellations;
    @JsonProperty("offerCode")
    private String offerCode;
    @JsonProperty("stateCode")
    private String stateCode;
    @JsonProperty("flgMaxDupSameName")
    private Integer flgMaxDupSameName;
    @JsonProperty("flgMaxDupRecentLoan")
    private Integer flgMaxDupRecentLoan;
    @JsonProperty("flgDupTypeAddress")
    private Integer flgDupTypeAddress;
    @JsonProperty("numRTR751")
    private Integer numRTR751;
    @JsonProperty("annualIncome")
    private Double annualIncome;
    @JsonProperty("numAgeOfAuthenticationYears")
    private Integer numAgeOfAuthenticationYears;
    @JsonProperty("numUserFailLogins")
    private Integer numUserFailLogins;
    @JsonProperty("numInWalletScore")
    private Integer numInWalletScore;
    @JsonProperty("bankName")
    private String bankName;
    @JsonProperty("P1401")
    private String p1401;
    @JsonProperty("campaignChannelName")
    private String campaignChannelName;
    @JsonProperty("flgOFAC")
    private String flgOFAC;
    @JsonProperty("dateAuthenticationCreationDate")
    private Long dateAuthenticationCreationDate;
    @JsonProperty("ADRStatusID")
    private String adrStatusID;
    @JsonProperty("catIPZipMatch")
    private String catIPZipMatch;
    @JsonProperty("catInWalletScore")
    private String catInWalletScore;
    @JsonProperty("catAddressUnitMismatchResult")
    private String catAddressUnitMismatchResult;
    @JsonProperty("numAgeOfAuthenticationMonths")
    private Integer numAgeOfAuthenticationMonths;
    @JsonProperty("flgMaxDupLoanDPD90Greater")
    private Integer flgMaxDupLoanDPD90Greater;
    @JsonProperty("numPrimaryResult")
    private String numPrimaryResult;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("flgMaxDupLoanActive")
    private Integer flgMaxDupLoanActive;
    @JsonProperty("numILN005")
    private Integer numILN005;
    @JsonProperty("SSN")
    private String ssn;
    @JsonProperty("numILN007")
    private Integer numILN007;
    @JsonProperty("numILN002")
    private Integer numILN002;
    @JsonProperty("flgMaxDupManualPayment")
    private Integer flgMaxDupManualPayment;
    @JsonProperty("openPaidClosedInactiveInstallTrades")
    private Integer openPaidClosedInactiveInstallTrades;
    @JsonProperty("flgSecurityAlert")
    private Integer flgSecurityAlert;
    @JsonProperty("flgMaxDupCreditScoreMissing")
    private Integer flgMaxDupCreditScoreMissing;
    @JsonProperty("campaignName")
    private String campaignName;
    
    
    public ListingInfo() {
    }
}
