
package com.prosper.automation.model.gds.processor;

import com.google.common.base.Preconditions;
import com.prosper.automation.model.gds.GDSHoldResponse;

import java.util.Map;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class GDSListing {

    private static final String NULL_GDS_REQUEST_LOG = "gdsRequest can not be null.";
    private static final String NULL_GDS_RESPONSE_LOG = "gdsResponse can not be null.";

    private final String listingId;

    private Map<String, String> gdsRequest;
    private GDSHoldResponse gdsResponse;


    public GDSListing(final String listingId) {
        this.listingId = listingId;
    }

    public GDSHoldResponse getGdsResponse() {
        return gdsResponse;
    }

    public Map<String, String> getGDSRequest() {
        return gdsRequest;
    }

    public void setGDSRequest(Map<String, String> gdsRequest) {
        Preconditions.checkNotNull(gdsRequest, NULL_GDS_REQUEST_LOG);
        this.gdsRequest = gdsRequest;
    }

    public void setListingResponse(GDSHoldResponse gdsResponse) {
        Preconditions.checkNotNull(gdsResponse, NULL_GDS_RESPONSE_LOG);
        this.gdsResponse = gdsResponse;
    }

    public String getListingId() {
        return listingId;
    }
}
