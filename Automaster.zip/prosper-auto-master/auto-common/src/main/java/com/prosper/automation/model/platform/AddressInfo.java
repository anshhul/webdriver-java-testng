
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"address_1", "city", "state", "zip_code", "address_type_id", "source_type_id"})
@JsonIgnoreProperties(ignoreUnknown = true)
public final class AddressInfo {

    private static final int ZIP_CODE_START_INDEX = 0;
    private static final int ZIP_CODE_END_INDEX = 4;
    @JsonProperty("addressAsString")
    private String addressAsString;
    @JsonProperty("city")
    private String city;
    @JsonProperty("address_1")
    private String address1;
    @JsonProperty("address_2")
    private String address2;
    @JsonProperty("address_type_id")
    private Integer addressTypeId;
    @JsonProperty("source_type_id")
    private Integer sourceTypeId;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip_code")
    private String zipCode;
    @JsonProperty("street")
    private String street;
    @JsonProperty("state_of_residence")
    private String stateOfResidence;

    // Platform-application properties
    @JsonProperty("address")
    private String address;
    @JsonProperty("address_as_string")
    private String addressAsStringForApplication;
    @JsonProperty("address_type")
    private String addressType;
    @JsonProperty("ownership_type")
    private String ownershipType;


    public AddressInfo() {
    }

    private AddressInfo(final Builder builder) {
        city = builder.city;
        address1 = builder.address1;
        address2 = builder.address2;
        addressTypeId = builder.addressTypeId;
        sourceTypeId = builder.sourceTypeId;
        state = builder.state;
        zipCode = builder.zipCode;
        street = builder.street;
        stateOfResidence = builder.stateOfResidence;
        address = builder.address;
        addressAsStringForApplication = builder.addressAsStringForApplication;
        addressType = builder.addressType;
    }

    @JsonIgnore
    public Integer getAddressTypeId() {
        return addressTypeId;
    }

    public void setAddressTypeId(Integer addressTypeId) {
        this.addressTypeId = addressTypeId;
    }

    @JsonIgnore
    public Integer getSourceTypeId() {
        return sourceTypeId;
    }

    public void setSourceTypeId(Integer sourceTypeId) {
        this.sourceTypeId = sourceTypeId;
    }

    @JsonIgnore
    public String getCity() {
        return city;
    }

    public void setCity(final String city) {
        this.city = city;
    }

    @JsonIgnore
    public String getAddress1() {
        return address1;
    }

    public void setAddress1(final String address1) {
        this.address1 = address1;
    }

    @JsonIgnore
    public String getAddress2() {
        return address2;
    }

    public void setAddress2(final String address2) {
        this.address2 = address2;
    }

    @JsonIgnore
    public String getState() {
        return state;
    }

    public void setState(final String state) {
        this.state = state;
    }

    @JsonIgnore
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(final String zipCode) {
        this.zipCode = zipCode;
    }

    @JsonIgnore
    public String getAddressAsString() {
        return addressAsString;
    }

    public void setAddressAsString(String addressAsString) {
        this.addressAsString = addressAsString;
    }

    @JsonIgnore
    public String getStateOfResidence() {
        return stateOfResidence;
    }

    public void setStateOfResidence(String stateOfResidence) {
        this.stateOfResidence = stateOfResidence;
    }

    @JsonIgnore
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @JsonIgnore
    public String getAddressAsStringForApplication() {
        return addressAsStringForApplication;
    }

    public void setAddressAsStringForApplication(String addressAsStringForApplication) {
        this.addressAsStringForApplication = addressAsStringForApplication;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AddressInfo that = (AddressInfo) o;
        return Objects.equal(addressAsString, that.addressAsString) &&
                Objects.equal(city, that.city) &&
                Objects.equal(address1, that.address1) &&
                Objects.equal(address2, that.address2) &&
                Objects.equal(addressTypeId, that.addressTypeId) &&
                Objects.equal(sourceTypeId, that.sourceTypeId) &&
                Objects.equal(state, that.state) &&
                Objects.equal(zipCode, that.zipCode) &&
                Objects.equal(street, that.street) &&
                Objects.equal(stateOfResidence, that.stateOfResidence) &&
                Objects.equal(address, that.address) &&
                Objects.equal(addressAsStringForApplication, that.addressAsStringForApplication) &&
                Objects.equal(addressType, that.addressType);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(addressAsString, city, address1, address2, addressTypeId, sourceTypeId, state, zipCode, street,
                stateOfResidence, address, addressAsStringForApplication, addressType);
    }

    @Override
    public String toString() {
        return "AddressInfo{" +
                "addressAsString='" + addressAsString + '\'' +
                ", city='" + city + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", addressTypeId=" + addressTypeId +
                ", sourceTypeId=" + sourceTypeId +
                ", state='" + state + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", street='" + street + '\'' +
                ", stateOfResidence='" + stateOfResidence + '\'' +
                ", address='" + address + '\'' +
                ", addressAsStringForApplication='" + addressAsStringForApplication + '\'' +
                ", addressType=" + addressType +
                '}';
    }

    private String trimZipCode(final String zipCode) {
        return zipCode.replace("-", "").substring(ZIP_CODE_START_INDEX, ZIP_CODE_END_INDEX);
    }


    public static final class Builder {

        private String city;
        private String address1;
        private String address2;
        private Integer addressTypeId;
        private Integer sourceTypeId;
        private String state;
        private String zipCode;
        private String street;
        private String stateOfResidence;
        private String address;
        private String addressAsStringForApplication;
        private String addressType;


        public Builder() {
        }

        public Builder withCity(final String city) {
            this.city = city;
            return this;
        }

        public Builder withAddress1(final String address1) {
            this.address1 = address1;
            return this;
        }

        public Builder withAddress2(final String address2) {
            this.address2 = address2;
            return this;
        }

        public Builder withAddressTypeId(final Integer addressTypeId) {
            this.addressTypeId = addressTypeId;
            return this;
        }

        public Builder withSourceTypeId(final Integer sourceTypeId) {
            this.sourceTypeId = sourceTypeId;
            return this;
        }

        public Builder withState(final String state) {
            this.state = state;
            return this;
        }

        public Builder withZipCode(final String zipCode) {
            this.zipCode = zipCode;
            return this;
        }

        public Builder withStreet(final String street) {
            this.street = street;
            return this;
        }

        public Builder withStateOfResidence(final String stateOfResidence) {
            this.stateOfResidence = stateOfResidence;
            return this;
        }

        public Builder withAddress(final String address) {
            this.address = address;
            return this;
        }

        public Builder withAddressAsStringForApplication(final String addressAsStringForApplication) {
            this.addressAsStringForApplication = addressAsStringForApplication;
            return this;
        }

        public Builder withAddressType(final String addressType) {
            this.addressType = addressType;
            return this;
        }

        public AddressInfo build() {
            return new AddressInfo(this);
        }
    }
}
