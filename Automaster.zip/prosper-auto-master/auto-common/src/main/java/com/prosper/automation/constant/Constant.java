
package com.prosper.automation.constant;


import com.google.common.collect.Lists;
import com.prosper.automation.enumeration.SortOrder;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class Constant {

    // max results in a response object
    public static final int MAX_RESULT_SIZE = 25;

    // epsilon
    public static final Double EPSILON = 0.00001D;

    // random generator
    public static final Random RANDOM = new Random();
    // User name type id
    public static final int LEGAL_NAME_USER_TYPE_ID = 3;
    // Source type id
    public static final int USER_INPUT_TYPE_ID = 1;
    // Requested loan amount
    public static final double GENERIC_LOAN_AMOUNT = 20000;
    public static final double LOWER_BOUND_LOAN_AMOUNT = 1999;
    public static final double UPPER_BOUND_LOAN_AMOUNT = 35001;
    // Loan purpose
    public static final long GENERIC_LOAN_PURPOSE_ID = 1;
    // Loan status types
    public static final int ORIGINATIONDELAYED = 0;
    public static final int CURRENT = 1;
    public static final int CHARGEOFF = 2;
    public static final int DEFAULTED = 3;
    public static final int COMPLETED = 4;
    public static final int FINALPAYMENTINPROGRESS = 5;
    public static final int CANCELLED = 6;

    //Listing status types
    public static final int SAVED_DRAFT = 0;
    public static final int PENDING_ACTIVATION = 1;
    public static final int ACTIVE = 2;
    public static final int ON_HOLD = 3;
    public static final int WITHDRAWN = 4;
    public static final int EXPIRED = 5;
    public static final int LISTING_COMPLETED = 6;
    public static final int LISTING_CANCELLED = 7;
    public static final int PENDING_COMPLETION = 8;
    public static final int FAILED_GROUP_LEADER_REVIEW = 9;


    // Listing category id
    public static final long GENERIC_LISTING_CATEGORY_ID = 1;
    // Credit range id
    public static final long GENERIC_CREDIT_RANGE_ID = 1;
    // User type
    public static final String LENDER_USER_TYPE = "LENDER";
    // SSN
    public static final String SSN_WITH_LEADING_ZEROES_AND_DASHES = "001-11-1234";
    public static final String SSN_WITH_LEADING_ZEROES = "003451234";
    public static final String SSN_WITH_DASH = "666-08-9526";
    public static final String SSN_WITHOUT_DASH = "666108747";
    public static final String ALPHA_NUMERIC_SSN = "abc-08-ab90";
    public static final String EIGHT_DIGIT_SSN = "66608952";
    public static final String TEN_DIGIT_SSN = "6660895223";
    // Rick Nick
    public static final String RICK_NICK_FIRST_NAME = "Rick";
    public static final String RICK_NICK_LAST_NAME = "Nick";
    public static final String RICK_NICK_DATE_OF_BIRTH = "01/01/1945";
    public static final String RICK_NICK_SSN = "666-19-3191";
    // FRED RUIZ-CRUZ
    public static final String FRED_RUIZ_CRUZ_FIRST_NAME = "FRED";
    public static final String FRED_RUIZ_CRUZ_LAST_NAME = "RUIZ-CRUZ";
    public static final String DEFAULT_DRIVER_LICENSE = "1234567890";
    public static final String FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH = "RUIZ CRUZ";
    public static final String FRED_RUIZ_CRUZ_DATE_OF_BIRTH_WITH_HYPHEN = "01-01-1956";
    public static final String FRED_RUIZ_CRUZ_DATE_OF_BIRTH = "01/01/1956";
    public static final String FRED_RUIZ_CRUZ_SSN = "666-44-5944";

    // WV address details
    public static final String WV_ADDRESS_1 = "501 Virginia St E";
    public static final String WV_CITY = "Charleston";
    public static final String WV_STATE = "WV";
    public static final String WV_ZIP_CODE = "25301";

    // Non RICK-CRUZ, Non FRED data
    public static final String NON_FRED_NON_RICK_LAST_NAME = "Z";
    public static final String NON_FRED_NON_RICK_ADDRESS = "27 Union Square";
    public static final String NON_FRED_NON_RICK_ZIPCODE = "94538";
    //Mary Hopkins Data
    public static final String MARY_FIRST = "MARY";
    public static final String MARY_LAST = "HOPKINS";
    public static final String MARY_MIDDLE = "E";
    public static final String MARY_STREET = "Pineland Avenue";
    public static final String MARY_CITY = "Hinesville";
    public static final String MARY_STATE = "GA";
    public static final String MARY_HOUSENUMBER = "912";
    public static final String MARY_ZIPCODE = "31313";
    public static final String MARY_SSN = "666451341";
    public static final String MARY_DOB = "1984-01-01";

    // common
    public static final String DASH_STRING = "-";
    public static final int MONTHS_IN_YEAR = 12;
    public static final String ONE_STRING_FORMAT_TEMPLATE = "%s";
    public static final String TWO_STRING_FORMAT_TEMPLATE = "%s%s";
    public static final String THREE_STRING_FORMAT_TEMPLATE = "%s%s%s";
    public static final String FAKE_SSN = "909-32-9283";
    public static final String SINGLE_SPACE_STRING = " ";
    public static final String BLANK_STRING = "";
    public static final String TEST_ALPHANUMERIC_STRING = "String007";
    public static final String STRING_WITH_SPECIAL_CHARACTERS = "!@#$%^&*()_";
    // PersonalInfo test data
    public static final String TEST_FIRST_NAME = "Monise";
    public static final String TEST_LAST_NAME = "Kelly";
    //666-47-0340 666-05-7741
    public static final String TEST_SSN = "666-30-2683";
    public static final String TEST_SSN_WITHOUT_DASH = "666302683";
    public static final String TEST_DATE_OF_BIRTH = "1/1/1963";
    public static final String TEST_DATE_OF_DEATH = "01/01/2016";
    public static final int TEST_USER_NAME_TYPE_ID = 3;
    public static final int TEST_SOURCE_TYPE_ID = 3;
    public static final String TEST_ALPHANUMERIC_FIRST_NAME = "FirstName007";
    public static final String TEST_ALPHANUMERIC_LAST_NAME = "FirstName007";
    public static final String TEST_LAST_NAME_WITH_DASH = "Sausage-Hausen";
    public static final String TEST_LAST_NAME_WITH_APOSTROPHE = "O'Brian";
    // EmploymentInfo data
    public static final String TEST_EMPLOYMENT_STATUS_ID = "7";
    public static final double TEST_ANNUAL_INCOME = 100000.0;
    // LendingAccreditation data
    public static final boolean TEST_CREDIT_PROFILE_AUTH = true;
    public static final boolean TEST_PRIVACY_POLICIES_AGREEMENT = true;
    // UserRequest data
    public static final String TEST_INTENDED_ROLE = "2";
    public static final int TEST_CREDIT_GRADE = 7;
    public static final int TEST_MONTHLY_DEBT = 1000;
    public static final UUID FAKE_UUID = UUID.randomUUID();
    public static final String INVALID_UUID_STRING = "eb2a9347-c186-46129db6-e6f415f189ca";
    public static final String FAKE_CLIENT_ID = "FAKE_CLIENT_ID";
    public static final String FAKE_CLIENT_SECRET = "FAKE_CLIENT_SECRET";
    public static final String FAKE_USER_EMAIL = "fake@prosper.com";
    public static final String FAKE_USER_PASSWORD = "fake@prosper.com";
    public static final String INVALID_USER_EMAIL_FORMAT = "fake@fake@prospser.com";
    public static final String EMAIL_WITH_ALPHANUMERIC_CHARACTERS = "james007@prosper.com";
    public static final String API_USERTOKEN_EMAIL = "fortokenonly100@c1.dev";
    public static final String PROD_EMAIL = "testproduser1@p2pcredit.com";
    public static final String PROD_PASS = "2yl8o7qcmgvUHSuZ0lkv8w==";
    public static final String PROD_SUPPORTSITE_EMAIL = "BPNbEyFZjVDAYCRM+SeB/cYDTYDLtWHb";
    public static final String PROD_SUPPORTSITE_PASS = "dTD2luY//RW5RZQN3fuXuw==";
    public static final String STAGE2_QA32_EMAIL = "9mnOeVRAPmsd@c1.dev";
    public static final String COMMON_PASSWORD = "P@ssword23";
    public static final String SUPPORT_SITE_PASSWORD = "P@ssword23";
    public static final String OLD_PASSWORD = "Password23";
    public static final String INVALID_PASSWORD = "P@ssword24";
    public static final String LESS_THAN_EIGHT_CHARACTERS_PASSWORD = "Pass23";
    public static final String PASSWORD_WITH_NO_CHARACTER = "123456789";
    public static final String PASSWORD_WITH_NO_NUMBER = "Password";
    public static final String VALID_UPPERCASE_PASSWORD = "PASSWORD23";
    public static final String VALID_LOWERCASE_PASSWORD = "password23";
    public static final String SEVEN_ALPHANUMERIC_CHARS = "ABC1234";
    public static final String TWELVE_ALPHANUMERIC_CHARS = "ABCDE1234567";
    // TODO: bad approach; user id is an int data type which has limit of 2
    // billion ++.
    // We assume that user with ID 2000000000 does not exist everywhere.
    public static final long INVALID_USER_ID = 2000000000L;
    public static final String EMAIL_TYPE_VERIFICATION = "ACTIVATION_EMAIL";
    // GDS
    public static final String GDS_FTP_HOST_NAME = "gds.ftp.host.name";
    public static final String GDS_FTP_HOST_USER = "gds.ftp.host.user";
    public static final String GDS_FTP_HOST_PASSWORD = "gds.ftp.host.password";
    public static final String GDS_FTP_HOST_GIACT_DIRECTORY = "gds.ftp.giact.directory";
    public static final String GDS_FTP_HOST_IDA_DIRECTORY = "gds.ftp.ida.directory";
    public static final String GDS_FTP_HOST_TWN_DIRECTORY = "gds.ftp.twn.directory";
    public static final String GDS_FTP_HOST_LN_DIRECTORY = "gds.ftp.ln.directory";
    // REGISTERED USER
    public static final String REGISTERED_USER_ROLE = "REGISTERED";
    public static final String REGISTERED_USER_ACTIVE = "ACTIVE";
    public static final String REGISTERED_USER_BECOME_BORROWER_ROLE = "Registered,Borrower";
    public static final String SCHEME_URL_TEMPLATE = "%s://%s";
    private static final Logger LOG = Logger.getLogger(Constant.class.getSimpleName());
    private static final int RANDOM_STRING_LENGTH = 20;
    // E-mail
    private static final String EMAIL_TEMPLATE = "%s@%s.com";
    private static final String DEV_EMAIL_TEMPLATE = "%s@c1.dev";
    private static final String DEV_PERF_EMAIL_TEMPLATE = "perf_%s@c1.dev";
    private static final String DEV_AUTO_EMAIL_TEMPLATE = "auto_%s@c1.dev";
    private static final String AUTO_AA_EMAIL_TEMPLATE = "AA_auto_%s@c1.dev";
    private static final int MAX_ASCII_LOWER_CASE = 122;
    private static final int MIN_ASCII_LOWER_CASE = 97;
    private static final String PROSPER_DOMAIN_EMAIL_TEMPLATE = "%s@prosper.com";
    // Prosper Offer Page Title
    public static final String PROSPER_BORROWER_OFFER_PAGE_TITLE = "Prosper | Borrower";
    public static final String TRUSTE_BORROWER_OFFER_PAGE_TITLE =
            "Prosper Marketplace, Inc.'s policies for online privacy and online safety are certified by TRUSTe";
    public static final String PROSPER_PRIVACY_POLICY = "Privacy Policy | Prosper";
    public static final String PROSPER_PRIVAY_POLICY_TITLE = "Prosper Privacy Policy & Federal Privacy Notice";
    public static final String PROSPER_WEBBANK_POLICY = "FACTS - WebBank-privacy-policy.pdf";

    // Spark Admin User Name
    public static final String sparkAdminUserName = "Admin Shiva1";

    // Settings Page
    public static final String SETTINGS_TITLE = "Settings";

    public static final  String CREDIT_BUREAU_TU = "TRANSUNION";
    public static final  String CREDIT_BUREAU_EXPERIAN = "EXPERIAN";

    // User Header Drop-down options
    public static final  String YOUR_LOANS = "Your Loans";
    public static final  String MESSAGES = "Messages";
    public static final  String SETTINGS = "Settings";
    public static final  String HISTORY = "History";
    public static final  String SIGN_OUT = "Sign Out";


    private Constant() {
    }

    public static String buildEmailAddress(final String localPart) {
        return String.format(DEV_EMAIL_TEMPLATE, localPart);
    }

    public static String getGloballyUniqueEmail() {
        return getGloballyUniqueEmail(false);
    }

    public static String getAAUniqueEmail() {
        return String.format(AUTO_AA_EMAIL_TEMPLATE,
                new SimpleDateFormat("ddMMMyyyyhhmmssz").format(Calendar.getInstance().getTime()));
    }

    public static String getUniqueEmail() {
        return String.format(DEV_AUTO_EMAIL_TEMPLATE,
                new SimpleDateFormat("ddMMMyyyyhhmmssz").format(Calendar.getInstance().getTime()));
    }

    public static String getGloballyUniqueEmail(final boolean isValidationExpected) {
        final String emailTemplate = isValidationExpected ? DEV_EMAIL_TEMPLATE : DEV_PERF_EMAIL_TEMPLATE;
        return String.format(emailTemplate, getGloballyUniqueString());
    }

    public static String getGloballyUniqueEmailDomain(final String localPart) {
        return String.format(EMAIL_TEMPLATE, getGloballyUniqueString(), localPart);
    }

    public static String getGloballyUniqueString() {
        // using Java UUID to generate unique String; this might
        // violate database String length constraint.
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * Creates a String of integer with length size of n.
     *
     * @param numberOfDigits
     * @return
     */
    public static String getRandomIntegerString(final int numberOfDigits) {
        final StringBuilder stringBuilder = new StringBuilder();
        final int maximumSingleDigitInteger = 9;
        for (int i = 0; i < numberOfDigits; i++) {
            stringBuilder.append(RANDOM.nextInt(maximumSingleDigitInteger));
        }
        return stringBuilder.toString();
    }

    /**
     * Creates a random String with length size of n.
     *
     * @param stringLength
     * @return
     */
    public static String getStringWithLength(final int stringLength) {
        final StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < stringLength; i++) {
            final int asciDecimalValue = RANDOM.nextInt(MAX_ASCII_LOWER_CASE - MIN_ASCII_LOWER_CASE + 1) + MIN_ASCII_LOWER_CASE;
            stringBuilder.append((char) asciDecimalValue);
        }
        return stringBuilder.toString();
    }

    public static String getRandomString() {
        return getStringWithLength(RANDOM_STRING_LENGTH);
    }

    public static List<String> generateSortedListOfStrings(final int numberOfString, final SortOrder sortOrder) {
        final List<String> list = Lists.newArrayList();
        for (int i = 0; i < numberOfString; i++) {
            list.add(getRandomString());
        }
        return generateSortedListOfObjects(list, sortOrder);
    }

    public static List<String> generateSortedListOfEmails(final int numberOfString, final SortOrder sortOrder) {
        final List<String> list = Lists.newArrayList();
        for (int i = 0; i < numberOfString; i++) {
            list.add(getGloballyUniqueEmail());
        }
        return generateSortedListOfObjects(list, sortOrder);
    }

    private static <T extends Comparable> List<T> generateSortedListOfObjects(final List<T> list, final SortOrder sortOrder) {
        if (sortOrder == SortOrder.ASC) {
            Collections.sort(list);
        } else if (sortOrder == SortOrder.DESC) {
            Collections.sort(list, Collections.reverseOrder());
        }
        return list;
    }

    public static String newUuid() {
        return UUID.randomUUID().toString().toUpperCase();
    }

    public static String getGloballyUniqueStringWithSpecialCharacters() {
        return String.format("%s-%s", getGloballyUniqueString(), "<>\"'\\&");
    }

    public static synchronized String buildTimeStampBasedSSNWithoutDash() {
        PollingUtilities.sleep(1);
        return String.valueOf(System.currentTimeMillis()).substring(4);
    }

    public static String buildTimeStampBasedSSNWithDash() {
        final String ssn = buildTimeStampBasedSSNWithoutDash();

        final StringBuilder ssnBuilder = new StringBuilder();
        ssnBuilder.append(ssn.substring(0, 2));
        ssnBuilder.append(StringConstant.HYPHEN);
        ssnBuilder.append(ssn.substring(3, 4));
        ssnBuilder.append(StringConstant.HYPHEN);
        ssnBuilder.append(ssn.substring(5));

        return ssnBuilder.toString();
    }

    public static String getGloballyUniqueProsperEmail() {
        return String.format(PROSPER_DOMAIN_EMAIL_TEMPLATE, getGloballyUniqueString());
    }
}
