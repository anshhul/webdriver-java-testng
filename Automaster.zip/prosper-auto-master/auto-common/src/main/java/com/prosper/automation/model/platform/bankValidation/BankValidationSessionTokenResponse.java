package com.prosper.automation.model.platform.bankValidation;


import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */
public class BankValidationSessionTokenResponse {

    @JsonProperty("token")
    private String token;
    @JsonProperty("reference")
    private String reference;

    /**
     * @return The token
     */
    @JsonProperty("token")
    public String getToken() {
        return token;
    }

    /**
     * @return The reference
     */
    @JsonProperty("reference")
    public String getReference() {
        return reference;
    }
}

