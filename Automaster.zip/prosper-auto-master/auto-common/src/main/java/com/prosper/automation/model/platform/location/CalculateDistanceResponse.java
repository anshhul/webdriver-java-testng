
package com.prosper.automation.model.platform.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Test class for get location by address API.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class CalculateDistanceResponse {
    
    @JsonProperty("coordinatesSet")
    private List<Coordinates> coordinatesSet;
    @JsonProperty("distance")
    private Double distance;
    
    
    @JsonIgnore
    public Double getDistance() {
        return distance;
    }
}
