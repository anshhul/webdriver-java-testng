
package com.prosper.automation.model.platform.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A location service response class representation.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class IPAddressLocationResponse {
    
    @JsonProperty("ipAddress")
    private String ipAddress;
    @JsonProperty("country")
    private String country;
    @JsonProperty("region")
    private String region;
    @JsonProperty("city")
    private String city;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("coordinates")
    private Coordinates coordinates;
    @JsonProperty("timezone")
    private String timezone;
    @JsonProperty("isp")
    private String isp;
    @JsonProperty("group")
    private String group;
    @JsonProperty("netspeed")
    private String netspeed;
    @JsonProperty("domain")
    private String domain;
    @JsonProperty("distance")
    private String distance;
    
    
    @JsonIgnore
    public Coordinates getCoordinates() {
        return coordinates;
    }
}
