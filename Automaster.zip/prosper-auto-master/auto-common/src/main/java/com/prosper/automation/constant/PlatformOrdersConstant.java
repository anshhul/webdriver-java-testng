package com.prosper.automation.constant;

public final class PlatformOrdersConstant {

    public static final String ORDERS_USER = "20150528test1@c1.dev";
    public static final Integer[] OFFSET = {0, 1, 5, 100 };
    public static final Integer[] LIMIT = {1, 2, 5, 100, 500, -1 };

    private PlatformOrdersConstant() {
        // intended private
    }
}
