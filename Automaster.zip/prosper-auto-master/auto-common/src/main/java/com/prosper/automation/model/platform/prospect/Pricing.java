
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"pricing_id", "created_date", "modified_date", "pricing_bin"})
public final class Pricing {
    
    @JsonProperty("pricing_id")
    private Long pricingId;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("modified_date")
    private String modifiedDate;
    @JsonProperty("pricing_bin")
    private String pricingBin;

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Pricing pricing = (Pricing) o;
        return Objects.equal(pricingId, pricing.pricingId) &&
                Objects.equal(createdDate, pricing.createdDate) &&
                Objects.equal(modifiedDate, pricing.modifiedDate) &&
                Objects.equal(pricingBin, pricing.pricingBin);
    }

    @Override public int hashCode() {
        return Objects.hashCode(pricingId, createdDate, modifiedDate, pricingBin);
    }
}
