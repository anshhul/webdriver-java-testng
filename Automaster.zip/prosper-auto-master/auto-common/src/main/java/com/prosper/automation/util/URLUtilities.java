package com.prosper.automation.util;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.prosper.automation.exception.AutomationException;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

/**
 * @author pbudiono
 */
public final class URLUtilities {

    private static final String UNABLE_TO_BUILD_URL_LOG = "Unable to build URL from URL String.";
    private static final String URL_WITHOUT_SCHEME_TEMPLATE = "%s%s?%s";


    private URLUtilities() {
    }

    public static Map<String, String> getQueryParameters(final URL url) {
        Preconditions.checkNotNull(url, "url can not be null");

        final ImmutableMap.Builder<String, String> queryParametersBuilder = ImmutableMap.builder();
        for (final String queryParameter : url.getQuery().split("&")) {
            final String[] queryParameterKeyValue = queryParameter.split("=");
            queryParametersBuilder.put(queryParameterKeyValue[0], queryParameterKeyValue[1]);
        }
        return queryParametersBuilder.build();
    }

    public static Map<String, String> getQueryParameters(final String stringUrl) throws AutomationException {
        try {
            return getQueryParameters(new URL(stringUrl));
        } catch (MalformedURLException ex) {
            throw new AutomationException(UNABLE_TO_BUILD_URL_LOG, ex);
        }
    }

    public static String getScheme(final String stringUrl) throws AutomationException {
        return buildURLFromString(stringUrl).getProtocol();
    }

    public static String getStringURLWithoutScheme(final String stringUrl) throws AutomationException {
        final URL url = buildURLFromString(stringUrl);
        return String.format(URL_WITHOUT_SCHEME_TEMPLATE, url.getHost(), url.getPath(), url.getQuery());
    }

    private static URL buildURLFromString(final String stringURL) throws AutomationException {
        try {
            return new URL(stringURL);
        } catch (MalformedURLException ex) {
            throw new AutomationException(UNABLE_TO_BUILD_URL_LOG, ex);
        }
    }

    public static String getHost(String stringURL) throws AutomationException {
        try {
            return new URL(stringURL).getHost();
        } catch (MalformedURLException ex) {
            throw new AutomationException(UNABLE_TO_BUILD_URL_LOG, ex);
        }
    }

    public static String getURLPath(String stringUrl) throws AutomationException {
        try {
            return new URL(stringUrl).getPath();
        } catch (MalformedURLException ex) {
            throw new AutomationException(UNABLE_TO_BUILD_URL_LOG, ex);
        }
    }
}
