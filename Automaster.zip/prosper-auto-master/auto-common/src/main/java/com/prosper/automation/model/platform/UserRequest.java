
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"request_ip", "anonymousToken", "cookie", "service_name", "session_id", "offer_code", "token_value",
        "token_type", "client_id", "grant_type", "auth_resource", "client_ip", "token_expiration", "user", "client_name"})
public final class UserRequest {
    
    @JsonProperty("request_ip")
    private String requestIp;
    @JsonProperty("anonymousToken")
    private Boolean anonymousToken;
    @JsonProperty("cookie")
    private String cookie;
    @JsonProperty("service_name")
    private String serviceName;
    @JsonProperty("session_id")
    private String sessionId;
    @JsonProperty("offer_code")
    private String offerCode;
    @JsonProperty("token_value")
    private String tokenValue;
    @JsonProperty("token_type")
    private String tokenType;
    @JsonProperty("client_id")
    private String clientId;
    @JsonProperty("grant_type")
    private String grantType;
    @JsonProperty("auth_resource")
    private String authResource;
    @JsonProperty("client_ip")
    private String clientIp;
    @JsonProperty("token_expiration")
    private Integer tokenExpiration;
    @JsonProperty("user")
    private User user;
    @JsonProperty("client_name")
    private String clientName;
    
    
    public UserRequest() {
    }
    
    private UserRequest(final Builder builder) {
        requestIp = builder.requestIp;
        anonymousToken = builder.anonymousToken;
        cookie = builder.cookie;
        serviceName = builder.serviceName;
        sessionId = builder.sessionId;
        offerCode = builder.offerCode;
        tokenValue = builder.tokenValue;
        tokenType = builder.tokenType;
        clientId = builder.clientId;
        grantType = builder.grantType;
        authResource = builder.authResource;
        clientIp = builder.clientIp;
        tokenExpiration = builder.tokenExpiration;
        user = builder.user;
        clientName = builder.clientName;
    }
    
    @JsonIgnore
    public User getUser() {
        return user;
    }
    
    @JsonIgnore
    public Long getUserId() {
        return user.getUserId();
    }
    
    @JsonIgnore
    public PersonalInfo getUserPersonalInfo() {
        return user.getPersonalInfo();
    }
    
    public void setUserPersonalInfo(final PersonalInfo userPersonalInfo) {
        user.setPersonalInfo(userPersonalInfo);
    }
    
    @JsonIgnore
    public AddressInfo getUserAddressInfo() {
        return user.getAddressInfo();
    }
    
    public void setUserAddressInfo(final AddressInfo userAddressInfo) {
        user.setAddressInfo(userAddressInfo);
    }
    
    @JsonIgnore
    public LendingAccreditation getLendingAccreditation() {
        return user.getLendingAccreditation();
    }
    
    public void setLendingAccreditation(final LendingAccreditation lendingAccreditation) {
        user.setLendingAccreditation(lendingAccreditation);
    }
    
    @JsonIgnore
    public ContactInfo getUserContactInfo() {
        return user.getContactInfo();
    }
    
    public void setUserContactInfo(final ContactInfo userContactInfo) {
        user.setContactInfo(userContactInfo);
    }
    
    public Boolean isAnonymousToken() {
        return anonymousToken;
    }
    
    @JsonIgnore
    public String getUserSsn() {
        return user.getUserSsn();
    }
    
    public void setUserSsn(final String userSsn) {
        user.setSsn(userSsn);
    }
    
    @JsonIgnore
    public EmploymentInfo getUserEmploymentInfo() {
        return user.getEmploymentInfo();
    }

    @JsonIgnore
    public String getUserEmail() {
        return user.geUserEmail();
    }

    public static final class Builder {
        
        private String requestIp;
        private Boolean anonymousToken;
        private String cookie;
        private String serviceName;
        private String sessionId;
        private String offerCode;
        private String tokenValue;
        private String tokenType;
        private String clientId;
        private String grantType;
        private String authResource;
        private String clientIp;
        private Integer tokenExpiration;
        private User user;
        private String clientName;
        
        
        public Builder() {
        }
        
        public Builder withRequestIp(final String requestIp) {
            this.requestIp = requestIp;
            return this;
        }
        
        public Builder withAnonymousToken(final Boolean anonymousToken) {
            this.anonymousToken = anonymousToken;
            return this;
        }
        
        public Builder withCookie(final String cookie) {
            this.cookie = cookie;
            return this;
        }
        
        public Builder withServiceName(final String serviceName) {
            this.serviceName = serviceName;
            return this;
        }
        
        public Builder withSessionId(final String sessionId) {
            this.sessionId = sessionId;
            return this;
        }
        
        public Builder withOfferCode(final String offerCode) {
            this.offerCode = offerCode;
            return this;
        }
        
        public Builder withTokenValue(final String tokenValue) {
            this.tokenValue = tokenValue;
            return this;
        }
        
        public Builder withTokenType(final String tokenType) {
            this.tokenType = tokenType;
            return this;
        }
        
        public Builder withClientId(final String clientId) {
            this.clientId = clientId;
            return this;
        }
        
        public Builder withGrantType(final String grantType) {
            this.grantType = grantType;
            return this;
        }
        
        public Builder withAuthResource(final String authResource) {
            this.authResource = authResource;
            return this;
        }
        
        public Builder withClientIp(final String clientIp) {
            this.clientIp = clientIp;
            return this;
        }
        
        public Builder withTokenExpiration(final Integer tokenExpiration) {
            this.tokenExpiration = tokenExpiration;
            return this;
        }
        
        public Builder withUser(final User user) {
            this.user = user;
            return this;
        }
        
        public Builder withClientName(final String clientName) {
            this.clientName = clientName;
            return this;
        }
        
        public UserRequest build() {
            return new UserRequest(this);
        }
    }
}
