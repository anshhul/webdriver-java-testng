
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"result", "result_count", "total_count"})
public final class EmailInfoResponse {
    
    @JsonProperty("result")
    private List<EmailInfo> result;
    @JsonProperty("result_count")
    private Integer resultCount;
    @JsonProperty("total_count")
    private Integer totalCount;
    
    
    public List<EmailInfo> getResult() {
        return result;
    }
    
    @JsonIgnore
    public Integer getResultCount() {
        return resultCount;
    }
    
    public Integer getTotalCount() {
        return resultCount;
    }
    
}
