package com.prosper.automation.model.platform.loan;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Sonali Phatak
 *
 */
public class ScheduledPayment {

	@JsonProperty("account_number")
	private Integer accountNumber;

	@JsonProperty("account_id")
	private Integer accountId;

	@JsonProperty("financial_institution_name")
	private String financialInstitutionName;

	@JsonProperty("institution_type")
	private String institutionType;

	@JsonProperty("bank_account_number")
	private String bankAccountNumber;

	@JsonProperty("bank_account_type")
	private String bankAccountType;

	@JsonProperty("status")
	private String Status;

	@JsonProperty("payment_servicing_id")
	private String paymentServicingId;

	@JsonProperty("pending")
	private Boolean Pending;

	@JsonProperty("security_code")
	private BigDecimal securityCode;

	@JsonProperty("payment_draft_amount")
	private BigDecimal paymentDraftAmount;

	@JsonProperty("payment_draft_date")
	private String paymentDraftDate;

	@JsonProperty("effective_date")
	private Date effectiveDate;

	@JsonProperty("usage_type")
	private String usageType;

	@JsonProperty("deactivated")
	private Boolean deactivated;

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getFinancialInstitutionName() {
		return financialInstitutionName;
	}

	public void setFinancialInstitutionName(String financialInstitutionName) {
		this.financialInstitutionName = financialInstitutionName;
	}

	public String getInstitutionType() {
		return institutionType;
	}

	public void setInstitutionType(String institutionType) {
		this.institutionType = institutionType;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getPaymentServicingId() {
		return paymentServicingId;
	}

	public void setPaymentServicingId(String paymentServicingId) {
		this.paymentServicingId = paymentServicingId;
	}

	public Boolean getPending() {
		return Pending;
	}

	public void setPending(Boolean pending) {
		Pending = pending;
	}

	public BigDecimal getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(BigDecimal securityCode) {
		this.securityCode = securityCode;
	}

	public BigDecimal getPaymentDraftAmount() {
		return paymentDraftAmount;
	}

	public void setPaymentDraftAmount(BigDecimal paymentDraftAmount) {
		this.paymentDraftAmount = paymentDraftAmount;
	}

	public String getPaymentDraftDate() {
		return paymentDraftDate;
	}

	public void setPaymentDraftDate(String paymentDraftDate) {
		this.paymentDraftDate = paymentDraftDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public Boolean getDeactivated() {
		return deactivated;
	}

	public void setDeactivated(Boolean deactivated) {
		this.deactivated = deactivated;
	}

	public static class ScheduledPaymentBuilder {
		private Integer accountNumber;
		private Integer accountId;
		private String financialInstitutionName;
		private String institutionType;
		private String bankAccountNumber;
		private String bankAccountType;
		private String status;
		private String paymentServicingId;
		private Boolean pending;
		private BigDecimal securityCode;
		private BigDecimal paymentDraftAmount;
		private String paymentDraftDate;
		private Date effectiveDate;
		private String usageType;
		private Boolean deactivated;

		public ScheduledPayment builder() {
			ScheduledPayment result = new ScheduledPayment();
			result.setAccountNumber(accountNumber);
			result.setAccountId(accountId);
			result.setFinancialInstitutionName(financialInstitutionName);
			result.setInstitutionType(institutionType);
			result.setBankAccountNumber(bankAccountNumber);
			result.setBankAccountType(bankAccountType);
			result.setStatus(status);
			result.setPaymentServicingId(paymentServicingId);
			result.setPending(pending);
			result.setSecurityCode(securityCode);
			result.setPaymentDraftAmount(paymentDraftAmount);
			result.setPaymentDraftDate(paymentDraftDate);
			result.setEffectiveDate(effectiveDate);
			result.setUsageType(usageType);
			result.setDeactivated(deactivated);
			return result;
		}

		public ScheduledPaymentBuilder accountNumber(Integer accountNumber) {
			this.accountNumber = accountNumber;
			return this;
		}

		public ScheduledPaymentBuilder accountId(Integer accountId) {
			this.accountId = accountId;
			return this;
		}

		public ScheduledPaymentBuilder financialInstitutionName(
				String financialInstitutionName) {
			this.financialInstitutionName = financialInstitutionName;
			return this;
		}

		public ScheduledPaymentBuilder institutionType(String institutionType) {
			this.institutionType = institutionType;
			return this;
		}

		public ScheduledPaymentBuilder bankAccountNumber(
				String bankAccountNumber) {
			this.bankAccountNumber = bankAccountNumber;
			return this;
		}

		public ScheduledPaymentBuilder bankAccountType(String bankAccountType) {
			this.bankAccountType = bankAccountType;
			return this;
		}

		public ScheduledPaymentBuilder status(String status) {
			status = status;
			return this;
		}

		public ScheduledPaymentBuilder paymentServicingId(
				String paymentServicingId) {
			this.paymentServicingId = paymentServicingId;
			return this;
		}

		public ScheduledPaymentBuilder pending(Boolean pending) {
			pending = pending;
			return this;
		}

		public ScheduledPaymentBuilder securityCode(BigDecimal securityCode) {
			this.securityCode = securityCode;
			return this;
		}

		public ScheduledPaymentBuilder paymentDraftAmount(
				BigDecimal paymentDraftAmount) {
			this.paymentDraftAmount = paymentDraftAmount;
			return this;
		}

		public ScheduledPaymentBuilder paymentDraftDate(String paymentDraftDate) {
			this.paymentDraftDate = paymentDraftDate;
			return this;
		}

		public ScheduledPaymentBuilder effectiveDate(Date effectiveDate) {
			this.effectiveDate = effectiveDate;
			return this;
		}

		public ScheduledPaymentBuilder usageType(String usageType) {
			this.usageType = usageType;
			return this;
		}

		public ScheduledPaymentBuilder deactivated(Boolean deactivated) {
			this.deactivated = deactivated;
			return this;
		}
	}
}
