
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prosper.automation.model.platform.publishing.PublishingJobsReq.PublishingJobsReqBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"ticket_id", "documents"})
public final class TicketMappingRequest {

    @JsonProperty("ticket_id")
    private int ticketId;
   
    @JsonProperty("documents")
    private List<Documents> documents;


    public TicketMappingRequest() {
    }

    private TicketMappingRequest(final Builder builder) {
    	ticketId = builder.ticketId;
    	documents = builder.documents;
    }

    @JsonIgnore
    public int getTicketId() {
        return ticketId;
    }

    @JsonIgnore
    public List<Documents> getDocuments() {
        return documents;
    }
    
    
    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {

        private int  ticketId;
        private List<Documents> documents;


        public Builder() {
        }

        public Builder withTicketId(final int ticketId) {
            this.ticketId = ticketId;
            return this;
        }

        public Builder withDocuments(final List<Documents> documents) {
            this.documents = documents;
            return this;
        }

        public TicketMappingRequest build() {
            return new TicketMappingRequest(this);
        }
    }

}
