
package com.prosper.automation.model.platform.origination;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */
public class PreOriginationValidationResponse {

    @JsonProperty("success")
    private boolean success;
    @JsonProperty("listing_id")
    private long listingId;
    @JsonProperty("validation_errors")
    private String validationError;


    public PreOriginationValidationResponse(Builder builder) {
        success = builder.success;
        listingId = builder.listingId;
        validationError = builder.validationError;
    }

    public boolean isSuccess() {
        return success;
    }

    public long getListingId() {
        return listingId;
    }

    public void setListingId(long listingId) {
        this.listingId = listingId;
    }

    public String getValidationError() {
        return validationError;
    }

    public void setValidationError(String validationError) {
        this.validationError = validationError;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }


    public static final class Builder {

        private boolean success;
        private long listingId;
        private String validationError;


        public Builder() {

        }

        public Builder withSuccess(final boolean success) {
            this.success = success;
            return this;

        }

        public Builder withlistingId(final long listingId) {
            this.listingId = listingId;
            return this;
        }

        public Builder withValidationError(final String validationError) {
            this.validationError = validationError;
            return this;
        }

        public PreOriginationValidationResponse build() {
            return new PreOriginationValidationResponse(this);

        }
    }
}
