
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;
import com.prosper.automation.constant.Constant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"campaign_id", "campaign_source_id", "campaign_channel_id", "rank", "name", "description", "send_date",
        "start_date", "end_date", "landing_page", "created_date", "modified_date", "legacy_id", "legacy_channel", "duration",
        "ref_ac"})
public final class Campaign {

    @JsonProperty("campaign_id")
    public String campaignId;
    @JsonProperty("campaign_source_id")
    public String campaignSourceId;
    @JsonProperty("campaign_channel_id")
    public String campaignChannelId;
    @JsonProperty("rank")
    public Integer rank;
    @JsonProperty("name")
    public String name;
    @JsonProperty("description")
    public String description;
    @JsonProperty("send_date")
    public String sendDate;
    @JsonProperty("start_date")
    public String startDate;
    @JsonProperty("end_date")
    public String endDate;
    @JsonProperty("landing_page")
    public String landingPage;
    @JsonProperty("created_date")
    public String createdDate;
    @JsonProperty("modified_date")
    public String modifiedDate;
    @JsonProperty("legacy_id")
    public Integer legacyId;
    @JsonProperty("legacy_channel")
    public String legacyChannel;
    @JsonProperty("duration")
    public Integer duration;
    @JsonProperty("ref_ac")
    public String refAc;


    public Campaign() {
    }

    private Campaign(Builder builder) {
        campaignId = builder.campaignId;
        campaignSourceId = builder.campaignSourceId;
        campaignChannelId = builder.campaignChannelId;
        rank = builder.rank;
        name = builder.name;
        description = builder.description;
        sendDate = builder.sendDate;
        startDate = builder.startDate;
        endDate = builder.endDate;
        landingPage = builder.landingPage;
        createdDate = builder.createdDate;
        modifiedDate = builder.modifiedDate;
        legacyId = builder.legacyId;
        legacyChannel = builder.legacyChannel;
        duration = builder.duration;
        refAc = builder.refAc;
    }

    public final static String REF_AC_PREFIX = "eco_ref_ac";
    public static Campaign createCampaign(String campaignId, String campaignSourceId, String campaignChannelId, int rank,
                                          int legacyId, String legacyChannel, int duration) {
        final String campaignName = String.format("eco_campaign_%s", Constant.getGloballyUniqueString());
        return createCampaign(campaignId, campaignSourceId, campaignChannelId, rank, legacyId, legacyChannel, duration,
                String.format(REF_AC_PREFIX + "_%s", Constant.getGloballyUniqueString()), campaignName);
    }

    public static Campaign createCampaign(String campaignId, String campaignSourceId, String campaignChannelId, int rank,
                                          int legacyId, String legacyChannel, int duration, String ref_ac, String campaignName) {
        return new Builder().withRefAC(ref_ac)
                .withCampaignId(campaignId).withCampaignSourceId(campaignSourceId).withCampaignChannelId(campaignChannelId)
                .withRank(rank).withLegacyId(legacyId).withLegacyChannel(legacyChannel).withName(campaignName)
                .withDescription(campaignName).withLandingPage(campaignName).withDuration(duration).build();
    }

    @JsonIgnore
    public String getCampaignId() {
        return campaignId;
    }

    @JsonIgnore
    public String getCampaignSourceId() {
        return campaignSourceId;
    }

    @JsonIgnore
    public String getCampaignChannelId() {
        return campaignChannelId;
    }

    @JsonIgnore
    public Integer getRank() {
        return rank;
    }

    @JsonIgnore
    public String getName() {
        return name;
    }

    @JsonIgnore
    public String getDescription() {
        return description;
    }

    @JsonIgnore
    public String getSendDate() {
        return sendDate;
    }

    @JsonIgnore
    public String getStartDate() {
        return startDate;
    }

    @JsonIgnore
    public String getEndDate() {
        return endDate;
    }

    @JsonIgnore
    public String getLandingPage() {
        return landingPage;
    }

    @JsonIgnore
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonIgnore
    public String getModifiedDate() {
        return modifiedDate;
    }

    @JsonIgnore
    public Integer getLegacyId() {
        return legacyId;
    }

    @JsonIgnore
    public String getLegacyChannel() {
        return legacyChannel;
    }

    @JsonIgnore
    public Integer getDuration() {
        return duration;
    }

    @JsonIgnore
    public String getRefAc() {
        return refAc;
    }

	public void setLegacyChannel(String legacyChannel) {
		this.legacyChannel = legacyChannel;
	}

	public void setLegacyId(Integer legacyId) {
		this.legacyId = legacyId;
	}

	public static final class Builder {

        private String campaignId;
        private String campaignSourceId;
        private String campaignChannelId;
        private Integer rank;
        private String name;
        private String description;
        private String sendDate;
        private String startDate;
        private String endDate;
        private String landingPage;
        private String createdDate;
        private String modifiedDate;
        private Integer legacyId;
        private String legacyChannel;
        private Integer duration;
        private String refAc;


        public Builder() {
        }

        public Builder withCampaignId(String val) {
            campaignId = val;
            return this;
        }

        public Builder withCampaignSourceId(String val) {
            campaignSourceId = val;
            return this;
        }

        public Builder withCampaignChannelId(String val) {
            campaignChannelId = val;
            return this;
        }

        public Builder withRank(Integer val) {
            rank = val;
            return this;
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withDescription(String val) {
            description = val;
            return this;
        }

        public Builder withSendDate(String val) {
            sendDate = val;
            return this;
        }

        public Builder withStartDate(String val) {
            startDate = val;
            return this;
        }

        public Builder withEndDate(String val) {
            endDate = val;
            return this;
        }

        public Builder withLandingPage(String val) {
            landingPage = val;
            return this;
        }

        public Builder withCreatedDate(String val) {
            createdDate = val;
            return this;
        }

        public Builder withModifiedDate(String val) {
            modifiedDate = val;
            return this;
        }

        public Builder withLegacyId(Integer val) {
            legacyId = val;
            return this;
        }

        public Builder withLegacyChannel(String val) {
            legacyChannel = val;
            return this;
        }

        public Builder withDuration(Integer val) {
            duration = val;
            return this;
        }

        public Builder withRefAC(String val) {
            refAc = val;
            return this;
        }

        public Campaign build() {
            return new Campaign(this);
        }
    }
}
