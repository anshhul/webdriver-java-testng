
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author grajasekar
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Bureau {

    @JsonProperty("GiactPI")
    private GiactPI giactPi;
    @JsonProperty("LNFlexID")
    private LNFlexID lnFlexId;
    @JsonProperty("EquTWN")
    private EquTWN equTwn;
    @JsonProperty("ID_Analytics")
    private IDAnalytics idAnalytics;


    @JsonIgnore
    public String getEquTWNHitFlag() {
        return equTwn.getEquTWNHitFlag();
    }

    @JsonIgnore
    public String getEquTWNPullFlag() {
        return equTwn.getEquTWNPullFlag();
    }

    @JsonIgnore
    public String getGiactPIHitFlag() {
        return giactPi.getGiactPIHitFlag();
    }

    @JsonIgnore
    public String getGiactPIPullFlag() {
        return giactPi.getGiactPIPullFlag();
    }

    @JsonIgnore
    public String getIDAnalyticsHitFlag() {
        return idAnalytics.getIDAnalyticsHitFlag();
    }

    @JsonIgnore
    public String getIDAnalyticsPullFlag() {
        return idAnalytics.getIDAnalyticsPullFlag();
    }

    @JsonIgnore
    public String getLNFlexIDHitFlag() {
        return lnFlexId.getLNFlexIDHitFlag();
    }

    @JsonIgnore
    public String getLNFlexIDPullFlag() {
        return lnFlexId.getLNFlexIDPullFlag();
    }
}
