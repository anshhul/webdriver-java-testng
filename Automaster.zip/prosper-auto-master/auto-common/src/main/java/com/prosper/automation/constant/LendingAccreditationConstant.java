
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.LendingAccreditation;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class LendingAccreditationConstant {

    public static final LendingAccreditation AGREED_LANDING_ACCREDITATION = new LendingAccreditation.Builder()
            .withConsentToElectronicDisclosures(true).withTermsOfUse(true).withPrivacyPoliciesAgreement(true)
            .withIsTaxWithholdingApproved(true).withCreditProfileAuth(true).withDataTermsOfUse(true)
            .withLenderRegistrationAgreementApproved(true).withProspectusReviewed(true).build();

    // Lending accreditation requirement Type Id is hard coded to 4 for valid investors
    public static final LendingAccreditation AGREED_LANDING_ACCREDITATION_INVESTOR = new LendingAccreditation.Builder()
            .withConsentToElectronicDisclosures(true).withTermsOfUse(true).withPrivacyPoliciesAgreement(true)
            .withIsTaxWithholdingApproved(true).withCreditProfileAuth(true).withDataTermsOfUse(true).withAccreditedState("CA")
            .withLendingAccreditationRequirementTypeID(4)
            .withLenderRegistrationAgreementApproved(true).withProspectusReviewed(true).build();


    private LendingAccreditationConstant() {
    }
}
