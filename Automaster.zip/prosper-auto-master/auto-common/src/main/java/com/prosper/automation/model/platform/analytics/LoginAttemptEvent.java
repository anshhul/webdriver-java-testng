
package com.prosper.automation.model.platform.analytics;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 7/18/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class LoginAttemptEvent {

    @JsonProperty("session_info_id")
    private String sessionInfoId;
    @JsonProperty("client_ip")
    private String clientIp;
    @JsonProperty("email")
    private String email;
    @JsonProperty("session_info_tracking_id")
    private String sessionInfoTrackingId;
    @JsonProperty("password_match")
    private Boolean passwordMatch;


    private LoginAttemptEvent(Builder builder) {
        sessionInfoId = builder.sessionInfoId;
        clientIp = builder.clientIp;
        email = builder.email;
        sessionInfoTrackingId = builder.sessionInfoTrackingId;
        passwordMatch = builder.passwordMatch;
    }


    public static final class Builder {

        private String sessionInfoId;
        private String clientIp;
        private String email;
        private String sessionInfoTrackingId;
        private Boolean passwordMatch;


        public Builder() {
        }

        public Builder withSessionInfoId(String val) {
            sessionInfoId = val;
            return this;
        }

        public Builder withClientIp(String val) {
            clientIp = val;
            return this;
        }

        public Builder withEmail(String val) {
            email = val;
            return this;
        }

        public Builder withSessionInfoTrackingId(String val) {
            sessionInfoTrackingId = val;
            return this;
        }

        public Builder withPasswordMatch(Boolean val) {
            passwordMatch = val;
            return this;
        }

        public LoginAttemptEvent build() {
            return new LoginAttemptEvent(this);
        }
    }
}
