package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.response.IndividualErrorResponse;
import com.prosper.automation.model.platform.marketplace.response.ValidationErrorResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rsubramanyam on 3/1/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartnerRequestGetResponse {
    @JsonProperty("partner_request_id")
    private String partner_request_id;
    @JsonProperty("referral_code")
    private String referral_code;
    @JsonProperty("identification") private IdentificationInfo identification;

    @JsonProperty("loan_info") private LoanInfo loanInfo;

    @JsonProperty("personal_info") private PersonalInfo personalInfo;

    @JsonProperty("address_info") private AddressInfo addressInfo;

    @JsonProperty("contact_info") private ContactInfo contactInfo;

    @JsonProperty("employment_info") private EmploymentInfo employmentInfo;

    @JsonProperty("bank_account_info") private BankAccountInfo bankAccountInfo;

    @JsonProperty("errors") private List<IndividualErrorResponse> errors;

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getPartner_request_id() {
        return partner_request_id;
    }

    public void setPartner_request_id(String partner_request_id) {
        this.partner_request_id = partner_request_id;
    }

    public String getReferral_code() {
        return referral_code;
    }

    public void setReferral_code(String referral_code) {
        this.referral_code = referral_code;
    }

    public IdentificationInfo getIdentification() {
        return identification;
    }

    public void setIdentification(IdentificationInfo identification) {
        this.identification = identification;
    }

    public LoanInfo getLoanInfo() {
        return loanInfo;
    }

    public void setLoanInfo(LoanInfo loanInfo) {
        this.loanInfo = loanInfo;
    }

    public PersonalInfo getPersonalInfo() {
        return personalInfo;
    }

    public void setPersonalInfo(PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    public AddressInfo getAddressInfo() {
        return addressInfo;
    }

    public void setAddressInfo(AddressInfo addressInfo) {
        this.addressInfo = addressInfo;
    }

    public EmploymentInfo getEmploymentInfo() {
        return employmentInfo;
    }

    public void setEmploymentInfo(EmploymentInfo employmentInfo) {
        this.employmentInfo = employmentInfo;
    }

    public BankAccountInfo getBankAccountInfo() {
        return bankAccountInfo;
    }

    public void setBankAccountInfo(BankAccountInfo bankAccountInfo) {
        this.bankAccountInfo = bankAccountInfo;
    }

    public List<IndividualErrorResponse> getErrors() {
        return errors;
    }

    public void setErrors(List<IndividualErrorResponse> errors) {
        this.errors = new ArrayList<IndividualErrorResponse>();
        this.errors.addAll(errors);
    }

}
