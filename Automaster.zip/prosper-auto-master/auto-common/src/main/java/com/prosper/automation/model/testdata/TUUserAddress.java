package com.prosper.automation.model.testdata;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class TUUserAddress {

    private String houseNumber;
    private String direction;
    private String streetName;
    private String postDir;
    private String streetType;
    private String apartmentNumber;
    private String city;
    private String state;
    private String zipCode;

    private TUUserAddress(Builder builder) {
        setHouseNumber(builder.houseNumber);
        setDirection(builder.direction);
        setStreetName(builder.streetName);
        setPostDir(builder.postDir);
        setStreetType(builder.streetType);
        setApartmentNumber(builder.apartmentNumber);
        setCity(builder.city);
        setState(builder.state);
        setZipCode(builder.zipCode);
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getPostDir() {
        return postDir;
    }

    public void setPostDir(String postDir) {
        this.postDir = postDir;
    }

    public String getStreetType() {
        return streetType;
    }

    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public static final class Builder {

        private String houseNumber;
        private String direction;
        private String streetName;
        private String postDir;
        private String streetType;
        private String apartmentNumber;
        private String city;
        private String state;
        private String zipCode;

        public Builder() {
        }

        public Builder withHouseNumber(String val) {
            houseNumber = val;
            return this;
        }

        public Builder withDirection(String val) {
            direction = val;
            return this;
        }

        public Builder withStreetName(String val) {
            streetName = val;
            return this;
        }

        public Builder withPostDir(String val) {
            postDir = val;
            return this;
        }

        public Builder withStreetType(String val) {
            streetType = val;
            return this;
        }

        public Builder withApartmentNumber(String val) {
            apartmentNumber = val;
            return this;
        }

        public Builder withCity(String val) {
            city = val;
            return this;
        }

        public Builder withState(String val) {
            state = val;
            return this;
        }

        public Builder withZipCode(String val) {
            zipCode = val;
            return this;
        }

        public TUUserAddress build() {
            return new TUUserAddress(this);
        }
    }
}
