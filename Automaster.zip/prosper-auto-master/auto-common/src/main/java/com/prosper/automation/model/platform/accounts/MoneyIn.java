
package com.prosper.automation.model.platform.accounts;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 *
 * @Description: Account Ledger
 * @author agarg
 */

public final class MoneyIn {

    @JsonProperty("money_transferred")
    private BigDecimal moneyTransferred;

    @JsonProperty("total_deposits")
    private BigDecimal totalDeposits;

    @JsonProperty("payments_received")
    private BigDecimal paymentsReceived;

    @JsonProperty("notes_sold")
    private BigDecimal notesSold;

    @JsonProperty("debt_sale")
    private BigDecimal debtSale;

    @JsonProperty("adjustments_credits")
    private BigDecimal adjustmentsCredits;


    public BigDecimal getMoneyTransferred() {
        return moneyTransferred;
    }

    public void setMoneyTransferred(BigDecimal moneyTransferred) {
        this.moneyTransferred = moneyTransferred;
    }

    public BigDecimal getTotalDeposits() {
        return totalDeposits;
    }

    public void setTotalDeposits(BigDecimal totalDeposits) {
        this.totalDeposits = totalDeposits;
    }

    public BigDecimal getPaymentsReceived() {
        return paymentsReceived;
    }

    public void setPaymentsReceived(BigDecimal paymentsReceived) {
        this.paymentsReceived = paymentsReceived;
    }

    public BigDecimal getNotesSold() {
        return notesSold;
    }

    public void setNotesSold(BigDecimal notesSold) {
        this.notesSold = notesSold;
    }

    public BigDecimal getDebtSale() {
        return debtSale;
    }

    public void setDebtSale(BigDecimal debtSale) {
        this.debtSale = debtSale;
    }

    public BigDecimal getAdjustmentsCredits() {
        return adjustmentsCredits;
    }

    public void setAdjustmentsCredits(BigDecimal adjustmentsCredits) {
        this.adjustmentsCredits = adjustmentsCredits;
    }




}
