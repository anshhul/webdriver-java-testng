
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class BureauRequest {

    @JsonProperty("user_info")
    private UserInfo userInfo;
    @JsonProperty("transunion_user_credit")
    private TransunionUserCredit tranunionUserCredit;

    @Override
    public String toString() {
        return "BureauRequest{" +
                "userInfo=" + userInfo +
                ", tranunionUserCredit=" + tranunionUserCredit +
                '}';
    }

    public BureauRequest() {
    }

    private BureauRequest(final Builder builder) {
        userInfo = builder.userInfo;
        tranunionUserCredit = builder.tranunionUserCredit;
    }

    public static final class Builder {

        private UserInfo userInfo;

        private TransunionUserCredit tranunionUserCredit;


        public Builder() {
        }

        public Builder withUserInfo(final UserInfo userInfo) {
            this.userInfo = userInfo;
            return this;
        }

        public Builder withTransunionUserCredit(final TransunionUserCredit tranunionUserCredit) {
            this.tranunionUserCredit = tranunionUserCredit;
            return this;
        }

        public BureauRequest build() {
            return new BureauRequest(this);
        }
    }
}
