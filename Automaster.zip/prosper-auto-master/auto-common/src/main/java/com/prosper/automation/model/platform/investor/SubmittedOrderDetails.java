package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class SubmittedOrderDetails {

    private double orderAmount;
    private int loanCount;
    private float estimatedReturn;

    @JsonProperty("estimated_return")
    public float getEstimatedReturn() {
        return estimatedReturn;
    }

    @JsonProperty("loan_count")
    public int getLoanCount() {
        return loanCount;
    }

    @JsonProperty("order_amount")
    public double getOrderAmount() {
        return orderAmount;
    }

    public void setEstimatedReturn(final float estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public void setLoanCount(final int loanCount) {
        this.loanCount = loanCount;
    }

    public void setOrderAmount(final double orderAmount) {
        this.orderAmount = orderAmount;
    }

}
