
package com.prosper.automation.model.platform.merchant;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.enumeration.platform.Industry;
import com.prosper.automation.enumeration.platform.PromoOption;
import com.prosper.automation.enumeration.platform.ProviderStatus;
import com.prosper.automation.enumeration.platform.UserRole;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.PhoneNumber;

/**
 * 
 * @author Sonali Phatak
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Merchant {

    @JsonProperty("role")
    private UserRole role;
    @JsonProperty("roles")
    private String roles;
    @JsonProperty("merchant_offered_product_specs")
    private MerchantOfferedProductSpecs merchant_offered_product_specs;
    @JsonProperty("industry")
    private Industry industry;
    @JsonProperty("billing_address")
    private AddressInfo billingAddress;
    @JsonProperty("merchant_id")
    private Integer MerchantId;
    @JsonProperty("phoneno")
    private PhoneNumber phonenumber;
    @JsonProperty("bank_account_info")
    private BankAccountInfo bankaccountinfo;
    @JsonProperty("promo_option")
    private PromoOption promoOption;
    @JsonProperty("next_review_date")
    private String NextReviewDate;
    @JsonProperty("institution_id")
    private Integer InstitutionId;
    @JsonProperty("merchant_contact")
    private com.prosper.automation.model.platform.MerchantContact MerchantContact;
    @JsonProperty("provider_status")
    private ProviderStatus providerStatus;
    @JsonProperty("merchant_compliance_status")
    private ProviderStatus merchantComplianceStatus;
    @JsonProperty("doing_business_as")
    private String DoingBusinessAs;
    @JsonProperty("provider_id")
    private String ProviderId;
    @JsonProperty("parent_merchant_id")
    private String ParentMerchantId;
    @JsonProperty("legal_name")
    private String LegalName;
    @JsonProperty("alt_key")
    private Integer AltKey;
    @JsonProperty("intended_role")
    private Integer IntendedRole;

}
