
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"loan_purpose_id", "listing_category_id", "name", "display_order"})
public class ListingCategory {
    
    @JsonProperty("loan_purpose_id")
    private Integer loanPurposeId;
    @JsonProperty("listing_category_id")
    private Integer listingCategoryId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("display_order")
    private Integer displayOrder;
}
