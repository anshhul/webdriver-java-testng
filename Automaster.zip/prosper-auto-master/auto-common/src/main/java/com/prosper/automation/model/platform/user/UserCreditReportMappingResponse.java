package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by rchintapalli on 12/06/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserCreditReportMappingResponse {

    protected List<Error> error;
    @JsonProperty("entities")
    private  List<UserCreditReportMappingDTO> userCRMappingResponse;
    @JsonProperty("entity_count")
    private Integer entityCount;
    @JsonProperty("entity_total_count")
    private Integer entityTotalCount;

    public List<UserCreditReportMappingDTO> getUserMappingResponse() {
        return userCRMappingResponse;
    }

    public List<Error> getError() {
        return error;
    }
}
