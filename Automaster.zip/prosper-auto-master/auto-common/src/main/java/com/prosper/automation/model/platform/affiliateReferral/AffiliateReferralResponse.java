
package com.prosper.automation.model.platform.affiliateReferral;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class AffiliateReferralResponse {
    
    @JsonProperty("affiliate_referral_id")
    private Long affiliateReferralId;
    @JsonProperty("affiliate_id")
    private Long affiliateId;
    @JsonProperty("affiliate_marketing_campaign_id")
    private Long affiliateMarketingCampaignId;
    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("affiliate_data")
    private String affiliateData;
    @JsonProperty("referrer_url")
    private String referrerUrl;
    @JsonProperty("landing_url")
    private String landingUrl;
    @JsonProperty("referral_date")
    private Date referralDate;
    @JsonProperty("login_date")
    private Date loginDate;
    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("creation_date")
    private String creationDate;
}
