package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by aamalraj on 12/21/15.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder({"secret_question_id",
        "secrete_question"}) public final class PasswordResetQuestion {

    @JsonProperty("secret_question_id") private Long secret_question_id;
    @JsonProperty("secrete_question") private String secrete_question;

    @JsonIgnore public Long getSecretQuestionId() {
        return secret_question_id;
    }

    @JsonIgnore public String getSecreteQuestion() {
        return secrete_question;
    }

}
