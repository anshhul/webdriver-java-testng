package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by ppatil on 12/1/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SocialSecurityNumber {

    @JsonProperty("number")
    private String number;

    private SocialSecurityNumber(final Builder builder) {
        number = builder.number;

    }

    public static final class Builder {
        private String number;


        public Builder() {
        }

        public Builder withNumber(final String number) {
            this.number = number;
            return this;
        }

        public SocialSecurityNumber build() {
            return new SocialSecurityNumber(this);
        }
    }

}
