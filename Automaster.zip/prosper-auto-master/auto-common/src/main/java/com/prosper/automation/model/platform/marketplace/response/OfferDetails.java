
package com.prosper.automation.model.platform.marketplace.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by rsubramanyam on 3/14/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferDetails {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("apr")
    private Double apr;
    @JsonProperty("loan_amount")
    private Double loan;
    @JsonProperty("origination_fee")
    private Double fees;
    @JsonProperty("monthly_payment")
    private Double monthlypay;
    @JsonProperty("loan_term_in_months")
    private Double termMonths;
    @JsonProperty("loan_term_in_years")
    private Double termYears;
    @JsonProperty("loan_rate")
    private Double rate;
    @JsonProperty("offer_url")
    private String offersUrl;
    @JsonProperty("offer_type")
    private String offersType;


    public OfferDetails() {
    }

    public OfferDetails(long id, double apr, double apr1, double apr2, double apr3, double apr4, double apr5, double apr6,
                        String offersUrl, String offersType) {
        this.id = id;
        this.apr = apr;
        this.apr = apr1;
        this.apr = apr2;
        this.apr = apr3;
        this.apr = apr4;
        this.apr = apr5;
        this.apr = apr6;
        this.offersUrl = offersUrl;
        this.offersType = offersType;
    }

    @JsonIgnore
    public double getMonthlypay() {
        return monthlypay;
    }

    @JsonIgnore
    public long getId() {
        return id;
    }

    @JsonIgnore
    public double getApr() {
        return apr;
    }

    @JsonIgnore
    public double getLoan() {
        return loan;
    }

    @JsonIgnore
    public double getFees() {
        return fees;
    }

    @JsonIgnore
    public double getTermMonths() {
        return termMonths;
    }

    @JsonIgnore
    public double getTermYears() {
        return termYears;
    }

    @JsonIgnore
    public double getRate() {
        return rate;
    }

    @JsonIgnore
    public String getOffersType() {
        return offersType;
    }

    @JsonIgnore
    public String getOffersUrl() {
        return offersUrl;
    }
}
