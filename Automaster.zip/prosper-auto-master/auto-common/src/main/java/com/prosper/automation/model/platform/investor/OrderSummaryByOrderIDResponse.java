
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public final class OrderSummaryByOrderIDResponse {
    
    @JsonProperty("order_id")
    private UUID orderID;

    @JsonProperty("created_date")
    private String createdDate;

    @JsonProperty("order_source")
    private OrderSource orderSource;
    
    @JsonProperty("order_number")
    private Integer orderNumber;

    @JsonProperty("submitted_order")
    private SubmittedOrderDetails submittedOrder;

    @JsonProperty("pending_order")
    private PendingOrderDetails pendingOrder;

    @JsonProperty("expired_order")
    private ExpiredOrderDetails expiredOrder;

    @JsonProperty("invested_order")
    private InvestorOrderDetails investedOrder;


    public UUID getOrderID() {
        return orderID;
    }

    public void setOrderID(UUID orderID) {
        this.orderID = orderID;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public OrderSource getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(OrderSource orderSource) {
        this.orderSource = orderSource;
    }

    public Integer getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    public SubmittedOrderDetails getSubmittedOrder() {
        return submittedOrder;
    }

    public void setSubmittedOrder(SubmittedOrderDetails submittedOrder) {
        this.submittedOrder = submittedOrder;
    }

    public PendingOrderDetails getPendingOrder() {
        return pendingOrder;
    }

    public void setPendingOrder(PendingOrderDetails pendingOrder) {
        this.pendingOrder = pendingOrder;
    }

    public ExpiredOrderDetails getExpiredOrder() {
        return expiredOrder;
    }

    public void setExpiredOrder(ExpiredOrderDetails expiredOrder) {
        this.expiredOrder = expiredOrder;
    }

    public InvestorOrderDetails getInvestedOrder() {
        return investedOrder;
    }

    public void setInvestedOrder(InvestorOrderDetails investedOrder) {
        this.investedOrder = investedOrder;
    }

}
