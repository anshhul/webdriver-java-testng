package com.prosper.automation.model.platform.marketplace.util.ProspectComparators;

import com.prosper.automation.model.platform.PersonalInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class ProspectPersonalInfoComparator implements Comparator<PersonalInfo> {

    @Override public int compare(PersonalInfo left, PersonalInfo right) {
        if (left!= null && !left.getFirstName().equalsIgnoreCase(right.getFirstName()))
            return 1;
        if (left!= null && !left.getLastName().equalsIgnoreCase(right.getLastName()))
            return 1;
        if (left!= null && !left.getMiddleInitial().equalsIgnoreCase(right.getMiddleInitial()))
            return 1;
        return 0;
    }
}
