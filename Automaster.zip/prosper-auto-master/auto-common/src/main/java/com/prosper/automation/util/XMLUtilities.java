
package com.prosper.automation.util;

import com.google.common.collect.ImmutableMap;
import com.prosper.automation.exception.AutomationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class XMLUtilities {

    private XMLUtilities() {
    }

    public static String updateXMLElementValue(final String templateFilePath, final ImmutableMap<String, String> xmlUpdates)
            throws AutomationException {
        try {
            final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            final Document document = documentBuilder.parse(templateFilePath);
            final XPathFactory xPathFactory = XPathFactory.newInstance();

            final Iterator<Map.Entry<String, String>> iterator = xmlUpdates.entrySet().iterator();
            while (iterator.hasNext()) {
                final Map.Entry<String, String> xmlUpdate = iterator.next();

                final XPath xPath = xPathFactory.newXPath();
                final XPathExpression xPathExpression = xPath.compile(xmlUpdate.getKey());

                final NodeList nodeList = (NodeList) xPathExpression.evaluate(document, XPathConstants.NODESET);
                // final NodeList nodeList = document.getElementsByTagName(xmlUpdate.getKey());

                if (nodeList.getLength() == 0) {
                    throw new AutomationException("Unable to find expected node in the XML.");
                }

                final Node node = nodeList.item(0);
                node.setTextContent(xmlUpdate.getValue());
            }

            final DOMSource domSource = new DOMSource(document);
            final StreamResult streamResult = new StreamResult(new StringWriter());

            final TransformerFactory transformerFactory = TransformerFactory.newInstance();
            final Transformer transformer = transformerFactory.newTransformer();
            transformer.transform(domSource, streamResult);
            return streamResult.getWriter().toString();
        } catch (ParserConfigurationException | IOException | XPathExpressionException | SAXException | TransformerException ex) {
            throw new AutomationException(ex.toString());
        }
    }
}
