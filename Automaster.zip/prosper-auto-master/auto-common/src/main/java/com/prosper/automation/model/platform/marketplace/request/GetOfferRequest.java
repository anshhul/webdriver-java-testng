
package com.prosper.automation.model.platform.marketplace.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Lists;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.CoApplicant;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;

import java.util.List;

/**
 * @author pbudiono
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetOfferRequest {

    @JsonProperty("identification")
    private IdentificationInfo identification;

    @JsonProperty("loan_info")
    private LoanInfo loanInfo;

    @JsonProperty("personal_info")
    private PersonalInfo personalInfo;

    @JsonProperty("address_info")
    private AddressInfo addressInfo;

    @JsonProperty("contact_info")
    private ContactInfo contactInfo;

    @JsonProperty("employment_info")
    private EmploymentInfo employmentInfo;

    @JsonProperty("bank_account_info")
    private BankAccountInfo bankAccountInfo;

    @JsonProperty("co_applicants")
    private List<CoApplicant> coApplicants;


    public GetOfferRequest() {
    }

    private GetOfferRequest(Builder builder) {
        identification = builder.identification;
        loanInfo = builder.loanInfo;
        setPersonalInfo(builder.personalInfo);
        addressInfo = builder.addressInfo;
        contactInfo = builder.contactInfo;
        employmentInfo = builder.employmentInfo;
        bankAccountInfo = builder.bankAccountInfo;
        coApplicants = builder.coApplicants;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public void setPersonalInfo(PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    @JsonIgnore
    public LoanInfo getLoanInfo() {
        return loanInfo;
    }

    public void setLoanInfo(LoanInfo loanInfo) {
        this.loanInfo = loanInfo;
    }

    public void setCoApplicant(CoApplicant coApplicant) {
        this.coApplicants = Lists.newArrayList(coApplicant);
    }

    public void setAddressInfo(AddressInfo addressInfo) {
        this.addressInfo = addressInfo;
    }


    public static final class Builder {

        private IdentificationInfo identification;
        private LoanInfo loanInfo;
        private PersonalInfo personalInfo;
        private AddressInfo addressInfo;
        private ContactInfo contactInfo;
        private EmploymentInfo employmentInfo;
        private BankAccountInfo bankAccountInfo;
        private List<CoApplicant> coApplicants;


        public Builder() {
        }

        public Builder withIdentification(IdentificationInfo val) {
            identification = val;
            return this;
        }

        public Builder withLoanInfo(LoanInfo val) {
            loanInfo = val;
            return this;
        }

        public Builder withPersonalInfo(PersonalInfo val) {
            personalInfo = val;
            return this;
        }

        public Builder withAddressInfo(AddressInfo val) {
            addressInfo = val;
            return this;
        }

        public Builder withContactInfo(ContactInfo val) {
            contactInfo = val;
            return this;
        }

        public Builder withEmploymentInfo(EmploymentInfo val) {
            employmentInfo = val;
            return this;
        }

        public Builder withBankAccountInfo(BankAccountInfo val) {
            bankAccountInfo = val;
            return this;
        }

        public Builder withCoApplicants(List<CoApplicant> val) {
            coApplicants = val;
            return this;
        }

        public GetOfferRequest build() {
            return new GetOfferRequest(this);
        }
    }
}
