
package com.prosper.automation.model.platform.passiveInvest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 25 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderFailedListings {

    @JsonProperty("listing_id")
    private Integer listingId;

    @JsonProperty("loan_amount")
    private Integer loanAmount;

    @JsonProperty("whole_loan_private_user_id")
    private Integer wholeLoanPrivateUserId;

    @JsonProperty("whole_loan_start_date")
    private String wholeLoanStartDate;


    public Integer getListingId() {
        return listingId;
    }

    public Integer getLoanAmount() {
        return loanAmount;
    }

    public Integer getWholeLoanPrivateUserId() {
        return wholeLoanPrivateUserId;
    }

    public String getWholeLoanStartDate() {
        return wholeLoanStartDate;
    }

}
