
package com.prosper.automation.model.platform.passiveInvest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ramkaur on 25 Nov, 2016
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrdersFailed {

    @JsonProperty("investor_id")
    private Integer investorId;

    @JsonProperty("order_id")
    private String orderId;

    @JsonProperty("error_message")
    private String errorMessage;

    @JsonProperty("order_listings")
    private List<OrderFailedListings> orderListings;

    @JsonProperty("success")
    private Boolean success;


    public Integer getInvestorId() {
        return investorId;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public List<OrderFailedListings> getOrderListings() {
        return orderListings;
    }

    public Boolean getSuccess() {
        return success;
    }

}
