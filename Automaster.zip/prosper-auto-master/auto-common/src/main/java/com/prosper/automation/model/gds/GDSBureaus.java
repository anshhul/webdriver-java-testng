
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 5/26/16.
 */
public final class GDSBureaus {

    @JsonProperty("GiactPI")
    private GiactPI giactPi;
    @JsonProperty("LNFlexID")
    private LNFlexID lnFlexId;
    @JsonProperty("EquTWN")
    private EquTWN equTwn;
    @JsonProperty("ID_Analytics")
    private IDAnalytics idAnalytics;


    public String getEquTWNHitFlag() {
        return equTwn.getEquTWNHitFlag();
    }

    public String getEquTWNPullFlag() {
        return equTwn.getEquTWNPullFlag();
    }

    public String getGiactPIHitFlag() {
        return giactPi.getGiactPIHitFlag();
    }

    public String getGiactPIPullFlag() {
        return giactPi.getGiactPIPullFlag();
    }

    public String getIDAnalyticsHitFlag() {
        return idAnalytics.getIDAnalyticsHitFlag();
    }

    public String getIDAnalyticsPullFlag() {
        return idAnalytics.getIDAnalyticsPullFlag();
    }

    public String getLNFlexIDHitFlag() {
        return lnFlexId.getLNFlexIDHitFlag();
    }

    public String getLNFlexIDPullFlag() {
        return lnFlexId.getLNFlexIDPullFlag();
    }
}
