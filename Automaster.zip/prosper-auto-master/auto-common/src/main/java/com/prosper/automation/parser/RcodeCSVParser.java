
package com.prosper.automation.parser;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.ScoreCardData;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.util.ArrayList;

import java.io.*;
import java.util.List;

/**
 * Created by ppatil on 12/6/16.
 */
public final class RcodeCSVParser {

    private RcodeCSVParser() {
    }

    public static Object[][] parse(final String csvFilePath) throws AutomationException {
        try (FileInputStream fileInputStream = new FileInputStream(csvFilePath);
             Reader reader = new InputStreamReader(fileInputStream);
             CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader())) {
            final List<CSVRecord> records = parser.getRecords();
            final int recordSize = records.size();
            final Object[][] bureauData = new Object[recordSize][1];
            for (int i = 0; i < recordSize; i++) {
                bureauData[i][0] = ScoreCardData.Mapper.map(i + 2, records.get(i));
            }
            return bureauData;
        } catch (IOException e) {
            throw new AutomationException(e.getMessage());
        }
    }


    public static void appendToCSV(final String csvFilePath, List probablityList) throws IOException {

        BufferedReader br = null;
        BufferedWriter bw = null;
        final String lineSep = System.getProperty("line.separator");
        String path = "/Users/ppatil/Desktop/PricingFiles/Rcode/";
        String fileName = "pmi7Output.csv";
        try {
            File file = new File(csvFilePath);
            File file2 = new File(path, fileName);

            br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2)));
            String line = null;
            int i = 0;
            boolean firstIteration = true;
            for (line = br.readLine(); line != null; line = br.readLine(), i++) {
                String addedColumn = String.valueOf(probablityList.get(i));
                bw.write(line + "," + addedColumn + lineSep);
            }

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            if (br != null)
                br.close();
            if (bw != null)
                bw.close();
        }
    }


}
