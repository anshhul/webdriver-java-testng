package com.prosper.automation.model.platform.investor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class OrderListingResponse {

    private List<Listings> result;
    private int resultCount;
    private int totalCount;

    @JsonProperty("result")
    public List<Listings> getResult() {
        return result;
    }

    @JsonProperty("result_count")
    public int getResultCount() {
        return resultCount;
    }

    @JsonProperty("total_count")
    public int getTotalCount() {
        return totalCount;
    }

    public void setResult(final List<Listings> result) {
        this.result = result;
    }

    public void setResultCount(final int resultCount) {
        this.resultCount = resultCount;
    }

    public void setTotalCount(final int totalCount) {
        this.totalCount = totalCount;
    }

}
