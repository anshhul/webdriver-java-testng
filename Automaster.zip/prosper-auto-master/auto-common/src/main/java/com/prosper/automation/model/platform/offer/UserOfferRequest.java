
package com.prosper.automation.model.platform.offer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by gzhou on 2/6/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserOfferRequest {

    private static final long serialVersionUID = 1L;

    @JsonProperty("user_annual_income")
    private Double userAnnualIncome;


    public Double getUserAnnualIncome() {
        return userAnnualIncome;
    }

    public void setUserAnnualIncome(Double userAnnualIncome) {
        this.userAnnualIncome = userAnnualIncome;
    }
}
