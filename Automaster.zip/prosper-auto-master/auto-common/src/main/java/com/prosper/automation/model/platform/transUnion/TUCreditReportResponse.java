
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by pbudiono on 9/8/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class TUCreditReportResponse {

    protected List<Error> error;
    @JsonProperty("external_credit_report_id")
    private UUID externalCreditReportId;
    @JsonProperty("address")
    private AddressRequestDTO address;
    @JsonProperty("person_name")
    private PersonNameRequestDTO personName;
    @JsonProperty("social_security_number")
    private SocialSecurityRequestDTO socialSecurity;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT")
    @JsonProperty("date_of_birth")
    private Date dateOfBirth;
    @JsonProperty("score_model")
    private List<ScoreResponseDTO> scoreResponse;
    @JsonProperty("bureau_attributes")
    private Map<String, String> bureauAttributes;


    @JsonIgnore
    public UUID getExternalCreditReportId() {
        return externalCreditReportId;
    }

    @JsonIgnore
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonIgnore
    public SocialSecurityRequestDTO getSocialSecurity() {
        return socialSecurity;
    }

    @JsonIgnore
    public PersonNameRequestDTO getPersonName() {
        return personName;
    }
}
