
package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public final class InvestOrderAll {

    @JsonProperty("result")
    private List<InvestOrders> result;
    
    @JsonProperty("total_count")
    private Integer totalCount;
    
    @JsonProperty("result_count")
    private Integer resultCount;
    
    
    public List<InvestOrders> getResult() {
        return result;
    }
    
    public void setResult(List<InvestOrders> result) {
        this.result = result;
    }
    
    public Integer getTotalCount() {
        return totalCount;
    }
    
    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
    
    public Integer getResultCount() {
        return resultCount;
    }
    
    public void setResultCount(Integer resultCount) {
        this.resultCount = resultCount;
    }
    
}
