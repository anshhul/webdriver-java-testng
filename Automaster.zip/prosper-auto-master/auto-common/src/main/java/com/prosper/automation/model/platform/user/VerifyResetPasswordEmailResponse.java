package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * Created by rsubramanyam on 5/17/16.
 */
public class VerifyResetPasswordEmailResponse {

    @JsonProperty("email_address")
    private String emailAddress;
    @JsonProperty("verified")
    private boolean isVerified;
    @JsonProperty("code")
    private String verificationCode;

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }


    @JsonProperty("question_map")
    private Map<String, String> questions;


    public Map<String, String> getQuestions() {
        return questions;
    }

    public void setQuestions(Map<String, String> questions) {
        this.questions = questions;
    }

    public void setVerified(boolean isVerified) {
        this.isVerified = isVerified;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
