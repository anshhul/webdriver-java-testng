package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by aamalraj on 1/8/16.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)

public class ResendVerificationEmailRequest {

    @JsonProperty("email_address") private String emailAddress;
    @JsonProperty("email_type") private String emailType;

    public ResendVerificationEmailRequest() {
    }

    private ResendVerificationEmailRequest(final Builder builder) {
        emailAddress = builder.emailAddress;
        emailType = builder.emailType;
    }

    public void setEmailAddress(final String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setEmailType(final String emailType) {
        this.emailType = emailType;
    }

    public static final class Builder {

        private String emailAddress;
        private String emailType;

        public Builder() {
        }

        public Builder withEmailAddress(final String emailAddress) {
            this.emailAddress = emailAddress;
            return this;
        }

        public Builder withEmailType(final String emailType) {
            this.emailType = emailType;
            return this;
        }

        public ResendVerificationEmailRequest build() {
            return new ResendVerificationEmailRequest(this);
        }
    }

}
