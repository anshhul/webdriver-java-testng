
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"source_status_message", "source_request_message", "source_response_message", "source_transaction_guid",
        "errors", "status_code", "http_response_code"})
public final class PartnerApiInfo {
    
    @JsonProperty("source_status_message")
    private String sourceStatusMessage;
    @JsonProperty("source_request_message")
    private String sourceRequestMessage;
    @JsonProperty("source_response_message")
    private String sourceResponseMessage;
    @JsonProperty("source_transaction_guid")
    private UUID sourceTransactionGuid;
    @JsonProperty("errors")
    private String errors;
    @JsonProperty("status_code")
    private String statusCode;
    @JsonProperty("http_response_code")
    private String httpResponseCode;

    public String getSourceStatusMessage() {
        return sourceStatusMessage;
    }

    public void setSourceStatusMessage(String sourceStatusMessage) {
        this.sourceStatusMessage = sourceStatusMessage;
    }

    public String getSourceRequestMessage() {
        return sourceRequestMessage;
    }

    public void setSourceRequestMessage(String sourceRequestMessage) {
        this.sourceRequestMessage = sourceRequestMessage;
    }

    public String getSourceResponseMessage() {
        return sourceResponseMessage;
    }

    public void setSourceResponseMessage(String sourceResponseMessage) {
        this.sourceResponseMessage = sourceResponseMessage;
    }

    public UUID getSourceTransactionGuid() {
        return sourceTransactionGuid;
    }

    public void setSourceTransactionGuid(UUID sourceTransactionGuid) {
        this.sourceTransactionGuid = sourceTransactionGuid;
    }

    public String getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors = errors;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getHttpResponseCode() {
        return httpResponseCode;
    }

    public void setHttpResponseCode(String httpResponseCode) {
        this.httpResponseCode = httpResponseCode;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PartnerApiInfo that = (PartnerApiInfo) o;
        return Objects.equal(sourceStatusMessage, that.sourceStatusMessage) &&
                Objects.equal(sourceRequestMessage, that.sourceRequestMessage) &&
                Objects.equal(sourceResponseMessage, that.sourceResponseMessage) &&
                Objects.equal(sourceTransactionGuid, that.sourceTransactionGuid) &&
                Objects.equal(errors, that.errors) &&
                Objects.equal(statusCode, that.statusCode) &&
                Objects.equal(httpResponseCode, that.httpResponseCode);
    }

    @Override public int hashCode() {
        return Objects.hashCode(sourceStatusMessage, sourceRequestMessage, sourceResponseMessage, sourceTransactionGuid, errors,
                statusCode, httpResponseCode);
    }

    @Override public String toString() {
        return "PartnerApiInfo{" +
                "sourceStatusMessage='" + sourceStatusMessage + '\'' +
                ", sourceRequestMessage='" + sourceRequestMessage + '\'' +
                ", sourceResponseMessage='" + sourceResponseMessage + '\'' +
                ", sourceTransactionGuid=" + sourceTransactionGuid +
                ", errors='" + errors + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", httpResponseCode='" + httpResponseCode + '\'' +
                '}';
    }
}
