
package com.prosper.automation.model.gds;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by grajasekar on 9/21/15.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class GDSHoldResponse {

    @JsonProperty("Response")
    private Response response;


    @JsonIgnore
    public Response getResponse() {
        return response;
    }
}
