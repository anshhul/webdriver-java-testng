
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public final class SlpOffers {

    @JsonProperty("offer_id")
    private String offerID;
    
    @JsonProperty("offer_date")
    private String offerDate;
    
    @JsonProperty("offer_expiration_date")
    private String offerExpirationDate;

    @JsonProperty("total_principal_balance")
    private String totalPrincipalBalance;

    @JsonProperty("total_dirty_price")
    private double totalDirtyPrice;

    @JsonProperty("total_fees")
    private double totalFees;

    @JsonProperty("total_wire_amount")
    private double totalWireAmount;

    @JsonProperty("buyer_user_id")
    private String buyerUserId;

    @JsonProperty("seller_user_id")
    private String sellerUserId;

    @JsonProperty("offer_status")
    private String offerStatus;


    public String getBuyerUserId() {
        return buyerUserId;
    }
    
    public String getOfferDate() {
        return offerDate;
    }
    
    public String getOfferExpirationDate() {
        return offerExpirationDate;
    }
    
    public String getOfferID() {
        return offerID;
    }

    public String getOfferStatus() {
        return offerStatus;
    }

    public String getSellerUserId() {
        return sellerUserId;
    }
    
    public double getTotalDirtyPrice() {
        return totalDirtyPrice;
    }

    public double getTotalFees() {
        return totalFees;
    }
    
    public String getTotalPrincipalBalance() {
        return totalPrincipalBalance;
    }

    public double getTotalWireAmount() {
        return totalWireAmount;
    }
    
    public void setBuyerUserId(final String buyerUserId) {
        this.buyerUserId = buyerUserId;
    }

    public void setOfferDate(final String offerDate) {
        this.offerDate = offerDate;
    }
    
    public void setOfferExpirationDate(final String offerExpirationDate) {
        this.offerExpirationDate = offerExpirationDate;
    }

    public void setOfferID(final String offerID) {
        this.offerID = offerID;
    }

    public void setOfferStatus(final String offerStatus) {
        this.offerStatus = offerStatus;
    }

    public void setSellerUserId(final String sellerUserId) {
        this.sellerUserId = sellerUserId;
    }

    public void setTotalDirtyPrice(final double totalDirtyPrice) {
        this.totalDirtyPrice = totalDirtyPrice;
    }

    public void setTotalFees(final double totalFees) {
        this.totalFees = totalFees;
    }

    public void setTotalPrincipalBalance(final String totalPrincipalBalance) {
        this.totalPrincipalBalance = totalPrincipalBalance;
    }

    public void setTotalWireAmount(final double totalWireAmount) {
        this.totalWireAmount = totalWireAmount;
    }

}
