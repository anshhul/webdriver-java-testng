
package com.prosper.automation.model.platform.origination;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */
public class OriginateLoan {
    
    @JsonProperty("success")
    private boolean success;
    @JsonProperty("success_database")
    private boolean successDatabase;
    @JsonProperty("messaging_result")
    private boolean messagingResult;
    
    
    private OriginateLoan(Builder builder) {
        success = builder.success;
        successDatabase = builder.success;
        messagingResult = builder.success;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public boolean isSuccessDatabase() {
        return successDatabase;
    }
    
    public void setSuccessDatabase(boolean successDatabase) {
        this.successDatabase = successDatabase;
    }
    
    public boolean isMessagingResult() {
        return messagingResult;
    }
    
    public void setMessagingResult(boolean messagingResult) {
        this.messagingResult = messagingResult;
    }
    
    
    public static final class Builder {
        
        private boolean success;
        private boolean successDatabase;
        private boolean messagingResult;
        
        
        public Builder() {
            
        }
        
        public Builder withSuccess(final boolean success) {
            this.success = success;
            return this;
        }
        
        public Builder withSuccessDatabase(final boolean successDatabase) {
            this.successDatabase = successDatabase;
            return this;
            
        }
        
        public Builder withMessagingResult(final boolean messagingResult) {
            this.messagingResult = messagingResult;
            return this;
        }
        
        public OriginateLoan build() {
            return new OriginateLoan(this);
        }
    }
}
