
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"version_end_date", "privacy_policies_agreement", "is_tax_withholding_approved", "user_id",
        "version_start_date", "credit_profile_auth", "lending_accreditation_requirement_type_id",
        "consent_to_electronic_disclosures", "accredited_state", "lender_registration_agreement_approved", "terms_of_use",
        "prospectus_reviewed", "data_terms_of_use"})
public final class LendingAccreditation {
    
    @JsonProperty("version_end_date")
    private VersionEndDate versionEndDate;
    @JsonProperty("privacy_policies_agreement")
    private Boolean privacyPoliciesAgreement;
    @JsonProperty("is_tax_withholding_approved")
    private Boolean isTaxWithholdingApproved;
    @JsonProperty("user_id")
    private Integer userId;
    @JsonProperty("version_start_date")
    private VersionStartDate versionStartDate;
    @JsonProperty("credit_profile_auth")
    private Boolean creditProfileAuth;
    @JsonProperty("lending_accreditation_requirement_type_id")
    private Integer lendingAccreditationRequirementTypeID;
    @JsonProperty("consent_to_electronic_disclosures")
    private Boolean consentToElectronicDisclosures;
    @JsonProperty("accredited_state")
    private String accreditedState;
    @JsonProperty("lender_registration_agreement_approved")
    private Boolean lenderRegistrationAgreementApproved;
    @JsonProperty("terms_of_use")
    private Boolean termsOfUse;
    @JsonProperty("prospectus_reviewed")
    private Boolean prospectusReviewed;
    @JsonProperty("webBankPrivacyPolicy")
    private Boolean webBankPrivacyPolicy;
    @JsonProperty("data_terms_of_use")
    private Boolean dataTermsOfUse;
    
    
    public LendingAccreditation() {
    }
    
    private LendingAccreditation(final Builder builder) {
        versionEndDate = builder.versionEndDate;
        privacyPoliciesAgreement = builder.privacyPoliciesAgreement;
        isTaxWithholdingApproved = builder.isTaxWithholdingApproved;
        userId = builder.userId;
        versionStartDate = builder.versionStartDate;
        creditProfileAuth = builder.creditProfileAuth;
        lendingAccreditationRequirementTypeID = builder.lendingAccreditationRequirementTypeID;
        consentToElectronicDisclosures = builder.consentToElectronicDisclosures;
        accreditedState = builder.accreditedState;
        lenderRegistrationAgreementApproved = builder.lenderRegistrationAgreementApproved;
        termsOfUse = builder.termsOfUse;
        prospectusReviewed = builder.prospectusReviewed;
        webBankPrivacyPolicy = builder.webBankPrivacyPolicy;
        dataTermsOfUse = builder.dataTermsOfUse;
    }
    
    public Boolean getPrivacyPoliciesAgreement() {
        return privacyPoliciesAgreement;
    }
    
    public void setPrivacyPoliciesAgreement(final Boolean privacyPoliciesAgreement) {
        this.privacyPoliciesAgreement = privacyPoliciesAgreement;
    }
    
    public Boolean getTermsOfUse() {
        return termsOfUse;
    }
    
    public void setTermsOfUse(final Boolean termsOfUse) {
        this.termsOfUse = termsOfUse;
    }
    
    public Boolean getConsentToElectronicDisclosures() {
        return consentToElectronicDisclosures;
    }
    
    public void setConsentToElectronicDisclosures(final Boolean consentToElectronicDisclosures) {
        this.consentToElectronicDisclosures = consentToElectronicDisclosures;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LendingAccreditation that = (LendingAccreditation) o;
        return Objects.equal(versionEndDate, that.versionEndDate)
                && Objects.equal(privacyPoliciesAgreement, that.privacyPoliciesAgreement)
                && Objects.equal(isTaxWithholdingApproved, that.isTaxWithholdingApproved) && Objects.equal(userId, that.userId)
                && Objects.equal(versionStartDate, that.versionStartDate)
                && Objects.equal(lendingAccreditationRequirementTypeID, that.lendingAccreditationRequirementTypeID)
                && Objects.equal(consentToElectronicDisclosures, that.consentToElectronicDisclosures)
                && Objects.equal(accreditedState, that.accreditedState)
                && Objects.equal(lenderRegistrationAgreementApproved, that.lenderRegistrationAgreementApproved)
                && Objects.equal(termsOfUse, that.termsOfUse) && Objects.equal(prospectusReviewed, that.prospectusReviewed);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(versionEndDate, privacyPoliciesAgreement, isTaxWithholdingApproved, userId, versionStartDate,
                creditProfileAuth, lendingAccreditationRequirementTypeID, consentToElectronicDisclosures, accreditedState,
                lenderRegistrationAgreementApproved, termsOfUse, prospectusReviewed, webBankPrivacyPolicy);
    }
    
    
    public static final class Builder {
        
        private VersionEndDate versionEndDate;
        private Boolean privacyPoliciesAgreement;
        private Boolean isTaxWithholdingApproved;
        private Integer userId;
        private VersionStartDate versionStartDate;
        private Boolean creditProfileAuth;
        private Integer lendingAccreditationRequirementTypeID;
        private Boolean consentToElectronicDisclosures;
        private String accreditedState;
        private Boolean lenderRegistrationAgreementApproved;
        private Boolean termsOfUse;
        private Boolean prospectusReviewed;
        private Boolean webBankPrivacyPolicy;
        private Boolean dataTermsOfUse;
        
        
        public Builder() {
        }
        
        public Builder withDataTermsOfUse(final Boolean dataTermsOfUse) {
            this.dataTermsOfUse = dataTermsOfUse;
            return this;
        }
        
        public Builder withVersionEndDate(final VersionEndDate versionEndDate) {
            this.versionEndDate = versionEndDate;
            return this;
        }
        
        public Builder withPrivacyPoliciesAgreement(final Boolean privacyPoliciesAgreement) {
            this.privacyPoliciesAgreement = privacyPoliciesAgreement;
            return this;
        }
        
        public Builder withIsTaxWithholdingApproved(final Boolean isTaxWithholdingApproved) {
            this.isTaxWithholdingApproved = isTaxWithholdingApproved;
            return this;
        }
        
        public Builder withUserId(final Integer userId) {
            this.userId = userId;
            return this;
        }
        
        public Builder withVersionStartDate(final VersionStartDate versionStartDate) {
            this.versionStartDate = versionStartDate;
            return this;
        }
        
        public Builder withCreditProfileAuth(final Boolean creditProfileAuth) {
            this.creditProfileAuth = creditProfileAuth;
            return this;
        }
        
        public Builder withLendingAccreditationRequirementTypeID(final Integer lendingAccreditationRequirementTypeID) {
            this.lendingAccreditationRequirementTypeID = lendingAccreditationRequirementTypeID;
            return this;
        }
        
        public Builder withConsentToElectronicDisclosures(final Boolean consentToElectronicDisclosures) {
            this.consentToElectronicDisclosures = consentToElectronicDisclosures;
            return this;
        }
        
        public Builder withAccreditedState(final String accreditedState) {
            this.accreditedState = accreditedState;
            return this;
        }
        
        public Builder withLenderRegistrationAgreementApproved(final Boolean lenderRegistrationAgreementApproved) {
            this.lenderRegistrationAgreementApproved = lenderRegistrationAgreementApproved;
            return this;
        }
        
        public Builder withTermsOfUse(final Boolean termsOfUse) {
            this.termsOfUse = termsOfUse;
            return this;
        }
        
        public Builder withProspectusReviewed(final Boolean prospectusReviewed) {
            this.prospectusReviewed = prospectusReviewed;
            return this;
        }
        
        public Builder withWebBankPrivacyPolicy(final Boolean webBankPrivacyPolicy) {
            this.webBankPrivacyPolicy = webBankPrivacyPolicy;
            return this;
        }
        
        public LendingAccreditation build() {
            return new LendingAccreditation(this);
        }
    }
}
