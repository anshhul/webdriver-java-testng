package com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators;

import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;

import java.util.Comparator;

/**
 * Created by rsubramanyam on 3/3/16.
 */
public class PartnerRequestContactInfoComparator implements Comparator<ContactInfo> {

    @Override public int compare(ContactInfo left, ContactInfo right) {
        // Contact Info
        if (right != null ?
                !left.getEmailAddress().equals(right.getEmailAddress()) :
                left != null)
            return 1;
        if (right != null && right.getMobilePhone() != null
                && right.getMobilePhone().getPhoneNumber() != null ?
                !right.getMobilePhone().getPhoneNumber().
                        equals(left.getMobilePhone().getPhoneNumber()) :
                left != null && (left != null && left.getMobilePhone() != null
                        && left.getMobilePhone().getPhoneNumber() != null))
            return 1;
        if (right != null && right.getWorkPhone() != null
                && right.getWorkPhone().getPhoneNumber() != null ?
                !right.getWorkPhone().getPhoneNumber().
                        equals(left.getWorkPhone().getPhoneNumber()) :
                (left != null && left.getWorkPhone() != null
                        && left.getWorkPhone().getPhoneNumber() != null))
            return 1;
        if (right != null && right.getHomePhone() != null
                && right.getHomePhone().getPhoneNumber() != null ?
                !right.getHomePhone().getPhoneNumber().
                        equals(left.getHomePhone().getPhoneNumber()) :
                left != null && left.getHomePhone() != null
                        && left.getHomePhone().getPhoneNumber() != null)

            return 1;
        if (right != null && right.getMobilePhone() != null
                && right.getMobilePhone().getAreaCode() != null ?
                !right.getMobilePhone().getAreaCode().
                        equals(left.getMobilePhone().getAreaCode()) :
                left != null && left.getMobilePhone() != null
                        && left.getMobilePhone().getAreaCode() != null)
            return 1;
        if (right != null && right.getWorkPhone() != null
                && right.getWorkPhone().getAreaCode() != null ?
                !right.getWorkPhone().getAreaCode().
                        equals(left.getWorkPhone().getAreaCode()) : left != null &&
                left.getWorkPhone() != null && left.getWorkPhone().getAreaCode() != null)
            return 1;
        if (right != null && right.getHomePhone() != null
                && right.getHomePhone().getAreaCode() != null ?
                !right.getHomePhone().getAreaCode().
                        equals(left.getHomePhone().getAreaCode()) : left != null &&
                left.getHomePhone() != null && left.getHomePhone().getAreaCode() != null)
            return 1;
        return 0;
    }
}
