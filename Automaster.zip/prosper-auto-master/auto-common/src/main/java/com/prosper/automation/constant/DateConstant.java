
package com.prosper.automation.constant;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.prosper.automation.exception.AutomationException;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class DateConstant {

    public static final SimpleDateFormat REST_API_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
    public static final SimpleDateFormat SLP_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final SimpleDateFormat PRICING_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final SimpleDateFormat TEST_CYCLE_DATE_FORMAT = new SimpleDateFormat("d/MMM/yy");
    public static final SimpleDateFormat TEST_CYCLE_TIME_FORMAT = new SimpleDateFormat("h:mm:ss z");
    public static final SimpleDateFormat DATE_FORMAT_UPTO_MILLIS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    public static final SimpleDateFormat YYYY_MM_DD_HH_MM_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
    public static final SimpleDateFormat YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");

    public static final String INVALID_MONTH_DATE_TEMPLATE = "20/1/%d";
    public static final String INVALID_DAY_DATE_TEMPLATE = "1/40/%d";

    public static final String FIVE_DIGIT_YEAR_DATE = "1/1/20000";

    public static final String CHARACTER_DATE = "ab/cd/efgh";

    private static final int MINUS_EIGHTEEN = -18;
    private static final int MINUS_NINETEEN = -19;
    private static final int PLUS_ONE = +1;
    private static final int MINUS_ONE = -1;


    private DateConstant() {
    }

    public static Boolean areDatesEqual(final String firstDateString, final String secondDateString,
                                        final SimpleDateFormat simpleDateFormat)
            throws AutomationException {
        try {
            final Date firstDate = simpleDateFormat.parse(firstDateString);
            final Date secondDate = simpleDateFormat.parse(secondDateString);

            return firstDate.compareTo(secondDate) == 0;
        } catch (final ParseException pe) {
            throw new AutomationException("Unable to parse date format.", pe);
        }
    }

    public static String getFutureMonthDateString(final SimpleDateFormat simpleDateFormat, final int month) {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, month);
        return simpleDateFormat.format(cal.getTime());
    }

    public static String getInvalidDayDateOfBirthString() {
        final Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, MINUS_NINETEEN);
        return String.format(INVALID_DAY_DATE_TEMPLATE, today.get(Calendar.YEAR));
    }

    public static String getInvalidMonthDateOfBirthString() {
        final Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, MINUS_NINETEEN);
        return String.format(INVALID_MONTH_DATE_TEMPLATE, today.get(Calendar.YEAR));
    }

    public static String getOverEighteenYearsOldDateOfBirthString() {
        final Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, MINUS_EIGHTEEN);
        today.add(Calendar.DAY_OF_MONTH, MINUS_ONE);
        return REST_API_DATE_FORMAT.format(today.getTime());
    }

    public static String getTodayDateString(final SimpleDateFormat simpleDateFormat) {
        return simpleDateFormat.format(Calendar.getInstance().getTime());
    }

    public static String getUnderEighteenYearsOldDateOfBirthString() {
        final Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, MINUS_EIGHTEEN);
        today.add(Calendar.DAY_OF_MONTH, PLUS_ONE);
        return REST_API_DATE_FORMAT.format(today.getTime());
    }

    public static int getMonthNumber(String month) throws ParseException {
        SimpleDateFormat inputFormat = new SimpleDateFormat("MMMM");
        Calendar cal = Calendar.getInstance();
        cal.setTime(inputFormat.parse(month));
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM");
        return Integer.valueOf(outputFormat.format(cal.getTime()));
    }

    public static String getFutureDateForPaymentString(int period, String futureDateandTime) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateFormat.parse(futureDateandTime));
        cal.add(Calendar.DATE, period);
        return new SimpleDateFormat("MM/dd/yyyy").format(cal.getTime());
    }

    public static String getFutureDateString(int period, String format) {
        SimpleDateFormat inputFormat = new SimpleDateFormat(format);
        Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.DAY_OF_MONTH, period);
        String futureDate = inputFormat.format(currentDate.getTime());
        return futureDate;
    }

    public static String convertDateFormat(String date, String currentFormt, String newFormat) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(currentFormt);
        Date startDate = df.parse(date);
        return new SimpleDateFormat(newFormat).format(startDate);
    }
    
    /**
     * Get sql current date and time in specified format and timezone
     *
     * @param format Desired format for e.g. MM-DD-YYYY
     *
     * @param timeZone Desired TimeZone e.g America/Los_Angeles
     *
     * @return Current date in the format specified
     * @throws ParseException 
     */
    public static String getCurrentTimeInFormat(String format, String timeZone) throws ParseException {
    	
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		sdf1.setTimeZone(TimeZone.getTimeZone(timeZone));
		Date dateFromInstant = Date.from(Instant.now());
		return sdf1.format(dateFromInstant);
    }
}
