
package com.prosper.automation.exception;

import com.prosper.automation.model.test.TestThreadContext;
import com.prosper.automation.model.test.TestThreadContextEnum;
import org.apache.logging.log4j.ThreadContext;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class AutomationException extends Exception {

	public AutomationException(final String message) {
		super(String.format("[%s]", message));
	}

	public AutomationException(final String message, final Exception exception) {
		super(String.format("[%s] %s", message, exception));
	}
}
