package com.prosper.automation.model.platform.loan;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class PlatformLoanDueEffectiveDate {

	@JsonProperty("status")
	private String status;
	@JsonProperty("message")
	private String message;
	@JsonProperty("pay_off_amount")
	private BigDecimal payOffAmount;
	@JsonProperty("minimum_payment_due_amount")
	private BigDecimal minimumPaymentDueAmount;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public BigDecimal getPayOffAmount() {
		return payOffAmount;
	}

	public void setPayOffAmount(BigDecimal payOffAmount) {
		this.payOffAmount = payOffAmount;
	}

	public BigDecimal getMinimumPaymentDueAmount() {
		return minimumPaymentDueAmount;
	}

	public void setMinimumPaymentDueAmount(BigDecimal minimumPaymentDueAmount) {
		this.minimumPaymentDueAmount = minimumPaymentDueAmount;
	}

	private class loanDueResponseBuilder {
		private String status;
		private String message;
		private BigDecimal payOffAmount;
		private BigDecimal minimumPaymentDueAmount;

		public PlatformLoanDueEffectiveDate builder() {
			PlatformLoanDueEffectiveDate result = new PlatformLoanDueEffectiveDate();
			result.setMessage(message);
			result.setMinimumPaymentDueAmount(minimumPaymentDueAmount);
			result.setPayOffAmount(payOffAmount);
			result.setStatus(status);
			return result;
		}

		public loanDueResponseBuilder status(String status) {
			this.status = status;
			return this;
		}

		public loanDueResponseBuilder message(String message) {
			this.message = message;
			return this;
		}

		public loanDueResponseBuilder payOffAmount(BigDecimal payOffAmount) {
			this.payOffAmount = payOffAmount;
			return this;
		}

		public loanDueResponseBuilder minimumPaymentDueAmount(
				BigDecimal minimumPaymentDueAmount) {
			this.minimumPaymentDueAmount = minimumPaymentDueAmount;
			return this;
		}
	}
}
