
package com.prosper.automation.constant;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ErrorMessageConstant {
    
    public static final String BAD_OAUTH_USER_CREDENTIAL = ".*\"error\":\"invalid_grant\","
            + "\"error_description\":\"Bad credentials\".*";
    public static final String BAD_OAUTH_CLIENT_CREDENTIAL = ".*\"error\":\"invalid_client\","
            + "\"error_description\":\"Bad client credentials\".*";
    public static final String BAD_OAUTH_REFRESH_TOKEN = ".*\"error\":\"invalid_grant\","
            + "\"error_description\":\"Invalid refresh token: .*";
    
    public static final String USR001 = ".*\"code\":\"USR001\",\"message\":\"User already exists.\".*";
    public static final String USR002 = ".*\"code\":\"USR002\",\"message\":\"Missing mandatory field: .*";
    public static final String USR0004 = ".*\"code\":\"USR0004\",\"message\":\"Not a valid phone number\".*";
    public static final String USR0005 = ".*\"code\":\"USR0005\",\"message\":\"Not a valid zip code\".*";
    public static final String USR0006 = ".*\"code\":\"USR0006\",\"message\":\"Invalid email.\".*";
    public static final String USR0010 = ".*\"code\":\"USR0010\",\"message\":\"Not a valid ssn.\".*";
    public static final String USR0013 = ".*\"code\":\"USR0013\",\"message\":\"Manual identity verification "
            + "required.\".*";
    public static final String USR0026 = ".*\"code\":\"USR0026\",\"message\":\"Password does not meet requirements. 8 "
            + "characters minimum, must contain a number and a letter\".*";
    public static final String USR0038 = ".*\"code\":\"USR0038\",\"message\":\"This field only accepts alphabets, "
            + "spaces, dashes, and apostrophes.*";
    public static final String USR0039 = ".*\"code\":\"USR0039\",\"message\":\"Lender cannot be less than 18"
            + " years old.\".*";
    public static final String USR0042 = ".*\"code\":\"USR0042\",\"message\":\"Not a valid verification code.\".*";
    public static final String USR0100 = ".*\"code\":\"USR0100\",\"message\":\"User Id is required to be passed.\".*";
    public static final String USR2001 = ".*\"code\":\"USR2001\",\"message\":\"Invalid time passed\".*";
    public static final String AC_0003 = ".*\"code\":\"ACC-0003\",\"message\":\" invalid routing number\".*";
    public static final String ACC_0009 = ".*\"code\":\"ACC-0009\",\"message\":\" only values from 0-9 allowed for "
            + "routing_number & acount_number\".*";
    public static final String ACC_0006 = ".*\"code\":\"ACC-0006\",\"message\":\" please pass.*"
            + " , first_account_holder_name,bank_account_ownership_type, bank_account_type, routing_number \".*";
    public static final String ACC_0010 = ".*\"code\":\"ACC-0010\",\"message\":\" can only be 17 digits \".*";
    
    public static final String AP_1008 = ".*\"code\":\"AP1008\".*";
    
    public static final String EMAIL_NOT_VALIDATED = ".*\"error\":\"unactivated_account\",\"error_description\":\"The "
            + "email address has still not been validated\".*";
    public static final String OFF_0001 = ".*\"code\":\"OFF-0001\",\"message\":\"invalid or missing static pricing "
            + "values provided for pricing Version: 1.0.\".*";
    public static final String OFF_26 = ".*\"code\":\"OFF-26\",\"message\":\"LISTING_CATEGORY_ID_CANNOT_BE_NULL\".*";
    public static final String OFF_600 = ".*\"code\":\"OFF-600\",\"message\":\"CPS_NO_MATCH_FOUND\".*";
    public static final String OFF_30 = ".*\"code\":\"OFF-30\",\"message\":\"STATE_AND_LOAN_AMOUNT\".*";
    public static final String OFF_40 = ".*\"code\":\"OFF-40\",\"message\":\"ANNUAL_INCOMELESS_THAN_OR_EQUAL_ZERO\".*";
    
    public static final String LST_1001 = ".*\"code\":\"LST1001\",\"message\":\"Listing Id is invalid/ already "
            + "processed\".*";
    
    /** SLP Errors **/
    public static final String SLP_2002 =
            ".*\"code\":\"SLP2002\",\"message\":\"You don't have sufficient balance to accept this offer.\".*";
    public static final String SLP_2006 =
            ".*\"code\":\"SLP2006\",\"message\":\"Total Wire amount is different from actual amount.\".*";
    public static final String SLP_2003 =
            ".*\"code\":\"SLP2003\",\"message\":\"Total purchase amount is different from actual amount.\".*";
    public static final String SLP_2004 =
            ".*\"code\":\"SLP2004\",\"message\":\"Buyer fee is different from actual fee amount.\".*";
    public static final String SLP_2007 =
            ".*\"code\":\"SLP2007\",\"message\":\"Wrong offerId or unauthorise user for this offerId\".*";
    public static final String SLP_2008 = "\"code\":\"SLP008\",\"message\":\"This userId is already exist.\"";
    public static final String SLP_010 =
            ".*\"code\":\"SLP010\",\"message\":\"This user does not have any loan group or dedicated funding account.\".*";
    public static final String SLP_012 =
            ".*\"code\":\"SLP012\",\"message\":\"No investor associated with this investor Id.\".*";
    public static final String SLP_013 =
            ".*\"code\":\"SLP013\",\"message\":\"This Investor does not have a pass through funding account.\".*";
    public static final String SLP_2022 =
            ".*\"code\":\"SLP2022\",\"message\":\"Minimum or Maximum seasoning days must be an integer value.\".*";
    public static final String SYS_0000 =
            ".*\"code\":\"SYS0000\",\"message\":\"Minimum Daily allocation must be a numeric value.\".*";
    
    public static final String DAO0002 = ".*\"code\":\"DAO0002\",\"message\":\"Query Execution failed\".*";
    
    /** Platform Loans */
    public static final String PLATFORM_ACCOUNTS_INACTIVATED_ACCOUNT =
            ".*\"error\":\"unactivated_account\",\"error_description\":\"The email address has still not been validated\".*";
    
    public static final String APP_1007 = ".*\"code\":\"APP1007\",\"message\":\"New password not provided\".*";
    public static final String APP_1009 = ".*\"code\":\"APP1009\",\"message\":\"User not found\".*";
    public static final String LOC_002 = ".*\"code\":\"LOC_002\",\"message\":\"Bad ip address.\".*";

    public static final String APP1011 = ".*APP1011.*";
    public static final String SEC0005 = ".*\"code\":\"SEC0005\",\"message\":\"Unauthorized service\".*";
    public static final String OFF_20 = ".*\"code\":\"OFF-28\",\"message\":\"invalid score\"?.*";
    public static final String OFF_29 = ".*\"code\":\"OFF-29\",\"message\":\"failed to find cached offer\".*";
    public static final String OFF_0009 = ".*\"code\":\"OFF-0009\",\"message\":\"invalid .* id passed \".*";

    private ErrorMessageConstant() {
    }
}
