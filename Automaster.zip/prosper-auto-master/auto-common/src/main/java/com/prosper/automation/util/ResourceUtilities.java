
package com.prosper.automation.util;

import org.apache.log4j.Logger;

import java.io.File;

/**
 * @author pbudiono
 */
public final class ResourceUtilities {

    private static final Logger LOG = Logger.getLogger(ResourceUtilities.class.getSimpleName());


    private ResourceUtilities() {
    }

    public File getFile(final String filePath) {
        final ClassLoader classLoader = getClass().getClassLoader();
        return new File(classLoader.getResource(filePath).getFile());
    }
}
