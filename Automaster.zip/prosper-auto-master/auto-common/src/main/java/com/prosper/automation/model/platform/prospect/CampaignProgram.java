
package com.prosper.automation.model.platform.prospect;

import com.prosper.automation.constant.Constant;

/**
 * @author pbudiono
 */
public final class CampaignProgram {
    public String campaignProgramId;
    public String campaignId;
    public String name;
    public String refMc;
    public Integer rank;
    public Integer pricingId;
    public String description;
    public Integer legacyId;
    public String legacyChannel;
    public String fallBackProgramUsed;
    public int workFlowTypeId;
    public Boolean isABPEligible;


    private CampaignProgram(Builder builder) {
        campaignProgramId = builder.campaignProgramId;
        campaignId = builder.campaignId;
        name = builder.name;
        refMc = builder.refMc;
        rank = builder.rank;
        pricingId = builder.pricingId;
        description = builder.description;
        legacyId = builder.legacyId;
        legacyChannel = builder.legacyChannel;
        fallBackProgramUsed = builder.fallBackProgramUsed;
        workFlowTypeId = builder.workFlowTypeId;
        isABPEligible = builder.isABPEligible;
    }


    public final static String REF_MC_PREFIX = "eco_ref_mc";


    public static CampaignProgram createCampaignProgram(String campaignProgramId, String campaignId, int campaignProgramRank,
                                                        int campaignProgramPricingId, int campaignProgramLegacyId,
                                                        String campaignProgramLegacyChannel,
                                                        String fallBackProgramUsed, int workFlowTypeId, boolean isABPEligible) {
        final String campaignProgramName = String.format("eco_campaign_program_%s", Constant.getGloballyUniqueString());
        return createCampaignProgram(campaignProgramId, campaignId, campaignProgramRank, campaignProgramPricingId,
                campaignProgramLegacyId, campaignProgramLegacyChannel,
                fallBackProgramUsed, workFlowTypeId, isABPEligible,
                String.format(REF_MC_PREFIX + "_%s", Constant.getGloballyUniqueString()), campaignProgramName);
    }

    public static CampaignProgram createCampaignProgram(String campaignProgramId, String campaignId, int campaignProgramRank,
                                                        int campaignProgramPricingId, int campaignProgramLegacyId,
                                                        String campaignProgramLegacyChannel,
                                                        String fallBackProgramUsed, int workFlowTypeId, boolean isABPEligible,
                                                        String refMc, String campaignProgramName) {
        return new Builder().withCampaignProgramId(campaignProgramId).withCampaignId(campaignId)
                .withName(String.format(campaignProgramName))
                .withRefMc(refMc).withRank(campaignProgramRank)
                .withPricingId(campaignProgramPricingId).withDescription(campaignProgramName)
                .withLegacyId(campaignProgramLegacyId).withLegacyChannel(campaignProgramLegacyChannel)
                .withFallBackProgramUsed(fallBackProgramUsed).withWorkFlowTypeId(workFlowTypeId).withIsABPEligible(isABPEligible)
                .build();
    }

    public String getCampaignProgramId() {
        return campaignProgramId;
    }

    public String getName() {
        return name;
    }

    public String getRefMc() {
        return refMc;
    }

    public Integer getRank() {
        return rank;
    }

    public Integer getPricingId() {
        return pricingId;
    }

    public String getDescription() {
        return description;
    }

    public Integer getLegacyId() {
        return legacyId;
    }

    public String getLegacyChannel() {
        return legacyChannel;
    }

    public String getFallBackProgramUsed() {
        return fallBackProgramUsed;
    }

    public int getWorkFlowTypeId() {
        return workFlowTypeId;
    }

    public Boolean getIsABPEligible() {
        return isABPEligible;
    }

    public String getCampaignId() {
        return campaignId;
    }


    public static final class Builder {

        private String campaignProgramId;
        private String campaignId;
        private String name;
        private String refMc;
        private Integer rank;
        private Integer pricingId;
        private String description;
        private Integer legacyId;
        private String legacyChannel;
        private String fallBackProgramUsed;
        private int workFlowTypeId;
        private Boolean isABPEligible;


        public Builder() {
        }

        public Builder withCampaignProgramId(String val) {
            campaignProgramId = val;
            return this;
        }

        public Builder withCampaignId(String val) {
            campaignId = val;
            return this;
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withRefMc(String val) {
            refMc = val;
            return this;
        }

        public Builder withRank(Integer val) {
            rank = val;
            return this;
        }

        public Builder withPricingId(Integer val) {
            pricingId = val;
            return this;
        }

        public Builder withDescription(String val) {
            description = val;
            return this;
        }

        public Builder withLegacyId(Integer val) {
            legacyId = val;
            return this;
        }

        public Builder withLegacyChannel(String val) {
            legacyChannel = val;
            return this;
        }

        public Builder withFallBackProgramUsed(String val) {
            fallBackProgramUsed = val;
            return this;
        }

        public Builder withWorkFlowTypeId(int val) {
            workFlowTypeId = val;
            return this;
        }

        public Builder withIsABPEligible(Boolean val) {
            isABPEligible = val;
            return this;
        }

        public CampaignProgram build() {
            return new CampaignProgram(this);
        }
    }
}
