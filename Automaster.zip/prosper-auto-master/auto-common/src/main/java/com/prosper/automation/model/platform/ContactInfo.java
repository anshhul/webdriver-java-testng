
package com.prosper.automation.model.platform;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Objects;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"phone_numbers", "email"})
public final class ContactInfo {
    
    @JsonProperty("phone_numbers")
    private List<PhoneNumber> phoneNumbers;
    @JsonProperty("email")
    private String email;
    
    
    public ContactInfo() {
    }
    
    public ContactInfo(final String email) {
        this.email = email;
    }
    
    private ContactInfo(final Builder builder) {
        phoneNumbers = builder.phoneNumbers;
        email = builder.email;
    }
    
    /**
     * @return The email
     */
    public String getEmail() {
        return email;
    }
    
    public void setEmail(final String email) {
        this.email = email;
    }
    
    public void setPhoneNumber(final List<PhoneNumber> phoneNumber) {
        this.phoneNumbers = phoneNumber;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ContactInfo that = (ContactInfo) o;
        return Objects.equal(phoneNumbers, that.phoneNumbers) && Objects.equal(email, that.email);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(phoneNumbers, email);
    }

    @Override public String toString() {
        return "ContactInfo{" +
                "phoneNumbers=" + phoneNumbers!= null? phoneNumbers.toString(): "" +
                ", email='" + email + '\'' +
                '}';
    }

    @JsonIgnore
    public List<PhoneNumber> getPhoneNumbers() {
        return phoneNumbers;
    }
    
    
    public static final class Builder {
        
        private List<PhoneNumber> phoneNumbers;
        private String email;
        
        
        public Builder() {
        }
        
        public Builder withPhoneNumbers(final List<PhoneNumber> phoneNumbers) {
            this.phoneNumbers = phoneNumbers;
            return this;
        }
        
        public Builder withEmail(final String email) {
            this.email = email;
            return this;
        }
        
        public ContactInfo build() {
            return new ContactInfo(this);
        }
    }
}
