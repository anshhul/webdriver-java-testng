
package com.prosper.automation.enumeration.platform;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum UserRole {
    
    NONE(0, "None"), REGISTERED(1, "Registered"), BORROWER(2, "Borrower"), LENDER(4, "Lender"), GROUP_LEADER(8, "Group Leader"),
    DEBT_BUYER(16, "Debt Buyer"), INSTITUTIONAL_LENDER(32, "Institutional Lender"), PAYPAL_LENDER(64, "PayPal Lender"), TRADER(
            256, "Trader"), THIRD_PARTY_BORROWER(512, "Third Party Borrower"), IRA_LENDER(1024, "IRA Lender"), PREMIER_LENDER(
            2048, "Premier Lender");
    
    private final Integer id;
    private final String role;
    
    
    UserRole(final Integer id, final String role) {
        this.id = id;
        this.role = role;
    }
    
    public int getId() {
        return id;
    }
    
    public String getIdInString() {
        return String.valueOf(id);
    }
}
