
package com.prosper.automation.constant;

import com.prosper.automation.model.platform.slp.LoanDetailFilter;
import com.prosper.automation.model.platform.slp.SlpAllocationAlgoReq;
import com.prosper.automation.model.platform.slp.SlpInvestorConfiguration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class PlatformSlpOffersConstant {
    
    public static final String TESTUSER = "user3185394@prosper.stg";
    public static final String VALID_USER1_WITH500KBALANNCE = "automation_8J0q4@c1.stg";
    public static final String BLACKROCK_INVESTOR = "user2093353@prosper.stg";
    
    public static final String PAYPLANT_INVESTOR = "user1944517@prosper.stg";
    public static final String COLCHIS_INVESTOR = "user2263183@prosper.stg";
    public static final String PAH_INVESTOR = "user2087744@prosper.stg";
    
    public static Long BLACKROCT_INVESTOR_ID = (long) 13;
    
    public static final String START_DATE1 = "2010-10-01";
    public static final String END_DATE1 = "2015-06-16";

    public static final String OFFER_ID_1 = "B15C13BF-D10B-4317-92ED-238887A5083C";
    
    /**
     * New Investor Details
     */
    public static final String INVESTOR_STATUS_ACTIVE = "ACTIVE";
    public static final String INVESTOR_STATUS_INACTIVE = "INACTIVE";
    public static Double SLP_INVESTOR_MONTHLY_INVESTMENT_TARGET_ONE_MILLION = 1000000.00;
    public static Double SLP_INVESTOR_MONTHLY_INVESTMENT_TARGET_TWO_MILLION = 2000000.00;
    public static Double SLP_INVESTOR_FEE_PERCENTAGE_POINT_FIVE = 0.5;
    public static Long COLCHIS_USERID = 2263183L;
    public static Long POST_SEC = 1L;
    public static SlpInvestorConfiguration COLCHIS_USER_REQ = SlpInvestorConfiguration.newBuilder()
                                                                                      .feePercenatge(PlatformSlpOffersConstant.SLP_INVESTOR_FEE_PERCENTAGE_POINT_FIVE)
                                                                                      .investorStatus(PlatformSlpOffersConstant.INVESTOR_STATUS_ACTIVE)
                                                                                      .monthlyInvestmentTarget(PlatformSlpOffersConstant.SLP_INVESTOR_MONTHLY_INVESTMENT_TARGET_ONE_MILLION)
                                                                                      .userId(COLCHIS_USERID).build();
    /**
     * SLP Allocation Config Params
     */
    public static String MIN_SEASONING_DAYS = "MIN_SEASONING_DAYS";
    public static String MIN_DAILY_ALLOCATION = "MIN_DAILY_ALLOCATION";
    public static String MAX_SEASONING_DAYS = "MAX_SEASONING_DAYS";

    public static final String MINIMUM_DAILY_INVESTMENT = "150000.00";
    public static final String MINIMUM_DAILY_INVESTMENT_PAYPLANT = "500.00";
    public static final String MINIMUM_DAILY_INVESTMENT_FOR_BLACKROCK = "500.00";
    public static final String MINIMUM_DAILY_INVESTMENT_FOR_COLCHIS = "500.00";
    public static final Integer MIN_SEASONING_DAYS_REQ_PARAMETER = 1;
    public static final String MAX_SEASONING_PERIOD_FOR_BLACKROCK = "120";
    public static final String MAX_SEASONING_PERIOD_FOR_COLCHIS = "100";
    public static final String MAX_SEASONING_PERIOD = "5000";
    
    public static final String SPV_SELLER_ID = "2087744";
    public static final String SPV_SELLER_ID_COLCHIS = "2263183";

    public static final Double REDUCED_WIRE_AMOUNT = 100.00;
    public static final Double MORE_WIRE_AMOUNT = 999999999.99;
    public static final List<String> SPV_ACCOUNT_ID = new ArrayList<String>(Arrays.asList(SPV_SELLER_ID));
    public static final List<String> SPV_ACCOUNT_ID_COLCHIS = new ArrayList<String>(
            Arrays.asList(SPV_SELLER_ID_COLCHIS));

    /**
     * Loan detail filters
     */
    public static final LoanDetailFilter LOAN_DETAIL_FILTER = new LoanDetailFilter().newBuilder()
            .minSeasoningDays(MIN_SEASONING_DAYS_REQ_PARAMETER).maxSeasoningPeriod(MAX_SEASONING_PERIOD)
            .spvAccountIds(SPV_ACCOUNT_ID).build();
    public static final LoanDetailFilter LOAN_DETAIL_FILTER_FOR_BLACKROCK = new LoanDetailFilter().newBuilder()
            .minSeasoningDays(MIN_SEASONING_DAYS_REQ_PARAMETER).maxSeasoningPeriod(MAX_SEASONING_PERIOD_FOR_BLACKROCK)
            .spvAccountIds(SPV_ACCOUNT_ID).build();
    public static final LoanDetailFilter LOAN_DETAIL_FILTER_FOR_PAYPLANT = new LoanDetailFilter().newBuilder()
            .minSeasoningDays(MIN_SEASONING_DAYS_REQ_PARAMETER).maxSeasoningPeriod(MAX_SEASONING_PERIOD_FOR_BLACKROCK)
            .spvAccountIds(SPV_ACCOUNT_ID).build();

    public static final LoanDetailFilter LOAN_DETAIL_FILTER_FOR_COLCHIS_AS_SPV = new LoanDetailFilter().newBuilder()
            .minSeasoningDays(MIN_SEASONING_DAYS_REQ_PARAMETER).maxSeasoningPeriod(MAX_SEASONING_PERIOD_FOR_COLCHIS)
            .spvAccountIds(SPV_ACCOUNT_ID_COLCHIS).build();
    
    /**
     * Allocation Req
     */
    public static final SlpAllocationAlgoReq ALLOCATION_REQ_DEFAULT = new SlpAllocationAlgoReq().newBuilder()
                                                                                                .minimumDailyInvestmentAmount(MINIMUM_DAILY_INVESTMENT).loanDetailFilter(LOAN_DETAIL_FILTER).build();
    
    public static final SlpAllocationAlgoReq ALLOCATION_REQ_PAYPLANT = new SlpAllocationAlgoReq().newBuilder()
            .minimumDailyInvestmentAmount(MINIMUM_DAILY_INVESTMENT_PAYPLANT)
            .loanDetailFilter(LOAN_DETAIL_FILTER_FOR_PAYPLANT).dryRun(true)
            .testInvestorIds(new ArrayList<Long>(Arrays.asList(1944517L))).build();

    public static final SlpAllocationAlgoReq ALLOCATION_REQ_DEFAULT_FOR_BLACKROCK = new SlpAllocationAlgoReq()
    .newBuilder().minimumDailyInvestmentAmount(MINIMUM_DAILY_INVESTMENT_FOR_BLACKROCK)
    .loanDetailFilter(LOAN_DETAIL_FILTER_FOR_BLACKROCK).build();
    
    public static final SlpAllocationAlgoReq ALLOCATION_REQ_DEFAULT_FOR_COLCHIS = new SlpAllocationAlgoReq()
    .newBuilder().minimumDailyInvestmentAmount(MINIMUM_DAILY_INVESTMENT_FOR_COLCHIS)
    .loanDetailFilter(LOAN_DETAIL_FILTER_FOR_COLCHIS_AS_SPV).build();

    public static List<Long> TEST_INVESTOR_IDS = new ArrayList<Long>(Arrays.asList(BLACKROCT_INVESTOR_ID));

    public static final SlpAllocationAlgoReq ALLOCATION_REQ_DEFAULT_FOR_BLACKROCK_PRODTESTTOOL =
            new SlpAllocationAlgoReq().newBuilder()
            .minimumDailyInvestmentAmount(MINIMUM_DAILY_INVESTMENT_FOR_BLACKROCK)
            .loanDetailFilter(LOAN_DETAIL_FILTER_FOR_BLACKROCK).dryRun(true).testInvestorIds(TEST_INVESTOR_IDS)
            .build();

}
