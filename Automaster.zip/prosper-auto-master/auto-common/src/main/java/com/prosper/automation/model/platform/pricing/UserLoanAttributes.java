
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class UserLoanAttributes {

    @JsonProperty("priorLoanMaxDPDLast12")
    private String priorLoanMaxDPDLast12;
    @JsonProperty("priorLoanMaxDPDLast18")
    private String priorLoanMaxDPDLast18;
    @JsonProperty("priorLoanMaxDPDLast6")
    private String priorLoanMaxDPDLast6;
    @JsonProperty("priorNReturnedPaymentsLast12")
    private String priorNReturnedPaymentsLast12;
    @JsonProperty("priorNReturnedPaymentsLast18")
    private String priorNReturnedPaymentsLast18;
    @JsonProperty("priorNReturnedPaymentsLast36")
    private String priorNReturnedPaymentsLast36;
    @JsonProperty("priorPctPrincRemCurrLoan")
    private String priorPctPrincRemCurrLoan;
    @JsonProperty("priorLoanNumber")
    private Integer priorLoanNumber;
    @JsonProperty("active_loan_count")
    private Integer activeLoanCount;
    @JsonProperty("is_prior_borrower")
    private Boolean isPriorBorrower;
    @JsonProperty("current_principal_balance")
    private Double currentPrincipalBalance;
    @JsonProperty("original_amount_borrowed")
    private Double originalAmountBorrowed;
    @JsonProperty("number_returned_payments_ever")
    private Integer numberReturnedPaymentsEver;
    @JsonProperty("16_dpd_last_12_months")
    private Integer dpd16Last12Months;
    @JsonProperty("latest_loan_origination_date_time")
    private String latestLoanOriginationDateTime;
    @JsonProperty("latest_credit_score")
    private Integer latestCreditScore;
    @JsonProperty("31_dpd_last_9_months")
    private Integer dpd31Last9Months;
    @JsonProperty("31_dpd_last_6_months")
    private Integer dpd31Last6Months;
    @JsonProperty("is_borrower_currently_delinquent")
    private Boolean isBorrowerCurrentlyDelinquent;
    @JsonProperty("max_delq_with_prosper_last_60_days")
    private Integer maxDelqWithProsperLast60Days;
    @JsonProperty("is_borrower_prior_charge_off")
    private Boolean isBorrowerPriorChargeOff;
    @JsonProperty("is_prime_recently_declined")
    private Boolean isPrimeRecentlyDeclined;
    @JsonProperty("is_near_prime_recently_declined")
    private Boolean isNearPrimeRecentlyDeclined;
    @JsonProperty("is_recently_declined_prebureau")
    private Boolean isRecentlyDeclinedPrebureau;
    @JsonProperty("is_seen_last_30days")
    private Boolean isSeenLast30days;

    public UserLoanAttributes() {
    }

    private UserLoanAttributes(final Builder builder) {
        priorLoanMaxDPDLast12 = builder.priorLoanMaxDPDLast12;
        priorLoanMaxDPDLast18 = builder.priorLoanMaxDPDLast18;
        priorLoanMaxDPDLast6 = builder.priorLoanMaxDPDLast6;
        priorNReturnedPaymentsLast12 = builder.priorNReturnedPaymentsLast12;
        priorNReturnedPaymentsLast18 = builder.priorNReturnedPaymentsLast18;
        priorNReturnedPaymentsLast36 = builder.priorNReturnedPaymentsLast36;
        priorPctPrincRemCurrLoan = builder.priorPctPrincRemCurrLoan;
        priorLoanNumber = builder.priorLoanNumber;
        activeLoanCount = builder.activeLoanCount;
        isPriorBorrower = builder.isPriorBorrower;
        currentPrincipalBalance = builder.currentPrincipalBalance;
        originalAmountBorrowed = builder.originalAmountBorrowed;
        numberReturnedPaymentsEver = builder.numberReturnedPaymentsEver;
        dpd16Last12Months = builder.dpd16Last12Months;
        latestLoanOriginationDateTime = builder.latestLoanOriginationDateTime;
        latestCreditScore = builder.latestCreditScore;
        dpd31Last9Months = builder.dpd31Last9Months;
        dpd31Last6Months = builder.dpd31Last6Months;
        isBorrowerCurrentlyDelinquent = builder.isBorrowerCurrentlyDelinquent;
        maxDelqWithProsperLast60Days = builder.maxDelqWithProsperLast60Days;
        isBorrowerPriorChargeOff = builder.isBorrowerPriorChargeOff;
        isPrimeRecentlyDeclined = builder.isPrimeRecentlyDeclined;
        isNearPrimeRecentlyDeclined = builder.isNearPrimeRecentlyDeclined;
        isRecentlyDeclinedPrebureau = builder.isRecentlyDeclinedPrebureau;
        isSeenLast30days = builder.isSeenLast30days;
    }


    public static final class Builder {

        private String priorLoanMaxDPDLast12;
        private String priorLoanMaxDPDLast18;
        private String priorLoanMaxDPDLast6;
        private String priorNReturnedPaymentsLast12;
        private String priorNReturnedPaymentsLast18;
        private String priorNReturnedPaymentsLast36;
        private String priorPctPrincRemCurrLoan;
        private Integer priorLoanNumber;
        private Integer activeLoanCount;
        private Boolean isPriorBorrower;
        private Double currentPrincipalBalance;
        private Double originalAmountBorrowed;
        private Integer numberReturnedPaymentsEver;
        private Integer dpd16Last12Months;
        private String latestLoanOriginationDateTime;
        private Integer latestCreditScore;
        private Integer dpd31Last9Months;
        private Integer dpd31Last6Months;
        private Boolean isBorrowerCurrentlyDelinquent;
        private Integer maxDelqWithProsperLast60Days;
        private Boolean isBorrowerPriorChargeOff;
        private Boolean isPrimeRecentlyDeclined;
        private Boolean isNearPrimeRecentlyDeclined;
        private Boolean isRecentlyDeclinedPrebureau;
        private Boolean isSeenLast30days;


        public Builder() {
        }

        public Builder withPriorLoanMaxDPDLast12(final String priorLoanMaxDPDLast12) {
            this.priorLoanMaxDPDLast12 = priorLoanMaxDPDLast12;
            return this;
        }

        public Builder withPriorLoanMaxDPDLast18(final String priorLoanMaxDPDLast18) {
            this.priorLoanMaxDPDLast18 = priorLoanMaxDPDLast18;
            return this;
        }

        public Builder withPriorLoanMaxDPDLast6(final String priorLoanMaxDPDLast6) {
            this.priorLoanMaxDPDLast6 = priorLoanMaxDPDLast6;
            return this;
        }

        public Builder withPriorNReturnedPaymentsLast12(final String priorNReturnedPaymentsLast12) {
            this.priorNReturnedPaymentsLast12 = priorNReturnedPaymentsLast12;
            return this;
        }

        public Builder withPriorNReturnedPaymentsLast18(final String priorNReturnedPaymentsLast18) {
            this.priorNReturnedPaymentsLast18 = priorNReturnedPaymentsLast18;
            return this;
        }

        public Builder withPriorNReturnedPaymentsLast36(final String priorNReturnedPaymentsLast36) {
            this.priorNReturnedPaymentsLast36 = priorNReturnedPaymentsLast36;
            return this;
        }

        public Builder withPriorPctPrincRemCurrLoan(final String priorPctPrincRemCurrLoan) {
            this.priorPctPrincRemCurrLoan = priorPctPrincRemCurrLoan;
            return this;
        }

        public Builder withPriorLoanNumber(final Integer priorLoanNumber) {
            this.priorLoanNumber = priorLoanNumber;
            return this;
        }

        public Builder withActiveLoanCount(final Integer activeLoanCount) {
            this.activeLoanCount = activeLoanCount;
            return this;
        }

        public Builder withIsPriorBorrower(final Boolean isPriorBorrower) {
            this.isPriorBorrower = isPriorBorrower;
            return this;
        }

        public Builder withCurrentPrincipalBalance(final Double currentPrincipalBalance) {
            this.currentPrincipalBalance = currentPrincipalBalance;
            return this;
        }

        public Builder withOriginalAmountBorrowed(final Double originalAmountBorrowed) {
            this.originalAmountBorrowed = originalAmountBorrowed;
            return this;
        }

        public Builder withNumberReturnedPaymentsEver(final Integer numberReturnedPaymentsEver) {
            this.numberReturnedPaymentsEver = numberReturnedPaymentsEver;
            return this;
        }

        public Builder with16DpdLast12Months(final Integer dpd16Last12Months) {
            this.dpd16Last12Months = dpd16Last12Months;
            return this;
        }

        public Builder withLatestLoanOriginationDateTime(final String latestLoanOriginationDateTime) {
            this.latestLoanOriginationDateTime = latestLoanOriginationDateTime;
            return this;
        }

        public Builder withLatestCreditScore(final Integer latestCreditScore) {
            this.latestCreditScore = latestCreditScore;
            return this;
        }

        public Builder with31DpdLast9Months(final Integer dpd31Last9Months) {
            this.dpd31Last9Months = dpd31Last9Months;
            return this;
        }

        public Builder with31DpdLast6Months(final Integer dpd31Last6Months) {
            this.dpd31Last6Months = dpd31Last6Months;
            return this;
        }

        public Builder withIsBorrowerCurrentlyDelinquent(final Boolean isBorrowerCurrentlyDelinquent) {
            this.isBorrowerCurrentlyDelinquent = isBorrowerCurrentlyDelinquent;
            return this;
        }

        public Builder withMaxDelqWithProsperLast60Days(final Integer maxDelqWithProsperLast60Days) {
            this.maxDelqWithProsperLast60Days = maxDelqWithProsperLast60Days;
            return this;
        }

        public Builder withIsBorrowerPriorChargeOff(final Boolean isBorrowerPriorChargeOff) {
            this.isBorrowerPriorChargeOff = isBorrowerPriorChargeOff;
            return this;
        }

        public Builder withIsPrimeRecentlyDeclined(final Boolean isPrimeRecentlyDeclined) {
            this.isPrimeRecentlyDeclined = isPrimeRecentlyDeclined;
            return this;
        }

        public Builder withIsNearPrimeRecentlyDeclined(final Boolean isNearPrimeRecentlyDeclined) {
            this.isNearPrimeRecentlyDeclined = isNearPrimeRecentlyDeclined;
            return this;
        }

        public Builder withIsRecentlyDeclinedPrebureau(final Boolean isRecentlyDeclinedPrebureau) {
            this.isRecentlyDeclinedPrebureau = isRecentlyDeclinedPrebureau;
            return this;
        }

        public Builder withIsSeenLast30days(final Boolean isSeenLast30days) {
            this.isSeenLast30days = isSeenLast30days;
            return this;
        }

        public UserLoanAttributes build() {
            return new UserLoanAttributes(this);
        }
    }
}
