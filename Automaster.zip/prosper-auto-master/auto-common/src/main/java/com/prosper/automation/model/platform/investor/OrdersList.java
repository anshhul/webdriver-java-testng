package com.prosper.automation.model.platform.investor;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class OrdersList {

    private String orderID;
    private String createdDate;
    private OrderSource orderSource;
    private int orderNumber;
    private SubmittedOrderDetails submittedOrder;
    private PendingOrderDetails pendingOrder;
    private ExpiredOrderDetails expiredOrder;
    private InvestorOrderDetails investorOrder;

    @JsonProperty("created_date")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("expired_order")
    public ExpiredOrderDetails getExpiredOrder() {
        return expiredOrder;
    }

    @JsonProperty("invested_order")
    public InvestorOrderDetails getInvestorOrder() {
        return investorOrder;
    }

    @JsonProperty("order_id")
    public String getOrderID() {
        return orderID;
    }

    @JsonProperty("order_number")
    public int getOrderNumber() {
        return orderNumber;
    }

    @JsonProperty("order_source")
    public OrderSource getOrderSource() {
        return orderSource;
    }

    @JsonProperty("pending_order")
    public PendingOrderDetails getPendingOrder() {
        return pendingOrder;
    }

    @JsonProperty("submitted_order")
    public SubmittedOrderDetails getSubmittedOrder() {
        return submittedOrder;
    }

    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }

    public void setExpiredOrder(final ExpiredOrderDetails expiredOrder) {
        this.expiredOrder = expiredOrder;
    }

    public void setInvestorOrder(final InvestorOrderDetails investorOrder) {
        this.investorOrder = investorOrder;
    }

    public void setOrderID(final String orderID) {
        this.orderID = orderID;
    }

    public void setOrderNumber(final int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setOrderSource(final OrderSource orderSource) {
        this.orderSource = orderSource;
    }

    public void setPendingOrder(final PendingOrderDetails pendingOrder) {
        this.pendingOrder = pendingOrder;
    }

    public void setSubmittedOrder(final SubmittedOrderDetails submittedOrder) {
        this.submittedOrder = submittedOrder;
    }

}
