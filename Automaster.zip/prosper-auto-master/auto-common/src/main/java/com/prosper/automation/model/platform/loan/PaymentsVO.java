package com.prosper.automation.model.platform.loan;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */
public final class PaymentsVO {

	@JsonProperty("payment_transaction_id")
	private Long paymentTransactionId;

	@JsonProperty("payment_source")
	private String paymentSource;

    @JsonProperty("status")
    private String status;

	@JsonProperty("payment_effective_date")
	private Date paymentEffectiveDate;

	@JsonProperty("days_past_due")
	private int daysPastDue;

	@JsonProperty("transaction_code")
	private String transactionCode;

	@JsonProperty("payment_type")
	private String paymentType;

	@JsonProperty("loan_group")
	private String loanGroup;

	@JsonProperty("total_paid")
	private BigDecimal totalPaid;

	@JsonProperty("principal")
	private BigDecimal principal;

	@JsonProperty("interest")
	private BigDecimal interest;

	@JsonProperty("nsf_fee")
	private BigDecimal nsfFee;

	@JsonProperty("late_fee")
	private BigDecimal lateFee;

	@JsonProperty("over_payment")
	private BigDecimal overPayment;

	@JsonProperty("service_fee")
	private BigDecimal serviceFee;

	@JsonProperty("prosper_collection_fee")
	private BigDecimal prosperCollectionFee;

	@JsonProperty("investor_collection_fee")
	private BigDecimal investorCollectionFee;

	@JsonProperty("principal_balance")
	private BigDecimal principalBalance;

	@JsonProperty("reversal_indicator")
	private String reversalIndicator;

	@JsonProperty("financial_account_number")
	private String financialAccountNumber;

	public Long getPaymentTransactionId() {
		return paymentTransactionId;
	}

	public void setPaymentTransactionId(Long paymentTransactionId) {
		this.paymentTransactionId = paymentTransactionId;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

    public String getStatus() {
        return status;
    }

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

    public void setStatus(String status) {
        this.status = status;
    }

	public Date getPaymentEffectiveDate() {
		return paymentEffectiveDate;
	}

	public void setPaymentEffectiveDate(Date paymentEffectiveDate) {
		this.paymentEffectiveDate = paymentEffectiveDate;
	}

	public int getDaysPastDue() {
		return daysPastDue;
	}

	public void setDaysPastDue(int daysPastDue) {
		this.daysPastDue = daysPastDue;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getLoanGroup() {
		return loanGroup;
	}

	public void setLoanGroup(String loanGroup) {
		this.loanGroup = loanGroup;
	}

	public BigDecimal getTotalPaid() {
		return totalPaid;
	}

	public void setTotalPaid(BigDecimal totalPaid) {
		this.totalPaid = totalPaid;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}

	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getNsfFee() {
		return nsfFee;
	}

	public void setNsfFee(BigDecimal nsfFee) {
		this.nsfFee = nsfFee;
	}

	public BigDecimal getLateFee() {
		return lateFee;
	}

	public void setLateFee(BigDecimal lateFee) {
		this.lateFee = lateFee;
	}

	public BigDecimal getOverPayment() {
		return overPayment;
	}

	public void setOverPayment(BigDecimal overPayment) {
		this.overPayment = overPayment;
	}

	public BigDecimal getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}

	public BigDecimal getProsperCollectionFee() {
		return prosperCollectionFee;
	}

	public void setProsperCollectionFee(BigDecimal prosperCollectionFee) {
		this.prosperCollectionFee = prosperCollectionFee;
	}

	public BigDecimal getInvestorCollectionFee() {
		return investorCollectionFee;
	}

	public void setInvestorCollectionFee(BigDecimal investorCollectionFee) {
		this.investorCollectionFee = investorCollectionFee;
	}

	public BigDecimal getPrincipalBalance() {
		return principalBalance;
	}

	public void setPrincipalBalance(BigDecimal principalBalance) {
		this.principalBalance = principalBalance;
	}

	public String getReversalIndicator() {
		return reversalIndicator;
	}

	public void setReversalIndicator(String reversalIndicator) {
		this.reversalIndicator = reversalIndicator;
	}

	public String getFinancialAccountNumber() {
		return financialAccountNumber;
	}

	public void setFinancialAccountNumber(String financialAccountNumber) {
		this.financialAccountNumber = financialAccountNumber;
	}

	public static class PaymentsVOBuilder {
		private String paymentSource;
		private String status;
		private Date paymentEffectiveDate;
		private int daysPastDue;
		private String transactionCode;
		private String paymentType;
		private String loanGroup;
		private BigDecimal totalPaid;
		private BigDecimal principal;
		private BigDecimal interest;
		private BigDecimal nsfFee;
		private BigDecimal lateFee;
		private BigDecimal overPayment;
		private BigDecimal serviceFee;
		private BigDecimal prosperCollectionFee;
		private BigDecimal investorCollectionFee;
		private BigDecimal principalBalance;
		private String reversalIndicator;
		private String financialAccountNumber;

		public PaymentsVO build() {
			final PaymentsVO result = new PaymentsVO();
			result.setPaymentSource(paymentSource);
            result.setStatus(status);
			result.setPaymentEffectiveDate(paymentEffectiveDate);
			result.setDaysPastDue(daysPastDue);
			result.setTransactionCode(transactionCode);
			result.setPaymentType(paymentType);
			result.setLoanGroup(loanGroup);
			result.setTotalPaid(totalPaid);
			result.setPrincipal(principal);
			result.setInterest(interest);
			result.setNsfFee(nsfFee);
			result.setLateFee(lateFee);
			result.setOverPayment(overPayment);
			result.setServiceFee(serviceFee);
			result.setProsperCollectionFee(prosperCollectionFee);
			result.setInvestorCollectionFee(investorCollectionFee);
			result.setPrincipalBalance(principalBalance);
			result.setReversalIndicator(reversalIndicator);
			result.setFinancialAccountNumber(financialAccountNumber);
			return result;

		}

		public PaymentsVOBuilder paymentTransactionId(Long paymentTransactionId) {
			return this;
		}

		public PaymentsVOBuilder paymentSource(String paymentSource) {
			this.paymentSource = paymentSource;
			return this;
		}

        public PaymentsVOBuilder paymentStatus(String status) {
            this.status = status;
            return this;
        }

		public PaymentsVOBuilder paymentEffectiveDate(Date paymentEffectiveDate) {
			this.paymentEffectiveDate = paymentEffectiveDate;
			return this;
		}

		public PaymentsVOBuilder daysPastDue(int daysPastDue) {
			this.daysPastDue = daysPastDue;
			return this;
		}

		public PaymentsVOBuilder transactionCode(String transactionCode) {
			this.transactionCode = transactionCode;
			return this;
		}

		public PaymentsVOBuilder paymentType(String paymentType) {
			this.paymentType = paymentType;
			return this;
		}

		public PaymentsVOBuilder loanGroup(String loanGroup) {
			this.loanGroup = loanGroup;
			return this;
		}

		public PaymentsVOBuilder totalPaid(BigDecimal totalPaid) {
			this.totalPaid = totalPaid;
			return this;
		}

		public PaymentsVOBuilder principal(BigDecimal principal) {
			this.principal = principal;
			return this;
		}

		public PaymentsVOBuilder interest(BigDecimal interest) {
			this.interest = interest;
			return this;
		}

		public PaymentsVOBuilder nsfFee(BigDecimal nsfFee) {
			this.nsfFee = nsfFee;
			return this;
		}

		public PaymentsVOBuilder lateFee(BigDecimal lateFee) {
			this.lateFee = lateFee;
			return this;
		}

		public PaymentsVOBuilder overPayment(BigDecimal overPayment) {
			this.overPayment = overPayment;
			return this;
		}

		public PaymentsVOBuilder serviceFee(BigDecimal serviceFee) {
			this.serviceFee = serviceFee;
			return this;
		}

		public PaymentsVOBuilder prosperCollectionFee(
				BigDecimal prosperCollectionFee) {
			this.prosperCollectionFee = prosperCollectionFee;
			return this;
		}

		public PaymentsVOBuilder investorCollectionFee(
				BigDecimal investorCollectionFee) {
			this.investorCollectionFee = investorCollectionFee;
			return this;
		}

		public PaymentsVOBuilder principalBalance(BigDecimal principalBalance) {
			this.principalBalance = principalBalance;
			return this;
		}

		public PaymentsVOBuilder reversalIndicator(String reversalIndicator) {
			this.reversalIndicator = reversalIndicator;
			return this;
		}

		public PaymentsVOBuilder financialAccountNumber(
				String financialAccountNumber) {
			this.financialAccountNumber = financialAccountNumber;
			return this;
		}
	}

}
