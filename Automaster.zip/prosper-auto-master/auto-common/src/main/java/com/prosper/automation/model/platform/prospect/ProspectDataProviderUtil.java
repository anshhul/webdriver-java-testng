
package com.prosper.automation.model.platform.prospect;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.StatesSupported;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;

import java.util.Map;

/**
 * Created by rsubramanyam on 6/30/16.
 */
public final class ProspectDataProviderUtil {

    protected static final String GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID = "1";
    protected static final Double GENERIC_PROSPECT_ANNUAL_INCOME = 150000.0;
    protected static final String GENERIC_PROSPECT_CREDIT_SCORE = "650";

    public static ProspectRequest buildGenericProspectRequestWithAllFields(final String refAC, final String refMC,
                                                                           final String email) throws AutomationException {
        return buildGenericProspectRequestWithAllFields(refAC, refMC, email, GENERIC_PROSPECT_ANNUAL_INCOME);
    }

    public static ProspectRequest buildGenericProspectRequestWithAllFields(final String refAC, final String refMC,
                                                                           final String email, final Double income)
            throws AutomationException {
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withAnnualIncome(income)
                .build();

        final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME)
                .withLastName(Constant.TEST_LAST_NAME).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();

        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();

        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                        .withCity(AddressInfoConstant.TEST_CITY).withAddress(AddressInfoConstant.TEST_ADDRESS_1)
                        .withAddressType(String.valueOf(AddressInfoConstant.ADDRESS_TYPE_ID))
                        .withState(AddressInfoConstant.TEST_STATE_GA).withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC).withProspect(prospect).build();
    }

    public static ProspectRequest buildGenericProspectRequestWithThirdPartyId(final String refAC, final String refMC,
                                                                          final String email, final String thirdpartyId)
            throws AutomationException {
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME)
                .build();

        final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME)
                .withLastName(Constant.TEST_LAST_NAME).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();

        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();

        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                        .withCity(AddressInfoConstant.TEST_CITY).withAddress(AddressInfoConstant.TEST_ADDRESS_1)
                        .withAddressType(String.valueOf(AddressInfoConstant.ADDRESS_TYPE_ID))
                        .withState(AddressInfoConstant.TEST_STATE_GA).withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo)
                        .withThirdPartyId(thirdpartyId).build();

        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC).withProspect(prospect).build();
    }

    public static ProspectRequest buildGenericProspectRequestWithMilitaryState(final String refAC, final String refMC,
                                                                              final String email)
            throws AutomationException {
        final Map<String, String> experianUserInformation = ExperianUserInformation.getByState(StatesSupported.MILITARY_STATE);
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME)
                .build();

        String state = null;
        if(experianUserInformation.get(ExperianUserInformation.STATE_OF_RESIDENCE) != null) {
            state = experianUserInformation.get(ExperianUserInformation.STATE_OF_RESIDENCE);
        }
        final PersonalInfo personalInfo = new PersonalInfo.Builder()
                .withFirstName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(experianUserInformation.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY))
                .withUserNameTypeId(Constant.TEST_USER_NAME_TYPE_ID)
                .withSourceTypeId(Constant.TEST_SOURCE_TYPE_ID)
                .build();
        final AddressInfo addressInfo = new AddressInfo.Builder()
                .withStreet(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(experianUserInformation.get(ExperianUserInformation.CITY_KEY))
                .withState(experianUserInformation.get(ExperianUserInformation.STATE_KEY))
                .withZipCode(experianUserInformation.get(ExperianUserInformation.ZIP_KEY))
                .withAddress1(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withAddressTypeId(((experianUserInformation.get(ExperianUserInformation.ADDRESS_TYPE_ID_KEY) != null)? Integer.parseInt(experianUserInformation.get(ExperianUserInformation.ADDRESS_TYPE_ID_KEY)):AddressInfoConstant.ADDRESS_TYPE_ID))
                .withStateOfResidence(state)
                .build();
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC).withProspect(prospect).build();
    }
}
