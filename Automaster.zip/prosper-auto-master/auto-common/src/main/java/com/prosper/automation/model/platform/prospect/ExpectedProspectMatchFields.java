
package com.prosper.automation.model.platform.prospect;

/**
 * Created by rsubramanyam on 6/21/16.
 */
public class ExpectedProspectMatchFields {

    String email;
    String zip;
    String address;
    String firstName;
    String lastName;
    String ssn;
    String userId;


    public ExpectedProspectMatchFields(String email, String firstName, String lastName, String ssn, String address, String zip,
                                       String userId) {
        this.email = email;
        this.lastName = lastName;
        this.zip = zip;
        this.address = address;
        this.firstName = firstName;
        this.ssn = ssn;
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }
}
