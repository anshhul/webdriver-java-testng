package com.prosper.automation.constant.web;

/**
 * Created by rsubramanyam on 6/16/16.
 */
public final class WebDriverConfigConstants {
    public static final String SAUCE_LAB_RUN_ID_MESSAGE_PREFIX = "Borrower Test Run: ";
}
