
package com.prosper.automation.model.platform.merchant;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.enumeration.platform.Industry;
import com.prosper.automation.enumeration.platform.ProviderStatus;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.PhoneNumber;

/**
 *
 * @author Sonali Phatak
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class MerchantRequest {

	@JsonProperty("role")
	private String role;
	@JsonProperty("partner_name")
	private String partnerName;
	@JsonProperty("institution_id")
	private Integer institutionId;
	@JsonProperty("email_address")
	private String emailAddress;
	@JsonProperty("merchant_contact")
	private List<MerchantsContactInformation> merchantsContactInformation;
	@JsonProperty("legal_name")
	private String legalName;
	@JsonProperty("doing_business_as")
	private String doingBusinessAs;
	@JsonProperty("industry")
	private Industry industry;
	@JsonProperty("merchant_funnel_name")
	private String merchantFunnelName;
	@JsonProperty("provider_id")
	private String providerId;
	@JsonProperty("promo_option")
	private String promoOption;
	@JsonProperty("next_review_date")
	private String nextReviewDate;
	@JsonProperty("merchant_offered_product_specs")
	private List<MerchantOfferedProductSpecs> merchantOfferedProductSpecs;
	@JsonProperty("intended_role")
	private Integer intendedRole;
	@JsonProperty("billing_addresses")
	private List<AddressInfo> billingAddress;
	@JsonProperty("phone_numbers")
	private List<PhoneNumber> phoneNumbers;
	@JsonProperty("bank_account_info")
	private List<BankAccountInfo> bankAccountinfo;
	@JsonProperty("compliance_status")
	private ProviderStatus complianceStatus;
	@JsonProperty("merchant_type")
	private String merchantType;

	public MerchantRequest() {
	}

	private MerchantRequest(Builder builder) {
		role = builder.role;
		partnerName = builder.partnerName;
		institutionId = builder.institutionId;
		emailAddress = builder.emailAddress;
		merchantsContactInformation = builder.merchantsContactInformation;
		legalName = builder.legalName;
		doingBusinessAs = builder.doingBusinessAs;
		industry = builder.industry;
		merchantFunnelName = builder.merchantFunnelName;
		providerId = builder.providerId;
		promoOption = builder.promoOption;
		nextReviewDate = builder.nextReviewDate;
		merchantOfferedProductSpecs = builder.merchantOfferedProductSpecs;
		intendedRole = builder.intendedRole;
		billingAddress = builder.billingAddress;
		phoneNumbers = builder.phoneNumbers;
		bankAccountinfo = builder.bankAccountInfos;
		complianceStatus = builder.complianceStatus;
		merchantType = builder.merchantType;
	}

	public static final class Builder {

		private String role;
		private String partnerName;
		private Integer institutionId;
		private String emailAddress;
		private List<MerchantsContactInformation> merchantsContactInformation;
		private String legalName;
		private String doingBusinessAs;
		private Industry industry;
		private String merchantFunnelName;
		private String providerId;
		private String promoOption;
		private String nextReviewDate;
		private List<MerchantOfferedProductSpecs> merchantOfferedProductSpecs;
		private Integer intendedRole;
		private List<AddressInfo> billingAddress;
		private List<PhoneNumber> phoneNumbers;
		private List<BankAccountInfo> bankAccountInfos;
		private ProviderStatus complianceStatus;
		private String merchantType;

		public Builder() {
		}

		public Builder withRole(String val) {
			role = val;
			return this;
		}

		public Builder withPartnerName(String val) {
			partnerName = val;
			return this;
		}

		public Builder withInstitutionId(Integer val) {
			institutionId = val;
			return this;
		}

		public Builder withEmailAddress(String val) {
			emailAddress = val;
			return this;
		}

		public Builder withMerchantsContactInformation(List<MerchantsContactInformation> val) {
			merchantsContactInformation = val;
			return this;
		}

		public Builder withLegalName(String val) {
			legalName = val;
			return this;
		}

		public Builder withDoingBusinessAs(String val) {
			doingBusinessAs = val;
			return this;
		}

		public Builder withIndustry(Industry val) {
			industry = val;
			return this;
		}

		public Builder withMerchantFunnelName(String val) {
			merchantFunnelName = val;
			return this;
		}

		public Builder withProviderId(String val) {
			providerId = val;
			return this;
		}

		public Builder withPromoOption(String val) {
			promoOption = val;
			return this;
		}

		public Builder withNextReviewDate(String val) {
			nextReviewDate = val;
			return this;
		}

		public Builder withMerchantOfferedProductSpecs(List<MerchantOfferedProductSpecs> val) {
			merchantOfferedProductSpecs = val;
			return this;
		}

		public Builder withIntendedRole(Integer val) {
			intendedRole = val;
			return this;
		}

		public Builder withBillingAddress(List<AddressInfo> val) {
			billingAddress = val;
			return this;
		}

		public Builder withPhoneNumbers(List<PhoneNumber> val) {
			phoneNumbers = val;
			return this;
		}

		public Builder withBankAccountinfo(List<BankAccountInfo> val) {
			bankAccountInfos = val;
			return this;
		}

		public Builder withComplianceStatus(ProviderStatus val) {
			complianceStatus = val;
			return this;
		}

		public Builder withMerchantType(MerchantType val) {
			merchantType = val.toString();
			return this;
		}

		public MerchantRequest build() {
			return new MerchantRequest(this);
		}
	}
}
