package com.prosper.automation.util;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.prosper.automation.configuration.NachaConfiguration;
import com.prosper.automation.exception.AutomationException;

/**
 * @author grajasekar
 * @since 0.0.1
 */
public final class NachaSSHUtilities implements Closeable {

    private static final Logger LOG = Logger.getLogger(NachaSSHUtilities.class.getSimpleName());

    private static final String STRICT_HOST_KEY_CHECKING_KEY = "StrictHostKeyChecking";
    private static final String STRICT_HOST_KEY_CHECKING_VALUE = "no";

    private static final String SFTP_CHANNEL_NAME = "sftp";

    private static final String INITIATING_SSH_CONNECTION_LOG = "Initiating remote ssh connection to %s.";
    private static final String UNABLE_TO_INITIATE_SSH_CONNECTION_LOG = "Unable to establish ssh connection to remote server.";
    private static final String UNABLE_TO_READ_FILE_CONTENT_FROM_REMOTE_SERVER_LOG = "Unable to read files from remote server.";
    private static final String CLOSING_REMOTE_SSH_SESSION_LOG = "Closing ssh connection to remote host.";
    private static final String SESSION_IS_NULL_LOG = "Session object is null.";
    private static final String READING_FILE_LOG = "Reading file content %s from remote server.";

    private final NachaConfiguration nachaConfiguration;

    private Session session = null;
    JSch jsch = new JSch();


    // TODO: there can only be ten channels open at a time; this limits the number of concurrency.
    public NachaSSHUtilities(final NachaConfiguration nachaConfiguration) throws AutomationException {
        LOG.info(String.format(INITIATING_SSH_CONNECTION_LOG, nachaConfiguration.getHostName()));

        final Properties properties = new Properties();
        properties.put(STRICT_HOST_KEY_CHECKING_KEY, STRICT_HOST_KEY_CHECKING_VALUE);

        this.nachaConfiguration = nachaConfiguration;

        try {
        	jsch.addIdentity(ClassLoader
                    .getSystemResource("testdata/environment/common/testFiles/" + nachaConfiguration.getSFTPWebKey())
                    .getFile());
        	session = jsch.getSession(nachaConfiguration.getUser(), nachaConfiguration.getHostName(), NachaConfiguration.PORT);
            session.setConfig(properties);
            session.connect();
        } catch (final JSchException jse) {
            throw new AutomationException(UNABLE_TO_INITIATE_SSH_CONNECTION_LOG, jse);
        }
    }

    /**
     * Read File from Remote File path (/Usr/Prosper/ProsperACH01/NACHA File)
     * @param remoteFilePath
     * @return
     * @throws AutomationException
     */
    public String readFiles(String remoteFilePath) throws AutomationException {
    	
		try {
			LOG.info(String.format(READING_FILE_LOG, remoteFilePath));

			final Channel channel = session.openChannel(SFTP_CHANNEL_NAME);
			final ChannelSftp sftpChannel = (ChannelSftp) channel;

			sftpChannel.connect();
			System.out.println("Connected TO SFTP Channel");

			sftpChannel.cd(remoteFilePath);
			System.out.println("Navigate TO Remote Filepath: "+remoteFilePath);

			String returnString;
			ArrayList<String> nachaFileNames = new ArrayList<String>();
			Vector filelist = sftpChannel.ls(remoteFilePath + "/*.nacha");
			for (int i = 0; i < filelist.size(); i++) {
				nachaFileNames.add(filelist.get(i).toString().substring(55, 86));
				System.out.println(filelist.get(i).toString().substring(55, 86));

			}

			Collections.reverse(nachaFileNames);
			System.out.println("Colection Reversed");
			try (final InputStream inputStream = sftpChannel.get(nachaFileNames.get(0))) {
				returnString = IOUtils.toString(inputStream);
				System.out.println(returnString);
			}
			sftpChannel.disconnect();
			System.out.println("SFTP Channel Disconnected");
			return returnString;
		} catch (JSchException | SftpException | IOException ex) {
			throw new AutomationException(UNABLE_TO_READ_FILE_CONTENT_FROM_REMOTE_SERVER_LOG, ex);
		}
    }

    @Override
    public void close() throws IOException {
        LOG.info(CLOSING_REMOTE_SSH_SESSION_LOG);

        try {
            session.disconnect();
        } catch (final Exception e) {
            LOG.warn(SESSION_IS_NULL_LOG, e);
        }
    }
}
