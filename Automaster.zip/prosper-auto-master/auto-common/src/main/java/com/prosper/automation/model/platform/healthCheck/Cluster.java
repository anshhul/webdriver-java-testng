package com.prosper.automation.model.platform.healthCheck;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

/**
 * Created by pbudiono on 6/13/16.
 */
public final class Cluster {

	public String name;
	public String scheme;
	public String connectTimeout;
	public String socketTimeout;
	public String hostName;
	public List<String> services;

	public Cluster() {
	}

	private Cluster(Builder builder) {
		name = builder.name;
		hostName = builder.hostName;
		services = builder.services;
	}

	@JsonIgnore
	public String getSocketTimeout() {
		return socketTimeout;
	}

	@JsonIgnore
	public String getScheme() {
		return scheme;
	}

	@JsonIgnore
	public String getConnectTimeout() {
		return connectTimeout;
	}

	@JsonIgnore
	public List<String> getServices() {
		return services;
	}

	@JsonIgnore
	public String getHostName() {
		return hostName;
	}

	@JsonIgnore
	public String getName() {
		return name;
	}

	public static final class Builder {

		private String name;
		private String hostName;
		private List<String> services;

		public Builder() {
		}

		public Builder withName(String val) {
			name = val;
			return this;
		}

		public Builder withHostName(String val) {
			hostName = val;
			return this;
		}

		public Builder withServices(List<String> val) {
			services = val;
			return this;
		}

		public Cluster build() {
			return new Cluster(this);
		}
	}
}
