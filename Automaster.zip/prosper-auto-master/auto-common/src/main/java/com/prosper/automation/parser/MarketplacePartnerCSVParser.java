
package com.prosper.automation.parser;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.BorrowerPricingData;
import com.prosper.automation.model.testdata.PartnerAuthenticationInfo;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

/**
 * @author pbudiono
 */
public final class MarketplacePartnerCSVParser {

    private MarketplacePartnerCSVParser() {
    }

    public static Object[][] parse(final String csvFilePath) throws AutomationException {
        try (final FileInputStream fileInputStream = new FileInputStream(csvFilePath);
                final Reader reader = new InputStreamReader(fileInputStream);
                final CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader())) {

            final List<CSVRecord> records = parser.getRecords();
            final int recordSize = records.size();

            final Object[][] pricingData = new Object[recordSize][1];
            for (int i = 0; i < recordSize; i++) {
                pricingData[i][0] = new PartnerAuthenticationInfo.Builder()
                        .withPartnerName(records.get(i).get("partner_name"))
                        .withLegacyId(records.get(i).get("legacy_id"))
                        .withOauthClientId(records.get(i).get("oauth_client_id"))
                        .withOauthClientSecret(records.get(i).get("oauth_client_secret"))
                        .build();
            }
            return pricingData;
        } catch (IOException e) {
            throw new AutomationException(e.getMessage());
        }
    }
}
