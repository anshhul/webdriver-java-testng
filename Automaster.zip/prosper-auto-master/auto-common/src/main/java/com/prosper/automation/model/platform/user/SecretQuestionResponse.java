package com.prosper.automation.model.platform.user;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbudiono
 */
public final class SecretQuestionResponse {

	@JsonProperty("result")
	private List<SecretQuestion> result;
	@JsonProperty("result_count")
	private Integer resultCount;
	@JsonProperty("total_count")
	private Integer totalCount;

	@JsonIgnore
	public int getResultCount() {
		return resultCount;
	}

	@JsonIgnore
	public int getTotalCount() {
		return totalCount;
	}

	@JsonIgnore
	public List<SecretQuestion> getResult() {
		return result;
	}
}
