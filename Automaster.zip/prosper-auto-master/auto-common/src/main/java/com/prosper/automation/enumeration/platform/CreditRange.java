
package com.prosper.automation.enumeration.platform;

import com.google.common.collect.Range;

import java.util.Random;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public enum CreditRange {
    
    EXCELLENT(1, 760, 850), GOOD(2, 700, 759), FAIR(3, 640, 699), POOR(4, 300, 639);
    
    private static final Random RANDOM = new Random();
    
    private final int id;
    private final Range<Integer> range;
    
    
    CreditRange(final int id, final int lowBound, final int highBound) {
        this.id = id;
        range = Range.closed(lowBound, highBound);
    }
    
    public int getId() {
        return id;
    }
    
    public int getRandomScore() {
        return RANDOM.nextInt(range.upperEndpoint() - range.lowerEndpoint());
    }
}
