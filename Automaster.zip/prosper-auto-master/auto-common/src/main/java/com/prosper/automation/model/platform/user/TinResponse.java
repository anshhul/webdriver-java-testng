
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class TinResponse {
    
    @JsonProperty("email")
    private String email;
    @JsonProperty("tin")
    private String tin;
    @JsonProperty("is_existing")
    private Boolean isExisting;
    
    
    public String getEmail() {
        return email;
    }

    public Boolean getIsExisting() {
        return isExisting;
    }
}
