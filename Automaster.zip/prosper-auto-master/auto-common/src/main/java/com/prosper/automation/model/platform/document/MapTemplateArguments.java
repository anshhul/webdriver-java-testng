
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"date", "listing_id", "user_name", "address_1", "city", "state", "zip_code", "apr", "finance_charge",
        "total_paid_back", "monthly_payment", "start_date", "end_date", "term", "loan_amount", "origination_fee", "final_payment"})
public final class MapTemplateArguments {
    
    @JsonProperty("date")
    private String date;
    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("user_name")
    private String userName;
    @JsonProperty("address_1")
    private String address1;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip_code")
    private String zipCode;
    @JsonProperty("apr")
    private Double apr;
    @JsonProperty("finance_charge")
    private Double financeCharge;
    @JsonProperty("total_paid_back")
    private Double totalPaidBack;
    @JsonProperty("monthly_payment")
    private Double monthlyPayment;
    @JsonProperty("start_date")
    private String startDate;
    @JsonProperty("end_date")
    private String endDate;
    @JsonProperty("term")
    private Integer term;
    @JsonProperty("loan_amount")
    private Integer loanAmount;
    @JsonProperty("origination_fee")
    private Integer originationFee;
    @JsonProperty("final_payment")
    private Double finalPayment;
    
    
    public MapTemplateArguments() {
    }
    
    private MapTemplateArguments(final Builder builder) {
        date = builder.date;
        listingId = builder.listingId;
        userName = builder.userName;
        address1 = builder.address1;
        city = builder.city;
        state = builder.state;
        zipCode = builder.zipCode;
        apr = builder.apr;
        financeCharge = builder.financeCharge;
        totalPaidBack = builder.totalPaidBack;
        monthlyPayment = builder.monthlyPayment;
        startDate = builder.startDate;
        endDate = builder.endDate;
        term = builder.term;
        loanAmount = builder.loanAmount;
        originationFee = builder.originationFee;
        finalPayment = builder.finalPayment;
    }
    
    
    public static final class Builder {
        
        private String date;
        private Long listingId;
        private String userName;
        private String address1;
        private String city;
        private String state;
        private String zipCode;
        private Double apr;
        private Double financeCharge;
        private Double totalPaidBack;
        private Double monthlyPayment;
        private String startDate;
        private String endDate;
        private Integer term;
        private Integer loanAmount;
        private Integer originationFee;
        private Double finalPayment;
        
        
        public Builder() {
        }
        
        public Builder withDate(final String date) {
            this.date = date;
            return this;
        }
        
        public Builder withListingId(final Long listingId) {
            this.listingId = listingId;
            return this;
        }
        
        public Builder withUserName(final String userName) {
            this.userName = userName;
            return this;
        }
        
        public Builder withAddress1(final String address1) {
            this.address1 = address1;
            return this;
        }
        
        public Builder withCity(final String city) {
            this.city = city;
            return this;
        }
        
        public Builder withState(final String state) {
            this.state = state;
            return this;
        }
        
        public Builder withZipCode(final String zipCode) {
            this.zipCode = zipCode;
            return this;
        }
        
        public Builder withApr(final Double apr) {
            this.apr = apr;
            return this;
        }
        
        public Builder withFinanceCharge(final Double financeCharge) {
            this.financeCharge = financeCharge;
            return this;
        }
        
        public Builder withTotalPaidBack(final Double totalPaidBack) {
            this.totalPaidBack = totalPaidBack;
            return this;
        }
        
        public Builder withMonthlyPayment(final Double monthlyPayment) {
            this.monthlyPayment = monthlyPayment;
            return this;
        }
        
        public Builder withStartDate(final String startDate) {
            this.startDate = startDate;
            return this;
        }
        
        public Builder withEndDate(final String endDate) {
            this.endDate = endDate;
            return this;
        }
        
        public Builder withTerm(final Integer term) {
            this.term = term;
            return this;
        }
        
        public Builder withLoanAmount(final Integer loanAmount) {
            this.loanAmount = loanAmount;
            return this;
        }
        
        public Builder withOriginationFee(final Integer originationFee) {
            this.originationFee = originationFee;
            return this;
        }
        
        public Builder withFinalPayment(final Double finalPayment) {
            this.finalPayment = finalPayment;
            return this;
        }
        
        public MapTemplateArguments build() {
            return new MapTemplateArguments(this);
        }
    }
}
