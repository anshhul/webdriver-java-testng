package com.prosper.automation.model.gds.processor;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class GDSListingResponse {

}
