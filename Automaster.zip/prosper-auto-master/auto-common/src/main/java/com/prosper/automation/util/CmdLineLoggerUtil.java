
package com.prosper.automation.util;

import org.apache.log4j.Logger;

/**
 * Created by rsubramanyam on 4/12/16.
 */
public class CmdLineLoggerUtil {

    private static final Logger LOG = Logger.getLogger(CmdLineLoggerUtil.class.getSimpleName());

    public static void log(Colorize color, String message) {
        LOG.info(String.format("%s %s %s", color.getColor(), message, Colorize.RESET.getColor()));
    }

    public static void log(String message) {
        LOG.info(message);
    }
}
