
package com.prosper.automation.model.platform.listing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Listings {

    @JsonProperty("listing_id")
    private Long listingId;
    @JsonProperty("user_id")
    private Integer userId;
    @JsonProperty("loan_offer_id")
    private String loanOfferId;
    @JsonProperty("loan_amount")
    private Double amount;
    @JsonProperty("max_rate")
    private Double maxRate;
    @JsonProperty("current_rate")
    private Double currentRate;
    @JsonProperty("max_rate_to_bid")
    private Double maxRateToBid;
    @JsonProperty("purpose")
    private String purpose;
    @JsonProperty("start_date")
    private Date startTime;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("status")
    private String status;
    @JsonProperty("account_id")
    private Integer accountId;
    @JsonProperty("creation_date")
    private Date creationDate;
    @JsonProperty("credit_grade")
    private Integer creditGrade;
    @JsonProperty("title")
    private String title;
    @JsonProperty("funding_term")
    private Double fundingTerm;
    @JsonProperty("funding_option")
    private String fundingOption;
    @JsonProperty("state")
    private String borrowerState;
    @JsonProperty("business_or_personal")
    private String businessOrPersonal;
    @JsonProperty("monthly_income")
    private Double monthlyIncome;
    @JsonProperty("monthly_debt")
    private Double monthlyDebt;
    @JsonProperty("current_dti")
    private Double currentDTI;
    @JsonProperty("end_date")
    private Date endDate;
    @JsonProperty("result_code")
    private String resultCode;
    @JsonProperty("borrower_mailing_address_id")
    private Integer borrowerMailingAddressId;
    @JsonProperty("completion_code_id")
    private Integer completionCodeId;
    @JsonProperty("user_credit_profile_id")
    private Integer userCreditProfileId;
    @JsonProperty("user_home_ownership_id")
    private Integer userHomeownershipId;
    @JsonProperty("last_modified_date")
    private Date lastModifiedDate;
    @JsonProperty("is_deleted")
    private Boolean isDeleted;
    @JsonProperty("alt_key")
    private String altKey;
    @JsonProperty("alt_key_search_id")
    private Integer altKeySearchId;
    @JsonProperty("lender_rate_spread")
    private Double lenderRateSpread;
    @JsonProperty("apr")
    private Double borrowerAPR;
    @JsonProperty("user_employment_detail_id")
    private Integer userEmploymentDetailId;
    @JsonProperty("income_range_id")
    private Integer incomeRangeId;
    @JsonProperty("amount_funded")
    private Double amountFunded;
    @JsonProperty("bid_count")
    private Integer bidCount;
    @JsonProperty("user_loan_history_snapshot_id")
    private Integer userLoanHistorySnapshotId;
    @JsonProperty("terms_approval_date")
    private Date termsApprovalDate;
    @JsonProperty("listing_category_id")
    private Integer listingCategoryId;
    @JsonProperty("product_spec_id")
    private String productSpecId;
    @JsonProperty("loan_id")
    private Integer loanId;
    @JsonProperty("offer_type")
    private String loanOfferingTypeId;
    @JsonProperty("prosper_rating_loss_range_id")
    private Integer prosperRatingLossRangeId;
    @JsonProperty("estimated_loss")
    private Double estimatedLoss;
    @JsonProperty("loan_seller_id")
    private Integer loanSellerId;
    @JsonProperty("lender_yield")
    private Double currentYield;
    @JsonProperty("max_yield_to_bid")
    private Double maxYieldToBid;
    @JsonProperty("investment_product_return_id")
    private Integer investmentProductReturnId;
    @JsonProperty("is_partial_funding_approved")
    private Boolean partialFundingApproved;
    @JsonProperty("funding_threshold")
    private Double fundingThreshold;
    @JsonProperty("adverse_action_group_id")
    private Integer adverseActionGroupId;
    @JsonProperty("prosper_rating_type_id")
    private Integer prosperRatingTypeId;
    @JsonProperty("origination_fee")
    private Double originationFeeAmount;
    @JsonProperty("origination_fee_percent")
    private Double originationFeePercent;
    @JsonProperty("monthly_payment")
    private Double monthlyPayment;
    @JsonProperty("monthly_payment_last")
    private Double monthlyPaymentLast;
    @JsonProperty("effective_yield")
    private Double effectiveYield;
    @JsonProperty("estimated_loss_impact")
    private Double estimatedLossImpact;
    @JsonProperty("estimated_return")
    private Double estimatedReturn;
    @JsonProperty("finance_charge")
    private Double financeCharge;
    @JsonProperty("amount_financed")
    private Double amountFinanced;
    @JsonProperty("total_paid_back")
    private Double totalPaidBack;
    @JsonProperty("ending_borrower_apr")
    private Double endingBorrowerAPR;
    @JsonProperty("ending_monthly_payment")
    private Double endingMonthlyPayment;
    @JsonProperty("ending_finance_charge")
    private Double endingFinanceCharge;
    @JsonProperty("ending_amount_financed")
    private Double endingAmountFinanced;
    @JsonProperty("ending_total_paid_back")
    private Double endingTotalPaidBack;
    @JsonProperty("ending_origination_fee_amount")
    private Double endingOriginationFeeAmount;
    @JsonProperty("ending_monthly_payment_last")
    private Double endingMonthlyPaymentLast;
    @JsonProperty("bre_rule_version")
    private String brERuleVersion;
    @JsonProperty("direct_pay_partner_id")
    private Integer directPayPartnerId;
    @JsonProperty("dealer_code")
    private String dealerCode;
    @JsonProperty("investment_type_id")
    private Integer investmentTypeId;
    @JsonProperty("whole_loan_private_user_id")
    private Integer wholeLoanPrivateUserId;
    @JsonProperty("whole_loan_start_date")
    private Date wholeLoanStartDate;
    @JsonProperty("whole_loan_end_date")
    private Date wholeLoanEndDate;
    @JsonProperty("salesforce_listing_id")
    private String salesforceListingId;
    @JsonProperty("underwriter_id")
    private Integer underwriterId;
    @JsonProperty("application_source_id")
    private Integer applicationSourceId;
    @JsonProperty("loan_product")
    private String loanProductId;


    public Listings() {
    }

    private Listings(final Builder builder) {
        listingId = builder.id;
        userId = builder.userId;
        loanOfferId = builder.loanOfferId;
        amount = builder.amount;
        maxRate = builder.maxRate;
        currentRate = builder.currentRate;
        maxRateToBid = builder.maxRateToBid;
        purpose = builder.purpose;
        startTime = builder.startTime;
        duration = builder.duration;
        status = builder.status;
        accountId = builder.accountId;
        creationDate = builder.creationDate;
        creditGrade = builder.creditGrade;
        title = builder.title;
        fundingOption = builder.fundingOption;
        borrowerState = builder.borrowerState;
        businessOrPersonal = builder.businessOrPersonal;
        monthlyIncome = builder.monthlyIncome;
        monthlyDebt = builder.monthlyDebt;
        currentDTI = builder.currentDTI;
        endDate = builder.endDate;
        resultCode = builder.resultCode;
        borrowerMailingAddressId = builder.borrowerMailingAddressId;
        completionCodeId = builder.completionCodeId;
        userCreditProfileId = builder.userCreditProfileId;
        userHomeownershipId = builder.userHomeownershipId;
        lastModifiedDate = builder.lastModifiedDate;
        isDeleted = builder.isDeleted;
        altKey = builder.altKey;
        altKeySearchId = builder.altKeySearchId;
        lenderRateSpread = builder.lenderRateSpread;
        borrowerAPR = builder.borrowerAPR;
        userEmploymentDetailId = builder.userEmploymentDetailId;
        incomeRangeId = builder.incomeRangeId;
        amountFunded = builder.amountFunded;
        bidCount = builder.bidCount;
        userLoanHistorySnapshotId = builder.userLoanHistorySnapshotId;
        termsApprovalDate = builder.termsApprovalDate;
        listingCategoryId = builder.listingCategoryId;
        productSpecId = builder.productSpecId;
        loanId = builder.loanId;
        loanOfferingTypeId = builder.loanOfferingTypeId;
        prosperRatingLossRangeId = builder.prosperRatingLossRangeId;
        estimatedLoss = builder.estimatedLoss;
        loanSellerId = builder.loanSellerId;
        currentYield = builder.currentYield;
        maxYieldToBid = builder.maxYieldToBid;
        investmentProductReturnId = builder.investmentProductReturnId;
        partialFundingApproved = builder.partialFundingApproved;
        fundingThreshold = builder.fundingThreshold;
        adverseActionGroupId = builder.adverseActionGroupId;
        prosperRatingTypeId = builder.prosperRatingTypeId;
        originationFeeAmount = builder.originationFeeAmount;
        originationFeePercent = builder.originationFeePercent;
        monthlyPayment = builder.monthlyPayment;
        monthlyPaymentLast = builder.monthlyPaymentLast;
        effectiveYield = builder.effectiveYield;
        estimatedLossImpact = builder.estimatedLossImpact;
        estimatedReturn = builder.estimatedReturn;
        financeCharge = builder.financeCharge;
        amountFinanced = builder.amountFinanced;
        totalPaidBack = builder.totalPaidBack;
        endingBorrowerAPR = builder.endingBorrowerAPR;
        endingMonthlyPayment = builder.endingMonthlyPayment;
        endingFinanceCharge = builder.endingFinanceCharge;
        endingAmountFinanced = builder.endingAmountFinanced;
        endingTotalPaidBack = builder.endingTotalPaidBack;
        endingOriginationFeeAmount = builder.endingOriginationFeeAmount;
        endingMonthlyPaymentLast = builder.endingMonthlyPaymentLast;
        brERuleVersion = builder.brERuleVersion;
        directPayPartnerId = builder.directPayPartnerId;
        dealerCode = builder.dealerCode;
        investmentTypeId = builder.investmentTypeId;
        wholeLoanPrivateUserId = builder.wholeLoanPrivateUserId;
        wholeLoanStartDate = builder.wholeLoanStartDate;
        wholeLoanEndDate = builder.wholeLoanEndDate;
        salesforceListingId = builder.salesforceListingId;
        underwriterId = builder.underwriterId;
        applicationSourceId = builder.applicationSourceId;
        loanProductId = builder.loanProductId;
    }


    public Long getListingId() {
        return listingId;
    }

    public void setListingId(Long listingId) {
        this.listingId = listingId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getLoanOfferId() {
        return loanOfferId;
    }

    public void setLoanOfferId(String loanOfferId) {
        this.loanOfferId = loanOfferId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getMaxRate() {
        return maxRate;
    }

    public void setMaxRate(Double maxRate) {
        this.maxRate = maxRate;
    }

    public Double getCurrentRate() {
        return currentRate;
    }

    public void setCurrentRate(Double currentRate) {
        this.currentRate = currentRate;
    }

    public Double getMaxRateToBid() {
        return maxRateToBid;
    }

    public void setMaxRateToBid(Double maxRateToBid) {
        this.maxRateToBid = maxRateToBid;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Integer getCreditGrade() {
        return creditGrade;
    }

    public void setCreditGrade(Integer creditGrade) {
        this.creditGrade = creditGrade;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFundingOption() {
        return fundingOption;
    }

    public void setFundingOption(String fundingOption) {
        this.fundingOption = fundingOption;
    }

    public String getBorrowerState() {
        return borrowerState;
    }

    public void setBorrowerState(String borrowerState) {
        this.borrowerState = borrowerState;
    }

    public String getBusinessOrPersonal() {
        return businessOrPersonal;
    }

    public void setBusinessOrPersonal(String businessOrPersonal) {
        this.businessOrPersonal = businessOrPersonal;
    }

    public Double getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(Double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public Double getMonthlyDebt() {
        return monthlyDebt;
    }

    public void setMonthlyDebt(Double monthlyDebt) {
        this.monthlyDebt = monthlyDebt;
    }

    public Double getCurrentDTI() {
        return currentDTI;
    }

    public void setCurrentDTI(Double currentDTI) {
        this.currentDTI = currentDTI;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public Integer getBorrowerMailingAddressId() {
        return borrowerMailingAddressId;
    }

    public void setBorrowerMailingAddressId(Integer borrowerMailingAddressId) {
        this.borrowerMailingAddressId = borrowerMailingAddressId;
    }

    public Integer getCompletionCodeId() {
        return completionCodeId;
    }

    public void setCompletionCodeId(Integer completionCodeId) {
        this.completionCodeId = completionCodeId;
    }

    public Integer getUserCreditProfileId() {
        return userCreditProfileId;
    }

    public void setUserCreditProfileId(Integer userCreditProfileId) {
        this.userCreditProfileId = userCreditProfileId;
    }

    public Integer getUserHomeownershipId() {
        return userHomeownershipId;
    }

    public void setUserHomeownershipId(Integer userHomeownershipId) {
        this.userHomeownershipId = userHomeownershipId;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }

    public String getAltKey() {
        return altKey;
    }

    public void setAltKey(String altKey) {
        this.altKey = altKey;
    }

    public Integer getAltKeySearchId() {
        return altKeySearchId;
    }

    public void setAltKeySearchId(Integer altKeySearchId) {
        this.altKeySearchId = altKeySearchId;
    }

    public Double getLenderRateSpread() {
        return lenderRateSpread;
    }

    public void setLenderRateSpread(Double lenderRateSpread) {
        this.lenderRateSpread = lenderRateSpread;
    }

    public Double getBorrowerAPR() {
        return borrowerAPR;
    }

    public void setBorrowerAPR(Double borrowerAPR) {
        this.borrowerAPR = borrowerAPR;
    }

    public Integer getUserEmploymentDetailId() {
        return userEmploymentDetailId;
    }

    public void setUserEmploymentDetailId(Integer userEmploymentDetailId) {
        this.userEmploymentDetailId = userEmploymentDetailId;
    }

    public Integer getIncomeRangeId() {
        return incomeRangeId;
    }

    public void setIncomeRangeId(Integer incomeRangeId) {
        this.incomeRangeId = incomeRangeId;
    }

    public Double getAmountFunded() {
        return amountFunded;
    }

    public void setAmountFunded(Double amountFunded) {
        this.amountFunded = amountFunded;
    }

    public Integer getBidCount() {
        return bidCount;
    }

    public void setBidCount(Integer bidCount) {
        this.bidCount = bidCount;
    }

    public Integer getUserLoanHistorySnapshotId() {
        return userLoanHistorySnapshotId;
    }

    public void setUserLoanHistorySnapshotId(Integer userLoanHistorySnapshotId) {
        this.userLoanHistorySnapshotId = userLoanHistorySnapshotId;
    }

    public Date getTermsApprovalDate() {
        return termsApprovalDate;
    }

    public void setTermsApprovalDate(Date termsApprovalDate) {
        this.termsApprovalDate = termsApprovalDate;
    }

    public Integer getListingCategoryId() {
        return listingCategoryId;
    }

    public void setListingCategoryId(Integer listingCategoryId) {
        this.listingCategoryId = listingCategoryId;
    }

    public String getProductSpecId() {
        return productSpecId;
    }

    public void setProductSpecId(String productSpecId) {
        this.productSpecId = productSpecId;
    }

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public String getLoanOfferingTypeId() {
        return loanOfferingTypeId;
    }

    public void setLoanOfferingTypeId(String loanOfferingTypeId) {
        this.loanOfferingTypeId = loanOfferingTypeId;
    }

    public Integer getProsperRatingLossRangeId() {
        return prosperRatingLossRangeId;
    }

    public void setProsperRatingLossRangeId(Integer prosperRatingLossRangeId) {
        this.prosperRatingLossRangeId = prosperRatingLossRangeId;
    }

    public Double getEstimatedLoss() {
        return estimatedLoss;
    }

    public void setEstimatedLoss(Double estimatedLoss) {
        this.estimatedLoss = estimatedLoss;
    }

    public Integer getLoanSellerId() {
        return loanSellerId;
    }

    public void setLoanSellerId(Integer loanSellerId) {
        this.loanSellerId = loanSellerId;
    }

    public Double getCurrentYield() {
        return currentYield;
    }

    public void setCurrentYield(Double currentYield) {
        this.currentYield = currentYield;
    }

    public Double getMaxYieldToBid() {
        return maxYieldToBid;
    }

    public void setMaxYieldToBid(Double maxYieldToBid) {
        this.maxYieldToBid = maxYieldToBid;
    }

    public Integer getInvestmentProductReturnId() {
        return investmentProductReturnId;
    }

    public void setInvestmentProductReturnId(Integer investmentProductReturnId) {
        this.investmentProductReturnId = investmentProductReturnId;
    }

    public Boolean getPartialFundingApproved() {
        return partialFundingApproved;
    }

    public void setPartialFundingApproved(Boolean partialFundingApproved) {
        this.partialFundingApproved = partialFundingApproved;
    }

    public Double getFundingTerm() {
        return fundingTerm;
    }

    public void setFundingTerm(Double fundingTerm) {
        this.fundingTerm = fundingTerm;
    }

    public Double getFundingThreshold() {
        return fundingThreshold;
    }

    public void setFundingThreshold(Double fundingThreshold) {
        this.fundingThreshold = fundingThreshold;
    }

    public Integer getAdverseActionGroupId() {
        return adverseActionGroupId;
    }

    public void setAdverseActionGroupId(Integer adverseActionGroupId) {
        this.adverseActionGroupId = adverseActionGroupId;
    }

    public Integer getProsperRatingTypeId() {
        return prosperRatingTypeId;
    }

    public void setProsperRatingTypeId(Integer prosperRatingTypeId) {
        this.prosperRatingTypeId = prosperRatingTypeId;
    }

    public Double getOriginationFeeAmount() {
        return originationFeeAmount;
    }

    public void setOriginationFeeAmount(Double originationFeeAmount) {
        this.originationFeeAmount = originationFeeAmount;
    }

    public Double getOriginationFeePercent() {
        return originationFeePercent;
    }

    public void setOriginationFeePercent(Double originationFeePercent) {
        this.originationFeePercent = originationFeePercent;
    }

    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(Double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public Double getMonthlyPaymentLast() {
        return monthlyPaymentLast;
    }

    public void setMonthlyPaymentLast(Double monthlyPaymentLast) {
        this.monthlyPaymentLast = monthlyPaymentLast;
    }

    public Double getEffectiveYield() {
        return effectiveYield;
    }

    public void setEffectiveYield(Double effectiveYield) {
        this.effectiveYield = effectiveYield;
    }

    public Double getEstimatedLossImpact() {
        return estimatedLossImpact;
    }

    public void setEstimatedLossImpact(Double estimatedLossImpact) {
        this.estimatedLossImpact = estimatedLossImpact;
    }

    public Double getEstimatedReturn() {
        return estimatedReturn;
    }

    public void setEstimatedReturn(Double estimatedReturn) {
        this.estimatedReturn = estimatedReturn;
    }

    public Double getFinanceCharge() {
        return financeCharge;
    }

    public void setFinanceCharge(Double financeCharge) {
        this.financeCharge = financeCharge;
    }

    public Double getAmountFinanced() {
        return amountFinanced;
    }

    public void setAmountFinanced(Double amountFinanced) {
        this.amountFinanced = amountFinanced;
    }

    public Double getTotalPaidBack() {
        return totalPaidBack;
    }

    public void setTotalPaidBack(Double totalPaidBack) {
        this.totalPaidBack = totalPaidBack;
    }

    public Double getEndingBorrowerAPR() {
        return endingBorrowerAPR;
    }

    public void setEndingBorrowerAPR(Double endingBorrowerAPR) {
        this.endingBorrowerAPR = endingBorrowerAPR;
    }

    public Double getEndingMonthlyPayment() {
        return endingMonthlyPayment;
    }

    public void setEndingMonthlyPayment(Double endingMonthlyPayment) {
        this.endingMonthlyPayment = endingMonthlyPayment;
    }

    public Double getEndingFinanceCharge() {
        return endingFinanceCharge;
    }

    public void setEndingFinanceCharge(Double endingFinanceCharge) {
        this.endingFinanceCharge = endingFinanceCharge;
    }

    public Double getEndingAmountFinanced() {
        return endingAmountFinanced;
    }

    public void setEndingAmountFinanced(Double endingAmountFinanced) {
        this.endingAmountFinanced = endingAmountFinanced;
    }

    public Double getEndingTotalPaidBack() {
        return endingTotalPaidBack;
    }

    public void setEndingTotalPaidBack(Double endingTotalPaidBack) {
        this.endingTotalPaidBack = endingTotalPaidBack;
    }

    public Double getEndingOriginationFeeAmount() {
        return endingOriginationFeeAmount;
    }

    public void setEndingOriginationFeeAmount(Double endingOriginationFeeAmount) {
        this.endingOriginationFeeAmount = endingOriginationFeeAmount;
    }

    public Double getEndingMonthlyPaymentLast() {
        return endingMonthlyPaymentLast;
    }

    public void setEndingMonthlyPaymentLast(Double endingMonthlyPaymentLast) {
        this.endingMonthlyPaymentLast = endingMonthlyPaymentLast;
    }

    public String getBrERuleVersion() {
        return brERuleVersion;
    }

    public void setBrERuleVersion(String brERuleVersion) {
        this.brERuleVersion = brERuleVersion;
    }

    public Integer getDirectPayPartnerId() {
        return directPayPartnerId;
    }

    public void setDirectPayPartnerId(Integer directPayPartnerId) {
        this.directPayPartnerId = directPayPartnerId;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public Integer getInvestmentTypeId() {
        return investmentTypeId;
    }

    public void setInvestmentTypeId(Integer investmentTypeId) {
        this.investmentTypeId = investmentTypeId;
    }

    public Integer getWholeLoanPrivateUserId() {
        return wholeLoanPrivateUserId;
    }

    public void setWholeLoanPrivateUserId(Integer wholeLoanPrivateUserId) {
        this.wholeLoanPrivateUserId = wholeLoanPrivateUserId;
    }

    public Date getWholeLoanStartDate() {
        return wholeLoanStartDate;
    }

    public void setWholeLoanStartDate(Date wholeLoanStartDate) {
        this.wholeLoanStartDate = wholeLoanStartDate;
    }

    public Date getWholeLoanEndDate() {
        return wholeLoanEndDate;
    }

    public void setWholeLoanEndDate(Date wholeLoanEndDate) {
        this.wholeLoanEndDate = wholeLoanEndDate;
    }

    public String getSalesforceListingId() {
        return salesforceListingId;
    }

    public void setSalesforceListingId(String salesforceListingId) {
        this.salesforceListingId = salesforceListingId;
    }

    public Integer getUnderwriterId() {
        return underwriterId;
    }

    public void setUnderwriterId(Integer underwriterId) {
        this.underwriterId = underwriterId;
    }

    public Integer getApplicationSourceId() {
        return applicationSourceId;
    }

    public void setApplicationSourceId(Integer applicationSourceId) {
        this.applicationSourceId = applicationSourceId;
    }

    public String getLoanProductId() {
        return loanProductId;
    }

    public void setLoanProductId(String loanProductId) {
        this.loanProductId = loanProductId;
    }

    public static final class Builder {

        private Long id;
        private Integer userId;
        private String loanOfferId;
        private Double amount;
        private Double maxRate;
        private Double currentRate;
        private Double maxRateToBid;
        private String purpose;
        private Date startTime;
        private Integer duration;
        private String status;
        private Integer accountId;
        private Date creationDate;
        private Integer creditGrade;
        private String title;
        private String fundingOption;
        private String borrowerState;
        private String businessOrPersonal;
        private Double monthlyIncome;
        private Double monthlyDebt;
        private Double currentDTI;
        private Date endDate;
        private String resultCode;
        private Integer borrowerMailingAddressId;
        private Integer completionCodeId;
        private Integer userCreditProfileId;
        private Integer userHomeownershipId;
        private Date lastModifiedDate;
        private Boolean isDeleted;
        private String altKey;
        private Integer altKeySearchId;
        private Double lenderRateSpread;
        private Double borrowerAPR;
        private Integer userEmploymentDetailId;
        private Integer incomeRangeId;
        private Double amountFunded;
        private Integer bidCount;
        private Integer userLoanHistorySnapshotId;
        private Date termsApprovalDate;
        private Integer listingCategoryId;
        private String productSpecId;
        private Integer loanId;
        private String loanOfferingTypeId;
        private Integer prosperRatingLossRangeId;
        private Double estimatedLoss;
        private Integer loanSellerId;
        private Double currentYield;
        private Double maxYieldToBid;
        private Integer investmentProductReturnId;
        private Boolean partialFundingApproved;
        private Double fundingThreshold;
        private Integer adverseActionGroupId;
        private Integer prosperRatingTypeId;
        private Double originationFeeAmount;
        private Double originationFeePercent;
        private Double monthlyPayment;
        private Double monthlyPaymentLast;
        private Double effectiveYield;
        private Double estimatedLossImpact;
        private Double estimatedReturn;
        private Double financeCharge;
        private Double amountFinanced;
        private Double totalPaidBack;
        private Double endingBorrowerAPR;
        private Double endingMonthlyPayment;
        private Double endingFinanceCharge;
        private Double endingAmountFinanced;
        private Double endingTotalPaidBack;
        private Double endingOriginationFeeAmount;
        private Double endingMonthlyPaymentLast;
        private String brERuleVersion;
        private Integer directPayPartnerId;
        private String dealerCode;
        private Integer investmentTypeId;
        private Integer wholeLoanPrivateUserId;
        private Date wholeLoanStartDate;
        private Date wholeLoanEndDate;
        private String salesforceListingId;
        private Integer underwriterId;
        private Integer applicationSourceId;
        private String loanProductId;


        public Builder() {
        }

        public Builder withListingId(final Long id) {
            this.id = id;
            return this;
        }

        public Builder withUserId(final Integer userId) {
            this.userId = userId;
            return this;
        }

        public Builder withLoanOfferId(final String loanOfferId) {
            this.loanOfferId = loanOfferId;
            return this;
        }

        public Builder withAmount(final Double amount) {
            this.amount = amount;
            return this;
        }

        public Builder withMaxRate(final Double maxRate) {
            this.maxRate = maxRate;
            return this;
        }

        public Builder withCurrentRate(final Double currentRate) {
            this.currentRate = currentRate;
            return this;
        }

        public Builder withMaxRateToBid(final Double maxRateToBid) {
            this.maxRateToBid = maxRateToBid;
            return this;
        }

        public Builder withPurpose(final String purpose) {
            this.purpose = purpose;
            return this;
        }

        public Builder withStartTime(final Date startTime) {
            this.startTime = startTime;
            return this;
        }

        public Builder withDuration(final Integer duration) {
            this.duration = duration;
            return this;
        }

        public Builder withStatus(final String status) {
            this.status = status;
            return this;
        }

        public Builder withAccountId(final Integer accountId) {
            this.accountId = accountId;
            return this;
        }

        public Builder withCreationDate(final Date creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder withCreditGrade(final Integer creditGrade) {
            this.creditGrade = creditGrade;
            return this;
        }

        public Builder withTitle(final String title) {
            this.title = title;
            return this;
        }

        public Builder withFundingOption(final String fundingOption) {
            this.fundingOption = fundingOption;
            return this;
        }

        public Builder withBorrowerState(final String borrowerState) {
            this.borrowerState = borrowerState;
            return this;
        }

        public Builder withBusinessOrPersonal(final String businessOrPersonal) {
            this.businessOrPersonal = businessOrPersonal;
            return this;
        }

        public Builder withMonthlyIncome(final Double monthlyIncome) {
            this.monthlyIncome = monthlyIncome;
            return this;
        }

        public Builder withMonthlyDebt(final Double monthlyDebt) {
            this.monthlyDebt = monthlyDebt;
            return this;
        }

        public Builder withCurrentDTI(final Double currentDTI) {
            this.currentDTI = currentDTI;
            return this;
        }

        public Builder withEndDate(final Date endDate) {
            this.endDate = endDate;
            return this;
        }

        public Builder withResultCode(final String resultCode) {
            this.resultCode = resultCode;
            return this;
        }

        public Builder withBorrowerMailingAddressId(final Integer borrowerMailingAddressId) {
            this.borrowerMailingAddressId = borrowerMailingAddressId;
            return this;
        }

        public Builder withCompletionCodeId(final Integer completionCodeId) {
            this.completionCodeId = completionCodeId;
            return this;
        }

        public Builder withUserCreditProfileId(final Integer userCreditProfileId) {
            this.userCreditProfileId = userCreditProfileId;
            return this;
        }

        public Builder withUserHomeownershipId(final Integer userHomeownershipId) {
            this.userHomeownershipId = userHomeownershipId;
            return this;
        }

        public Builder withLastModifiedDate(final Date lastModifiedDate) {
            this.lastModifiedDate = lastModifiedDate;
            return this;
        }

        public Builder withIsDeleted(final Boolean isDeleted) {
            this.isDeleted = isDeleted;
            return this;
        }

        public Builder withAltKey(final String altKey) {
            this.altKey = altKey;
            return this;
        }

        public Builder withAltKeySearchId(final Integer altKeySearchId) {
            this.altKeySearchId = altKeySearchId;
            return this;
        }

        public Builder withLenderRateSpread(final Double lenderRateSpread) {
            this.lenderRateSpread = lenderRateSpread;
            return this;
        }

        public Builder withBorrowerAPR(final Double borrowerAPR) {
            this.borrowerAPR = borrowerAPR;
            return this;
        }

        public Builder withUserEmploymentDetailId(final Integer userEmploymentDetailId) {
            this.userEmploymentDetailId = userEmploymentDetailId;
            return this;
        }

        public Builder withIncomeRangeId(final Integer incomeRangeId) {
            this.incomeRangeId = incomeRangeId;
            return this;
        }

        public Builder withAmountFunded(final Double amountFunded) {
            this.amountFunded = amountFunded;
            return this;
        }

        public Builder withBidCount(final Integer bidCount) {
            this.bidCount = bidCount;
            return this;
        }

        public Builder withUserLoanHistorySnapshotId(final Integer userLoanHistorySnapshotId) {
            this.userLoanHistorySnapshotId = userLoanHistorySnapshotId;
            return this;
        }

        public Builder withTermsApprovalDate(final Date termsApprovalDate) {
            this.termsApprovalDate = termsApprovalDate;
            return this;
        }

        public Builder withListingCategoryId(final Integer listingCategoryId) {
            this.listingCategoryId = listingCategoryId;
            return this;
        }

        public Builder withProductSpecId(final String productSpecId) {
            this.productSpecId = productSpecId;
            return this;
        }

        public Builder withLoanId(final Integer loanId) {
            this.loanId = loanId;
            return this;
        }

        public Builder withLoanOfferingTypeId(final String loanOfferingTypeId) {
            this.loanOfferingTypeId = loanOfferingTypeId;
            return this;
        }

        public Builder withProsperRatingLossRangeId(final Integer prosperRatingLossRangeId) {
            this.prosperRatingLossRangeId = prosperRatingLossRangeId;
            return this;
        }

        public Builder withEstimatedLoss(final Double estimatedLoss) {
            this.estimatedLoss = estimatedLoss;
            return this;
        }

        public Builder withLoanSellerId(final Integer loanSellerId) {
            this.loanSellerId = loanSellerId;
            return this;
        }

        public Builder withCurrentYield(final Double currentYield) {
            this.currentYield = currentYield;
            return this;
        }

        public Builder withMaxYieldToBid(final Double maxYieldToBid) {
            this.maxYieldToBid = maxYieldToBid;
            return this;
        }

        public Builder withInvestmentProductReturnId(final Integer investmentProductReturnId) {
            this.investmentProductReturnId = investmentProductReturnId;
            return this;
        }

        public Builder withPartialFundingApproved(final Boolean partialFundingApproved) {
            this.partialFundingApproved = partialFundingApproved;
            return this;
        }

        public Builder withFundingThreshold(final Double fundingThreshold) {
            this.fundingThreshold = fundingThreshold;
            return this;
        }

        public Builder withAdverseActionGroupId(final Integer adverseActionGroupId) {
            this.adverseActionGroupId = adverseActionGroupId;
            return this;
        }

        public Builder withProsperRatingTypeId(final Integer prosperRatingTypeId) {
            this.prosperRatingTypeId = prosperRatingTypeId;
            return this;
        }

        public Builder withOriginationFeeAmount(final Double originationFeeAmount) {
            this.originationFeeAmount = originationFeeAmount;
            return this;
        }

        public Builder withOriginationFeePercent(final Double originationFeePercent) {
            this.originationFeePercent = originationFeePercent;
            return this;
        }

        public Builder withMonthlyPayment(final Double monthlyPayment) {
            this.monthlyPayment = monthlyPayment;
            return this;
        }

        public Builder withMonthlyPaymentLast(final Double monthlyPaymentLast) {
            this.monthlyPaymentLast = monthlyPaymentLast;
            return this;
        }

        public Builder withEffectiveYield(final Double effectiveYield) {
            this.effectiveYield = effectiveYield;
            return this;
        }

        public Builder withEstimatedLossImpact(final Double estimatedLossImpact) {
            this.estimatedLossImpact = estimatedLossImpact;
            return this;
        }

        public Builder withEstimatedReturn(final Double estimatedReturn) {
            this.estimatedReturn = estimatedReturn;
            return this;
        }

        public Builder withFinanceCharge(final Double financeCharge) {
            this.financeCharge = financeCharge;
            return this;
        }

        public Builder withAmountFinanced(final Double amountFinanced) {
            this.amountFinanced = amountFinanced;
            return this;
        }

        public Builder withTotalPaidBack(final Double totalPaidBack) {
            this.totalPaidBack = totalPaidBack;
            return this;
        }

        public Builder withEndingBorrowerAPR(final Double endingBorrowerAPR) {
            this.endingBorrowerAPR = endingBorrowerAPR;
            return this;
        }

        public Builder withEndingMonthlyPayment(final Double endingMonthlyPayment) {
            this.endingMonthlyPayment = endingMonthlyPayment;
            return this;
        }

        public Builder withEndingFinanceCharge(final Double endingFinanceCharge) {
            this.endingFinanceCharge = endingFinanceCharge;
            return this;
        }

        public Builder withEndingAmountFinanced(final Double endingAmountFinanced) {
            this.endingAmountFinanced = endingAmountFinanced;
            return this;
        }

        public Builder withEndingTotalPaidBack(final Double endingTotalPaidBack) {
            this.endingTotalPaidBack = endingTotalPaidBack;
            return this;
        }

        public Builder withEndingOriginationFeeAmount(final Double endingOriginationFeeAmount) {
            this.endingOriginationFeeAmount = endingOriginationFeeAmount;
            return this;
        }

        public Builder withEndingMonthlyPaymentLast(final Double endingMonthlyPaymentLast) {
            this.endingMonthlyPaymentLast = endingMonthlyPaymentLast;
            return this;
        }

        public Builder withBrERuleVersion(final String brERuleVersion) {
            this.brERuleVersion = brERuleVersion;
            return this;
        }

        public Builder withDirectPayPartnerId(final Integer directPayPartnerId) {
            this.directPayPartnerId = directPayPartnerId;
            return this;
        }

        public Builder withDealerCode(final String dealerCode) {
            this.dealerCode = dealerCode;
            return this;
        }

        public Builder withInvestmentTypeId(final Integer investmentTypeId) {
            this.investmentTypeId = investmentTypeId;
            return this;
        }

        public Builder withWholeLoanPrivateUserId(final Integer wholeLoanPrivateUserId) {
            this.wholeLoanPrivateUserId = wholeLoanPrivateUserId;
            return this;
        }

        public Builder withWholeLoanStartDate(final Date wholeLoanStartDate) {
            this.wholeLoanStartDate = wholeLoanStartDate;
            return this;
        }

        public Builder withWholeLoanEndDate(final Date wholeLoanEndDate) {
            this.wholeLoanEndDate = wholeLoanEndDate;
            return this;
        }

        public Builder withSalesforceListingId(final String salesforceListingId) {
            this.salesforceListingId = salesforceListingId;
            return this;
        }

        public Builder withUnderwriterId(final Integer underwriterId) {
            this.underwriterId = underwriterId;
            return this;
        }

        public Builder withApplicationSourceId(final Integer applicationSourceId) {
            this.applicationSourceId = applicationSourceId;
            return this;
        }

        public Builder withLoanProductId(final String loanProductId) {
            this.loanProductId = loanProductId;
            return this;
        }

        public Listings build() {
            return new Listings(this);
        }
    }
}
