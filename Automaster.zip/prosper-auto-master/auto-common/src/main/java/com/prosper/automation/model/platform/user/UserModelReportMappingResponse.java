package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 * Created by rchintapalli on 12/07/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserModelReportMappingResponse {

    protected List<Error> error;
    @JsonProperty("external_model_report_id")
    private UUID externalModelReportId;
    @JsonProperty("external_credit_report_id")
    private UUID externalCreditReportId;
    @JsonProperty("external_user_id")
    private UUID externalUserId;

    public UUID getExternalModelReportId() {
        return externalModelReportId;
    }

    public UUID getExternalCreditReportId() {
        return externalCreditReportId;
    }

    public UUID getExternalUserId() {
        return externalUserId;
    }

    public List<Error> getError() {
        return error;
    }
}
