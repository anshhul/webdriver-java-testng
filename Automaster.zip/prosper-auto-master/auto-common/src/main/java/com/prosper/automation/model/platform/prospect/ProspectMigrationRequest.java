package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 4/13/16.
 */
public final class ProspectMigrationRequest {

	@JsonProperty("start_date")
	private String startDate;

	@JsonProperty("end_date")
	private String endDate;

	@JsonProperty("limit")
	private Integer limit;

	private ProspectMigrationRequest(Builder builder) {
		startDate = builder.startDate;
		endDate = builder.endDate;
		limit = builder.limit;
	}

	public static final class Builder {

		private String startDate;
		private String endDate;
		private Integer limit;

		public Builder() {
		}

		public Builder withStartDate(String val) {
			startDate = val;
			return this;
		}

		public Builder withEndDate(String val) {
			endDate = val;
			return this;
		}

		public Builder withLimit(Integer val) {
			limit = val;
			return this;
		}

		public ProspectMigrationRequest build() {
			return new ProspectMigrationRequest(this);
		}
	}
}
