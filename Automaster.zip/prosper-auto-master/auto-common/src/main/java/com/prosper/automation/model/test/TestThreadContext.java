
package com.prosper.automation.model.test;

import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.util.Strings;

/**
 * Created by rsubramanyam on 6/13/16.
 */
public final class TestThreadContext {

    private static final String THREAD_CONTEXT_ABSENT_MESSAGE = Strings.EMPTY;
    public static final String SEPARATOR = ";";


    public static String getValue(String key) {
        if (ThreadContext.get(key) != null) {
            return ThreadContext.get(key);
        } else {
            return THREAD_CONTEXT_ABSENT_MESSAGE;
        }
    }

    public static void put(String key, String value) {
        ThreadContext.put(key, value);
    }

    public static void appendIfPresent(String key, String value) {
        String currentValue = ThreadContext.get(key);
        if (currentValue != null) {
            if(!currentValue.contains(value)) {
                ThreadContext.put(key, currentValue + SEPARATOR + value);
            }
        } else {
            ThreadContext.put(key, value);
        }
    }

    public static void clearCache() {
        for(TestThreadContextEnum value: TestThreadContextEnum.values()) {
            ThreadContext.remove(value.getName());
        }
    }
}
