package com.prosper.automation.model.platform.loan;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author Sonali Phatak
 *
 */

public class CreatePaymentRequest {

	@JsonProperty("bank_routing_number")
	public String bankRoutingNumber;

	@JsonProperty("bank_account_number")
	public String bankAccountNumber;

	@JsonProperty("additional_amount")
    public double additionalAmount;

	@JsonProperty("payment_post_date")
	public String paymentPostDate;

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

    public double getAdditionalAmount() {
		return additionalAmount;
	}

    public void setAdditionalAmount(double additionalAmount2) {
        this.additionalAmount = additionalAmount2;
	}

	public String getPaymentPostDate() {
		return paymentPostDate;
	}

	public void setPaymentPostDate(String paymentPostDate) {
		this.paymentPostDate = paymentPostDate;
	}

	public static class CreatePaymentRequestBuilder {
		private String bankRoutingNumber;
		private String bankAccountNumber;
        private double additionalAmount;
		private String paymentPostDate;

		public CreatePaymentRequest build() {
			CreatePaymentRequest request = new CreatePaymentRequest();
			request.setAdditionalAmount(additionalAmount);
			request.setBankAccountNumber(bankAccountNumber);
			request.setBankRoutingNumber(bankRoutingNumber);
			request.setPaymentPostDate(paymentPostDate);
			return request;

		}

		public CreatePaymentRequestBuilder bankRoutingNumber(
				String bankRoutingNumber) {
			this.bankRoutingNumber = bankRoutingNumber;
			return this;
		}

		public CreatePaymentRequestBuilder bankAccountNumber(
				String bankAccountNumber) {
			this.bankAccountNumber = bankAccountNumber;
			return this;
		}

		public CreatePaymentRequestBuilder additionalAmount(
				double additionalAmount) {
			this.additionalAmount = additionalAmount;
			return this;
		}

		public CreatePaymentRequestBuilder paymentPostDate(
				String paymentPostDate) {
			this.paymentPostDate = paymentPostDate;
			return this;
		}

	}
}
