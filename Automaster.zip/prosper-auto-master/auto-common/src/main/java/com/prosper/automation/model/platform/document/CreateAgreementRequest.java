
package com.prosper.automation.model.platform.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"agreement_transaction_id", "is_agreement_authorized"})
public final class CreateAgreementRequest {
    
    @JsonProperty("agreement_transaction_id")
    private UUID agreementTransactionId;
    @JsonProperty("is_agreement_authorized")
    private Boolean isAgreementAuthorized;
    
    
    private CreateAgreementRequest(final Builder builder) {
        agreementTransactionId = builder.agreementTransactionId;
        isAgreementAuthorized = builder.isAgreementAuthorized;
    }
    
    
    public static final class Builder {
        
        private UUID agreementTransactionId;
        private Boolean isAgreementAuthorized;
        
        
        public Builder() {
        }
        
        public Builder withAgreementTransactionId(final UUID agreementTransactionId) {
            this.agreementTransactionId = agreementTransactionId;
            return this;
        }
        
        public Builder withIsAgreementAuthorized(final Boolean isAgreementAuthorized) {
            this.isAgreementAuthorized = isAgreementAuthorized;
            return this;
        }
        
        public CreateAgreementRequest build() {
            return new CreateAgreementRequest(this);
        }
    }
}
