
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class SlpOfferRatingSummary {
    
    @JsonProperty("total_principal_balance")
    private Double totalPrincipalBalance;

    @JsonProperty("total_dirty_price")
    private Double totalDirtyPrice;
    
    @JsonProperty("rating")
    private String rating;

    @JsonProperty("term")
    private Integer term;

    @JsonProperty("loan_ids")
    private List<String> loanIds;

	public Double getTotalPrincipalBalance() {
		return totalPrincipalBalance;
	}

	public void setTotalPrincipalBalance(Double totalPrincipalBalance) {
		this.totalPrincipalBalance = totalPrincipalBalance;
	}

	public Double getTotalDirtyPrice() {
		return totalDirtyPrice;
	}

	public void setTotalDirtyPrice(Double totalDirtyPrice) {
		this.totalDirtyPrice = totalDirtyPrice;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public Integer getTerm() {
		return term;
	}

	public void setTerm(Integer term) {
		this.term = term;
	}

	public List<String> getLoanIds() {
		return loanIds;
	}

	public void setLoanIds(List<String> loanIds) {
		this.loanIds = loanIds;
	}
    
    
    

}
