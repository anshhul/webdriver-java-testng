
package com.prosper.automation.model.platform.prospect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;

import java.util.UUID;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class Prospect {

	@JsonProperty("prospect_id")
	private UUID prospectId;
	@JsonProperty("campaign_program_id")
	private UUID campaignProgramId;
	@JsonProperty("offer_code")
	private String offerCode;
	@JsonProperty("loan_purpose_id")
	private Integer loanPurposeId;
	@JsonProperty("loan_amount")
	private Double loanAmount;
	@JsonProperty("user_id")
	private Long userId;
	@JsonProperty("username")
	private String username;
	@JsonProperty("password")
	private String password;
	@JsonProperty("user_credit_pull_id")
	private Long userCreditPullId;
	@JsonProperty("experian_id")
	private String experianId;
	@JsonProperty("personal_info")
	private PersonalInfo personalInfo;
	@JsonProperty("address_info")
	private AddressInfo addressInfo;
	@JsonProperty("contact_info")
	private ContactInfo contactInfo;
	@JsonProperty("employment_info")
	private EmploymentInfo employmentInfo;
	@JsonProperty("bank_account_info")
	private BankAccountInfo bankAccountInfo;
	@JsonProperty("tracking_info")
	private TrackingInfo trackingInfo;
	@JsonProperty("partner_info")
	private PartnerInfo partnerInfo;
	@JsonProperty("partner_api_info")
	private PartnerApiInfo partnerApiInfo;
	@JsonProperty("credit_quality_id")
	private String creditQualityId;
	@JsonProperty("referral_id")
	private String referralId;
	@JsonProperty("legacy_id")
	private Long legacyId;
	@JsonProperty("offer_user_id")
	private String offerUserId;
	@JsonProperty("prosper_acceptance_code")
	private String prosperAcceptanceCode;
	@JsonProperty("agent_id")
	private Integer agentId;
	@JsonProperty("abandon_reason")
	private Integer abandonReason;
	@JsonProperty("institution_id")
	private Integer institutionId;
	@JsonProperty("third_party_id")
	private String thirdPartyId;
	@JsonProperty("relationship_id")
	private Integer relationshipId;
	@JsonProperty("relationship_name")
	private String relationshipName;
	@JsonProperty("merchant_client_name")
	private String merchantClientName;
	@JsonProperty("merchant_funnel_name")
	private String merchantFunnelName;

	public Prospect() {
	}

	private Prospect(final Builder builder) {
		prospectId = builder.prospectId;
		campaignProgramId = builder.campaignProgramId;
		offerCode = builder.offerCode;
		loanPurposeId = builder.loanPurposeId;
		loanAmount = builder.loanAmount;
		userId = builder.userId;
		username = builder.username;
		password = builder.password;
		userCreditPullId = builder.userCreditPullId;
		experianId = builder.experianId;
		personalInfo = builder.personalInfo;
		addressInfo = builder.addressInfo;
		contactInfo = builder.contactInfo;
		employmentInfo = builder.employmentInfo;
		bankAccountInfo = builder.bankAccountInfo;
		trackingInfo = builder.trackingInfo;
		partnerInfo = builder.partnerInfo;
		partnerApiInfo = builder.partnerApiInfo;
		creditQualityId = builder.creditQualityId;
		referralId = builder.referralId;
		legacyId = builder.legacyId;
		offerUserId = builder.offerUserId;
		prosperAcceptanceCode = builder.prosperAcceptanceCode;
		agentId = builder.agentId;
		abandonReason = builder.abandonReason;
		institutionId = builder.institutionId;
		thirdPartyId = builder.thirdPartyId;
		relationshipId = builder.relationshipId;
		relationshipName = builder.relationshipName;
		merchantClientName = builder.merchantClientName;
		merchantFunnelName = builder.merchantFunnelName;
	}

	@JsonIgnore
	public UUID getProspectId() {
		return prospectId;
	}

	public void setProspectId(UUID prospectId) {
		this.prospectId = prospectId;
	}

	@JsonIgnore
	public PersonalInfo getPersonalInfo() {
		return personalInfo;
	}

	public void setPersonalInfo(final PersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}

	@JsonIgnore
	public AddressInfo getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(final AddressInfo addressInfo) {
		this.addressInfo = addressInfo;
	}

	@JsonIgnore
	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(final ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	@JsonIgnore
	public EmploymentInfo getEmploymentInfo() {
		return employmentInfo;
	}

	@JsonIgnore
	public BankAccountInfo getBankAccountInfo() {
		return bankAccountInfo;
	}

	@JsonIgnore
	public String getOfferCode() {
		return offerCode;
	}

	@JsonIgnore
	public Double getLoanAmount() {
		return loanAmount;
	}

	@JsonIgnore
	public int getLoanPurposeId() {
		return loanPurposeId;
	}

	public TrackingInfo getTrackingInfo() {
		return trackingInfo;
	}

	public void setTrackingInfo(TrackingInfo trackingInfo) {
		this.trackingInfo = trackingInfo;
	}

	public PartnerInfo getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(PartnerInfo partnerInfo) {
		this.partnerInfo = partnerInfo;
	}

	public PartnerApiInfo getPartnerApiInfo() {
		return partnerApiInfo;
	}

	public void setPartnerApiInfo(PartnerApiInfo partnerApiInfo) {
		this.partnerApiInfo = partnerApiInfo;
	}

	public UUID getCampaignProgramId() {
		return campaignProgramId;
	}

	public Long getUserId() {
		return userId;
	}

	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return username;
	}

	public Long getUserCreditPullId() {
		return userCreditPullId;
	}

	public String getExperianId() {
		return experianId;
	}

	public String getCreditQualityId() {
		return creditQualityId;
	}

	public void setCreditQualityId(final String creditQualityId) {
		this.creditQualityId = creditQualityId;
	}

	public String getReferralId() {
		return referralId;
	}

	public Long getLegacyId() {
		return legacyId;
	}

	public String getProsperAcceptanceCode() {
		return prosperAcceptanceCode;
	}

	public String getOfferUserId() {
		return offerUserId;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public Integer getAbandonReason() {
		return abandonReason;
	}

	public Integer getInstitutionId() {
		return institutionId;
	}

	public String getThirdPartyId() {
		return thirdPartyId;
	}

	public Integer getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(Integer relationshipId) {
		this.relationshipId = relationshipId;
	}

	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	public String getMerchantClientName() {
		return merchantClientName;
	}

	public String getMerchantFunnelName() {
		return merchantFunnelName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Prospect prospect = (Prospect) o;
		return Objects.equal(prospectId, prospect.prospectId) && Objects.equal(campaignProgramId, prospect.campaignProgramId)
				&& Objects.equal(offerCode, prospect.offerCode) && Objects.equal(loanPurposeId, prospect.loanPurposeId)
				&& Objects.equal(loanAmount, prospect.loanAmount) && Objects.equal(userId, prospect.userId)
				&& Objects.equal(username, prospect.username) && Objects.equal(password, prospect.password)
				&& Objects.equal(userCreditPullId, prospect.userCreditPullId) && Objects.equal(experianId, prospect.experianId)
				&& Objects.equal(personalInfo, prospect.personalInfo) && Objects.equal(addressInfo, prospect.addressInfo)
				&& Objects.equal(contactInfo, prospect.contactInfo) && Objects.equal(employmentInfo, prospect.employmentInfo)
				&& Objects.equal(bankAccountInfo, prospect.bankAccountInfo) && Objects.equal(trackingInfo, prospect.trackingInfo)
				&& Objects.equal(partnerInfo, prospect.partnerInfo) && Objects.equal(partnerApiInfo, prospect.partnerApiInfo)
				&& Objects.equal(creditQualityId, prospect.creditQualityId) && Objects.equal(referralId, prospect.referralId)
				&& Objects.equal(legacyId, prospect.legacyId) && Objects.equal(offerUserId, prospect.offerUserId)
				&& Objects.equal(prosperAcceptanceCode, prospect.prosperAcceptanceCode)
				&& Objects.equal(agentId, prospect.agentId) && Objects.equal(abandonReason, prospect.abandonReason)
				&& Objects.equal(institutionId, prospect.institutionId) && Objects.equal(thirdPartyId, prospect.thirdPartyId)
				&& Objects.equal(relationshipId, prospect.relationshipId)
				&& Objects.equal(relationshipName, prospect.relationshipName)
				&& Objects.equal(merchantClientName, prospect.merchantClientName)
				&& Objects.equal(merchantFunnelName, prospect.merchantFunnelName);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(prospectId, campaignProgramId, offerCode, loanPurposeId, loanAmount, userId, username, password,
				userCreditPullId, experianId, personalInfo, addressInfo, contactInfo, employmentInfo, bankAccountInfo,
				trackingInfo, partnerInfo, partnerApiInfo, creditQualityId, referralId, legacyId, offerUserId,
				prosperAcceptanceCode, agentId, abandonReason, institutionId, thirdPartyId, relationshipId, relationshipName,
				merchantClientName, merchantFunnelName);
	}

	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}

	public static final class Builder {

		private UUID prospectId;
		private UUID campaignProgramId;
		private String offerCode;
		private Integer loanPurposeId;
		private Double loanAmount;
		private Long userId;
		private String username;
		private String password;
		private Long userCreditPullId;
		private String experianId;
		private PersonalInfo personalInfo;
		private AddressInfo addressInfo;
		private ContactInfo contactInfo;
		private EmploymentInfo employmentInfo;
		private BankAccountInfo bankAccountInfo;
		private TrackingInfo trackingInfo;
		private PartnerInfo partnerInfo;
		private PartnerApiInfo partnerApiInfo;
		private String creditQualityId;
		private String referralId;
		private Long legacyId;
		private String offerUserId;
		private String prosperAcceptanceCode;
		private Integer agentId;
		private Integer abandonReason;
		private Integer institutionId;
		private String thirdPartyId;
		private Integer relationshipId;
		private String relationshipName;
		private String merchantClientName;
		private String merchantFunnelName;

		public Builder() {
		}

		public Builder withProspectId(final UUID prospectId) {
			this.prospectId = prospectId;
			return this;
		}

		public Builder withCampaignProgramId(final UUID campaignProgramId) {
			this.campaignProgramId = campaignProgramId;
			return this;
		}

		public Builder withOfferCode(final String offerCode) {
			this.offerCode = offerCode;
			return this;
		}

		public Builder withLoanPurposeId(final Integer loanPurposeId) {
			this.loanPurposeId = loanPurposeId;
			return this;
		}

		public Builder withLoanAmount(final Double loanAmount) {
			this.loanAmount = loanAmount;
			return this;
		}

		public Builder withUserId(final Long userId) {
			this.userId = userId;
			return this;
		}

		public Builder withUsername(final String username) {
			this.username = username;
			return this;
		}

		public Builder withPassword(final String password) {
			this.password = password;
			return this;
		}

		public Builder withUserCreditPullId(final Long userCreditPullId) {
			this.userCreditPullId = userCreditPullId;
			return this;
		}

		public Builder withExperianId(final String experianId) {
			this.experianId = experianId;
			return this;
		}

		public Builder withPersonalInfo(final PersonalInfo personalInfo) {
			this.personalInfo = personalInfo;
			return this;
		}

		public Builder withAddressInfo(final AddressInfo addressInfo) {
			this.addressInfo = addressInfo;
			return this;
		}

		public Builder withContactInfo(final ContactInfo contactInfo) {
			this.contactInfo = contactInfo;
			return this;
		}

		public Builder withEmploymentInfo(final EmploymentInfo employmentInfo) {
			this.employmentInfo = employmentInfo;
			return this;
		}

		public Builder withBankAccountInfo(final BankAccountInfo bankAccountInfo) {
			this.bankAccountInfo = bankAccountInfo;
			return this;
		}

		public Builder withTrackingInfo(final TrackingInfo trackingInfo) {
			this.trackingInfo = trackingInfo;
			return this;
		}

		public Builder withPartnerInfo(final PartnerInfo partnerInfo) {
			this.partnerInfo = partnerInfo;
			return this;
		}

		public Builder withPartnerApiInfo(final PartnerApiInfo partnerApiInfo) {
			this.partnerApiInfo = partnerApiInfo;
			return this;
		}

		public Builder withCreditQualityId(final String creditQualityId) {
			this.creditQualityId = creditQualityId;
			return this;
		}

		public Builder withReferralId(final String referralId) {
			this.referralId = referralId;
			return this;
		}

		public Builder withLegacyId(final Long legacyId) {
			this.legacyId = legacyId;
			return this;
		}

		public Builder withOfferUserId(final String offerUserId) {
			this.offerUserId = offerUserId;
			return this;
		}

		public Builder withProsperAcceptanceCode(final String prosperAcceptanceCode) {
			this.prosperAcceptanceCode = prosperAcceptanceCode;
			return this;
		}

		public Prospect build() {
			return new Prospect(this);
		}

		public Builder withAgentId(final Integer agentId) {
			this.agentId = agentId;
			return this;
		}

		public Builder withAbandonReason(final Integer abandonReason) {
			this.abandonReason = abandonReason;
			return this;
		}

		public Builder withInstitutionId(final Integer institutionId) {
			this.institutionId = institutionId;
			return this;
		}

		public Builder withThirdPartyId(final String thirdPartyId) {
			this.thirdPartyId = thirdPartyId;
			return this;
		}

		public Builder withRelationshipId(final Integer relationshipId) {
			this.relationshipId = relationshipId;
			return this;
		}

		public Builder withRelationshipName(final String relationshipName) {
			this.relationshipName = relationshipName;
			return this;
		}

		public Builder withMerchantClientName(final String merchantClientName) {
			this.merchantClientName = merchantClientName;
			return this;
		}

		public Builder withMerchantFunnelName(final String merchantFunnelName) {
			this.merchantFunnelName = merchantFunnelName;
			return this;
		}
	}
}
