
package com.prosper.automation.model.platform.accounts;

public class VAccountsVO {

    private Long userid;
    private Double availableCashBalance;
    private Double pendingInvestmentsPrimaryMkt;
    private Double pendingInvestmentsSecondaryMkt;
    private Double pendingQuickInvestOrders;
    private Double totalPrincipalRecievedOnActiveNotes;
    private Double totalAmountInvestedOnActiveNotes;
    private Double outstandingPrincipalOnActiveNotes;
    private Double totalAccountValue;


    public static class VAccountsVOBuilder {

        private Double availableCashBalance;
        private Double outstandingPrincipalOnActiveNotes;
        private Double pendingInvestmentsPrimaryMkt;
        private Double pendingInvestmentsSecondaryMkt;
        private Double pendingQuickInvestOrders;
        private Double totalAccountValue;
        private Double totalAmountInvestedOnActiveNotes;
        private Double totalPrincipalRecievedOnActiveNotes;
        private Long userid;


        public VAccountsVOBuilder availableCashBalance(final Double value) {
            this.availableCashBalance = value;
            return this;
        }

        public VAccountsVO build() {
            final VAccountsVO result = new VAccountsVO();

            result.setAvailableCashBalance(availableCashBalance);
            result.setOutstandingPrincipalOnActiveNotes(outstandingPrincipalOnActiveNotes);
            result.setPendingInvestmentsPrimaryMkt(pendingInvestmentsPrimaryMkt);
            result.setPendingInvestmentsSecondaryMkt(pendingInvestmentsSecondaryMkt);
            result.setPendingQuickInvestOrders(pendingQuickInvestOrders);
            result.setTotalAccountValue(totalAccountValue);
            result.setTotalAmountInvestedOnActiveNotes(totalAmountInvestedOnActiveNotes);
            result.setTotalPrincipalRecievedOnActiveNotes(totalPrincipalRecievedOnActiveNotes);
            result.setUserid(userid);
            return result;
        }

        public VAccountsVOBuilder outstandingPrincipalOnActiveNotes(final Double value) {
            this.outstandingPrincipalOnActiveNotes = value;
            return this;
        }

        public VAccountsVOBuilder pendingInvestmentsPrimaryMkt(final Double value) {
            this.pendingInvestmentsPrimaryMkt = value;
            return this;
        }

        public VAccountsVOBuilder pendingInvestmentsSecondaryMkt(final Double value) {
            this.pendingInvestmentsSecondaryMkt = value;
            return this;
        }

        public VAccountsVOBuilder pendingQuickInvestOrders(final Double value) {
            this.pendingQuickInvestOrders = value;
            return this;
        }

        public VAccountsVOBuilder totalAccountValue(final Double value) {
            this.totalAccountValue = value;
            return this;
        }

        public VAccountsVOBuilder totalAmountInvestedOnActiveNotes(final Double value) {
            this.totalAmountInvestedOnActiveNotes = value;
            return this;
        }

        public VAccountsVOBuilder totalPrincipalRecievedOnActiveNotes(final Double value) {
            this.totalPrincipalRecievedOnActiveNotes = value;
            return this;
        }

        public VAccountsVOBuilder userid(final Long value) {
            this.userid = value;
            return this;
        }
    }
    
    
    public static VAccountsVOBuilder buildUpon(final VAccountsVO original) {
        final VAccountsVOBuilder builder = newBuilder();
        builder.availableCashBalance(original.getAvailableCashBalance());
        builder.outstandingPrincipalOnActiveNotes(original.getOutstandingPrincipalOnActiveNotes());
        builder.pendingInvestmentsPrimaryMkt(original.getPendingInvestmentsPrimaryMkt());
        builder.pendingInvestmentsSecondaryMkt(original.getPendingInvestmentsSecondaryMkt());
        builder.pendingQuickInvestOrders(original.getPendingQuickInvestOrders());
        builder.totalAccountValue(original.getTotalAccountValue());
        builder.totalAmountInvestedOnActiveNotes(original.getTotalAmountInvestedOnActiveNotes());
        builder.totalPrincipalRecievedOnActiveNotes(original.getTotalPrincipalRecievedOnActiveNotes());
        builder.userid(original.getUserid());
        return builder;
    }
    
    public static VAccountsVOBuilder newBuilder() {
        return new VAccountsVOBuilder();
    }
    
    public Double getAvailableCashBalance() {
        return availableCashBalance;
    }
    
    public Double getOutstandingPrincipalOnActiveNotes() {
        return outstandingPrincipalOnActiveNotes;
    }
    
    public Double getPendingInvestmentsPrimaryMkt() {
        return pendingInvestmentsPrimaryMkt;
    }
    
    public Double getPendingInvestmentsSecondaryMkt() {
        return pendingInvestmentsSecondaryMkt;
    }
    
    public Double getPendingQuickInvestOrders() {
        return pendingQuickInvestOrders;
    }
    
    public Double getTotalAccountValue() {
        return totalAccountValue;
    }
    
    public Double getTotalAmountInvestedOnActiveNotes() {
        return totalAmountInvestedOnActiveNotes;
    }
    
    public Double getTotalPrincipalRecievedOnActiveNotes() {
        return totalPrincipalRecievedOnActiveNotes;
    }
    
    public Long getUserid() {
        return userid;
    }
    
    public void setAvailableCashBalance(final Double availableCashBalance) {
        this.availableCashBalance = availableCashBalance;
    }
    
    public void setOutstandingPrincipalOnActiveNotes(final Double outstandingPrincipalOnActiveNotes) {
        this.outstandingPrincipalOnActiveNotes = outstandingPrincipalOnActiveNotes;
    }
    
    public void setPendingInvestmentsPrimaryMkt(final Double pendingInvestmentsPrimaryMkt) {
        this.pendingInvestmentsPrimaryMkt = pendingInvestmentsPrimaryMkt;
    }
    
    public void setPendingInvestmentsSecondaryMkt(final Double pendingInvestmentsSecondaryMkt) {
        this.pendingInvestmentsSecondaryMkt = pendingInvestmentsSecondaryMkt;
    }
    
    public void setPendingQuickInvestOrders(final Double pendingQuickInvestOrders) {
        this.pendingQuickInvestOrders = pendingQuickInvestOrders;
    }
    
    public void setTotalAccountValue(final Double totalAccountValue) {
        this.totalAccountValue = totalAccountValue;
    }
    
    public void setTotalAmountInvestedOnActiveNotes(final Double totalAmountInvestedOnActiveNotes) {
        this.totalAmountInvestedOnActiveNotes = totalAmountInvestedOnActiveNotes;
    }
    
    public void setTotalPrincipalRecievedOnActiveNotes(final Double totalPrincipalRecievedOnActiveNotes) {
        this.totalPrincipalRecievedOnActiveNotes = totalPrincipalRecievedOnActiveNotes;
    }
    
    public void setUserid(final Long userid) {
        this.userid = userid;
    }

}
