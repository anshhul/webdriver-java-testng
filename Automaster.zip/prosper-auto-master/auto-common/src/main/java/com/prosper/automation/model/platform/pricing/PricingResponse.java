
package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PricingResponse {

    @JsonProperty("pricingVersion")
    private String pricingVersion;
    @JsonProperty("monthlyPayment")
    private Double monthlyPayment;
    @JsonProperty("lastPayment")
    private Double lastPayment;
    @JsonProperty("loanAmount")
    private Double loanAmount;
    @JsonProperty("loanTerm")
    private String loanTerm;
    @JsonProperty("lossRate")
    private Double lossRate;
    @JsonProperty("baseLossRate")
    private Boolean baseLossRate;
    @JsonProperty("prosperRatingTypeId")
    private Long prosperRatingTypeId;
    @JsonProperty("borrowerRate")
    private Double borrowerRate;
    @JsonProperty("borrowerAPR")
    private Double borrowerAPR;
    @JsonProperty("lenderExpectedReturn")
    private Double lenderExpectedReturn;
    @JsonProperty("originationFee")
    private Double originationFee;
    @JsonProperty("originationFeeAmount")
    private Long originationFeeAmount;
    @JsonProperty("servicingFee")
    private Double servicingFee;
    @JsonProperty("adjInt")
    private Double adjInt;
    @JsonProperty("loanCap")
    private Double loanCap;
    @JsonProperty("valid")
    private Boolean valid;
    @JsonProperty("invalidReasons")
    private String invalidReasons;
    @JsonProperty("financeCharge")
    private Double financeCharge;
    @JsonProperty("cumulativeInterestPayment")
    private Double cumulativeInterestPayment;
    @JsonProperty("firstPaymentDueDate")
    private String firstPaymentDueDate;
    @JsonProperty("lastPaymentDueDate")
    private String lastPaymentDueDate;
    @JsonProperty("pricingBins")
    private List<PricingBin> pricingBins = new ArrayList();
    @JsonProperty("partialFundingEligible")
    private Boolean partialFundingEligible;


    public PricingResponse() {
    }

    private PricingResponse(final Builder builder) {
        pricingVersion = builder.pricingVersion;
        lastPayment = builder.lastPayment;
        loanAmount = builder.loanAmount;
        loanTerm = builder.loanTerm;
        lossRate = builder.lossRate;
        baseLossRate = builder.baseLossRate;
        prosperRatingTypeId = builder.prosperRatingTypeId;
        borrowerRate = builder.borrowerRate;
        borrowerAPR = builder.borrowerAPR;
        lenderExpectedReturn = builder.lenderExpectedReturn;
        originationFee = builder.originationFee;
        originationFeeAmount = builder.originationFeeAmount;
        servicingFee = builder.servicingFee;
        adjInt = builder.adjInt;
        loanCap = builder.loanCap;
        valid = builder.valid;
        invalidReasons = builder.invalidReasons;
        financeCharge = builder.financeCharge;
        cumulativeInterestPayment = builder.cumulativeInterestPayment;
        firstPaymentDueDate = builder.firstPaymentDueDate;
        lastPaymentDueDate = builder.lastPaymentDueDate;
        pricingBins = builder.pricingBins;
        partialFundingEligible = builder.partialFundingEligible;
    }

    @JsonIgnore
    public Double getLoanAmount() {
        return loanAmount;
    }

    @JsonIgnore
    public boolean isValid() {
        return valid;
    }

    @JsonIgnore
    public String getPricingVersion() {
        return pricingVersion;
    }

    @JsonIgnore
    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    @JsonIgnore
    public Double getLastPayment() {
        return lastPayment;
    }

    @JsonIgnore
    public Double getLossRate() {
        return lossRate;
    }

    @JsonIgnore
    public Double getBorrowerApr() {
        return borrowerAPR;
    }

    @Override
    public String toString() {
        return "PricingResponse{" +
                "pricingVersion='" + pricingVersion + '\'' +
                ", monthlyPayment=" + monthlyPayment +
                ", lastPayment=" + lastPayment +
                ", loanAmount=" + loanAmount +
                ", loanTerm='" + loanTerm + '\'' +
                ", lossRate=" + lossRate +
                ", baseLossRate=" + baseLossRate +
                ", prosperRatingTypeId=" + prosperRatingTypeId +
                ", borrowerRate=" + borrowerRate +
                ", borrowerAPR=" + borrowerAPR +
                ", lenderExpectedReturn=" + lenderExpectedReturn +
                ", originationFee=" + originationFee +
                ", originationFeeAmount=" + originationFeeAmount +
                ", servicingFee=" + servicingFee +
                ", adjInt=" + adjInt +
                ", loanCap=" + loanCap +
                ", valid=" + valid +
                ", invalidReasons='" + invalidReasons + '\'' +
                ", financeCharge=" + financeCharge +
                ", cumulativeInterestPayment=" + cumulativeInterestPayment +
                ", firstPaymentDueDate='" + firstPaymentDueDate + '\'' +
                ", lastPaymentDueDate='" + lastPaymentDueDate + '\'' +
                ", pricingBins=" + pricingBins +
                ", partialFundingEligible=" + partialFundingEligible +
                '}';
    }

    @JsonIgnore
    public Double getOriginationFee() {
        return originationFee;
    }

    @JsonIgnore
    public Double getLoanCap() {
        return loanCap;
    }

    public Double getFinanceCharge() {
        return financeCharge;
    }

    public Boolean getPartialFunding() {
        return partialFundingEligible;
    }

    public List<PricingBin> getPricingBins() {
        return pricingBins;
    }


    public static final class Builder {

        private String pricingVersion;
        private Double lastPayment;
        private Double loanAmount;
        private String loanTerm;
        private Double lossRate;
        private Boolean baseLossRate;
        private Long prosperRatingTypeId;
        private Double borrowerRate;
        private Double borrowerAPR;
        private Double lenderExpectedReturn;
        private Double originationFee;
        private Long originationFeeAmount;
        private Double servicingFee;
        private Double adjInt;
        private Double loanCap;
        private Boolean valid;
        private String invalidReasons;
        private Double financeCharge;
        private Double cumulativeInterestPayment;
        private String firstPaymentDueDate;
        private String lastPaymentDueDate;
        private List<PricingBin> pricingBins;
        private Boolean partialFundingEligible;


        public Builder() {
        }

        public Builder withPricingVersion(final String pricingVersion) {
            this.pricingVersion = pricingVersion;
            return this;
        }

        public Builder withLastPayment(final Double lastPayment) {
            this.lastPayment = lastPayment;
            return this;
        }

        public Builder withLoanAmount(final Double loanAmount) {
            this.loanAmount = loanAmount;
            return this;
        }

        public Builder withLoanTerm(final String loanTerm) {
            this.loanTerm = loanTerm;
            return this;
        }

        public Builder withLossRate(final Double lossRate) {
            this.lossRate = lossRate;
            return this;
        }

        public Builder withBaseLossRate(final Boolean baseLossRate) {
            this.baseLossRate = baseLossRate;
            return this;
        }

        public Builder withProsperRatingTypeId(final Long prosperRatingTypeId) {
            this.prosperRatingTypeId = prosperRatingTypeId;
            return this;
        }

        public Builder withBorrowerRate(final Double borrowerRate) {
            this.borrowerRate = borrowerRate;
            return this;
        }

        public Builder withBorrowerAPR(final Double borrowerAPR) {
            this.borrowerAPR = borrowerAPR;
            return this;
        }

        public Builder withLenderExpectedReturn(final Double lenderExpectedReturn) {
            this.lenderExpectedReturn = lenderExpectedReturn;
            return this;
        }

        public Builder withOriginationFee(final Double originationFee) {
            this.originationFee = originationFee;
            return this;
        }

        public Builder withOriginationFeeAmount(final Long originationFeeAmount) {
            this.originationFeeAmount = originationFeeAmount;
            return this;
        }

        public Builder withServicingFee(final Double servicingFee) {
            this.servicingFee = servicingFee;
            return this;
        }

        public Builder withAdjInt(final Double adjInt) {
            this.adjInt = adjInt;
            return this;
        }

        public Builder withLoanCap(final Double loanCap) {
            this.loanCap = loanCap;
            return this;
        }

        public Builder withValid(final Boolean valid) {
            this.valid = valid;
            return this;
        }

        public Builder withInvalidReasons(final String invalidReasons) {
            this.invalidReasons = invalidReasons;
            return this;
        }

        public Builder withFinanceCharge(final Double financeCharge) {
            this.financeCharge = financeCharge;
            return this;
        }

        public Builder withCumulativeInterestPayment(final Double cumulativeInterestPayment) {
            this.cumulativeInterestPayment = cumulativeInterestPayment;
            return this;
        }

        public Builder withFirstPaymentDueDate(final String firstPaymentDueDate) {
            this.firstPaymentDueDate = firstPaymentDueDate;
            return this;
        }

        public Builder withLastPaymentDueDate(final String lastPaymentDueDate) {
            this.lastPaymentDueDate = lastPaymentDueDate;
            return this;
        }

        public Builder withPricingBins(final List<PricingBin> pricingBins) {
            this.pricingBins = pricingBins;
            return this;
        }

        public Builder withPartialFundingEligible(final Boolean partialFundingEligible) {
            this.partialFundingEligible = partialFundingEligible;
            return this;
        }

        public PricingResponse build() {
            return new PricingResponse(this);
        }
    }
}
