
package com.prosper.automation.model.platform.loan;

public class GetLoanAndOwnerInfoVO {
    
    private Long recipientId;
    private Integer loanId;
    private String email;


    public static class GetLoanAndOwnerInfoVOBuilder {

        private String email;
        private Integer loanId;
        private Long recipientId;


        public GetLoanAndOwnerInfoVO build() {
            final GetLoanAndOwnerInfoVO result = new GetLoanAndOwnerInfoVO();

            result.setEmail(email);
            result.setLoanId(loanId);
            result.setRecipientId(recipientId);
            return result;
        }

        public GetLoanAndOwnerInfoVOBuilder email(final String value) {
            this.email = value;
            return this;
        }

        public GetLoanAndOwnerInfoVOBuilder loanId(final Integer value) {
            this.loanId = value;
            return this;
        }

        public GetLoanAndOwnerInfoVOBuilder recipientId(final Long value) {
            this.recipientId = value;
            return this;
        }
    }
    
    
    public static GetLoanAndOwnerInfoVOBuilder buildUpon(final GetLoanAndOwnerInfoVO original) {
        final GetLoanAndOwnerInfoVOBuilder builder = newBuilder();
        builder.email(original.getEmail());
        builder.loanId(original.getLoanId());
        builder.recipientId(original.getRecipientId());
        return builder;
    }
    
    public static GetLoanAndOwnerInfoVOBuilder newBuilder() {
        return new GetLoanAndOwnerInfoVOBuilder();
    }
    
    public String getEmail() {
        return email;
    }
    
    public Integer getLoanId() {
        return loanId;
    }
    
    public Long getRecipientId() {
        return recipientId;
    }
    
    public void setEmail(final String email) {
        this.email = email;
    }
    
    public void setLoanId(final Integer loanId) {
        this.loanId = loanId;
    }
    
    public void setRecipientId(final Long recipientId) {
        this.recipientId = recipientId;
    }

}
