
package com.prosper.automation.model.platform.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;

import java.util.List;
import java.util.UUID;

/**
 * Created by pbudiono on 7/21/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class EmailMessage {

    @JsonProperty("message_request_key")
    private UUID messageRequestKey;
    @JsonProperty("reference_id")
    private String referenceId;
    @JsonProperty("reference_type")
    private String referenceType;
    @JsonProperty("legacy_template_id")
    private Integer legacyTemplateId;
    @JsonProperty("template_code")
    private String templateCode;
    @JsonProperty("is_shown_on_public_site")
    private Boolean isShownOnPublicSite;
    @JsonProperty("is_sent_externally")
    private Boolean isSentExternally;
    @JsonProperty("to_address")
    private String toAddress;
    @JsonProperty("from_address")
    private String fromAddress;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("message")
    private String message;
    @JsonProperty("bcc_addresses")
    private List<String> bccAddress;
    @JsonProperty("campaign_code")
    private String campaignCode;
    @JsonProperty("result")
    private List<EmailMessage> result;
    @JsonProperty("is_deleted")
    private Boolean isDeleted;
    @JsonProperty("is_user_read")
    private boolean isUserRead;


    public EmailMessage() {
    }

    private EmailMessage(Builder builder) {
        messageRequestKey = builder.messageRequestKey;
        referenceId = builder.referenceId;
        referenceType = builder.referenceType;
        legacyTemplateId = builder.legacyTemplateId;
        templateCode = builder.templateCode;
        isShownOnPublicSite = builder.isShowOnPublicSite;
        isSentExternally = builder.isSentExternally;
        toAddress = builder.toAddress;
        fromAddress = builder.fromAddress;
        subject = builder.subject;
        message = builder.message;
        bccAddress = builder.bccAddress;
        campaignCode = builder.campaignCode;
    }

    @JsonIgnore
    public Boolean getShownOnPublicSite() {
        return isShownOnPublicSite;
    }

    @JsonIgnore
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonIgnore
    public Boolean getSentExternally() {
        return isSentExternally;
    }

    public void setSentExternally(Boolean sentExternally) {
        isSentExternally = sentExternally;
    }

    @JsonIgnore
    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    @JsonIgnore
    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    @JsonIgnore
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @JsonIgnore
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @JsonIgnore
    public List<String> getBccAddress() {
        return bccAddress;
    }

    public void setBccAddress(List<String> bccAddress) {
        this.bccAddress = bccAddress;
    }

    public List<EmailMessage> getResult() {
        return result;
    }

    @JsonIgnore
    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    @JsonIgnore
    public String getReferenceType() {
        return referenceType;
    }

    public void setReferenceType(String referenceType) {
        this.referenceType = referenceType;
    }

    @JsonIgnore
    public UUID getMessageRequestKey() {
        return messageRequestKey;
    }

    public void setShowOnPublicSite(Boolean showOnPublicSite) {
        isShownOnPublicSite = showOnPublicSite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EmailMessage that = (EmailMessage) o;
        return Objects.equal(referenceId, that.referenceId) &&
                Objects.equal(referenceType, that.referenceType) &&
                Objects.equal(legacyTemplateId, that.legacyTemplateId) &&
                Objects.equal(templateCode, that.templateCode) &&
                Objects.equal(isShownOnPublicSite, that.isShownOnPublicSite) &&
                Objects.equal(isSentExternally, that.isSentExternally) &&
                Objects.equal(toAddress, that.toAddress) &&
                Objects.equal(fromAddress, that.fromAddress) &&
                Objects.equal(subject, that.subject) &&
                Objects.equal(bccAddress, that.bccAddress);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(referenceId, referenceType, legacyTemplateId, templateCode, isShownOnPublicSite,
                isSentExternally, toAddress, fromAddress, subject, message, bccAddress);
    }

    @JsonIgnore
    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode;
    }

    @JsonIgnore
    public Integer getLegacyTemplateId() {
        return legacyTemplateId;
    }

    public void setLegacyTemplateId(Integer legacyTemplateId) {
        this.legacyTemplateId = legacyTemplateId;
    }

    public void setIsShownToPublicSite(final Boolean isShownToPublicSite) {
        this.isShownOnPublicSite = isShownToPublicSite;
    }

    @JsonIgnore
    public Boolean getIsShownOnPublicSite() {
        return isShownOnPublicSite;
    }

    @JsonIgnore
    public Boolean getIsSentExternally() {
        return isSentExternally;
    }

    public void setIsSentExternally(Boolean isSentExternally) {
        this.isSentExternally = isSentExternally;
    }

    @JsonIgnore
    public boolean getIsUserRead() {
        return isUserRead;
    }

    @JsonIgnore
    public String getCampaignCode() { return campaignCode; }


    public static final class Builder {

        private UUID messageRequestKey;
        private String referenceId;
        private String referenceType;
        private Integer legacyTemplateId;
        private String templateCode;
        private Boolean isShowOnPublicSite;
        private Boolean isSentExternally;
        private String toAddress;
        private String fromAddress;
        private String subject;
        private String message;
        private List<String> bccAddress;
        private String campaignCode;


        public Builder() {
        }

        public Builder withMessageRequestKey(UUID val) {
            messageRequestKey = val;
            return this;
        }

        public Builder withReferenceId(String val) {
            referenceId = val;
            return this;
        }

        public Builder withReferenceType(String val) {
            referenceType = val;
            return this;
        }

        public Builder withLegacyTemplateId(Integer val) {
            legacyTemplateId = val;
            return this;
        }

        public Builder withTemplateCode(String val) {
            templateCode = val;
            return this;
        }

        public Builder withIsShowOnPublicSite(Boolean val) {
            isShowOnPublicSite = val;
            return this;
        }

        public Builder withIsSentExternally(Boolean val) {
            isSentExternally = val;
            return this;
        }

        public Builder withToAddress(String val) {
            toAddress = val;
            return this;
        }

        public Builder withFromAddress(String val) {
            fromAddress = val;
            return this;
        }

        public Builder withSubject(String val) {
            subject = val;
            return this;
        }

        public Builder withMessage(String val) {
            message = val;
            return this;
        }

        public Builder withBccAddress(List<String> val) {
            bccAddress = val;
            return this;
        }

        public Builder withCampaignCode(String val){
            campaignCode = val;
            return this;
        }

        public EmailMessage build() {
            return new EmailMessage(this);
        }
    }
}
