
package com.prosper.automation.model.wcf.allocateListing;

public class AllocateFractionalRequest {

    public static String requestStr =
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">" +
                    "<soapenv:Header/>" +
                    "<soapenv:Body>" +
                    "<tem:ConvertListingsToWLoans>" +
                    "<tem:request>" +
                    "<pros:LoansToConvert xmlns:pros=\"http://schemas.datacontract.org/2004/07/Prosper.Reporting.Publication.DataContract\">"
                    + "<pros:WholeLoanConversionObject>" +
                    "<pros:ListingID>%s</pros:ListingID>" +
                    "<pros:TypeOfInvestment>%s</pros:TypeOfInvestment>" +
                    "</pros:WholeLoanConversionObject>" +
                    "</pros:LoansToConvert>" +
                    "</tem:request>" +
                    "</tem:ConvertListingsToWLoans>" +
                    "</soapenv:Body>" +
                    "</soapenv:Envelope>";


    public static final class Builder {

        private String listingID;
        private String investmentType;


        public Builder withListingID(final String listingID) {
            this.listingID = listingID;
            return this;
        }

        public Builder withInvestmentType(final String investmentType) {
            this.investmentType = investmentType;
            return this;
        }

        public String build() {
            return String.format(requestStr, listingID, investmentType);
        }
    }
}
