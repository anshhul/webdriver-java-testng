
package com.prosper.automation.model.platform.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class OccupationResponse {
    
    @JsonProperty("result")
    private List<Occupation> result;
    
    @JsonProperty("result_count")
    private Integer resultCount;
    
    @JsonProperty("total_count")
    private Integer totalCount;
    
    
    @JsonIgnore
    public int getResultCount() {
        return resultCount;
    }
    
    @JsonIgnore
    public int getTotalCount() {
        return totalCount;
    }
    
    @JsonIgnore
    public List<Occupation> getResult() {
        return result;
    }
}
