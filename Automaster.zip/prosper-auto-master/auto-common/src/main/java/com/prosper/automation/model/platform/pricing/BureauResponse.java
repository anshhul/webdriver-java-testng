package com.prosper.automation.model.platform.pricing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prosper.automation.exception.AutomationException;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * Created by ppatil on 12/6/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BureauResponse {


    @JsonProperty("score_card_type")
    private String scorecardName;
    @JsonProperty("probability_score")
    private Double probabilityScore;
    @JsonProperty("score_variables")
    private Map<String, ScoreVariable> scoreVariables = new HashMap<>();
    @JsonProperty("top_four_reasons")
    private List<ScoreVariable> topFourReasons;

    public List<ScoreVariable> getTopFourReasons() {
        return topFourReasons;
    }

    public void setTopFourReasons(List<ScoreVariable> topFourReasons) {
        this.topFourReasons = topFourReasons;
    }

    public String getScorecardName() {
        return scorecardName;
    }

    public void setScorecardName(String scorecardName) {
        this.scorecardName = scorecardName;
    }

    public Double getProbabilityScore() {
        return probabilityScore;
    }

    public void setProbabilityScore(Double probabilityScore) {
        this.probabilityScore = probabilityScore;
    }

    public BureauResponse() {
    }


    private BureauResponse(final Builder builder) {
        scorecardName = builder.scorecardName;
        probabilityScore = builder.probabilityScore;
        topFourReasons = builder.topFourReasons;
    }

    public static final class Builder {
        private String scorecardName;
        private List<ScoreVariable> topFourReasons;
        private Double probabilityScore;

        public Builder() {
        }

        public Builder withScoreCardName(final String scorecardName) {
            this.scorecardName = scorecardName;
            return this;
        }

        public Builder withProbablityScore(final Double probabilityScore) {
            this.probabilityScore = probabilityScore;
            return this;
        }

        public Builder withTopFourReasons(List<ScoreVariable> topFourReasons) {
            this.topFourReasons = topFourReasons;
            return this;
        }
    }


}
