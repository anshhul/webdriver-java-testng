
package com.prosper.automation.model.platform.slp;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class GetAllSlpInvestorsResponse {
    
    @JsonProperty("result")
    private List<SlpInvestorConfiguration> result;

    @JsonProperty("result_count")
    private Integer resultCount;

    @JsonProperty("total_count")
    private Integer totalCount;
    
    
    /**
     * @return
     */
    public List<SlpInvestorConfiguration> getResult() {
        return result;
    }
    
    /**
     * @return
     */
    public Integer getResultCount() {
        return resultCount;
    }
    
    /**
     * @return
     */
    public Integer getTotalCount() {
        return totalCount;
    }
    
    /**
     * @param result
     */
    public void setResult(final List<SlpInvestorConfiguration> result) {
        this.result = result;
    }
    
    /**
     * @param resultCount
     */
    public void setResultCount(final Integer resultCount) {
        this.resultCount = resultCount;
    }
    
    /**
     * @param totalCount
     */
    public void setTotalCount(final Integer totalCount) {
        this.totalCount = totalCount;
    }
    
}
