
package com.prosper.automation.model.platform.bankAccount;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"verification_consecutive_failures", "account_verification_status_type", "verification_date_time",
        "account_verification_method_type", "is_default", "creation_date_time", "account_type_code", "account_id", "user_id",
        "nick_name", "last_verification_account_date_time", "modified_date_time", "error_code", "category", "account_status_type"})
public final class Account {
    
    @JsonProperty("verification_consecutive_failures")
    private Integer verificationConsecutiveFailures;
    @JsonProperty("account_verification_status_type")
    private AccountVerificationStatusType accountVerificationStatusType;
    @JsonProperty("verification_date_time")
    private String verificationDateTime;
    @JsonProperty("account_verification_method_type")
    private AccountVerificationMethodType accountVerificationMethodType;
    @JsonProperty("is_default")
    private Boolean isDefault;
    @JsonProperty("creation_date_time")
    private String creationDateTime;
    @JsonProperty("account_type_code")
    private AccountTypeCode accountTypeCode;
    @JsonProperty("account_id")
    private Long accountId;
    @JsonProperty("user_id")
    private Integer userId;
    @JsonProperty("nick_name")
    private String nickName;
    @JsonProperty("last_verification_account_date_time")
    private String lastVerificationAccountDateTime;
    @JsonProperty("modified_date_time")
    private String modifiedDateTime;
    @JsonProperty("error_code")
    private Integer errorCode;
    @JsonProperty("category")
    private String category;
    @JsonProperty("account_status_type")
    private AccountStatusType accountStatusType;
    
    
    public Account() {
    }
    
    private Account(final Builder builder) {
        verificationConsecutiveFailures = builder.verificationConsecutiveFailures;
        accountVerificationStatusType = builder.accountVerificationStatusType;
        verificationDateTime = builder.verificationDateTime;
        accountVerificationMethodType = builder.accountVerificationMethodType;
        isDefault = builder.isDefault;
        creationDateTime = builder.creationDateTime;
        accountTypeCode = builder.accountTypeCode;
        accountId = builder.accountId;
        userId = builder.userId;
        nickName = builder.nickName;
        lastVerificationAccountDateTime = builder.lastVerificationAccountDateTime;
        modifiedDateTime = builder.modifiedDateTime;
        errorCode = builder.errorCode;
        category = builder.category;
        accountStatusType = builder.accountStatusType;
    }
    
    @JsonIgnore
    public Long getAccountId() {
        return accountId;
    }
    
    
    public static enum AccountStatusType {
        
        CREATED("CREATED"), INVALID("INVALID"), ACTIVE("ACTIVE"), FROZEN("FROZEN"), EXPIRED("EXPIRED"), CLOSING("CLOSING"),
        CLOSED("CLOSED");
        
        private final String value;
        
        
        AccountStatusType(final String value) {
            this.value = value;
        }
    }
    
    public static enum AccountTypeCode {
        
        BANK("BANK"), CREDITCARD("CREDITCARD"), FBO("FBO"), FEE("FEE"), INTEREST("INTEREST"), LISTING("LISTING"), LOAN("LOAN"),
        ORIGINATION("ORIGINATION"), RESERVE("RESERVE"), STANDINGBID("STANDINGBID"), UNSPECIFIED("UNSPECIFIED");
        
        private final String value;
        
        
        AccountTypeCode(final String value) {
            this.value = value;
        }
    }
    
    public enum AccountVerificationMethodType {
        
        NOT_STARTED("NotStarted"), MTV_1("MTV1"), YODLEE_IAV("YodleeIAV"), MTV("MTV"), FAX_OR_MAIL("FaxOrMail"), IAV_NAME_AUTO(
                "IAVNameAuto"), IAV_NAME_MANUAL("IAVNameManual"), BANK_CALL("BankCall"), BANK_CALL_CONFERENCE(
                "BankCallConference"), CHECK_REVIEW_MAIL("CheckReviewMail"), CHECK_REVIEW_FAX("CheckReviewFax"),
        SECURITY_OVERRIDE("SecurityOverride"), AAS("AAS");
        
        private final String value;
        
        
        AccountVerificationMethodType(final String value) {
            this.value = value;
        }
    }
    
    public static enum AccountVerificationStatusType {
        
        IN_PROGRESS("InProgress"), UNABLE("Unable"), VERIFIED("Verified"), FAILED("Failed");
        
        private final String value;
        
        
        AccountVerificationStatusType(final String value) {
            this.value = value;
        }
    }
    
    public static final class Builder {
        
        private Integer verificationConsecutiveFailures;
        private AccountVerificationStatusType accountVerificationStatusType;
        private String verificationDateTime;
        private AccountVerificationMethodType accountVerificationMethodType;
        private Boolean isDefault;
        private String creationDateTime;
        private AccountTypeCode accountTypeCode;
        private Long accountId;
        private Integer userId;
        private String nickName;
        private String lastVerificationAccountDateTime;
        private String modifiedDateTime;
        private Integer errorCode;
        private String category;
        private AccountStatusType accountStatusType;
        
        
        public Builder() {
        }
        
        public Builder withVerificationConsecutiveFailures(final Integer verificationConsecutiveFailures) {
            this.verificationConsecutiveFailures = verificationConsecutiveFailures;
            return this;
        }
        
        public Builder withAccountVerificationStatusType(final AccountVerificationStatusType accountVerificationStatusType) {
            this.accountVerificationStatusType = accountVerificationStatusType;
            return this;
        }
        
        public Builder withVerificationDateTime(final String verificationDateTime) {
            this.verificationDateTime = verificationDateTime;
            return this;
        }
        
        public Builder withAccountVerificationMethodType(final AccountVerificationMethodType accountVerificationMethodType) {
            this.accountVerificationMethodType = accountVerificationMethodType;
            return this;
        }
        
        public Builder withIsDefault(final Boolean isDefault) {
            this.isDefault = isDefault;
            return this;
        }
        
        public Builder withCreationDateTime(final String creationDateTime) {
            this.creationDateTime = creationDateTime;
            return this;
        }
        
        public Builder withAccountTypeCode(final AccountTypeCode accountTypeCode) {
            this.accountTypeCode = accountTypeCode;
            return this;
        }
        
        public Builder withAccountId(final Long accountId) {
            this.accountId = accountId;
            return this;
        }
        
        public Builder withUserId(final Integer userId) {
            this.userId = userId;
            return this;
        }
        
        public Builder withNickName(final String nickName) {
            this.nickName = nickName;
            return this;
        }
        
        public Builder withLastVerificationAccountDateTime(final String lastVerificationAccountDateTime) {
            this.lastVerificationAccountDateTime = lastVerificationAccountDateTime;
            return this;
        }
        
        public Builder withModifiedDateTime(final String modifiedDateTime) {
            this.modifiedDateTime = modifiedDateTime;
            return this;
        }
        
        public Builder withErrorCode(final Integer errorCode) {
            this.errorCode = errorCode;
            return this;
        }
        
        public Builder withCategory(final String category) {
            this.category = category;
            return this;
        }
        
        public Builder withAccountStatusType(final AccountStatusType accountStatusType) {
            this.accountStatusType = accountStatusType;
            return this;
        }
        
        public Account build() {
            return new Account(this);
        }
    }
}
