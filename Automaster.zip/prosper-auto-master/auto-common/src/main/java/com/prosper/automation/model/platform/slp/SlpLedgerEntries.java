
package com.prosper.automation.model.platform.slp;

/**
 *
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author pchaturvedi
 */
public class SlpLedgerEntries {
    
    private Integer accountId;
    private Double amount;
    private String creditOrDebit;
    private Integer entryTypeCode;
    private Integer loanId;
    private String referenceId;
    private Integer category;
    
    
    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getCreditOrDebit() {
        return creditOrDebit;
    }

    public void setCreditOrDebit(String creditOrDebit) {
        this.creditOrDebit = creditOrDebit;
    }

    public Integer getEntryTypeCode() {
        return entryTypeCode;
    }

    public void setEntryTypeCode(Integer entryTypeCode) {
        this.entryTypeCode = entryTypeCode;
    }

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }


    public static class SlpLedgerEntriesBuilder {
        
        private Integer accountId;
        private Double amount;
        private String creditOrDebit;
        private Integer entryTypeCode;
        private Integer loanId;
        private String referenceId;
        private Integer category;
        
        
        public SlpLedgerEntriesBuilder accountId(Integer value) {
            this.accountId = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder amount(Double value) {
            this.amount = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder creditOrDebit(String value) {
            this.creditOrDebit = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder entryTypeCode(Integer value) {
            this.entryTypeCode = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder loanId(Integer value) {
            this.loanId = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder referenceId(String value) {
            this.referenceId = value;
            return this;
        }
        
        public SlpLedgerEntriesBuilder category(Integer value) {
            this.category = value;
            return this;
        }
        
        public SlpLedgerEntries build() {
            final SlpLedgerEntries result = new SlpLedgerEntries();
            
            result.setAccountId(accountId);
            result.setAmount(amount);
            result.setCreditOrDebit(creditOrDebit);
            result.setEntryTypeCode(entryTypeCode);
            result.setLoanId(loanId);
            result.setReferenceId(referenceId);
            result.setCategory(category);
            return result;
        }
    }


    public static SlpLedgerEntriesBuilder newBuilder() {
        return new SlpLedgerEntriesBuilder();
    }

    public static SlpLedgerEntriesBuilder buildUpon(SlpLedgerEntries original) {
        final SlpLedgerEntriesBuilder builder = newBuilder();
        builder.accountId(original.getAccountId());
        builder.amount(original.getAmount());
        builder.creditOrDebit(original.getCreditOrDebit());
        builder.entryTypeCode(original.getEntryTypeCode());
        builder.loanId(original.getLoanId());
        builder.referenceId(original.getReferenceId());
        builder.category(original.getCategory());
        return builder;
    }
    
    @Override
    public String toString() {
        return "SlpLedgerEntries [accountId=" + accountId + ", amount=" + amount + ", creditOrDebit=" + creditOrDebit
                + ", entryTypeCode=" + entryTypeCode + ", loanId=" + loanId + ", referenceId=" + referenceId + ", category="
                + category + "]";
    }
    
}
