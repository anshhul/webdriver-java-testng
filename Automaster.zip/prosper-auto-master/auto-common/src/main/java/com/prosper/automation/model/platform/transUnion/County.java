
package com.prosper.automation.model.platform.transUnion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by pbudiono on 9/8/16.
 */
public final class County {

    @JsonProperty("name")
    private String name;
    @JsonProperty("code")
    private String code;
    @JsonProperty("population")
    private String population;


    public County() {
    }

    private County(Builder builder) {
        setName(builder.name);
        setCode(builder.code);
        setPopulation(builder.population);
    }

    @JsonIgnore
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonIgnore
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @JsonIgnore
    public String getPopulation() {
        return population;
    }

    public void setPopulation(String population) {
        this.population = population;
    }


    public static final class Builder {

        private String name;
        private String code;
        private String population;


        public Builder() {
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withCode(String val) {
            code = val;
            return this;
        }

        public Builder withPopulation(String val) {
            population = val;
            return this;
        }

        public County build() {
            return new County(this);
        }
    }
}
