
package com.prosper.automation.batch.collection;

import com.prosper.automation.jira.model.Issue;

import org.apache.commons.collections.Transformer;

/**
 * A transformer based class to get JIRA ticket numbers.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class JiraIssueKeyTransformer implements Transformer {
    
    @Override
    public Object transform(Object input) {
        return ((Issue) input).getKey();
    }
}
