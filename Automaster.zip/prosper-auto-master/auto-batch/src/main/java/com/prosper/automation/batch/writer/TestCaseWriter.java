
package com.prosper.automation.batch.writer;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.jira.clients.JiraClientImpl;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.CreateIssueRequest;
import com.prosper.automation.jira.model.CustomField11217;
import com.prosper.automation.jira.model.Issue;
import com.prosper.automation.jira.model.IssuePriority;
import com.prosper.automation.jira.model.IssueType;
import com.prosper.automation.jira.model.Project;
import com.prosper.automation.model.test.TestCase;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;

import java.util.List;

/**
 * A writer class to create new test case in Zephyr.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class TestCaseWriter implements ItemWriter<TestCase> {

    private static final Logger LOG = Logger.getLogger(TestCaseWriter.class.getSimpleName());

    private static final String CREATING_TEST_CASE_LOG_TEMPLATE = "Creating new test case %s.";
    private static final String NEW_TEST_CASE_IS_CREATED_LOG_TEMPLATE = "New test case is created %s.";
    private static final String ISSUE_TYPE = "Test";

    private IJiraClient jiraService;


    public TestCaseWriter(final JiraClientImpl jiraService) {
        this.jiraService = jiraService;
    }

    @Override
    public void write(List<? extends TestCase> items) throws AutomationException, HttpRequestException {
        for (final TestCase testCase : items) {
            LOG.info(String.format(CREATING_TEST_CASE_LOG_TEMPLATE, testCase.getTestMethodName()));

            final Project project = new Project.Builder().withKey(testCase.getProjectName()).build();
            final IssueType issueType = new IssueType.Builder().withName(ISSUE_TYPE).build();
            final CustomField11217 customField11217 = new CustomField11217();
            final IssuePriority testPriority = new IssuePriority.Builder().withName(testCase.getTestPriority()).build();

            final IssueType testStory = new IssueType.Builder()
                    .withName("Story Tests")
                    .build();
            final Issue testIssue = new Issue.Builder()
                    .withKey("QE-282")
                    .build();

//            final IssueLink issueLink = new IssueLink.Builder()
//                    .withIssueType(testStory)
//                    .withIssue(testIssue)
//                    .build();
            final Issue issue = new Issue.Builder()
//                    .withIssueLinks(Lists.newArrayList(issueLink))
                    .withProject(project)
                    .withPriority(testPriority)
                    .withSummary(testCase.getTestCaseName())
                    .withLabels(testCase.getLabels()).withDescription(testCase.getTestDescription().toString())
                    .withIssueType(issueType).withCustomField11217(customField11217).build();
            final CreateIssueRequest createIssueRequest = new CreateIssueRequest.Builder().withField(issue).build();

            final Issue response = jiraService.createJiraIssue(createIssueRequest);
            LOG.info(String.format(NEW_TEST_CASE_IS_CREATED_LOG_TEMPLATE, response.getKey()));
        }
    }
}
