package com.prosper.automation.batch.writer;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.prosper.automation.batch.collection.JiraProjectVersionPredicate;
import com.prosper.automation.batch.utility.JiraUtilities;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.Project;
import com.prosper.automation.jira.model.ProjectVersion;
import com.prosper.automation.jira.model.SessionResponse;
import com.prosper.automation.model.test.TestResult;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;

import java.util.List;
import java.util.Map;

/**
 * A writer class to for result processing.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class TestResultWriter implements ItemWriter<TestResult> {

    public static final Map<String, String> PROJECT_TEST_CYCLE = Maps.newHashMap();

    private static final Logger LOG = Logger.getLogger(TestResultWriter.class.getSimpleName());

    private static final String WRITING_TEST_RESULT_LOG_TEMPLATE = "Updating test status for %s.";
    private static final String CREATE_NEW_TEST_CYCLE_LOG_TEMPLATE = "Creating new test cycle for project %s.";
    private static final String UNABLE_TO_GET_VERSION_LOG_TEMPLATE = "Unable to fetch project version %s in %s project.";

    private IJiraClient jiraService;

    private String testEnvironment;

    private Boolean processDefect;

    private String projectVersion;

    private String testCyclePrefix;

    public TestResultWriter(final IJiraClient jiraService, final String testEnvironment, final Boolean processDefect,
                            final String projectVersion, final String testCyclePrefix) {
        this.jiraService = jiraService;
        this.testEnvironment = testEnvironment;
        this.processDefect = processDefect;
        this.projectVersion = projectVersion;
        this.testCyclePrefix = testCyclePrefix;
    }

    @Override public void write(final List<? extends TestResult> items) throws Exception {
        if (items != null && items.size() > 0) {
            jiraService.initializeJsessionId();
        }

        for (final TestResult testResult : items) {
            final String projectName = testResult.getProjectName();
            final String testMethodName = testResult.getTestMethodName();

            LOG.info(String.format(WRITING_TEST_RESULT_LOG_TEMPLATE, testMethodName));

            final Project project = JiraUtilities.getProject(jiraService, projectName);
            final String projectId = project.getId();

            // get project version id from Project
            final List<ProjectVersion> version = (List<ProjectVersion>) CollectionUtils
                    .select(project.getVersions(), new JiraProjectVersionPredicate(projectVersion));
            Preconditions.checkArgument(version.size() == 1,
                    String.format(UNABLE_TO_GET_VERSION_LOG_TEMPLATE, projectVersion, projectName));
            final String projectVersionId = version.get(0).getId();

            createTestCycle(projectName, projectId, projectVersionId);

            // add test case to test cycle.
            final String executionId = JiraUtilities.createTestExecution(jiraService, testResult, projectId, projectVersionId,
                    PROJECT_TEST_CYCLE.get(projectName));
            LOG.info("Test cycle created. Execution ID: " + executionId);
            // update test case status
            JiraUtilities.updateTestExecution(jiraService, executionId, testResult.getTestStatus());

            // create defect ticket if the flag is set to true
            if (processDefect) {
                JiraUtilities.processDefectTicket(jiraService, testResult);
            }
        }
    }

    private synchronized void createTestCycle(final String projectName, final String projectId, final String projectVersionId) throws HttpRequestException, AutomationException {
        // create project test cycle if not exist.
        if (!PROJECT_TEST_CYCLE.containsKey(projectName)) {
            LOG.info(String.format(CREATE_NEW_TEST_CYCLE_LOG_TEMPLATE, projectName));
            PROJECT_TEST_CYCLE.put(projectName, JiraUtilities
                    .createTestCycle(jiraService, testEnvironment, projectVersionId, projectVersion, projectId, testCyclePrefix));
        }
    }
}
