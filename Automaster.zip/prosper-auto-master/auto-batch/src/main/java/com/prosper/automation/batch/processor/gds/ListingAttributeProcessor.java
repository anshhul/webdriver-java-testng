package com.prosper.automation.batch.processor.gds;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.core.mapper.MapperService;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.gds.IGDSClient;
import com.prosper.automation.model.gds.GDSHoldResponse;
import com.prosper.automation.model.gds.processor.GDSListing;
import com.prosper.automation.util.SSHUtilities;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import java.util.List;
import java.util.Map;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class ListingAttributeProcessor implements ItemProcessor {

    private static final Logger LOG = Logger.getLogger(ListingAttributeProcessor.class.getSimpleName());

    private static final String PROCESSING_LISTING_LOG = "Processing listing id %s.";
    private static final String UNABLE_TO_LOCATE_REMOTE_FILE_LOG =
            "Unable to locate web request file for listing id %s.";
    private static final String UNABLE_TO_DESERIALIZE_GDS_REQUEST_LOG =
            "Unable to deserialize web request with listing id %s : %s.";
    private static final String HTTP_REQUEST_ERROR_LOG = "HTTP error on processing holds for listing id %s.";

    private static final String NULL_GDS_CLIENT_LOG = "gdsClient can not be null.";
    private static final String NULL_SSH_UTILITIES_LOG = "sshUtilities can not be null.";
    private static final String NULL_REMOTE_DIRECTORY_LOG = "remoteDirectory can not be null.";

    private final IGDSClient gdsClient;
    private final SSHUtilities sshUtilities;

    private final String remoteDirectory;

    public ListingAttributeProcessor(final IGDSClient gdsClient, final SSHUtilities sshUtilities,
            final String remoteDirectory) {

        Preconditions.checkNotNull(gdsClient, NULL_GDS_CLIENT_LOG);
        Preconditions.checkNotNull(gdsClient, NULL_SSH_UTILITIES_LOG);
        Preconditions.checkNotNull(gdsClient, NULL_REMOTE_DIRECTORY_LOG);

        this.gdsClient = gdsClient;
        this.sshUtilities = sshUtilities;
        this.remoteDirectory = remoteDirectory;
    }

    @Override public Object process(Object item) throws Exception {
        final GDSListing gdsListing = (GDSListing) item;
        final String listingId = gdsListing.getListingId();

        LOG.info(String.format(PROCESSING_LISTING_LOG, listingId));
        final List<String> requestFiles = sshUtilities.searchFiles(remoteDirectory, listingId);

        final int numberOfFilesFound = requestFiles.size();
        if (numberOfFilesFound == 0) {
            LOG.warn(String.format(UNABLE_TO_LOCATE_REMOTE_FILE_LOG, listingId));
            return null;
        }

        // always fetches the last offline file from remote server.
        final String remoteFileName = requestFiles.get(numberOfFilesFound - 1);

        final String remoteRequestFilePath =
                String.format(StringConstant.PATH_DELIMITER, remoteDirectory, remoteFileName);
        final String requestString = sshUtilities.readFiles(remoteRequestFilePath);

        // there are files with empty content.
        try {
            gdsListing.setGDSRequest(MapperService.deserializeJSON(requestString, Map.class));
        } catch (final AutomationException ae) {
            LOG.warn(String.format(UNABLE_TO_DESERIALIZE_GDS_REQUEST_LOG, listingId, ae.getMessage()));
            return null;
        }

        final Map<String, String> gdsRequest = gdsListing.getGDSRequest();

        try {
            final GDSHoldResponse gdsHoldResponse = gdsClient.directHolds(gdsRequest);
            gdsListing.setListingResponse(gdsHoldResponse);
        } catch (final HttpRequestException ex) {
            LOG.warn(String.format(HTTP_REQUEST_ERROR_LOG, listingId), ex);
            return null;
        }

        return gdsListing;
    }
}
