
package com.prosper.automation.batch.tasklet;

import com.prosper.automation.util.SSHUtilities;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

/**
 * Created by pbudiono on 6/16/16.
 */
public final class ListingAttributeDestructor implements Tasklet {

    private final SSHUtilities sshUtilities;


    public ListingAttributeDestructor(final SSHUtilities sshUtilities) {
        this.sshUtilities = sshUtilities;
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
            throws Exception {
        this.sshUtilities.close();

        return RepeatStatus.FINISHED;
    }
}
