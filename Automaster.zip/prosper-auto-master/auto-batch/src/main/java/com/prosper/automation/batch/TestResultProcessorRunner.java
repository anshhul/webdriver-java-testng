
package com.prosper.automation.batch;

/**
 * A main class to run test result processor job.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class TestResultProcessorRunner extends ProcessorRunner {
    
    private static final String JOB_NAME = "test-result-processor-job";
    private static final String JOB_CONFIG = "spring/test_result_processor.xml";
    
    private static final String ELAPSED_TIME_LOG_TEMPLATE = "Elapsed time %fs.";
    
    
    public static void main(final String[] args) {
        final long startTime = System.nanoTime();
        run(JOB_CONFIG, JOB_NAME);
        final long estimatedTime = System.nanoTime() - startTime;
        
        final double elapsedTime = estimatedTime / 1000000000.0;
        System.out.println(String.format(ELAPSED_TIME_LOG_TEMPLATE, elapsedTime));
    }
}
