
package com.prosper.automation.batch;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * An abstract class for running auto batch jobs.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public abstract class ProcessorRunner {

    private static final Logger LOG = Logger.getLogger(ProcessorRunner.class.getSimpleName());

    private static final String JOB_LAUNCHER_BEAN_ID = "jobLauncher";
    private static final String EXIT_STATUS_LOG_TEMPLATE = "Exit status %s";


    protected static void run(final String configurationLocation, final String jobName) {
        final ApplicationContext context = new ClassPathXmlApplicationContext(configurationLocation);

        final JobLauncher jobLauncher = (JobLauncher) context.getBean(JOB_LAUNCHER_BEAN_ID);
        final Job job = (Job) context.getBean(jobName);

        try {
            final JobExecution execution = jobLauncher.run(job, new JobParameters());
            LOG.info(String.format(EXIT_STATUS_LOG_TEMPLATE, execution.getStatus()));
        } catch (JobExecutionAlreadyRunningException e) {
            e.printStackTrace();
        } catch (JobRestartException e) {
            e.printStackTrace();
        } catch (JobInstanceAlreadyCompleteException e) {
            e.printStackTrace();
        } catch (JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }
}
