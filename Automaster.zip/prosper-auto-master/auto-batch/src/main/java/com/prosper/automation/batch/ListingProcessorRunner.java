package com.prosper.automation.batch;

/**
 * Created by pbudiono on 5/24/16.
 */
public class ListingProcessorRunner extends ProcessorRunner {

	private static final String JOB_NAME = "listing-processor-job";
	private static final String JOB_CONFIG = "spring/listing_attr_processor.xml";

	public static void main(final String[] args) {
		run(JOB_CONFIG, JOB_NAME);
	}
}
