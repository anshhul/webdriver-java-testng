package com.prosper.automation.batch.writer;

/**
 * Created by pbudiono on 9/8/16.
 */
public class TUDataWriter {

}
