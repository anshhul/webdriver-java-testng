
package com.prosper.automation.batch.processor;

import com.google.common.base.Strings;
import com.prosper.automation.jira.clients.JiraClientImpl;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.SearchJiraIssueRequest;
import com.prosper.automation.jira.model.SearchResponse;
import com.prosper.automation.model.test.TestCase;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

/**
 * A processor class to determine whether or not it is a new test case (not stored in Zephyr).
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class TestCaseProcessor implements ItemProcessor {

    private static final Logger LOG = Logger.getLogger(TestCaseProcessor.class.getSimpleName());

    private static final String PROCESSING_TEST_CASE_LOG_TEMPLATE = "Processing test case: %s";
    private static final String EXISTING_TEST_CASE_WITH_TICKET_NUMBER_LOG_TEMPLATE = "Test case %s already has ticket number %s.";
    private static final String TEST_CASE_DOES_NOT_EXIST_LOG_TEMPLATE = "Test case %s does not exist.";
    private static final String TEST_CASE_DOES_EXIST_LOG_TEMPLATE = "Test case %s exists.";
    private static final String DUPLICATE_TEST_CASES_FOUND_LOG_TEMPLATE = "Duplicate test case %s are found.";
    private static final String UNEXPECTED_SEARCH_BEHAVIOR_LOG_TEMPLATE = "Unexpected behavior is observed while processing %s.";

    private IJiraClient jiraService;


    public TestCaseProcessor(final JiraClientImpl jiraService) {
        this.jiraService = jiraService;
    }

    /**
     * Checks whether a test case is a new test case.
     * 
     * @param item
     * @return TestCase
     * @throws Exception
     */
    @Override
    public Object process(final Object item) throws Exception {
        final TestCase testCase = (TestCase) item;

        // using test method name for logging purposes.
        final String testMethodName = testCase.getTestMethodName();

        LOG.info(String.format(PROCESSING_TEST_CASE_LOG_TEMPLATE, testMethodName));

        // ignores existing test case in Zephyr by checking if ProsperZephyr's ticketNumber is not empty or null.
        final String testCaseId = testCase.getTicketNumber();
        if (!Strings.isNullOrEmpty(testCaseId)) {
            LOG.info(String.format(EXISTING_TEST_CASE_WITH_TICKET_NUMBER_LOG_TEMPLATE, testMethodName, testCaseId));
            return null;
        }

        // searches if test case has already been created. search criteria are project name and test case name.
        final SearchJiraIssueRequest searchJiraIssueRequest = new SearchJiraIssueRequest.ByProjectNameAndSummary()
                .withProjectName(testCase.getProjectName()).withTestTitle(testCase.getTestCaseName()).build();
        final SearchResponse searchResponse = jiraService.searchJiraIssue(searchJiraIssueRequest);

        // based on the number of test count returned from JIRA, it is creating, ignoring, or reporting unexpected behavior.
        final int totalTestCount = searchResponse.getTotal();
        if (totalTestCount == 0) {
            LOG.info(String.format(TEST_CASE_DOES_NOT_EXIST_LOG_TEMPLATE, testMethodName));
            return item;
        } else if (totalTestCount == 1) {
            LOG.info(String.format(TEST_CASE_DOES_EXIST_LOG_TEMPLATE, testMethodName));
        } else if (totalTestCount > 1) {
            LOG.warn(String.format(DUPLICATE_TEST_CASES_FOUND_LOG_TEMPLATE, testMethodName));
        } else {
            LOG.warn(String.format(UNEXPECTED_SEARCH_BEHAVIOR_LOG_TEMPLATE, testMethodName));
        }
        return null;
    }
}
