
package com.prosper.automation.batch;

/**
 * Indicate whether test process is turned off or on
 * Created by rsubramanyam on 4/13/16.
 */
public enum TestProcessorRunnerStatusType {
    OFF("off"),
    ON("on");

    private String switchStatus;


    TestProcessorRunnerStatusType(String status) {
        this.switchStatus = status;
    }

    public String getSwitchStatus() {
        return switchStatus;
    }
}
