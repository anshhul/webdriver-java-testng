
package com.prosper.automation.batch;

/**
 * A main class to run test case processor job.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class TestCaseProcessorRunner extends ProcessorRunner {
    
    private static final String JOB_NAME = "test-case-processor-job";
    private static final String JOB_CONFIG = "spring/test_case_processor.xml";
    
    
    public static void main(final String[] args) {
        run(JOB_CONFIG, JOB_NAME);
    }
}
