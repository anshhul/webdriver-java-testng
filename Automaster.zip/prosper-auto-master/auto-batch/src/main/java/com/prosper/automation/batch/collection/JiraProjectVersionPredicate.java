
package com.prosper.automation.batch.collection;

import com.prosper.automation.jira.model.ProjectVersion;

import org.apache.commons.collections.Predicate;

import java.util.Objects;

/**
 * A predicate based class to get JIRA project version ID.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class JiraProjectVersionPredicate implements Predicate {
    
    private final String projectVersionString;
    
    
    public JiraProjectVersionPredicate(final String projectVersion) {
        projectVersionString = projectVersion;
    }
    
    @Override
    public boolean evaluate(Object object) {
        final ProjectVersion projectVersion = (ProjectVersion) object;
        return Objects.equals(projectVersion.getName(), projectVersionString);
    }
}
