
package com.prosper.automation.batch.reader.gds;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.DirectoryConstant;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.Attachment;
import com.prosper.automation.jira.model.Issue;
import com.prosper.automation.model.gds.processor.GDSListing;
import com.prosper.automation.parser.GDSListingCSVParser;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemReader;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class ListingAttributeReader implements ItemReader<GDSListing> {

    private static final Logger LOG = Logger.getLogger(ListingAttributeReader.class.getSimpleName());

    private static final String FETCH_STRATEGY_TICKET_FROM_JIRA_LOG = "Checking regression ticket %s in JIRA.";
    private static final String TICKET_NOT_FOUND_LOG = "Unable to find regression ticket %s in JIRA.";
    private static final String TICKET_FETCHING_ERROR_LOG = "There is error in fetching ticket %s in JIRA.";
    private static final String FETCH_STRATEGY_FILE_FROM_JIRA_LOG = "Checking listing id seed data file %s in JIRA.";
    private static final String ATTACHMENT_IS_NULL = "Attachment object is null.";
    private static final String FILE_DOWNLOAD_LOG = "Downloading file from JIRA.";
    private static final String UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG = "Unable to download file.";

    private static final String READING_LISTING_LOG =
            "Reading listing id %s from csv file, and with remaining of %d number of listings.";
    private static final Object FILE_PATH_IS_NULL_LOG = "Listing file path can not be null.";

    private final List<String> listingIds;


    public ListingAttributeReader(final IJiraClient jiraService, final String ticketNumber, final String fileName)
            throws AutomationException {
        Preconditions.checkNotNull(fileName, FILE_PATH_IS_NULL_LOG);

        final String filePath = String.format("%s/%s", DirectoryConstant.USER_DIR, fileName);

        LOG.info(String.format(FETCH_STRATEGY_TICKET_FROM_JIRA_LOG, ticketNumber));
        Issue pricingTicket = null;
        try {
            pricingTicket = jiraService.getIssue(ticketNumber);
        } catch (HttpNotFoundException ex) {
            Assert.fail(String.format(TICKET_NOT_FOUND_LOG, ticketNumber), ex);
        } catch (HttpRequestException ex) {
            Assert.fail(String.format(TICKET_FETCHING_ERROR_LOG, ticketNumber), ex);
        }

        LOG.info(String.format(FETCH_STRATEGY_FILE_FROM_JIRA_LOG, fileName));
        final Attachment attachment = pricingTicket.getAttachment(fileName);
        if (Objects.isNull(attachment)) {
            throw new AutomationException(ATTACHMENT_IS_NULL);
        }

        LOG.info(FILE_DOWNLOAD_LOG);
        final String tempPricingFilePath = String.format("%s/%s", DirectoryConstant.USER_DIR, fileName);
        try {
            jiraService.downloadAttachment(attachment, tempPricingFilePath);
        } catch (HttpRequestException e) {
            throw new AutomationException(UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG);
        }

        listingIds = GDSListingCSVParser.parse(filePath);
    }

    @Override
    public synchronized GDSListing read() throws AutomationException, IOException {

        if (listingIds.isEmpty()) {
            return null;
        }

        final String listingId = listingIds.remove(0);
        LOG.info(String.format(READING_LISTING_LOG, listingId, listingIds.size()));

        return new GDSListing(listingId);
    }
}
