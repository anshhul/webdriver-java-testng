
package com.prosper.automation.batch.utility;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.prosper.automation.batch.collection.JiraIssueIdTransformer;
import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.AuthenticationInfoRequest;
import com.prosper.automation.jira.model.CreateTestCycleRequest;
import com.prosper.automation.jira.model.CreateTestCycleResponse;
import com.prosper.automation.jira.model.Project;
import com.prosper.automation.jira.model.SearchJiraIssueRequest;
import com.prosper.automation.jira.model.SearchResponse;
import com.prosper.automation.jira.model.SessionResponse;
import com.prosper.automation.jira.model.TestExecution;
import com.prosper.automation.jira.model.TestExecutionRequest;
import com.prosper.automation.jira.model.TestExecutionResponse;
import com.prosper.automation.enumeration.test.TestStatus;
import com.prosper.automation.model.test.TestResult;

import org.apache.commons.collections.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * An JIRA utility class to help test case and result processing.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class JiraUtilities {

    private static final String TEST_CYCLE_NAME_LOG_TEMPLATE = "%s [%s]";
    // log string template
    private static final String UNABLE_TO_FIND_JIRA_TICKET_ID_LOG = "Unable to find jira ticket id.";
    private static final String UNABLE_TO_GET_VERSION_LOG_TEMPLATE = "Unable to fetch project version %s in %s project.";
    private static final String UNABLE_TO_ADD_TEST_TO_CYCLE_LOG = "Unable to add test case to test cycle.";


    public static Project getProject(final IJiraClient jiraClient, final String projectName)
            throws AutomationException, HttpRequestException {
        return jiraClient.getProject(projectName);
    }

    public static String createTestCycle(final IJiraClient jiraClient, final String testEnvironment,
                                         final String projectVersionId, final String projectVersion, final String projectId,
                                         final String testCyclePrefix) throws AutomationException, HttpRequestException {
        final Date now = new Date();
        final String dateStamp = DateConstant.TEST_CYCLE_DATE_FORMAT.format(now);
        final String timeStamp = DateConstant.TEST_CYCLE_TIME_FORMAT.format(now);

        final String testCycleName = String.format(TEST_CYCLE_NAME_LOG_TEMPLATE, testCyclePrefix, timeStamp);

        final CreateTestCycleRequest createTestCycleRequest = new CreateTestCycleRequest.Builder().withName(testCycleName)
                .withEnvironment(testEnvironment).withBuild(projectVersion).withStartDate(dateStamp).withProjectId(projectId)
                .withVersionId(projectVersionId).withDescription("").withClonedCycleId("").withEndDate(dateStamp).build();

        final CreateTestCycleResponse response = jiraClient.createNewTestCycle(createTestCycleRequest);
        return response.getId();
    }

    public static String createTestExecution(final IJiraClient jiraClient, final TestResult testResult, final String projectId,
                                             final String projectVersionId, final String testCycleId)
                                                     throws AutomationException, HttpRequestException {
        final String jiraTicketNumber = testResult.getTicketNumber();
        final SearchJiraIssueRequest searchJiraIssueRequest = Strings.isNullOrEmpty(jiraTicketNumber)
                ? new SearchJiraIssueRequest.ByProjectNameAndSummary().withProjectName(testResult.getProjectName())
                        .withTestTitle(testResult.getTestCaseName()).build()
                : new SearchJiraIssueRequest.ByTicketNumber().withTicketNumber(jiraTicketNumber).build();
        final SearchResponse searchResponse = jiraClient.searchJiraIssue(searchJiraIssueRequest);
        final List<String> jiraTestCaseIds =
                (List<String>) CollectionUtils.collect(searchResponse.getIssues(), new JiraIssueIdTransformer());
        Preconditions.checkArgument(jiraTestCaseIds.size() == 1, UNABLE_TO_FIND_JIRA_TICKET_ID_LOG);
        final String jiraTicketId = jiraTestCaseIds.get(0);
        final TestExecutionRequest testExecutionRequest = new TestExecutionRequest.Builder().withCycleId(testCycleId)
                .withIssueId(jiraTicketId).withVersionId(projectVersionId).withProjectId(projectId).build();
        final TestExecutionResponse testExecutionResponse = jiraClient.createNewTestExecution(testExecutionRequest);
        final Map<String, TestExecution> executions = testExecutionResponse.getAdditionalProperties();
        Preconditions.checkArgument(executions.size() == 1, UNABLE_TO_ADD_TEST_TO_CYCLE_LOG);
        return executions.entrySet().iterator().next().getKey();
    }

    public static void updateTestExecution(final IJiraClient jiraClient, final String executionId, final TestStatus testStatus)
            throws AutomationException, HttpRequestException {
        jiraClient.updateTestExecution(executionId, testStatus.getId());
    }

    public static void processDefectTicket(final IJiraClient jiraClient, final TestResult testResult)
            throws AutomationException {
        throw new AutomationException("Feature is not supported.");
    }
}
