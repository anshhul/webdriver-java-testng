
package com.prosper.automation.batch.reader;

import com.google.common.collect.Lists;
import com.prosper.automation.enumeration.test.TestStatus;
import com.prosper.automation.model.test.TestResult;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * A reader class to read TestNG results.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public class TestResultReader implements ItemReader<TestResult> {

    private static final Logger LOG = Logger.getLogger(TestResultReader.class.getSimpleName());

    private static final String USER_DIRECTORY = System.getProperty("user.dir");

    private static final String TESTNG_FILE_PATH_LOG_TEMPLATE = "TestNG result file path %s.";
    private static final String TESTNG_STATUS_READING_LOG_TEMPLATE = "Reading TestNG result for tests with status %s.";
    private static final String TESTNG_TEST_INFORMATION_LOG_TEMPLATE = "Reading %s result.";

    private static final String TESTNG_ELEMENT_ATTRIBUTE_KEY = "description";

    private static final String GET_TEST_XPATH_TEMPLATE =
            "/testng-results/*/*/class/test-method[not(@is-config) and (@status='%s')]";

    private final List<TestResult> testCases = Lists.newArrayList();


    public TestResultReader(final String testNgOutput, final List<String> testStatuses)
            throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {

        final String testNgResultFullPath = String.format("%s/%s", USER_DIRECTORY, testNgOutput);
        LOG.info(String.format(TESTNG_FILE_PATH_LOG_TEMPLATE, testNgResultFullPath));

        final File testNgResultFile = new File(testNgResultFullPath);
        final DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        final Document testNGDocument = documentBuilder.parse(testNgResultFile);
        testNGDocument.getDocumentElement().normalize();

        for (final String testStatus : testStatuses) {

            final TestStatus enumeratedTestStatus = TestStatus.valueOf(testStatus);
            LOG.info(String.format(TESTNG_STATUS_READING_LOG_TEMPLATE, enumeratedTestStatus));

            final XPath xPath = XPathFactory.newInstance().newXPath();
            final XPathExpression xPathExpression = xPath.compile(String.format(GET_TEST_XPATH_TEMPLATE, testStatus));
            final NodeList testNodes = (NodeList) xPathExpression.evaluate(testNGDocument, XPathConstants.NODESET);

            for (int i = 0; i < testNodes.getLength(); i++) {
                final Node testNode = testNodes.item(i);
                final Node testInstanceNameNode = testNode.getAttributes().getNamedItem(TESTNG_ELEMENT_ATTRIBUTE_KEY);

                // skips the test without ProsperZephyr annotation.
                if (Objects.nonNull(testInstanceNameNode)) {
                    final TestResult testResult = TestResult.buildFromTestNGDescriptionString(testInstanceNameNode.getNodeValue(),
                            enumeratedTestStatus);

                    LOG.info(String.format(TESTNG_TEST_INFORMATION_LOG_TEMPLATE, testResult.getTestMethodName()));
                    testCases.add(testResult);
                }
            }
        }
    }

    @Override
    public TestResult read() throws UnexpectedInputException, ParseException, NonTransientResourceException {
        if (!testCases.isEmpty()) {
            return testCases.remove(0);
        }
        return null;
    }
}
