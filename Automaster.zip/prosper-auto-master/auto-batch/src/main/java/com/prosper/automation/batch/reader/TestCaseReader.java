
package com.prosper.automation.batch.reader;

import com.google.common.collect.Lists;
import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.model.test.TestCase;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.List;

/**
 * A reader class to read test cases definition.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class TestCaseReader implements ItemReader<TestCase> {

    private static final Logger LOG = Logger.getLogger(TestCaseReader.class.getSimpleName());

    private static final List<TestCase> TEST_CASES = Lists.newArrayList();

    private static final String START_READING_TEST_CLASS_LOG_TEMPLATE = "Start reading test class %s.";
    private static final String BUILDING_TEST_CASE_LOG_TEMPLATE = "Building test case %s from annotation.";


    public TestCaseReader(final List<Class> testClasses) {
        for (final Class testClass : testClasses) {
            LOG.info(String.format(START_READING_TEST_CLASS_LOG_TEMPLATE, testClass.getSimpleName()));

            for (final Method method : testClass.getDeclaredMethods()) {
                // test method needs to have both Test and ProsperZephyr annotations so that it can be processed.
                if (method.isAnnotationPresent(ProsperZephyr.class) && method.isAnnotationPresent(Test.class)) {
                    final ProsperZephyr prosperZephyrAnnotation = method.getAnnotation(ProsperZephyr.class);
                    final String testMethodName = method.getName();

                    LOG.info(String.format(BUILDING_TEST_CASE_LOG_TEMPLATE, testMethodName));
                    TEST_CASES.add(new TestCase(testMethodName, prosperZephyrAnnotation));
                }
            }
        }
    }

    @Override
    public TestCase read() throws UnexpectedInputException, ParseException, NonTransientResourceException {
        if (!TEST_CASES.isEmpty()) {
            return TEST_CASES.remove(0);
        }
        return null;
    }
}
