
package com.prosper.automation.batch.writer.gds;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.gds.processor.GDSListing;
import com.prosper.automation.writer.GDSListingCSVWriter;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;

import java.util.List;
import java.util.Objects;

/**
 * Created by pbudiono on 5/24/16.
 */
public final class ListingAttributeWriter implements ItemWriter<GDSListing> {

    private static final Logger LOG = Logger.getLogger(ListingAttributeWriter.class.getSimpleName());

    private static final String WRITING_OUTPUT_FILE = "Writing processed listing attributes holds to %s.";
    private static final String WRITING_PROCESSED_LISTING_LOG = "Writing processed listing with id %s.";
    private static final String NOT_WRITING_PROCESSED_LISTING_LOG = "Skipping result writing for listing with id %s.";

    private final String outputFilePath;


    public ListingAttributeWriter(final String outputFilePath) throws AutomationException {
        this.outputFilePath = outputFilePath;
        GDSListingCSVWriter.writeHeader(outputFilePath);
    }

    @Override
    public void write(List<? extends GDSListing> items) throws Exception {
        LOG.info(String.format(WRITING_OUTPUT_FILE, outputFilePath));

        for (final GDSListing gdsListing : items) {
            final String listingId = gdsListing.getListingId();
            if (isProcessedListing(gdsListing)) {
                LOG.info(String.format(WRITING_PROCESSED_LISTING_LOG, listingId));
                GDSListingCSVWriter.writeData(outputFilePath, gdsListing);
            } else {
                LOG.info(String.format(NOT_WRITING_PROCESSED_LISTING_LOG, listingId));
            }
        }
    }

    private boolean isProcessedListing(GDSListing gdsListing) {
        return (Objects.nonNull(gdsListing.getGDSRequest()) && Objects.nonNull(gdsListing.getGdsResponse()));
    }
}
