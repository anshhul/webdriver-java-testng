```
                                                                                  _                          
                                                                                 | |                         
 ______  ______   _ __   _ __  ___   ___  _ __    ___  _ __  ______  __ _  _   _ | |_  ___    ______  ______ 
|______||______| | '_ \ | '__|/ _ \ / __|| '_ \  / _ \| '__||______|/ _` || | | || __|/ _ \  |______||______|
                 | |_) || |  | (_) |\__ \| |_) ||  __/| |          | (_| || |_| || |_| (_) |                 
                 | .__/ |_|   \___/ |___/| .__/  \___||_|           \__,_| \__,_| \__|\___/                  
                 | |                     | |                                                                 
                 |_|                     |_|                                                                 
```

### [Release Notes](documentation/CHANGELOG.md)

### Project Structure
* [auto-batch](/auto-batch)
* [auto-common](/auto-common)
* [auto-core](/auto-core)
* [auto-db](/auto-db)
* [auto-gds-client](/auto-gds-client)
* [auto-jira-client](/auto-jira-client)
* [auto-jenkins-client](/auto-jenkins-client)
* [auto-platform-client](/auto-platform-client)
* [auto-service](/auto-service)
* [auto-solr-client](/auto-solr-client)
* [auto-test](/auto-test)
* [auto-wcf-client](/auto-wcf-client)
* [auto-web-driver](/auto-web-driver)
