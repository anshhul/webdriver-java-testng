```
                           dP                                                                        
                           88                                                                        
.d8888b. .d8888b.          88d888b. .d8888b. 88d888b. 88d888b. .d8888b. dP  dP  dP .d8888b. 88d888b. 
88'  `88 88ooood8 88888888 88'  `88 88'  `88 88'  `88 88'  `88 88'  `88 88  88  88 88ooood8 88'  `88 
88.  .88 88.  ...          88.  .88 88.  .88 88       88       88.  .88 88.88b.88' 88.  ... 88       
`8888P88 `88888P'          88Y8888' `88888P' dP       dP       `88888P' 8888P Y8P  `88888P' dP       
ooooo~88~oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
      dP                                                                                             
```
