
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 27-feb
 *
 */
public class AppResumeModalValidationsTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalValidationsTest.class.getSimpleName());


    /**
     * GEAR-2636 Verify that validation is displayed for NO last name entered in resume modal. GEAR-2637 Verify that user is
     * Blocked to enter invalid data in the Last Name field in resume modal GEAR-2635 Verify that user is only allowed to input
     * numeric data in zipcode field on resume modal. GEAR-2634 Verify that user is Blocked to input more than 5 digits in the
     * zipcode field on the resume Modal. GEAR-2631 Verify that validation is displayed for NO zipcode entered in resume modal.
     * GEAR-2639 Verify that validation is displayed for NO year of birth entered in resume modal. GEAR-2640 Verify that user is
     * Blocked to enter invalid data in the Yaer Of Birth field in resume modal. GEAR-2631 Verify that validation is displayed for
     * NO zipcode entered in resume modal
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalValidations() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalValidationsTest~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAppResumeModalValidations");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // Get alternate key from cookie
            final String altKey = offersPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Verify that validation is displayed for NO last name entered in resume modal
            Assert.assertTrue(publicSitePreRegistrationPage.getLastNameFromAppResumeModal().isEmpty());
            Assert.assertTrue(publicSitePreRegistrationPage.verifyLastNameValidation());
            LOG.info("GEAR-2636 Verify that validation is displayed for NO last name entered in resume modal");

            // Verify user blocked to enter invalid last name in modal
            publicSitePreRegistrationPage.enterLastNameInAppResumeModal(MessageBundle.getMessage("invalidText"));
            Assert.assertTrue(publicSitePreRegistrationPage.getLastNameFromAppResumeModal().isEmpty());
            LOG.info("GEAR-2637 Verify that user is Blocked to enter invalid data in the Last Name field in resume modal");

            // Enter albhabets value in zip code
            publicSitePreRegistrationPage.enterZipIntoAppResumeModal(MessageBundle.getMessage("nonNumericValue"));
            Assert.assertTrue(publicSitePreRegistrationPage.getZipFromAppResumeModal().isEmpty());
            LOG.info("GEAR-2635 Verify that user is only allowed to input numeric data in zipcode field on resume modal");

            // Verify that validation is displayed for NO zipcode entered in resume modal
            Assert.assertTrue(publicSitePreRegistrationPage.getZipFromAppResumeModal().isEmpty());
            Assert.assertTrue(publicSitePreRegistrationPage.verifyZipValidation());
            LOG.info("GEAR-2631 Verify that validation is displayed for NO zipcode entered in resume modal");

            // Verify validation is displayed for NO year of birth entered in resume modal
            Assert.assertTrue(publicSitePreRegistrationPage.getYOBFromAppResumeModal().isEmpty());
            Assert.assertTrue(publicSitePreRegistrationPage.verifyYOBValidation());
            LOG.info("GEAR-2639 Verify that validation is displayed for NO year of birth entered in resume modal");

            // Verify that user is Blocked to enter invalid data in the Yaer Of Birth field in resume modal
            publicSitePreRegistrationPage.enterYOBIntoAppResumeModal(MessageBundle.getMessage("nonNumericValue"));
            Assert.assertTrue(publicSitePreRegistrationPage.getYOBFromAppResumeModal().isEmpty());
            LOG.info("GEAR-2640 Verify that user is Blocked to enter invalid data in the Yaer Of Birth field in resume modal");

            // Verify user blocked to enter more than 5 digits in zipcode
            publicSitePreRegistrationPage.enterZipIntoAppResumeModal(MessageBundle.getMessage("zipcodeMoreThan5Digit"));
            Assert.assertTrue(publicSitePreRegistrationPage.getZipFromAppResumeModal().length() == 5);
            LOG.info("GEAR-2634 Verify that user is Blocked to input more than 5 digits in the zipcode field on the resume Modal");
        }
    }

    /*
     * GEAR-2876 Verify that user navigates to reg page on using fake/invalid alt-key in URL and submititng App resume modal
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyAppResumeWithInvalidAltKey() throws AutomationException {
        LOG.info("~~~~~~Executing: verifyAppResumeWithInvalidAltKey~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");

            // Enter invalid alt key in URL
            String altKey = RandomStringUtils.random(20, true, true);
            LOG.info("Alternate key is " + altKey);

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));
            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            Assert.assertTrue(publicSiteRegistrationPage.isRegisterPageDisplayed());
            LOG.info("GEAR-2876 Verify that user navigates to reg page on using fake/invalid alt-key in URL and submititng App resume modal");
        }
    }
}
