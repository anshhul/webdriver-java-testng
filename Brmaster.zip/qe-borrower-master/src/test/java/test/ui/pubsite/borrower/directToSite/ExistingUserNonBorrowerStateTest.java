
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Created by rsubramanyam on 6/24/16.
 */
public class ExistingUserNonBorrowerStateTest extends PartnerLandingPageTestBase {

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyBorrowerNonBorrowingStateTest() throws AutomationException {

        LOG.info("~~~~~~Executing-verifyBorrowerNonBorrowingStateTest~~~~~~~~~~~~~~~");
        withdrawUserListing(getUserForEnvironment("testNonBorrowingStateUser"));
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("originalPreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Enter existing withdrawn user email
        String email = getUserForEnvironment("testNonBorrowingStateUser");
        publicSiteRegistrationPage.enterEmailAddress(email);
        LOG.info("User email addresss is:" + email);
        // login modal displayed
        Assert.assertTrue(publicSiteRegistrationPage.getLoginModalAsElement().isDisplayed());
        // User entered the common Password: "Password23"
        publicSiteRegistrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
        // User accept the agreement on Reg Page
        publicSiteRegistrationPage.clickOnSignInToContinue();
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        Assert.assertTrue(
                publicSiteRegistrationPage.isStaticTextDisplayed(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE),
                "Restriction should be displayed to WV State User");
//        publicSiteRegistrationPage.clearZipCode();
//        publicSiteRegistrationPage.clearHomeAddress();
//        publicSiteRegistrationPage.clearCity();
//
//        publicSiteRegistrationPage.fillRegistrationForm(Constant.WV_ZIP_CODE, null, null, null, null, null, null, Constant.WV_ADDRESS_1,
//                Constant.WV_CITY, Constant.WV_STATE, null, null, null);
//        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
//        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed("Not available in your state"),
//                "Restriction should be displayed");
    }
}
