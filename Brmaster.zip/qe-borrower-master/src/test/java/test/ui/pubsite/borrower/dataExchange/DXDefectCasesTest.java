
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;

/**
 */
public class DXDefectCasesTest extends DXCompleteListingTestBase
 {

    protected static final Logger LOG = Logger.getLogger(DXDefectCasesTest.class.getSimpleName());


    /**
     * GEAR-1410 DX: Eligible prospect should be displayed for the user
     *
     */
    @Test(groups = {TestGroup.NIGHTLY})
    public void verifyGetOfferNewUserEligibleProspect()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("Execution Started: verifyGetOfferNewUserEligibleProspect()");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("GTNewUserEligibleProspect");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");


        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));

                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();

            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();
            final String listingID = tilaPage.getListingIdFromTILAContent();
            LOG.info("Listing ID: " + listingID);

            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);

            prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            final ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
            prospectInfo.getResponseCodes(email);

           Assert.assertTrue("BestQPSegment".equals(prospectInfo.getBREAttribute1(email)));
           Assert.assertTrue("Eligible".equals(prospectInfo.getEligibilityStatus(email)));

        }
    }
}
