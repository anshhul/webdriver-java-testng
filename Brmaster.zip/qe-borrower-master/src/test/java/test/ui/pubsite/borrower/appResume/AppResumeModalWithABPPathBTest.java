
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.net.MalformedURLException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 22-feb
 *
 */
public class AppResumeModalWithABPPathBTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithABPPathBTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;

    /*
     * GEAR-2711 Confirm user is able to login after entering the lastname,zip,birth year details and is redirected to Offers page
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testAppResumeModalWithABPPathB() throws AutomationException, MalformedURLException, HttpRequestException {

        LOG.info("~~~~~~~~~~~~~Executing: testAppResumeModalWithABPPathB~~~~~~~~~~~~~~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testAppResumeModalWithABPPathB", "p2pcredit");
        String pathBUrl = null;
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.deleteAllCookies();
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");
            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");

            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            abpRegistrationPage.handleSSNPage(getAllDmValidOfferCode().get(0).get(Constants.RegisterationPageConstants.SSN_TAG));
            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();

            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            pathBUrl = abpPersonalDetailPage.getABPPathBUrl(referralCode);
            // abandon the flow , click on complete later button
            abpPersonalDetailPage.clickOnCompleteLater();
            PollingUtilities.sleep(3000);
            // wait for complete later modal to appear
            Assert.assertTrue(abpPersonalDetailPage.isCompleteLaterModalDisplayed());
            // select abandon reason for flow
            abpPersonalDetailPage.selectAbandonReason("Miscellaneous");
            // submit the abandon reason
            abpPersonalDetailPage.clickOnSubmitAbandonReason();
            PollingUtilities.sleep(5000);
            Assert.assertTrue(abpPersonalDetailPage.getCompleteLaterModalHeader().getText().contains("Success!"));
            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getAllDmValidOfferCode().get(0).get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        // Use the generated ABP PathB URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathBUrl), URLUtilities.getStringURLWithoutScheme(pathBUrl))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSitePersonalDetailPage personalDetailPage = abpLandingPage.reviewYourOfferPathB();

            // Get alternate key from DB
            final String altKey = circleOneDBConnection.getDataAccessObject(UserDAO.class).getAltKeyByEmail(email);
            // final String altKey = personalDetailPage.getCookieValue("alt_key");

            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            PollingUtilities.sleep(2000);
            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = personalDetailPage.clickProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            LOG.info(
                    "GEAR-2565 Verify CTA app resume modal shows up to user dropped on PD page on clicking 'continue your application'");

            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            final PublicSiteOfferPage offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info("GEAR-2711 Confirm user is able to login after entering the lastname,zip,birth year details and is redirected to Offers page");
        }
    }
}
