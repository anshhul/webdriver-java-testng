package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.IDVSessionTrackingDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.WebDriverTestBase;

import javax.annotation.Resource;

/**
 * Created by ppatil on 6/2/16.
 */

public class IDVSessionTrackingTest extends WebDriverTestBase {

    private static final Logger LOG = Logger.getLogger(IDVSessionTrackingTest.class);

    @Autowired @Qualifier("publicSitePreRegistrationPage") private PublicSitePreRegistrationPage
            publicSitePreRegistrationPage;

    @Resource private CloseableJdbcConnection idvsessionDBConnection;

    @DataProvider(name = "testData") public static Object[][] userRegisterData() {
        return new Object[][] {Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose",
                "homeImprovementListing"),};
    }

    @Test(dataProvider = "testData", groups = {TestGroup.SANITY})
    public void verifyDTSFunnel(String Key, String jiraID, String loanAmount, String loanPurpose, String creditQuality,
            String firstName, String middleInitial, String lastName, String homeAddress, String city, String state,
            String zipCode, String employmentStatus, String yearlyIncome, String dob, String emailAddress,
            String password, String homePhone, String mobilePhone, String workPhone, String employerName,
            String employerPhone, String occupation, String employmentStartDate, String SSN, String bankName,
            String accountType, String accountholderName, String AlternateAccountHolderName, String routingNumber,
            String accountNumber, String confirmAccountNumber, String paymentType) throws AutomationException {

        LOG.info("Test Method Name- verifyDTSFunnel()");

        password = MessageBundle.getMessage("password");

        PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage
                .checkYourRate();
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        registrationPage.getSessionCookie();
        IDVSessionTrackingDAO idvSession1 = idvsessionDBConnection.getDataAccessObject(IDVSessionTrackingDAO.class);
        int sessionInfoTrackingCount1 = idvSession1.getSessionInfoTrackingCount();
        int sessionInfoCount1 = idvSession1.getSessionInfoCount();
        LOG.info("SessionInfoTracking_count1" + sessionInfoTrackingCount1);
        LOG.info("**  SessionInfoTracking_count1**" + sessionInfoTrackingCount1);
        LOG.info("**  SessionInfoTracking_count1**" + sessionInfoCount1);

        // Submit Register page
        registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName,
                homeAddress, city, state, employmentStatus, yearlyIncome, dob);
        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
        String afterSession = offerPage.getSessionCookie();
        System.out.println("** Inside Session Cookie **" + afterSession);
        IDVSessionTrackingDAO idvSession = idvsessionDBConnection.getDataAccessObject(IDVSessionTrackingDAO.class);

        int sessionInfoTrackingCount2 = idvSession.getSessionInfoTrackingCount();
        int sessionInfoCount2 = idvSession.getSessionInfoCount();
        LOG.info("**  SessionInfoTracking_count2**" + sessionInfoTrackingCount2);
        LOG.info("**  SessionInfoTracking_count2**" + sessionInfoCount2);

        Assert.assertTrue(sessionInfoTrackingCount2 > sessionInfoTrackingCount1,
                "SessionInfoTracking entry count is incremental.Logging is successfully ");
        Assert.assertTrue(sessionInfoCount2 > sessionInfoCount1,
                "sessionInfo entry count is incremental.Logging is successfully ");
    }
}
