
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;

public class NewDXPendingActivationTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewDXPendingActivationTest.class.getSimpleName());


    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testNewDXForPendingActivation() throws AutomationException, HttpRequestException, UnsupportedEncodingException {
        LOG.info("~~~~Executing: testNewDXForPendingActivation~~~~~~~~~~~");
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testNewDXForPendingActivation");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                LOAN_AMOUNT, getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        borrowerThankYouPage.clickGoToMyAccountPage();
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        LOG.info("DX User emailaddress is:" + email);

        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);
        PollingUtilities.sleep(2000);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + newUri)) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsAgainPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            personalDetailsAgainPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsAgainPage.waitForPersonalDetailsPage();
            personalDetailsAgainPage.selectOccupation("Chemist");
            personalDetailsAgainPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            personalDetailsAgainPage.clickOnContinue();
            personalDetailsAgainPage.waitForPersonalDetailsPage();
            Assert.assertTrue(personalDetailsAgainPage.isStaticTextDisplayed(Constants.EXISTING_LISTING_MESSAGE));
            LOG.info(
                    "BMP-3744 Verify that user is navigate to Existing listing page on submitting DX personal details landing page");
        }
    }
}
