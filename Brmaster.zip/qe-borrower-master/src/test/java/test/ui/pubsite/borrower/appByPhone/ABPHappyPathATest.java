
package test.ui.pubsite.borrower.appByPhone;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * verify ABP Path A flow Modified with DM OfferCode (Pricing Test)
 *
 * BMP-452 Path A: Borrower should be able to complete the funnel from public site java funnel.
 *
 * @author jdoriya 29-Apr-2016
 *
 */
public class ABPHappyPathATest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPHappyPathATest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // PART-1325 [Direct Mail] Path A: Borrower should be able to complete the funnel from public site java funnel.
    // GEAR-2003 Verify ABP Path A bank details should be pre-filled.
    @Test(groups = {TestGroup.SANITY})
    void testHappyPathFlow() throws AutomationException {

        LOG.info("~~~~~~~Executing: testHappyPathAFlow~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
        supportSiteMainPage.enterOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
        LOG.info("ABP User email is " + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");

        final String prospectID = getQueryMap(abpRegistrationPage.getCurrentURL()).get("prospect_id").toString();

        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        abpRegistrationPage.handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
        // Check Business Rule Version for all offers for prospect
        final List<Map<String, Object>> prospectOfferInfo =
                queryProspectDb(String.format(MessageBundle.getMessage("prospectOffers"), prospectID));

        for (final Map<String, Object> prospectRecord : prospectOfferInfo) {
            Assert.assertEquals(prospectRecord.get("BUSINESSRULEVERSION").toString(), Constants.BRE_RULE_VERSION);
        }
        // click on choose rate button
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        // csa is submitting personal detail for borrower
        abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        abpPersonalDetailPage
                .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        abpPersonalDetailPage
                .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
        final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details

        Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
        abpBankInfoPage
                .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        abpBankInfoPage.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);
        abpThankYouPage.close();
        // Verify abp mail box and retrieve the finish request url for borrower

        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(urlFromWeb), URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");

            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(urlFromWeb);

            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            // Check if Account Number is masker on Bank detail page
            // GEAR-1840 ABP Happy Path: Masked account number displayed on bank info page of PS and user unable to complete
            // listing.

            Assert.assertEquals(publicSiteBankAccountInfoPage.getPriorUserAccountNumber(),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            Assert.assertEquals(publicSiteBankAccountInfoPage.getPriorUserConfirmAccountNumber(),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            LOG.info("Account Details are not masker on Bank info page");
            LOG.info("GEAR-2003 Verify ABP Path A bank details should be pre-filled.");

            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            final AccountOverviewPage overviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();
            overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            overviewPage.dismissCongratulationWelcomeModal();
            final String listingID = overviewPage.getListingInfo().get("LISTING ID");
            // User navigate to Account Overview Page and observed the listing

            LOG.info("ABP  Path A Borrower ListingID is:" + listingID);
            LOG.info(
                    "PART-1325 [Direct Mail] Path A: Borrower should be able to complete the funnel from public site java funnel.");
            //check the BRE pricing version after P2B.
            final List<Map<String, Object>> listingInfo = queryCircleOne(MessageBundle.getMessage("listingsTable") + listingID);

            Assert.assertEquals(listingInfo.get(0).get("BRERuleVersion").toString(), Constants.BRE_RULE_VERSION);
            LOG.info("BRE pricing version verified" + " " + Constants.BRE_RULE_VERSION);
            // User navigate to Account Overview Page and observed the listing
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            Assert.assertEquals(varID38.get("Value").toString(),
                    getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG),
                    "var 38 value should be same as offer code provided");
            // verify DM reduce pricing as || corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to ABP user via DM Channel");

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final List<Map<String, Object>> lendingAccreditationRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
            Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
        }
    }
}
