
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;
import test.ui.pubsite.borrower.dataExchange.cases.BorrowerDXLTNewUserTestCase;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

/**
 * Created by rsubramanyam on 4/6/16.
 */
public class BorrowerDXLTNewUserTest extends DXCompleteListingTestBase
        implements BorrowerDXLTNewUserTestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXLTNewUserTest.class.getSimpleName());


    @Override
    @Test(groups = {TestGroup.SANITY})
    public void verifyListingCreationLTNewUser()
            throws IOException, JAXBException, XPathExpressionException, SAXException, ParserConfigurationException,
            TransformerException, AutomationException, HttpRequestException, JSONException {
        LOG.info("~~~~Executing: verifyListingCreationLTNewUser~~~~~~~~~~~");
        final String emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("verifyListingCreationLTNewUser");
        final ModifiedXmlEntity entity = updateLendingTreeRequestForNewPrimeUser(emailAddress);
        LOG.info(emailAddress);
        final String lendingTreeRequest =entity.getRequestBody();
        LOG.info("Dx Lending Tree request is hit  on endpoint");
        final String[] allURLs =
                getTagValue(validateResponse(creditKarmaWCFService, lendingTreeRequest, "LendingTree").getResponseBody(),
                Constants.dxResponse.LENDINGTREEURL);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        // Navigate to the DX Landing page
        Assert.assertNotNull(allURLs);
        String DXv2Url = navigateToDxLandingPageFromLTResponse(allURLs, emailAddress);
        LOG.info("DXv2Url  "+DXv2Url);
        final String offersUrlToUseForTesting = DXv2Url.replace("plp/dx-landing-page","personal-loans/pre-approval");
        LOG.info("offersUrlToUseForTesting:::::  "+offersUrlToUseForTesting);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterDXPassword(Constant.COMMON_PASSWORD);
            LOG.info("isPasswordEntered::  Boolean :: "+isPasswordEntered);

            if (isPasswordEntered) {
//                Assert.assertEquals(dxLandingPage.getUserName(),
//                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
//                LOG.info(
//                        "BMP-1408 Lending Tree: A check box for agreements signature should be displayed on Pre Screen Create Password page.-Passed");
//                LOG.info(
//                        "BMP-1394 Lending Tree: Correct User First name should be displayed on Pre Screen Create Password page.-Passed");

//                Assert.assertEquals(dxLandingPage.getWelcomeNote(), MessageBundle.getMessage("welcomeMessageNewUser"));
//                LOG.info(
//                        "BMP-1413 Lending Tree: Correct Welcome message should be displayed on Pre Screen Create Password page.-Passed");
                dxLandingPage.clickElectronicSignatureCheckBox();
                LOG.info("User submitted the DM landing page successfully");

                LOG.info(
                        "BMP-1408 Lending Tree: A check box for agreements signature should be displayed on Pre Screen Create Password page.-Passed");
                personalDetailsPage =
                        dxLandingPage.ClickContinueButton(offersUrlToUseForTesting);
                LOG.info(
                        "BMP-1414   Lending Tree: Agree and Continue button should be displayed on Pre Screen Create Password page-Passed");
            }
            PollingUtilities.sleep(2000);
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            LOG.info("User landed on the Personal detail page successfully");
            LOG.info(
                    "BMP-1404 Lending Tree: User navigated to \"Personal Detail\" page on submitting \"Pre-Screen Create Password Page with Offer page with valid details.-Passed");

            LOG.info("User landed on the Personal detail page after resuming successfully");
            LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
            personalDetailsPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailsPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailsPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            personalDetailsPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailsPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailsPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailsPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            LOG.info("User is able to submit the Personal detail page successfully");

            LOG.info("Tila Document is loaded successfully");
            LOG.info("BMP-1409 Lending Tree: Verify that Loan Terms page displayed on submitting Personal Information page");
            tilPage.verifyBorrowerDetails(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase() + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toUpperCase(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toUpperCase(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toUpperCase() + "," + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toUpperCase() + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toUpperCase());
            LOG.info("BMP-1403 Lending Tree: Correct address should be displayed on Loan Terms page.-Passed");
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();

            LOG.info("BMP-1407 Lending Tree: Bank Info page displayed on submitting Loan Terms page-Passed");

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage  overviewPageAgain =   publicSiteThankYouPage.clickGoToMyAccountPage();
            LOG.info("User navigate to Account Overview Page");
             overviewPageAgain.getListingDetail();
             LOG.info("DM Borrower ListingID is:" + overviewPageAgain.getListingDetail().get(1));

            LOG.info("BMP-1398 Lending Tree: Verify that Thank You page displayed on submitting Bank Info page-Passed");
            LOG.info("~~~~verifyListingCreationLTNewUser--PASSED~~~~~~~~~~~");
        }
    }
}
