
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;

public class NewDXUserWithOutPersonalDetailTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewDXUserWithOutPersonalDetailTest.class.getSimpleName());


    // BMP-3737 Verify that all the agreements are saved correctly in History of user on submitting DX personal details landing
    // page
    // BMP-3733 Verify that user who did not provide personal details in DX request is able to complete DX listing
    @Test(groups = {TestGroup.NIGHTLY}, enabled = true)
    public void testDXWithOutPersonalDetails()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testDXWithOutPersonalDetails~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDXWithOutPersonalDetails");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForWithOutPersonalDetailsPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID,
                        email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String dxV2Url = allURLs[0].replace("amp;", "");
        LOG.info("dXv2Url  " + dxV2Url);
        final String offersUrlToUseForTesting = dxV2Url.replace("plp/dx-landing-page", "personal-loans/pre-approval");
        LOG.info("offersUrlToUseForTesting::  " + offersUrlToUseForTesting);
        LOG.info("DX User emailaddress is::" + email);
        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);
        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterDXPassword(Constant.COMMON_PASSWORD);
            LOG.info("isPasswordEntered::  Boolean :: " + isPasswordEntered);
            dxLandingPage.clickElectronicSignatureCheckBox();
            LOG.info(
                    "BMP-1408 DX: A check box for agreements signature should be displayed on Pre Screen Create Password page.-Passed");
            personalDetailsPage =
                    dxLandingPage.ClickContinueButton(offersUrlToUseForTesting);
            LOG.info("User submitted the DX landing page successfully - Passed");
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertTrue(personalDetailsPage.getEmployerName().isEmpty());
            Assert.assertTrue(personalDetailsPage.getHomePhone().isEmpty());
            Assert.assertTrue(personalDetailsPage.getWorkPhone().isEmpty());

            LOG.info("Employer name and work phone fields should not be displayed.");
            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();
            final String listingId = tilaPage.getListingIdFromTILAContent();
            LOG.info("User listingid is:" + listingId);
            tilaPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilaPage.clickContinue();

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            final AccountOverviewPage accountOverviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();
            // Move to myaccount in case if signin page occurence
            if (accountOverviewPage.getWindowLocationHref().contains("signin")) {
                accountOverviewPage
                        .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                accountOverviewPage.dismissCongratulationWelcomeModal();
            }
            accountOverviewPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            // Navigate to 'Event History' Page
            final AccountHistoryPage historyPage = accountOverviewPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();

            eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.LEGAL_DOCUMENT_SAVED,
                    Constants.EventHistorypage.CREDIT_AUTHORIZATION_EVENT_DETAIL);
            eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.LEGAL_DOCUMENT_SAVED,
                    Constants.EventHistorypage.PRIVACY_POLICY_EVENT_DETAIL);
            eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.LEGAL_DOCUMENT_SAVED,
                    Constants.EventHistorypage.TERMS_OF_USE_EVENT_DETAIL);
            eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.LEGAL_DOCUMENT_SAVED,
                    Constants.EventHistorypage.DATA_TERMS_OF_USE_EVENT_DETAIL);
            eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.LEGAL_DOCUMENT_SAVED,
                    Constants.EventHistorypage.WEBBANK_PRIVAY_EVENT_DETAIL);
            LOG.info(
                    "BMP-3737 Verify that all the agreements are saved correctly in History of user on submitting DX personal details landing page");
            LOG.info("User navigate to Thank you  Page");
            LOG.info(
                    "BMP-3733 Verify that user who did not provide personal details in DX request is able to complete DX listing");
            LOG.info("~~~~NewDXUserWithOutPersonalDetailTest--PASSED~~~~~~~~~~~");

        }
    }
}
