
package test.ui.pubsite.borrower.dataExchange;

import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ProspectResponseCodes;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

/**
 * Verify AA charge off user loan
 *
 * @author jdoriya 13-May-2016
 *
 */
public class BorrowerDXExistingChargeOfferLoanUserTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXExistingChargeOfferLoanUserTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    // BMP-885 Existing User:Get Offer: Adverse Action Chargeoff Loan : Correct response details should be displayed in SoapUI
    // response to the existing user in SoapUI response to the DX user coming through Get Offer Having Chargeoff Loan.
    @Test(groups = {TestGroup.NIGHTLY})
    void testExistingChargeOffLoanAdverseAction() throws HttpRequestException, AutomationException, UnsupportedEncodingException {
        LOG.info("Executing: testExistingChargeOffLoanAdverseAction");

        ModifiedXmlEntity entity = buildDXReferralOfferExistingUserRequest(Constants.ClientTokenUsers.creditKarmaSubProgramID,
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toString(), "3000",
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG).toString(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG).toString());
        String email = getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG);
        LOG.info("Charged Offer Loan User is : " + email);

        // reset Adverse action event date to avoid 120 decline
        UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String userID = userInfo.getUserIDByEmail(email);
        LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
        loanOfferDeclineInfo.updateCreatedDate(userID);
        AdverseActionEventDAO adverseActionEventInfo =
                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
        adverseActionEventInfo.updateAdverseActionEventDate(userID);
        PollingUtilities.sleep(2000);
        HttpResponse dxReferralOfferResponse = creditKarmaWCFService.getOffers(entity.getRequestBody());
        String[] allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), Constants.dxResponse.GETOFFERELIGIBILITYSTATUS);
        Assert.assertEquals(allURLs[0], Constants.dxResponseTagValue.GETOFFERINELIGIBLESTATUS,
                "EligibilityStatus is not correct");
        LOG.info("Charge off user is not getting offers");
        String[] statusCodes = getTagValue(dxReferralOfferResponse.getResponseBody(), Constants.dxResponse.GETOFFERSTATUSCODE);

        // Verify Prospect table
        MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
        ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        String prospectCreatedDate = prospectInfo.getCreatedDate(email);
        ProspectResponseCodes codes = prospectInfo.getResponseCodes(email);
        prospectInfo.getOfferUserId(email);
        String offerUserID = prospectInfo.getOfferUserId(email);
        LOG.info("User OfferUserID is: " + offerUserID);
        prospectInfo.getCreatedDate(email);


        Assert.assertTrue(prospectCreatedDate
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");

        Assert.assertEquals(codes.getHttpResponseCode(), "200", "Correct 'HTTPResponseCode' should be displayed");

        Assert.assertEquals(codes.getStatusCode(), statusCodes[0], "Correct 'StatusCode' should be displayed");


        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");

        // verify AdverseActionEvent table:
        PollingUtilities.sleep(40000);


        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(email),
                AdverseActionTemplate.PRIOR_LOAN_CHARGEOFF.getAdverseActionEventTypeID());
        LOG.info("verified Adverse Action verification");
        String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(email);

        Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
                SquareCutTemplate.PRIOR_LOAN_CHARGEOFF.getSquareCutTypeID());
        LOG.info("verified SquareCutTypeID verification");
        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
                "messagesent data should not be null");
        LOG.info("verified Message sent tbl status");


        Assert.assertEquals(
                loanOfferDeclineInfo.getDeclineReasonID(offerUserID),
                DeclineReasonTemplate.PRIOR_LOAN_CHARGEOFF.getDeclineReasonID());
        LOG.info("verified Decline ReasonID ");
        LOG.info(
                "BMP-885 Existing User:Get Offer: Adverse Action Chargeoff Loan : Correct response details should be displayed in SoapUI response to the existing user in SoapUI response to the DX user coming through Get Offer Having Chargeoff Loan.");

        // verifyWebMail(outlookQAWebAppPage, "QA", email,
        // getExistingChargeOfferLoanBorrowerData().get(Constants.RegisterationPage.FIRSTNAME_TAG),
        // MessageBundle.getMessage("unableToApplyLoanSubject"), MessageBundle.getMessage("chargeOffLoanViewMessage"));
        LOG.info(
                "BMP-869 Verify that no content issues are displayed in Ineligible for 2nd Loan AA letter to DX AA user in personal mail box");
    }
}
