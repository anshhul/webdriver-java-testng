
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.enumeration.platform.EmploymentStatus;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

/**
 * Created by jdoriya on 9/28/2016
 */
public class NewDXGetOfferNewSelfEmployedUserTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewDXGetOfferNewSelfEmployedUserTest.class.getSimpleName());


    // BMP-3868 Verify that end-to-end DX flow from new PD landing page for self-employed user
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    public void testNewDXGetOfferSelfEmployedUser()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testNewDXGetOfferSelfEmployedUser~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForSelfEmployedPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);
        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + newUri)) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));

                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();

            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertFalse(personalDetailsPage.isEmployerNameFieldDisplayed());
            Assert.assertFalse(personalDetailsPage.isWorkPhoneFieldDisplayed());

            LOG.info("Employer name and work phone fields should not be displayed.");
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();
            tilaPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilaPage.clickContinue();

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            publicSiteThankYouPage.clickGoToMyAccountPage();
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final List<Map<String, Object>> lendingAccreditationRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
            Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            LOG.info("User navigate to Thank you  Page");
            LOG.info("BMP-3868 Verify that end-to-end DX flow from new PD landing page for self-employed user");
            LOG.info("~~~~testNewTilaForDXGetOfferUser--PASSED~~~~~~~~~~~");

        }
    }

    protected DXReferralRequest buildDXReferralOfferSelfEmploymentRequest(Hashtable<String, String> testData,
                                                          String userEmail)
            throws AutomationException {
        return new DXReferralRequest.Builder()
                .withSubProgramId(SUB_PROGRAM_ID)
                // experian data for different credit ratings
                .withFirstName(testData.get(Constants.RegisterationPageConstants.FIRSTNAME_TAG))
                .withLastName(testData.get(Constants.RegisterationPageConstants.LASTNAME_TAG))
                .withDateOfBirth(testData.get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG))
                .withStreet(testData.get(Constants.RegisterationPageConstants.STREETNAME_TAG))
                .withCity(testData.get(Constants.RegisterationPageConstants.CITYNAME_TAG))
                .withState(testData.get(Constants.RegisterationPageConstants.STATE_TAG))
                .withZipCode(testData.get(Constants.RegisterationPageConstants.ZIPCODE_TAG))
                .withSsn(testData.get(Constants.RegisterationPageConstants.SSN_TAG))
                // contact information
                .withEmailAddress(userEmail)
                // loan information
                .withLoanAmount(LOAN_AMOUNT).withLoanPurposeId(LOAN_PURPOSE_ID)
                // employment information
                .withOccupationalId(OCCUPATIONAL_ID)
                .withYearlyIncome(testData.get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG))
                .withYearlyIncomeVerifiable(YEARLY_INCOME_VERIFIABLE)
                .withEmploymentStatusId(Long.valueOf(EmploymentStatus.SELF_EMPLOYED.getId()))
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)
                .withEmployerName(EMPLOYER_NAME)
                // reported credit score
                .withSelfReportedCreditScore(SELF_REPORTED_CREDIT_SCORE)
                .withHomePhoneAreaCode(Constants.UserCommonTestDetails.HOMEPHONEAREACODE)
                .withHomePhoneNumber(Constants.UserCommonTestDetails.HOMEPHONENUMBER)
                .withMobilePhoneAreaCode(Constants.UserCommonTestDetails.MOBILEAREACODE)
                .withMobilePhoneNumber(Constants.UserCommonTestDetails.MOBILENUMBER)
                .withWorkPhoneAreaCode(Constants.UserCommonTestDetails.WORKPHONEAREACODE)
                .withWorkPhoneNumber(Constants.UserCommonTestDetails.WORKPHONENUMBER)
                .withEmployerPhoneAreaCode(Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE)
                .withEmployerPhoneNumber(Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER)
                // bank account information
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(testData.get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();
    }
}
