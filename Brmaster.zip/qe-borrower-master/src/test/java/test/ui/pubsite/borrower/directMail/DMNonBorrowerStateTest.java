
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Created by rsubramanyam on 6/23/16.
 *
 */
public class DMNonBorrowerStateTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMNonBorrowerStateTest.class.getSimpleName());


    // GEAR-1363 Verify that decline page is displayed after submitting Register page to 'WV' state user
    @Test(groups = {TestGroup.NIGHTLY})
    void testNonBorrowerStateWithValidUnconsumedOfferFlow() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: testNonBorrowerStateWithValidUnconsumedOfferFlow~~~~~~~~~~~~~~~~~~~~");
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig, publicSiteUrlScheme,
                publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            resetOfferCode(getNonBorrowerStateData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getNonBorrowerStateData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

            Assert.assertTrue(
                    publicSiteRegistrationPage.isStaticTextDisplayed(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE),
                    "Restriction should be displayed to WV State User");
        }
    }

    // GEAR-1363 Verify that decline page is displayed after submitting Register page to 'WV' state user
    @Test(groups = {TestGroup.NIGHTLY})
    void testNonBorrowerStateWithBlankOfferCodeFlow() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: testNonBorrowerStateWithBlankOfferCodeFlow~~~~~~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // dm offer dialog box will be displayed
            Assert.assertTrue(partnerLandingPage.getDMOfferValidationDialogAsElement().size() == 1);

            // dm offer dialog header content
            Assert.assertEquals(partnerLandingPage.getDMOfferDialogHeader(), Constants.PartnerLandingPage.DMOFFERDIALOGHEADER);

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();
            // enter borrower registration details
            publicSiteRegistrationPage
                    .enterZipCode(getNonBorrowerStateData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            Assert.assertTrue(
                    publicSiteRegistrationPage.isStaticTextDisplayed(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE),
                    "Restriction should be displayed to WV State User");
        }
    }

    // GEAR-1363 Verify that decline page is displayed after submitting Register page to 'WV' state user
    @Test(groups = {TestGroup.NIGHTLY})
    void testNonBorrowerStateWithInvalidOfferCodeFlow() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: testNonBorrowerStateWithInvalidOfferCodeFlow~~~~~~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                    "#@$%");

            // dm offer dialog box will be displayed
            Assert.assertTrue(partnerLandingPage.getDMOfferValidationDialogAsElement().size() == 1);

            // dm offer dialog header content
            Assert.assertEquals(partnerLandingPage.getDMOfferDialogHeader(), Constants.PartnerLandingPage.DMOFFERDIALOGHEADER);

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();
            // enter borrower registration details
            publicSiteRegistrationPage
                    .enterZipCode(getNonBorrowerStateData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            Assert.assertTrue(
                    publicSiteRegistrationPage.isStaticTextDisplayed(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE),
                    "Restriction should be displayed to WV State User");
        }
    }
}
