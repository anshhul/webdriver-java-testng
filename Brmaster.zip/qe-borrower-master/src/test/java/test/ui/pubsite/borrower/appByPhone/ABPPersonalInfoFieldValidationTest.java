
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.enumeration.platform.EmploymentStatus;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 02-Sep-2016
 *
 */
public class ABPPersonalInfoFieldValidationTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPPersonalInfoFieldValidationTest.class.getSimpleName());
    private static final String BAD_EMPLOYMENT_SOD_YEAR = "12/26";
    private static final String BAD_EMPLOYMENT_SOD_MONTH = "13/2001";


    // BMP-2518 ABP: Verify functionality of \"Continue\" button displayed on personal details page.
    // BMP-2575 ABP: Verify \"Complete Later\" button displayed on personal details page
    // BMP-2477 ABP: Verify \"Continue\" button displayed on personal details page.
    // BMP-2451 ABP: Verify Year of Employment field auto formatted while entering Year of Employment
    // BMP-2462 ABP: Verify SSN field auto formatted while entering SSN
    // BMP-2488 ABP: Verify functionality of \"Complete Later\" button displayed on personal details page.
    @Test(groups = {TestGroup.NIGHTLY})
    void testPersonalDetailFields() throws AutomationException {
        LOG.info("~~~~~~~Executing: testPersonalDetailFields~~~~~~~~~~~~~~");
        // login to support site
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testPersonalDetailFields", "p2pcredit");
            LOG.info("ABP User email is " + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");

            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            // verify complete-later option for user

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            Assert.assertTrue(abpPersonalDetailPage.isElementPresentOnPersonDetailPage("complete-later-personal-details"));
            LOG.info("BMP-2575 ABP: Verify \"Complete Later\" button displayed on personal details page");
            Assert.assertTrue(abpPersonalDetailPage.isElementPresentOnPersonDetailPage("continue-personal-details"));
            LOG.info("BMP-2477 ABP: Verify \"Continue\" button displayed on personal details page.");
            abpPersonalDetailPage.enterStartOfEmployment(BAD_EMPLOYMENT_SOD_YEAR);
            abpPersonalDetailPage.clickOnContinue();
            Assert.assertTrue(abpPersonalDetailPage.isTextPresent(Constants.BAD_EMPLOYMENT_SOD_MESSAGE, false));

            abpPersonalDetailPage.enterStartOfEmployment(BAD_EMPLOYMENT_SOD_MONTH);
            abpPersonalDetailPage.clickOnContinue();
            Assert.assertTrue(abpPersonalDetailPage.isTextPresent(Constants.BAD_EMPLOYMENT_SOD_MESSAGE, false));
            PollingUtilities.sleep(2000);
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            Assert.assertFalse(abpPersonalDetailPage.isTextPresent(Constants.BAD_EMPLOYMENT_SOD_MESSAGE, false));
            LOG.info("BMP-2451 ABP: Verify Year of Employment field auto formatted while entering Year of Employment");
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            PollingUtilities.sleep(1000);
            abpPersonalDetailPage.clickPersonalDetailHeader();
            Assert.assertEquals(abpPersonalDetailPage.getSocialSecurityNumber(),
                    formatSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG)));
            LOG.info("BMP-2462 ABP: Verify SSN field auto formatted while entering SSN");

            abpPersonalDetailPage.clickOnCompleteLater();
            Assert.assertTrue(abpPersonalDetailPage.getCompleteLaterModalForm().isDisplayed());
            LOG.info("BMP-2488 ABP: Verify functionality of \"Complete Later\" button displayed on personal details page.");

            abpPersonalDetailPage.clickCloseCompleteLaterModal();
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            Assert.assertNotNull(abpBankInfoPage);
            LOG.info("BMP-2518 ABP: Verify functionality of \"Continue\" button displayed on personal details page.");
        }
    }

    private String formatSocialSecurityNumber(String ssn) {
        final String s1 = ssn.substring(0, 3);
        final String s2 = ssn.substring(3, 5);
        final String s3 = ssn.substring(5, ssn.length());
        return (s1 + "-" + s2 + "-" + s3);
    }

    // BMP-2484 ABP: Verify employment status "Employed" displayed on Personal detail page
    // BMP-2537 ABP: Verify employment status "Other" displayed on Personal detail page
    // BMP-2527 ABP: Verify employment status "Self Employed" displayed on Personal detail page
    @Test(dataProvider = "employmentOptions", groups = {TestGroup.NIGHTLY})
    void testEmploymentCaption(EmploymentStatus employmentStatus) throws AutomationException {
        LOG.info("~~~~~~~Executing: testEmploymentCaption~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testEmploymentCaption", "p2pcredit");
        LOG.info("ABP User email is " + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(employmentStatus.getDescription());
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        Assert.assertEquals(abpPersonalDetailPage.getEmploymentCaption(), employmentStatus.getDescription().toUpperCase());
    }

    @DataProvider(name = "employmentOptions")
    public static Object[][] employmentStatus() {
        return new Object[][] {
                {EmploymentStatus.OTHER},
                {EmploymentStatus.SELF_EMPLOYED},
                {EmploymentStatus.EMPLOYED},
        };
    }
}
