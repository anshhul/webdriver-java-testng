
package test.ui.pubsite.borrower.appByPhone.withoutEmailInboxCheck;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmailValidationResponse;
import com.prosper.automation.model.platform.UserEmailVerifyResponse;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Created by ppatil on 5/27/16.
 */

public class ABPHappyPathBWithoutEmailTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    // Should be greater then $6000.0
    private static String MA_STATE_USER_LOAN_AMOUNT = "7000";
    protected static final Logger LOG = Logger.getLogger(ABPHappyPathBWithoutEmailTest.class.getSimpleName());
    private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
    private static final String SUCCESS_PASSWORD_MESSAGE = "Success. Your password has been changed.";
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    // PART-1326 [Direct Mail] Path B: Path Borrower should be able to complete the funnel from public site java funnel.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testHappyPathBFlowWithoutEmail() throws AutomationException, MalformedURLException, HttpRequestException {

        LOG.info("~~~~~~~~~~~~~Executing: testHappyPathBFlowWithoutEmail~~~~~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        String urlFromWeb = null;
        String pathBUrl=null;
        List<Map<String, Object>> prospectInfo = null;
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testPathB", "p2pcredit");
        final String offerCode = getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG);
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.deleteAllCookies();
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            resetOfferCode(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG));
            supportSiteMainPage.enterOfferCode(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG));
            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");

            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

            abpRegistrationPage.enterLoanAmount(MA_STATE_USER_LOAN_AMOUNT);
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");

            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            abpRegistrationPage.handleSSNPage(getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.SSN_TAG));
            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();

            // Verify the values displayed in table Prospect
            // verify prospect details for the user
            prospectInfo = queryCircleOne(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
            final List<Map<String, Object>> prospectDisclosuresTable =
                    queryCircleOne(String.format(MessageBundle.getMessage("prospectDisclosureQuery"),
                            prospectInfo.get(0).get("ProspectID").toString()));

            Assert.assertTrue(prospectDisclosuresTable.get(0).get("DisclosureID").toString().equals("1500"),
                    "DisclosureID = 1500 should be stored");
            Assert.assertTrue(prospectDisclosuresTable.get(1).get("DisclosureID").toString().equals("1501"),
                    "DisclosureID = 1501 should be stored");
            Assert.assertTrue(prospectDisclosuresTable.get(2).get("DisclosureID").toString().equals("1502"),
                    "DisclosureID = 1502 should be stored");
            LOG.info(
                    "BMP-3927 DM: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of Prospect table in prospect db");
            LOG.info(
                    "BMP-3929 DM: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect table in prospect db");
            LOG.info(
                    "BMP-3945 DM: Verify that correct Phone Disclosure ID is displayed in Phone Disclosure column of Prospect table in prospect db");

            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            pathBUrl = abpPersonalDetailPage.getABPPathBUrl(referralCode);
            // abandon the flow , click on complete later button
            abpPersonalDetailPage.clickOnCompleteLater();
            PollingUtilities.sleep(3000);
            // wait for complete later modal to appear
            Assert.assertTrue(abpPersonalDetailPage.isCompleteLaterModalDisplayed());
            // select abandon reason for flow
            abpPersonalDetailPage.selectAbandonReason("Miscellaneous");
            // submit the abandon reason
            abpPersonalDetailPage.clickOnSubmitAbandonReason();
            PollingUtilities.sleep(3000);
            Assert.assertTrue(abpPersonalDetailPage.getCompleteLaterModalHeader().getText().contains("Success!"));
            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        // Use the generated ABP PathB URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathBUrl), URLUtilities.getStringURLWithoutScheme(pathBUrl))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            Assert.assertNotNull(prospectInfo.get(0).get("AgentID").toString(), "Agent Id should not be null");
            LOG.info(
                    "BMP-3960 Standard: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");
            LOG.info(
                    "BMP-3916 DM: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");

            LOG.info(prospectInfo.get(0).get("OfferUserID").toString());
            Assert.assertNotNull(prospectInfo.get(0).get("OfferUserID"), "Loan Offer ID should be not null");
            LOG.info(
                    "BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of Prospect table in prospect db");
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSitePersonalDetailPage personalDetailPage = abpLandingPage.reviewYourOfferPathB();
            // verify the prospect tbl records
            final Map<String, Object> prospectRows = queryProspectDb(
                    MessageBundle.getMessage("prospectOfferCodeQuery").replace("{offerCode}", offerCode)).get(0);

            // Prospect records shouldnot be null
            Assert.assertFalse(prospectRows.isEmpty(), "Prospect is not generated yet");
            LOG.info("Prospect is generated into prospecttbl for prospect user");

            // verify engagementdate of prospect
            Assert.assertTrue(prospectRows.get("EngagementDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                    "Correct 'CreatedDate' should be displayed");
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            // verify userid of prospect
           /* Preconditions.checkNotNull(prospectRows.get("UserId"), "Userid is null in prospecttbl");*/
        /*    Assert.assertTrue(prospectRows.get("UserId").toString().contains(userId),
                    "Correct 'userId' should be displayed");*/
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            PollingUtilities.sleep(3000);
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path B Borrower ListingID is:" + listingID);
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            final Map<String, Object> varID73 = loanOfferScoreDetails.get(1);
            
            //for the time being allowing the timestamp to be populated with offercode
            Assert.assertTrue(varID38.get("Value").toString().contains(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG)));
           /* Assert.assertEquals(varID38.get("Value").toString(),
              getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG),
                    "var 38 value should be same as offer code provided");*/
            final String var_73_actualValue = varID73.get("Value").toString();
            // verify DM reduce pricing as || corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code");

            final List<Map<String, Object>> prospectRecord =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
            final String attributionMethodId = prospectRecord.get(0).get("UserAttributionMethodID").toString();
            if (attributionMethodId != "2") {
                Assert.assertEquals(var_73_actualValue, "DirectMail|Str201407|C");
            }
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
            accountOverviewPage.deleteAllCookies();
            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = accountOverviewPage.clickOnProsperLogo();
            final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();
            final PublicSiteRequestEmailForChangePasswordPage changePasswordPage = publicSiteSignInPage.clickForgotPassword();
            changePasswordPage.enterEmailAddress(email);
            changePasswordPage.clickContinue();

            verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), email,
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp_resetPassword"),
                    MessageBundle.getMessage("followingUpBody_resetPassword"));

            // resetCode = changePasswordPage.getResetCodeForUser(identityVerificationUrl);
            final EmailValidationResponse responseFromEmailService = pubSiteUserService.validateUserEmail(email);
            final UserEmailVerifyResponse verifyResponse =
                    pubSiteUserService.verifyUserEmail(responseFromEmailService.getActivationKey());
            Assert.assertTrue(verifyResponse.getIsVerified());
            final String resetCode = circleOneDBConnection.getDataAccessObject(UserDAO.class).getUserIDByEmail(email);
            changePasswordPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + resetCode));
            final PublicSiteMarketplaceLandingPage verificationPage = changePasswordPage.gotoMarketPlaceLandingPage();
            final PasswordChangePage passwordChangePage = verificationPage.resetPasswordForUser(
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            passwordChangePage.enterNewPassword("P@ssword24");
            passwordChangePage.confirmNewPassword("P@ssword24");

            final PublicSiteSignInPage publicSiteSignInAgainPage = passwordChangePage.clickChangePassword();
            Assert.assertTrue(passwordChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
            Assert.assertTrue(passwordChangePage.isStaticTextDisplayed(SUCCESS_PASSWORD_MESSAGE));

            final AccountOverviewPage accountOverviewAgainPage = publicSiteSignInAgainPage.signIn(email, "P@ssword24");
            Assert.assertNotNull(accountOverviewAgainPage);
            LOG.info("GEAR-1274 Verify that registered user is navigated back to sign-in page on resetting his password");
            if (accountOverviewAgainPage.getWindowLocationHref().contains("signin")) {
                accountOverviewAgainPage
                        .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                accountOverviewAgainPage.dismissCongratulationWelcomeModal();
                LOG.info("BMP-1816 Verify that both user with c1.stg & p2pcredit domain are able to reset their password");
            }
            LOG.info("BMP-1816 Verify that both user with c1.stg & p2pcredit domain are able to reset their password");
            LOG.info(
                    "PART-1326[Direct Mail] Path B: Path Borrower should be able to complete the funnel from public site java funnel.");
        }

    }
}
