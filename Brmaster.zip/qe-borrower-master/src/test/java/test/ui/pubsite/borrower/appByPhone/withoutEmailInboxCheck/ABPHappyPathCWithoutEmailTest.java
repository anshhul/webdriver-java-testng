
package test.ui.pubsite.borrower.appByPhone.withoutEmailInboxCheck;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

/**
 * Created by ppatil on 5/27/16.
 */

public class ABPHappyPathCWithoutEmailTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    private static String MA_STATE_USER_LOAN_AMOUNT = "7000";
    protected static final Logger LOG = Logger.getLogger(ABPHappyPathCWithoutEmailTest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // PART-1327 [Direct Mail] Path C: Path Borrower should be able to complete the funnel from public site java funnel.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testHappyPathCFlow() throws AutomationException {

        LOG.info("~~~~~~~~~~~~~~~~~~~~~~~Executing: testHappyPathCFlow~~~~~~~~~~~~~~~~~~~~");
        String pathCUrl=null;
        String listingID = null;
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testPathC", "p2pcredit");
        final String offerCode = getAllDmValidOfferCode().get(0).get(Constants.HomeWidgetPage.OFFCODE_TAG);
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.deleteAllCookies();
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            resetOfferCode(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG));
            supportSiteMainPage.enterOfferCode(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG));
            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");

            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                    getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

            abpRegistrationPage.enterLoanAmount(MA_STATE_USER_LOAN_AMOUNT);
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");

            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            abpRegistrationPage.handleSSNPage(getAllDmValidOfferCode().get(0).get(Constants.RegisterationPageConstants.SSN_TAG));
            // Get referal code from url
            pathCUrl = abpOfferPage.getABPPathCUrl();

            // click on complete later button
            abpOfferPage.clickOnCompleteLater();
            // wait for complete later modal to appear
            PollingUtilities.sleep(3000);
            Assert.assertTrue(abpOfferPage.isCompleteLaterModalDisplayed());
            // select abandon reason for flow
            abpOfferPage.selectAbandonReason("Miscellaneous");
            PollingUtilities.sleep(3000);
            // submit the abandon reason
            abpOfferPage.clickOnSubmitAbandonReason();
            PollingUtilities.sleep(4000);
            LOG.info("Text displayed on complete later modal: " + abpOfferPage.getCompleteLaterModalHeader().getText());

            Assert.assertTrue(abpOfferPage.getCompleteLaterModalHeader().getText().contains("Success!"));
            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getAllDmValidOfferCode().get(0).get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        // Use the generated ABP PathC URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathCUrl), URLUtilities.getStringURLWithoutScheme(pathCUrl))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(pathCUrl);
            // verify the prospect tbl records
            final Map<String, Object> prospectRows = queryProspectDb(
                    MessageBundle.getMessage("prospectOfferCodeQuery").replace("{offerCode}", offerCode)).get(0);

            // Prospect records shouldnot be null
            Assert.assertFalse(prospectRows.isEmpty(), "Prospect is not generated yet");
            LOG.info("Prospect is generated into prospecttbl for prospect user");

            // verify engagementdate of prospect
            Assert.assertTrue(prospectRows.get("EngagementDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                    "Correct 'CreatedDate' should be displayed");
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            userInfo.getUserIDByEmail(email);
            // verify userid of prospect
      /*      Preconditions.checkNotNull(prospectRows.get("UserId"), "Userid is null in prospecttbl");
            Assert.assertTrue(prospectRows.get("UserId").toString().contains(userId),
                    "Correct 'userId' should be displayed");*/
            // GEAR-2257 issue is minor update once defect is closed
            publicSiteRegistrationPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            PollingUtilities.sleep(3000);
            listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage =
                    publicSiteBankAccountInfoPage.submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage accountOverviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();
            accountOverviewPage.close();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path B Borrower ListingID is:" + listingID);
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            final Map<String, Object> varID73 = loanOfferScoreDetails.get(1);

            //for the time being allowing the timestamp to be populated with offercode
            Assert.assertTrue(varID38.get("Value").toString().contains(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG)));

            // AutoBlocker:BR-187 STG2: Incorrect value is populated for var 38 in tblLoanOfferScoreDetail for DM User via ABP
            // funnel
            /*
             * Assert.assertEquals(varID38.get("Value").toString(),
             * getAllDmValidOfferCode().get(0).get(Constants.HomeWidgetPage.OFFCODE_TAG),
             * "var 38 value should be same as offer code provided");
             */
            final String var_73_actualValue = varID73.get("Value").toString();

            // verify DM reduce pricing as || corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code");
            final List<Map<String, Object>> prospectRecord =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
            final String attributionMethodId = prospectRecord.get(0).get("UserAttributionMethodID").toString();
            if (attributionMethodId != "2") {
                Assert.assertEquals(var_73_actualValue, "DirectMail|Str201407|C");

            }
            LOG.info(
                    "PART-1327 [Direct Mail] Path C: Path Borrower should be able to complete the funnel from public site java funnel.");
        }
        // Log into the Support site with user created above
        try (final ClassPathXmlApplicationContext verifySupportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingAgainPage =
                    (SupportSiteLandingPage) verifySupportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingAgainPage.enterEmailAddress();
            supportSiteLandingAgainPage.enterPassword(Constant.COMMON_PASSWORD);

            final SupportSiteMainPage supportSiteMainAgainPage = supportSiteLandingAgainPage.clickLogin();
            // Activate listing
            supportSiteMainAgainPage.activateListing(listingID, "1");
            final SupportSiteMembersPage memberPage = supportSiteMainAgainPage.clickMembersLink();
            memberPage.searchByEmail(email);
            // Commenting view link on member page as per defect BR-574.
            // final SupportBorrowerTabPage supportBorrowerTabPage = memberPage.clickOnView();

            final SupportBorrowerTabPage supportBorrowerTabPage = memberPage.goToSupportBorrowerTabPage();
            final SupportBorrowerListingsTabPage borrowerListingsTabPage = supportBorrowerTabPage.clickOnListings();
            Assert.assertTrue(borrowerListingsTabPage.getSource().contains("AppByPhone"));
            Assert.assertTrue(borrowerListingsTabPage.getChannel().contains("DirectMail"));

            verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                    MessageBundle.getMessage("verifyEmailAddress"), MessageBundle.getMessage("verifyEmailAddressEmailContent"));

            verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                    MessageBundle.getMessage("bankAccountSubject"), MessageBundle.getMessage("bankAccountEmailContent"));

            verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                    MessageBundle.getMessage("listingActivatedSubject"), MessageBundle.getMessage("listingActivatedBody"));
            LOG.info("~~~~~~~~~~testHappyPathCFlow--PASSED~~~~~~~~~~~~~~~~~~~~");
        }
    }
}
