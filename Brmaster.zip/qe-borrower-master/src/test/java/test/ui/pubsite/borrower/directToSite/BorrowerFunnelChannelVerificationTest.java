
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-612 Verify that user came through DTS funnel
 *
 * BMP-613 Verify that user came through ABP funnel
 *
 * BMP-614 Verify that user came through DM/PLP funnel
 *
 * @author hnegi
 */
public class BorrowerFunnelChannelVerificationTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerFunnelChannelVerificationTest.class.getSimpleName());
    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    private static String ABPEMAILDOMAIN = "p2pcredit";

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    String listingId = null;
    HashMap<String, String> testData;


    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose", "homeImprovementListing"),
        };
    }

    @Test(dataProvider = "testData", groups = {TestGroup.NIGHTLY})
    public void verifyDTSChannelVerification(String Key, String jiraID, String loanAmount, String loanPurpose,
                                             String creditQuality,
                                             String firstName, String middleInitial, String lastName,
                                             String homeAddress, String city, String state, String zipCode,
                                             String employmentStatus,
                                             String yearlyIncome, String dob, String emailAddress, String password,
                                             String homePhone, String mobilePhone, String workPhone, String employerName,
                                             String employerPhone, String occupation, String employmentStartDate, String SSN,
                                             String bankName,
                                             String accountType, String accountholderName, String AlternateAccountHolderName,
                                             String routingNumber, String accountNumber, String confirmAccountNumber,
                                             String paymentType)
            throws AutomationException {

        LOG.info("Test Method Name- verifyDTSChannelVerification");

        try (final ClassPathXmlApplicationContext publicSiteContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) publicSiteContext.getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage.checkYourRate();
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("dtsFunnelVerify");
            // Submit Register page
            registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, Constant.COMMON_PASSWORD, firstName,
                    lastName,
                    homeAddress,
                    city, state, employmentStatus, yearlyIncome, dob);
            registrationPage.clickElectronicSignatureCheckBox();
            final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

            // Submit Loan Offers page
            final PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

            // Submit Personal Details page
            detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
                    employmentStartDate, SSN);
            final PublicSiteTruthInLendingDisclosurePage tilaPage = detailsPage.clickContinue();

            // Accept agreement and submit Tila page
            tilaPage.confirmElectronicSignature();
            listingId = tilaPage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage bankInfoPage = tilaPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

            // Submit Bank Information Page
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankPage.enterBankInfo(bankName, accountType, accountholderName, AlternateAccountHolderName,
                            routingNumber,
                            accountNumber, confirmAccountNumber, null);
            borrowerThankYouPage.clickGoToMyAccountPage();
        }
        // Log into the Support site with user created above
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            final SupportBorrowerListingsTabPage listingPage = memberPage.searchListingByID(listingId);
            Assert.assertTrue(listingPage.getSource().contains("Web"));
            Assert.assertTrue(listingPage.getChannel().contains("DirectToSite"));
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void verifyABPChannelVerification() throws AutomationException {

        LOG.info("~~~~~~~~~~Executing: testHappyPathAFlowWithoutEmail~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("abpFunnelVerify", ABPEMAILDOMAIN);
            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");

            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final String pathAUrl = abpPersonalDetailPage.getABPPathAUrl(referralCode);
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // enter bank details

            abpBankInfoPage
                    .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            abpBankInfoPage
                    .enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);
            // Use the generated ABP PathA URL(Skipping Mailbox)
            try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                    new PublicSiteMarketplaceLandingPage(webDriverConfig,
                            URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
                abpLandingPage.setPageElements(pageElements);
                abpLandingPage.clickElectronicSignatureCheckBox();
                abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
                LOG.info("Borrower submit the ABP Landing Page and create own Password");
                final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
                // String ListingID = getQueryMap(disclosurePage.getListingIdFromTILAContent()).get("listing_id");
                listingId = disclosurePage.getListingIdFromTILAContent();
                disclosurePage.confirmElectronicSignature();
                final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
                final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
                publicSiteThankYouPage.clickGoToMyAccountPage();
                publicSiteThankYouPage.close();

            }
        }
        // Log into the Support site with user created above
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            final SupportBorrowerListingsTabPage listingPage = memberPage.searchListingByID(listingId);
            Assert.assertTrue(listingPage.getSource().contains("AppByPhone"));
            Assert.assertTrue(listingPage.getChannel().contains("Affiliates"));
        }
        LOG.info("~~~~~~~~~~testHappyPathAFlowWithoutEmail--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void verifyDMChannelVerification() throws AutomationException {
        LOG.info("Executing: verifyDMChannelVerification");
        testData = new HashMap<>();
        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            final String refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            final String prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("dmFunnelVerify");

            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);

            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            // String listingId = getQueryMap(publicSiteTILAPage.getListingIdFromTILAContent()).get("listing_id");
            listingId = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature(); // User navigated to bank info page final
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            // Log into the Support site with user created above
            try (final ClassPathXmlApplicationContext jobContext =
                    new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

                final SupportSiteLandingPage supportSiteLandingPage =
                        (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

                supportSiteLandingPage.enterEmailAddress();
                supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

                final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

                final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
                final SupportBorrowerListingsTabPage listingPage = memberPage.searchListingByID(listingId);
                Assert.assertTrue(listingPage.getSource().contains("Web"));
                Assert.assertTrue(listingPage.getChannel().contains("Affiliates"));
            }
        }
    }

}
