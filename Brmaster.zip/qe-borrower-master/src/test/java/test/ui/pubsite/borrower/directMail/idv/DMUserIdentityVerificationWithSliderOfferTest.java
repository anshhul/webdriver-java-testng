
package test.ui.pubsite.borrower.directMail.idv;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi created on 24 Nov 2016
 */
public class DMUserIdentityVerificationWithSliderOfferTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMUserIdentityVerificationWithSliderOfferTest.class.getSimpleName());
    private static final String CREDIT_FILE_NOT_FOUND = "Credit file not found";


    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForWrongLastNameAndValidSSN() throws AutomationException {
        LOG.info("Executing: testFunnelForWrongLastNameAndValidSSN");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            Assert.assertTrue(publicSiteOfferPage.isSliderDisplayed());
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForWrongAddressAndValidSSN() throws AutomationException {
        LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndValidSSN~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            Assert.assertTrue(publicSiteOfferPage.isSliderPageDisplayed());
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForWrongLastNameAndWrongSSN() throws AutomationException {
        LOG.info("Executing: testFunnelForWrongLastNameAndWrongSSN");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            publicSiteRegistrationPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN);
            Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForWrongAddressAndWrongSSN() throws AutomationException {
        LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndWrongSSN~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            publicSiteRegistrationPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN);
            Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForWrongFirstName() throws AutomationException {
        LOG.info("~~~~~~Executing: testFunnelForWrongFirstName~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
        }
    }

    @Test(groups = {TestGroup.NIGHTLY})
    void testFunnelForIncorrectSSN() throws AutomationException {
        LOG.info("~~~~~~Executing: testFunnelForIncorrectSSN~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testFunnelForIncorrectSSN");

            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.SLIDER_FLAG_DM);

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // User navigate to Personal detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(Constants.UserCommonTestDetails.INTSSN_HYPHEN);

            personalDetailPage.clickOnContinue();
            PollingUtilities.sleep(2000);
            LOG.info("AUTO-473: Automated Scenarios where we are providing only incorrect SSN in all funnels");
            Assert.assertTrue(personalDetailPage.getSSNValidationMessage()
                    .contains(MessageBundle.getMessage("ssnValidationMessage")));

        }
    }
}
