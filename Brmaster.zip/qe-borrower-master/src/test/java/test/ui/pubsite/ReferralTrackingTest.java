
package test.ui.pubsite;

import com.prosper.automation.constant.web.DigitalLandingPagesSandboxConstants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.DigitalLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import test.api.WebServiceTestBase;

import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.webdriver.WebDriverConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.Map;

/**
 * Created by rsubramanyam on 5/2/16.
 */
public class ReferralTrackingTest extends WebServiceTestBase {
    @Autowired
    protected WebDriverConfig webDriverConfig;
    @Resource(name = "pageElements")
    protected Map<String, String> pageElements;
    private static final String REFAC_MC_ON_GOOGLE_CLICK = "refac=GoogSearch&refmc=BorGenAcq";
    private static final String REFAC_MC_ON_GOOGLE_CLICK_ON_REG_PAGE = "ref_ac=GoogSearch&ref_mc=BorGenAcq";
    private static final Double LOAN_AMOUNT = 5000.0;

    private static final String LOAN_PURPOSE = "Debt Consolidation";
    private static final String CREDIT_QUALITY = "Excellent Credit (760+)";

    @DataProvider(name = "landingPages")
    public static Object[][] landingPages() {
        return new Object[][] {
                {DigitalLandingPagesSandboxConstants.AUTO_LOANS_PAGE},
                {DigitalLandingPagesSandboxConstants.BABY_ADOPTION_LOANS_PAGE},
                {DigitalLandingPagesSandboxConstants.DEBT_CONSOLIDATION_LOANS_PAGE},
                {DigitalLandingPagesSandboxConstants.ENGAGEMENT_RING_FINANCING},
                {DigitalLandingPagesSandboxConstants.GREEN_LOANS},
                {DigitalLandingPagesSandboxConstants.HOME_IMPROVEMENT_PAGE},
                {DigitalLandingPagesSandboxConstants.MILITARY_LOANS},
                {DigitalLandingPagesSandboxConstants.PERSONAL_LOANS_PAGE},
                {DigitalLandingPagesSandboxConstants.SHORT_TERMS_LOANS_PAGE},
                {DigitalLandingPagesSandboxConstants.SPECIAL_OCCASION_LOANS}
        };
    }

    @Test(dataProvider = "landingPages")
    public void testRefAcRefMc(String url) throws AutomationException {
        try (final DigitalLandingPage preRegPage = new DigitalLandingPage(webDriverConfig,
                URLUtilities.getScheme(url),
                URLUtilities.getStringURLWithoutScheme(url), "OLD")) {
            preRegPage.setPageElements(pageElements);
            preRegPage.clickRedirectionUrl();
            Assert.assertTrue(preRegPage.getCurrentUrl().contains(REFAC_MC_ON_GOOGLE_CLICK));
            preRegPage.checkYourRate();
            Assert.assertTrue(preRegPage.getCurrentUrl().contains(REFAC_MC_ON_GOOGLE_CLICK));
        }
    }

    @Test
    public void testGetYourRate() throws AutomationException {
        try (final DigitalLandingPage preRegPage = new DigitalLandingPage(webDriverConfig,
                URLUtilities.getScheme(DigitalLandingPagesSandboxConstants.HOW_IT_WORKS_PAGE),
                URLUtilities.getStringURLWithoutScheme(DigitalLandingPagesSandboxConstants.HOW_IT_WORKS_PAGE), "OLD")) {
            preRegPage.setPageElements(pageElements);
            preRegPage.clickRedirectionUrl();
            Assert.assertTrue(preRegPage.getCurrentUrl().contains(REFAC_MC_ON_GOOGLE_CLICK));
            preRegPage.checkYourRateOnHowItWorksPage();
            Assert.assertTrue(preRegPage.getCurrentUrl().contains(REFAC_MC_ON_GOOGLE_CLICK));
        }
    }

    @Test
    public void testApplyOnline() throws AutomationException {
        try (final PublicSitePreRegistrationPage preRegPage = new PublicSitePreRegistrationPage(webDriverConfig,
                URLUtilities.getScheme(DigitalLandingPagesSandboxConstants.APPLY_ONLINE_PAGE),
                URLUtilities.getStringURLWithoutScheme(DigitalLandingPagesSandboxConstants.APPLY_ONLINE_PAGE))) {
            preRegPage.setPageElements(pageElements);
            preRegPage.clickRedirectionUrl();
            Assert.assertTrue(preRegPage.getCurrentURL().contains(REFAC_MC_ON_GOOGLE_CLICK));
            preRegPage.selectLoanPurpose(LOAN_PURPOSE);
            preRegPage.selectCreditQuality(CREDIT_QUALITY);
            preRegPage.enterLoanAmount(LOAN_AMOUNT);
            preRegPage.checkYourRate();
            Assert.assertTrue(preRegPage.getCurrentURL().contains(REFAC_MC_ON_GOOGLE_CLICK_ON_REG_PAGE));
        }
    }
}
