
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.ChangeContactInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-4078 Verify that Legal Name is displayed as borrowers name on new initial tila page when user have different legal name and
 * Preferred name BMP-4080 Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user
 * completes funnel with new tila page and user have different legal name and Preferred name BMP-4079 Verify that Legal Name is
 * displayed as borrowers name on old initial tila page when user have different legal name and Preferred name BMP-4081 Verify
 * that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user completes funnel with old tila page
 * and user have different legal name and Preferred name
 *
 * @author hnegi 03-Nov-2016
 *
 */
public class BorrowerLegalNameOnTILATest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerLegalNameOnTILATest.class.getSimpleName());
    private static final String BORROWER_PREFERRED_NAME = "testLegalName";


    @Test(groups = {TestGroup.ACCEPTANCE})
    void testBorrowerLegalNameOnNewTILA() throws AutomationException {
        LOG.info("~~~~~~~~~~Executing test : testBorrowerLegalNameOnTILA~~~~~~~~~~~~~~~~~~");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {
            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    publicSitePreRegistrationPage.checkYourRate();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testBorrowerLegalNameOnTILA");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            // Verify new Personal detail Header text
            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            tilaPage.clickOnProsperLogo();

            // Navigate to Settings Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = publicSitePreRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName(BORROWER_PREFERRED_NAME);
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage = changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            tilaPage = personalDetailsPage.clickContinue();
            tilaPage.navigateToNewTILAPage();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4078 Verify that Legal Name is displayed as borrowers name on new initial tila page when user have different legal name and Preferred name");

            tilaPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
            final PublicSitePreRegistrationPage preRegistrationPage = publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            preRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = preRegistrationPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLendingDisclosure();
            // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLendingDisclosure();
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4080 Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user completes funnel with new tila page and user have different legal name and Preferred name");
        }
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    void testBorrowerLegalNameOnOldTILA() throws AutomationException {
        LOG.info("~~~~~~~~~~Executing test : testBorrowerLegalNameOnTILA~~~~~~~~~~~~~~~~~~");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    publicSitePreRegistrationPage.checkYourRate();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testBorrowerLegalNameOnTILA");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            // Verify new Personal detail Header text
            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            final PublicSitePreRegistrationPage preRegistrationPage = tilaPage.clickOnProsperLogo();

            // Navigate to Settings Page
            preRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = preRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName(BORROWER_PREFERRED_NAME);
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage = changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            tilaPage = personalDetailsPage.clickContinue();

            tilaPage.navigateToOldTILAPage();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4079 Verify that Legal Name is displayed as borrowers name on old initial tila page when user have different legal name and Preferred name");

            tilaPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
            PollingUtilities.sleep(4000);
            publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLendingDisclosure();
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLendingDisclosure();;
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4081 Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user completes funnel with old tila page and user have different legal name and Preferred name");
        }
    }
}
