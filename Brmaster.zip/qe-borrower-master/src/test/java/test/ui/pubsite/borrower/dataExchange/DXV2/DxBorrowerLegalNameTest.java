
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya
 */
public class DxBorrowerLegalNameTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(DxBorrowerLegalNameTest.class.getSimpleName());
    private static final String DX_PREFERRED_NAME = "dxLegalNameTest";


    // BMP-4091 DX: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name
    // and Preferred name
    // BMP-4092 DX: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have
    // different legal name and Preferred name
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testDxBorrowerLegalName()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testDxBorrowerLegalName~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDxBorrowerLegalName");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String dxV2Url = allURLs[0].replace("amp;", "");
        LOG.info("dXv2Url  " + dxV2Url);
        final String offersUrlToUseForTesting = dxV2Url.replace("plp/dx-landing-page", "personal-loans/pre-approval");
        LOG.info("offersUrlToUseForTesting::  " + offersUrlToUseForTesting);
        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterDXPassword(Constant.COMMON_PASSWORD);
            LOG.info("isPasswordEntered::  Boolean :: " + isPasswordEntered);
            if (isPasswordEntered) {
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("File Permission Error"));
                String firstName = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG);
                Assert.assertEquals(dxLandingPage.getUserFirstName(), firstName.substring(0, 1).toUpperCase() + firstName.substring(1).toLowerCase());
                Assert.assertEquals(dxLandingPage.getDxWelcomeMsg(), "Welcome to Prosper.");
                LOG.info(

                        " DX v2: Correct Welcome message should be displayed on Pre Screen Create Password page.-Passed");
                Assert.assertTrue(dxLandingPage.getDxProsperLogo());
                LOG.info(
                        " DX v2: Correct Prosper Logo  should be displayed on DX Landing Page create password page.-Passed");

                Assert.assertEquals(dxLandingPage.getDxTitleText(), "We put together a great, pre-approved\n" +
                        "loan offer for you based on information\n" +
                        "we received from:");
//                Assert.assertEquals(dxLandingPage.getFooterDeclaration(),"This will not affect your credit score");
                dxLandingPage.verifyLoanTermsonLandingPage();
                dxLandingPage.clickElectronicSignatureCheckBox();
                LOG.info("User submitted the DX landing page successfully");

                LOG.info(
                        "BMP-1408 DX: A check box for agreements signature should be displayed on Pre Screen Create Password page.-Passed");
                personalDetailsPage =
                        dxLandingPage.ClickContinueButton(offersUrlToUseForTesting);
                LOG.info(
                        "BMP-1414   Lending Tree: Agree and Continue button should be displayed on Pre Screen Create Password page-Passed");

                dxLandingPage.clickElectronicSignatureCheckBox();
                dxLandingPage.ClickContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertFalse(personalDetailsPage.isStaticTextDisplayed("Sass Compiling Error"));
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = tilaPage.clickOnProsperLogo();
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = publicSitePreRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName(DX_PREFERRED_NAME);
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage = changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            final PublicSiteOfferPage publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            final PublicSiteTruthInLendingDisclosurePage tilaAgainPage = personalDetailsPage.clickContinue();
            tilaAgainPage.navigateToNewTILAPage();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            Assert.assertFalse(tilaAgainPage.isStaticTextDisplayed(DX_PREFERRED_NAME));
            LOG.info(
                    "BMP-4091 DX: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name and Preferred name");

            tilaAgainPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaAgainPage.clickContinue();
            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage =
                    publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            publicSitePreRegistrationAgainPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationAgainPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLendingDisclosure();
            // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLendingDisclosure();
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4092 DX: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have different legal name and Preferred name");
        }
    }
}
