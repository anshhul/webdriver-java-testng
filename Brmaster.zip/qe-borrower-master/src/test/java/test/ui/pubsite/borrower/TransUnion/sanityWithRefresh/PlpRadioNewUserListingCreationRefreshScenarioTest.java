
package test.ui.pubsite.borrower.TransUnion.sanityWithRefresh;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.UserCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * No records in affiliate referral tbl for the user
 *
 * BMP-532 PLP: complete listing
 *
 * @author jdoriya 12-May-2016
 *
 */
public class PlpRadioNewUserListingCreationRefreshScenarioTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PlpRadioNewUserListingCreationRefreshScenarioTest.class.getSimpleName());
    HashMap<String, String> testData;


    // BMP-5296 Verify lisitng creation from new credit karma landing page.
    @Test(groups = {TestGroup.SANITY})
    void test_Listing_Prospect_RefAc_RefMc_Affiliates_Channel() throws AutomationException {
        // calling listingCreation init method for User via Plp Page
        LOG.info("~~~~~~~~~~Executing test : test_Listing_Prospect_RefAc_RefMc_Affiliates_Channel~~~~~~~~~~~~~~~~~~");
        testData = userListingViaPlpPageWithRefresh();
        final String listingID = testData.get("LISTINGID");
        final String emailAddress = testData.get("EMAILADDRESS");
        LOG.info("Borrower coming via Plp Page is created listing successfully:" + listingID);

        // verify prospect tbl records
        final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        final Prospect prospectCreated =
                prospectRowDetailsInfo.getProspectInfoLogByEmailId(testData.get("EMAILADDRESS"));
        final ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        final String prospectCreatedDate = prospectInfo.getCreatedDate(testData.get("EMAILADDRESS"));
        // Verify Prospect table
        PollingUtilities.sleep(4000);
        Assert.assertTrue(prospectCreatedDate
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");
        Assert.assertTrue(prospectInfo.getEngagementDate(testData.get("EMAILADDRESS"))
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
        Assert.assertEquals(prospectCreated.getAddressInfo().getZipCode(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        Assert.assertEquals(prospectCreated.getAddressInfo().getAddress1().toString().trim(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).trim());
        Assert.assertEquals(prospectCreated.getAddressInfo().getCity().toString(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        Assert.assertEquals(prospectCreated.getAddressInfo().getState().toString(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        Assert.assertEquals(prospectCreated.getLoanAmount().toString().replaceAll("\\.0*$", ""),
                getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        final UserEmailDAO userEmailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userEmailDAO.getUserIDByEmail(emailAddress);
        /*
         * For row having CreditBureau=1 validate following: IsDecisionBureau should be "0". ExternalCreditReportId for
         * CreditBureau=1 should be = Select ExternalCreditReportId from Circleone..ExperianDocuments where UserID = <userid> and
         * documentType='Response Credit Profile'
         */

        final UserCreditProfilesDAO creditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
        // final UserCreditReportMappingModel creditReportMappingModel =
        // creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 1);
        //
        // // verify IsDecisionBureau is false:
        // Assert.assertEquals(creditReportMappingModel.isIsDecisionBureau(), "0");
        //
        // final ExperianDocumentDAO experianDocumentDAO = circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);
        // // verify externalCreditReportId
        // Assert.assertEquals(experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)),
        // creditReportMappingModel.getExternalCreditReportId());

        /*
         * For row having CreditBureau=2 validate following: ExternalCreditReportId should not be null. IsDecisionBureau should be
         * "1".
         */
        final UserCreditReportMappingModel creditReportMappingModelTu =
                creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 2);
        // verify IsDecisionBureau is false:
        Assert.assertEquals(creditReportMappingModelTu.isIsDecisionBureau(), "1");

        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);

        /*
         * For row having CreditBureau=1 validate following: IsDecisionBureau should be "0". ExternalCreditReportId should be =
         * Select ExternalCreditReportId from Circleone..ExperianDocuments where UserID = <userid> and documentType='Response
         * Credit Profile'
         */
        // final ListingCreditReportMappingModel listingCreditReportMappingModel =
        // listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 1);
        // // verify ExternalCreditReportId in tbl ListingCreditReportMapping
        // Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
        // experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
        // // verify IsDecisionBureau is false:
        // Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(), "0");

        /*
         * For row having CreditBureau=2 validate following: ExternalCreditReportId should be = Select ExternalCreditReportId from
         * Circleone..UserCreditReportMapping where UserID = <UserID> and CreditBureau=2 IsDecisionBureau should be "1".
         */
        final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 2);

        // verify IsDecisionBureau is false:
        Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

        // verify ExternalCreditReportId in tbl ListingCreditReportMapping
        Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
                creditReportMappingModelTu.getExternalCreditReportId());

        final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
        // verify ExternalModelReportId for TransUnion enabled
        Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
        LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
        // verify ExternalModelReportId for Experian enabled
        final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
        Assert.assertEquals(externalModelReportIdEx, null);

        // Temporary created Transunion DB object
        final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
        final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
        LOG.info("modelReportId is:" + modelReportId);
        Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));

        Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));
        LOG.info("~~~~~~Executing:~~~~~~BMP-5499~~~~~~");
        final String listingforPMI= listingsDAO.getListingIdForPMI(listingID);
        Assert.assertNull(listingforPMI);
        LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");

        // final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
        // MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
        // listingID));
        // // verify DQP reduce pricing as || corresponding to variableID(73)
        // Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
        // "Pipes should not be displayed for the QP via Card Refinace Page --- Standard Pricing displayed to QP Channel");
    }
}
