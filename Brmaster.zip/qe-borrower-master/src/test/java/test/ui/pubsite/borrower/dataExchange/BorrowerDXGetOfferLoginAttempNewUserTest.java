
package test.ui.pubsite.borrower.dataExchange;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.LoginAttemptDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 *
 * @author jdoriya 13-May-2016
 *
 */
public class BorrowerDXGetOfferLoginAttempNewUserTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXGetOfferLoginAttempNewUserTest.class.getSimpleName());


    // BMP-861 Verify that records are generated in [dbo].[LoginAttempt] table for DX New user on submitting DX Landing Page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDXUserLoginAttemptTblRecord()
            throws HttpRequestException, AutomationException, JsonParseException, JsonMappingException, IOException {
        LOG.info("Executing: testDXUserLoginAttemptTblRecord");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDXUserLoginAttemptTblRecord");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        PollingUtilities.sleep(2000);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());

        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);

            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());

            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            LOG.info("BMP-1001 Get Offer: All the fields except SSN should be editable on Personal Information page-Passed");
            LOG.info(
                    "BMP-1354 Get Offer: User navigated to \"Personal Detail\" page on submitting \"Pre-Screen Create Password Page with Offer\" page with valid details.-Passed");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

            LOG.info("BMP-1233 Get Offer: Verify that Loan Terms page displayed on submitting Personal Information page.-Passed");
            tilPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            Assert.assertNotNull(bankAccountInfoPage);

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG), null,
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            publicSiteThankYouPage.clickGoToMyAccountPage();
        }
        // Log into the Public site with user created above
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");

            publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userID = userInfo.getUserIDByEmail(email);
            PollingUtilities.sleep(2000);
            final LoginAttemptDAO userLoginStatus = circleOneDBConnection.getDataAccessObject(LoginAttemptDAO.class);
           /* Assert.assertTrue(userLoginStatus.isUserLoginSuccess(userID));*/
            LOG.info(
                    "BMP-861 Verify that records are generated in [dbo].[LoginAttempt] table for DX New user on submitting DX Landing Page");
        }
    }
}
