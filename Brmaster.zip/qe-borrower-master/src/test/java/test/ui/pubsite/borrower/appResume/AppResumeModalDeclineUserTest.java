
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.annotation.Resource;

public class AppResumeModalDeclineUserTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalDeclineUserTest.class.getSimpleName());
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // GEAR-2655 Verify that declined user coming from app resume modal doesnt see decline page upon submitting the modal
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDeclineUserAppResume() throws AutomationException {
        LOG.info("Test Method Name - testDeclineUserAppResume");
        // Submit Home page
        final PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDeclineUserAppResume");
        registrationPage.fillRegistrationForm(
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email, Constant.COMMON_PASSWORD,
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.STATE_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("Email address of the user: " + email);

        registrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // Decline Page content check
        Assert.assertTrue(offerPage.isDeclinePageAppears(),
                "Decline should be thrown to the user having fico less than 640");
        // Get alternate key from cookie
        final String altKey = offerPage.getCookieValue("alt_key");
        LOG.info("alternate key is" + altKey);
        Assert.assertNotNull(altKey);

        final PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
        PollingUtilities.sleep(4000);
        declinePage.waitForPageToLoad("D-110");
        Assert.assertTrue(declinePage.isTextDisplayed(Constants.AMONE_PARTNER_DECLINE_D110),
                "Decline Message is not correct");
        Assert.assertTrue(declinePage.isTextDisplayed(Constants.D110_PAGE_HEADER),
                "Decline Message is not correct");
        Assert.assertTrue(declinePage.isGetStartedDisplayed(), " Get Started button is not displayd on decline Page");

        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = declinePage.clickOnProsperLogo();
        // Signout user
        publicSitePreRegistrationAgainPage.deleteAllCookies();

        publicSitePreRegistrationAgainPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

        Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());

        publicSitePreRegistrationAgainPage.checkYourRate();
        // app resume modal displayed
        Assert.assertTrue(publicSitePreRegistrationAgainPage.getAppResumeModal().isDisplayed());

        // Enter details in App Resume Modal
        final PublicSiteRegistrationPage publicSiteRegistrationAgainPage =
                publicSitePreRegistrationAgainPage.submitAppResumeModalDeclineUser(
                        getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                        getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                        getUserForTest("testCsLessThan640TuUser").get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

        LOG.info(
                "GEAR-2655 Verify that declined user coming from app resume modal doesnt see decline page upon submitting the modal");
        Assert.assertTrue(publicSiteRegistrationAgainPage.isRegisterPageDisplayed());

    }
}
