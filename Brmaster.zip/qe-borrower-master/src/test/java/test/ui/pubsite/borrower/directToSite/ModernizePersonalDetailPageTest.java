package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.enumeration.platform.EmploymentStatus;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 08-Jun-2016
 *
 */
/**
 * @author hisharma
 *
 */
public class ModernizePersonalDetailPageTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(ModernizePersonalDetailPageTest.class.getSimpleName());

	@Resource
	private PublicSitePreRegistrationPage modernizePreRegistrationPage;

	private String emailAddress;


	/**
	 * Common wrapper to navigate to Loan Offers page
	 *
	 * @return PublicSiteOfferPage object for chaining
	 * @throws AutomationException
	 */
	public PublicSiteOfferPage navigateToLoanOfferPage() throws AutomationException{

		// Submit Home Page
		final PublicSiteRegistrationPage publicSiteRegistrationPage =
				modernizePreRegistrationPage.checkYourRate();

		// Fill Register page form
		emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
		publicSiteRegistrationPage.fillRegistrationForm(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
				Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), emailAddress,
				Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

		publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

		// Submitting Register page and return Offer page object
		return  publicSiteRegistrationPage.clickGetYourRate(false, false);
	}

	/**
	 * Common wrapper to navigate to Personal Details page
	 *
	 * @return PublicSitePersonalDetailPage object for chaining
	 * @throws AutomationException
	 */
	public PublicSitePersonalDetailPage navigateToPDPage() throws AutomationException{

		// Submit Offers Page (3 Years)
		final PublicSitePersonalDetailPage personalDetailsPage = navigateToLoanOfferPage().clickGetLoan();
		return personalDetailsPage;
	}


	/**
	 * GEAR-1105 Verify that new personal details page is loaded correctly.
	 * GEAR-1108 Verify that personal details page is divided in three sections
	 * GEAR-1121 Verify that 'work phone number' field is placed in 'employment' section
	 * GEAR-1109 Verify that correct fields are displayed in How Can We Contact You? Section
	 * GEAR-1111 Verify that correct fields are displayed in More About Your Employment Section
	 * GEAR-1112 Verify that correct fields are displayed in What's Your Social Security Number? Section
	 * GEAR-1133 Verify that correct loan amount is displayed in right rail of personal details page
	 * GEAR-1107 Verify that 'employer phone number' field is not displayed on personal details page.
	 * GEAR-1123 Verify that if the user enters data for work phone number then the data provided by user should be saved in DB
	 * GEAR-1110 Verify that Secondary phone number field is displayed on clicking Hyperlink for 'Secondary phone number.'
	 * GEAR-1134 Verify that correct loan term is displayed in right rail of personal details page for 3 year loan term -------------------------
	 * GEAR-1136 Verify that correct monthly payment is displayed in right rail of personal details page.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testNewPersonalDetailPageAppearance() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testNewPersonalDetailPageAppearance()~~~~~~~~~~");

		// Navigate to Offers page
		final PublicSiteOfferPage publicSiteOfferPage = navigateToLoanOfferPage();

		// Get Monthly Payment Amount(3 Years)
        // String threeYearMonthlyInstalment = publicSiteOfferPage.getThreeYearFixedMonthlyPaymentAmount();

		// Submit offer page (click On Get This Loan Button For Three Years)
		final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();

		// Verify new Personal detail Header text
		personalDetailsPage.verifyPersonalDetailPageHeaderContent();
		LOG.info("GEAR-1105 Verify that new personal details page is loaded correctly.");

		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {

			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);
			LOG.info("GEAR-1108 Verify that personal details page is divided in three sections");

			Assert.assertEquals(personalDetailsPage.getSectionHeaderByCss("personalDetail_Section_01_Header_css"), "How Can We Contact You?");
			personalDetailsPage.verifySection01Fields();
			LOG.info("GEAR-1109 Verify that correct fields are displayed in How Can We Contact You? Section");

			Assert.assertEquals(personalDetailsPage.getSectionHeaderByCss("personalDetail_Section_02_Header_css"), "More About Your Employment");
			personalDetailsPage.verifySection02Fields();
			LOG.info("GEAR-1121 Verify that 'work phone number' field is placed in 'employment' section");
			LOG.info("GEAR-1111 Verify that correct fields are displayed in More About Your Employment Section");

			Assert.assertEquals(personalDetailsPage.getSectionHeaderByCss("personalDetail_Section_03_Header_css"), "What's Your Social Security Number?");
			personalDetailsPage.verifySection03Fields();
			LOG.info("GEAR-1112 Verify that correct fields are displayed in What's Your Social Security Number? Section");


			// Verify Employer Phone is not present on new Personal detail page
			try {
				personalDetailsPage.getElementByID("employerPhone");
			} catch (final NoSuchElementException elementNotPresent) {
				LOG.info(elementNotPresent
						+ "GEAR-1107 Verify that 'employer phone number' field is not displayed on personal details page.");
			}

			// verify right rail information for the user

			// New method updated to verify LOAN_AMOUNT (5000.0) with ($5,000.00) , regex updated while getting rightRailInfo
			Assert.assertTrue(personalDetailsPage.validationRightRailInfoUpdated(Double.toString(LOAN_AMOUNT)));

			//LOG.info("GEAR-1133 Verify that correct loan amount is displayed in right rail of personal details page");

			// TODO: Need Work as per Offer Page display feature
            // Assert.assertTrue(personalDetailsPage.validationRightRailInfo(threeYearMonthlyInstalment));
			LOG.info("GEAR-1136 Verify that correct monthly payment is displayed in right rail of personal details page.");



			Assert.assertTrue(personalDetailsPage.validationRightRailInfo("3 years"));
			LOG.info("GEAR-1134 Verify that correct loan term is displayed in right rail of personal details page for 3 year loan term");              // 3year loan terms

			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
			LOG.info("GEAR-1110 Verify that Secondary phone number field is displayed on clicking Hyperlink for 'Secondary phone number.'");

			final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
			Assert.assertNotNull(tilPage);
			LOG.info("GEAR-1106 Verify that user is able to submit personal details page with all the correct details.");

			// Get user id
			final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
			final String userId = userEmail.getUserIDByEmail(emailAddress);
			// UserPhoneTypeID 4: WorkphoneNumber, 1: HomePhoneNumber
			final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
					MessageBundle.getMessage("userPhoneDetails").replace("{userID}", userId).replace("{phoneTypeID}", "4"));
			Assert.assertEquals(
					loanOfferScoreDetails.get(0).get("AreaCode").toString()
					+ loanOfferScoreDetails.get(0).get("PhoneNumber").toString(),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
			LOG.info("GEAR-1123 Verify that if the user enters data for work phone number then the data provided by user should be saved in DB");
		} else {
			LOG.warn("New Personal detail page is not displayed to User");
		}
	}


	/**
	 * GEAR-1135 Verify that correct loan term is displayed in right rail of personal details page for 5 year loan term
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE, enabled = false)
	void testPersonalDetailPageFor5YearLoanTerms() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testPersonalDetailPageFor5YearLoanTerms~~~~~~~~~~");

		final PublicSiteOfferPage publicSiteOfferPage = navigateToLoanOfferPage();

		// Check for offer page occuring on qa32 environment,
		if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
			publicSiteOfferPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
			publicSiteOfferPage.waitForLoaderDialogToDismiss(150, 150,
					Constants.UserCommonTestDetails.LOADING_DIALOG_BOX_AT_PUBLICSITE_PAGES_CSS,
					PublicSiteOfferPage.class.getSimpleName());
		}

		final String fiveYearMonthlyInstalment = publicSiteOfferPage.get5YearMonthlyPaymentOnOffersChart();
		final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickOnGetThisLoanButtonForFiveYears();
		// Verify new Personal detail Header text
		personalDetailsPage.verifyPersonalDetailPageHeaderContent();
		LOG.info("GEAR-1105 Verify that new personal details page is loaded correctly.");
		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);
			LOG.info("GEAR-1108 Verify that personal details page is divided in three sections");

			// Verify Employer Phone is not present on new Personal detail page
			try {
				personalDetailsPage.getElementByID("employerPhone");
			} catch (final NoSuchElementException elementNotPresent) {
				LOG.info(elementNotPresent
						+ " 'employer phone number' field is not displayed on personal details page.");
			}

			// verify right rail information for the user
			Assert.assertTrue(personalDetailsPage.validationRightRailInfo(Double.toString(LOAN_AMOUNT)));
			Assert.assertTrue(personalDetailsPage.validationRightRailInfo(fiveYearMonthlyInstalment));
			Assert.assertTrue(personalDetailsPage.validationRightRailInfo("5 years"));
			LOG.info(
					"GEAR-1135 Verify that correct loan term is displayed in right rail of personal details page for 5 year loan term");
			LOG.info("~~~~~~testPersonalDetailPageFor5YearLoanTerms--PASSED~~~~~~~~~~");
		}
	}



	/**
	 * GEAR-1126 Verify that validation is displayed if user eneters non-numeric data in SSN field.
	 * GEAR-1128 Verify that validation is displayed if user enters less than 9 digits in SSN field
	 * GEAR-1127 Verify that SSn of user is auto-formatted when user clicks out of SSN field after entering 9 digit SSN
	 * GEAR-1116 Verify that user is not able to submit the page without providing primary phone number and other valid details
	 * GEAR-1113 Verify that correct validation is displayed on entering non-numeric data in primary phone number text field
	 * GEAR-1125 Verify that validation is displayed if difference in D.O.B of user and start of employment is less than 10 years.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testFieldValidation() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testFieldValidation~~~~~~~~~~");

		final PublicSitePersonalDetailPage personalDetailsPage = navigateToPDPage();

		// Verify Fields on Section 1:
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			// ----------------PrimaryPhoneValidation-------------------------//
			personalDetailsPage.fillPersonalDetailPage("",
					getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			personalDetailsPage.clickOnContinue();
			Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.PRIMARY_PHONE_BLANK_FIELD_VALIDATION, false));
			LOG.info(
					"GEAR-1116 Verify that user is not able to submit the page without providing primary phone number and other valid details");

			personalDetailsPage.enterPrimaryPhone("asdfg");
			PollingUtilities.sleep(2000);
			Assert.assertTrue(
					personalDetailsPage.isTextPresent(Constants.PersonalDetailPage.NONNUMBERIC_FIELD_VALIDATION, false));
			LOG.info(
					"GEAR-1113 Verify that correct validation is displayed on entering non-numeric data in primary phone number text field");
			// ----------------StartOfEmploymentValidation-------------------------//
			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    "01/1960",
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			/*personalDetailsPage.clickOnContinue();*/
		    /*	Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.START_OF_EMPLOYMENT_DATE_FIELD_VALIDATION, false));*/
			LOG.info(
					"GEAR-1125 Verify that validation is displayed if difference in D.O.B of user and start of employment is less than 10 years.");
			PollingUtilities.sleep(2000);
			personalDetailsPage.enterStartOfEmployment("1953/02");
			personalDetailsPage.clickOnContinue();
			Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.START_OF_EMPLOYMENT_FIELD_FORMAT_VALIDATION, false));

			// --------------------StartOfEmploymentValidation-END--------------------------------//
			// --------------------SSNValidation--------------------------------//
			// try with non-number primary phone number
			personalDetailsPage.enterSocialSecurityNumber("asdfg");
            personalDetailsPage.clickOnContinue();
			// same validation as for secondary phone number
			PollingUtilities.sleep(2000);
			Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.SSN_FIELD_VALIDATION, false));
			LOG.info(
					"GEAR-1126 Verify that validation is displayed if user eneters non-numeric data in SSN field.");
			personalDetailsPage.enterSocialSecurityNumber("123456");
			PollingUtilities.sleep(2000);
			Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.SSN_FIELD_VALIDATION, false));
			LOG.info("GEAR-1128 Verify that validation is displayed if user enters less than 9 digits in SSN field");
            personalDetailsPage.reload();
            personalDetailsPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			Assert.assertTrue(personalDetailsPage.getSSnFieldValue().contains("-"), "SSN field is not formatted itself");
			LOG.info(
					"GEAR-1127 Verify that SSn of user is auto-formatted when user clicks out of SSN field after entering 9 digit SSN");
			// --------------------SSNValidation-END-------------------------------//
			// --------------------SecondaryPhoneValidation-------------------------------//
			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					"asdfg",
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			personalDetailsPage.clickOnContinue();
			Assert.assertTrue(personalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.NONNUMBERIC_FIELD_VALIDATION, false));
			// --------------------SecondaryPhoneValidation-END------------------------------//
		}
	}



	/**
	 * GEAR-1120 Verify that 'work phone number' field is optional on personal details page
	 * GEAR-1122 Verify that if the user doesn't enter any data for work phone number then 'primary phone number' should be passed as work phone in database.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testSubmitNewPDPageWithoutWorkPhone() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testSubmitNewPDPageWithoutWorkPhone()~~~~~~~~~~");

		final PublicSitePersonalDetailPage personalDetailsPage = navigateToPDPage();

		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);
			LOG.info("GEAR-1108 Verify that personal details page is divided in three sections");

			// Verify Employer Phone is not present on new Personal detail page
			try {
				personalDetailsPage.getElementByID("employerPhone");
			} catch (final NoSuchElementException elementNotPresent) {
				LOG.info(elementNotPresent
						+ "GEAR-1107 Verify that 'employer phone number' field is not displayed on personal details page.");
			}
			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
					"",
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
			Assert.assertNotNull(tilPage);
			LOG.info("GEAR-1120 Verify that 'work phone number' field is optional on personal details page");

			// Get user id
			final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
			final String userId = userEmail.getUserIDByEmail(emailAddress);
			// UserPhoneTypeID 4: WorkphoneNumber, 1: HomePhoneNumber
			final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
					MessageBundle.getMessage("userPhoneDetails").replace("{userID}", userId).replace("{phoneTypeID}", "4"));
			Assert.assertEquals(
					loanOfferScoreDetails.get(0).get("AreaCode").toString()
					+ loanOfferScoreDetails.get(0).get("PhoneNumber").toString(),
					getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
			LOG.info("GEAR-1122 Verify that if the user doesn't enter any data for work phone number then 'primary phone number' should be passed as work phone in database.");

			LOG.info("~~~~~~~~~~testSubmitNewPDPageWithoutWorkPhone()--PASSED~~~~~~~~~");
		} else {

			LOG.warn("New Personal detail page is not displayed to User");
		}
	}



	/**
	 * GEAR-1131 Verify that correct tool-tip is displayed when user clicks in Secondary phone field.
	 * GEAR-1130 Verify that correct tool-tip is displayed when user clicks in Employer Name field.
	 * GEAR-1129 Verify that correct tool-tip is displayed when user clicks in SSN field.
	 *
	 * GEAR-1117 Verify that correct options are displayed for occupation drop-down on personal details page
	 * GEAR-1118 Verify that user is not able to submit the page without selecting occupation
	 * GEAR-1119 Verify that user is not able submit the page without providing employer name
	 *
	 * GEAR-1115 Verify that user is able to submit the page without providing secondary phone number and other valid details
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testSubmitNewPersonalDetailPage() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testSubmitNewPersonalDetailPage()~~~~~~~~~~");

		//Submit Pages up to PD page
		final PublicSitePersonalDetailPage personalDetailsPage = navigateToPDPage();

		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {

			personalDetailsPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));

			Assert.assertTrue(personalDetailsPage.isToolTipDisplay(Constants.PersonalDetailPage.SECONDARY_PHONE_FIELD_TOOLTIP));
			LOG.info("GEAR-1131 Verify that correct tool-tip is displayed when user clicks in Secondary phone field.");

			personalDetailsPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
			PollingUtilities.sleep(2000);
			Assert.assertTrue(personalDetailsPage.isToolTipDisplay(Constants.PersonalDetailPage.EMPLOYER_NAME_TOOLTIP));
			LOG.info("GEAR-1130 Verify that correct tool-tip is displayed when user clicks in Employer Name field.");

			personalDetailsPage.enterSSNWithOutTab(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
			PollingUtilities.sleep(2000);
            // Obselet now as SHOW |Hide options available
            // Assert.assertTrue(personalDetailsPage.isToolTipDisplay(Constants.PersonalDetailPage.SSN_FIELD_TOOLTIP));
            // LOG.info("GEAR-1129 Verify that correct tool-tip is displayed when user clicks in SSN field.");

			personalDetailsPage.reload();

			final ArrayList<String> occupationOptions = new ArrayList<String>(
					Arrays.asList("Occupation", "Accountant/CPA", "Analyst", "Architect", "Attorney", "Biologist", "Bus Driver",
							"Car Dealer", "Chemist", "Civil Service", "Clergy", "Clerical", "Computer Programmer", "Construction",
							"Dentist", "Doctor",  "Engineer - Chemical", "Engineer - Electrical", "Engineer - Mechanical",
							"Executive", "Fireman", "Flight Attendant", "Food Service", "Food Service Management",
							"Homemaker", "Judge", "Laborer", "Landscaping", "Medical Technician", "Military Enlisted",
							"Military Officer", "Nurse - Licensed Practical Nurse (LPN)", "Nurse - Registered Nurse (RN)",
							"Nurse's Aide", "Pharmacist", "Pilot - Private/Commercial", "Police Officer/Correction Officer",
							"Postal Service", "Principal", "Professional", "Professor", "Psychologist", "Realtor",
							"Religious", "Retail Management", "Sales - Commission", "Sales - Retail",
							"Scientist", "Secretary/Administrative Assistant",  "Skilled Labor",
							"Social Worker", "Student - College Freshman",  "Student - College Sophomore",
							"Student - College Junior", "Student - College Senior", "Student - Graduate School",
							"Student - Community College", "Student - Technical School", "Teacher", "Teacher's Aide",
							"Tradesman - Carpenter",  "Tradesman - Electrician", "Tradesman - Mechanic", "Tradesman - Plumber",
							"Truck Driver", "Waiter/Waitress", "Profession that is not part of this list", "Investor"));

			Assert.assertTrue(personalDetailsPage.getOccupationOptions().containsAll(occupationOptions));
			LOG.info("GEAR-1117 Verify that correct options are displayed for occupation drop-down on personal details page");

			// Submit PD page without selecting occupation
			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					"Occupation",
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			personalDetailsPage.clickOnContinue();
			PollingUtilities.sleep(2000);

			Assert.assertTrue(personalDetailsPage.isTextPresent(Constants.PersonalDetailPage.OCCUPATION_FIELD_VALIDATION, false));
			LOG.info("GEAR-1118 Verify that user is not able to submit the page without selecting occupation");

			// Reload PD page and submit without providing "Employer Name"
			personalDetailsPage.reload();

			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					"",
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			personalDetailsPage.clickOnContinue();
			PollingUtilities.sleep(2000);
			Assert.assertTrue(personalDetailsPage.isTextPresent(Constants.PersonalDetailPage.EMPLOYER_NAME_FIELD_VALIDATION, false));
			LOG.info("GEAR-1119 Verify that user is not able submit the page without providing employer name.");

			personalDetailsPage.reload();

			personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG), null,
					getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
					getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

			final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
			Assert.assertNotNull(tilPage);
			LOG.info("GEAR-1115 Verify that user is able to submit the page without providing secondary phone number and other valid details");

			LOG.info("~~~~~~~~~~testSubmitNewPersonalDetailPage()---PASSED~~~~~~~~~~~~~~~~~~~");
		} else {

			LOG.warn("New Personal detail page is not displayed to User");
		}
	}


	// TODO: Disabled due to defect GEAR-1496
	/**
	 * GEAR-1139 Verify that SSN field is displayed pre-filled and non-editable if user provided SSN on SSN page
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE, enabled = false)
	void testPreFilledSSN() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testPreFilledSSN~~~~~~~~~~");

		final PublicSiteRegistrationPage publicSiteRegistrationPage =
				modernizePreRegistrationPage.checkYourRate();

		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
		// Investor account registration page
		publicSiteRegistrationPage.fillRegistrationForm("666111634",
				Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
				Constant.COMMON_PASSWORD, "TAHIR", RandomStringUtils.random(10, true ,false), "1639 SW WITHDEAN RD", "XX", "KS",
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
				"01/01/1932");

		publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
		publicSiteRegistrationPage.clickGetYourRate(false, false);
		// verify SSN Page on wrong reg details
		final PublicSiteOfferPage publicSiteOfferPage =
				publicSiteRegistrationPage.handleSSNPage("666057741");

		final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
		// Verify new Personal detail Header text
		personalDetailsPage.verifyPersonalDetailPageHeaderContent();
		LOG.info("GEAR-1105 Verify that new personal details page is loaded correctly.");
		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);
			Assert.assertTrue(personalDetailsPage.getSsnPopulated());

			LOG.info("GEAR-1139 Verify that SSN field is displayed pre-filled and non-editable if user provided SSN on SSN page");
			LOG.info("~~~~~~testPreFilledSSN--PASSED~~~~~~~~~~");
		}

	}

	/**
	 * GEAR-1138 Verify that correct fields are displayed on personal details page to the user with Other employment status
	 *
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testPersonalInfoPageForOtherEmploymentStatus() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testPersonalInfoPageForOtherEmploymentStatus~~~~~~~~~~");

		 final PublicSiteRegistrationPage publicSiteRegistrationPage =
	                modernizePreRegistrationPage.checkYourRate();

	        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
	        publicSiteRegistrationPage.fillRegistrationForm(
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
	                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
	                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
	                EmploymentStatus.OTHER.getDescription(),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
	                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

	        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

	        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

	        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
	        // Verify new Personal detail Header text
	        personalDetailsPage.verifyPersonalDetailPageHeaderContent();
	        LOG.info("GEAR-1105 Verify that new personal details page is loaded correctly.");

		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);

			Assert.assertFalse(personalDetailsPage.verifyFieldOnPersonalPage("occupation"));
			Assert.assertFalse(personalDetailsPage.verifyFieldOnPersonalPage("employerName"));
			Assert.assertFalse(personalDetailsPage.verifyFieldOnPersonalPage("workPhone"));
			// primary phone should be present
			Assert.assertTrue(personalDetailsPage.verifyFieldOnPersonalPage("homePhone"));
			LOG.info("GEAR-1138 Verify that correct fields are displayed on personal details page to the user with Other employment status");
			LOG.info("~~~~~~testPersonalInfoPageForOtherEmploymentStatus--PASSED~~~~~~~~~~");
		}
	}


	/**
	 * GEAR-1137 Verify that correct fields are displayed on personal details page to the user with Self-employed employment status
	 * @throws AutomationException
	 */
	@Test(groups = TestGroup.ACCEPTANCE)
	void testPersonalInfoPageForSelfEmploymentStatus() throws AutomationException {
		LOG.info("~~~~~~Executing Test: testPersonalInfoPageForSelfEmploymentStatus~~~~~~~~~~");

		final PublicSiteRegistrationPage publicSiteRegistrationPage =
                modernizePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                EmploymentStatus.SELF_EMPLOYED.getDescription(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text
        personalDetailsPage.verifyPersonalDetailPageHeaderContent();
        LOG.info("GEAR-1105 Verify that new personal details page is loaded correctly.");

		// Verify Personal Page is divided into 3 section OR Panes
		if (personalDetailsPage.getNumberOfPanes() > 1) {
			Assert.assertEquals(personalDetailsPage.getNumberOfSections(), 3);
			// Only Occupation field displayed as difference from other employment behavior
			Assert.assertTrue(personalDetailsPage.verifyFieldOnPersonalPage("occupation"));
			Assert.assertFalse(personalDetailsPage.verifyFieldOnPersonalPage("employerName"));
			Assert.assertFalse(personalDetailsPage.verifyFieldOnPersonalPage("workPhone"));
			// primary phone should be present
			Assert.assertTrue(personalDetailsPage.verifyFieldOnPersonalPage("homePhone"));
			LOG.info("GEAR-1137 Verify that correct fields are displayed on personal details page to the user with Self-employed employment status");
			LOG.info("~~~~~~testPersonalInfoPageForSelfEmploymentStatus--PASSED~~~~~~~~~~");
		}
	}
}
