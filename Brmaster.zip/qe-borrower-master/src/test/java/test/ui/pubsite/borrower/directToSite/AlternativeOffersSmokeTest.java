
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteAltOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.annotation.Resource;

/**
 * NGMA - 833 New Offer Page Design
 * <p>
 * Created by sgonaki on 10/6/16.
 */
public class AlternativeOffersSmokeTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AlternativeOffersSmokeTest.class.getSimpleName());

    @Resource
    private PublicSitePreRegistrationPage modernizePreRegistrationPage;


    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose", "homeImprovementListing"),};
    }

    // Note: AUTO-183 - DTS funnel (with moved fields) with miicard bank page
    @Test(dataProvider = "testData", groups = {TestGroup.SANITY})
    public void verifyDTSFunnel(String Key, String jiraID,
                                String loanAmount,
                                String loanPurpose,
                                String creditQuality,
                                String firstName,
                                String middleInitial,
                                String lastName, String homeAddress,
                                String city, String state,
                                String zipCode,
                                String employmentStatus,
                                String yearlyIncome, String dob,
                                String emailAddress,
                                String password, String homePhone,
                                String mobilePhone,
                                String workPhone,
                                String employerName,
                                String employerPhone,
                                String occupation,
                                String employmentStartDate,
                                String SSN, String bankName,
                                String accountType,
                                String accountholderName,
                                String AlternateAccountHolderName,
                                String routingNumber,
                                String accountNumber,
                                String confirmAccountNumber,
                                String paymentType)
                                        throws AutomationException {

        LOG.info("~~~~~~Executing: verifyDTSFunnel With ALT OffersPage~~~~~~~~~~~~~~~");

        password = MessageBundle.getMessage("password");

        PublicSiteRegistrationPage registrationPage =
                modernizePreRegistrationPage.checkYourRateAlt(loanAmount, loanPurpose, creditQuality);
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
        // Submit Register page
        registrationPage
                .fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName, homeAddress, city,
                        state, employmentStatus, yearlyIncome, dob);
        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteAltOfferPage publicSiteAltOfferPage = registrationPage.clickAltGetYourRate(false, false);

        // Submit Alternative Loan Offers page************
        Assert.assertTrue(publicSiteAltOfferPage.isLoanAltOfferPageDisplayed(), "Alternative Loan offer page is not  displayed.");
        PublicSitePersonalDetailPage detailsPage = publicSiteAltOfferPage.clickGetAltLoan();

        // Submit Personal Details page
        detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
                employmentStartDate, SSN);

    }
}
