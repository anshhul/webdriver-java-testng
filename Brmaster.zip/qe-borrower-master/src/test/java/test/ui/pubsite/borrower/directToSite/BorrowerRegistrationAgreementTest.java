
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import java.io.IOException;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class BorrowerRegistrationAgreementTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerRegistrationAgreementTest.class.getSimpleName());
    @Resource
    private PublicSitePreRegistrationPage modernizePreRegistrationPage;


    // TODO: Auto-287
    // BMP-2245 Verify that Borrower Registration Agreement is updated on legal page.
    @Test(groups = {TestGroup.NIGHTLY})
    void testPlpLegalRegistrationAgreementDetails() throws AutomationException, IOException, XmlException, OpenXML4JException {

        LOG.info("~~~~~~~~~~Executing: testPlpLegalRegistrationAgreementDetails~~~~~~~~~~~~~");

        // Navigated to PLP Legal Page
        modernizePreRegistrationPage.clickOnLegal();

        modernizePreRegistrationPage.clickOnLink("borrower_registration_link_text");
        PollingUtilities.sleep(4000);
        Assert.assertTrue(modernizePreRegistrationPage.isAgreementPageDisplayed());
        // Verfiy Promise to Pay contents of Registration Agreement
        modernizePreRegistrationPage.checkPromiseToPay();
        Assert.assertTrue(modernizePreRegistrationPage.isTextPresent(Constants.RegistrationAgreement.PROMISE_TO_PAY));
        LOG.info("PROMISE_TO_PAY Contents are verified");

        // Verfiy Interest contents of Registration Agreement
        Assert.assertTrue(modernizePreRegistrationPage.isTextPresent(Constants.RegistrationAgreement.INTEREST));
        LOG.info("INTEREST Contents are verified");

        // Verfiy Late Charge contents of Registration Agreement
        modernizePreRegistrationPage.checkLateCharge();
        Assert.assertTrue(modernizePreRegistrationPage.isTextPresent(Constants.RegistrationAgreement.LATE_CHARGE));
        LOG.info("LATE_CHARGE Contents are verified");

        // Verfiy Last Update Date contents of Registration Agreement
        modernizePreRegistrationPage.checkLastUpdatedDate();
        Assert.assertTrue(modernizePreRegistrationPage.isTextPresent(Constants.RegistrationAgreement.LAST_UPADTE_DATE));
        LOG.info("LAST_UPADTE_DATE Contents are verified");
        LOG.info("Registration Agreement Document is Verified");
        LOG.info("Verified BMP-2245 Verify that Borrower Registration Agreement is updated on legal page.");
    }
}
