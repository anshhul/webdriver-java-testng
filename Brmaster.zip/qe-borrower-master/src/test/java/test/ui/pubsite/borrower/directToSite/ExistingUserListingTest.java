package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.util.web.borrower.common.CryptoUtil;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

/**
 * Created by ppatil on 6/16/16.
 */


public class ExistingUserListingTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ExistingUserListingTest.class.getSimpleName());


    @Test()
    void testExistingProdUserListing() throws AutomationException, NoSuchPaddingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, IOException, BadPaddingException, InvalidKeyException, InvalidKeySpecException {
        LOG.info("~~~~~~Executing-testExistingUserListing~~~~~~~~~~~~~~~");
//        String userPasscode = CryptoUtil.decrypt(Constant.PROD_PASS);

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
        AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(Constant.STAGE2_QA32_EMAIL, Constant.COMMON_PASSWORD);

        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();

        // Validate the available flow on Account Overview Page(choose apply loan or finish Application) for the User and continue
        // new listing process
        if (accountOverviewPage.isApplyNowButtonDisplayed()) {
            LOG.info("Entered Apply Loan function:");
            BorrowerPreRegistrationPage borrowerPreRegistrationPage = accountOverviewPage.clickApplyLoan();
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    borrowerPreRegistrationPage.submitPreRegistrationPage(Double.toString(LOAN_AMOUNT),
                            Constants.UserCommonTestDetails.LOANPURPOSE,
                            Constants.UserCommonTestDetails.CREDITQUALTIY);

            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();

            // need to enter employer phone because user is coming via old pre-reg page
            personalDetailsPage.enterEmployerPhone(Constants.PersonalDetailPage.EMPLOYERPHONE);
            personalDetailsPage.enterEmployerName(Constants.PersonalDetailPage.EMPLOYERNAME);
            personalDetailsPage.enterStartOfEmployment(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE);
            personalDetailsPage.selectOccupation(Constants.PersonalDetailPage.OCCUPATION);
            LOG.info("Existing User Dropped the funnel on personal detail page");

            PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            tilPage.confirmElectronicSignature();
            String newListing = tilPage.getListingIdFromTILAContent();

            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();

            PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.clickAddBank();

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            accountOverviewPage
                    .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            accountOverviewPage.dismissCongratulationWelcomeModal();

            Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));

        } else if (accountOverviewPage.verifyFinishApplicationButtonDisplayed()) {
            LOG.info("Entered Finish Application function:");
            final PublicSiteOfferPage offerPage = accountOverviewPage.submitFinishApplication();
            Assert.assertNotNull(offerPage);

            final PublicSitePersonalDetailPage personalDetailsPage = offerPage.clickGetLoan();

            // Verify new Personal detail Header text
            personalDetailsPage.verifyPersonalDetailPageHeaderContent();

            // Need to enter employer phone because user is coming via old pre-reg page
            personalDetailsPage.enterEmployerPhone(Constants.PersonalDetailPage.EMPLOYERPHONE);
            personalDetailsPage.enterEmployerName(Constants.PersonalDetailPage.EMPLOYERNAME);
            personalDetailsPage.enterStartOfEmployment(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE);
            personalDetailsPage.selectOccupation(Constants.PersonalDetailPage.OCCUPATION);

            PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            tilPage.confirmElectronicSignature();
            String newListing = tilPage.getListingIdFromTILAContent();

            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();

            PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.clickAddBank();

            // User navigate to Thank you Page and clicked on go to my account
            LOG.info("User navigate to Thank you Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            accountOverviewPage
                    .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            accountOverviewPage.dismissCongratulationWelcomeModal();

            Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));
            LOG.info("New ListingId  created for ProdUser is :" + newListing);

        }

    }

}
