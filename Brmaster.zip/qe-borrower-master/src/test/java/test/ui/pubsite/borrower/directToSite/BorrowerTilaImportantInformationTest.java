
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.TilaVariation;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * AUTO-233 Automate 'Important information' section in new TILA page
 *
 * Created by sariga on 7/18/16.
 */

public class BorrowerTilaImportantInformationTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(BorrowerTilaImportantInformationTest.class.getSimpleName());

    @Resource
	private PublicSitePreRegistrationPage modernizePreRegistrationPage;

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] { Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose",
				"homeImprovementListing"), };
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	public void verifyBorrowerTila(String Key, String jiraID, String loanAmount, String loanPurpose,
			String creditQuality, String firstName, String middleInitial, String lastName, String homeAddress,
			String city, String state, String zipCode, String employmentStatus, String yearlyIncome, String dob,
			String emailAddress, String password, String homePhone, String mobilePhone, String workPhone,
			String employerName, String employerPhone, String occupation, String employmentStartDate, String SSN,
			String bankName, String accountType, String accountholderName, String AlternateAccountHolderName,
			String routingNumber, String accountNumber, String confirmAccountNumber, String paymentType)
			throws AutomationException {

		LOG.info("~~~~~~Executing: verifyBorrowerTila~~~~~~~~~~~~~~~");

		password = MessageBundle.getMessage("password");

		final PublicSiteRegistrationPage registrationPage = modernizePreRegistrationPage
				.checkYourRate();
		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyBorrowerTila");
		// Submit Register page
		registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName,
				homeAddress, city, state, employmentStatus, yearlyIncome, dob);
		registrationPage.clickElectronicSignatureCheckBox();
		final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

		// Submit Loan Offers page
		final PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

		// Submit Personal Details page
		detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
				employmentStartDate, SSN);
		final PublicSiteTruthInLendingDisclosurePage tilPage = detailsPage.clickContinue();

		// Accept agreement and submit Tila page
		tilPage.goToVariation(TilaVariation.NEW_TILA);
		Assert.assertTrue(tilPage.isStaticTextDisplayed(MessageBundle.getMessage("tilaInformation")));
		tilPage.confirmElectronicSignature();

		LOG.info("AUTO-233 Verify " + "Automate 'Important information' section in new TILA page");
		final String listingID = tilPage.getListingIDFromURI();
		final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
		final PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

		// Submit Bank Information Page
		final PublicSiteThankYouPage borrowerThankYouPage = manualBankPage.enterBankInfo(bankName, accountType,
				accountholderName, AlternateAccountHolderName, routingNumber, accountNumber, confirmAccountNumber,
				paymentType);
		// Submit Thank you page
		final AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();

		LOG.info("Prime Borrower ListingID is:" + listingID);
		// Delete cookies
		overviewPage.deleteAllCookies();

		// Log into the Public site with user created above
		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"public_site/spring/public_site_context.xml");
		final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
		final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(email, password);
		// Verify that New Account overview page is displayed on sign in
		overviewPageAgain
				.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
		overviewPageAgain.dismissCongratulationWelcomeModal();

		Assert.assertNotNull(overviewPageAgain.getListingDetail(), "Account Overview page should be displayed");
		LOG.info("~~~~~~verifyBorrowerTila--PASSED~~~~~~~~~~~~~~~");
	}
}
