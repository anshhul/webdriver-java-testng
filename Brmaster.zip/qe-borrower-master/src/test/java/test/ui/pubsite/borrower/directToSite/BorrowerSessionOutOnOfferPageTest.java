
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 03-Aug-2016
 *
 */
public class BorrowerSessionOutOnOfferPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerSessionOutOnOfferPageTest.class.getSimpleName());


    // GEAR-1674 Test Session timeout on Loan offer page with new loan amount(Auto-251)
    @Test(groups = {TestGroup.NIGHTLY})
    void testSessionOutOnOfferPage() throws AutomationException {
        LOG.info("Executing ~~~~~~~testSessionOutOnOfferPage~~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSessionOutOnOfferPage");
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        final PublicSiteRegistrationPage modernizeRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        modernizeRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);

        modernizeRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        modernizeRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = modernizeRegistrationPage.clickGetYourRate(false, false);

        Assert.assertNotNull(publicSiteOfferPage);
        Assert.assertTrue(publicSiteOfferPage.isSliderPageDisplayed(), "Offer slider should be displayed");

        publicSiteOfferPage.openOfferUrlInNewTab();
        publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();

        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();

        publicSitePreRegistrationAgainPage.deleteAllCookies();

        publicSiteOfferPage.moveToNextTab();
        LOG.info("Borrower has switched to old tab");
        // Select OfferChart For New Listing
        if (publicSiteOfferPage.isOriginalOfferPageDisplayed()) {
            publicSiteOfferPage.clickEditLoanAmount();
            Assert.assertTrue(publicSiteOfferPage.isEditLoanAmountPopUpDisplayed());
            publicSiteOfferPage.enterLoanAmountOnEditLoanAmountPopup(Double.toString(LOAN_AMOUNT + 1000.0));
            publicSiteOfferPage.clickOnRequestThisAmount();
            LOG.info("Borrower has edited loan amount and submit ");
        } else if (publicSiteOfferPage.isSliderPageDisplayed()) {
            publicSiteOfferPage.clickEditPencilIcon();
            publicSiteOfferPage.submitEditLoanAmount(Double.toString(LOAN_AMOUNT + 1000.0));
            LOG.info("Borrower has edited loan amount and submit ");

            // Submit offers page
            publicSiteOfferPage.clickGetLoan();
        }

        publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();

        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(Constants.SESSION_TIMEOUT_MODAL_HEADER));
        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(Constants.SESSION_TIMEOUT_MODAL_SUB_HEADER));
        Assert.assertTrue(publicSiteOfferPage.isSessionExpiredModalDisplayed(), "Expired Session Modal is not displayed");
        publicSiteOfferPage.enterPasswordIntoSessionExpiredModal(Constant.COMMON_PASSWORD);
        publicSiteOfferPage.clickOnSignInToContinue();
        publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        PollingUtilities.sleep(2000);
        Assert.assertTrue(publicSiteOfferPage.isSliderPageDisplayed());
        LOG.info("GEAR-1674 Test Session timeout on Loan offer page with new loan amount(Auto-251)");
    }
}
