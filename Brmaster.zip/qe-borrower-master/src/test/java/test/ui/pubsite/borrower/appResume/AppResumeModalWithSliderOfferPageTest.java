
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 20-feb
 *
 */
public class AppResumeModalWithSliderOfferPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithSliderOfferPageTest.class.getSimpleName());


    /**
     *
     * GEAR-2554 Verify app resume modal login with user dropping off on slider offer page
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalWithSliderOfferPage() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalWithSliderOfferPage~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Apply Original Offers page flag
            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAppResumeModalWithSliderOfferPage");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            Assert.assertTrue(offersPage.isSliderPageDisplayed(), "Slider Offers page should be displayed");

            // Get alternate key from cookie
            final String altKey = offersPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            PollingUtilities.sleep(2000);
            publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), getPrimeBorrowerData()
                            .get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData()
                            .get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info("GEAR-2554 Verify app resume modal login with user dropping off on slider offer page");
        }
    }
}
