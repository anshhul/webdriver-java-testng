package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.HomePageMessageConstants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import test.ui.WebDriverTestBase;

/**
 * Created by ppatil on 5/15/16.
 */
@Test(enabled = true)
public class HomePageTest extends WebDriverTestBase {

    protected static final Logger LOG =
            Logger.getLogger(HomePageTest.class.getSimpleName());

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    @Test(groups = TestGroup.ACCEPTANCE)
    public void verifyBillguardPaneFunctionality() throws AutomationException {
        publicSitePreRegistrationPage.clickOnAppleStore();
        publicSitePreRegistrationPage.verifyApplePlayStorePage();
        LOG.info("Apple Playstore displayed successfully");
        publicSitePreRegistrationPage.clickOnGooglePlayStore();
        publicSitePreRegistrationPage.verifyGooglePlayStorePage();
        LOG.info("Google Playstore displayed successfully");
    }

    @Test(groups = TestGroup.ACCEPTANCE)
    public void verifyHowItWorksPaneFunctionality() throws AutomationException {
        publicSitePreRegistrationPage.scrollToHowItWorksPane();

        // Verify Title
        publicSitePreRegistrationPage.verifyHIWPaneTitle();

        // Verify Image
        publicSitePreRegistrationPage.isHIWImageDisplayed();

        // Content verifications
        publicSitePreRegistrationPage.verifyCheckRate();
        publicSitePreRegistrationPage.verifyChooseYourTerm();
        publicSitePreRegistrationPage.verifyGetYourFunds();
    }


    @Test(groups = TestGroup.ACCEPTANCE)
    public void verifyGetRatePaneAppearance() throws AutomationException {

        publicSitePreRegistrationPage.verifyPageContent(HomePageMessageConstants.loanTermsHeader);
        publicSitePreRegistrationPage.verifyPageContent(HomePageMessageConstants.loanTermsText1);
        // publicSitePreRegistrationPage.verifyPageContent(HomePageMessageConstants.loanTermsText2);
        publicSitePreRegistrationPage.verifyPageContent(HomePageMessageConstants.loanTermsText3);
        publicSitePreRegistrationPage.verifyPageContent(HomePageMessageConstants.loanTermsText4);
        publicSitePreRegistrationPage.verifyCreditCardText();
        publicSitePreRegistrationPage.checkYourRate();
        LOG.info("Get Rate Pane displayed successfully");
    }


    @Test(groups = TestGroup.ACCEPTANCE)
    public void verifyTestimonialPane() throws AutomationException {

        // Scroll To Testimonial Pane
        publicSitePreRegistrationPage.scrollToTestimonialPane();

        // Verify title
        publicSitePreRegistrationPage.verifyTestimonialPaneTitle();

        // Verify contents
        publicSitePreRegistrationPage.verifyTestimonial(0, HomePageMessageConstants.TESTIMONIAL_OSCAR_NAME,
                HomePageMessageConstants.TESTIMONIAL_OSCAR_1);
        publicSitePreRegistrationPage.verifyTestimonial(0, HomePageMessageConstants.TESTIMONIAL_OSCAR_NAME,
                HomePageMessageConstants.TESTIMONIAL_OSCAR_2);
        publicSitePreRegistrationPage.verifyTestimonial(1, HomePageMessageConstants.TESTIMONIAL_NIK_NAME,
                HomePageMessageConstants.TESTIMONIAL_NIK);
        publicSitePreRegistrationPage.verifyTestimonial(2, HomePageMessageConstants.TESTIMONIAL_SHANITA_NAME,
                HomePageMessageConstants.TESTIMONIAL_SHANITA);
        LOG.info("Testimonials Pane displayed successfully");
    }


    @Test(groups = TestGroup.ACCEPTANCE)
    public void verifyInvestorPane() throws AutomationException {

        publicSitePreRegistrationPage.clickOnInvestBtn();
        publicSitePreRegistrationPage.tabswitching();
        publicSitePreRegistrationPage.verifyInvestorPaneText();
        publicSitePreRegistrationPage.isInvestorPromoImageDisplayed();
        publicSitePreRegistrationPage.clickOnInvestorImage();
        LOG.info("Investor Pane displayed successfully");

    }

    @Test(enabled = true)
    public void verifyLoanPurposePane() throws AutomationException {
        publicSitePreRegistrationPage.scrollToLoanPurposePane();

        publicSitePreRegistrationPage.verifyDebtConsolidationLoanIsDisplayed();
        publicSitePreRegistrationPage.verifyDebtConsolidationCheckRateBtn();
        publicSitePreRegistrationPage.verifyDebtConsolidationLearnMoreBtn();
        LOG.info(" Debt Consolidation loan purpose verified successfully");


        publicSitePreRegistrationPage.verifyHomeImprovementLoanIsDisplayed();
        publicSitePreRegistrationPage.verifyHomeImprovementCheckRateBtn();
        publicSitePreRegistrationPage.verifyHomeImprovementLearnMoreBtn();
        LOG.info("Home Improvement loan purpose verified successfully");

        publicSitePreRegistrationPage.verifySpecialOccasionLoanIsDisplayed();
        publicSitePreRegistrationPage.verifySpecialOccasionCheckRateBtn();
        publicSitePreRegistrationPage.verifySpecialOccasionLearnMoreBtn();
        LOG.info(" Special Occasion loan purpose verified successfully");

        publicSitePreRegistrationPage.verifySmallBussinessLoanisDisplayed();
        publicSitePreRegistrationPage.verifySmallBussinessLoanCheckRateBtn();
        publicSitePreRegistrationPage.verifySmallBussinessLearnMoreBtn();
        LOG.info("Small Bussiness loan purpose verified successfully");

        publicSitePreRegistrationPage.verifyBabyAndAdoptionLoanIsDisplayed();
        publicSitePreRegistrationPage.verifyBabyAndAdoptionCheckRateBtn();
        publicSitePreRegistrationPage.verifyBabyAndAdoptionLearnMoreBtn();
        LOG.info(" Baby and Adoption oan purpose verified successfully");

        publicSitePreRegistrationPage.verifyAutoVehicalLoanIsDisplayed();
        publicSitePreRegistrationPage.verifyAutoVehicalLoanCheckRateBtn();
        publicSitePreRegistrationPage.verifyAutoVehicalLearnMoreBtn();
        LOG.info(" Auto and Vehical loan purpose verified successfully");

        LOG.info("Loan Purpose Pane displayed successfully");

    }

}
