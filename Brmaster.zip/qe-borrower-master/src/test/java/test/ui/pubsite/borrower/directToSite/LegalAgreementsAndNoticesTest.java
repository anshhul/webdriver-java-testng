
package test.ui.pubsite.borrower.directToSite;

import java.io.IOException;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerAuthorizationToDebitAccountPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author hisharma
 *
 */
public class LegalAgreementsAndNoticesTest extends PartnerLandingPageTestBase {

	@Resource
	private PublicSitePreRegistrationPage modernizePreRegistrationPage;

	protected static final Logger LOG = Logger.getLogger(LegalAgreementsAndNoticesTest.class.getSimpleName());


	/**
	 * GEAR-1903 Verify that content of 'Borrower Registration Agreement' for DTS logged-out user on legal page is as per mock
	 * 
	 */
	@Test(groups = {TestGroup.ACCEPTANCE}, enabled = true)
	void verifyRegistrationAgreementWithOutSession() throws AutomationException, IOException, XmlException, OpenXML4JException {

		LOG.info("~~~~~~~~~~Executing: verifyRegistrationAgreementWithOutSession~~~~~~~~~~~~~");

		// click on Legal link on footer and then navigate to the Borrower Registration Agreement page
		modernizePreRegistrationPage.clickOnLegal();
		modernizePreRegistrationPage.clickOnLink("borrower_registration_link_text");

		// verify that agreement page is opened
		Assert.assertTrue(modernizePreRegistrationPage.isAgreementPageDisplayed());

		String agreementContent = modernizePreRegistrationPage.getAgreementContent();

		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.BRA_INTRO));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.REGISTRATION_AS_A_PROSPER_BORROWER));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.AUTHORIZATION_TO_OBTAIN_CREDIT_REPORT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LISTINGS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.RIGHT_TO_VERIFY_INFORMATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MATCHING_OF_INVESTOR));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.COMPENSATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MAKING_YOUR_LOAN_PAYMENTS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.COLLECTION_AND_REPORTING));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NO_GUARANTEE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.RESTRICTIONS_ON_USE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.AUTHORITY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.TERMINATION_OF_REGISTRATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROSPER_RIGHT_TO_MODIFY_TERMS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MEMBER_WEB_PAGE_DISPLAY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NOTICES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NO_WARRANTIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LIMITATION_ON_LIABILITY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.STATE_NOTICES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MISCELLANEOUS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PERFORMANCE_BY_PROSPER));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.SEPARATE_ENTITIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ARBITRATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ELECTRONIC_TRANSACTIONS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PERMISSION_TO_CONTACT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.APPOINTMENT));
		//        Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MILITARY_LENDING));
		//        Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROMISSORY_NOTE_SAMPLE));

		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROMISE_TO_PAY_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PAYMENTS_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.INTEREST_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LATE_CHARGE_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.CLAIMS_AND_DEFENSES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.CERTIFICATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.METHOD_OF_PAYMENT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.DEFAULT_AND_REMEDIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PREPAYMENTS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.WAIVERS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.INSUFFICIENT_FUNDS_CHARGE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ATTORNEYS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LOAN_CHARGES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ASSIGNMENT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NOTICES_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.GOVERNING_LAW));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MISCELLANEOUS_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ARBITRATION_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ELECTRONIC_TRANSACTIONS_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.REGISTRATION_OF_NOTE_OWNERS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.STATE_NOTICES_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MILITARY_LENDING_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.SIGNING_THIS_NOTE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LAST_UPADTE_DATE));

		LOG.info("GEAR-1903 Verify that content of 'Borrower Registration Agreement' for DTS logged-out user on legal page is as per mock");

	}


	/**
	 * 
	 * GEAR-1902 Verify that content of 'Borrower Registration Agreement' for DTS logged-in user on legal page is as per mock
	 */
	@Test(dataProvider = "testData", groups = {TestGroup.ACCEPTANCE})
	void verifyRegistrationAgreementWithSession(String Key, String jiraID, String loanAmount, String loanPurpose, String creditQuality,
			String firstName, String middleInitial, String lastName,
			String homeAddress, String city, String state, String zipCode, String employmentStatus,
			String yearlyIncome, String dob, String emailAddress, String password,
			String homePhone, String mobilePhone, String workPhone, String employerName,
			String employerPhone, String occupation, String employmentStartDate, String SSN, String bankName,
			String accountType, String accountholderName, String AlternateAccountHolderName,
			String routingNumber, String accountNumber, String confirmAccountNumber, String paymentType) throws AutomationException, IOException, XmlException, OpenXML4JException {

		LOG.info("~~~~~~~~~~Executing: verifyRegistrationAgreementWithSession()~~~~~~~~~~~~~");
		
		PublicSiteRegistrationPage registrationPage =
				modernizePreRegistrationPage.checkYourRate();
		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
		// Submit Register page
		registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName, homeAddress,
				city, state, employmentStatus, yearlyIncome, dob);
		registrationPage.clickElectronicSignatureCheckBox();
		PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

		// Submit Loan Offers page
		PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

		// Submit Personal Details page
		detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
				employmentStartDate, SSN);
		PublicSiteTruthInLendingDisclosurePage tilaPage = detailsPage.clickContinue();
		
		
		// Accept agreement and submit Tila page
		tilaPage.confirmElectronicSignature();
		Assert.assertEquals(tilaPage.getContactNumber(), Constants.UserCommonTestDetails.PROSPER_HELP_LINE_PHONE_NUMBER);
		LOG.info("GEAR-1647 Verify that Ph number is shown in new funnel footer");

		String listingID = tilaPage.getListingIdFromTILAContent();
		LOG.info("Prime Borrower ListingID is:" + listingID);

		PublicSiteBankAccountInfoPage bankInfoPage = tilaPage.clickContinue();
		PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

		// Submit Bank Information Page
		PublicSiteThankYouPage borrowerThankYouPage =
				manualBankPage.enterBankInfo(bankName, accountType, accountholderName, AlternateAccountHolderName, routingNumber,
						accountNumber, confirmAccountNumber, paymentType);
		// Submit Thank you page
		AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();

		overviewPage.clickOnProsperLogo();

		// click on Legal link on footer and then navigate to the Borrower Registration Agreement page
		modernizePreRegistrationPage.clickOnLegal();
		modernizePreRegistrationPage.clickOnLink("borrower_registration_link_text");

		// verify that agreement page is opened
		Assert.assertTrue(modernizePreRegistrationPage.isAgreementPageDisplayed());

		String agreementContent = modernizePreRegistrationPage.getAgreementContent();

		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.BRA_INTRO));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.REGISTRATION_AS_A_PROSPER_BORROWER));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.AUTHORIZATION_TO_OBTAIN_CREDIT_REPORT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LISTINGS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.RIGHT_TO_VERIFY_INFORMATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MATCHING_OF_INVESTOR));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.COMPENSATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MAKING_YOUR_LOAN_PAYMENTS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.COLLECTION_AND_REPORTING));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NO_GUARANTEE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.RESTRICTIONS_ON_USE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.AUTHORITY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.TERMINATION_OF_REGISTRATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROSPER_RIGHT_TO_MODIFY_TERMS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MEMBER_WEB_PAGE_DISPLAY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NOTICES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NO_WARRANTIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LIMITATION_ON_LIABILITY));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.STATE_NOTICES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MISCELLANEOUS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PERFORMANCE_BY_PROSPER));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.SEPARATE_ENTITIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ARBITRATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ELECTRONIC_TRANSACTIONS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PERMISSION_TO_CONTACT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.APPOINTMENT));
		//        Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MILITARY_LENDING));
		//        Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROMISSORY_NOTE_SAMPLE));

		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PROMISE_TO_PAY_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PAYMENTS_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.INTEREST_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LATE_CHARGE_SAMPLE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.CLAIMS_AND_DEFENSES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.CERTIFICATION));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.METHOD_OF_PAYMENT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.DEFAULT_AND_REMEDIES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.PREPAYMENTS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.WAIVERS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.INSUFFICIENT_FUNDS_CHARGE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ATTORNEYS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LOAN_CHARGES));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ASSIGNMENT));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.NOTICES_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.GOVERNING_LAW));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MISCELLANEOUS_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ARBITRATION_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.ELECTRONIC_TRANSACTIONS_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.REGISTRATION_OF_NOTE_OWNERS));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.STATE_NOTICES_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.MILITARY_LENDING_PN));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.SIGNING_THIS_NOTE));
		Assert.assertTrue(agreementContent.contains(Constants.RegistrationAgreement.LAST_UPADTE_DATE));
		LOG.info("GEAR-1902 Verify that content of 'Borrower Registration Agreement' for DTS logged-in user on legal page is as per mock");
	}



	/**
	 * 
	 * GEAR-1907 Verify that content of 'Debit Authorization' for DTS logged-out user on legal page is as per mock
	 */
	@Test(groups = {TestGroup.ACCEPTANCE}, enabled = true)
	void verifyDebitAuthorizationWithOutSession() throws AutomationException, IOException, XmlException, OpenXML4JException {

		LOG.info("~~~~~~~~~~Executing: verifyDebitAuthorizationWithOutSession~~~~~~~~~~~~~");

		// click on Legal link on footer and then navigatet to the Borrower Registration Agreement page
		modernizePreRegistrationPage.clickOnLegal();
		modernizePreRegistrationPage.clickOnLink("debitAuthorization_linkText");

		// verify that agreement page is opened
		Assert.assertTrue(modernizePreRegistrationPage.isAgreementPageDisplayed());

		String agreementContent = modernizePreRegistrationPage.getAgreementContent();

		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.DEBIT_AUTHORIZATION_TITLE));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.I_HEREBY));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_PREAUTHORIZED));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_A_ONE_TIME));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.I_UNDERSTAND));

		LOG.info("GEAR-1907 Verify that content of 'Debit Authorization' for DTS logged-out user on legal page is as per mock");

	}

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] {
			Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose", "homeImprovementListing"),
		};
	}


	/**
	 * GEAR-1904 Verify that for DTS user content of 'Debit Authorization' is as per mock-up
	 * GEAR-1906 Verify that content of 'Debit Authorization' for DTS logged-in user on legal page is as per mock
	 * GEAR-1905 Verify that content of 'Debit Authorization' for DTS logged-in user under history is as per mock
	 * 
	 */
	@Test(dataProvider = "testData", groups = {TestGroup.ACCEPTANCE})
	public void verifyDebitAuthorizationWithSession(String Key, String jiraID, String loanAmount, String loanPurpose, String creditQuality,
			String firstName, String middleInitial, String lastName,
			String homeAddress, String city, String state, String zipCode, String employmentStatus,
			String yearlyIncome, String dob, String emailAddress, String password,
			String homePhone, String mobilePhone, String workPhone, String employerName,
			String employerPhone, String occupation, String employmentStartDate, String SSN, String bankName,
			String accountType, String accountholderName, String AlternateAccountHolderName,
			String routingNumber, String accountNumber, String confirmAccountNumber, String paymentType)
					throws AutomationException {

		LOG.info("~~~~~~~~~~Executing: verifyDebitAuthorizationWithSession~~~~~~~~~~~~~");

		password = MessageBundle.getMessage("password");

		PublicSiteRegistrationPage registrationPage =
				modernizePreRegistrationPage.checkYourRate();
		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
		// Submit Register page
		registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName, homeAddress,
				city, state, employmentStatus, yearlyIncome, dob);
		registrationPage.clickElectronicSignatureCheckBox();
		PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

		// Submit Loan Offers page
		PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

		// Submit Personal Details page
		detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
				employmentStartDate, SSN);
		PublicSiteTruthInLendingDisclosurePage tilaPage = detailsPage.clickContinue();

		tilaPage.clickOnLink(Constants.TilaPageConstants.PAYMENT_AUTHORIZATION);
		tilaPage.switchToNewlyOpenedWindow();

		BorrowerAuthorizationToDebitAccountPage  AuthorizationToDebitPage = tilaPage.getAuthorizationToDebitPage();

		String agreementContentTILA = AuthorizationToDebitPage.getAgreementContent();

		Assert.assertTrue(agreementContentTILA.contains(Constants.DebitAuthorization.DEBIT_AUTHORIZATION_TITLE));
		//		Assert.assertTrue(agreementContentTILA.contains(Constants.DebitAuthorization.I_HEREBY));
		//		Assert.assertTrue(agreementContentTILA.contains(Constants.DebitAuthorization.IF_I_SELECT_PREAUTHORIZED));
		Assert.assertTrue(agreementContentTILA.contains(Constants.DebitAuthorization.IF_I_SELECT_A_ONE_TIME));
		Assert.assertTrue(agreementContentTILA.contains(Constants.DebitAuthorization.I_UNDERSTAND));
		LOG.info("GEAR-1904 Verify that for DTS user content of 'Debit Authorization' is as per mock-up");

		tilaPage.closeAllButOneBrowser();

		// Accept agreement and submit Tila page
		tilaPage.confirmElectronicSignature();
		Assert.assertEquals(tilaPage.getContactNumber(), Constants.UserCommonTestDetails.PROSPER_HELP_LINE_PHONE_NUMBER);
		LOG.info("GEAR-1647 Verify that Ph number is shown in new funnel footer");

		String listingID = tilaPage.getListingIdFromTILAContent();
		LOG.info("Prime Borrower ListingID is:" + listingID);

		PublicSiteBankAccountInfoPage bankInfoPage = tilaPage.clickContinue();
		PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

		// Submit Bank Information Page
		PublicSiteThankYouPage borrowerThankYouPage =
				manualBankPage.enterBankInfo(bankName, accountType, accountholderName, AlternateAccountHolderName, routingNumber,
						accountNumber, confirmAccountNumber, paymentType);
		// Submit Thank you page
		AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();

		overviewPage.clickOnProsperLogo();

		// click on Legal link on footer and then navigate to the Borrower Registration Agreement page
		modernizePreRegistrationPage.clickOnLegal();
		modernizePreRegistrationPage.clickOnLink("debitAuthorization_linkText");

		// verify that agreement page is opened
		Assert.assertTrue(modernizePreRegistrationPage.isAgreementPageDisplayed());

		String agreementContent = modernizePreRegistrationPage.getAgreementContent();

		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.DEBIT_AUTHORIZATION_TITLE));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.I_HEREBY));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_PREAUTHORIZED));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_A_ONE_TIME));
		Assert.assertTrue(agreementContent.contains(Constants.DebitAuthorization.I_UNDERSTAND));
		LOG.info("GEAR-1906 Verify that content of 'Debit Authorization' for DTS logged-in user on legal page is as per mock");


		overviewPage.clickOnProsperLogo();

		modernizePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());

		final AccountHistoryPage historyPage = modernizePreRegistrationPage.goToHistoryPage();

		final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();

		legalAgreementsPage.clickAgreementLink(Constants.LegalAgreementsPage.AUTHORIZATION_TO_DEBIT_ACCOUNT);

		String legalAgreementContent = legalAgreementsPage.getAgreementContent();

		Assert.assertTrue(legalAgreementContent.contains(Constants.DebitAuthorization.DEBIT_AUTHORIZATION_TITLE));
		//		  Assert.assertTrue(legalAgreementContent.contains(Constants.DebitAuthorization.I_HEREBY));
		//		  Assert.assertTrue(legalAgreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_PREAUTHORIZED));
		Assert.assertTrue(legalAgreementContent.contains(Constants.DebitAuthorization.IF_I_SELECT_A_ONE_TIME));
		Assert.assertTrue(legalAgreementContent.contains(Constants.DebitAuthorization.I_UNDERSTAND));
		LOG.info("GEAR-1905 Verify that content of 'Debit Authorization' for DTS logged-in user under history is as per mock");

	}
}
