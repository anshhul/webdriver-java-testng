
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 08-Jul-2016
 *
 */
public class OfferChartForAgentTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(OfferChartForAgentTest.class.getSimpleName());
    private static String ABP_PARTNER_CHANNEL = "Direct Mail";


    // GEAR-1441 Verify that user NOT sees new offer page in ABP funnel
    @Test(groups = {TestGroup.NIGHTLY})
    void testOfferChartForAgentUser() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testOfferChartForAgentUser~~~~~~~~~~~~~~~~~~~~");

        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.deleteAllCookies();
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testOfferChartForAgentUser", "p2pcredit");
        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

        if (!abpOfferPage.getWindowLocationHref().contains("offersSliderChart?")) {
            abpOfferPage.navigateToNewOfferPage();
        }
        // You qualify for a loan Static text displayed to Borrower
        Assert.assertFalse(abpOfferPage.isStaticTextDisplayed("You qualify for a loan"));
        // Loan Offers Static text displayed to Agent
        Assert.assertFalse(abpOfferPage.isStaticTextDisplayed("Loan Offers"));
        LOG.info("GEAR-1441 Verify that user NOT sees new offer page in ABP funnel");
    }
}
