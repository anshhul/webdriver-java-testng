
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ProspectResponseCodes;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.util.web.borrower.common.ModifyXMLUtil;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

/**
 * PART-373 Existing User:Lending Tree:Adverse Action - Adverse Action - 580<=FICO<=FICO<640)
 *
 * @author jdoriya 13-May-2016
 *
 */
public class BorrowerDXLTExistingLowCreditLessThan640Test extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXLTExistingLowCreditLessThan640Test.class.getSimpleName());


    @Test(groups = {TestGroup.NIGHTLY})
    void testLTExistingLowCreditScoreAdverseAction()
            throws HttpRequestException, AutomationException, XPathExpressionException, SAXException, IOException,
            ParserConfigurationException, TransformerException {
        LOG.info("Executing: testLTExistingLowCreditScoreAdverseAction");
        String email = getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG);
        ModifiedXmlEntity entity =
                ModifyXMLUtil.updateLTXMLFile(getExistingLowFicoLessthan640Data().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), null,
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, null,
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.SSN_TAG),
                        email, null, null, null,
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.STATE_TAG), null,
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                        getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));

        String requestBody = entity.getRequestBody();

        LOG.info("Existing LT Low Credit score user is: " + email);
        // reset Adverse action event date to avoid 120 decline
        UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String userID = userInfo.getUserIDByEmail(email);
        LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
        loanOfferDeclineInfo.updateCreatedDate(userID);
        AdverseActionEventDAO adverseActionEventInfo =
                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
        adverseActionEventInfo.updateAdverseActionEventDate(userID);
        PollingUtilities.sleep(2000);
        HttpResponse dxReferralOfferResponse = creditKarmaWCFService.getLTOffers(requestBody);

        LOG.info("Dx Lending Tree request is hit  on endpoint");
        String[] allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), "ERRORDESCRIPTION");
        Assert.assertEquals(allURLs[0], "Success", "ERRORDESCRIPTION is not correct");
//        Assert.assertNotNull(allURLs[0]);
        // Verify Prospect table
        LOG.info("Success Verified");
        MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
        ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        ProspectResponseCodes codes = prospectInfo.getResponseCodes(email);
        String offerUserID = prospectInfo.getOfferUserId(email);
        LOG.info("User OfferUserID is: " + offerUserID);
        // verfiy prospect records
        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getExistingLowFicoLessthan640Data().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");
        Assert.assertEquals(codes.getHttpResponseCode(), "200",
                "Eligiblity reason is not correct");

        Assert.assertEquals(prospectInfo.getIneligibilityReason(email).toString(),
                "Based on Prosper's internal algorithm, we could not find any matching offers.");

        // verify AdverseActionEvent table:
        PollingUtilities.sleep(40000);
//        adverseActionEventInfo =
//                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
//        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(email),
//               AdverseActionTemplate.CREDIT_SCORE_TOOLOW_PRIOR_BORROWER.getAdverseActionEventTypeID());

        String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(email);

//        Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
//                SquareCutTemplate.CREDIT_SCORE_TOOLOW_PRIOR_BORROWER.getSquareCutTypeID());

//        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
//                "messagesent data should not be null");

        loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
//        Assert.assertEquals(
//                loanOfferDeclineInfo.getDeclineReasonID(offerUserID),
//                DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_PRIOR_BORROWER.getDeclineReasonID());
        LOG.info("BMP-888 Existing User:Lending Tree:Adverse Action - Adverse Action - 580<=FICO<=FICO<640)");
    }
}
