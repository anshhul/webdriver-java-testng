
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.wcf.client.DXReferralImpl;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 *
 * @author jdoriya 15-May-2016
 *
 */
public class BorrowerDXGetOfferNewUserListingViaAHLClientTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXGetOfferNewUserListingViaAHLClientTest.class.getSimpleName());


    // BMP-894 New User:Get Offer :Employed:AHL: Pricing and Loan Values : User should able to create listing and standard
    // pricing should be displayed to the user.
    @Test(groups = {TestGroup.NIGHTLY})
    public void testListingViaAHLClient()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        String listingId = null;;
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("wcf/spring/wcf_service_context.xml")) {

            final DXReferralImpl ahlClientWCFService = (DXReferralImpl) jobContext.getBean("ahlWCFService");
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testListingViaAHLClient");
            final ModifiedXmlEntity entity =
                    buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.AHL_SUBPROGRAM_ID, email);
            PollingUtilities.sleep(2000);
            final HttpResponse response = ahlClientWCFService.getOffers(entity.getRequestBody());

            Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                    "ShowSelectedOfferUrl Tag size is 0");
            final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
            Assert.assertNotNull(allURLs);
            Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
            final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
            try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                    URLUtilities.getScheme(offersUrlToUseForTesting),
                    URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
                dxLandingPage.setPageElements(pageElements);
                PublicSitePersonalDetailPage personalDetailsPage = null;
                final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
                if (isPasswordEntered) {
                    Assert.assertTrue(dxLandingPage.getUserName()
                            .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)
                                    .toUpperCase()));
                    Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                            .replace("{firstName}",
                                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                            .contains(dxLandingPage.getWelcomeNote()));

                    dxLandingPage.clickElectronicSignatureCheckBox();

                    personalDetailsPage =
                            dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
                }
                personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
                personalDetailsPage.waitForPersonalDetailsPage();
                Assert.assertTrue(personalDetailsPage.getSsnPopulated());
                Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
                personalDetailsPage.selectOccupation("Chemist");
                personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

                final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
                listingId = tilPage.getListingIdFromTILAContent();
                tilPage.confirmElectronicSignature();
                final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
                // Un-comment below assert once Miicard is stable for borrower on stg2/qa
                // String headerText = bankAccountInfoPage.getbankInfoHeaderText();
                // Assert.assertTrue(headerText.contains(MessageBundle.getMessage("newUserBankInfoHeader")));

                final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                        .submitManualBankOption();
                // User added general Bank details with routing no
                final PublicSiteThankYouPage borrowerThankYouPage =
                        manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                                "Savings",
                                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                                getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                                getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                                getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

                // User navigate to Thank you Page and clicked on go to my account
                // button
                LOG.info("User navigate to Thank you  Page");
                borrowerThankYouPage.clickGoToMyAccountPage();
                LOG.info(
                        "BMP-894 New User:Get Offer :Employed:AHL: Pricing and Loan Values : User should able to create listing and standard pricing should be displayed to the user.");
            }
                // Log into the Support site with user created above
                try (ClassPathXmlApplicationContext supportSiteContext =
                        new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

                    final SupportSiteLandingPage supportSiteLandingPage =
                            (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

                    supportSiteLandingPage.enterEmailAddress();
                    supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

                    final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

                    final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
                    final SupportBorrowerListingsTabPage listingPage = memberPage.searchListingByID(listingId);
                    Assert.assertTrue(listingPage.getSource().contains("DX"));
                    Assert.assertTrue(listingPage.getChannel().contains("DataExchange"));
                    Assert.assertTrue(listingPage.getPartnerNameAsElement().getText().contains("American HealthCare Lending"));
                }
            }
    }
}
