
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author hnegi
 */
public class ModernizePwdStrengthOnABPFunnelTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ModernizePwdStrengthOnABPFunnelTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    private static String INCORRECT_PASSWORD_ERROR_MESSAGE ="Please create a password. For added security, it must be at least 8 characters and contain 1 number, 1 uppercase letter, 1 lowercase letter and 1 symbol.";

    /**
     *
     * GEAR-720 Verify that correct text is displayed when password field is in focus on ABP landing page
     * GEAR-719 Verify that password strength is upgraded on ABP landing page
     * GEAR-726 Verify that error is displayed immediately after user clicks out of password field ABP landing page
     * GEAR-730 Verify that user is not able to submit reset password page without fulfiling all the conditions of password strength ABP landing page
     * GEAR-731 Verify that user is able to submit reset password page after fulfiling all the conditions of password strength
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.NIGHTLY}, enabled = true)
    void testPasswordStrengthOnABPLandingPage() throws AutomationException, InterruptedException {

        LOG.info("Executing: testPasswordStrengthOnABPLandingPage");
        // login to support site
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.deleteAllCookies();
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testPasswordStrengthOnABP", "p2pcredit");
        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        final String maxLoanOfferLimit = abpOfferPage.getMaxLoanOfferLimit();
        // click on choose rate button
        PollingUtilities.sleep(3000);
        abpOfferPage.clickOnCompleteLater();
        // wait for complete later modal to appear
        Assert.assertTrue(abpOfferPage.getCompleteLaterAsElement().isDisplayed());
        // select abandon reason for flow
        abpOfferPage.selectAbandonReason("Miscellaneous");
        // submit the abandon reason
        abpOfferPage.clickOnSubmitAbandonReason();
        PollingUtilities.sleep(3000);
        Assert.assertTrue(abpOfferPage.getCompleteLaterModalHeader().getText().contains("Success!"));
        // Verify abp mail box and retrieve the finish request url for borrower
        abpOfferPage.close();
        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"),
                MessageBundle.getMessage("followingUpBodyDroppedTemplate").replace("{maxLoanOfferAmount}", maxLoanOfferLimit));
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(urlFromWeb), URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);

            // Set the focus on password field
            abpLandingPage.enterPasswordWithFocus(RandomStringUtils.random(1, true, false));
            Assert.assertTrue(abpLandingPage
                    .verifyPasswordMessageDisplayed(INCORRECT_PASSWORD_ERROR_MESSAGE));
            LOG.info("GEAR-720 Verify that correct text is displayed when password field is in focus on ABP landing page");
            LOG.info("GEAR-719 Verify that password strength is upgraded on ABP landing page");

            //Set the focus at outside of password page
            abpLandingPage.enterPassword(RandomStringUtils.random(1));
            Assert.assertTrue(abpLandingPage
                    .verifyPasswordMessageDisplayedWithoutFocus(INCORRECT_PASSWORD_ERROR_MESSAGE));
            LOG.info("GEAR-726 Verify that error is displayed immediately after user clicks out of password field ABP landing page");

            // submit reset password page without fulfilling all the conditions of password
            abpLandingPage.enterPassword(RandomStringUtils.random(8));
            Assert.assertTrue(abpLandingPage
                    .verifyPasswordMessageDisplayedWithoutFocus(INCORRECT_PASSWORD_ERROR_MESSAGE));
            LOG.info("GEAR-730 Verify that user is not able to submit reset password page without fulfiling all the conditions of password strength ABP landing page");


            // Set the focus back on Password field by putting any random character
            abpLandingPage.enterPasswordWithFocus(RandomStringUtils.random(1, false, true));
            abpLandingPage.verifyPasswordTextColor("1 Number");
            LOG.info("GEAR-727 Verify that text message goes back to black color when user clicks in password field ABP landing page");

            // submit reset password page after fulfiling all the conditions of password strength
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            Assert.assertFalse(abpLandingPage
                    .verifyPasswordMessageDisplayedWithoutFocus(INCORRECT_PASSWORD_ERROR_MESSAGE));
            LOG.info("GEAR-731 Verify that user is able to submit reset password page after fulfiling all the conditions of password strength");
        }
    }
}