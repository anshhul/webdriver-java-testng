
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.offer.OffersUnfundedRequest;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class MaStateUserDMFirmOfferTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(MaStateUserDMFirmOfferTest.class.getSimpleName());
    private static final String MA_STATE_LOAN_AMOUNT = "7000";
    @Autowired
    IPlatformOffer platFormOffer;


    // HINT: Ma state user is not known
    // GEAR-868 MA State: Verify that user with expired listing created from DM Scanning do not receive firm offer of credit email
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testMaStateDmUser() throws AutomationException, HttpRequestException {
        LOG.info("~~~~~~~~~~~~Executing: testMaStateDmUser~~~~~~~~~~~~~~~~~~");
        // reset DM User's offer code
        resetOfferCode(getAllDmValidOfferCode().get(1).get(Constants.HomeWidgetPage.OFFCODE_TAG));
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testMaStateDmUser", "p2pcredit");
        publicSiteRegistrationPage.fillRegistrationForm(
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                MA_STATE_LOAN_AMOUNT, getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getAllDmValidOfferCode().get(1).get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingId = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        Assert.assertNotNull(accountOverviewPage);
        LOG.info("MA State User listingId is:" + listingId);

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        // verify firm offer email for expired listing DM User
        final OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingId, userId));
        // Response delay
        PollingUtilities.sleep(10000);
        Assert.assertNull(offerResponse);
        LOG.info(
                "GEAR-868 MA State: Verify that user with expired listing created from DM Scanning do not receive firm offer of credit email");
    }
}
