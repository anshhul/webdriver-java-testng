
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author jdoriya
 *
 */
public class NewTilaDMBorrowerCompleteListingTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(NewTilaDMBorrowerCompleteListingTest.class.getSimpleName());


    // GEAR-1554 Verify that user is able to complete DM listing from new TILA page
    @Test(groups = {TestGroup.NIGHTLY})
    void testNewTilaDmUser() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: testNewTilaDmUser~~~~~~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            final String refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            final String prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String emailAddress = Constant.getGloballyUniqueEmail(true);

            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            /*
             * publicSiteRegistrationPage
             * .enter5digitZipCode(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
             */
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);

            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingId = tilaPage.getListingIdFromTILAContent();
            LOG.info("User listingid is:" + listingId);
            if (tilaPage.isTilaPrintVersionDisplayed()) {
                tilaPage.navigateToNewTILAPage();
            }
            tilaPage.waitForTILAPage();
            Assert.assertFalse(tilaPage.isTilaPrintVersionDisplayed());
            Assert.assertFalse(
                    tilaPage.isTextDisplayed(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG)));
            tilaPage.confirmElectronicSignature(); // User navigated to bank info page final
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
            // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
            // User navigate to Thank you Page and clicked on go to my account // button
            LOG.info("User navigate to Thank you Page");
            LOG.info("DM Borrower ListingID is:" + listingId);
        }
    }
}
