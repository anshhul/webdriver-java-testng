
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmailValidationResponse;
import com.prosper.automation.model.platform.UserEmailVerifyResponse;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformUser;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by jdoriya on 9/22/2016
 */
public class NewTilaDXGetOfferNewUserTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewTilaDXGetOfferNewUserTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;
    @Resource
    protected IPlatformUser pubSiteUserService;
    private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
    private static final String SUCCESS_PASSWORD_MESSAGE = "Success. Your password has been changed.";


    // GEAR-1556 Verify that user is able to complete DX listing from new TILA page
    // GEAR-1555 Verify new TILA page from DX funnel
    // HINT :BMP-5430
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    public void testNewTilaForDXGetOfferUser()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testNewTilaForDXGetOfferUser~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testNewTilaForDXGetOfferUser");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));

                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();

            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();
            final String listingId = tilaPage.getListingIdFromTILAContent();
            LOG.info("User listingid is:" + listingId);
            if (tilaPage.isTilaPrintVersionDisplayed()) {
                tilaPage.navigateToNewTILAPage();
            }
            tilaPage.waitForTILAPage();
            Assert.assertFalse(tilaPage.isTilaPrintVersionDisplayed());
            Assert.assertFalse(
                    tilaPage.getTilLoanPurposerHeader()
                            .contains(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG)));
            tilaPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilaPage.clickContinue();

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button
            final AccountOverviewPage accountOverviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final List<Map<String, Object>> lendingAccreditationRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
            Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            LOG.info("User navigate to Thank you  Page");
            LOG.info("GEAR-1555 Verify new TILA page from DX funnel");

            // verify password reset flow for DX user
            accountOverviewPage.deleteAllCookies();
            final PublicSitePreRegistrationPage preRegistrationPage = accountOverviewPage.clickOnProsperLogo();
            final PublicSiteSignInPage signInPage = preRegistrationPage.clickSignIn();
            final PublicSiteRequestEmailForChangePasswordPage forgotPasswordPage = signInPage.clickForgotPassword();
            forgotPasswordPage.enterEmailAddress(email);
            forgotPasswordPage.clickContinue();
            PollingUtilities.sleep(4000);
            verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp_resetPassword"),
                    MessageBundle.getMessage("followingUpBody_resetPassword"));
            final EmailValidationResponse responseFromEmailService = pubSiteUserService.validateUserEmail(email);
            final UserEmailVerifyResponse verifyResponse =
                    pubSiteUserService.verifyUserEmail(responseFromEmailService.getActivationKey());
            Assert.assertTrue(verifyResponse.getIsVerified());
            final String code = circleOneDBConnection.getDataAccessObject(UserDAO.class).getUserIDByEmail(email);
            try (final PublicSiteMarketplaceLandingPage verificationPage =
                    new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
                            publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + code)) {
                verificationPage.setPageElements(pageElements);
                final String fiveDigitZip =
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).substring(0, 5);
                final PasswordChangePage passwordChangePage = verificationPage.resetPasswordForUser(
                        fiveDigitZip,
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
                checkPasswordStrengthMeter(passwordChangePage);
                passwordChangePage.confirmNewPassword(Constant.COMMON_PASSWORD);
                passwordChangePage.clickChangePassword();
                Assert.assertTrue(passwordChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
                Assert.assertTrue(passwordChangePage.isStaticTextDisplayed(SUCCESS_PASSWORD_MESSAGE));
                LOG.info(
                        "BOR-7430 Verify that user is able to submit  Security Question page with 5 digit Zip code for default questions");
            }

            LOG.info("~~~~testNewTilaForDXGetOfferUser--PASSED~~~~~~~~~~~");

        }
    }

    private void checkPasswordStrengthMeter(PasswordChangePage pwdChangePage) throws AutomationException {
        pwdChangePage.enterNewPassword("P");
        pwdChangePage.checkPasswordMeter("1 uppercase letter");
        pwdChangePage.enterNewPassword("@");
        pwdChangePage.checkPasswordMeter("1 symbol");
        pwdChangePage.enterNewPassword("ssword");
        pwdChangePage.checkPasswordMeter("8 characters");
        pwdChangePage.enterNewPassword("23");
        pwdChangePage.checkPasswordMeter("1 number");
    }
}
