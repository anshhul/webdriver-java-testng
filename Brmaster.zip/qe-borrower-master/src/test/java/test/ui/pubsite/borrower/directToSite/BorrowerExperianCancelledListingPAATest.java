
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsEditPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * BMP-520 Verify that decline is displayed to having A user having Cancelled Listing (Blank)
 *
 * @author hnegi
 *
 */
public class BorrowerExperianCancelledListingPAATest extends PartnerLandingPageTestBase {

    Logger LOG = Logger.getLogger(BorrowerExperianCancelledListingPAATest.class);


    @DataProvider(name = "userNonBorrowingStateTestData")
    public static Object[][] FICOUserData() {

        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "UserRegisterPersonalDetail", "Valid User Details")};

    }


    @Autowired
    protected CloseableJdbcConnection adverseActionEventDBConnection;

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

    private final static String DECLINE_CONTENT = MessageBundle.getMessage("noCreditScoreAvailable");
    private static String messageId;


    @Test(dataProvider = "userNonBorrowingStateTestData", groups = {TestGroup.NIGHTLY}, enabled = false)
    public void verifyListingIsCancelledWithExperianReason(String adverseAction, String loanAmount, String loanPurpose,
                                                           String creditQuality, String firstName, String lastName,
                                                           String middleInitial, String suffix, String homeAddress, String city,
                                                           String state,
                                                           String zipCode, String employmentStatus, String yearlyIncome,
                                                           String dob,
                                                           String emailAddress, String password, String primaryPhone,
                                                           String secondaryPhone, String workPhone, String employerName,
                                                           String employerPhone, String occupation, String startOfemployment,
                                                           String SSN, String bankName, String accountHolderName,
                                                           String routingNumber, String accountNumber) throws AutomationException {

        LOG.info("Test Method Name- verifyLitingIsCancelledWithBlankReason");

        // Submit Home page
        final PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        emailAddress =
                registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, emailAddress,
                        MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                        yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // registrationPage.handleSSNPage(SSN);

        final PublicSitePersonalDetailPage personalDetailsPage = offerPage
                .clickOnGetThisLoanButtonForThreeYears();
        personalDetailsPage.fillPersonalDetailPage(primaryPhone, secondaryPhone, workPhone, employerName, employerPhone,
                occupation, startOfemployment, SSN);
        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage
                .clickContinue();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();
        final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();

        final PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

        // Submit Bank Information Page
        final PublicSiteThankYouPage borrowerThankYouPage =   manualBankPage.enterBankInfo(bankName, "", accountHolderName,
                accountHolderName, routingNumber, accountNumber,
                accountNumber, "");

        // Submit Thank you page
        final AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPage.dismissCongratulationWelcomeModal();
        final String listingID = overviewPage.getListingInfo().get("LISTING ID");
        Assert.assertNotNull(listingID, "Account Overview page should be displayed");


        overviewPage.userSignOut();

        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        LOG.info("Clicked on 'Members' link");
        final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();

        LOG.info("search listing by listing id and navigate to 'Listings Tab' page");
        final SupportBorrowerListingsTabPage borrowerListingsTabPage = memberPage.searchListingByID(listingID);

        LOG.info("click on 'Edit Status' link");
        final SupportBorrowerListingsEditPage borrowerListingsEditPage = borrowerListingsTabPage.clickOnEditStatusLink();

        LOG.info("Cancel the loan listing from support site.");
        borrowerListingsEditPage.cancelListing("Experian");

        LOG.info("Sign out from support site");
        supportSiteMainPage.signOut();

        // Verify in Public site
        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();
        Assert.assertNotNull(publicSiteSignInPage);
        PollingUtilities.sleep(5000);
        publicSiteSignInPage.enterUserEmail(emailAddress);
        publicSiteSignInPage.enterUserPassword(Constant.COMMON_PASSWORD);

        // Navigate to Messages Page
        publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.MESSAGES.getValue());
        final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();

        // Verify message and navigate to View Messages Page
        final ViewMessagePage viewmessagesPage = messagesPage.verifyAndClickMessage(Constants.MessagesPage.CREDIT_SCORE_UNAVAILABLE);

        messageId = viewmessagesPage.getMessageIdFromURL();
        LOG.info("Message ID: " + messageId);

        // Verify message content
        viewmessagesPage.verifyMessageContent(firstName,
                MessageBundle.getMessage("noCreditScoreAvailableMessage"));

        // Navigate to History Page
        viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());

        // Navigate to 'Event History' Page
        final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
        final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();

        // Verify that appropriate events are displayed on the 'Event History' page
        eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
                Constants.EventHistorypage.CREDIT_SCORE_UNAVAILABLE_EVENT_NAME);
        eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
                Constants.EventHistorypage.AALETTERDETAILS);

        // Click on 'Adverse Action Letter' link displayed within event details and verify Agreement Page content
        eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
        // switched to newly opened window
        eventHistoryPage.switchToNewlyOpenedWindow();
        Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
                .contains(MessageBundle.getMessage("noCreditScoreAvailableMessage")));
        eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);

        // Navigate to History Page
        eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
        final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();

        // Verify Agreement page content and get AgreementID from URL for further use
        final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(MessageBundle.getMessage("AALetter"),
                MessageBundle.getMessage("noCreditScoreAvailableMessage"));

        // Get user id
        final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userEmail.getUserIDByEmail(emailAddress);

        // Verify the values displayed in table AdverseActionEvent
        final AdverseActionEventDAO adverseActionEventInfo =
                circleOneDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
                AdverseActionTemplate.INVALID_FICOSCORE.getAdverseActionEventTypeID());

        // Get 'AdverseActionEventID' from the query result
        final String adverseActionEventId =
                adverseActionEventInfo.getAdverseActionEventID(emailAddress);
        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
                "messagesent data should not be null");

        // Verify the values displayed in MessageSent tabl
        Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));

        Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));

        // Verify the values displayed in AdverseActionEventSquareCutInfo table
        Assert.assertFalse(adverseActionEventInfo.isSquareCutTypeID(adverseActionEventId));

        // Verify the values displayed in tblloanofferdecline table
        final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
        Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
                DeclineReasonTemplate.INVALID_FICOSCORE_9001.getDeclineReasonID());

        // Verify An email notification "Information about your loan request" should be triggered to user in his personal email
        // inbox
        verifyWebMail(outlookQAWebAppPage, "QA", emailAddress, firstName,
                MessageBundle.getMessage("infoAboutLoanRequest"),
                MessageBundle.getMessage("notEligibleForLoan"));
        LOG.info("**** Passed ****");

    }

}
