
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.enumeration.platform.EmploymentStatus;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-441 Existing user with loan Path B:User should be able to complete the funnel from Public site.
 *
 * @author jdoriya 18-May-2016
 *
 */
public class ABPExistingUserHappyPathBTest extends PartnerLandingPageTestBase {

    private static final String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPExistingUserHappyPathBTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // BMP-3971 Existing user with loan Path B:User should be able to drop the
    // funnel on Personal Details page.
    // BMP-3982 Standard: Verify that correct Abandon Reason ID is displayed in
    // AbandonReason column of Prospect table when
    // dropped listing on personal detail page
    // BMP-3947 Existing user with loan Path B:Password creation mail of Path B
    // should be triggered to borrower on dropping the
    // funnel on Personal details page.
    // BMP-3963 Existing user with loan Path B:User should be navigated to Enter
    // Your password page from Password creation mail of
    // Path B should be triggered to borrower .
    // BMP-3967 Existing user with loan Path B:User should be navigated to
    // Register page on submiiting Enter Your password page
    // with correct password.
    // BOR-7508 Existing user with loan Path B:User should be able to complete
    // the funnel from Public site
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserHappyPathB() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testExistingUserHappyPathB~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
                .getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);
        final String email = getUserForEnvironment("testExistingUserHappyPathB");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);

        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage
                .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        abpRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG));
        // click on choose rate button
        final String referralCode = abpOfferPage.getReferalCode();
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        LOG.info("CSA user abandon the flow as per client request on Personal detail page");
        PollingUtilities.sleep(3000);
        final String pathBUrl = abpPersonalDetailPage.getABPPathBUrl(referralCode);
        abpPersonalDetailPage.clickOnCompleteLater();

        // wait for complete later modal to appear
        Assert.assertTrue(abpPersonalDetailPage.isCompleteLaterModalDisplayed());
        LOG.info(
                "BMP-3971 Existing user with loan Path B:User should be able to drop the funnel on Personal Details page.");
        // select abandon reason for flow
        abpPersonalDetailPage.selectAbandonReason("Miscellaneous");
        final String abandonReasonId = abpPersonalDetailPage.getAbandonReasonId("Miscellaneous");
        PollingUtilities.sleep(3000);
        // submit the abandon reason
        abpPersonalDetailPage.clickOnSubmitAbandonReason();
        PollingUtilities.sleep(3000);
        final List<Map<String, Object>> prospectInfo = queryCircleOne(
                String.format(MessageBundle.getMessage("prospectTableQuery"), email));
        final String expectedReasonId = prospectInfo.get(0).get("AbandonReason").toString();
        Assert.assertEquals(abandonReasonId, expectedReasonId);
        LOG.info(
                "BMP-3982 Standard: Verify that correct Abandon Reason ID is displayed in AbandonReason column of Prospect table when dropped listing on personal detail page");
        Assert.assertTrue(abpPersonalDetailPage.getCompleteLaterModalHeader().getText().contains("Success!"));
        abpPersonalDetailPage.close();
       /* final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        Assert.assertNotNull(urlFromWeb);*/

        verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        LOG.info(
                "BMP-3947 Existing user with loan Path B:Password creation mail of Path B should be triggered to borrower on dropping the funnel on Personal details page.");
        LOG.info(
                "BMP-3963 Existing user with loan Path B:User should be navigated to Enter Your password page from Password creation mail of Path B should be triggered to borrower .");
        try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
                webDriverConfig, URLUtilities.getScheme(pathBUrl), URLUtilities.getStringURLWithoutScheme(pathBUrl))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(pathBUrl);
            LOG.info(
                    "BMP-3967 Existing user with loan Path B:User should be navigated to Register page on submiiting Enter Your password page with correct password.");
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            Assert.assertNotNull(personalDetailPage);
            final PublicSiteTruthInLendingDisclosurePage truthInLendingDisclosurePage = personalDetailPage
                    .clickContinue();

            truthInLendingDisclosurePage.confirmElectronicSignature();
            final String listingID = truthInLendingDisclosurePage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = truthInLendingDisclosurePage
                    .clickContinue();

            Assert.assertNotNull(publicSiteBankAccountInfoPage);
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            /*
             * clearAndEnterBankInfoForExistingUser( getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
             */
            publicSiteThankYouPage.clickGoToMyAccountPage();
            LOG.info("ABP  Path B Prior Borrower ListingID is:" + listingID);
            LOG.info(
                    " BOR-7508 Existing user with loan Path B:User should be able to complete the funnel from Public site");
        }
        LOG.info("~~~~~~~~~ testExistingUserHappyPathB--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

    /*
     * BMP-3977:Existing user with loan Path B:User should be able to complete the funnel from Public site
     *
     *
     */
    // TODO: Duplicate
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testExistingUserHappyPathBQPWorkFlow() throws AutomationException {

        LOG.info("Executing: testExistingUserHappyPathBQPWorkFlow");
        // login to support site
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
                .getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathBFlow", "p2pcredit");
        LOG.info("ABP User email is: " + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage
                .enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage
                .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage
                .enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage
                .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        abpRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG));
        final String maxLoanOfferLimit = abpOfferPage.getMaxLoanOfferLimit();
        // click on choose rate button
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        // abandon the flow , click on complete later button
        PollingUtilities.sleep(3000);
        abpPersonalDetailPage.clickOnCompleteLater();

        // wait for complete later modal to appear
        Assert.assertTrue(abpPersonalDetailPage.isCompleteLaterModalDisplayed());
        // select abandon reason for flow
        abpPersonalDetailPage.selectAbandonReason("Miscellaneous");
        // submit the abandon reason
        abpPersonalDetailPage.clickOnSubmitAbandonReason();
        PollingUtilities.sleep(5000);
        Assert.assertTrue(abpPersonalDetailPage.getCompleteLaterModalHeader().getText().contains("Success!"));
        // Verify abp mail box and retrieve the finish request url for borrower

        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBodyDroppedTemplate")
                        .replace("{maxLoanOfferAmount}", maxLoanOfferLimit));

        try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
                webDriverConfig, URLUtilities.getScheme(urlFromWeb),
                URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(urlFromWeb);
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

           /* Assert.assertTrue(abpRegistrationPage.verifyUserDetailsPreFilled());*/
            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyEmploymentStatus(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG)));
            Assert.assertTrue(publicSiteRegistrationPage.verifyPrefilledEmail(email));
            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledDOB(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG)));

             Assert.assertTrue(publicSiteRegistrationPage
             .verifyPrefilledCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG)));

            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG)));
            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG)));
            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG)));
            LOG.info("Verified Pre-filled Reg details for Prime borrower");

            Assert.assertTrue(publicSiteRegistrationPage.isEmploymentStatusDropDownEditable());
            Assert.assertTrue(publicSiteRegistrationPage.isYearlyIncomeFieldEditable());
            Assert.assertEquals(publicSiteRegistrationPage.getEmploymentStatus(), EmploymentStatus.EMPLOYED.getDescription());

            LOG.info(
                    "~~~~~~~~~~~~~~~testExistingUserHappyPathBQPWorkFlow~~~~~~PASSED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        }
    }
}
