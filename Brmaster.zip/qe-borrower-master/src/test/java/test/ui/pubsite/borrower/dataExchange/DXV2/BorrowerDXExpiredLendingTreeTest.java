
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;
import test.ui.pubsite.borrower.dataExchange.cases.BorrowerDXExpiredLendingTreeTestCase;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

/**
 * Created by rsubramanyam on 4/7/16.
 */

public class BorrowerDXExpiredLendingTreeTest extends DXCompleteListingTestBase
        implements BorrowerDXExpiredLendingTreeTestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXExpiredLendingTreeTest.class.getSimpleName());

    // PART-638 Lending Tree:Get Offer:user with expired offers navigate to home page on hitting "ShowSelectedOfferUrl"
    @Override
    @Test(groups = {TestGroup.NIGHTLY})
    public void verifyExpiredOfferDXLendingTreeUserTest()
            throws IOException, JAXBException, XPathExpressionException, SAXException, ParserConfigurationException,
            TransformerException, JSONException, AutomationException, HttpRequestException {
        LOG.info("~~~~Executing: verifyExpiredOfferDXLendingTreeUserTest~~~~~~~~~~~");
        final String emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("ExpiredOfferDXLendingTree");
        final ModifiedXmlEntity entity = updateLendingTreeRequestForNewPrimeUser(emailAddress);
        final String lendingTreeRequest = entity.getRequestBody();
        final HttpResponse dxReferralOfferResponse = creditKarmaWCFService.getLTOffers(lendingTreeRequest);
        LOG.info(emailAddress);
        LOG.info("Dx Lending Tree request is hit  on endpoint");
        final String[] allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), Constants.dxResponse.LENDINGTREEURL);
        Assert.assertNotNull(allURLs);
        PollingUtilities.sleep(2000);
        String DXv2Url = navigateToDxLandingPageFromLTResponse(allURLs, emailAddress);
        LOG.info("DXv2Url  "+DXv2Url);
        final String offersUrlToUseForTesting = DXv2Url.replace("plp/dx-landing-page","personal-loans/pre-approval");
        LOG.info("OffersUrlToUseForTesting ::  "+offersUrlToUseForTesting);

        // Navigate to the DX Landing page
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);

            final String dxUserOfferCode = getDXUserReferralCode(offersUrlToUseForTesting);
            // added delay to have db sync
            PollingUtilities.sleep(1000);
            expireOfferCode(dxUserOfferCode);

            // Now verify that once offercode is expired (after>30 days) then user will navigate to public site home page not on
            // DX landing page.
            final PublicSitePreRegistrationPage preRegPage = dxLandingPage.reloadPageToReturnToPreRegPage();
            Assert.assertTrue(preRegPage.isBorrowerLandingPageDisplayed());
            LOG.info(
                    "PART-638 Lending Tree:Get Offer:user with expired offers navigate to home page on hitting \"ShowSelectedOfferUrl\"");
            LOG.info("~~~~ verifyExpiredOfferDXLendingTreeUserTest--PASSED~~~~~~~~~~~");
        }
    }
}
