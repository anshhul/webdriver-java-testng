
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ProspectResponseCodes;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

import java.io.IOException;

/**
 * Created by rsubramanyam on 4/14/16.
 */
public class BorrowerDXProspectTableTest extends DXCompleteListingTestBase {

    /**
     *
     * BMP-864 Get Offer: Correct \"CreatedDate\" should be displayed under Prospect database. BMP-1133 Get Offer: Correct \
     * "EngagementDate\" should be displayed under Prospect database. BMP-874 Get Offer: Correct \"MiddleInitial\" should be
     * displayed under Prospect database. BMP-882 Get Offer: Correct \"EmploymentStatusId\" should be displayed under Prospect
     * database. BMP-863 Get Offer: Correct \"HTTPResponseCode\" should be displayed under Prospect database. BMP-884 Get Offer:
     * Correct \"EligibilityStatus\" should be displayed under Prospect database. BMP-1208 Get Offer: Correct \"YearlyIncome\"
     * should be displayed under Prospect database. BMP-893 Get Offer: Correct \"StatusCode\" should be displayed under Prospect
     * database. BMP-875 Get Offer: Correct \"LoanAmount\" should be displayed under Prospect database. BMP-876 Get Offer: Correct
     * \"FirstName\" should be displayed under Prospect database. BMP-1045 Get Offer: Correct \"LastName\" should be displayed
     * under Prospect database. BMP-891 Get Offer: Correct \"Zipcode\" should be displayed under Prospect database. BMP-866 Get
     * Offer: Correct \"Address\" should be displayed under Prospect database. PART-134 Get Offer: Correct \"City\" should be
     * displayed under Prospect database. BMP-868 Get Offer: Correct \"State\" should be displayed under Prospect database.
     * BMP-883 Get Offer: Correct \"LoanPurposeId\" should be displayed under Prospect database. BMP-872 Get Offer: Record should
     * not be created under \"UserEmail\" table of circleone database on hitting DX URL.
     *
     * @throws IOException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyProspectTable()
            throws IOException, AutomationException, HttpRequestException {
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyProspectTable");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        PollingUtilities.sleep(3000);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        final String emailAddress = entity.getEmailAddress();
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String DXv2Url = allURLs[0];
        LOG.info("DXv2Url  "+DXv2Url);
        final String offersUrlToUseForTesting = DXv2Url.replace("plp/dx-landing-page","personal-loans/pre-approval");
        LOG.info("offersUrlToUseForTesting:::::  "+offersUrlToUseForTesting);

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
            }
        }

        // Verify Prospect table
        final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(emailAddress);
        final ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        final ProspectResponseCodes codes = prospectInfo.getResponseCodes(emailAddress);
        final String prospectCreatedDate = prospectInfo.getCreatedDate(emailAddress);
        // Verify Prospect table
        PollingUtilities.sleep(4000);
        Assert.assertTrue(prospectCreatedDate
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");
        Assert.assertEquals(codes.getHttpResponseCode(), "200",
                "Eligiblity reason is not correct");

        Assert.assertEquals(prospectInfo.getEligibilityStatus(emailAddress).toString(),
                StringUtils.substringBetween(response.getResponseBody(), "<EligibilityStatus>", "</EligibilityStatus>"));
        LOG.info("BMP-863 Get Offer: Correct \"HTTPResponseCode\" should be displayed under Prospect database.");
        LOG.info("BMP-884 Get Offer: Correct \"EligibilityStatus\" should be displayed under Prospect database.");
        LOG.info("BMP-864 Get Offer: Correct \"CreatedDate\" should be displayed under Prospect database.");
        LOG.info("BMP-876 Get Offer: Correct \"FirstName\" should be displayed under Prospect database.");
        LOG.info("BMP-893 Get Offer: Correct \"StatusCode\" should be displayed under Prospect database.");
        LOG.info("BMP-1045 Get Offer: Correct \"LastName\" should be displayed under Prospect database.");

        Assert.assertTrue(prospectInfo.getEngagementDate(emailAddress)
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
        LOG.info(
                "BMP-877 Correct UserCreditPullID and EngagementDate is stored in prospect table for New user who is getting offers when coming from DX.");
        LOG.info("BMP-874 Get Offer: Correct \"MiddleInitial\" should be displayed under Prospect database.");

        Assert.assertEquals(prospectInfo.getEmployementStatusID(emailAddress),
                Constants.UserEmploymentStatus.borrowerEmployedStatusID);
        Assert.assertEquals(prospectCreated.getEmploymentInfo().getAnnualIncome().toString().replaceAll("\\.0*$", ""),
                getPrimeBorrowerData().get((Constants.RegisterationPageConstants.YEARLYINCOME_TAG)));
        LOG.info("BMP-882 Get Offer: Correct \"EmploymentStatusId\" should be displayed under Prospect database.");
        LOG.info("BMP-1208 Get Offer: Correct \"YearlyIncome\" should be displayed under Prospect database.");

        Assert.assertEquals(prospectCreated.getAddressInfo().getZipCode(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        Assert.assertEquals(prospectCreated.getAddressInfo().getAddress1().toString().trim(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).trim());
        Assert.assertEquals(prospectCreated.getAddressInfo().getCity().toString(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        Assert.assertEquals(prospectCreated.getAddressInfo().getState().toString(),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("BMP-891 Get Offer: Correct \"Zipcode\" should be displayed under Prospect database.");
        LOG.info("BMP-866 Get Offer: Correct \"Address\" should be displayed under Prospect database.");
        LOG.info("BMP-886 Get Offer: Correct \"City\" should be displayed under Prospect database.");
        LOG.info("BMP-868 Get Offer: Correct \"State\" should be displayed under Prospect database.");
        Assert.assertEquals(prospectCreated.getLoanAmount().toString().replaceAll("\\.0*$", ""),
                "5000");
        Assert.assertEquals(Integer.toString(prospectCreated.getLoanPurposeId()),
                StringUtils.substringBetween(entity.getRequestBody(), "<LoanPurposeId>", "</LoanPurposeId>"));
        LOG.info("BMP-875 Get Offer: Correct \"LoanAmount\" should be displayed under Prospect database.");
        LOG.info("BMP-883 Get Offer: Correct \"LoanPurposeId\" should be displayed under Prospect database.");
    }
}
