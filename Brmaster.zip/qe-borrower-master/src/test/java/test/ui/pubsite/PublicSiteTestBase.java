package test.ui.pubsite;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.testng.annotations.BeforeTest;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.platform.interfaces.IPlatformUser;
import test.ui.WebDriverTestBase;
import com.prosper.automation.webdriver.WebDriverConfig;

/**
 * Created by pbudiono on 5/10/16.
 */
public abstract class PublicSiteTestBase extends WebDriverTestBase {

	protected static final String TEST_USER_EMAIL = Constant.getGloballyUniqueEmail();
	protected static final String TEST_USER_PASSWORD = Constant.COMMON_PASSWORD;
	protected static final String INVALID_TEST_USER_PASSWORD = Constant.INVALID_PASSWORD;

	private static final Logger LOG = Logger.getLogger(PublicSiteTestBase.class.getSimpleName());

	@Value("${public.site.scheme}")
	protected String publicSiteUrlScheme;
	@Value("${public.site.url}")
	protected String publicSiteUrl;

	@Resource
	protected WebDriverConfig webDriverConfig;
	@Resource
	protected Map<String, String> pageElements;
	@Resource
	private IPlatformUser pubSiteUserService;

	@BeforeTest
	public void createNewBorrower() throws HttpRequestException, AutomationException {
		LOG.info(String.format("Creating new borrower for %s tests.", this.getClass().getSimpleName()));
		pubSiteUserService.createBorrower(buildGenericUserRequest(TEST_USER_EMAIL));
	}
}
