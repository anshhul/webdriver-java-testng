package test.ui.pubsite.borrower.appByPhone;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja BMP-3957:Existing User with Employment status as Employed:
 *         Correct details should be populated on register page of ABP funnel
 */
public class ABPHappyPathExistingUserTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(ABPHappyPathExistingUserTest.class.getSimpleName());

	private static String ABP_PARTNER_CHANNEL = "Direct Mail";
	@Resource
	private PublicSitePreRegistrationPage modernizePreRegistrationPage;

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] { Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose",
				"homeImprovementListing"), };
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	public void testExistingUserRegistrationPage(String Key, String jiraID, String loanAmount, String loanPurpose,
			String creditQuality, String firstName, String middleInitial, String lastName, String homeAddress,
			String city, String state, String zipCode, String employmentStatus, String yearlyIncome, String dob,
			String emailAddress, String password, String homePhone, String mobilePhone, String workPhone,
			String employerName, String employerPhone, String occupation, String employmentStartDate, String SSN,
			String bankName, String accountType, String accountholderName, String AlternateAccountHolderName,
			String routingNumber, String accountNumber, String confirmAccountNumber, String paymentType)
			throws AutomationException {

		LOG.info("~~~~~~Executing: verifyDTSFunnel~~~~~~~~~~~~~~~");

		password = MessageBundle.getMessage("password");

		final PublicSiteRegistrationPage registrationPage = modernizePreRegistrationPage.checkYourRate();
		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
		// Submit Register page
		registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, password, firstName, lastName,
				homeAddress, city, state, employmentStatus, yearlyIncome, dob);
		registrationPage.clickElectronicSignatureCheckBox();
		registrationPage.clickGetYourRate(false, false);
		// registrationPage.clickOnProsper();
		registrationPage.close();

		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
		// navigate to home page and select default abp partner as direct mail
		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);

		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
		String emailAddress1 = abpRegistrationPage.getEmailAddress();
		String firstName1 = abpRegistrationPage.getFirstName();
		String lastName1 = abpRegistrationPage.getLastName();
		String homeAddress1 = abpRegistrationPage.getHomeAddress();
		String city1 = abpRegistrationPage.getCity();
		String zipCode1 = abpRegistrationPage.getZipCode();
		String yearlyIncome1 = abpRegistrationPage.getYearlyIncome();
		String dateOfBirth = abpRegistrationPage.getDateOfBirth();

		Assert.assertEquals(email, emailAddress1);
		Assert.assertEquals(firstName, firstName1);
		Assert.assertEquals(lastName, lastName1);
		Assert.assertEquals(homeAddress, homeAddress1);
		Assert.assertEquals(city, city1);
		// Assert.assertTrue(zipCode1.contains(zipCode));
		Assert.assertEquals(yearlyIncome, yearlyIncome1);
		Assert.assertEquals(dob, dateOfBirth);

		LOG.info("~~~~~~~Executing: testExistingUserRegistrationPage~~~~~~~~~~~~~~~~~PASSED~~~~~~~~~~~~~~");
		LOG.info(
				"BMP-3957:Existing User with Employment status as Employed:Correct details should be populated on register page of ABP funnel~~~~~~~~~~~~~~~~~~~~~~~PASSED");

	}

}
