package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.MiiCardAtBankInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage.MiiCard;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * GEAR - 1466 Verify funnel flow from 3-step mii-card
 *
 *
 */
public class MiiCard3StepFunctionalityTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(MiiCard3StepFunctionalityTest.class.getSimpleName());

    @Resource
	private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    @Test(groups = {TestGroup.ACCEPTANCE})
	void verifyMiiCard3StepFunctionality() throws AutomationException {
		LOG.info("~~~~~~~~Executing:verifyMiiCard3StepFunctionality~~~~~~~~~~~");

		final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage
                .checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testMiiCard3Steps");

        publicSiteRegistrationPage.fillRegistrationForm(getPrimeBorrowerData()
                .get(Constants.RegisterationPageConstants.ZIPCODE_TAG), Double.toString(LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email, Constant.COMMON_PASSWORD, getPrimeBorrowerData()
								.get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

		publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
        LOG.info("User navigate to Personal detail Page");
        personalDetailPage.fillPersonalDetailPage(
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
		LOG.info("User navigate to TIL Page");
		publicSiteTILAPage.confirmElectronicSignature();
		// User navigated to bank info page
        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
        PollingUtilities.sleep(3000);
		// Navigate to the 3 step mii card
        publicSiteBankAccountInfoPage.showMiiCard(MiiCardAtBankInfoPage.MII_CARD_THREE_STEP);
        Assert.assertTrue(publicSiteBankAccountInfoPage.is3StepMiiCardDisplayed());

		LOG.info("Verify that mii card section is displayed on Bank page");
		final MiiCard miiCard = publicSiteBankAccountInfoPage.goToMiCardPage();

		// selecting bank name to link with the account
        miiCard.selectBankName(Constants.BankInfoPage.MII_CARD_BANK_NAME);

		// entered credentials for bank details
        miiCard.submitLoginForm(Constants.BankInfoPage.MII_CARD_USER_NAME, Constants.BankInfoPage.MII_CARD_PASSWORD);
        final PublicSiteThankYouPage borrowerThankYouPage =
                miiCard.enterMiiCardUserRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));

        // User navigate to Thank you Page and clicked on go to my account button
		LOG.info("User navigate to Thank you  Page");
		borrowerThankYouPage.clickGoToMyAccountPage();
		LOG.info("~~~~GEAR - 1466 Verify funnel flow from 3-step mii-card~~~~");
	}
}
