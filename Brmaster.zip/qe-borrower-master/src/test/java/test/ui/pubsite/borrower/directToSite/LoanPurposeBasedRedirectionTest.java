
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.DeclinedPartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOffersDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 24-Aug-2016
 *
 */
public class LoanPurposeBasedRedirectionTest extends PartnerLandingPageTestBase {

    // AUTO-291, Updated loan purpose redirection for the User
    /*
     * @DataProvider(name = "testRedirection") public static Object[][] redirectionTest() { return new Object[][] {
     * {LoanPurpose.Business, RedirectionPath.ONDECK, CREDIT_QUALITY}, {LoanPurpose.Business, RedirectionPath.ONDECK,
     * POOR_CREDIT_QUALITY}, {LoanPurpose.Auto, RedirectionPath.AMONE, CREDIT_QUALITY}, {LoanPurpose.LargePurchase,
     * RedirectionPath.AMONE, CREDIT_QUALITY}, {LoanPurpose.BabyAndAdoption, RedirectionPath.AMONE, CREDIT_QUALITY},
     * {LoanPurpose.HouseholdExpense, RedirectionPath.AMONE, CREDIT_QUALITY}, {LoanPurpose.Other, RedirectionPath.AMONE,
     * CREDIT_QUALITY}, {LoanPurpose.SpecialOcassion, RedirectionPath.AMONE, CREDIT_QUALITY}, {LoanPurpose.Taxes,
     * RedirectionPath.AMONE, CREDIT_QUALITY}, {LoanPurpose.Vacation, RedirectionPath.AMONE, CREDIT_QUALITY},
     * {LoanPurpose.DebtConsolidation, RedirectionPath.PROSPER, CREDIT_QUALITY}, {LoanPurpose.HomeImprovement,
     * RedirectionPath.PROSPER, CREDIT_QUALITY}, {LoanPurpose.Medical, RedirectionPath.PROSPER, CREDIT_QUALITY}
     *
     * }; }
     */
    // GEAR-1226 Verify that user is navigated to OnDeck decline page for Business loan purpose.
    @Test(groups = {TestGroup.NIGHTLY})
    public void testRedirectionForLoanPurpose()
            throws AutomationException, HttpRequestException {
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("classpath:public_site/spring/public_site_context.xml");
        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");

        completeListing(publicSitePreRegistrationPage, getCommonTestData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG),
                false);
    }

    // Since Pre-reg has only check rate button bellow test is deprecated,GEAR-1871
    @Deprecated
    @Test(dataProvider = "testRedirection", groups = {TestGroup.ACCEPTANCE}, enabled = false)
    public void testRedirectionForLoanPurposeForPreRegistration()
            throws AutomationException, HttpRequestException {
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("classpath:public_site/spring/public_site_context.xml");
        jobContext.getBean("publicSitePreRegistrationLandingPage");
    }

    private void completeListing(PublicSitePreRegistrationPage modernizePreRegistrationPage, String creditQuality,
                                 boolean isPreRegLandingPage)
            throws AutomationException {
        // Loan Purpose available on Prosper in current state:
        final ArrayList<String> loanPurposeOptions = new ArrayList<String>(
                Arrays.asList("Business", "Debt Consolidation", "Home Improvement", "Medical / Dental",
                        "Large Purchase", "Household Expenses", "Auto / Motorcycle / RV / Boat", "Special Occasion", "Vacation",
                        "Taxes", "Baby & Adoption", "Other"));
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testRedirectionForLoanPurpose");
        for (final String loanPurpose : loanPurposeOptions) {
            PublicSiteRegistrationPage publicSiteRegistrationPage = null;
            if (loanPurpose.toString().equals("Business")) {
                final PublicSiteRegistrationPage registrationPage =
                        modernizePreRegistrationPage.submitBorrowerWidget(Constant.GENERIC_LOAN_AMOUNT, loanPurpose,
                                creditQuality, isPreRegLandingPage);
                Assert.assertNotNull(registrationPage);
                if (registrationPage.isEmailAddressFieldEditable()) {
                    registrationPage.fillRegistrationForm(
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                            String.valueOf(Constant.GENERIC_LOAN_AMOUNT),
                            loanPurpose, email, Constant.COMMON_PASSWORD,
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG), null, "Employed",
                            String.valueOf(Constant.TEST_ANNUAL_INCOME),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
                    registrationPage.clickElectronicSignatureCheckBox();
                } else {
                    registrationPage.clickElectronicSignatureCheckBox();
                }
                final PublicSiteOffersDeclinePage declinePage = registrationPage.clickToGoToOffersDeclinePage();
                final DeclinedPartnerLandingPage partnerPage = declinePage.clickToGoToDeclinedPartnerLandingPage("get-started");
                declinePage.switchToNewlyOpenedWindow();
                Assert.assertTrue(partnerPage.getWindowLocationHref().contains("www.ondeck.com"));
                LOG.info("GEAR-1226 Verify that user is navigated to OnDeck decline page for Business loan purpose.");
                partnerPage.closeAllButOneBrowser();
                declinePage.clickOnProsperLogo();
            } else {
                if (!isPreRegLandingPage) {
                    if (modernizePreRegistrationPage.isStaticTextDisplayed("Start")) {
                        modernizePreRegistrationPage.clickOnStartAnApplication();
                    }
                    else {
                        publicSiteRegistrationPage =
                            modernizePreRegistrationPage.checkYourRate();
                    }
                } else {
                    publicSiteRegistrationPage =
                            modernizePreRegistrationPage.submitBorrowerWidgetFromPreRegPage(Constant.GENERIC_LOAN_AMOUNT,
                                    loanPurpose, creditQuality);
                }

                if (publicSiteRegistrationPage.isEmailAddressFieldEditable()) {
                    publicSiteRegistrationPage.fillRegistrationForm(
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                            String.valueOf(Constant.GENERIC_LOAN_AMOUNT),
                            loanPurpose, email, Constant.COMMON_PASSWORD,
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG), null, "Employed",
                            String.valueOf(Constant.TEST_ANNUAL_INCOME),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
                    publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
                } else {
                    publicSiteRegistrationPage.selectLoanPurpose(loanPurpose);
                    publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
                }

                final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
                final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
                // Verify new Personal detail Header text
                if (personalDetailsPage.getWorkPhone().isEmpty()) {
                personalDetailsPage.fillPersonalDetailPage(
                        getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                        getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
                }
                final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();
                if (!tilaPage.isTilaPrintVersionDisplayed()) {
                    tilaPage.navigateToOldTILAPage();
                    PollingUtilities.sleep(2000);
                    tilaPage.waitForTILAPage();
                    Assert.assertTrue(tilaPage.getTilLoanPurposerHeader().contains(loanPurpose));
                    LOG.info("User ListingId " + tilaPage.getListingIdFromTILAContent() + " with loan Purpose " + loanPurpose);
                }
                final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = tilaPage.clickOnProsperLogo();
                Assert.assertNotNull(publicSitePreRegistrationAgainPage);
            }
        }
    }
}
