
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja
 *
 */
public class ABPRegisterPageTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";

    protected static final Logger LOG = Logger.getLogger(ABPRegisterPageTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testRegisterPageAppearance() throws AutomationException {

        LOG.info("~~~~~~~Executing: testRegisterPageAppearance~~~~~~~~~~~~~~");
        // login to support site
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
            LOG.info("ABP User email is " + email);
            supportSiteMainPage.enterEmailAddress(email);

            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

            Assert.assertTrue(abpRegistrationPage.isEmailDisplayedAtTop(), "Email is displayed at top");
            LOG.info("BMP-2524 Verify that Email text field is displayed on top of all text fields on registration page");

            Assert.assertTrue(abpRegistrationPage.verifyCreditDisclosureText());
            Assert.assertTrue(abpRegistrationPage.verifyIncomeDisclosure());
            LOG.info("BMP-2573 Income disclosure: Correct content should be for Income disclosure on Register page");

            Assert.assertTrue(abpRegistrationPage.verifyPhoneNumberDisclosure());
            LOG.info("BMP-2481 Phone number disclosure: Correct content should be for Phone number disclosure on Register page");

            Assert.assertTrue(abpRegistrationPage.verifySuffixDropdownOptions());
            LOG.info("BMP-2476 Suffix: Verify that correct options should be displayed under \"Suffix\" drop-down.");

            Assert.assertTrue(abpRegistrationPage.verifyStateDropdownOptions());
            LOG.info("BMP-2513 State: Verify that correct options should be displayed under \"State\" drop-down.");

            Assert.assertTrue(abpRegistrationPage.verifyEmploymentStatusDropDownOptions());
            LOG.info(
                    "BMP-2502 Employment Status: Verify that correct options should be displayed under \"Employment status\" drop-down.");

            Assert.assertTrue(abpRegistrationPage.verifyLoanPurposeDropDownOptions());
            LOG.info("BMP-2535 Loan Purpose: Verify that correct options should be displayed under \"Loan Purpose\" drop-down.");

            abpRegistrationPage.selectState("AA");
            Assert.assertTrue(abpRegistrationPage.verifyStateOfResidenceDisplayed("AA"));
            abpRegistrationPage.reload();

            abpRegistrationPage.selectState("AE");
            Assert.assertTrue(abpRegistrationPage.verifyStateOfResidenceDisplayed("AE"));
            abpRegistrationPage.reload();

            abpRegistrationPage.selectState("AP");
            Assert.assertTrue(abpRegistrationPage.verifyStateOfResidenceDisplayed("AP"));
            abpRegistrationPage.reload();
            LOG.info(
                    "BMP-2561 \"State of Residence\" drop down field should be displayed on selecting \"AA/AE/AP\" states from \"Register\" page.");
        }
    }

    @DataProvider(name = "validUser")
    public static Object[][] validUserData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "ABPRegisterPage", "validUser"),
        };
    }

    @Test(dataProvider = "validUser")
    public void testRegisterPageInDB(String key, String loanAmount, String loanPurpose, String firstName, String lastName,
                                     String middleInitial, String suffix, String homeAddress, String city, String state,
                                     String zipCode, String primaryPhone,
                                     String secondaryPhone, String employmentStatus, String yearlyIncome, String dob)
            throws AutomationException {

        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        /*
         * resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
         * supportSiteMainPage.enterOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
         */
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
        LOG.info("ABP User email is " + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

        abpRegistrationPage.enterFirstName(firstName);
        LOG.info("CSA Enter first name of the borrower");

        abpRegistrationPage.enterLastName(lastName);
        LOG.info("CSA Enter Last name of the borrower");

        abpRegistrationPage.enterCity(city);
        LOG.info("CSA Enter City of the borrower");

        abpRegistrationPage.selectState(state);
        LOG.info("CSA Enter State of the borrower");

        abpRegistrationPage.enterZipCode(zipCode);
        LOG.info("CSA Enter zipcode of the borrower");

        abpRegistrationPage.enterMiddleName(middleInitial);
        LOG.info("CSA Enter Middle name of the borrower");

        abpRegistrationPage.selectSuffix(suffix);
        LOG.info("CSA Enter suffix of the borrower");

        abpRegistrationPage.enterHomeAddress(homeAddress);
        LOG.info("CSA Enter home address of the borrower");

        // navigate to ABP Registration Page
        abpRegistrationPage.selectEmploymentStatus(employmentStatus);
        LOG.info("CSA user select employment status of borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(yearlyIncome);
        LOG.info("CSA user entered the yearlyincome of borrower");
        abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                dob);
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(primaryPhone);
        abpRegistrationPage.enterSecondaryPhone(secondaryPhone);

        abpRegistrationPage.enterLoanAmount(loanAmount);
        LOG.info("CSA user entered the loanamount for borrower");

        abpRegistrationPage.selectLoanPurposer(loanPurpose);
        LOG.info("CSA user select loan purpose for borrower");

        final String LoanPurposeID = abpRegistrationPage.getLoanPurposeId(loanPurpose);
        LOG.info("CSA user select loan purpose Id for borrower");

        abpRegistrationPage.clickGetYourRate();

        final List<Map<String, Object>> prospectInfo =
                queryCircleOne(String.format(MessageBundle.getMessage("prospectTableQuery"), email));

        Assert.assertTrue(prospectInfo.get(0).get("FirstName").toString().equalsIgnoreCase(firstName),
                "Correct First Name should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("LastName").toString().equalsIgnoreCase(lastName),
                "Correct Last Name should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("MiddleInitial").toString().equalsIgnoreCase(middleInitial),
                "Correct Middle Initial should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("Address").toString().equalsIgnoreCase(homeAddress),
                "Correct Address should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("City").toString().equalsIgnoreCase(city), "Correct City should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("State").toString().equalsIgnoreCase(state), "Correct State should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("Zipcode").toString().equalsIgnoreCase(zipCode),
                "Correct Zip code should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("LoanAmount").toString().contains(loanAmount),
                "Correct Loan Amount should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("LoanPurposeId").toString().contains(LoanPurposeID),
                "Correct Loan purpose should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("YearlyIncome").toString().replaceAll("[^\\d]", "").contains(yearlyIncome),
                "Correct Yearly Income should be stored");
        Assert.assertTrue(prospectInfo.get(0).get("EmailAddress").toString().equals(email),
                "Correct Email Address should be stored");
        LOG.info("BMP-2480 Correct details provided on \"Register page\" should be stored in DB.");
    }

    @DataProvider(name = "invalidState")
    public static Object[][] invalidStateUserData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "ABPRegisterPage", "IAUser"),
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "ABPRegisterPage", "MEUser"),
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "ABPRegisterPage", "NDUser")
        };
    }

    @Test(dataProvider = "invalidState")
    public void verifyNonBorrowingState(String key, String loanAmount, String loanPurpose, String firstName, String lastName,
                                        String middleInitial, String suffix, String homeAddress, String city, String state,
                                        String zipCode, String primaryPhone,
                                        String secondaryPhone, String employmentStatus, String yearlyIncome, String dob)
            throws AutomationException {

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
            LOG.info("ABP User email is " + email);
            supportSiteMainPage.enterEmailAddress(email);

            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

            abpRegistrationPage.enterFirstName(firstName);
            LOG.info("CSA Enter first name of the borrower");

            abpRegistrationPage.enterLastName(lastName);
            LOG.info("CSA Enter Last name of the borrower");

            abpRegistrationPage.enterCity(city);
            LOG.info("CSA Enter City of the borrower");

            abpRegistrationPage.selectState(state);
            LOG.info("CSA Enter State of the borrower");

            abpRegistrationPage.enterZipCode(zipCode);
            LOG.info("CSA Enter zipcode of the borrower");

            abpRegistrationPage.enterMiddleName(middleInitial);
            LOG.info("CSA Enter Middle name of the borrower");

            abpRegistrationPage.selectSuffix(suffix);
            LOG.info("CSA Enter suffix of the borrower");

            abpRegistrationPage.enterHomeAddress(homeAddress);
            LOG.info("CSA Enter home address of the borrower");

            // navigate to ABP Registration Page
            abpRegistrationPage.selectEmploymentStatus(employmentStatus);
            LOG.info("CSA user select employment status of borrower");

            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(yearlyIncome);
            LOG.info("CSA user entered the yearlyincome of borrower");
            abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                    dob);
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(primaryPhone);
            abpRegistrationPage.enterSecondaryPhone(secondaryPhone);

            abpRegistrationPage.enterLoanAmount(loanAmount);
            LOG.info("CSA user entered the loanamount for borrower");

            abpRegistrationPage.selectLoanPurposer(loanPurpose);
            LOG.info("CSA user select loan purpose for borrower");

            abpRegistrationPage.clickGetYourRate();
            Assert.assertTrue(abpRegistrationPage.getInvalidStateMessage()
                    .contains(MessageBundle.getMessage("notAvailableInYourStateRestrictionMessage")));
            LOG.info("BMP-1550  State: User should be restricted on selecting non-borrowing state (IA, ME, ND).");
        }
    }

}
