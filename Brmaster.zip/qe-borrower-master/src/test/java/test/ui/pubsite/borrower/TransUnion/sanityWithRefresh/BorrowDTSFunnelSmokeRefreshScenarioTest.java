
package test.ui.pubsite.borrower.TransUnion.sanityWithRefresh;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.UserCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.annotation.Resource;

import java.util.List;
import java.util.Map;

/**
 * BMP-527 Verify that new user is able to complete DTS funnel
 *
 * Created by rsubramanyam on 5/10/16.
 */
public class BorrowDTSFunnelSmokeRefreshScenarioTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowDTSFunnelSmokeRefreshScenarioTest.class.getSimpleName());

    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // Note: AUTO-183 - DTS funnel (with moved fields) with miicard bank page
    @Test(groups = {TestGroup.SANITY})
    public void verifyDTSFunnel()
            throws AutomationException {

        LOG.info("~~~~~~Executing: verifyDTSFunnel~~~~~~~~~~~~~~~");
        final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

        publicSiteRegistrationPage.reload();
        publicSiteRegistrationPage.waitForRegistrationFormToDisplayed();
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        publicSiteOfferPage.reload();
        publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        personalDetailsPage.reload();
        personalDetailsPage.waitForPersonalDetailsPage();
        // Verify new Personal detail Header text

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
        tilPage.reload();
        tilPage.waitForTILAPage();
        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        publicSiteBankAccountInfoPage.reload();
        publicSiteBankAccountInfoPage.waitForBankPageToLoadCompletely();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        Assert.assertNotNull(accountOverviewPage);
        final List<Map<String, Object>> listingInfo = queryCircleOne(MessageBundle.getMessage("listingsTable") + listingID);

        Assert.assertEquals(listingInfo.get(0).get("BRERuleVersion").toString(), Constants.BRE_RULE_VERSION);
        if (accountOverviewPage.getWindowLocationHref().contains("signin")) {
            accountOverviewPage.close();
            // Log into the Public site with user created above
            try (final ClassPathXmlApplicationContext jobContext =
                    new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {
                final PublicSiteSignInPage publicSiteSignInPage =
                        (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
                final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
                // Verify that New Account overview page is displayed on sign in
                overviewPageAgain
                        .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                overviewPageAgain.dismissCongratulationWelcomeModal();
                Assert.assertNotNull(overviewPageAgain.getListingDetail(), "Account Overview page should be displayed");
            }
        }
        final String listingId = accountOverviewPage.getListingInfo().get("LISTING ID");
        LOG.info("Borrower from DTS funnel is able to complete listing" + listingId);
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        Assert.assertNotNull(accountOverviewPage);

        final List<Map<String, Object>> lendingAccreditationRecord =
                queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
        Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

        final List<Map<String, Object>> agreementRecord =
                queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
        Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
        Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
        /*
         * For row having CreditBureau=1 validate following: IsDecisionBureau should be "0". ExternalCreditReportId for
         * CreditBureau=1 should be = Select ExternalCreditReportId from Circleone..ExperianDocuments where UserID = <userid> and
         * documentType='Response Credit Profile'
         */

        final UserCreditProfilesDAO creditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
        // final UserCreditReportMappingModel creditReportMappingModel =
        // creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 1);
        //
        // // verify IsDecisionBureau is false:
        // Assert.assertEquals(creditReportMappingModel.isIsDecisionBureau(), "0");
        //
        // final ExperianDocumentDAO experianDocumentDAO = circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);
        // // verify externalCreditReportId
        // Assert.assertEquals(experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)),
        // creditReportMappingModel.getExternalCreditReportId());

        /*
         * For row having CreditBureau=2 validate following: ExternalCreditReportId should not be null. IsDecisionBureau should be
         * "1".
         */
        final UserCreditReportMappingModel creditReportMappingModelTu =
                creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 2);
        // verify IsDecisionBureau is false:
        Assert.assertEquals(creditReportMappingModelTu.isIsDecisionBureau(), "1");

        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);

        /*
         * For row having CreditBureau=1 validate following: IsDecisionBureau should be "0". ExternalCreditReportId should be =
         * Select ExternalCreditReportId from Circleone..ExperianDocuments where UserID = <userid> and documentType='Response
         * Credit Profile'
         */
        // final ListingCreditReportMappingModel listingCreditReportMappingModel =
        // listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 1);
        // // verify ExternalCreditReportId in tbl ListingCreditReportMapping
        // Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
        // experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
        // // verify IsDecisionBureau is false:
        // Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(), "0");

        /*
         * For row having CreditBureau=2 validate following: ExternalCreditReportId should be = Select ExternalCreditReportId from
         * Circleone..UserCreditReportMapping where UserID = <UserID> and CreditBureau=2 IsDecisionBureau should be "1".
         */
        final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 2);

        // verify IsDecisionBureau is false:
        Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

        // verify ExternalCreditReportId in tbl ListingCreditReportMapping
        Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
                creditReportMappingModelTu.getExternalCreditReportId());

        final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
        // verify ExternalModelReportId for TransUnion enabled
        Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
        LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
        // verify ExternalModelReportId for Experian enabled
        final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
        Assert.assertEquals(externalModelReportIdEx, null);

        // Temporary created Transunion DB object
        final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
        final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
        LOG.info("modelReportId is:" + modelReportId);
        Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));

        Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));

        Assert.assertEquals(listingInfo.get(0).get("BRERuleVersion").toString(), Constants.BRE_RULE_VERSION);
        LOG.info("~~~~~~Executing:~~~~~~BMP-5497~~~~~~");
        final String listingforPMI= listingsDAO.getListingIdForPMI(listingId);
        Assert.assertNull(listingforPMI);
    }
}
