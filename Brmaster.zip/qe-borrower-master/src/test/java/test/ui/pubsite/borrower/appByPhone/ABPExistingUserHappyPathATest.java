
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-451 Existing user with loan Path A:User should be able to complete the funel from Public site.
 *
 * @author jdoriya 16-May-2016
 *
 */
public class ABPExistingUserHappyPathATest extends PartnerLandingPageTestBase {

    private static final String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPExistingUserHappyPathATest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // BMP-3944 Existing user with loan: User should be able to submit Register
    // page.
    // BMP-3962 Existing user with loan who creates new listing from aBP. should
    // be able to submit Loan offers page.
    // BMP-3964 Existing user with loan : SSN field should be displayed
    // uneditable on Personal Details page.
    // BMP-3935 Existing user with loan Path A:User should be navigated to Enter
    // Your password page from Password creation mail of
    // Path A should be triggered to borrower .
    // BMP-3966 Existing user with loan Path A:User should be navigated to
    // Registration page on submiiting Enter Your password
    // page with correct password.
    // BMP-3939 Existing User: Verify that Start Employment Month in prospect
    // table of prospect db updates for the user
    // BMP-3958 Existing User: Verify that Start Employment Year in prospect
    // table of prospect db updates for the user
    // BMP-3954 Existing User: Verify that Employer Phone in prospect table of
    // prospect db updates for the user
    // BMP-3956 Existing User: Verify that Employer Name in prospect table of
    // prospect db updates for the user
    // BMP-3948 Existing User: Verify that Home Phone in prospect table of
    // prospect db updates for the user
    // BMP-3961 Existing User: Verify that Mobile Phone in prospect table of
    // prospect db updates for the user
    // BMP-3969 Existing User: Verify that Work Phone in prospect table of
    // prospect db updates for the user
    // BMP-3981 Existing User: Verify that Occupation in prospect table of
    // prospect db updates for the user
    // BMP-3975 Existing User: Verify that Account Holder in prospect table of
    // prospect db updates for the user
    // BMP-3974 Existing User: Verify that Employment Status in prospect table
    // of prospect db updates under new prospect created
    // for the user
    // BMP-3973 Existing User: Verify that Yearly Income in prospect table of
    // prospect db updates under new prospect created for
    // the user
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserHappyPathA() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testExistingUserHappyPathA~~~~~~~~~~~~~~~~~~~~");
        final String email = getUserForEnvironment("testExistingUserHappyPathA");
        String urlFromWeb = null;
        List<Map<String, Object>> prospectInfo = null;
        // login to support site
        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
                    .getBean("supportSiteLandingPage");

            supportSiteLandingPage.deleteAllCookies();
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            // Clean Existing User for new listing creation
            final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            final List<Map<String, Object>> listings = circleOneDBConnection
                    .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
            listings.get(0).get("id").toString();
            listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);

            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            LOG.info("BMP-3944 Existing user with loan: User should be able to submit Register page.");
            final String referralCode = abpOfferPage.getReferalCode();

            // Verify the values displayed in table Prospect
            // verify prospect details for the user
            prospectInfo = queryCircleOne(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
            final List<Map<String, Object>> prospectDisclosuresTable =
                    queryCircleOne(String.format(
                            MessageBundle.getMessage("prospectDisclosureQuery"),
                            prospectInfo.get(0).get("ProspectID").toString()));

            Assert.assertTrue(prospectDisclosuresTable.get(0).get("DisclosureID").toString().equals("1500"),
                    "DisclosureID = 1500 should be stored");
            Assert.assertTrue(prospectDisclosuresTable.get(1).get("DisclosureID").toString().equals("1501"),
                    "DisclosureID = 1501 should be stored");
            Assert.assertTrue(prospectDisclosuresTable.get(2).get("DisclosureID").toString().equals("1502"),
                    "DisclosureID = 1502 should be stored");
            LOG.info(
                    "BMP-3942 Standard: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect table in prospect db");
            LOG.info(
                    "BMP-3946 Standard: Verify that correct Phone Disclosure ID is displayed in Disclosure column of Prospect table in prospect db");
            LOG.info(
                    "BMP-3934 Standard: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of Prospect table in prospect db");

            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            urlFromWeb=abpPersonalDetailPage.getABPPathAUrl(referralCode);

            LOG.info(
                    "BMP-3962 Existing user with loan who creates new listing from aBP. should be able to submit Loan offers page.");
            Assert.assertTrue(abpPersonalDetailPage.isSSNDisabled());
            LOG.info(
                    "BMP-3964 Existing user with loan : SSN field should be displayed uneditable on Personal Details page.");
            // csa is submitting personal detail for prior borrower
            abpPersonalDetailPage.fillPersonalDetailsForPriorBorrower(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // enter bank details
            Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
            /*
             * abpBankInfoPage.fillBankInfoForPriorBorrower(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
             */
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);

            // Verify abp mail box and retrieve the finish request url for borrower


            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
            LOG.info(
                    "BMP-3988 Existing user with loan: Password creation mail of Path A should be triggered to borrower on submitting bank Info page.");
        }
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
                webDriverConfig, URLUtilities.getScheme(urlFromWeb),
                URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);
            LOG.info(
                    "BMP-3935 Existing user with loan Path A:User should be navigated to Enter Your password page from Password creation mail of Path A should be triggered to borrower .");
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            Assert.assertNotNull(prospectInfo.get(0).get("AgentID").toString(), "Agent Id should not be null");
            LOG.info(
                    "BMP-3960 Standard: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");

            LOG.info(prospectInfo.get(0).get("OfferUserID").toString());
            Assert.assertNotNull(prospectInfo.get(0).get("OfferUserID"), "Loan Offer ID should be not null");
            LOG.info(
                    "BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of Prospect table in prospect db");

            final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(urlFromWeb);
            // Assert.assertTrue(publicSiteRegistrationPage.isRegisterPageDisplayed());
            LOG.info(
                    "BMP-3966 Existing user with loan Path A:User should be navigated to Registration page on submiiting Enter Your password page with correct password.");
            LOG.info("User landed on Landing Page and start new listing");
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            Assert.assertNotNull(personalDetailPage);
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));

            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            final String expectedOccupationID = personalDetailPage
                    .GetOccupationId(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

            final PublicSiteTruthInLendingDisclosurePage truthInLendingDisclosurePage = personalDetailPage
                    .clickContinue();

            truthInLendingDisclosurePage.confirmElectronicSignature();
            final String ListingID = truthInLendingDisclosurePage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = truthInLendingDisclosurePage
                    .clickContinue();

            Assert.assertNotNull(publicSiteBankAccountInfoPage);
            final PublicSiteThankYouPage publicSiteThankYouPage =publicSiteBankAccountInfoPage.clickFinish();


            		/*publicSiteBankAccountInfoPage
                    .clearAndEnterBankInfoForExistingUser(
                            getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));*/
            publicSiteThankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing

            // verify prospect details for the user
            prospectInfo = queryCircleOne(
                    String.format(MessageBundle.getMessage("prospectTableQuery"), email));

            final String startOfEmploymentYear = prospectInfo.get(0).get("EmploymentYear").toString();
            final String startofEmploymentMonth = prospectInfo.get(0).get("EmploymentMonth").toString();
            final String employerName = prospectInfo.get(0).get("EmployerName").toString();
            final String employerPhoneNumber = prospectInfo.get(0).get("EmployerPhoneNumber").toString();
            final String homePhoneNumber = prospectInfo.get(0).get("HomePhoneNumber").toString();
            final String mobilePhoneNumber = prospectInfo.get(0).get("MobilePhoneNumber").toString();
            final String workPhoneNumber = prospectInfo.get(0).get("WorkPhoneNumber").toString();
            final String accountHolderName = prospectInfo.get(0).get("FirstAccountHolderName").toString();
            final String employmentStatusId = prospectInfo.get(0).get("EmploymentStatusId").toString();
            final String yearlyIncome = prospectInfo.get(0).get("YearlyIncome").toString();
            final String occupationId = prospectInfo.get(0).get("OccupationId").toString();
            Assert.assertTrue(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG)
                    .contains(startOfEmploymentYear));
            Assert.assertTrue(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG)
                    .contains(startofEmploymentMonth));
            Assert.assertTrue(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG).contains(employerName));
            Assert.assertTrue(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG)
                    .contains(employerPhoneNumber));
            Assert.assertTrue(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG)
                    .contains(mobilePhoneNumber));
            Assert.assertTrue(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG).contains(homePhoneNumber));
            Assert.assertTrue(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG).contains(workPhoneNumber));
            Assert.assertTrue(occupationId.equalsIgnoreCase(expectedOccupationID));
            Assert.assertTrue(accountHolderName
                    .contains(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG)));
            Assert.assertTrue(employmentStatusId.equalsIgnoreCase("7"));
            Assert.assertTrue(yearlyIncome
                    .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG)));

            LOG.info(
                    "BMP-3958 Existing User: Verify that Start Employment Year in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3939 Existing User: Verify that Start Employment Month in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3954 Existing User: Verify that Employer Phone in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3956 Existing User: Verify that Employer Name in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3948 Existing User: Verify that Home Phone in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3961 Existing User: Verify that Mobile Phone in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3969 Existing User: Verify that Work Phone in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3981 Existing User: Verify that Occupation in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3975 Existing User: Verify that Account Holder in prospect table of prospect db updates for the user");
            LOG.info(
                    "BMP-3974 Existing User: Verify that Employment Status in prospect table of prospect db updates under new prospect created for the user");
            LOG.info(
                    "BMP-3973 Existing User: Verify that Yearly Income in prospect table of prospect db updates under new prospect created for the user");
            LOG.info("ABP Path A Prior Borrower ListingID is:" + ListingID);
        }
        LOG.info("~~~~~~~~~ testExistingUserHappyPathA--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

    // BMP-3970 Existing user with loan: Correct Pricing should be offered to
    // the existing user with loan user who creates new listing from aBP
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserHappyPathAPWorkflow() throws AutomationException {

        LOG.info("~~~~~~~~~Executing: testExistingUserHappyPathAPWorkflow~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
                .getBean("supportSiteLandingPage");

        supportSiteLandingPage.deleteAllCookies();
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);
        final String email = getUserForEnvironment("testExistingUserHappyPathA");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        final String listingId = listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);

        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage
                .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        abpRegistrationPage.clickGetYourRate();
        final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}", listingId));
        Assert.assertNotNull(loanOfferScoreDetails.get(1).get("Value").toString(),
                "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to ABP user via DM Channel");
        LOG.info(
                "BMP-3970 Existing user with loan: Correct Standard Pricing should be offered to the existing user with loan user who creates new listing from aBP");
        LOG.info("~~~~~~~~~ testExistingUserHappyPathAPWorkflow--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

}
