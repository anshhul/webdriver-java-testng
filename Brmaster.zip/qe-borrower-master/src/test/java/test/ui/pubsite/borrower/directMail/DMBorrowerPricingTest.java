
package test.ui.pubsite.borrower.directMail;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.List;
import java.util.Map;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * verify DM Pricing for borrower coming via DM pages with valid/invalid/blank offercodes
 *
 *
 * BMP-528 verify pricing with invalid offercode BMP-529 verify dm pricing with blank offercode BMP-530 verify pricing with valid
 * offercode
 *
 * @author jdoriya
 */
public class DMBorrowerPricingTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerPricingTest.class.getSimpleName());


    // verify pricing with invalid offercode as "####" publicSiteUrlScheme, publicSiteUrl + HOME_PLUS_PAGE
    // GEAR-1601 Verify that banner does not appear on DM reg page coming from invalid offer-code
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDMPricingWithInvalidOfferCode() throws AutomationException {
        LOG.info("Executing: testDMPricingWithInvalidOfferCode");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with invalid OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                    "#####");

            // dm offer dialog box will be displayed
            Assert.assertTrue(partnerLandingPage.getDMOfferValidationDialogAsElement().size() == 1);

            // dm offer dialog header content
            Assert.assertEquals(partnerLandingPage.getDMOfferDialogHeader(), Constants.PartnerLandingPage.DMOFFERDIALOGHEADER);

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithInvalidOfferCode");
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                Assert.assertTrue(publicSiteRegistrationPage.getNumberOfPanes() > 0,
                        "NEW REGISTRAION PAGE IS DISPLAYED TO DM USER");
            }
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            // verify the tblLoanofferScore for pricing
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            // verify qp reduce pricing as || corresponding to variableID(73)
            Assert.assertTrue(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
        }
    }

    // verify dm pricing with blank offercode
    // GEAR-1603 Verify that banner does not appear on DM reg page coming from no offer-code
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDMPricingWithBlankOfferCode() throws AutomationException {
        LOG.info("Executing: testDMPricingWithBlankOfferCode");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with User's OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG), "");

            // dm offer dialog box will be displayed
            Assert.assertTrue(partnerLandingPage.getDMOfferValidationDialogAsElement().size() == 1);

            // dm offer dialog header content
            Assert.assertEquals(partnerLandingPage.getDMOfferDialogHeader(), Constants.PartnerLandingPage.DMOFFERDIALOGHEADER);

            // click on continue anyway for prospect
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDMPricingWithBlankOfferCode");
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                Assert.assertTrue(publicSiteRegistrationPage.getNumberOfPanes() > 0,
                        "NEW REGISTRAION PAGE IS DISPLAYED TO DM USER");
            }
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    RandomStringUtils.random(5, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            // verify the tblLoanofferScore for pricing
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}", listingID));
            // verify qp reduce pricing as || corresponding to variableID(73)
            Assert.assertTrue(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
        }
    }

    // BMP-530 verify pricing with valid offercode
    // GEAR-1604 Verify that banner appears on DM reg page coming from valid offer-code
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDMPricingWithValidOfferCode() throws AutomationException {
        LOG.info("Executing: testDMPricingWithValidOfferCode");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            // submit DM Landing Page with User's OfferCode
            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
            final String offerCode = getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG);
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

            /* enter borrower registration details */
            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDmWithValidOffercode");
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(email);
            LOG.info("User email addresss is:" + email);
            /*
             * publicSiteRegistrationPage
             * .enter5digitZipCode(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG)); if
             * (publicSiteRegistrationPage.getNumberOfPanes() > 0) { LOG.info("New Registration page is displayed...");
             * publicSiteRegistrationPage.enterLoanAmount(LOAN_AMOUNT);
             * publicSiteRegistrationPage.selectLoanPurpose(getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
             *
             * }
             */
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");

            // verify the prospect tbl records
            final Map<String, Object> prospectRows = queryProspectDb(
                    MessageBundle.getMessage("prospectOfferCodeQuery").replace("{offerCode}", offerCode)).get(0);

            // Prospect records shouldnot be null
            Assert.assertFalse(prospectRows.isEmpty(), "Prospect is not generated yet");
            LOG.info("Prospect is generated into prospecttbl for prospect user");

            // verify engagementdate of prospect
            Assert.assertTrue(prospectRows.get("EngagementDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                    "Correct 'CreatedDate' should be displayed");

            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            // verify userid of prospect
            Preconditions.checkNotNull(prospectRows.get("UserId"), "Userid is null in prospecttbl");
            Preconditions.checkNotNull(userId, "Userid is null in UserEmails");
            Assert.assertTrue(prospectRows.get("UserId").toString().contains(userId),
                    "Correct 'userId' should be displayed");
            // Submit the general personal details
            personalDetailPage.enterPrimaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage.enterSecondaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage.enterEmployerName(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage.enterEmployerPhone(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage.selectOccupation(getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            final String offerCodeInProspecttbl = prospectCreated.getOfferCode();

            // User navigate to Account Overview Page and observed the listing
            LOG.info("DM Borrower ListingID is:" + listingID);
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            final Map<String, Object> varID73 = loanOfferScoreDetails.get(1);
            final Map<String, Object> varID515 = loanOfferScoreDetails.get(2);

            Assert.assertEquals(varID38.get("Value").toString(),
                    getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG),
                    "var 38 value should be same as offer code provided");
            final String var_73_actualValue = varID73.get("Value").toString();
            Assert.assertEquals(var_73_actualValue, "DirectMail|Str201407|C");
            final String var_515_actualValue = varID515.get("Value").toString();
            Assert.assertEquals(var_515_actualValue.trim(), offerCodeInProspecttbl.trim(), "Copy prospect offercode is correct");

            // verify qp reduce pricing as || corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
            LOG.info("BMP-530 verify pricing with valid offercode");
        }
    }
}
