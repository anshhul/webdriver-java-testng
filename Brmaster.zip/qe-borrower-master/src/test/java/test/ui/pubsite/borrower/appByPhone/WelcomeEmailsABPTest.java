
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-1819 Verify welcome emails in user's personal account
 *
 * @author hisharma
 */
public class WelcomeEmailsABPTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(WelcomeEmailsABPTest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // HINT: Merged to ABPHappyPathCWithoutEmailTest
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void verifyWelcomeEmailsInABP() throws AutomationException {
        LOG.info("Executing: verifyWelcomeEmailsInABP()");
        // setup test data for test
        final HashMap<String, String> testData = abpPathAListing("verifyWelcomeEmailsInABP");
        final String listingID = testData.get("LISTINGID");
        final String email = testData.get("EMAILADDRESS");
        // Activate listing
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

        // Activate listing
        supportSiteMainPage.activateListing(listingID, "1");

        verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                MessageBundle.getMessage("verifyEmailAddress"), MessageBundle.getMessage("verifyEmailAddressEmailContent"));

        verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                MessageBundle.getMessage("bankAccountSubject"), MessageBundle.getMessage("bankAccountEmailContent"));

        verifyWebMail(outlookAbpWebAppPage, "QA", email, Constants.RegisterationPageConstants.FIRSTNAME_TAG,
                MessageBundle.getMessage("listingActivatedSubject"), MessageBundle.getMessage("listingActivatedBody"));

    }

}
