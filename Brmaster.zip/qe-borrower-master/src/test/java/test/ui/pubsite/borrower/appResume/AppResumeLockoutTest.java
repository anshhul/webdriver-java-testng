
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class AppResumeLockoutTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeLockoutTest.class.getSimpleName());


    // GEAR-2747 Verify that app resume URL works fine even after performing lockout scenario
    // GEAR-2745 Verify user navigates to home page on entering incorrect Lname 6th time in app resume modal
    // GEAR-2759 Verify app resume modal after lockout on Landing Page
    // GEAR-2638 Verify that validation is displayed for incorrect last name entered in resume modal
    // GEAR-2897 Verify user navigates to home page on submitting app resume modal with invalid zip 6th time
    // GEAR-2633 Verify that validation is displayed for incorrect zipcode entered in resume modal
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testLockoutAppResume() throws AutomationException {
        LOG.info("~~~~~~Executing: testLockoutAppResume~~~~~~~~~~~~~~~");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            PollingUtilities.sleep(2000);
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testLockoutAppResume");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
            PollingUtilities.sleep(2000);
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PollingUtilities.sleep(2000);
            try {
                Assert.assertTrue(publicSiteOfferPage.isOriginalOfferPageDisplayed());
            }catch (final AssertionError e){
                publicSiteRegistrationPage.clickGetYourRate(false, false);
            }

            // Get the current URL.
            String currentURL = publicSiteOfferPage.getCurrentURL();
            LOG.info("Current URL:" + currentURL);

            String flag = "flags=Offers-Test-Q2-2017:Original";

            String new_url = currentURL + (flag);
            LOG.info("New URL: " + new_url);

            // If Offer's page flag is not present in URL, add the flag to current URL & refresh the page.
            if(!currentURL.contains(new_url)){
                publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.ORIGINAL_FLAG_URL);
                LOG.info("URL changed successfully");
            }

            PollingUtilities.sleep(2000);
            Assert.assertTrue(publicSiteOfferPage.isOriginalOfferPageDisplayed(), "Original Offers page should be displayed");

            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);
            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationAgainPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());

            publicSitePreRegistrationAgainPage.checkYourRate();

            // app resume modal displayed
            // Test lockout use case for wrong zipcode 6times
            // 1 time:
            Assert.assertTrue(publicSitePreRegistrationAgainPage.getAppResumeModal().isDisplayed());
            LOG.info("GEAR-2890 Verify that app resume funnel works smoothly for DM use");

            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            // verify error warning message
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            LOG.info("GEAR-2633 Verify that validation is displayed for incorrect zipcode entered in resume modal");
            // 2 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 3 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 4 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 5 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 6 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(RandomStringUtils.random(4, false, true));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertFalse(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            LOG.info("GEAR-2897 Verify user navigates to home page on submitting app resume modal with invalid zip 6th time");

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());

            publicSitePreRegistrationAgainPage.checkYourRate();

            // Test lockout use case for wrong lastname 6times
            // 1 time:
            Assert.assertTrue(publicSitePreRegistrationAgainPage.getAppResumeModal().isDisplayed());
            LOG.info("GEAR-2759 Verify app resume modal after lockout on Landing Page");
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            // verify error warning message
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            LOG.info("GEAR-2638 Verify that validation is displayed for incorrect last name entered in resume modal");
            // 2 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 3 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 4 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 5 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertTrue(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            // 6 time:
            publicSitePreRegistrationAgainPage
                    .enterYearOfBorn(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG));
            publicSitePreRegistrationAgainPage
                    .enterLastName(RandomStringUtils.random(6, true, false));
            publicSitePreRegistrationAgainPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            publicSitePreRegistrationAgainPage.continueAppResume();
            PollingUtilities.sleep(6000);
            Assert.assertFalse(publicSitePreRegistrationAgainPage.isCredentialErrorDisplayed(Constants.CREDENTIAL_ERROR));
            LOG.info("GEAR-2745 Verify user navigates to home page on entering incorrect Lname 6th time in app resume modal");

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());

            publicSitePreRegistrationAgainPage.checkYourRate();
            final PublicSiteOfferPage offersAgainPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            PollingUtilities.sleep(2000);
            // Verify offer page displayed
            Assert.assertTrue(offersAgainPage.isLoanOfferPageDisplayed());
            LOG.info("GEAR-2747 Verify that app resume URL works fine even after performing lockout scenario");
        }
    }

    // GEAR-2750 Verify app resume lockout scenario when user is logged in into account in another tab
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testLockoutAppResumeWithAnotherTab() throws AutomationException {
        LOG.info("~~~~~~Executing: testLockoutAppResumeWithAnotherTab~~~~~~~~~~~~~~~");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testLockoutAppResumeWithAnotherTab");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);
            publicSitePreRegistrationPage.openCurrentUrlIntoNewTab(publicSiteOfferPage.getWindowLocationHref());
            publicSitePreRegistrationPage.moveToNextTab();
            publicSitePreRegistrationPage = publicSiteOfferPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();
            publicSitePreRegistrationPage.moveToNextTab();
            publicSitePreRegistrationPage
                    .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                            publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));
            PollingUtilities.sleep(3000);

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            PollingUtilities.sleep(3000);
            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            publicSiteOfferPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info("GEAR-2750 Verify app resume lockout scenario when user is logged in into account in another tab");
        }
    }
}
