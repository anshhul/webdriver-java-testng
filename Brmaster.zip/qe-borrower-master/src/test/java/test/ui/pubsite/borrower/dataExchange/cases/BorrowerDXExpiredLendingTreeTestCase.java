
package test.ui.pubsite.borrower.dataExchange.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import java.io.IOException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import org.codehaus.jettison.json.JSONException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

/**
 * Created by rsubramanyam on 4/8/16.
 */
public interface BorrowerDXExpiredLendingTreeTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Lending Tree:Get Offer:user with expired offers navigate to home page on hitting \"ShowSelectedOfferUrl\"", priority = "P2", labels = {
            "qe_ecosystem_automation", "dx"}, stepToTests = {
                    "Pre-requisite: \n" + "Offers should be expired for user.\n"
                            + "Update [Prospect].[dbo].[tblProspectOffer] set OfferDate=DATEADD(DAY, -31, getdate()) ,CreatedDate=DATEADD(DAY, -31, getdate()) where ProspectId in (\n"
                            + "SELECT TOP 1 [ProspectID]\n"
                            + "FROM [Prospect].[dbo].[tblProspect] where OfferCode='46cd1cf8-2602-4468-850c-4984128994b1')\n"}, expectedResult = "user with expired offers navigate to home page on hitting \"ShowSelectedOfferUrl\"")

    // PART-638 Lending Tree:Get Offer:user with expired offers navigate to home page on hitting "ShowSelectedOfferUrl"
    @Test(groups = {TestGroup.SANITY})
    void verifyExpiredOfferDXLendingTreeUserTest()
            throws IOException, JAXBException, XPathExpressionException, SAXException, ParserConfigurationException,
            TransformerException, JSONException, AutomationException, HttpRequestException;
}
