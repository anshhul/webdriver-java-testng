
package test.ui.pubsite.borrower.dataExchange.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import java.io.IOException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.codehaus.jettison.json.JSONException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

/**
 * Created by rsubramanyam on 4/8/16.
 */
public interface BorrowerDXGetOfferNewAAFSTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Get Offer:Correct response details should be displayed in SoapUI response to the DX user coming through Getoffer method having Experian STAGG value FICO<640.", priority = "P2", labels = {
            "qe_ecosystem_automation", "dx"}, stepToTests = {
                    "User details having value of FICO<640  should exist."}, expectedResult = "*Verify the followings:*\n"
                            + "1. Correct eligibility status\" Ineligible\" should be displayed.\n"
                            + "2. Correct IneligibilityReason \"Based on Prosper's internal algorithm, we could not find any matching offers.\" should be displayed.\n"
                            + "\n" + "\n" + "Verify the following in DB:\n" + "1. Prospect id should be generated.\n"
                            + "2.Correct Eligibility Status,Status Code and Ineligibilty reason should be displayed in table \"Prospect\"\n"
                            + "- Verify AdverseActionEvent table in DB.\n"
                            + "- Verify that correct AdverseActionEventTypeId=9 should be triggered.\n"
                            + "- Verify AdverseActionEventReason,AdverseActionEvent table in DB.\n"
                            + "- Verify Loan Offer Decline with DeclineID=1300 table in DB. \n"
                            + "- Verify Square Cut Info table with ID=16 in DB.\n"
                            + "- Offeruserid triggered in prospect table should be same as userid triggered in tblloanofferdecline.")

    // PART-377 Get Offer:Correct response details should be displayed in SoapUI response to the DX user coming through Getoffer
    // method having Experian STAGG value FICO<640.
    @Test(groups = {TestGroup.SANITY})
    void verifyAAForUserFSLesserThan640()
            throws IOException, JAXBException, JSONException, AutomationException, TransformerException,
            ParserConfigurationException, SAXException, HttpRequestException;
}
