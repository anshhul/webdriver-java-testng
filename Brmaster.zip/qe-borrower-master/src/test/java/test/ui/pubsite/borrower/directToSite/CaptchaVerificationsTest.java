
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-116 Verify Google's re-Captcha is not Fired on Sign-in Page before Three
 * Invalid Logins. BMP-115 Verify Google's re-Captcha is Fired on Sign-in Page
 * after Three Invalid Logins.
 *
 * @author hisharma
 */
public class CaptchaVerificationsTest extends PartnerLandingPageTestBase {

	private static final Double LOAN_AMOUNT = 5000.0;
	protected static final Logger LOG = Logger.getLogger(CaptchaVerificationsTest.class.getSimpleName());
	@Resource
	private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

	/**
	 *
	 * BMP-116 Verify Google's re-Captcha is not Fired on Sign-in Page before
	 * Three Invalid Logins. BMP-115 Verify Google's re-Captcha is Fired on
	 * Sign-in Page after Three Invalid Logins.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = { TestGroup.NIGHTLY })
	void verifyCaptcha() throws AutomationException {
		LOG.info("Test Method's Execution Started: verifyCaptcha()");

		final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage
				.checkYourRate();

		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
		publicSiteRegistrationPage.fillRegistrationForm(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
				Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
				Constant.COMMON_PASSWORD,
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

		publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
		final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

		publicSiteOfferPage.clickOnProsperLogo();
		publicSitePreRegistrationPage.userSignOut();

		final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();

		publicSiteSignInPage.signIn(email, RandomStringUtils.random(10, true, true));
		Assert.assertFalse(publicSiteSignInPage.isCaptchaDisplayed(), "Captcha should not appear before 3 attempts");

		publicSiteSignInPage.signIn(null, RandomStringUtils.random(10, true, true));
		Assert.assertFalse(publicSiteSignInPage.isCaptchaDisplayed(), "Captcha should not appear before 3 attempts");
		logger.info("BMP-116 Verify Google's re-Captcha is not Fired on Sign-in Page before Three Invalid Logins.");

		publicSiteSignInPage.signIn(null, RandomStringUtils.random(10, true, true));
		Assert.assertTrue(publicSiteSignInPage.isCaptchaDisplayed(), "Captcha should appear after 3 attenpts");
		logger.info("BMP-115 Verify Google's re-Captcha is Fired on Sign-in Page after Three Invalid Logins.");
	}
}
