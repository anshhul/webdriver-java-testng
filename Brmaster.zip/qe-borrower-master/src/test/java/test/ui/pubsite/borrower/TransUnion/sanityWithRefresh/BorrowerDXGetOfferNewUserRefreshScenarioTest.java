
package test.ui.pubsite.borrower.TransUnion.sanityWithRefresh;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ExperianDocumentDAO;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.ProspectCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;
import test.ui.pubsite.borrower.dataExchange.cases.BorrowerDXGetOfferNewUserTestCase;

/**
 * Created by jdoriya on 11/29/16.
 */
public class BorrowerDXGetOfferNewUserRefreshScenarioTest extends DXCompleteListingTestBase
        implements BorrowerDXGetOfferNewUserTestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXGetOfferNewUserRefreshScenarioTest.class.getSimpleName());


    @Override
    @Test(groups = {TestGroup.SANITY})
    public void verifyGetOfferNewUserTest()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: verifyGetOfferNewUserTest~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyGetOfferNewUserTest");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        LOG.info(allURLs[0]);
        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("File Permission Error"));
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));

                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            personalDetailsPage.reload();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertFalse(personalDetailsPage.isStaticTextDisplayed("Sass Compiling Error"));
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            tilPage.reload();
            tilPage.waitForTILAPage();
            tilPage.confirmElectronicSignature();
            final String listingID = tilPage.getListingIdFromTILAContent();
            PollingUtilities.sleep(4000);
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            final String prospectId = prospectCreated.getProspectId().toString();

            final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);

            // verify for creditbureau:2
            final ProspectCreditReportMappingModel prospectCreditReportMappingModelTu =
                    prospectDAO.getUserCreditReportMapping(prospectId, 2);
            // verify isdecisionbureau for tu enabled service
            Assert.assertEquals(prospectCreditReportMappingModelTu.getIsDecisionBureau(), "1");

            Preconditions.checkNotNull(prospectCreditReportMappingModelTu.getExternalCreditReportId(),
                    "ExternalCreditReportId  should not be null");

            // verify for creditbureau:1
            // final ProspectCreditReportMappingModel prospectCreditReportMappingModelEx =
            // prospectDAO.getUserCreditReportMapping(prospectId, 1);
            //
            // // verify isdecisionbureau for ex enabled service
            // Assert.assertEquals(prospectCreditReportMappingModelEx.getIsDecisionBureau(), "0");

            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            bankAccountInfoPage.reload();
            bankAccountInfoPage.waitForBankPageToLoadCompletely();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button

            publicSiteThankYouPage.clickGoToMyAccountPage();
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            LOG.info("User navigate to Thank you  Page");
            final UserCreditProfilesDAO creditProfilesDAO =
                    circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);

            circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);

            final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            // // verify for creditbureau:1
            // final ListingCreditReportMappingModel listingCreditReportMappingModel =
            // listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 1);
            // // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            // Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
            // experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
            // // verify IsDecisionBureau is false:
            // Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(), "0");

            /*
             * For row having CreditBureau=2 validate following: ExternalCreditReportId should be = Select ExternalCreditReportId
             * from Circleone..UserCreditReportMapping where UserID = <UserID> and CreditBureau=2 IsDecisionBureau should be "1".
             */
            final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                    listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 2);

            // verify IsDecisionBureau is false:
            Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

            // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
                    prospectCreditReportMappingModelTu.getExternalCreditReportId());

            // Submit the TILA page and validate following: (Model Report Validation):
            final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
            // verify ExternalModelReportId for TransUnion enabled
            Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
            LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
            // verify ExternalModelReportId for Experian enabled
            final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
            Assert.assertEquals(externalModelReportIdEx, null);

            // Temporary created Transunion DB object
            final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
            final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
            LOG.info("modelReportId is:" + modelReportId);
            Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));

            Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));
            LOG.info("~~~~~~Executing:~~~~~~BMP-5499~~~~~~");
            final String listingforPMI= listingsDAO.getListingIdForPMI(listingID);
            Assert.assertNull(listingforPMI);
            LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");
        }
    }
}
