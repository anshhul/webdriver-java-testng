
package test.ui.pubsite.borrower.TransUnion.sanityWithRefresh;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.ProspectCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Created by ppatil on 5/27/16.
 */

public class ABPHappyPathARefreshScenarioTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPHappyPathARefreshScenarioTest.class.getSimpleName());
    /*
     * @Autowired SupportSiteLandingPage supportSiteLandingPage;
     */
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // PART-1325 [Direct Mail] Path A: Borrower should be able to complete the funnel from public site java funnel.
    @Test(groups = {TestGroup.SANITY})
    void testHappyPathAFlow() throws AutomationException {

        LOG.info("~~~~~~~~~~Executing: testHappyPathAFlow~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlowWithoutEmail", "p2pcredit");
        String pathAUrl = null;
        String prospectId = null;
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            abpRegistrationPage.reload();
            abpRegistrationPage.waitForRegistrationFormToDisplayed();
        
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");
            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            prospectId = getQueryMap(abpRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            abpOfferPage.reload();
            abpOfferPage.waitForLoanOfferPageToLoadCompletely();
            
            
            
            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();

            final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);

            // verify for creditbureau:2
            final ProspectCreditReportMappingModel prospectCreditReportMappingModelTu =
                    prospectDAO.getUserCreditReportMapping(prospectId, 2);
            // verify isdecisionbureau for tu enabled service
            Assert.assertEquals(prospectCreditReportMappingModelTu.getIsDecisionBureau(), "1");

            Preconditions.checkNotNull(prospectCreditReportMappingModelTu.getExternalCreditReportId(),
                    "ExternalCreditReportId  should not be null");
            // Commenting below Credit Bureau assert for TU User
            // // verify for creditbureau:1
            // final ProspectCreditReportMappingModel prospectCreditReportMappingModelEx =
            // prospectDAO.getUserCreditReportMapping(prospectId, 1);
            //
            // // verify isdecisionbureau for ex enabled service
            // Assert.assertEquals(prospectCreditReportMappingModelEx.getIsDecisionBureau(), "0");

            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            abpPersonalDetailPage.reload();
            abpPersonalDetailPage.waitForPersonalDetailsPage();

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            pathAUrl = abpPersonalDetailPage.getABPPathAUrl(referralCode);
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            abpBankInfoPage.reload();
            abpBankInfoPage.waitForBankPageToLoadCompletely();
            // enter bank details

            abpBankInfoPage
                    .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            abpBankInfoPage
                    .enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);
            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
            // Borrower finish loan request and complete listing
        }
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
        	abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
            disclosurePage.reload();
            disclosurePage.waitForTILAPage();
            final String listingID = disclosurePage.getListingIdFromTILAContent();
            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            publicSiteBankAccountInfoPage.reload();
            publicSiteBankAccountInfoPage.waitForBankPageToLoadCompletely();
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            publicSiteThankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path A Borrower ListingID is:" + listingID);

            PollingUtilities.sleep(4000);
            final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
            final ProspectCreditReportMappingModel creditReportMappingModelTu =
                    prospectDAO.getUserCreditReportMapping(prospectId, 2);
            // verify isdecisionbureau for tu enabled service
            Assert.assertEquals(creditReportMappingModelTu.getIsDecisionBureau(), "1");

            // final ProspectCreditReportMappingModel creditReportMappingModelExp =
            // prospectDAO.getUserCreditReportMapping(prospectId,
            // 1);
            // verify isdecisionbureau for tu enabled service
            // Assert.assertEquals(creditReportMappingModelExp.getIsDecisionBureau(), "0");

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final UserCreditProfilesDAO creditProfilesDAO =
                    circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);

            // final ExperianDocumentDAO experianDocumentDAO =
            // circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);

            final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            // // verify for creditbureau:1
            // final ListingCreditReportMappingModel listingCreditReportMappingModel =
            // listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 1);
            // // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            // Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
            // experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
            // // verify IsDecisionBureau is false:
            // Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(), "0");

            /*
             * For row having CreditBureau=2 validate following: ExternalCreditReportId should be = Select ExternalCreditReportId
             * from Circleone..UserCreditReportMapping where UserID = <UserID> and CreditBureau=2 IsDecisionBureau should be "1".
             */
            final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                    listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 2);

            // verify IsDecisionBureau is false:
            Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

            // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            final ProspectCreditReportMappingModel prospectCreditReportMappingModelTu =
                    prospectDAO.getUserCreditReportMapping(prospectId, 2);
            Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
                    prospectCreditReportMappingModelTu.getExternalCreditReportId());

            // Submit the TILA page and validate following: (Model Report Validation):
            final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
            // verify ExternalModelReportId for TransUnion enabled
            Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
            LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
            // verify ExternalModelReportId for Experian enabled
            final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
            Assert.assertEquals(externalModelReportIdEx, null);

            // Temporary created Transunion DB object
            final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
            final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
            LOG.info("modelReportId is:" + modelReportId);
            Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));

            Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));
            LOG.info("~~~~~~Executing:~~~~~~BMP-5498~~~~~~");
            final String listingforPMI= listingsDAO.getListingIdForPMI(Long.toString(listingId));
            Assert.assertNull(listingforPMI);
            

            LOG.info("~~~~~~~~~~testHappyPathAFlowWithoutEmail--PASSED~~~~~~~~~~~~~~~~~~~~");
        }
    }

}
