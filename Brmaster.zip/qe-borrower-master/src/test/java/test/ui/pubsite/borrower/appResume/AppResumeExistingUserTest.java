
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class AppResumeExistingUserTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeExistingUserTest.class.getSimpleName());
    @Autowired
    @Qualifier("publicSiteSignInPage")
    private PublicSiteSignInPage publicSiteSignInPage;


    // GEAR-2621 Verify that resume modal is displayed to existing user with loan trying to create new listing dropped on invalid
    // offers page
    // GEAR-2590 Verify that \"Sign in\" link takes user to sign in page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserAppResume() throws AutomationException {
        LOG.info("Test Method Name - testExistingUserAppResume");
        final String email = getUserForEnvironment("testExistingUserAppResume");
        final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
        if (accountOverviewPage.getWindowLocationHref().contains("signin")) {
            accountOverviewPage
                    .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            accountOverviewPage.dismissCongratulationWelcomeModal();
        }
        final PublicSitePreRegistrationPage publicSitePreRegistrationPage = accountOverviewPage.clickOnProsperLogo();

        // Increase polling time to load home page
        PollingUtilities.sleep(6000);
        final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        // verify existing lisitng decline
        // Get alternate key from cookie
        final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
        LOG.info("alternate key is " + altKey);
        Assert.assertNotNull(altKey);

        final PublicSiteDeclinePage declinePage = publicSiteOfferPage.goToDeclinePage();
        PollingUtilities.sleep(4000);

        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = declinePage.clickOnProsperLogo();
        // Signout user
        publicSitePreRegistrationAgainPage.deleteAllCookies();

        publicSitePreRegistrationAgainPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

        Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());
        publicSitePreRegistrationAgainPage.checkYourRate();

        // app resume modal displayed
        Assert.assertTrue(publicSitePreRegistrationAgainPage.getAppResumeModal().isDisplayed());
        LOG.info(
                "GEAR-2621 Verify that resume modal is displayed to existing user with loan trying to create new listing dropped on invalid offers page");

        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationAgainPage.clickOnSignInAppResume();
        Assert.assertTrue(publicSiteSignInPage.isSignInPageDisplayed());
        LOG.info("GEAR-2590 Verify that \"Sign in\" link takes user to sign in page");
    }
}
