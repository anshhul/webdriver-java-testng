
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.WebDriverTestBase;

/**
 * @author hisharma
 *
 */
public class LumberjackFooterTest extends WebDriverTestBase{

    protected static final Logger LOG =
            Logger.getLogger(LumberjackFooterTest.class.getSimpleName());

	@Resource
	private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    @Test(groups = TestGroup.NIGHTLY)
    public void verifyPrivacyAndSocialFooterLinks() throws AutomationException {
        LOG.info("~~~~~~Executing-testExistingUserListing~~~~~~~~~~~~~~~");

        // Verify Privacy Icons on Footer
        Assert.assertTrue(publicSitePreRegistrationPage.verifyTrusteFooterLink());
        publicSitePreRegistrationPage.navigateToBack();

        // Other privacy icons
        Assert.assertTrue(publicSitePreRegistrationPage.isEqualHousingFooterIconDisplayed());
        Assert.assertTrue(publicSitePreRegistrationPage.isBetterBusinessFooterIconDisplayed());

        // Verify facebook social footer link
        Assert.assertTrue(publicSitePreRegistrationPage.verifyFacebookFooterLink());
        publicSitePreRegistrationPage.closeCurrentTab();

        // Verify linked in social footer link
        Assert.assertTrue(publicSitePreRegistrationPage.verifyLinkedInFooterLink());
        publicSitePreRegistrationPage.closeCurrentTab();

        // Verify twitter social footer link
        Assert.assertTrue(publicSitePreRegistrationPage.verifyTwitterFooterLink());
        publicSitePreRegistrationPage.closeCurrentTab();

        Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());
	    }
	}
