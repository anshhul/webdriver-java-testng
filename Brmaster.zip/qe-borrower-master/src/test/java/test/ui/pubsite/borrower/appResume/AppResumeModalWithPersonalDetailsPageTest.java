
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 17-feb
 *
 */
public class AppResumeModalWithPersonalDetailsPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithPersonalDetailsPageTest.class.getSimpleName());


    /**
     * GEAR-2565 Verify CTA app resume modal shows up to user dropped on PD page on clicking 'continue your application' GEAR-2566
     * Verify app resume login for user dropped on PD page on entering lastname, zip, birth year details and is redirected to
     * Offers page GEAR-2567 Verify funnel flow beyond offers page for user dropping off on PD page. GEAR-2693 User Drop off on
     * Personal Details Page
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalWithPersonalDetailsPage() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalWithPersonalDetailsPage~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAppResumeModalWithPDPage");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            PublicSitePersonalDetailPage personalDetailsPage = offersPage.clickGetLoan();

            // Get alternate key from cookie
            final String altKey = personalDetailsPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            PollingUtilities.sleep(2000);
            publicSitePreRegistrationPage = personalDetailsPage.clickProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            LOG.info(
                    "GEAR-2565 Verify CTA app resume modal shows up to user dropped on PD page on clicking 'continue your application'");

            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info(
                    "GEAR-2566 Verify app resume login for user dropped on PD page on entering lastname, zip, birth year details and is redirected to Offers page");

            personalDetailsPage = offersPage.clickGetLoan();
            // Verify new Personal detail Header text

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

            tilPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            MessageBundle.getMessage("savingAccountType"),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
            Assert.assertNotNull(accountOverviewPage);
            LOG.info("GEAR-2567 Verify funnel flow beyond offers page for user dropping off on PD page");
            LOG.info("GEAR-2693 User Drop off on Personal Details Page");
        }
    }

    /**
     *
     * GEAR-2564 Verify that SSN is not prepopped on PD page when IDV scenarios is fulfilled
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifySSNNotPrePoppedOnPDPageWithIDV() throws AutomationException {
        LOG.info("~~~~~~Executing: verifySSNNotPrePoppedOnPDPageWithIDV~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                .getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSSNNotPrePoppedOnPDPageWithIDV");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("invalidLastName"),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        // Verify that SSN page is displayed
        Assert.assertTrue(publicSiteRegistrationPage.isSSNPageDisplayed());
        LOG.info("Make sure that SSN page displayed on providing incorrect last name");

        // Submit SSN page with VALID SSN
        publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        // Get alternate key from cookie
        String altKey = offersPage.getCookieValue("alt_key");
        LOG.info("alternate key is:" + altKey);
        Assert.assertNotNull(altKey);

        publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();

        // Signout user
        publicSitePreRegistrationPage.deleteAllCookies();

        publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

        Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
        LOG.info("GEAR-2565 Verify CTA app resume modal shows up to user dropped on PD page on clicking 'continue your application'");

        publicSitePreRegistrationPage.checkYourRate();

        // app resume modal displayed
        Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

        // Enter details in App Resume Modal
        offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                MessageBundle.getMessage("invalidLastName"),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

        // Verify offer page displayed
        Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());

        PublicSitePersonalDetailPage personalDetailsPage = offersPage.clickGetLoan();
        Assert.assertTrue(personalDetailsPage.getSSnFieldValue().isEmpty());
        LOG.info("GEAR-2564 Verify that SSN is not prepopped on PD page when IDV scenarios is fulfilled");
    }

    // GEAR-2658 Verify that user dropped from offer page gets authorized only after submitting valid SSN on PD page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyUserAuthorizedOnPDSubmissionTest() throws AutomationException {
        LOG.info("~~~~~~Executing: verifyUserAuthorizedOnPDSubmissionTest~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            String email = TestDataProviderUtil.getUniqueEmailIdForTest("testUserAuthorizedOnPDSubmissionTest");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // Get alternate key from cookie
            final String altKey = offersPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            PollingUtilities.sleep(2000);
            publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), getPrimeBorrowerData()
                            .get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData()
                            .get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());
            publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();
            PollingUtilities.sleep(3000);

            Assert.assertTrue(publicSitePreRegistrationPage.isSignInHeaderLinkDisplayed());

            publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            PublicSitePersonalDetailPage personalDetailsPage = offersPage.clickGetLoan();

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            publicSitePreRegistrationPage = tilPage.clickOnProsperLogo();
            Assert.assertFalse(publicSitePreRegistrationPage.isSignInHeaderLinkDisplayed());
            LOG.info("GEAR-2658 Verify that user dropped from offer page gets authorized only after submitting valid SSN on PD page");
        }
    }
}
