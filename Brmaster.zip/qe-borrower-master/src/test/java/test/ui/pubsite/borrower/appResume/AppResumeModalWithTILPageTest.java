
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 20-feb
 *
 */
public class AppResumeModalWithTILPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithTILPageTest.class.getSimpleName());


    /**
     *
     * GEAR-2585 Verify that for user dropping funnel on TIL page, all other details are prepopped on PDP page except SSN
     * GEAR-2586 Verify that for user droppping on TIL page is allowed to move to TILA page on entering valid SSN on PDP page
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalWithTILPage() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalWithTILPage~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyAppResumeModalWithTILPage");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            // Verify new Personal detail Header text

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            PollingUtilities.sleep(2000);
            tilPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            publicSiteOfferPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Verify offer page displayed
            Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed());
            personalDetailsPage = publicSiteOfferPage.clickGetLoan();

            // Verify SSN field should be blanked on PD page
            Assert.assertTrue(personalDetailsPage.getSSnFieldValue().isEmpty());

            // Verify all other details should be prepopped on PDP page except SSN
            Assert.assertTrue(personalDetailsPage.getEmployerName().contains(
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG)));
            Assert.assertTrue(personalDetailsPage.verifyPreFilledOccupation(getCommonTestData().get(
                    Constants.PersonalDetailPage.OCCUPATION_TAG)));
            Assert.assertTrue(personalDetailsPage.verifyPrefilledPrimaryPhone(getCommonTestData().get(
                    Constants.PersonalDetailPage.HOMEPHONE_TAG)));
            Assert.assertTrue(personalDetailsPage.verifyPreFilledSecondaryPhone(getCommonTestData().get(
                    Constants.PersonalDetailPage.SECONDARYPHONE_TAG)));
            Assert.assertTrue(personalDetailsPage.verifyStartOfEmploymentDate(getCommonTestData().get(
                    Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG)));
            LOG.info(
                    "GEAR-2585 Verify that for user droppping funnel on TIL page, all other details are prepopped on PDP page except SSN");

            personalDetailsPage.enterSocialSecurityNumber(getPrimeBorrowerData()
                    .get(Constants.RegisterationPageConstants.SSN_TAG));
            tilPage = personalDetailsPage.clickContinue();
            Assert.assertTrue(tilPage.isTruthInLendingDisclosurePageDisplayed());
            LOG.info("GEAR-2586 Verify that for user droppping on TIL page is allowed to move to TILA page on entering valid SSN on PDP page");
        }
    }
}
