
package test.ui.pubsite.borrower.dataExchange.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import java.io.IOException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

/**
 * Created by rsubramanyam on 4/8/16.
 */
public interface BorrowerDXExpiredGetOfferTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Get Offer:Existing user with expired offers should navigate to home page and remain logged on public site on hitting ShowSelectedOfferUrl", priority = "P1", labels = {
            "qe_ecosystem_automation", "dx"}, stepToTests = {
                    "*Pre-requisite*\n" + "Existing user with draft listing should exists.\n" + "\n" + "*Steps*\n"
                            + "Expire offers obtained from public side.\n" + "use Circleone\n"
                            + "SQL update LoanOffer set OfferDate=DATEADD(DAY, -31, getdate()) where ListingScoreID=3713940\n"
                            + "-Hit Get offer end point .\n" + "Expire offers obtained in DX response.\n" + "SQL\n"
                            + "Update [Prospect].[dbo].[tblProspectOffer] set OfferDate=DATEADD(DAY, -31, getdate()) ,CreatedDate=DATEADD(DAY, -31, getdate()) where ProspectId in (\n"
                            + "SELECT TOP 1 [ProspectID]\n"
                            + "FROM [Prospect].[dbo].[tblProspect] where OfferCode='5c3983dd-e11b-4919-bb09-3098f9ba67e7')\n"
                            + "-Open url obtained in response and observe that user is logged in .\n"}, expectedResult = "*Verify the followings:* \n"
                                    + "Existing user with expired offers should navigate to home page and remain logged on public site on hitting ShowSelectedOfferUrl")
    @Test(groups = {TestGroup.SANITY})
    void verifyExpiredOfferDXGetOfferUserTest()
            throws AutomationException, ParserConfigurationException, IOException, SAXException, TransformerException,
            HttpRequestException, JAXBException;
}
