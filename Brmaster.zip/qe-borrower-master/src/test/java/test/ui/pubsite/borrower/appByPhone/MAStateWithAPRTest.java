package test.ui.pubsite.borrower.appByPhone;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage.ABPDeclineOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class MAStateWithAPRTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(MAStateWithAPRTest.class.getSimpleName());

	private static String ABP_PARTNER_CHANNEL = "Direct Mail";

	/**
	 * @author ntaneja BMP-3806:Verify decline to MA state user having APR>35
	 *         from ABP
	 */
	@Test(groups = { TestGroup.NIGHTLY })
	public void testMAStateWithAPRGreaterThan35() throws AutomationException {

		LOG.info("~~~~~~~Executing: testMAStateWithAPRGreaterThan35~~~~~~~~~~~~~~");
		// login to support site
		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
		// navigate to home page and select default abp partner as direct mail
		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

		final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);
		// click on start application button
		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

		// navigate to ABP Registration Page
		abpRegistrationPage
				.enterFirstName(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
		LOG.info("CSA user entered the firstname of borrower");
		abpRegistrationPage
				.enterLastName(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
		LOG.info("CSA user entered the lastname of borrower");
		abpRegistrationPage.enterMiddleName("L");
		LOG.info("CSA user entered the middle name of  borrower");
		abpRegistrationPage.selectSuffix("Jr.");
		LOG.info("CSA user entered the streetname of borrower");
		abpRegistrationPage
				.enterHomeAddress(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
		abpRegistrationPage.enterCity(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
		LOG.info("CSA user entered the cityname of borrower");
		abpRegistrationPage.selectState(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
		LOG.info("CSA user select the state of borrower");
		abpRegistrationPage
				.enterZipCode(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
		LOG.info("CSA user entered the zipcode of borrower");
		// User enter the employment status as Employed
		abpRegistrationPage.selectEmploymentStatus(
				getMAStateBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
		LOG.info("CSA user select employment status of borrower");

		// User enter the Yearly Income
		abpRegistrationPage
				.enterYearlyIncome(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
		LOG.info("CSA user entered the yearlyincome of borrower");
		// User enter the Date of Birth >18 years
		abpRegistrationPage
				.enterDateOfBirth(getMAStateBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
		LOG.info("CSA user entered the dateofbirth borrower");
		// select all disclosures agreements
		abpRegistrationPage.clickOnDisclosures();
		LOG.info("CSA user agreed to disclosures for borrower");
		abpRegistrationPage.enterHomePhone(getMAStateBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
		abpRegistrationPage
				.enterSecondaryPhone(getMAStateBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
		abpRegistrationPage.enterLoanAmount(getMAStateBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
		LOG.info("CSA user entered the loanamount for borrower");
		abpRegistrationPage.selectLoanPurposer(getMAStateBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
		LOG.info("CSA user select loan purpose for borrower");
		final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
		final ABPDeclineOfferPage abpDeclineOfferPage = abpOfferPage.goToDeclinePage();
		Assert.assertTrue(abpDeclineOfferPage.getDeclineContentAsElement().getText()
				.contains(Constants.VALIDATIONS.ABP_DECLINE_MESSAGE));
		final ProspectDAO prospectdao = circleOneDBConnection.getDataAccessObject(ProspectDAO.class);
		String offerUserId = prospectdao.getOfferUserId(email);
		final LoanOfferDeclineDAO loanOfferDecline = circleOneDBConnection
				.getDataAccessObject(LoanOfferDeclineDAO.class);
		String DeclineReasonID = String.valueOf(loanOfferDecline.getDeclineReasonID(offerUserId));
		String reason = loanOfferDecline.getDeclineReason(DeclineReasonID);
		Assert.assertEquals(reason, "NoOffersMA");
		LOG.info("~~~~~~~Executing: MAStateWithAPRTest~~~~~~~~~~~~~~~~~PASSED~~~~~~~~~~~~~~");
		LOG.info("BMP-3806:Verify decline to MA state user having APR>35 from ABP~~~~~~~~~~~~~~~~~~~~~~~PASSED");
	}

}
