package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;


/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 15-Jun-2016
 *
 */
public class ExistingUserListingViaSignInTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ExistingUserListingViaSignInTest.class.getSimpleName());



    // BMP-455 Existing borrower with Withdrawn listing should be navigated to Pre-Popped Register page on sign in through SignIn
    // modal on Register page.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testListingForExistingUserViaSignInModal() throws AutomationException {

        LOG.info("~~~~~~Executing-testListingForExistingUserViaSignInModal~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testListingForExistingUserViaSignInModal");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        Assert.assertNotNull(publicSiteOfferPage);
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();
        Assert.assertTrue(publicSitePreRegistrationAgainPage.isBorrowerLandingPageDisplayed());
        publicSitePreRegistrationAgainPage.userSignOut();
        Assert.assertTrue(publicSitePreRegistrationAgainPage.isBorrowerLandingPageDisplayed());

        publicSitePreRegistrationAgainPage.clickOnStartAnApplication();

        publicSiteRegistrationPage.enterEmailAddress(email);
        PollingUtilities.sleep(4000);
        if (publicSiteRegistrationPage.isTextPresent(Constants.RegisterationPageConstants.EXISTING_USER_EMAIL_NOTIFY, false)) {

            final PublicSiteSignInPage publicSiteSignInPage = publicSiteRegistrationPage.clickLogin();
            final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage1 = accountOverviewPage.clickOnProsperLogo();
            publicSiteRegistrationPage =
                    publicSitePreRegistrationAgainPage1.checkYourRate();
        } else {
            publicSiteRegistrationPage.signInViaModal(email);
        }
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferAgainPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferAgainPage.clickGetLoan();
        // Verify new Personal detail Header text
        personalDetailsPage.verifyPersonalDetailPageHeaderContent();

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.dismissCongratulationWelcomeModal();

        Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));
        LOG.info("New Listing for Withdrawn Listing User :" + listingID);
        LOG.info(
                "BMP-455  Existing borrower with Withdrawn listing should be navigated to Pre-Popped Register page on sign in through SignIn modal on Register page.");
        LOG.info("~~~~~~testListingForExistingUserViaSignInModal--PASSED~~~~~~~~~~~~~~~");
    }

    // BMP-728 User with withdrawn listing should be able to create new listing from java funnel.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testListingForExistingUserViaSignInPage() throws AutomationException {

        LOG.info("~~~~~~Executing-testListingForExistingUserViaSignInPage~~~~~~~~~~~~~~~");
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        Assert.assertNotNull(publicSiteOfferPage);
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();
        Assert.assertTrue(publicSitePreRegistrationAgainPage.isBorrowerLandingPageDisplayed());
        publicSitePreRegistrationAgainPage.userSignOut();
        Assert.assertTrue(publicSitePreRegistrationAgainPage.isBorrowerLandingPageDisplayed());

        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

        final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);

        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.dismissCongratulationWelcomeModal();
        //
        final PublicSiteOfferPage publicSiteOfferAgainPage = accountOverviewPage.clickFinishApplication();
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferAgainPage.clickGetLoan();

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        borrowerThankYouPage.clickGoToMyAccountPage();
        LOG.info("New Listing for User :" + listingID);
        LOG.info("BMP-728 User with withdrawn listing should be able to create new listing from java funnel.");
        LOG.info("~~~~~~testListingForExistingUserViaSignInPage-- PASSED~~~~~~~~~~~~~~~");
    }
}
