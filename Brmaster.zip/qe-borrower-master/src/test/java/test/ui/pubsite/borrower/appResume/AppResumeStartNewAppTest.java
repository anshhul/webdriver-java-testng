
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class AppResumeStartNewAppTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeStartNewAppTest.class.getSimpleName());


    // GEAR-2760 Verify that cllcking "Start new application" deletes app resume cookie
    // GEAR-2589 Verify that "Start New application" works like "Check your rate" button and takes user to reg page
    // GEAR-2698 On clicking the CTA the pop up modal should show up
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testAppResumeStartNewApp() throws AutomationException {
        LOG.info("~~~~~~Executing: testAppResumeStartNewApp~~~~~~~~~~~~~~~");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testLockoutAppResume");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // Assert.assertTrue(publicSiteOfferPage.isOriginalOfferPageDisplayed(), "Original Offers page should be displayed");

            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);
            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationAgainPage.deleteAllCookies();

            publicSitePreRegistrationAgainPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/?altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());
            // verify cta button action for modal pop up
            publicSitePreRegistrationAgainPage.clickOnCta();
            LOG.info("GEAR-2698 On clicking the CTA the pop up modal should show up");

            Assert.assertFalse(publicSitePreRegistrationAgainPage.getCookieValue("app_resume").isEmpty());
            PollingUtilities.sleep(6000);
            final PublicSiteRegistrationPage publicSiteRegistrationAgainPage =
                    publicSitePreRegistrationAgainPage.clickStartNewApp();
            PollingUtilities.sleep(6000);
            Assert.assertNotNull(publicSiteRegistrationAgainPage);
            Assert.assertTrue(publicSiteRegistrationAgainPage.isRegisterPageDisplayed());
            LOG.info(
                    "GEAR-2589 Verify that \"Start New application\" works like \"Check your rate\" button and takes user to reg page");
            try{
                publicSitePreRegistrationAgainPage.getCookieValue("app_resume");
            }catch(final NullPointerException npe){
                LOG.info("GEAR-2760 Verify that cllcking \"Start new application\" deletes app resume cookie");
            }
        }
    }
}
