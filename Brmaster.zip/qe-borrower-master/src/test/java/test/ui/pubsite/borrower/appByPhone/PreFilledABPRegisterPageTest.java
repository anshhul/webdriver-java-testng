
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.enumeration.platform.EmploymentStatus;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class PreFilledABPRegisterPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PreFilledABPRegisterPageTest.class.getSimpleName());
    private static final String ABP_PARTNER_CHANNEL = "Direct Mail";


    // BMP-3987 Existing User with Employment status as Other: Correct details should be populated on register page of ABP funnel.
    @Test(groups = {TestGroup.NIGHTLY})
    void testPreFilledEmploymentStatus() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testPreFilledEmploymentStatus~~~~~~~~~~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testPreFilledEmploymentStatus");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    publicSitePreRegistrationPage.checkYourRate();

            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    EmploymentStatus.OTHER.getDescription(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            Assert.assertNotNull(publicSiteOfferPage);
        }
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

            Assert.assertTrue(abpRegistrationPage.verifyUserDetailsPreFilled());
            Assert.assertEquals(abpRegistrationPage.getEmploymentStatus(), EmploymentStatus.OTHER.getDescription());
            LOG.info(
                    "BMP-3987 Existing User with Employment status as Other: Correct details should be populated on register page of ABP funnel.");
        }
    }
}
