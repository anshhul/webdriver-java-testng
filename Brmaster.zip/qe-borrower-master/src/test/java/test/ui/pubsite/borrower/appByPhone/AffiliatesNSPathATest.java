
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 06-Sep-2016
 *
 */
public class AffiliatesNSPathATest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Affiliates";
    private static String AFFILIATES_PARTNER_CHANNEL = "Affiliates (Nationstar)";
    String pathAURL = null;
    protected static final Logger LOG = Logger.getLogger(AffiliatesNSPathATest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // BMP-1434 AF: NS: Verify that correct prospect is generated for the user created via ABP in prospect database
    // BMP-1478 AF: NS: Path A: Borrower should be able to create password from Create Password landing Page.
    // BMP-1447 AF: NS: Path A: Borrower should be navigated to Loan Terms page of java funnel after creating password
    // BMP-1432 AF: NS: Path A: Borrower should be navigated to Create Password landing Page of Path A on clicking the links in
    // Password Creation mail.
    // BMP-1431 AF: NS: Path A: Borrower should be able to complete the funnel from public site java funnel.
    @Test(groups = {TestGroup.NIGHTLY})
    void testAffiliatesPathA() throws AutomationException {

        LOG.info("~~~~~~~~~~Executing: testAffiliatesPathA~~~~~~~~~~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testAffiliatesPathA", "p2pcredit");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            supportSiteMainPage.selectPartner(AFFILIATES_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnContinue();
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");
            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            pathAURL = abpPersonalDetailPage.getABPPathAUrl(referralCode);
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // enter bank details

            abpBankInfoPage
                    .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            abpBankInfoPage
                    .enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);
            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAURL), URLUtilities.getStringURLWithoutScheme(pathAURL))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAURL);
            final String listingID = disclosurePage.getListingIdFromTILAContent();
            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            publicSiteThankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path A Borrower ListingID is:" + listingID);
            LOG.info("BMP-1431 AF: NS: Path A: Borrower should be able to complete the funnel from public site java funnel.");
            PollingUtilities.sleep(3000);
            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            final ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
            prospectInfo.getCreatedDate(email);
            // verify created date
            // TODO: Investigate below createdate failure
            // Assert.assertTrue(prospectCreatedDate
            // .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
            // "Correct 'CreatedDate' should be displayed");
            // verify engagementdate
            Assert.assertTrue(prospectInfo.getEngagementDate(email)
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            // verify user first name
            Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    "Correct 'FirstName' should be displayed");
            // verify user last name
            Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    "Correct 'LastName' should be displayed");
            // verify user employment status
            Assert.assertEquals(prospectInfo.getEmployementStatusID(email),
                    Constants.UserEmploymentStatus.borrowerEmployedStatusID);
            // verify user zip code
            Assert.assertEquals(prospectCreated.getAddressInfo().getZipCode(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            // verify user address
            Assert.assertEquals(prospectCreated.getAddressInfo().getAddress1().toString().trim(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).trim());
            // verify city name
            Assert.assertEquals(prospectCreated.getAddressInfo().getCity().toString(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // verify state name
            Assert.assertEquals(prospectCreated.getAddressInfo().getState().toString(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // verify loan amount
            Assert.assertEquals(prospectCreated.getLoanAmount().toString().replaceAll("\\.0*$", ""),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info(
                    "BMP-1434 AF: NS: Verify that correct prospect is generated for the user created via ABP in prospect database");
        }
        LOG.info("~~~~~~~~~~testAffiliatesPathA--PASSED~~~~~~~~~~~~~~~~~~~~");
    }
}
