
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.RegistrationPageMessageConstants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 02-Sep-2016
 *
 */
public class ABPRegistrationFieldValidationTest extends PartnerLandingPageTestBase {

	private static String ABP_PARTNER_CHANNEL = "Direct Mail";
	protected static final Logger LOG = Logger.getLogger(ABPRegistrationFieldValidationTest.class.getSimpleName());
	private static final String INVALI_DOB_FORMATE_MONTH="13/02/1984";
	private static final String INVALI_DOB_FORMATE_DATE="12/32/1984";
	private static final String INVALI_DOB_FORMATE_YEAR = "12/12/84";


	/**
	 * BMP-2545 City: Correct inline validation should be displayed on leaving "City" field blank.
	 * BMP-2471 Note should displayed on selecting loan purpose as "other" on register page
	 * BMP-2565 Zip Code: Correct validation should be displayed on providing invalid values in "Zip Code" field
	 * BMP-2490 Individual Yearly Income: Yearly income field should accept only Numeric values.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = {TestGroup.NIGHTLY})
	void testRegistrationFields() throws AutomationException {
        LOG.info("~~~~~~~Executing: testRegistrationFields~~~~~~~~~~~~~~");
		// login to support site
		final ApplicationContext jobContext =
				new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

		// navigate to home page and select default abp partner as direct mail
		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testRegistrationFields", "p2pcredit");
		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);
		// click on start application button
		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
		// navigate to ABP Registration Page
		abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
		LOG.info("CSA user entered the firstname of borrower");

		abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
		LOG.info("CSA user entered the lastname of borrower");
		abpRegistrationPage.enterMiddleName("L");
		LOG.info("CSA user entered the middle name of  borrower");
		abpRegistrationPage.selectSuffix("Jr.");
		LOG.info("CSA user entered the streetname of borrower");
		abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
		abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
		LOG.info("CSA user entered the cityname of borrower");
		abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
		LOG.info("CSA user select the state of borrower");
		// CSA user left blank zipcode of borrower
		abpRegistrationPage.enterZipCode("");
		LOG.info("CSA user left blank zipcode of borrower");
		// User enter the employment status as Employed
		abpRegistrationPage.selectEmploymentStatus(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
		LOG.info("CSA user select employment status of borrower");

		// User enter the Yearly Income
		abpRegistrationPage
		.enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
		LOG.info("CSA user entered the yearlyincome of borrower");
		// User enter the Date of Birth >18 years
		abpRegistrationPage
		.enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
		LOG.info("CSA user entered the dateofbirth borrower");
		// select all disclosures agreements
		abpRegistrationPage.clickOnDisclosures();
		LOG.info("CSA user agreed to disclosures for borrower");
		abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
		abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

		abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
		LOG.info("CSA user entered the loanamount for borrower");
		abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));

		abpRegistrationPage.clickGetRate();

		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.BLANK_ZIP_CODE_ERROR_MESSAGE, false));
		LOG.info("BMP-2565 Zip Code: Correct validation should be displayed on providing invalid values in \"Zip Code\" field");

		abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

		// clear city field for borrower
		abpRegistrationPage.enterCity("");
		abpRegistrationPage.clickGetRate();
		PollingUtilities.sleep(1000);
		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.BLANK_CITY_ERROR_MESSAGE, false));
		LOG.info("BMP-2545 City: Correct inline validation should be displayed on leaving \"City\" field blank.");
		abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
		abpRegistrationPage.enterDateOfBirth("");
		abpRegistrationPage.enterDateOfBirth(INVALI_DOB_FORMATE_MONTH);
		abpRegistrationPage.clickGetRate();
		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.DATE_OF_BIRTH_ERROR_MESSAGE, false));
		PollingUtilities.sleep(1000);
		abpRegistrationPage.enterDateOfBirth("");
		abpRegistrationPage.enterDateOfBirth(INVALI_DOB_FORMATE_DATE);
		abpRegistrationPage.clickGetRate();
        PollingUtilities.sleep(2000);
		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.DATE_OF_BIRTH_ERROR_MESSAGE, false));
		PollingUtilities.sleep(1000);
		abpRegistrationPage.enterDateOfBirth("");
		abpRegistrationPage.enterDateOfBirth(INVALI_DOB_FORMATE_YEAR);
		abpRegistrationPage.clickGetRate();
		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.DATE_OF_BIRTH_ERROR_MESSAGE, false));
		PollingUtilities.sleep(1000);
		// User enter the Date of Birth >18 years
		abpRegistrationPage
		.enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
		Assert.assertFalse(abpRegistrationPage.isTextPresent(Constants.DATE_OF_BIRTH_ERROR_MESSAGE, false));
		LOG.info("BMP-253 ABP: Verify DOB field (MM/DD/YYYY) formatted while entering date of birth.");
		// Select Other Loan Purpose
		abpRegistrationPage.selectLoanPurposer("Other");
		PollingUtilities.sleep(1000);
		Assert.assertTrue(abpRegistrationPage.isFieldHintPresent(Constants.OTHER_LOAN_PURPOSER_HINT));
		LOG.info("BMP-2471 Note should displayed on selecting loan purpose as \"other\" on register page");

		abpRegistrationPage.enterYearlyIncome("asdasd");
		abpRegistrationPage.clickGetRate();
        PollingUtilities.sleep(1000);
		Assert.assertTrue(abpRegistrationPage.isTextPresent(Constants.YEARLY_INCOME_ERROR_MESSAGE, false));
		LOG.info("BMP-2490 Individual Yearly Income: Yearly income field should accept only Numeric values.");
	}

    @Test(groups = {TestGroup.NIGHTLY})
	public void testRegisterPageForBlankFieldValidations() throws AutomationException{

		final ApplicationContext jobContext =
				new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage =
				(SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        final String email =
                TestDataProviderUtil.getGloballyUniqueEmailDomain("testRegisterPageForBlankFieldValidations", "p2pcredit");
		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);

		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

		abpRegistrationPage.clickGetRate();

		Assert.assertEquals(abpRegistrationPage.getBlankLoanPurposeValidation(),MessageBundle.getMessage("blankLoanPurposeValidation"));
		LOG.info("BMP-2568 Loan Purpose: Appropriate validation should be displayed on submitting \"Borrower Application by Phone\" page without selecting loan purpose.");

		Assert.assertEquals(abpRegistrationPage.getBlankLastFieldValidation(),MessageBundle.getMessage("lastNameEmptyValidation"));
		LOG.info("BMP-2448 Last Name: Correct inline validation should be displayed on leaving \"Last Name\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getBlankHomeAddressValidation(),MessageBundle.getMessage("homeAddressEmptyValidation"));
		LOG.info("BMP-2522 Home Address: Correct inline validation should be displayed on leaving \"Home Address\" field blank");

		Assert.assertEquals(abpRegistrationPage.getBlankCityValidation(),MessageBundle.getMessage("cityEmptyValidation"));
		LOG.info("BMP-2545 City: Correct inline validation should be displayed on leaving \"City\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getZipValidation(),MessageBundle.getMessage("zipEmptyValidation"));
		LOG.info("BMP-2555 Zip: Correct inline validation should be displayed on leaving \"Zip\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getPrimaryPhoneValidation(),MessageBundle.getMessage("primaryPhoneEmptyValidation"));
		LOG.info("BMP-2536 Home/Mobile Phone: Correct inline validation should be displayed on leaving Home phone AND Mobile phone fields blank.");

		Assert.assertEquals(abpRegistrationPage.getDOBValidation(),MessageBundle.getMessage("dobEmptyValidation"));
		LOG.info("BMP-2468 Date of Birth: Correct inline validation should be displayed on leaving \"Date Of Birth\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getYearlyIncomeValidation(),MessageBundle.getMessage("invalidYearlyIncomeValidation"));
		LOG.info("BMP-2492 Individual Yearly Income : Correct inline validation should be displayed on leaving \"Yearly Income\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getPhoneNoDisclosureValidation(), MessageBundle.getMessage("phoneNumberDisclosureValidation"));
		LOG.info("BMP-2514 Phone number disclosure: Correct inline validation should be displayed on submitting the page without selecting \"Phone number disclosure\" agreement.");

		Assert.assertEquals(abpRegistrationPage.getIncomeDisclosureValidation(), MessageBundle.getMessage("incomeDisclosureValidation"));
		LOG.info("BMP-2507 Income disclosure: Correct inline validation should be displayed on submitting the page without selecting \"Income Disclosure\" agreement.");

		Assert.assertEquals(abpRegistrationPage.getCBDisclosureValidation(),MessageBundle.getMessage("cbDisclosureValidation"));
		LOG.info("BMP-2455 Credit bureau disclosure: Correct inline validation should be displayed on submitting the page without selecting \"Credit Bureau\" agreement.");

		Assert.assertEquals(abpRegistrationPage.getEmploymentStatusValidation(),MessageBundle.getMessage("employmentStatusValidation"));
		LOG.info("BMP-2466 Employment Status: Correct inline validation should be displayed on leaving \"Employment Status\" field blank.");

		Assert.assertEquals(abpRegistrationPage.getLoanAmountValidation(), MessageBundle.getMessage("loanAmountValidationMessage"));
		LOG.info("BMP-2493 Loan Amount: Correct inline validation should be displayed on leaving \"Loan Amount\" field blank.");

        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
		abpRegistrationPage.clickGetRate();
        PollingUtilities.sleep(2000);
        Assert.assertFalse(
                abpRegistrationPage.isTextPresent(
                        Constants.PersonalDetailPage.PRIMARY_PHONE_BLANK_FIELD_VALIDATION, false),
                "Validation should not be thrown");
		LOG.info("BMP-2566 Mobile Phone: No validation message should be shown if Mobile Phone is empty and Home phone is not empty");
	}


	/**
	 * BMP-2509 Note should displayed on selecting loan purpose as \"business\" on register page.
	 * BMP-1551 Validation should be displayed on selecting DOB<18 years from current date.
	 *
	 * @throws AutomationException
	 */
	@Test(groups = {TestGroup.NIGHTLY})
	public void testRegisterPageOtherFieldFieldValidations() throws AutomationException{

		final ApplicationContext jobContext =
				new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage =
				(SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        final String email =
                TestDataProviderUtil.getGloballyUniqueEmailDomain("testRegisterPageOtherFieldFieldValidations", "p2pcredit");
		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);

		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

		Assert.assertEquals(abpRegistrationPage.getLoanPurposeHint("Business"), MessageBundle.getMessage("businessLoanPurposeHint"), "Hint is incorrect");
		LOG.info("BMP-2509 Note should displayed on selecting loan purpose as \"business\" on register page.");

		abpRegistrationPage.enterDateOfBirth(MessageBundle.getMessage("invavidDOB"));
        abpRegistrationPage.clickGetRate();
        PollingUtilities.sleep(2000);
        Assert.assertTrue(
                abpRegistrationPage.isTextPresent(RegistrationPageMessageConstants.DOB_MESSAGE_IDENTIFIER, false));

		LOG.info("BMP-1551 Validation should be displayed on selecting DOB<18 years from current date.");
	}
}
