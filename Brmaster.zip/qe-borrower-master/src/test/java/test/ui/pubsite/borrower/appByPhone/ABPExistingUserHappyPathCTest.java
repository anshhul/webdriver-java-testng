
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-453 Existing user with loan Path C:User should be able to complete the funnel from Public site.
 *
 * @author jdoriya 18-May-2016
 *
 */
public class ABPExistingUserHappyPathCTest extends PartnerLandingPageTestBase {

    private static final String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPExistingUserHappyPathCTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    /**
     * BMP-453 Existing user with loan Path C:User should be able to complete the funnel from Public site.
     *
     * @throws AutomationException
     */
    // BMP-3938 Existing user with loan Path C:User should be able to drop the
    // funnel on Loan offer page.
    // BMP-3976 Standard: Verify that correct Abandon Reason ID is displayed in
    // AbandonReason column of Prospect table when
    // dropped listing on loan offer page
    // listing on loan offer page
    // BMP-3986 Existing user with loan Path C:User should be navigated to
    // Register page on submitting Enter Your password page
    // with correct password.
    // BMP-3983 Existing user with loan Path C:User should be navigated to Enter
    // Your password page from Password creation mail of
    // Path C should be triggered to borrower .
    // BMP-3968 Existing user with loan Path C:Password creation mail of Path C
    // should be triggered to borrower on dropping the
    // funnel on loan offer page.
    // BMP-3949 Existing user with loan Path C:Correct details should be
    // displayed on Register page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserHappyPathC() throws AutomationException {
        LOG.info("~~~~~~~~~~Executing: testExistingUserHappyPathC~~~~~~~~~~~~~~~~~~~~~`");
        String urlFromWeb = null;
        // login to support site
        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
                    .getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            final String email = getUserForEnvironment("testExistingUserHappyPathC");
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            // Clean Existing User for new listing creation
            final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            final List<Map<String, Object>> listings = circleOneDBConnection
                    .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
            listings.get(0).get("id").toString();
            listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);

            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            // click on choose rate button
            abpRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG));
            PollingUtilities.sleep(3000);
            abpOfferPage.getABPPathCUrl();
            abpOfferPage.clickOnCompleteLater();
            // wait for complete later modal to appear
            PollingUtilities.sleep(4000);
            Assert.assertTrue(abpOfferPage.getCompleteLaterAsElement().isDisplayed());
            LOG.info("BMP-3938 Existing user with loan Path C:User should be able to drop the funnel on Loan offer page.");
            // select abandon reason for flow
            abpOfferPage.selectAbandonReason("Miscellaneous");
            // submit the abandon reason
            abpOfferPage.clickOnSubmitAbandonReason();
            PollingUtilities.sleep(4000);
            Assert.assertTrue(abpOfferPage.getCompleteLaterModalHeader().getText().contains("Success!"));
            // verify prospect details for the user
            final List<Map<String, Object>> prospectInfo = queryCircleOne(
                    String.format(MessageBundle.getMessage("prospectTableQuery"), email));
            PollingUtilities.sleep(2000);
            Assert.assertTrue(prospectInfo.get(0).get("AbandonReason").toString().equalsIgnoreCase("8"),
                    "Abandon Reason Id = 8 should be stored");
            LOG.info(
                    "BMP-3976 Standard: Verify that correct Abandon Reason ID is displayed in AbandonReason column of Prospect table when dropped listing on loan offer page");

            urlFromWeb = abpOfferPage.getABPPathCUrl();
            		verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
            Assert.assertNotNull(urlFromWeb);
     }
        try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
                webDriverConfig, URLUtilities.getScheme(urlFromWeb),
                URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info(
                    "BMP-3983 Existing user with loan Path C:User should be navigated to Enter Your password page from Password creation mail of Path C should be triggered to borrower .");
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            LOG.info(
                    "BMP-3968 Existing user with loan Path C:Password creation mail of Path C should be triggered to borrower on dropping the funnel on loan offer page.");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(urlFromWeb);

            Assert.assertTrue(publicSiteRegistrationPage.verifyUserDetailsPreFilled());

            LOG.info("BMP-3949 Existing user with loan Path C:Correct details should be displayed on Register page");
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
            LOG.info(
                    "BMP-3986 Existing user with loan Path C:User should be navigated to Register page on submitting Enter Your password page with correct password.");
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));

            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            PollingUtilities.sleep(3000);
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();

            Assert.assertNotNull(publicSiteBankAccountInfoPage);
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
                 /*   .clearAndEnterBankInfoForExistingUser(
                            getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));*/
            publicSiteThankYouPage.clickGoToMyAccountPage();
            LOG.info("ABP  Path C Prior Borrower ListingID is:" + listingID);
            LOG.info(
                    "BMP-453 Existing user with loan Path C:User should be able to complete the funnel from Public site.");
            LOG.info("~~~~~~~~~~testExistingUserHappyPathC--PASSED~~~~~~~~~~~~~~~~~~~~~`");
        }

    }

}
