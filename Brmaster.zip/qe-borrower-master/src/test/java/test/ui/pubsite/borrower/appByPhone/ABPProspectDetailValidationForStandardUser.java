package test.ui.pubsite.borrower.appByPhone;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja BMP-3965:Standard: Verify that correct value is displayed in
 *         OriginalProspect column of LoanOfferScoreDetail table in prospect db.
 * 
 * 
 */
public class ABPProspectDetailValidationForStandardUser extends PartnerLandingPageTestBase {

	private static final String ABP_PARTNER_CHANNEL = "Direct Mail";
	protected static final Logger LOG = Logger
			.getLogger(ABPProspectDetailValidationForStandardUser.class.getSimpleName());
	/*
	 * @Autowired SupportSiteLandingPage supportSiteLandingPage;
	 */
	@Autowired
	OutlookWebAppLoginPage outlookAbpWebAppPage;

	@Test(groups = { TestGroup.NIGHTLY })
	void testLoanOfferScoreDetailForStandardUser() throws AutomationException {

		LOG.info("~~~~~~~~~Executing: testLoanOfferScoreDetailForStandardUser~~~~~~~~~~~~~~~~~~~~");
		// login to support site
		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");

		supportSiteLandingPage.deleteAllCookies();
		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
		// supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);

		final String email = getUserForEnvironment("testExistingUserHappyPathA");
		final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
		final String userId = userInfo.getUserIDByEmail(email);
		// Clean Existing User for new listing creation
		final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
		final List<Map<String, Object>> listings = circleOneDBConnection
				.executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
		listings.get(0).get("id").toString();
		listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
		// navigate to home page and select default abp partner as direct mail
		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

		LOG.info("ABP User email is" + email);
		supportSiteMainPage.enterEmailAddress(email);

		// click on start application button
		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

		// select all disclosures agreements
		abpRegistrationPage.clickOnDisclosures();
		LOG.info("CSA user agreed to disclosures for borrower");
		abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
		abpRegistrationPage
				.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
		abpRegistrationPage
				.enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
		abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
		abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
		LOG.info("CSA user entered the loanamount for borrower");
		abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
		LOG.info("CSA user select loan purpose for borrower");
		final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

		// click on choose rate button
		final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

		Assert.assertTrue(abpPersonalDetailPage.isSSNDisabled());

		// csa is submitting personal detail for prior borrower
		abpPersonalDetailPage.fillPersonalDetailsForPriorBorrower(
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

		final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
		// enter bank details
		Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
		abpBankInfoPage.fillBankInfoForPriorBorrower(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
		// CSA thank you page is displayed
		final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
		// assert thank you page context
		Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
				Constants.ThankYourPage.ABPTHANKYOUHEADER);

		// Verify abp mail box and retrieve the finish request url for borrower
		abpThankYouPage.close();
		final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));

		// Borrower finish loan request and complete listing
		try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
				webDriverConfig, URLUtilities.getScheme(urlFromWeb),
				URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
			abpLandingPage.setPageElements(pageElements);

			abpLandingPage.clickElectronicSignatureCheckBox();
			abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
			final PublicSiteRegistrationPage publicSiteRegistrationPage = abpLandingPage.reviewYourOffer(urlFromWeb);
			// Assert.assertTrue(publicSiteRegistrationPage.isRegisterPageDisplayed());

			LOG.info("User landed on Landing Page and start new listing");
			publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

			final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

			final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
			LOG.info("User navigate to Personal detail Page");
			Assert.assertNotNull(personalDetailPage);
			// Submit the general personal details
			personalDetailPage
					.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));

			personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
			personalDetailPage
					.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
			personalDetailPage
					.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
			final String expectedOccupationID = personalDetailPage
					.GetOccupationId(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
			personalDetailPage
					.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
			personalDetailPage.enterStartOfEmployment(
					getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

			final PublicSiteTruthInLendingDisclosurePage truthInLendingDisclosurePage = personalDetailPage
					.clickContinue();

			truthInLendingDisclosurePage.confirmElectronicSignature();
			final String ListingID = truthInLendingDisclosurePage.getListingIdFromTILAContent();
			final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = truthInLendingDisclosurePage
					.clickContinue();

			Assert.assertNotNull(publicSiteBankAccountInfoPage);
			final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage
					.clearAndEnterBankInfoForExistingUser(
							getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
							getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
							getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
							getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
							getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
							getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
			publicSiteThankYouPage.clickGoToMyAccountPage();

			// Get the user ID
			final List<Map<String, Object>> userIDTable = queryCircleOne(
					MessageBundle.getMessage("userIdFromEmail").replace("{email}", email));
			String userID = userIDTable.get(0).get("UserID").toString();

			// Verify the values displayed in table Prospect
			final List<Map<String, Object>> prospectTable = queryCircleOne(
					MessageBundle.getMessage("loanOfferScoreDetailQuery").replace("{UserID}", userID));
			String value = prospectTable.get(0).get("Value").toString();

			// Verify Prospect Table details
			final List<Map<String, Object>> abandonReasonQuery = queryCircleOne(
					MessageBundle.getMessage("abandonReasonIdQuery").replace("{emailAddress}", email));
			Assert.assertTrue(value.trim().contains(abandonReasonQuery.get(0).get("OfferCode").toString().trim()),
					"Value should be equal to Offercode stored in the Prospect");
			LOG.info(
					"BMP-3965:Standard: Verify that correct value is displayed in OriginalProspect column of LoanOfferScoreDetail table in prospect db.");

		}
	}
}
