
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerWithdrawListingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * BMP-455 Existing borrower with Withdrawn listing should be navigated to
 * Pre-Popped Register page on sign in through SignIn modal on Register page.
 * GEAR-851 Verify that sign-in modal is displayed if existing user comes from register page without logging in.
 *
 * @author hisharma
 *
 */
public class BorrowerWithdrawnListingSignInModelTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(BorrowerWithdrawnListingSignInModelTest.class.getSimpleName());

	/**
	 *
	 * GEAR-851 Verify that sign-in modal is displayed if existing user comes from register page without logging in.
	 * BOR-4652 Existing borrower with Withdrawn listing should be navigated to Pre-Popped Register page on sign in through SignIn modal on Register page.
	 *
	 * @throws AutomationException
	 */
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
	public void verifySignInModalWithdrawnLlisting() throws AutomationException {
		ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"public_site/spring/public_site_context.xml");

		final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
				.getBean("publicSitePreRegistrationPage");
		final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage
				.checkYourRate();

		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSignInModalWithdraw");
		publicSiteRegistrationPage.fillRegistrationForm(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
				Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
				Constant.COMMON_PASSWORD,
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

		publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

		final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
		final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
		// Verify new Personal detail Header text

		personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
				getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

		final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

		tilaPage.confirmElectronicSignature();

		final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
		final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
				.submitManualBankOption();
		// User added general Bank details with routing no
		final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.enterBankInfo(
				getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG), "Savings",
				getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
				getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

		// User navigate to Thank you Page and clicked on go to my account
		// button
		LOG.info("User navigate to Thank you  Page");
		final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
		accountOverviewPage
				.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
		accountOverviewPage.waitForAccountOverviewPageToLoad();
		accountOverviewPage.dismissCongratulationWelcomeModal();
		if (accountOverviewPage.isElementPresentOnPage(By.linkText(pageElements.get("withdrawRequest_link")))) {
			accountOverviewPage.clickWithdrawYourRequestLink();
			LOG.info("Borrower clicked for withdraw listing request");
			final BorrowerWithdrawListingPage borrowerWithdrawListingPage = accountOverviewPage.clickWithdrawLoanRequest();
			borrowerWithdrawListingPage.clickWithdrawListing();
			Assert.assertTrue(borrowerWithdrawListingPage.getWithdrawListingStatusAsElement().getText()
					.contains("Your listing has been withdrawn."));
            borrowerWithdrawListingPage.close();
		} else {
			LOG.info("Borrower Listing status is already in WITHDRAWN status");
		}

		jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
		final PublicSitePreRegistrationPage modernizePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
				.getBean("modernizePreRegistrationPage");
		final PublicSiteRegistrationPage publicSiteRegistrationAgainPage = modernizePreRegistrationPage.checkYourRate();

		publicSiteRegistrationAgainPage.enterEmailAddress(email);
		LOG.info("User email addresss is:" + email);
		// login modal displayed
		Assert.assertTrue(publicSiteRegistrationAgainPage.getLoginModalAsElement().isDisplayed());
		publicSiteRegistrationAgainPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
		// User accept the agreement on Reg Page
		publicSiteRegistrationAgainPage.clickOnSignInToContinue();
		LOG.info("Existing Borrower Logged-in via Sign-modal");
		Assert.assertFalse(publicSiteRegistrationAgainPage.isFieldByIdEditable("email"));
		Assert.assertFalse(publicSiteRegistrationAgainPage.isFieldByIdEditable("password"));
        Assert.assertFalse(publicSiteRegistrationAgainPage.isFieldByIdEditable("dateOfBirth_masked"));
		Assert.assertFalse(publicSiteRegistrationAgainPage.isFieldByIdEditable("firstName"));
		Assert.assertFalse(publicSiteRegistrationAgainPage.isFieldByIdEditable("lastName"));
		Assert.assertTrue(publicSiteRegistrationAgainPage.isFieldByIdEditable("zip"));
		Assert.assertTrue(publicSiteRegistrationAgainPage.isFieldByIdEditable("yearlyIncome"));
		Assert.assertTrue(publicSiteRegistrationAgainPage.isFieldByIdEditable("city"));
		Assert.assertTrue(publicSiteRegistrationAgainPage.isFieldByIdEditable("homeAddress"));
		Assert.assertTrue(publicSiteRegistrationAgainPage.isEmploymentStatusDropDownEditable(),
				"Employment Status Drop Down is not Editable.");
		// verify pre-filled registration details for sign-in user
		Assert.assertTrue(publicSiteRegistrationAgainPage.getRegistrationPageHeader());
		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledEmail(email));
		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledFirstName(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledLastName(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG)));
		Assert.assertTrue(publicSiteRegistrationAgainPage
				.verifyPrefilledState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG)));

		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledZip(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).substring(0, 5)));
		Assert.assertTrue(publicSiteRegistrationAgainPage
				.verifyPrefilledCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG)));
		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledYearlyIncome(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG)));
		Assert.assertTrue(publicSiteRegistrationAgainPage
				.verifyPrefilledDOB(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG)));
		Assert.assertTrue(publicSiteRegistrationAgainPage.verifyEmploymentStatus(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG)));

		LOG.info("GEAR-851 Verify that sign-in modal is displayed if existing user comes from register page without logging in.");
		LOG.info("BOR-4652 Existing borrower with Withdrawn listing should be navigated to Pre-Popped Register page on sign in through SignIn modal on Register page.");

		publicSiteRegistrationAgainPage.clickElectronicSignatureCheckBox();
		final PublicSiteOfferPage publicSiteOfferAgainPage = publicSiteRegistrationAgainPage.clickGetYourRate(false, false);

		final PublicSitePersonalDetailPage personalDetailAgainPage = publicSiteOfferAgainPage.clickGetLoan();
		// Verify new Personal detail Header text
		personalDetailAgainPage.verifyPersonalDetailPageHeaderContent();

		// verify pre-filled for sign-in user
		Assert.assertTrue(personalDetailAgainPage
				.verifyPreFilledOccupation(getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG)));
		Assert.assertTrue(personalDetailAgainPage
				.verifyPrefilledPrimaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG)));
		Assert.assertTrue(personalDetailAgainPage.verifyPreFilledSecondaryPhone(
				getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG)));
		Assert.assertTrue(personalDetailAgainPage.getEmployerName()
				.contains(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG)));
		Assert.assertTrue(personalDetailAgainPage.verifyStartOfEmploymentDate(
				getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG)));
		Assert.assertTrue(personalDetailAgainPage.getSsnPopulated());
		PollingUtilities.sleep(2000);
		final PublicSiteTruthInLendingDisclosurePage tilaAgainPage = personalDetailAgainPage.clickContinue();
		tilaAgainPage.confirmElectronicSignature();
		final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilaAgainPage.clickContinue();
		// verify bank info pre-filled details for sign-in user on existing Bank
		// page (old page)
		Assert.assertTrue(bankAccountInfoPage
				.verifyBankNamePrefilled(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG)));
		Assert.assertTrue(bankAccountInfoPage
				.verifyAccountNumberPrefilled(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG)));
		Assert.assertTrue(bankAccountInfoPage
				.verifyRoutingNumberPrefilled(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG)));
	}
}
