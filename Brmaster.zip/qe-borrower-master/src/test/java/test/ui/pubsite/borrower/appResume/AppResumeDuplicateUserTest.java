
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteEditMemberStatus;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.io.UnsupportedEncodingException;

public class AppResumeDuplicateUserTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeDuplicateUserTest.class.getSimpleName());
    private static final String OTHER_REASON = "Other";
    private static final String DUPLICATE_NOTE = "Duplicate";


    // GEAR-2654 Verify resume modal for funnel dropped user who is Duplicate
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDuplicateUserAppResume() throws UnsupportedEncodingException, AutomationException, HttpRequestException {
        LOG.info("~~~~~~~~testDuplicateUserAppResume~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDuplicateUserAppResume");
        String altKey = null;
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Submit Register page
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // Get alternate key from cookie
            altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);
        }
        // Log into the Support site with user created above
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            memberPage.searchByEmail(email);
            final SupportBorrowerTabPage supportBorrowerTabPage = memberPage.clickOnView();
            // Click on Member "Edit" status link
            final SupportSiteEditMemberStatus supportSiteEditMemberStatus = supportBorrowerTabPage.clickOnEditStatus();

            // Update the user status to OnHold
            supportSiteEditMemberStatus.setUserStatus(OTHER_REASON, DUPLICATE_NOTE);

            Assert.assertTrue(supportBorrowerTabPage.isUserStatus(DUPLICATE_NOTE));
        }

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());

            publicSitePreRegistrationPage.checkYourRate();
            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            final PublicSiteRegistrationPage publicSiteRegistrationAgainPage =
                    publicSitePreRegistrationPage.submitAppResumeModalDeclineUser(
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            PollingUtilities.sleep(3000);
            Assert.assertFalse(publicSiteRegistrationAgainPage.verifyPrefilledEmail(email));
            LOG.info("GEAR-2654 Verify resume modal for funnel dropped user who is Duplicate");
        }
    }
}
