
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 08-Jul-2016
 *
 */
public class OfferChartForPriorABPUserOnDTSTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(OfferChartForPriorABPUserOnDTSTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // GEAR-1397 Verify that correct offer page is displayed to existing user of ABP funnel coming from DTS
    @Test(groups = {TestGroup.NIGHTLY})
    void testOfferChartForPriorABPUserOnDTS() throws AutomationException {
        map = abpPathAListing("testOfferChartForPriorABPUserOnDTS");
        final String email = map.get("EMAILADDRESS");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    publicSitePreRegistrationPage.checkYourRate();
            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);
            // Enter existing withdrawn user email
            publicSiteRegistrationPage.enterEmailAddress(email);
            PollingUtilities.sleep(4000);
            if (publicSiteRegistrationPage.isTextPresent(Constants.RegisterationPageConstants.EXISTING_USER_EMAIL_NOTIFY,
                    false)) {

                final PublicSiteSignInPage publicSiteSignInPage = publicSiteRegistrationPage.clickLogin();
                final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
                final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage1 =
                        accountOverviewPage.clickOnProsperLogo();
                publicSiteRegistrationPage =
                        publicSitePreRegistrationAgainPage1.checkYourRate();
            } else {
                publicSiteRegistrationPage.signInViaModal(email);
            }

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            Assert.assertTrue(publicSiteOfferPage.isSliderPageDisplayed());

            Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForFiveYearsDisplayed());
            Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info("GEAR-1397 Verify that correct offer page is displayed to existing user of ABP funnel coming from DTS");
        }
    }
}
