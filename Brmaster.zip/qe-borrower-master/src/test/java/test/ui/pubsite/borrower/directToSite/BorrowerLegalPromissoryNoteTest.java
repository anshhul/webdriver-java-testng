
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.util.web.borrower.common.DocParserUtil;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 16-Jun-2016
 *
 */
public class BorrowerLegalPromissoryNoteTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerLegalPromissoryNoteTest.class.getSimpleName());
    private static final String LEGAL_PROMISSORY_NOTE_URI = "/legal/promissory-note-sample/";

    // Current Promissory Note updated document content deployed on staging environment NOT on staging2
    // see comments on BMP-1575
    // TODO: Revisit the test
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testPromissoryNoteDetails() throws AutomationException, IOException, XmlException, OpenXML4JException {

        LOG.info("~~~~~~~~~~Executing: testPromissoryNoteDetails~~~~~~~~~~~~~");

        try (PublicSitePreRegistrationPage preRegistrationPage = new PublicSitePreRegistrationPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + LEGAL_PROMISSORY_NOTE_URI)) {
            preRegistrationPage.setPageElements(pageElements);
            preRegistrationPage.checkPromiseToPay();
            Assert.assertTrue(preRegistrationPage.verifyStaticContent(Constants.PromissoryNote.PROMISE_TO_PAY));

            preRegistrationPage.checkPayment();
            Assert.assertTrue(preRegistrationPage
                    .verifyStaticContent(Constants.PromissoryNote.PAYMENTS));
            preRegistrationPage.checkLateCharge();
            Assert.assertTrue(preRegistrationPage.verifyStaticContent(Constants.PromissoryNote.LATE_CHARGE));
            preRegistrationPage.checkLastUpdatedDate();
            Assert.assertTrue(preRegistrationPage.verifyStaticContent(Constants.PromissoryNote.LAST_UPADTE_DATE));

            // Verify whole promissory note content
            final DocParserUtil document = new DocParserUtil(System.getProperty("user.dir")
                    + PROMISSORY_NOTE_DOC);
            Assert.assertTrue(preRegistrationPage.verifyStaticContent(document.getDocumentContent()));
        }
    }
}
