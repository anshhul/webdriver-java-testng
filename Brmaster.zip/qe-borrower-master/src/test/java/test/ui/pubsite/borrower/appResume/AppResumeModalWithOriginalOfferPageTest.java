
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.ArrayList;
import java.util.List;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 17-feb
 *
 */
public class AppResumeModalWithOriginalOfferPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithOriginalOfferPageTest.class.getSimpleName());


    /**
     * GEAR-2548 Verify application resume modal for user Droping off on Offers page GEAR-2549 Verify that app resume landing page
     * loads by appending the user alt key to the url. GEAR-2551 Verify CTA is displayed on app resume landing page saying
     * 'continue your application'. GEAR-2552 Verify on clicking "continue your application" CTA app resume modal shows up.
     * GEAR-2553 Verify user login on entering the lastname,zip,birth year details and is redirected to Offers page GEAR-2555
     * Verify app resume modal login with user dropping off on original offer page. GEAR-2557 Verify funnel flow beyond offers
     * page for user dropping off on offers page
     *
     * @throws AutomationException
     */
    // GEAR-2703 Same offer page should be shown with app resume after navigating to app resume landing page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalWithOriginalOfferPage() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalWithOriginalOfferPage~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            // Apply Original Offers page flag
            publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.ORIGINAL_FLAG);

            // Submit Register page
            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAppResumeModalWithOriginalOffer");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage offersPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            Assert.assertTrue(offersPage.isOriginalOfferPageDisplayed(), "Original Offers page should be displayed");

            // Get alternate key from cookie
            final String altKey = offersPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);
            // Initial Offers displayed to User
            final List<ArrayList<String>> offerDetails = offersPage.get3YearsOffersDetails();
            final String offeredApr = offersPage.getDefaultApr();
            final String monthlyPayment = offersPage.getDefaultMonthlyPayment();
            final List<ArrayList<String>> fiveYearsofferDetails = offersPage.get5YearsOffersDetails();
            PollingUtilities.sleep(2000);
            publicSitePreRegistrationPage = offersPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            LOG.info("GEAR-2549 Verify that app resume landing page loads by appending the user alt key to the url");
            LOG.info("GEAR-2551 Verify CTA is displayed on app resume landing page saying 'continue your application'");
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());
            LOG.info("GEAR-2548 Verify application resume modal for user Droping off on Offers page");
            LOG.info("GEAR-2552 Verify on clicking 'continue your application' CTA app resume modal shows up");

            // verify zipcode with invalid date i.e. excluding Int data form.

            publicSitePreRegistrationPage.enterZipCode(RandomStringUtils.random(5, true, false));

            Assert.assertTrue(publicSitePreRegistrationPage.getZipFromAppResumeModal().isEmpty());

            // Enter details in App Resume Modal
            offersPage = publicSitePreRegistrationPage.enterDetailsIntoAppResumeModal(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // Wait for offer page to load
            offersPage.waitForLoanOfferPageToLoadCompletely();

            // Get the current URL.
            String currentURL = offersPage.getCurrentURL();
            LOG.info("Current URL:" + currentURL);

            String flag = "flags=Offers-Test-Q2-2017:Original";

            String new_url = currentURL + (flag);
            LOG.info("New URL: " + new_url);

            // If Offer's page flag is not present in URL, add the flag to current URL & refresh the page.
            if(!currentURL.contains(new_url)){
                publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.ORIGINAL_FLAG_URL);
                LOG.info("URL changed successfully");
            }
            PollingUtilities.sleep(2000);

            // Verify offer page displayed
            //data-q="offers-main-offer-get-loan-button"
            Assert.assertTrue(offersPage.isGetThisLoanButtonForThreeYearsDisplayed());
            LOG.info(
                    "GEAR-2553 Verify user login on entering the lastname,zip,birth year details and is redirected to Offers page");
            LOG.info("GEAR-2555 Verify app resume modal login with user dropping off on original offer page");
            PollingUtilities.sleep(2000);
            final List<ArrayList<String>> appResume3YearsOffers = offersPage.get3YearsOffersDetails();
            PollingUtilities.sleep(2000);
            final List<ArrayList<String>> appResume5YearsOffers = offersPage.get5YearsOffersDetails();
            PollingUtilities.sleep(2000);
            final String appResumeApr = offersPage.getDefaultApr();
            final String appResumeMonthlyPayment = offersPage.getDefaultMonthlyPayment();
            // verify with initial offers displayed to User
            Assert.assertEquals(appResume3YearsOffers, offerDetails);
            Assert.assertEquals(appResume5YearsOffers, fiveYearsofferDetails);
            Assert.assertEquals(appResumeApr, offeredApr);
            Assert.assertEquals(appResumeMonthlyPayment, monthlyPayment);
            LOG.info("GEAR-2703 Same offer page should be shown with app resume after navigating to app resume landing page");

            final PublicSitePersonalDetailPage personalDetailsPage = offersPage.clickGetLoan();
            // Verify new Personal detail Header text

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PollingUtilities.sleep(1000);
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);


            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
            Assert.assertNotNull(accountOverviewPage);
            LOG.info("GEAR-2557 Verify funnel flow beyond offers page for user dropping off on offers page");
        }
    }
}
