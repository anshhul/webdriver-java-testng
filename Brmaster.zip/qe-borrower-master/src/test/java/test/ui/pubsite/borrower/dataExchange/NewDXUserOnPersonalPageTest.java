
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.RegistrationPageMessageConstants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

public class NewDXUserOnPersonalPageTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewDXUserOnPersonalPageTest.class.getSimpleName());
    private static final String NEW_USER_PASSWORD_HINT = "Create Password";


    // BMP-3729 Verify the functionality of password strength meter on DX personal details landing page
    // BMP-3730 Verify that masked SSN is displayed on DX personal details landing page if user passed the SSN in DX request
    // BMP-3734 Verify that correct details are displayed in right rail on DX personal details landing page
    // BMP-3728 Verify that Email address and Create password fields are also displayed on DX personal details landing page for
    // new user
    // BMP-3732 Verify that user is navigate to TILA page and able to complete listing on submitting DX personal details landing
    // page
    // GEAR-781 Verify that error is displayed immediately after user clicks out of password field DX landing page
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testNewUserOnPersonalPage() throws AutomationException, HttpRequestException, UnsupportedEncodingException {
        LOG.info("~~~~Executing: testNewUserOnPersonalPage~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testNewUserOnPersonalPage");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        LOG.info("DX User emailaddress is:" + email);

        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + newUri)) {
            dxLandingPage.setPageElements(pageElements);

            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertFalse(personalDetailsPage.isStaticTextDisplayed("Sass Compiling Error"));
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            final List<String> infoOnCard = personalDetailsPage.getRightRailCardInfo();

            Assert.assertEquals(infoOnCard.get(0).replace("$", "").replaceAll("\\D", ""),
                    "5000");
            Assert.assertEquals(infoOnCard.get(1), "3 years");
            LOG.info("BMP-3734 Verify that correct details are displayed in right rail on DX personal details landing page");
            Assert.assertEquals(personalDetailsPage.getUserEmailAddress().getAttribute("value"), email);
            Assert.assertFalse(personalDetailsPage.getUserEmailAddress().isEnabled());
            Assert.assertEquals(personalDetailsPage.getPasswordOnPersonalDetail().getAttribute("placeholder"),
                    NEW_USER_PASSWORD_HINT);
            LOG.info(
                    "BMP-3728 Verify that Email address and Create password fields are also displayed on DX personal details landing page for new user");

            LOG.info("BMP-3731 Verify that email address field is pre-filled and is non-editable.");
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            Assert.assertTrue(personalDetailsPage.getEmployerName()
                    .contains(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG)));

            Assert.assertTrue(personalDetailsPage.getMobilePhone()
                    .contains(Constants.UserCommonTestDetails.MOBILEAREACODE + Constants.UserCommonTestDetails.MOBILENUMBER));
            Assert.assertTrue(personalDetailsPage.getHomePhone()
                    .contains(
                            Constants.UserCommonTestDetails.HOMEPHONEAREACODE + Constants.UserCommonTestDetails.HOMEPHONENUMBER));
            Assert.assertTrue(personalDetailsPage.getWorkPhone()
                    .contains(
                            Constants.UserCommonTestDetails.WORKPHONEAREACODE + Constants.UserCommonTestDetails.WORKPHONENUMBER));

            Assert.assertTrue(personalDetailsPage.verifyStartOfEmploymentDate(Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH
                    + "/" + Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR));
            LOG.info(
                    "BMP-3726 Verify that correct personal details are displayed pre-filled if personal details are passed in DX request");
            personalDetailsPage.selectOccupation("Chemist");

            // personalDetailsPage.
            personalDetailsPage.getPasswordFieldAsElement().click();
            Assert.assertTrue(personalDetailsPage.isToolTipDisplay("Password must be at least"));
            LOG.info(
                    "GEAR-781 Verify that error is displayed immediately after user clicks out of password field DX landing page");
            // enter 1 number in Password field
            personalDetailsPage.enterPassword("1");
            Assert.assertTrue(personalDetailsPage.verifyPasswordTextColor("1 number"));
            LOG.info("GEAR-534 Verify that '1 number' in the text turns green when user enetrs a number in password field.");

            // enter 1 upper case letter in Password field
            personalDetailsPage.enterPassword("U");
            Assert.assertTrue(personalDetailsPage.verifyPasswordTextColor("1 uppercase letter"));
            LOG.info(
                    "GEAR-535 Verify that '1 uppercase letter' in the text turns green when user enetrs a uppercase letter in password field.");

            // enter 1 lower case letter in Password field
            personalDetailsPage.enterPassword("a");
            Assert.assertTrue(personalDetailsPage.verifyPasswordTextColor("1 lowercase letter"));
            LOG.info(
                    "GEAR-536 Verify that '1 lowercase letter' in the text turns green when user enetrs a lowercase letter in password field.");

            // enter 1 symbol in Password field
            personalDetailsPage.enterPassword("@");
            Assert.assertTrue(personalDetailsPage.verifyPasswordTextColor("1 symbol"));
            LOG.info("GEAR-537 Verify that '1 symbol' in the text turns green when user enetrs a symbol in password field.");

            // enter 8 characters in Password field
            personalDetailsPage.enterPassword(RandomStringUtils.random(8));
            Assert.assertTrue(personalDetailsPage.verifyPasswordTextColor("8 characters"));
            personalDetailsPage.checkPasswordMeter(RegistrationPageMessageConstants.INCORRECT_PASSWORD_ERROR_MESSAGE);
            LOG.info("BMP-3729 Verify the functionality of password strength meter on DX personal details landing page");
            personalDetailsPage.clearPasswordField();

            Assert.assertTrue(personalDetailsPage.getSSnFieldValue().contains("xxx-xx"));
            Assert.assertTrue(personalDetailsPage.getSSnFieldValue()
                    .contains(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).substring(
                            7, getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).length())));

            LOG.info(
                    "BMP-3730 Verify that masked SSN is displayed on DX personal details landing page if user passed the SSN in DX request");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            LOG.info(
                    "BMP-3725 Verify that get-offer new user is navigated to personal details landing page on accessing new landing URL");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            tilPage.getListingIdFromTILAContent();
            tilPage.confirmElectronicSignature();
            LOG.info(
                    "BMP-3732 Verify that user is navigate to TILA page and able to complete listing on submitting DX personal details landing page");
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button

            publicSiteThankYouPage.clickGoToMyAccountPage();
            publicSiteThankYouPage.close();
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final List<Map<String, Object>> lendingAccreditationRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
            Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            LOG.info("User navigate to Thank you  Page");
            LOG.info(
                    "BMP-3742 Verify that user is navigate to TILA page and able to complete listing on submitting DX personal details landing page");

            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            final ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
            // verify created date
            Assert.assertTrue(prospectInfo.getCreatedDate(email)
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                    "Correct 'CreatedDate' should be displayed");
            // verify engagementdate
            Assert.assertTrue(prospectInfo.getEngagementDate(email)
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            // verify user first name
            Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    "Correct 'FirstName' should be displayed");
            // verify user last name
            Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    "Correct 'LastName' should be displayed");
            // verify user employment status
            Assert.assertEquals(prospectInfo.getEmployementStatusID(email),
                    Constants.UserEmploymentStatus.borrowerEmployedStatusID);
            // verify user zip code
            Assert.assertEquals(prospectCreated.getAddressInfo().getZipCode(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            // verify user address
            Assert.assertEquals(prospectCreated.getAddressInfo().getAddress1().toString().trim(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).trim());
            // verify city name
            Assert.assertEquals(prospectCreated.getAddressInfo().getCity().toString(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // verify state name
            Assert.assertEquals(prospectCreated.getAddressInfo().getState().toString(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));

            // verify occupationid of the User
            Assert.assertEquals(prospectCreated.getEmploymentInfo().getOccupationId(), "8");

            // Verify detail on support site

            // login to support site
            final ApplicationContext jobContext =
                    new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            memberPage.searchByEmail(email);
            final SupportBorrowerTabPage supportBorrowerTabPage = memberPage.clickOnView();

            Assert.assertTrue(supportBorrowerTabPage.getEmploymentInfo().contains("Employed"));
            Assert.assertTrue(supportBorrowerTabPage.getEmploymentInfo().contains("Chemist"));
            Assert.assertTrue(supportBorrowerTabPage.getHomePhoneNumber().contains(
                    Constants.UserCommonTestDetails.HOMEPHONEAREACODE + Constants.UserCommonTestDetails.HOMEPHONENUMBER));
            Assert.assertTrue(supportBorrowerTabPage.getMobilePhoneNumber().contains(
                    Constants.UserCommonTestDetails.MOBILEAREACODE + Constants.UserCommonTestDetails.MOBILENUMBER));
            Assert.assertTrue(supportBorrowerTabPage.getWorkPhoneNumber().contains(
                    Constants.UserCommonTestDetails.WORKPHONEAREACODE + Constants.UserCommonTestDetails.WORKPHONENUMBER));
            LOG.info("BMP-3735 Verify that personal details are saved in circleone correctly.");
            LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");
        }
    }
}
