
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-3942 Standard: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect
 * table in prospect db BMP-3946 Standard: Verify that correct Phone Disclosure ID is displayed in Disclosure column of Prospect
 * table in prospect db BMP-3934 Standard: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of
 * Prospect table in prospect db BMP-3960 Standard: Verify that correct Support Agent ID is displayed in AgentID column of
 * Prospect table in Prospect db BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of Prospect
 * table in prospect db. BMP-3927 DM: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of
 * Prospect table in prospect db BMP-3929 DM: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau
 * Disclosure column of Prospect table in prospect db BMP-3945 DM: Verify that correct Phone Disclosure ID is displayed in Phone
 * Disclosure column of Prospect table in prospect db. BMP-3960 Standard: Verify that correct Support Agent ID is displayed in
 * AgentID column of Prospect table in Prospect db. BMP-3916 DM: Verify that correct Support Agent ID is displayed in AgentID
 * column of Prospect table in Prospect db. BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of
 * Prospect table in prospect db
 *
 * @author hnegi
 *
 */
public class ABPProspectDetailValidationTest extends PartnerLandingPageTestBase {

    private static final String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPProspectDetailValidationTest.class.getSimpleName());
    /*
     * @Autowired SupportSiteLandingPage supportSiteLandingPage;
     */
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // HINT: Merged to ABPExistingUserHappyPathATest
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testCSADetailsForStandardUser() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testCSADetailsForStandardUser~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);

        final String email = getUserForEnvironment("testExistingUserHappyPathA");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);

        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        // Verify the values displayed in table Prospect
        // verify prospect details for the user
        final List<Map<String, Object>> prospectInfo =
                queryCircleOne(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
        final List<Map<String, Object>> prospectDisclosuresTable =
                queryCircleOne(String.format(
                        MessageBundle.getMessage("prospectDisclosureQuery"), prospectInfo.get(0).get("ProspectID").toString()));

        Assert.assertTrue(prospectDisclosuresTable.get(0).get("DisclosureID").toString().equals("1500"),
                "DisclosureID = 1500 should be stored");
        Assert.assertTrue(prospectDisclosuresTable.get(1).get("DisclosureID").toString().equals("1501"),
                "DisclosureID = 1501 should be stored");
        Assert.assertTrue(prospectDisclosuresTable.get(2).get("DisclosureID").toString().equals("1502"),
                "DisclosureID = 1502 should be stored");
        LOG.info(
                "BMP-3942 Standard: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect table in prospect db");
        LOG.info(
                "BMP-3946 Standard: Verify that correct Phone Disclosure ID is displayed in Disclosure column of Prospect table in prospect db");
        LOG.info(
                "BMP-3934 Standard: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of Prospect table in prospect db");
        // click on choose rate button
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        // csa is submitting personal detail for prior borrower
        abpPersonalDetailPage.fillPersonalDetailsForPriorBorrower(
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

        final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details
        Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
        abpBankInfoPage.fillBankInfoForPriorBorrower(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);

        // Verify abp mail box and retrieve the finish request url for borrower
        abpThankYouPage.close();
        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(urlFromWeb), URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        }
        Assert.assertNotNull(prospectInfo.get(0).get("AgentID").toString(), "Agent Id should not be null");
        LOG.info(
                "BMP-3960 Standard: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");

        LOG.info(prospectInfo.get(0).get("OfferUserID").toString());
        Assert.assertNotNull(prospectInfo.get(0).get("OfferUserID"), "Loan Offer ID should be not null");
        LOG.info(
                "BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of Prospect table in prospect db");
    }

    // HINT: Merged to ABPHappyPathBWithoutEmailTest
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testCSADetailsForDMUser() throws AutomationException {
        LOG.info("~~~~~~~~~Executing: testCSADetailsForDMUser~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // supportSiteLandingPage.checkListingStatusAndCancel(EXISTING_USER_EMAIL);

        final String email = getUserForEnvironment("testExistingUserHappyPathA");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);

        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();

        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        // Verify the values displayed in table Prospect
        // verify prospect details for the user
        final List<Map<String, Object>> prospectInfo =
                queryCircleOne(String.format(MessageBundle.getMessage("prospectTableQuery"), email));
        final List<Map<String, Object>> prospectDisclosuresTable =
                queryCircleOne(String.format(
                        MessageBundle.getMessage("prospectDisclosureQuery"), prospectInfo.get(0).get("ProspectID").toString()));

        Assert.assertTrue(prospectDisclosuresTable.get(0).get("DisclosureID").toString().equals("1500"),
                "DisclosureID = 1500 should be stored");
        Assert.assertTrue(prospectDisclosuresTable.get(1).get("DisclosureID").toString().equals("1501"),
                "DisclosureID = 1501 should be stored");
        Assert.assertTrue(prospectDisclosuresTable.get(2).get("DisclosureID").toString().equals("1502"),
                "DisclosureID = 1502 should be stored");
        LOG.info(
                "BMP-3927 DM: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of Prospect table in prospect db");
        LOG.info(
                "BMP-3929 DM: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect table in prospect db");
        LOG.info(
                "BMP-3945 DM: Verify that correct Phone Disclosure ID is displayed in Phone Disclosure column of Prospect table in prospect db");
        /*
         * LOG.info(
         * "BMP-3942 Standard: Verify that correct Credit Bureau Disclosure ID is displayed in Credit Bureau Disclosure column of Prospect table in prospect db"
         * ); LOG.info(
         * "BMP-3946 Standard: Verify that correct Phone Disclosure ID is displayed in Disclosure column of Prospect table in prospect db"
         * ); LOG.info(
         * "BMP-3934 Standard: Verify that correct Income Disclosure ID is displayed in Income Disclosure column of Prospect table in prospect db"
         * );
         */
        // click on choose rate button
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        // csa is submitting personal detail for prior borrower
        abpPersonalDetailPage.fillPersonalDetailsForPriorBorrower(
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));

        final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details
        Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
        abpBankInfoPage.fillBankInfoForPriorBorrower(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);

        // Verify abp mail box and retrieve the finish request url for borrower
        abpThankYouPage.close();
        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(urlFromWeb), URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        }
        Assert.assertNotNull(prospectInfo.get(0).get("AgentID").toString(), "Agent Id should not be null");
        LOG.info(
                "BMP-3960 Standard: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");
        LOG.info(
                "BMP-3916 DM: Verify that correct Support Agent ID is displayed in AgentID column of Prospect table in Prospect db");

        LOG.info(prospectInfo.get(0).get("OfferUserID").toString());
        Assert.assertNotNull(prospectInfo.get(0).get("OfferUserID"), "Loan Offer ID should be not null");
        LOG.info(
                "BMP-3978 Standard: Verify that correct Loan Offer ID is displayed in OfferID column of Prospect table in prospect db");
    }
}
