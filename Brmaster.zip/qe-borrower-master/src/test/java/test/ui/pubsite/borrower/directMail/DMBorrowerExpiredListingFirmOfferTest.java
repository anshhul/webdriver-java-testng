
package test.ui.pubsite.borrower.directMail;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.offer.OffersUnfundedRequest;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerWithdrawListingPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteCreditReportListingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 *
 * @author hnegi 02-june-2016
 *
 */
public class DMBorrowerExpiredListingFirmOfferTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerExpiredListingFirmOfferTest.class.getSimpleName());
    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    @Autowired
    IPlatformOffer platFormOffer;


    // GEAR-927 Verify that Forgot Password link is displayed on unfunded loan landing page.
    // GEAR-883 Verify that Forgot Password link displayed on unfunded loan landing page is functional.
    // GEAR-924 Verify that user with expired DM listing created using valid DM offer code from DM landing page receives firm
    // offer of credit email.
    // GEAR-930 Verify that correct user's first name is displayed on unfunded loan landing page
    // GEAR-911 Verify the happy path of firm offers for EP new user who is not from MA state.
    // GEAR-935 Verify that offers for only $2,000 are displayed to the user on Offers page.
    // GEAR-879 Verify that user is able to select the offer for 3 years and submit the offers page.
    // GEAR-869 Verify that user is able to submit Personal details page and navigate to tILA page.
    // GEAR-911 Verify the happy path of firm offers for EP new user who is not from MA state.
    // GEAR-926 Verify that user is able to submit TILA and complete the listing for 3 years offer.
    // GEAR-923 Verify that user is navigated to loan offer page on submitting unfunded loan landing page with correct valid
    // password.
    // GEAR-907 Verify that user is navigated to correct page on clicking ' Prosper privacy policies ' link on unfunded loan
    // landing page
    // GEAR-899 Verify that user is navigate
    // GEAR-901 Verify that 'click here' text in firm offer of credit email is hyperlinked
    // GEAR-921 Verify that user is navigated to correct page on clicking ' Terms of Use' link on unfunded loan landing page
    // GEAR-872 Verify that user is able to submit unfunded loan landing page with correct valid password.
    @Test(groups = {TestGroup.NIGHTLY})
    void testExpiredDMFirmOfferUser() throws AutomationException, InterruptedException,
            HttpRequestException {
        LOG.info("Executing: testExpiredDMFirmOfferUser");

        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            final String firstName = publicSiteRegistrationPage.getFirstName();
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = TestDataProviderUtil.getGloballyUniqueEmailDomain("testExpiredDMFirmOfferUser", "p2pcredit");
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage
                    .enterCity(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            publicSiteRegistrationPage
                    .selectState(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.STATE_TAG));
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage.handleSSNPage(getDMValidOfferCodeUserData().get(
                    Constants.RegisterationPageConstants.SSN_TAG));

            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            final String listingID = tilPage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            borrowerThankYouPage.clickGoToMyAccountPage();

            final UserEmailDAO userIfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userIfo.getUserIDByEmail(emailAddress);

            final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            listingInfo.updateListingStatusByUserId(5, Long.valueOf(userId));
            PollingUtilities.sleep(2000);
            // verify firm offer email for expired listing DM User
            final OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingID, userId));
            // Response delay
            PollingUtilities.sleep(10000);
            Preconditions.checkNotNull(offerResponse, "Unfunedoffer Response is NULL");
            final String altKey = offerResponse.getUser().getAltKey();
            verifyWebMail(outlookAbpWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), emailAddress,
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("fundingListingThroughProsper"), MessageBundle.getMessage("loanExpiredMessage"));
            LOG.info("GEAR-901 Verify that 'click here' text in firm offer of credit email is hyperlinked");
            LOG.info(
                    "GEAR-924 Verify that user with expired DM listing created using valid DM offer code from DM landing page receives firm offer of credit email");

            borrowerThankYouPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/borrower/#/promotions/firm-offer/alt-code/" + altKey));
            // default wait till complete section's content is displayed
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerLandingPage.getEmailMarketingSection());
            PollingUtilities.sleep(2000);

            Assert.assertTrue(partnerLandingPage.isForgotYourPasswordLinkDisplayed());
            LOG.info(
                    "GEAR-927 Verify that Forgot Password link is displayed on unfunded loan landing page");

            final PublicSiteRequestEmailForChangePasswordPage changePasswordPage =
                    partnerLandingPage.clickOnForgotYourPasswordLink();
            Assert.assertTrue(changePasswordPage.isChangePasswordPageDisplayed());
            LOG.info(
                    "GEAR-883 Verify that Forgot Password link displayed on unfunded loan landing page is functional");

            LOG.info(
                    "GEAR-930 Verify that correct user's first name is displayed on unfunded loan landing page");
            changePasswordPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/borrower/#/promotions/firm-offer/alt-code/" + altKey));
            // default wait till complete section's content is displayed
            Assert.assertTrue(partnerLandingPage.getEmailMarketingSection());
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerLandingPage.getUserName().contains(firstName));
            final PublicSiteCreditReportListingPage creditReportListingPage = partnerLandingPage.clickOnTermsOfUse();
            creditReportListingPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(creditReportListingPage.getPageContent().contains(
                    Constants.RegisterationPageConstants.TERMS_OF_USE_PAGE_TITLE));
            creditReportListingPage.closeAllButOneBrowser();
            LOG.info(
                    "GEAR-921 Verify that user is navigated to correct page on clicking ' Terms of Use' link on unfunded loan landing page");
            final PublicSiteOfferPage offerPage = partnerLandingPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            LOG.info("GEAR-872 Verify that user is able to submit unfunded loan landing page with correct valid password.");
            Assert.assertEquals(offerPage.getOfferCountOnOldOfferPage(), 1);
            Assert.assertEquals(offerPage.getSelectedOfferAmount(), "$2,000");
            LOG.info(
                    "GEAR-923 Verify that user is navigated to loan offer page on submitting unfunded loan landing page with correct valid password.");
            LOG.info(
                    "GEAR-911 Verify the happy path of firm offers for EP new user who is not from MA state");
            LOG.info(
                    "GEAR-935 Verify that offers for only $2,000 are displayed to the user on Offers page");

            Assert.assertTrue(publicSiteOfferPage.verifyTrusteFooterLink());
            publicSiteOfferPage.closeAllButOneBrowser();

            Assert.assertTrue(publicSiteOfferPage.verifyProsperPrivacyPolicyLink());
            publicSiteOfferPage.closeAllButOneBrowser();
            Assert.assertTrue(publicSiteOfferPage.verifyWebBankPrivacyPolicyLink());
            LOG.info(
                    "GEAR-907 Verify that user is navigated to correct page on clicking ' Prosper privacy policies ' link on unfunded loan landing page");
            publicSiteOfferPage.closeAllButOneBrowser();
            LOG.info(
                    "GEAR-899 Verify that user is navigated to correct page on clicking ' Webbank ' link on unfunded loan landing page");
            final PublicSitePersonalDetailPage detailPage = offerPage.clickGetLoan();
            Assert.assertTrue(detailPage.isPersonalDetailsPageDisplayed());
            LOG.info(
                    "GEAR-879 Verify that user is able to select the offer for 3 years and submit the offers page");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = detailPage.clickContinue();
            Assert.assertTrue(disclosurePage.isTruthInLendingDisclosurePageDisplayed());
            LOG.info(
                    "GEAR-869 Verify that user is able to submit Personal details page and navigate to tILA page");
            LOG.info(
                    "GEAR-911 Verify the happy path of firm offers for EP new user who is not from MA state");
            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankInfoAgainPage = disclosurePage.clickContinue();
            final PublicSiteThankYouPage borrowerThankYouAgainPage = bankInfoAgainPage.clickFinish();
            borrowerThankYouAgainPage.clickGoToMyAccountPage();
            LOG.info(
                    "GEAR-926 Verify that user is able to submit TILA and complete the listing for 3 years offer");
        }
    }

    // GEAR-932 Verify that user with cancelled DM listing created using valid DM offer code from DM landing page do not receive
    // firm offer of credit email
    @Test(groups = {TestGroup.NIGHTLY})
    void testCancelledDmListingFirmOffer() throws AutomationException, HttpRequestException {
        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            final String email =
                    TestDataProviderUtil.getGloballyUniqueEmailDomain("testCancelledDmListingFirmOffer", "p2pcredit");
            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.getFirstName();
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(email);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            final String listingID = tilPage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            borrowerThankYouPage.clickGoToMyAccountPage();
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            // Clean Existing User for new listing creation
            final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            final List<Map<String, Object>> listings = circleOneDBConnection
                    .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
            listings.get(0).get("id").toString();
            listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
            // verify firm offer email for expired listing DM User
            final OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingID, userId));
            // Response delay
            PollingUtilities.sleep(10000);
            Assert.assertNull(offerResponse);
            LOG.info(
                    "GEAR-932 Verify that user with cancelled DM listing created using valid DM offer code from DM landing page do not receive firm offer of credit email");
        }

    }

    // GEAR-933 Verify that offers in firm email expires if user creates new draft listing from DTS.
    @Test(groups = {TestGroup.NIGHTLY})
    void testDraftListingDmFirmOffer() throws AutomationException, HttpRequestException {
        LOG.info("~~~~~~~~~~Executing: testDraftListingDmFirmOffer~~~~~~~~~~~`");
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testDraftListingDmFirmOffer", "p2pcredit");
        final String firmOfferUrlDmUser = createDmFirmOfferUser(email);
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
            PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();
            // Enter existing withdrawn user email
            publicSiteRegistrationPage.enterEmailAddress(email);
            LOG.info("User email addresss is:" + email);
            // login modal displayed
            /*
             * Assert.assertTrue(publicSiteRegistrationPage.getLoginModalAsElement().isDisplayed()); // User entered the common
             * Password: "Password23" publicSiteRegistrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD); // User
             * accept the agreement on Reg Page publicSiteRegistrationPage.clickOnSignInToContinue();
             */

            if (publicSiteRegistrationPage.isTextPresent(Constants.RegisterationPageConstants.EXISTING_USER_EMAIL_NOTIFY, false)) {

                final PublicSiteSignInPage publicSiteSignInPage = publicSiteRegistrationPage.clickLogin();
                final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
                if (accountOverviewPage.isAccountOverviewPageDisplayed() == false) {
                    accountOverviewPage.selectFromUserHeaderDropdown("Your Loans");
                }
                final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = accountOverviewPage.clickOnProsperLogo();
                publicSiteRegistrationPage =
                        publicSitePreRegistrationAgainPage.checkYourRate();
            } else {
                publicSiteRegistrationPage.signInViaModal(email);
            }

            publicSiteRegistrationPage
                    .enterCity(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            publicSiteRegistrationPage
                    .selectState(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.STATE_TAG));
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
            final PublicSiteOfferPage publicSiteOfferAgainPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferAgainPage.clickGetLoan();
            personalDetailsPage.verifyPersonalDetailPageHeaderContent();
            final PartnerLandingPage partnerLandingPage = personalDetailsPage.goToPartnerLandingPage();
            partnerLandingPage.goTo(firmOfferUrlDmUser);
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerLandingPage.getEmailMarketingSection());

            final PublicSiteOfferPage offerPage = partnerLandingPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            Assert.assertNotEquals(offerPage.getOfferCountOnOldOfferPage(), 1);
            Assert.assertEquals(offerPage.getSelectedOfferAmount(), "$2,000");
            LOG.info("GEAR-933 Verify that offers in firm email expires if user creates new draft listing from DTS.");
        }
    }

    // GEAR-871 Verify that offers in firm email expires if user creates new draft listing from DM without offer code
    @Test(groups = {TestGroup.NIGHTLY})
    void testDmDraftListingDmFirmOffer() throws AutomationException, HttpRequestException {
        LOG.info("~~~~~~~~~~Executing: testDmDraftListingDmFirmOffer~~~~~~~~~~~`");
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testDraftListingDmFirmOffer", "p2pcredit");
        final String firmOfferUrlDmUser = createDmFirmOfferUser(email);
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            // submit DM Landing Page with invalid OfferCode
            partnerLandingPage.submitDmOfferWidgetWithInvalidOfferCode(
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                    "#####");

            // dm offer dialog box will be displayed
            Assert.assertTrue(partnerLandingPage.getDMOfferValidationDialogAsElement().size() == 1);

            // dm offer dialog header content
            Assert.assertEquals(partnerLandingPage.getDMOfferDialogHeader(), Constants.PartnerLandingPage.DMOFFERDIALOGHEADER);

            // click on continue anyway for prospect
            PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnContinueAnyway();
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                Assert.assertTrue(publicSiteRegistrationPage.getNumberOfPanes() > 0,
                        "NEW REGISTRAION PAGE IS DISPLAYED TO DM USER");
            }
            publicSiteRegistrationPage.enterEmailAddress(email);
            LOG.info("User email addresss is:" + email);
            // login modal displayed
            /*
             * Assert.assertTrue(publicSiteRegistrationPage.getLoginModalAsElement().isDisplayed()); // User entered the common
             * Password: "Password23" publicSiteRegistrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD); // User
             * accept the agreement on Reg Page publicSiteRegistrationPage.clickOnSignInToContinue();
             */

            if (publicSiteRegistrationPage.isTextPresent(Constants.RegisterationPageConstants.EXISTING_USER_EMAIL_NOTIFY, false)) {

                final PublicSiteSignInPage publicSiteSignInPage = publicSiteRegistrationPage.clickLogin();
                final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
                if (accountOverviewPage.isAccountOverviewPageDisplayed() == false) {
                    accountOverviewPage.selectFromUserHeaderDropdown("Your Loans");
                }
                final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = accountOverviewPage.clickOnProsperLogo();
                publicSiteRegistrationPage =
                        publicSitePreRegistrationAgainPage.checkYourRate();
            } else {
                publicSiteRegistrationPage.signInViaModal(email);
            }

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            personalDetailPage.verifyPersonalDetailPageHeaderContent();
            final PartnerLandingPage partnerLandingAgainPage = personalDetailPage.goToPartnerLandingPage();
            partnerLandingAgainPage.goTo(firmOfferUrlDmUser);
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerLandingAgainPage.getEmailMarketingSection());

            final PublicSiteOfferPage offerPage = partnerLandingAgainPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            Assert.assertNotEquals(offerPage.getOfferCountOnOldOfferPage(), 1);
            Assert.assertEquals(offerPage.getSelectedOfferAmount(), "$2,000");
            LOG.info(
                    "GEAR-871 Verify that offers in firm email expires if user creates new draft listing from DM without offer code");
        }
    }

    // GEAR-862 Verify that offers in firm email expires if user creates new draft listing from ABP
    @Test(groups = {TestGroup.NIGHTLY})
    void testAbpDraftListingDmFirmOffer() throws AutomationException, HttpRequestException {
        LOG.info("~~~~~~~~~~Executing: testAbpDraftListingDmFirmOffer~~~~~~~~~~~`");
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("abpDraftListingDmFirmOffer", "p2pcredit");
        final String firmOfferUrlDmUser = createDmFirmOfferUser(email);
        String pathAUrl = null;
        // login to support site
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // enter bank details
            Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
            // abpBankInfoPage.fillBankInfoForPriorBorrower(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);
            pathAUrl = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        // Use the generated ABP PathA URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
            disclosurePage.getListingIdFromTILAContent();
            disclosurePage.confirmElectronicSignature();
            final PartnerLandingPage partnerLandingPage = disclosurePage.goToPartnerLandingPage();
            partnerLandingPage.goTo(firmOfferUrlDmUser);
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerLandingPage.getEmailMarketingSection());

            final PublicSiteOfferPage offerPage = partnerLandingPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            Assert.assertNotEquals(offerPage.getOfferCountOnOldOfferPage(), 1);
            Assert.assertEquals(offerPage.getSelectedOfferAmount(), "$2,500");
            LOG.info("GEAR-862 Verify that offers in firm email expires if user creates new draft listing from ABP");
        }

    }

    // GEAR-909 Verify that user with withdrawn listing created from DM Scanning do not receive firm offer of credit email
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testWithDrawnListingDmFirmOffer()
            throws UnsupportedEncodingException, AutomationException, HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~~~~Executing test : testWithDrawnListingDmFirmOffer~~~~~~~~~~~~~~~~~~");
        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            final String email =
                    TestDataProviderUtil.getGloballyUniqueEmailDomain("testCancelledDmListingFirmOffer", "p2pcredit");
            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.getFirstName();
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            publicSiteRegistrationPage
                    .enterCity(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            publicSiteRegistrationPage
                    .selectState(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(email);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            final String listingID = tilPage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            borrowerThankYouPage.clickGoToMyAccountPage();
            borrowerThankYouPage.close();

            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final ApplicationContext jobContext =
                    new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
            final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
            final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
            // Hack for Signin page for logged-in User
            if (accountOverviewPage.getWindowLocationHref().contains("signin")) {
                accountOverviewPage
                        .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                accountOverviewPage.dismissCongratulationWelcomeModal();
            }
            accountOverviewPage.clickWithdrawYourRequestLink();
            LOG.info("Borrower clicked for withdraw listing request");
            final BorrowerWithdrawListingPage borrowerWithdrawListingPage = accountOverviewPage.clickWithdrawLoanRequest();
            borrowerWithdrawListingPage.clickWithdrawListing();
            Assert.assertTrue(borrowerWithdrawListingPage.getWithdrawListingStatusAsElement().getText()
                    .contains("Your listing has been withdrawn."));
            final OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingID, userId));
            // Response delay
            PollingUtilities.sleep(10000);
            Assert.assertNull(offerResponse);
            LOG.info(
                    "GEAR-909 Verify that user with withdrawn listing created from DM Scanning do not receive firm offer of credit email");
        }
    }

    final String createDmFirmOfferUser(String email) throws AutomationException, HttpRequestException {
        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            final String firstName = publicSiteRegistrationPage.getFirstName();
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            publicSiteRegistrationPage
                    .enterCity(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            publicSiteRegistrationPage
                    .selectState(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.STATE_TAG));

            // Generate Random email for borrower
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(email);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            final String listingID = tilPage.getListingIdFromTILAContent();
            final PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            borrowerThankYouPage.clickGoToMyAccountPage();

            final UserEmailDAO userIfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userIfo.getUserIDByEmail(email);

            final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            listingInfo.updateListingStatusByUserId(5, Long.valueOf(userId));
            PollingUtilities.sleep(2000);
            // verify firm offer email for expired listing DM User
            final OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingID, userId));
            // Response delay
            PollingUtilities.sleep(10000);
            Preconditions.checkNotNull(offerResponse, "Unfunedoffer Response is NULL");
            final String altKey = offerResponse.getUser().getAltKey();
            verifyWebMail(outlookAbpWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), email,
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("fundingListingThroughProsper"), MessageBundle.getMessage("loanExpiredMessage"));

            final String firmOfferUrl = String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/borrower/#/promotions/firm-offer/alt-code/" + altKey);
            borrowerThankYouPage.goTo(firmOfferUrl);
            PollingUtilities.sleep(4000);
            Assert.assertTrue(partnerLandingPage.getEmailMarketingSection());
            PollingUtilities.sleep(2000);

            Assert.assertTrue(partnerLandingPage.getUserName().contains(firstName));
            final PublicSiteOfferPage offerPage = partnerLandingPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            Assert.assertEquals(offerPage.getOfferCountOnOldOfferPage(), 1);
            Assert.assertEquals(offerPage.getSelectedOfferAmount(), "$2,000");
            return firmOfferUrl;
        }
    }

}
