
package test.ui.pubsite.borrower.dataExchange.idv;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.DeclinedPartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.util.web.borrower.common.ModifyXMLUtil;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;
import test.ui.pubsite.borrower.dataExchange.NewDXGetOfferNewSelfEmployedUserTest;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi created on 25 Nov 2016
 */
public class DXUserIdentityVerificationTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(NewDXGetOfferNewSelfEmployedUserTest.class.getSimpleName());


    @Test(groups = {TestGroup.NIGHTLY})
    public void testFunnelForWrongLastNameAndValidSSN()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForWrongLastNameAndValidSSN~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        String invalidLastName = RandomStringUtils.random(5, true, false);
        String validSSN = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG);
        String Address = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG);
        final ModifiedXmlEntity entity =
                buildGetOfferRequest(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                        invalidLastName, validSSN, Address);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        buildPersonalPageLandingUri(referral_code, selected_offer_id);
        LOG.info("DX User emailaddress is:" + email);
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testFunnelForWrongAddressAndValidSSN()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForWrongAddressAndValidSSN~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        String lastName = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG);
        String invalidAddress = RandomStringUtils.random(5, true, false);
        String validSSN = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG);
        final ModifiedXmlEntity entity =
                buildGetOfferRequest(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                        lastName, validSSN, invalidAddress);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        buildPersonalPageLandingUri(referral_code, selected_offer_id);
        LOG.info("DX User emailaddress is:" + email);
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testFunnelForWrongLastNameAndWrongSSN()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForWrongLastNameAndWrongSSN~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        String invalidlastName = RandomStringUtils.random(5, true, false);
        String address = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG);
        String invalidSSN = Constants.UserCommonTestDetails.INTSSN;
        final ModifiedXmlEntity entity =
                buildGetOfferRequest(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                        invalidlastName, invalidSSN, address);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERINELIGIBILITYREASON);
        Assert.assertEquals(allURLs[0], Constants.dxResponseTagValue.GETOFFERINELIGIBILITYCOMMONREASON);
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testFunnelForWrongAddressAndWrongSSN()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForWrongAddressAndWrongSSN~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        String invalidAddress = RandomStringUtils.random(5, true, false);
        String invalidSSN = Constants.UserCommonTestDetails.INTSSN;
        final ModifiedXmlEntity entity =
                buildGetOfferRequest(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                		getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), invalidSSN, invalidAddress);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERINELIGIBILITYREASON);
        Assert.assertEquals(allURLs[0], Constants.dxResponseTagValue.GETOFFERINELIGIBILITYCOMMONREASON);

    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testFunnelForWrongFirstName()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForWrongFirstName~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testSelfEmployedNewDx");
        String invalidFirstName = RandomStringUtils.random(5, true, false);
        final ModifiedXmlEntity entity =
                buildGetOfferRequestWithInvalidFirstName(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                        invalidFirstName);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERINELIGIBILITYREASON);
        Assert.assertEquals(allURLs[0], Constants.dxResponseTagValue.GETOFFERINELIGIBILITYCOMMONREASON);

    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testFunnelForIncorrectSSN()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testFunnelForIncorrectSSN~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testFunnelForIncorrectSSN");
        String incorrectSSN = Constants.UserCommonTestDetails.INTSSN_HYPHEN;
        final ModifiedXmlEntity entity =
                buildGetOfferRequestWithInvalidSSN(Constants.ClientTokenUsers.creditKarmaSubProgramID, email,
                        incorrectSSN);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);

        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);

            dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            dxLandingPage.clickElectronicSignatureCheckBox();
            dxLandingPage.clickAgreeAndContinueButtonToGetRegPage();

            DeclinedPartnerLandingPage declinePage = dxLandingPage.goToDeclinePage();
            PollingUtilities.sleep(4000);
            declinePage.waitForPageToLoad("E-120");
            Assert.assertTrue(declinePage.isTextDisplayed(Constants.SSNPage.CREDIT_FILE_NOT_FOUND),
                    "Decline Message is not correct");
        }

    }

    public ModifiedXmlEntity buildGetOfferRequestWithInvalidFirstName(String clientVariant, String emailAddress,
                                                                      String firstName) throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(Constants.ClientTokenUsers.creditKarmaSubProgramID,
                firstName, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        return entity;
    }

    public ModifiedXmlEntity buildGetOfferRequestWithInvalidSSN(String clientVariant, String emailAddress,
                                                                String invalidSSN) throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(Constants.ClientTokenUsers.creditKarmaSubProgramID,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                invalidSSN,
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        return entity;
    }

    public final ModifiedXmlEntity buildGetOfferRequest(String clientVariant, String emailAddress,
                                                        String lastName, String ssn, String address)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                lastName, null,
                emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                address,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerSelfEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                ssn,
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }
}
