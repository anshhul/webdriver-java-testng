
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLoanEstimatorPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.annotation.Resource;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 17-Jun-2016
 *
 * GEAR-1462 - Verify funnel flow from loan estimator landing page
 *
 */
public class BorrowerDTSLoanEstimatorFunnelSmokeTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDTSLoanEstimatorFunnelSmokeTest.class.getSimpleName());

    @Resource
    PublicSitePreRegistrationPage loanEstimatorPreRegistrationPage;


    // AUTO-183 Loan estimator funnel - complete funnel test through loan estimator page.
    // AUTO-208 Verify funnel flow from loan estimator landing page

    @Test(groups = { TestGroup.ACCEPTANCE })
    void testDTSLoanEstimatorFunnel() throws AutomationException {
        LOG.info("~~~~~~~~Executing:   testDTSLoanEstimatorFunnel~~~~~~~~~~~");
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        // wait till estimator section appears
        loanEstimatorPage.waitForLoanEstimatorSection();
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$18,500");
        loanEstimatorPage.getloanAmount();
        PublicSiteRegistrationPage publicSiteRegistrationPage =loanEstimatorPage.clickGetCustomRate();
        // wait for Registration Page to Load
        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email = Constant.getGloballyUniqueEmail(true);
        // User entered the random email address
        LOG.info("User email addresss is:" + email);
        // User entered the common Password: "Password23"

        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null,
                getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email, Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
        LOG.info("User navigate to Personal detail Page");
        personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
        LOG.info("User navigate to TIL Page");
        publicSiteTILAPage.confirmElectronicSignature(); // User navigated to bank info page final
        PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
        // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPage.dismissCongratulationWelcomeModal();

        Assert.assertNotNull(overviewPage.getListingDetail(), "Account Overview page should be displayed");
        LOG.info("GEAR-1462 - Verified funnel flow from loan estimator landing page");
    }
}
