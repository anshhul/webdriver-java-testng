package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class VTandNYStateWithAPRTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(VTandNYStateWithAPRTest.class.getSimpleName());

	/**
	 *
	 * @author ntaneja BMP-3765:ABP Prime: Verify that VT State user receives
	 *         offers with APR =< 12% BMP-3763:ABP Prime: Verify that NY State
	 *         user receives offers with APR =< 16%
	 */

	private static String ABP_PARTNER_CHANNEL = "Direct Mail";

	@Test(groups = { TestGroup.NIGHTLY })
	public void verifyVTStateWithAPRLessThan12() throws AutomationException {

		LOG.info("Test Method Started: verifyVTStateWithAPRLessThan12");

		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");

		SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");
		supportSiteLandingPage.deleteAllCookies();
		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
		final String email = getUserForEnvironment("VTStateWithAPRLessThan12");
		LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnContinue();
		Assert.assertTrue(abpRegistrationPage.verifyUserDetailsPreFilled());
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        abpRegistrationPage.clickOnDisclosures();
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        List<String> test = abpOfferPage.getSelectedOfferDetails();
        String apr = test.get(1).replace("%", "");
        double aprcompare = Double.valueOf(apr);
        // Assert.assertTrue(abpOfferPage.IsAPRLessThan12(aprcompare));
        LOG.info("-----------------------verifyVTStateWithAPRLessThan12----------Passed");
        LOG.info("BMP-3765:ABP Prime: Verify that VT State user receives offers with APR =< 12%----------Passed");

	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void verifyNYStateWithAPRLessThan16() throws AutomationException {

		LOG.info("Test Method Started: verifyNYStateWithAPRLessThan16");
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");
		supportSiteLandingPage.deleteAllCookies();
		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
		final String email = getUserForEnvironment("NYStateWithAPRLessThan16");
		LOG.info("ABP User email is" + email);
		supportSiteMainPage.enterEmailAddress(email);
		ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnContinue();
        Assert.assertTrue(abpRegistrationPage.verifyUserDetailsPreFilled());
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        abpRegistrationPage.clickOnDisclosures();
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        List<String> test = abpOfferPage.getSelectedOfferDetails();
        String apr = test.get(1).replace("%", "");
		double aprcompare = Double.valueOf(apr);
		// Assert.assertTrue(abpOfferPage.IsAPRLessThan16(aprcompare));
		LOG.info("-----------------------verifyNYStateWithAPRLessThan16----------Passed");
		LOG.info("BMP-3763:ABP Prime: Verify that NY State user receives offers with APR =< 16%----------Passed");
	}
}
