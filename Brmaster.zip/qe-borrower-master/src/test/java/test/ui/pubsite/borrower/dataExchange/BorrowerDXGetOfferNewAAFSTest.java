
package test.ui.pubsite.borrower.dataExchange;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ProspectResponseCodes;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import test.ui.pubsite.borrower.dataExchange.cases.BorrowerDXGetOfferNewAAFSTestCase;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class BorrowerDXGetOfferNewAAFSTest extends DXCompleteListingTestBase
        implements BorrowerDXGetOfferNewAAFSTestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXGetOfferNewAAFSTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    // BMP-887 Get Offer:Correct response details should be displayed in SoapUI response to the DX user coming through Getoffer
    // method having Experian STAGG value FICO<640.
    @Override
    @Test(groups = {TestGroup.NIGHTLY})
    public void verifyAAForUserFSLesserThan640()
            throws IOException, JAXBException, JSONException, AutomationException, TransformerException,
            ParserConfigurationException, SAXException, HttpRequestException {
        LOG.info("~~~~Executing: verifyAAForUserFSLesserThan640~~~~~~~~~~~");
        ModifiedXmlEntity entity =
                buildGetOfferRequestForLowFicoLessThan640Borrower(Constants.ClientTokenUsers.creditKarmaSubProgramID);
        PollingUtilities.sleep(3000);
        HttpResponse dxReferralOfferResponse = creditKarmaWCFService.getOffers(entity.getRequestBody());
        String emailAddress = entity.getEmailAddress();
        LOG.info(emailAddress);
        LOG.info("Dx Lending Tree request is hit  on endpoint");
        String[] allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), Constants.dxResponse.GETOFFERELIGIBILITYSTATUS);
        Assert.assertEquals(allURLs[0], Constants.dxResponseTagValue.GETOFFERINELIGIBLESTATUS,
                "EligibilityStatus is not correct");

        String[] statusCodes = getTagValue(dxReferralOfferResponse.getResponseBody(), Constants.dxResponse.GETOFFERSTATUSCODE);
        MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(emailAddress);
        ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        String prospectCreatedDate = prospectInfo.getCreatedDate(emailAddress);
        ProspectResponseCodes codes = prospectInfo.getResponseCodes(emailAddress);
        prospectInfo.getOfferUserId(emailAddress);
        circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        prospectInfo.getCreatedDate(emailAddress);
        String offerUserID = prospectInfo.getOfferUserId(emailAddress);
        LOG.info("User OfferUserID is: " + offerUserID);
        // Verify Prospect table
        Assert.assertTrue(prospectCreatedDate
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");

        Assert.assertEquals(codes.getHttpResponseCode(), "200", "Correct 'HTTPResponseCode' should be displayed");

        Assert.assertEquals(codes.getStatusCode(), statusCodes[0], "Correct 'StatusCode' should be displayed");

        Assert.assertEquals(prospectCreated.getEmploymentInfo().getAnnualIncome().toString().replaceAll("\\.0*$", ""),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG)
                        .replaceAll("\\.0*$", ""),
                "Correct 'YearlyIncome' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");

        PollingUtilities.sleep(2000);
        LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);

        Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(offerUserID),
                DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getDeclineReasonID());

        LOG.info("verified Decline ReasonID ");
        // verify AdverseActionEvent table:
        PollingUtilities.sleep(40000);
        AdverseActionEventDAO adverseActionEventInfo =
                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);

        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
                AdverseActionTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getAdverseActionEventTypeID());
        LOG.info("verified Adverse Action verification");
        String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(emailAddress);

        Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
                SquareCutTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getSquareCutTypeID());
        LOG.info("verified SquareCutTypeID verification");
        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
                "messagesent data should not be null");
        LOG.info("verified Message sent tbl status");


        LOG.info(
                "BMP-887	Get Offer:Correct response details should be displayed in SoapUI response to the DX user coming through Getoffer method having Experian STAGG value FICO<640.-Passed");
        verifyWebMail(outlookQAWebAppPage, "QA", emailAddress,
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("creditScoreLow"), MessageBundle.getMessage("nearPrimerAAContent"));
        LOG.info("~~~~verifyAAForUserFSLesserThan640--PASSED~~~~~~~~~~~");
    }
}
