
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.ChangeContactInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya
 */
public class DxBorrowerLegalNameTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(DxBorrowerLegalNameTest.class.getSimpleName());
    private static final String DX_PREFERRED_NAME = "dxLegalNameTest";


    // BMP-4091 DX: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name
    // and Preferred name
    // BMP-4092 DX: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have
    // different legal name and Preferred name
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testDxBorrowerLegalName()
            throws IOException, JAXBException, AutomationException, ParserConfigurationException, SAXException,
            TransformerException, HttpRequestException {
        LOG.info("~~~~Executing: testDxBorrowerLegalName~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDxBorrowerLegalName");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        LOG.info("DX User emailaddress is:" + email);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("File Permission Error"));
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));
                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertFalse(personalDetailsPage.isStaticTextDisplayed("Sass Compiling Error"));
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = tilaPage.clickOnProsperLogo();
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = publicSitePreRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName(DX_PREFERRED_NAME);
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage = changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            final PublicSiteOfferPage publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            final PublicSiteTruthInLendingDisclosurePage tilaAgainPage = personalDetailsPage.clickContinue();
            tilaAgainPage.navigateToNewTILAPage();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            Assert.assertFalse(tilaAgainPage.isStaticTextDisplayed(DX_PREFERRED_NAME));
            LOG.info(
                    "BMP-4091 DX: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name and Preferred name");

            tilaAgainPage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaAgainPage.clickContinue();
            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage =
                    publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            publicSitePreRegistrationAgainPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationAgainPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLendingDisclosure();
            // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLendingDisclosure();
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
            LOG.info(
                    "BMP-4092 DX: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have different legal name and Preferred name");
        }
    }
}
