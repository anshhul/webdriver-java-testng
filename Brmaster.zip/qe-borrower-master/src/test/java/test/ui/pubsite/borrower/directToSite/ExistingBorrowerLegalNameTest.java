
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.ChangeContactInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya created on 11 Nov 2016
 */
public class ExistingBorrowerLegalNameTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(ExistingBorrowerLegalNameTest.class.getSimpleName());
    private static final String EXISTING_USER_PREFERRED_NAME = RandomStringUtils.random(5, true, false);


    // BMP-4085 Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user completes
    // funnel with old tila page and user have different legal name and Preferred name for user creating 2nd loan listing
    // BMP-4084 Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user completes
    // funnel with new tila page and user have different legal name and Preferred name for user creating 2nd loan listing
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testExistingUserLegalName() throws AutomationException {
        LOG.info("~~~~~~~~~~Executing test : testExistingUserLegalName~~~~~~~~~~~~~~~~~~");
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();
        final String email = getUserForEnvironment("testPriorBorrowerOnPersonalPage");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        publicSiteRegistrationPage.enterEmailAddress(email);
        LOG.info("User email addresss is:" + email);
        // login modal displayed
        Assert.assertTrue(publicSiteRegistrationPage.getLoginModalAsElement().isDisplayed());
        // User entered the common Password: "Password23"
        publicSiteRegistrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
        // User accept the agreement on Reg Page
        publicSiteRegistrationPage.clickOnSignInToContinue();
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text
        personalDetailsPage.verifyPersonalDetailPageHeaderContent();

        final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

        tilaPage.confirmElectronicSignature();
        final String listingID = tilaPage.getListingIdFromTILAContent();
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = tilaPage.clickOnProsperLogo();
        publicSitePreRegistrationAgainPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
        SettingsPage settingPage = publicSitePreRegistrationAgainPage.goToSettingsPage();

        final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

        changeContactInformationPage.enterPreferredFirstName(EXISTING_USER_PREFERRED_NAME);
        changeContactInformationPage.selectPreferredPhone("Mobile");
        settingPage = changeContactInformationPage.clickOnChangeButton();
        final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
        final PublicSiteOfferPage publicSiteOfferAgainPage = accountOverviewPage.clickFinishApplication();
        final PublicSitePersonalDetailPage personalDetailsAgainPage = publicSiteOfferAgainPage.clickGetLoan();
        final PublicSiteTruthInLendingDisclosurePage tilaAgainPage = personalDetailsAgainPage.clickContinue();
        tilaAgainPage.navigateToNewTILAPage();
        Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
        Assert.assertFalse(tilaAgainPage.isStaticTextDisplayed(EXISTING_USER_PREFERRED_NAME));
        
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info("~~~~~~Executing:~~~~~~BMP-5497~~~~~~");
        final String listingforPMI= listingsDAO.getListingIdForPMI(listingID);
        Assert.assertNull(listingforPMI);
        LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");
        
        tilaAgainPage.confirmElectronicSignature();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaAgainPage.clickContinue();
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgain2Page =
                publicSiteBankAccountInfoPage.clickProsperLogo();

        // Navigate to History Page
        publicSitePreRegistrationAgain2Page.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
        final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationAgain2Page.goToHistoryPage();
        final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
        eventHistoryPage.clickOnLinkWithinEventDetail("truthInLendingDisclosure_linkText");
        // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
        eventHistoryPage.switchToNewlyOpenedWindow();
        Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
        eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
        eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
        final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
        legalAgreementPage.clickOnLinkWithinEventDetail("truthInLendingDisclosure_linkText");
        legalAgreementPage.switchToNewlyOpenedWindow();
        Assert.assertTrue(tilaAgainPage.getBorrowerDetails().contains(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
    }

}
