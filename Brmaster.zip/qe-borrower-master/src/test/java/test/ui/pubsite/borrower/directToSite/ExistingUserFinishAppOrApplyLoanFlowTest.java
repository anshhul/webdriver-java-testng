
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerPreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 17-Jun-2016
 *
 */
public class ExistingUserFinishAppOrApplyLoanFlowTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ExistingUserFinishAppOrApplyLoanFlowTest.class.getSimpleName());
    protected static final String EXISTING_USER_TEST_DATA = "EXISTING_USER_TEST_DATA";


    @DataProvider(name = EXISTING_USER_TEST_DATA)
    public Object[][] getExistingUserData() {
        final Object[][] userData = new Object[2][1];

        // Abandon User having no listing( finish application flow)
        userData[0][0] = "testabandonUser008@c1.stg";

        // Existing User having pending activation listing status(apply loan flow)
        userData[1][0] = "testExistingUser007@c1.stg";
        return userData;
    }

    // Supply User email Address
    @Test(dataProvider = EXISTING_USER_TEST_DATA)
    void testExistingUserListing(String email) throws AutomationException {
        LOG.info("~~~~~~Executing-testExistingUserListing~~~~~~~~~~~~~~~");
        // email ="pauravispatil@gmail.com";

        withdrawUserListing(email);

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

        final AccountOverviewPage accountOverviewPage =
                publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);

        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.dismissCongratulationWelcomeModal();

        // Validate the available flow on Account Overview Page(choose apply loan or finish Application) for the User and continue
        // new listing process
        if (accountOverviewPage.isApplyNowButtonDisplayed()) {
            final BorrowerPreRegistrationPage borrowerPreRegistrationPage = accountOverviewPage.clickApplyLoan();
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    borrowerPreRegistrationPage.submitPreRegistrationPage(Double.toString(LOAN_AMOUNT),
                            getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                            getCommonTestData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteOfferPage.getThreeYearFixedMonthlyPaymentAmount();
            final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();

            // Verify new Personal detail Header text
            personalDetailsPage.verifyPersonalDetailPageHeaderContent();

            // need to enter employer phone because user is coming via old pre-reg page
            personalDetailsPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            LOG.info("Existing User Dropped the funnel on personal detail page");

            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

            tilPage.confirmElectronicSignature();
            final String newListing = getQueryMap(tilPage.getListingIdFromTILAContent()).get("listing_id");

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // TODO: Submitting Bank Info Page, need to revisit once existing user bank info fixed
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you Page");
            borrowerThankYouPage.clickGoToMyAccountPage();

            accountOverviewPage
                    .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            accountOverviewPage.dismissCongratulationWelcomeModal();

            Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));
            LOG.info("New Listing for Withdrawn Listing User :" + newListing);
        } else if (accountOverviewPage.isFinishApplicationButtonDisplayed()) {

            final PublicSiteOfferPage publicSiteOfferPage = accountOverviewPage.clickFinishApplication();

            publicSiteOfferPage.getThreeYearFixedMonthlyPaymentAmount();
            final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();

            // Verify new Personal detail Header text
            personalDetailsPage.verifyPersonalDetailPageHeaderContent();
            /*
             * TODO: Un-comment below code if we have many existing abandon users to test listing, for testing as of now only
             * single user is being user to test finish application flow
             */
            // need to enter employer phone because user is coming via old pre-reg page
            // personalDetailsPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
            // getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
            // getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            //
            // LOG.info("Verified - Personal Detail Page is pre-filled for existing User have submitted Personal info earlier");
            // PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            //
            // tilPage.confirmElectronicSignature();
            // getQueryMap(tilPage.getListingIdFromTILAContent()).get("listing_id");
            //
            // PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
            // final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
            // .submitManualBankOption();
            // // TODO: Submitting Bank Info Page, need to revisit once existing user bank info fixed
            // PublicSiteThankYouPage borrowerThankYouPage =
            // manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
            // "Savings",
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
            // getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            //
            // // User navigate to Thank you Page and clicked on go to my account
            // // button
            // LOG.info("User navigate to Thank you Page");
            // borrowerThankYouPage.clickGoToMyAccountPage();
            //
            // accountOverviewPage
            // .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            // accountOverviewPage.dismissCongratulationWelcomeModal();
            // Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));
        }
    }
}
