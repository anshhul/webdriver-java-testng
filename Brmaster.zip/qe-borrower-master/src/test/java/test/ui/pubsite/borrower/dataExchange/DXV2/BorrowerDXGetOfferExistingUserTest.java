
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * Created by rsubramanyam on 4/18/16.
 */
public class BorrowerDXGetOfferExistingUserTest extends DXCompleteListingTestBase {

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyGetOfferExistingUserListingTest() throws Exception {

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String dxEmail = getUserForEnvironment("testPriorBorrowerListingViaAHLClient");
        final String userId = userInfo.getUserIDByEmail(getUserForEnvironment("testPriorBorrowerListingViaAHLClient"));
        // Clean Existing User for new listing creation
        LOG.info("Existing User Email :"+dxEmail);
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeExistingBorrower(getUserForEnvironment("testPriorBorrowerListingViaAHLClient"));
        PollingUtilities.sleep(2000);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());

        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String dxV2Url = allURLs[0].replace("amp;", "");
        LOG.info("dXv2Url  "+dxV2Url);
        final String offersUrlToUseForTesting = dxV2Url.replace("plp/dx-landing-page","personal-loans/pre-approval");
        LOG.info("offersUrlToUseForTesting:::::  "+offersUrlToUseForTesting);

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            Assert.assertTrue(dxLandingPage.verifyForgotPasswordIconToolTip());
            final boolean isPasswordEntered = dxLandingPage.enterDXPassword(Constant.COMMON_PASSWORD);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            PublicSiteRegistrationPage registrationPage = null;
            if (isPasswordEntered) {
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("File Permission Error"));
                String firstName = getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG);
                Assert.assertEquals(dxLandingPage.getUserFirstName(), firstName.substring(0, 1).toUpperCase() + firstName.substring(1).toLowerCase());
                Assert.assertEquals(dxLandingPage.getDxWelcomeMsg(), "Welcome Back.");
                LOG.info(

                        " DX v2: Correct Welcome message should be displayed on Pre Screen Create Password page.-Passed");
                Assert.assertTrue(dxLandingPage.getDxProsperLogo());
                LOG.info(
                        " DX v2: Correct Prosper Logo  should be displayed on DX Landing Page create password page.-Passed");

                Assert.assertEquals(dxLandingPage. getDxTitleText(), "We put together a great, pre-approved\n" +
                        "loan offer for you based on information\n" +
                        "we received from:");
//                Assert.assertEquals(dxLandingPage.getFooterDeclaration(),"This will not affect your credit score");
                dxLandingPage.verifyLoanTermsonLandingPage();
                dxLandingPage.clickElectronicSignatureCheckBox();
                registrationPage = dxLandingPage.clickContinueBtn();
            } else {

                personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
                personalDetailsPage.waitForPersonalDetailsPage();
                personalDetailsPage.selectOccupation("Chemist");
                personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
                registrationPage = personalDetailsPage.clickContinueButton();

            }

            registrationPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            Assert.assertTrue(
                    registrationPage.verifyPrefilledEmail(getUserForEnvironment("testPriorBorrowerListingViaAHLClient")),
                    "Pre-filled email is not correct");
            Assert.assertFalse(registrationPage.isAllFieldsEditable(), "All fields are not Editable.");

            Assert.assertTrue(registrationPage.isEmploymentStatusDropDownEditable(), "Employmentstatus is not editable");
            Assert.assertTrue(registrationPage.isYearlyIncomeFieldEditable(), "Yearly income is not editable.");

            registrationPage.clickElectronicSignatureCheckBox();
            LOG.info("User checked the creditreport checkbox successfully");

            final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
            LOG.info("User submitted the registration page successfully");
            final PublicSitePersonalDetailPage personalDetailsPageAgain = offerPage.clickGetLoan();
            LOG.info("User landed on the Personal detail page after resuming successfully");
            personalDetailsPageAgain
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPageAgain.clickContinue();
            LOG.info("User is able to submit the Personal detail page successfully");
            LOG.info(
                    "BMP-880 Get Offer: Existing: Verify that Loan Terms page displayed on submitting Personal Information page");
            LOG.info("Tila Document is loaded successfully");
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            // submit existing bank info page
            final PublicSiteThankYouPage thankYouPage = bankAccountInfoPage.clearAndEnterBankInfoForExistingUser(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            LOG.info("BMP-867 Get Offer: Existing: Verify that Thank You page displayed on submitting Bank Info page");
            thankYouPage.clickGoToMyAccountPage();
        }
    }
}
