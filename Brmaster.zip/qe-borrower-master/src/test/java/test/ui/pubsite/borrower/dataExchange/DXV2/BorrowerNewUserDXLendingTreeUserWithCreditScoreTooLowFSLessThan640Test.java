
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.mapper.ProspectResponseCodes;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.util.web.borrower.common.ModifyXMLUtil;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;
import test.ui.pubsite.borrower.dataExchange.cases.BorrowerNewUserDXLendingTreeUserWithCreditScoreTooLowFSLessThan640TestCase;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class BorrowerNewUserDXLendingTreeUserWithCreditScoreTooLowFSLessThan640Test extends DXCompleteListingTestBase implements
        BorrowerNewUserDXLendingTreeUserWithCreditScoreTooLowFSLessThan640TestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerNewUserDXLendingTreeUserWithCreditScoreTooLowFSLessThan640Test.class.getSimpleName());

    @Override
    @Test(groups = {TestGroup.NIGHTLY})
    public void verifyNewUserWithCreditScoreTooLowFSLessThan640Test()
            throws XPathExpressionException, SAXException, IOException, ParserConfigurationException, TransformerException,
            JAXBException, JSONException, AutomationException, HttpRequestException, InterruptedException {
        LOG.info("~~~~Executing: verifyNewUserWithCreditScoreTooLowFSLessThan640Test~~~~~~~~~~~");
        ModifiedXmlEntity entity =
                ModifyXMLUtil.updateLTXMLFile(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), null,
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, null,
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG), null,
                        null,
                        null, getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG), null,
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        String emailAddress = entity.getEmailAddress();
        String requestBody = entity.getRequestBody();
        PollingUtilities.sleep(2000);
        HttpResponse dxReferralOfferResponse = creditKarmaWCFService.getLTOffers(requestBody);

        LOG.info(emailAddress);

        LOG.info("Dx Lending Tree request is hit  on endpoint");
        String[] allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), "ERRORDESCRIPTION");
        Assert.assertEquals(allURLs[0], "Success", "ERRORDESCRIPTION is not correct");

        // Verify Prospect table
        MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
        Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(emailAddress);
        ProspectDAO prospectInfo = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        ProspectResponseCodes codes = prospectInfo.getResponseCodes(emailAddress);
        prospectInfo.getCreatedDate(emailAddress);
        circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        prospectInfo.getCreatedDate(emailAddress);
        String offerUserID = prospectInfo.getOfferUserId(emailAddress);

        // verfiy prospect records
        Assert.assertEquals(prospectCreated.getPersonalInfo().getFirstName(),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                "Correct 'FirstName' should be displayed");

        Assert.assertEquals(prospectCreated.getPersonalInfo().getLastName(),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                "Correct 'LastName' should be displayed");
        Assert.assertEquals(codes.getHttpResponseCode(), "200",
                "Eligiblity reason is not correct");

        Assert.assertEquals(prospectInfo.getIneligibilityReason(emailAddress).toString(),
                "Based on Prosper's internal algorithm, we could not find any matching offers.");

        // verify AdverseActionEvent table:
//        PollingUtilities.sleep(40000);
//        AdverseActionEventDAO adverseActionEventInfo =
//                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
//
//        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
//                AdverseActionTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getAdverseActionEventTypeID());
//
//        String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(emailAddress);
//
//        Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
//                SquareCutTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getSquareCutTypeID());
//
//        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
//                "messagesent data should not be null");
//
//        LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
//        Assert.assertEquals(
//                loanOfferDeclineInfo.getDeclineReasonID(offerUserID),
//                DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getDeclineReasonID());
//
//        LOG.info("Decline Reseaon id is:" + circleOneDBConnection
//                .executeSelectQuery(MessageBundle.getMessage("loanOfferDeclineQuery").replace("{offerUserId}", offerUserID)));
//        Assert.assertEquals(
//                circleOneDBConnection
//                        .executeSelectQuery(
//                                MessageBundle.getMessage("loanOfferDeclineQuery").replace("{offerUserId}", offerUserID))
//                        .get(0).get("DeclineReasonID"),
//                DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getDeclineReasonID());
//        LOG.info(
//                "PART-352 Lending Tree:Correct response details should be displayed in SoapUI response to the DX user coming through Getoffer method having Experian STAGG value FICO<640.-Passed");
//
//        // Re-attempt to verify 120 decline
//        dxReferralOfferResponse = creditKarmaWCFService.getLTOffers(requestBody);
//        LOG.info(emailAddress);
//
//        LOG.info("Dx Lending Tree request is hit  on endpoint");
//        allURLs = getTagValue(dxReferralOfferResponse.getResponseBody(), "ERRORDESCRIPTION");
//        Assert.assertEquals(allURLs[0], "Success", "ERRORDESCRIPTION is not correct");
//        LOG.info(
//                "PART-378 New User:Lending Tree:Adverse Action  120 Day Decline : Correct response details should be displayed in SoapUI response to the existing user in SoapUI response to the DX user coming through Lending Tree and fall in category fro 120 day decline .-Passed");
//        Assert.assertEquals(
//                loanOfferDeclineInfo.getDeclineReasonID(offerUserID),
//                DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getDeclineReasonID());

        LOG.info("~~~~verifyNewUserWithCreditScoreTooLowFSLessThan640Test--PASSED~~~~~~~~~~~");
    }
}
