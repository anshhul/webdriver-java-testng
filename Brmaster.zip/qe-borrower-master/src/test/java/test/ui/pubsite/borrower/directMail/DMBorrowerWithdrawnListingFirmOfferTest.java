
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerWithdrawListingPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 31-May-2016
 *
 */
public class DMBorrowerWithdrawnListingFirmOfferTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerWithdrawnListingFirmOfferTest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testWithdrawnDMUserNotReceiveFirmOffers() throws AutomationException {
        LOG.info("Executing: testWithdrawnDMUserNotReceiveFirmOffers");

        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(getDMPagesURI().get(0).get("URL")),
                URLUtilities.getStringURLWithoutScheme(getDMPagesURI().get(0).get("URL")))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getPrimeBorrowerData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);

            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            // Submit Thank you page
            AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();

            overviewPage.clickWithdrawYourRequestLink();
            LOG.info("Borrower clicked for withdraw listing request");
            BorrowerWithdrawListingPage borrowerWithdrawListingPage = overviewPage.clickWithdrawLoanRequest();
            borrowerWithdrawListingPage.clickWithdrawListing();
            Assert.assertTrue(borrowerWithdrawListingPage.getWithdrawListingStatusAsElement().getText()
                    .contains("Your listing has been withdrawn."));
            LOG.info("Borrower listing is withdraw successfully");
            LOG.info("Borrower having withdrawn listing" + emailAddress);

            // verify firm offer email for withdrawn listing DM User

                verifyWebMail(outlookQAWebAppPage, "QA", emailAddress,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                        MessageBundle.getMessage("fundingListingThroughProsper"), MessageBundle.getMessage("notEligibleForLoan"));
            //"GEAR-857 Verify that user with withdrawn DM listing created using valid DM offer code from DM landing page do not receive firm offer of credit email"
        }
    }
}
