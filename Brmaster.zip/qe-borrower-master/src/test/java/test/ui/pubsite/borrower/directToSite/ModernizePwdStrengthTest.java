
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.RegistrationPageMessageConstants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Created by rsubramanyam on 5/15/16.
 */
public class ModernizePwdStrengthTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ModernizePwdStrengthTest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "preRegisterPageLoanPurpose", "homeImprovementListing"),
        };
    }

    /**
     *
     * GEAR-539 Verify that error is displayed immediately after user clicks out of password field. GEAR-533 Verify that correct
     * text is displayed when password field is in focus. GEAR-534 Verify that '1 number' in the text turns green when user enetrs
     * a number in password field. GEAR-535 Verify that '1 uppercase letter' in the text turns green when user enetrs a uppercase
     * letter in password field. GEAR-536 Verify that '1 lowercase letter' in the text turns green when user enetrs a lowercase
     * letter in password field. GEAR-537 Verify that '1 symbol' in the text turns green when user enetrs a symbol in password
     * field. GEAR-538 Verify that '8 characters' in the text turns green when user enetrs 8 characters in password field.
     * GEAR-532 Verify that password strength is upgraded on Register page of DTS GEAR-543 Verify that user should not be able to
     * submit register page without fulfiling all the conditions of password strength GEAR-544 Verify that user should be able to
     * submit register page after fulfiling all the conditions of password strength
     *
     * @throws AutomationException
     */
    @Test(groups = TestGroup.NIGHTLY)
    public void testPasswordVariation() throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage modernizeRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();
        modernizeRegistrationPage.enterPassword("P");
        modernizeRegistrationPage.checkPasswordMeter("1 uppercase letter");
        modernizeRegistrationPage.enterPassword("1");
        modernizeRegistrationPage.checkPasswordMeter("1 number");
        modernizeRegistrationPage.enterPassword("!");
        modernizeRegistrationPage.checkPasswordMeter("1 symbol");
        modernizeRegistrationPage.enterPassword("assword");
        modernizeRegistrationPage.checkPasswordMeter("8 characters");
    }

    @Test(groups = TestGroup.NIGHTLY)
    public void testErrorDisplayedOnPasswordField() throws AutomationException, InterruptedException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage modernizeRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();
        // enter any 3-4 characters in Password field
        modernizeRegistrationPage.enterPassword(RandomStringUtils.random(4));
        Assert.assertTrue(modernizeRegistrationPage
                .verifyPasswordMessageDisplayed(RegistrationPageMessageConstants.INCORRECT_PASSWORD_ERROR_MESSAGE));
        LOG.info("GEAR-539 Verify that error is displayed immediately after user clicks out of password field");

        modernizeRegistrationPage.checkPasswordMeter(RegistrationPageMessageConstants.INCORRECT_PASSWORD_ERROR_MESSAGE);
        LOG.info("GEAR-533 Verify that correct text is displayed when password field is in focus.");
    }

    @Test(groups = TestGroup.NIGHTLY)
    public void testPasswordTextColor() throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage modernizeRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();
        // enter 1 number in Password field
        modernizeRegistrationPage.enterPassword("1");
        Assert.assertTrue(modernizeRegistrationPage.verifyPasswordTextColor("1 number"));
        LOG.info("GEAR-534 Verify that '1 number' in the text turns green when user enetrs a number in password field.");

        // enter 1 upper case letter in Password field
        modernizeRegistrationPage.enterPassword("U");
        Assert.assertTrue(modernizeRegistrationPage.verifyPasswordTextColor("1 uppercase letter"));
        LOG.info(
                "GEAR-535 Verify that '1 uppercase letter' in the text turns green when user enetrs a uppercase letter in password field.");

        // enter 1 lower case letter in Password field
        modernizeRegistrationPage.enterPassword("a");
        Assert.assertTrue(modernizeRegistrationPage.verifyPasswordTextColor("1 lowercase letter"));
        LOG.info(
                "GEAR-536 Verify that '1 lowercase letter' in the text turns green when user enetrs a lowercase letter in password field.");

        // enter 1 symbol in Password field
        modernizeRegistrationPage.enterPassword("@");
        Assert.assertTrue(modernizeRegistrationPage.verifyPasswordTextColor("1 symbol"));
        LOG.info("GEAR-537 Verify that '1 symbol' in the text turns green when user enetrs a symbol in password field.");

        // enter 8 characters in Password field
        modernizeRegistrationPage.enterPassword(RandomStringUtils.random(8));
        Assert.assertTrue(modernizeRegistrationPage.verifyPasswordTextColor("8 characters"));
        modernizeRegistrationPage.checkPasswordMeter(RegistrationPageMessageConstants.INCORRECT_PASSWORD_ERROR_MESSAGE);
        LOG.info("GEAR-538 Verify that '8 characters' in the text turns green when user enetrs 8 characters in password field.");
    }

    @Test(dataProvider = "testData", groups = TestGroup.NIGHTLY)
    public void testInsertIncorrectPasswordOnDTSRegPage(String Key, String jiraID, String loanAmount, String loanPurpose,
                                                        String creditQuality,
                                                        String firstName, String middleInitial, String lastName,
                                                        String homeAddress, String city, String state, String zipCode,
                                                        String employmentStatus,
                                                        String yearlyIncome, String dob, String emailAddress, String password,
                                                        String homePhone, String mobilePhone, String workPhone,
                                                        String employerName,
                                                        String employerPhone, String occupation, String employmentStartDate,
                                                        String SSN, String bankName,
                                                        String accountType, String accountholderName,
                                                        String AlternateAccountHolderName,
                                                        String routingNumber, String accountNumber,
                                                        String confirmAccountNumber, String paymentType)
                                                                throws AutomationException, InterruptedException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage modernizePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage registrationPage =
                modernizePreRegistrationPage.checkYourRate();
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        // enter any random 8 characters in Password field which do not fulfill all the condition of password strength and submit
        // the registration page

        registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, RandomStringUtils.random(8), firstName,
                lastName,
                homeAddress,
                city, state, employmentStatus, yearlyIncome, dob);
        registrationPage.clickElectronicSignatureCheckBox();
        registrationPage.clickGetYourRate(false, false);

        Assert.assertTrue(registrationPage
                .isPasswordFieldHintDisplayed(RegistrationPageMessageConstants.INCORRECT_PASSWORD_ERROR_MESSAGE));
        LOG.info("GEAR-532 Verify that password strength is upgraded on Register page of DTS");

        Assert.assertTrue(registrationPage.isRegisterPageDisplayed());
        LOG.info(
                "GEAR-543 Verify that user should not be able to submit register page without fulfiling all the conditions of password strength");
    }

    @Test(dataProvider = "testData", groups = TestGroup.NIGHTLY)
    public void testInsertCorrectPasswordOnDTSRegPage(String Key, String jiraID, String loanAmount, String loanPurpose,
                                                      String creditQuality,
                                                      String firstName, String middleInitial, String lastName,
                                                      String homeAddress, String city, String state, String zipCode,
                                                      String employmentStatus,
                                                      String yearlyIncome, String dob, String emailAddress, String password,
                                                      String homePhone, String mobilePhone, String workPhone,
                                                      String employerName,
                                                      String employerPhone, String occupation, String employmentStartDate,
                                                      String SSN, String bankName,
                                                      String accountType, String accountholderName,
                                                      String AlternateAccountHolderName,
                                                      String routingNumber, String accountNumber,
                                                      String confirmAccountNumber, String paymentType)
                                                              throws AutomationException, InterruptedException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage modernizePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage registrationPage =
                modernizePreRegistrationPage.checkYourRate();
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        // enter Password field which fulfill all the condition of password strength and submit
        // the registration page
        registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, MessageBundle.getMessage("password"),
                firstName,
                lastName,
                homeAddress,
                city, state, employmentStatus, yearlyIncome, dob);
        registrationPage.clickElectronicSignatureCheckBox();
        Assert.assertFalse(registrationPage.isPasswordBubbleFieldHintDisplayed());
        LOG.info(
                "GEAR-544 Verify that user should be able to submit register page after fulfiling all the conditions of password strength");
    }

    @Test(dataProvider = "testData", groups = TestGroup.NIGHTLY, enabled = false)
    public void testPasswordStrengthOnResetPasswordPage(String Key, String jiraID, String loanAmount, String loanPurpose,
                                                        String creditQuality,
                                                        String firstName, String middleInitial, String lastName,
                                                        String homeAddress, String city, String state, String zipCode,
                                                        String employmentStatus,
                                                        String yearlyIncome, String dob, String emailAddress, String password,
                                                        String homePhone, String mobilePhone, String workPhone,
                                                        String employerName,
                                                        String employerPhone, String occupation, String employmentStartDate,
                                                        String SSN, String bankName,
                                                        String accountType, String accountholderName,
                                                        String AlternateAccountHolderName,
                                                        String routingNumber, String accountNumber, String confirmAccountNumber,
                                                        String paymentType)
                                                                throws AutomationException {

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage modernizePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("modernizePreRegistrationPage");
        PublicSiteRegistrationPage registrationPage =
                modernizePreRegistrationPage.checkYourRate();
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        // Submit Register page
        registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email, MessageBundle.getMessage("password"),
                firstName, lastName, homeAddress,
                city, state, employmentStatus, yearlyIncome, dob);
        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // Submit Loan Offers page
        PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

        // Submit Personal Details page
        detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
                employmentStartDate, SSN);
        PublicSiteTruthInLendingDisclosurePage tilPage = detailsPage.clickContinue();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();
        PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
        PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

        // Submit Bank Information Page
        PublicSiteThankYouPage borrowerThankYouPage =
                manualBankPage.enterBankInfo(bankName, accountType, accountholderName, AlternateAccountHolderName, routingNumber,
                        accountNumber, confirmAccountNumber, paymentType);
        // Submit Thank you page
        AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        overviewPage.dismissCongratulationWelcomeModal();
        overviewPage.selectFromUserHeaderDropdown(HeaderOptions.SIGN_OUT.getValue());
        PublicSiteSignInPage signInPage = modernizePreRegistrationPage.clickOnSignIn();
        PublicSiteRequestEmailForChangePasswordPage changePasswordPage = signInPage.clickForgotPassword();
        changePasswordPage.enterEmailAddress(email);
        changePasswordPage.clickContinue();

        // Verify abp mail box and retrieve the finish request url for borrower

        // verifyWebMailForResetPassword(outlookAbpWebAppPage, "QA", email, firstName,
        // MessageBundle.getMessage("followingUp_resetPassword"), MessageBundle.getMessage("followingUpBody"));
        LOG.info(
                "GEAR-559 Verify that user should be able to submit reset password page after fulfiling all the conditions of password strength");

    }
}
