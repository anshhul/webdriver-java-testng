
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage.ABPDeclineOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * BMP-454 Invalid State:New user where Applicant State of Residence is in state where Program is NOT offered is not allowed to
 * create the listing.
 *
 * @author jdoriya 17-May-2016
 *
 */
public class ABPInvalidStateAATest extends DXCompleteListingTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPInvalidStateAATest.class.getSimpleName());


    // BMP-454 Invalid State:New user where Applicant State of Residence is in state where Program is NOT offered is not allowed
    // to create the listing.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testRestrictionForInvalidStateAA() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: testRestrictionForInvalidStateAA~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testRestrictionForInvalidState", "p2pcredit");
        LOG.info("ABP invalid state borrower email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of prime invalid state borrower");
        abpRegistrationPage.enterLastName(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of prime invalid state borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  invalid state borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of invalid state borrower");
        abpRegistrationPage
                .enterHomeAddress(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of invalid state borrower");
        abpRegistrationPage.selectState(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of invalid state borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of invalid state borrower");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of invalid state borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getInvalidStateBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth invalid state borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for invalid state borrower");
        abpRegistrationPage.enterHomePhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage
                .enterSecondaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage
                .selectLoanPurposer(getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        final ABPDeclineOfferPage abpDeclineOfferPage = abpOfferPage.goToDeclinePage();
        Assert.assertTrue(abpDeclineOfferPage.getDeclineContentAsElement().getText()
                .contains(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE_1));
        Assert.assertTrue(abpDeclineOfferPage.getDeclineContentAsElement().getText()
                .contains(Constants.VALIDATIONS.INVALID_STATE_RESTRICTION_MESSAGE_2));
        LOG.info(
                "BOR-6740 Invalid State:New user where Applicant State of Residence is in state where Program is NOT offered is not allowed to create the listing.");
        LOG.info("~~~~~~~~~~~testRestrictionForInvalidStateAA--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

}
