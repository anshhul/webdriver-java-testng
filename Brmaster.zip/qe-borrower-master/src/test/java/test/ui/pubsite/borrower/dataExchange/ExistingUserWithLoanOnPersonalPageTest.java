
package test.ui.pubsite.borrower.dataExchange;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.wcf.client.DXReferralImpl;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class ExistingUserWithLoanOnPersonalPageTest extends DXCompleteListingTestBase {

    protected static final Logger LOG =
            Logger.getLogger(ExistingUserWithLoanOnPersonalPageTest.class.getSimpleName());
    private static final String EXISTING_USER_PASSWORD_HINT = "Enter Your Password";


    // BMP-3745 Verify that user with previous loan is navigated to pre-filled register page and able to complete listing on
    // submitting DX personal details landing page
    // BMP-3741 Verify that Email address and Enter password fields are also displayed on DX personal details landing page for
    // existing user
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testPriorBorrowerOnPersonalPage()
            throws AutomationException, HttpRequestException, JsonParseException, JsonMappingException, IOException {

        LOG.info("Executing: testPriorBorrowerOnPersonalPage");

        final String email = getUserForEnvironment("testPriorBorrowerOnPersonalPage");

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        final ModifiedXmlEntity entity = buildDXReferralOfferExistingUserRequest(Constants.ClientTokenUsers.AHL_SUBPROGRAM_ID,
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toString(), "3000",
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG).toString(),
                email);

        // initialise ahl wcf configuration
        try (final ClassPathXmlApplicationContext jobContext2 =
                new ClassPathXmlApplicationContext("wcf/spring/wcf_service_context.xml")) {

            final DXReferralImpl ahlClientWCFService = (DXReferralImpl) jobContext2.getBean("ahlWCFService");
            PollingUtilities.sleep(2000);
            final HttpResponse response = ahlClientWCFService.getOffers(entity.getRequestBody());
            Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                    "ShowSelectedOfferUrl Tag size is 0");
            final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
            Assert.assertNotNull(allURLs);
            Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
            final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

            final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
            final String selected_offer_id = getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

            final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);

            try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                    publicSiteUrlScheme, publicSiteUrl + newUri)) {
                dxLandingPage.setPageElements(pageElements);
                final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
                PublicSitePersonalDetailPage personalDetailsPage = null;

                personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
                personalDetailsPage.waitForPersonalDetailsPage();
                personalDetailsPage.selectOccupation("Chemist");
                personalDetailsPage
                        .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
                Assert.assertEquals(personalDetailsPage.getUserEmailAddress().getAttribute("value"), email);
                Assert.assertFalse(personalDetailsPage.getUserEmailAddress().isEnabled());
                Assert.assertEquals(personalDetailsPage.getPasswordOnPersonalDetail().getAttribute("placeholder"),
                        EXISTING_USER_PASSWORD_HINT);
                LOG.info(
                        "BMP-3741 Verify that Email address and Enter password fields are also displayed on DX personal details landing page for existing user");
                personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
                final PublicSiteRegistrationPage registrationPage = personalDetailsPage.clickContinueForNewDXListing();

                LOG.info("User clicked on Get My Loan Button successfully");
                Assert.assertTrue(registrationPage.getRegistrationPageHeader());
                Assert.assertTrue(registrationPage.verifyPrefilledEmail(email), "Pre-filled email is not correct");

                registrationPage.clickElectronicSignatureCheckBox();
                LOG.info("User checked the creditreport checkbox successfully");

                final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
                LOG.info("User submitted the registration page successfully");
                final PublicSitePersonalDetailPage personalDetailsPageAgain = offerPage.clickGetLoan();
                LOG.info("User landed on the Personal detail page after resuming successfully");
                LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
                final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPageAgain.clickContinue();
                LOG.info("User is able to submit the Personal detail page successfully");
                LOG.info("Tila Document is loaded successfully");
                LOG.info("User navigate to TIL Page");
                final String listingId = tilPage.getListingIdFromTILAContent();
                tilPage.confirmElectronicSignature();
                final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
                final PublicSiteThankYouPage thankYouPage = bankAccountInfoPage.clickFinish();
                final AccountOverviewPage accountOverviewPage = thankYouPage.clickGoToMyAccountPage();
                Assert.assertNotNull(accountOverviewPage);
                LOG.info("User listing id is: " + listingId);
                LOG.info(
                        "BMP-3745 Verify that user with previous loan is navigated to pre-filled register page and able to complete listing on submitting DX personal details landing page");
            }
        }
    }

    // BMP-3819 Verify that user with previous loan is navigated to Register page and able to complete listing on submitting DX
    // personal details landing page
    // HINT: New PD is no longer in testing
    @Test(groups = {TestGroup.NIGHTLY}, enabled = false)
    void testLTPriorBorrowerOnPersonalPage()
            throws AutomationException, HttpRequestException, JsonParseException, JsonMappingException, IOException,
            XPathExpressionException, SAXException, ParserConfigurationException, TransformerException {

        LOG.info("Executing: testLTPriorBorrowerOnPersonalPage");

        final String email = getUserForEnvironment("testPriorBorrowerOnPersonalPage");

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final List<Map<String, Object>> listings = circleOneDBConnection
                .executeSelectQuery(String.format(MessageBundle.getMessage("getLatestListingForUser"), userId));
        listings.get(0).get("id").toString();
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        final ModifiedXmlEntity entity = updateLendingTreeRequestForNewPrimeUser(email);
        LOG.info(email);
        final String lendingTreeRequest = entity.getRequestBody();
        LOG.info("Dx Lending Tree request is hit  on endpoint");
        final String[] allURLs =
                getTagValue(validateResponse(creditKarmaWCFService, lendingTreeRequest, "LendingTree").getResponseBody(),
                        Constants.dxResponse.LENDINGTREEURL);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        // Navigate to the DX Landing page
        Assert.assertNotNull(allURLs);
        LOG.info("DX User emailaddress is:" + email);
        final String offersUrlToUseForTesting = navigateToDxLandingPageFromLTResponse(allURLs, email);
        final String newUri = buildPersonalPageLandingLendingTreeUri(offersUrlToUseForTesting);

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + newUri)) {
            dxLandingPage.setPageElements(pageElements);
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            PublicSitePersonalDetailPage personalDetailsPage = null;

            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();

            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            Assert.assertEquals(personalDetailsPage.getUserEmailAddress().getAttribute("value"), email);
            Assert.assertFalse(personalDetailsPage.getUserEmailAddress().isEnabled());
            Assert.assertEquals(personalDetailsPage.getPasswordOnPersonalDetail().getAttribute("placeholder"),
                    EXISTING_USER_PASSWORD_HINT);
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            final PublicSiteRegistrationPage registrationPage = personalDetailsPage.clickContinueForNewDXListing();
            registrationPage.waitForRegistrationFormToDisplayed();
            LOG.info("User clicked on Get My Loan Button successfully");
            Assert.assertTrue(registrationPage.getRegistrationPageHeader());
            Assert.assertTrue(registrationPage.verifyPrefilledEmail(email), "Pre-filled email is not correct");

            registrationPage.clickElectronicSignatureCheckBox();
            LOG.info("User checked the creditreport checkbox successfully");

            final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
            LOG.info("User submitted the registration page successfully");
            final PublicSitePersonalDetailPage personalDetailsPageAgain = offerPage.clickGetLoan();
            LOG.info("User landed on the Personal detail page after resuming successfully");
            LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
            final List<String> infoOnCard = personalDetailsPageAgain.getRightRailCardInfo();

            Assert.assertEquals(infoOnCard.get(0).replace("$", ""),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            Assert.assertEquals(infoOnCard.get(1), "3 years");
            // Assert.assertEquals(infoOnCard.get(3).replaceAll("\\D", ""), apr_url.replaceAll("00*$", "").replaceAll("\\D", ""));
            LOG.info("Right rail displayed as blank for draft listing/existing loan user coming from LT request.");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPageAgain.clickContinue();
            LOG.info("User is able to submit the Personal detail page successfully");
            LOG.info("Tila Document is loaded successfully");
            LOG.info("User navigate to TIL Page");
            new PartnerLandingPageTestBase();
            final String listingId = tilPage.getListingIdFromTILAContent();
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteThankYouPage thankYouPage = bankAccountInfoPage.clickFinish();
            thankYouPage.clickGoToMyAccountPage();
            LOG.info("User listing id is: " + listingId);
            LOG.info(
                    "BMP-3819 Verify that user with previous loan is navigated to Register page and able to complete listing on submitting DX personal details landing page");
        }
    }
}
