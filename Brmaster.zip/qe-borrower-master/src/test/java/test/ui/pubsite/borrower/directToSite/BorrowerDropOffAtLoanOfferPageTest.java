
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import javax.annotation.Resource;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 *
 * BMP-443 Drop off on Loan offer page and Resume after Log out within 30 days.
 *
 * @author jdoriya 17-May-2016
 *
 */
public class BorrowerDropOffAtLoanOfferPageTest extends PartnerLandingPageTestBase {

    private static final Double LOAN_AMOUNT = 5000.0;
    protected static final Logger LOG =
            Logger.getLogger(BorrowerDropOffAtLoanOfferPageTest.class.getSimpleName());
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    /**
     * BMP-443 Drop off on Loan offer page and Resume after Log out within 30 days.
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDropOffFlowAtLoanOfferPage() throws AutomationException {
        LOG.info("testDropOffFlowAtLoanOfferPage");

        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();


        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testDropOffFlowAtLoanOffer");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));


        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        LOG.info("Prime Borrower clicked on Get Your Rate");
        Assert.assertNotNull(publicSiteOfferPage);
        publicSiteOfferPage.clickOnProsperLogo();
        LOG.info("Prime Borrower Abandon the flow at loan offer page");
        Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());
        publicSitePreRegistrationPage.userSignOut();
        LOG.info("Prime Logged out from session");

        // Prime borrower re-login via sign in present on pre-reg page
        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();
        Assert.assertNotNull(publicSiteSignInPage);
        final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
        LOG.info("Prime borrower resumed the funnel and create a new listing this time");
        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.dismissCongratulationWelcomeModal();
        // Flow from Get loan button is not working sign-in page issue, hence using prosperlogo click
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage=accountOverviewPage.clickOnProsperLogo();

        final PublicSiteRegistrationPage publicSiteRegistrationAgainPage =
                publicSitePreRegistrationAgainPage.clickOnStartAnApplication();
        // re try for listing
        // verify reg page details for the prime borrower
        Assert.assertTrue(publicSiteRegistrationAgainPage
                .verifyEmploymentStatus(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG)));
        Assert.assertTrue(publicSiteRegistrationAgainPage.verifyPrefilledEmail(email));
        // TODO: Comment DOB asser due masked reason
        // Assert.assertTrue(publicSiteRegistrationAgainPage
        // .verifyPrefilledDOB(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG)));

         Assert.assertTrue(publicSiteRegistrationAgainPage
         .verifyPrefilledCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG)));

        Assert.assertTrue(publicSiteRegistrationAgainPage
                .verifyPrefilledFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG)));
        Assert.assertTrue(publicSiteRegistrationAgainPage
                .verifyPrefilledLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG)));
        Assert.assertTrue(publicSiteRegistrationAgainPage
                .verifyPrefilledAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG)));
        Assert.assertTrue(publicSiteRegistrationAgainPage
                .verifyPrefilledState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG)));
        LOG.info("Verified Pre-filled Reg details for Prime borrower");

        publicSiteRegistrationAgainPage.clickElectronicSignatureCheckBox();

        // User clicked on get your rate button
        final PublicSiteOfferPage publicSiteOfferAgainPage=publicSiteRegistrationAgainPage.clickGetYourRate(false, false);
        LOG.info("User navigate to Loan Offer Page");
        // User navigate to Personald detail page
        final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferAgainPage.clickGetLoan();
        LOG.info("User navigate to Personal detail Page");
        Assert.assertNotNull(personalDetailPage);
        // Submit the general personal details
        personalDetailPage
                .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        personalDetailPage
                .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
        personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
        personalDetailPage
                .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        personalDetailPage
                .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        personalDetailPage
                .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        personalDetailPage.enterStartOfEmployment(
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        // User entered the SSN of Borrower coming with Offercode
        personalDetailPage
                .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
        // User navigateed to TIL Page
        final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
        LOG.info("User navigate to TIL Page");
        final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
        publicSiteTILAPage.confirmElectronicSignature();
        // User navigated to bank info page
        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
        // User select the Manual Bank options
        LOG.info("User navigate to Bank Info Page");
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG), "Savings",
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        // manualBankAccountPage.enterAlternateAccountHolderName(
        // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        // manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        // final String accountNumber = Constant.getRandomIntegerString(10);
        // manualBankAccountPage.enterAccountNumber(accountNumber);
        // manualBankAccountPage.enterConfirmAccountNumber(accountNumber);
        //
        // final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        borrowerThankYouPage.clickGoToMyAccountPage();
        // User navigate to Account Overview Page and observed the listing
        LOG.info("Drop Off Borrower ListingID is:" + listingID);
        LOG.info("BOR-4640 Drop off on Loan offer page and Resume after Log out within 30 days.");
    }
}
