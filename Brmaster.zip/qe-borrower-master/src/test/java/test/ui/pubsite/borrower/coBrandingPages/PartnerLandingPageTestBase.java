
package test.ui.pubsite.borrower.coBrandingPages;

import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.EmploymentInfoConstant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.XMLReader;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.LoanOriginationDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.document.CreateAgreementRequest;
import com.prosper.automation.model.platform.document.CreateAgreementResponse;
import com.prosper.automation.model.platform.document.GenerateAgreementRequest;
import com.prosper.automation.model.platform.document.GenerateAgreementResponse;
import com.prosper.automation.model.platform.document.MapTemplateArguments;
import com.prosper.automation.model.platform.listing.Listings;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformAccountImpl;
import com.prosper.automation.platform.clients.PlatformDocumentImpl;
import com.prosper.automation.platform.clients.PlatformListingImpl;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.clients.PlatformUserImpl;
import com.prosper.automation.platform.interfaces.IPlatformAccount;
import com.prosper.automation.platform.interfaces.IPlatformDocument;
import com.prosper.automation.platform.interfaces.IPlatformInquiry;
import com.prosper.automation.platform.interfaces.IPlatformListing;
import com.prosper.automation.platform.interfaces.IPlatformOrder;
import com.prosper.automation.platform.interfaces.IPlatformUser;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.BorrowerWithdrawListingPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.spark.pages.SparkHeaderPage;
import com.prosper.automation.spark.pages.SparkListingDetailsPage;
import com.prosper.automation.spark.pages.SparkListingsPage;
import com.prosper.automation.spark.pages.SparkLoginPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.wcf.interfaces.IAllocateListing;
import com.prosper.automation.webdriver.WebDriverConfig;

import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

import test.api.java.platformOffer.PlatformOfferTestBase;

import javax.annotation.Resource;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

/**
 * @author jdoriya
 *
 */
public class PartnerLandingPageTestBase extends PlatformOfferTestBase {

    protected static final Double LOAN_AMOUNT = 5000.0;
    protected static final Double MAX_LOAN_AMOUNT = 35000.0;
    public static final String CARDREFINANCELANDINGPAGES = "CARDREFINANCE_LANDING_PAGE_URI";
    public static final String RADIOPAGES = "RADIO_LANDING_PAGE_URI";
    public static final String DMCREDITQUALITY = "DM_LANDING_PAGE_CREDITQUALITY";
    public static final String DMLISTINGCATEGORY = "DM_LANDING_PAGE_LISTINGCATEGORY_ID";
    public static final String DMLANDINGPAGES = "DM_LANDING_PAGE_URI";
    public static final String HOMEIMPROVEMENTPAGE = "HOME_IMPROVEMENT_PAGE_URI";
    public static final String HOMEPLUSPAGE = "HOME_PLUS_PAGE_URI";
    public static final String UNITEDMILEAGEPLUS = "UNITED_MILEAGE_PLUS_URI";
    public static final String PROMISSORY_NOTE_DOC =
            System.getProperty("relative.path.testdata.environment") + "/common/PromissoryNote_Content.docx";
    public static final String REGISTRATION_AGREEMENT_DOC =
            System.getProperty("relative.path.testdata.environment") + "/common/BorrowerRegistrationAgreement_Content.docx";
    public static final String PARTNER_BRAND_IMAGE_TEST = System.getProperty("user.dir")
            + "\\src\\test\\resources\\testdata\\environment\\common\\testBrandImage.jpg";
    public static final String UNITED_MILEAGE_PLUS_DM_URL = "/plp/mileageplus/";
    public static final String UNITED_MILEAGE_PLUS_EMAIL_LANDINGPAGE_URL = "/plp/no-service/";
    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static String WARM_TRANSFER_CHANNEL = "Warm Transfers (Inbound)";
    protected String emailAddress, userID, listingID, prospectID, refAc, refMc;

    protected long listingId;
    protected Long LOAN_ID;

    protected ListingsDAO listingsDAO;
    public LoanOriginationDAO loanOriginationDAO;
    protected static int Origination_StatusType_Id;
    protected String Error_Result;
    protected String Process_Started_Date;
    protected String Last_Modified_Date;
    protected String Funding_Status;
    protected static int Number_Of_Agreement;
    protected static int Listing_Status;
    protected static int Investment_Type_ID;

    public XMLReader xml;
    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;
    @Resource
    protected CloseableJdbcConnection adverseActionEventDBConnection;
    @Autowired
    protected WebDriverConfig webDriverConfig;
    protected IPlatformDocument documentService;
    protected IPlatformListing listingService;
    protected IPlatformUser userService;
    protected IPlatformAccount accountService;
    @Resource(name = "pageElements")
    protected Map<String, String> pageElements;
    public HashMap<String, String> map = new HashMap<>();
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    @Autowired
    @Qualifier("pubSiteInquiryService")
    protected IPlatformInquiry pubSiteInquiryService;

    @Autowired
    @Qualifier("allocateListing")
    protected IAllocateListing allocateListing;

    @Autowired
    @Qualifier("spectrumDBConnection")
    protected CloseableJdbcConnection spectrumDBConnection;

    @Value("${db.spectrum.dbname}")
    protected String spectrumDbName;

    @Autowired
    @Qualifier("platformOrder")
    protected IPlatformOrder platformOrder;


    // TODO: Create a data file with environment based properties
    public String getUserForEnvironment(String testName) throws AutomationException {
        return getUserForTest(testName).get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG);
    }


    public static final Set<String> RESET_YOUR_PASSWORD_HEADER_EXPECTED_VALUES = new HashSet<String>(Arrays.asList(
            new String[] {"Borrow", "Invest", "Sign In", "Check Your Rate"}));


    public XMLReader getxmlReader() throws AutomationException {
        final File file = new File(
                ClassLoader
                        .getSystemResource(
                                "testdata/environment/" + System.getProperty("environment") + "/PartnerLandingPagesTestData.xml")
                        .getFile());
        // String PATH = System.getProperty("user.dir") + "/" + System.getProperty("relative.path.testdata.environment") + "/"
        // + System.getProperty("environment") + "/PartnerLandingPagesTestData.xml";
        if (file.exists()) {
            return new XMLReader(file);
        } else {
            throw new AutomationException(String.format("Could not find file in the path %s", file));
        }
    }

    /**
     * build data for Prime Borrower Example: TAHIR BESS
     *
     * @return
     */
    public Hashtable<String, String> getPrimeBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("TuPrimeBorrowerValidDetails").get(0);
    }

    public Hashtable<String, String> getMilitaryStateBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("MilitaryStateUserDetails").get(0);
    }



    /**
     * Get phl page URI
     *
     * @return
     */
    public List<Hashtable<String, String>> getPHLPageURI() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("PHLPageURI");
    }

    public Hashtable<String, String> getTUBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("TuPrimeBorrowerValidDetails").get(0);
    }

    public Hashtable<String, String> getMAStateBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("MAStateBorrowerValidDetails").get(0);
    }

    public Hashtable<String, String> get2kLoanCapUserData() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList("LoanCapUser2k").get(0);
    }

    /**
     * build data for Non Borrowing State i.e WV ('Gary')
     *
     * @return
     */
    public Hashtable<String, String> getNonBorrowerStateData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("NonBorrowerStateUserDetails").get(0);
    }

    public Hashtable<String, String> getDMScannedProofUserData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("DMScanProofUser").get(0);
    }

    public Hashtable<String, String> getDMValidOfferCodeUserData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("DMValidOfferCodeUser").get(0);
    }

    public Hashtable<String, String> getDMValidOfferCodeTuUserData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("DMValidOfferCodeTuUser").get(0);
    }

    public List<Hashtable<String, String>> getAllDmValidOfferCode() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList("DMValidOfferCodeUser");
    }


    public Hashtable<String, String> getTestCSLessThan640() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList("testCsLessThan640TuUser").get(0);
    }

    /**
     * Get list of all Card refinance pages
     *
     * @return
     */
    public List<Hashtable<String, String>> getAllDMPagesURI() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("DMLandingPageURI");
    }

    /**
     * Get common data for all pages i.e Reg, Personal, Manual Bank detail
     *
     * @return
     */
    public Hashtable<String, String> getCommonTestData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("CommonTestDataShare").get(0);
    }

    public Hashtable<String, String> getUserForTest(String testName) throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList(testName).get(0);
    }

    public List<Hashtable<String, String>> getUserForTest() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("testName");
    }

    /**
     * Get list of all DM Plp pages
     *
     * @return
     */
    public List<Hashtable<String, String>> getDMPagesURI() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("DMPageURI");
    }

    /**
     * Get new alt key relative url
     *
     * @return
     */
    public List<Hashtable<String, String>> getAltKeyURL() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("AltKeyURL");
    }

    public List<Hashtable<String, String>> getPLPPagesURI() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("PLPPageURI");
    }

    /**
     * Get list of all Radio Pages
     *
     * @return
     */
    public List<Hashtable<String, String>> getAllRadioPagesURI() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("RadioLandingPageURI");
    }

    public List<Hashtable<String, String>> getPhlPageUrl() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("PhlPageURI");
    }

    @DataProvider(name = "CARDREFINANCE_LANDING_PAGE_URI")
    public Object[][] getDMLandingPageURIs() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsArray("DMLandingPageURI");
    }

    @DataProvider(name = "HOME_PLUS_PAGE_URI")
    public Object[][] getHomePlusURIs() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsArray("HomePlus");
    }

    @DataProvider(name = "UNITED_MILEAGE_PLUS_URI")
    public Object[][] getUnitedMileagePlusURIs() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsArray("Mileageplus");
    }

    public Hashtable<String, String> getUnitedMileagePlusURI() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList("Mileageplus").get(0);
    }

    @DataProvider(name = "DM_LANDING_PAGE_URI")
    public Object[][] getPlpLandingPageURIs() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsArray("DMPageURI");
    }

    @DataProvider(name = "HOME_IMPROVEMENT_PAGE_URI")
    public Object[][] getHomeImprovementPageURIs() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsArray("HomeImprovementURI");
    }

    /**
     * Get all Radio URIs
     *
     * @return
     */
    @DataProvider(name = "RADIO_LANDING_PAGE_URI")
    public Object[][] getRadioPageURIs() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsArray("RadioLandingPageURI");
    }

    @DataProvider(name = "DM_LANDING_PAGE_CREDITQUALITY")
    public Object[][] getDMPageCreditQuality() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsArray("DMCreditQuality");
    }

    @DataProvider(name = "DM_LANDING_PAGE_LISTINGCATEGORY_ID")
    public Object[][] getDMPageListingCategoryIDs() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsArray("DMListingCategories");
    }

    /**
     * Return URL Paramters
     *
     * @param query
     * @return
     */
    public Map<String, String> getQueryMap(String query) {
        final String[] params = query.split("&");
        final Map<String, String> map = new HashMap<String, String>();
        for (final String param : params) {
            final String name = param.split("=")[0];
            final String value = param.split("=")[1];
            map.put(name, value);
        }
        return map;
    }

    public HashMap<String, String> userListingViaPlpPage() throws AutomationException {

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(getAllRadioPagesURI().get(0).get("URL")),
                URLUtilities.getStringURLWithoutScheme(getAllRadioPagesURI().get(0).get("URL")).replace("?null", ""))) {
            partnerLandingPage.setPageElements(pageElements);
            Assert.assertFalse(partnerLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
            // submit the widget
            // partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            // partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.checkYourRate();
            // enter borrower registration details
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

            final String prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            final String refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            final String emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("testPlpUserListing");
            if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                Assert.assertTrue(publicSiteRegistrationPage.getNumberOfPanes() > 0,
                        "NEW REGISTRAION PAGE IS DISPLAYED TO DM USER");
            }
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                    emailAddress,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    null,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();

            publicSiteTILAPage.confirmElectronicSignature(); // User navigated to bank info page final
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            // User navigate to Thank you Page and clicked on go to my account // button
            LOG.info("User navigate to Thank you Page");
            map.put("EMAILADDRESS", emailAddress);
            map.put("PROSPECTID", prospectID);
            map.put("REFMC", refMc);
            map.put("REFAC", refAc);
            map.put("LISTINGID", listingID);
            LOG.info("User listing and Email are:" + emailAddress + "--" + listingID);
            borrowerThankYouPage.clickGoToMyAccountPage();

        }
        return map;
    }

    public HashMap<String, String> userListingViaPlpPageWithRefresh() throws AutomationException {

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(getAllRadioPagesURI().get(0).get("URL")),
                URLUtilities.getStringURLWithoutScheme(getAllRadioPagesURI().get(0).get("URL")).replace("?null", ""))) {
            partnerLandingPage.setPageElements(pageElements);
            Assert.assertFalse(partnerLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
            // submit the widget
            // partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            // partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.checkYourRate();

            // enter borrower registration details
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

            final String prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            final String refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            final String emailAddress = TestDataProviderUtil.getUniqueEmailIdForTest("testPlpUserListing");
            if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                Assert.assertTrue(publicSiteRegistrationPage.getNumberOfPanes() > 0,
                        "NEW REGISTRAION PAGE IS DISPLAYED TO DM USER");
            }
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                    getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                    emailAddress,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    null,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteOfferPage.reload();
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            personalDetailPage.reload();
            personalDetailPage.waitForPersonalDetailsPage();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            publicSiteTILAPage.reload();
            publicSiteTILAPage.waitForTILAPage();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();

            publicSiteTILAPage.confirmElectronicSignature(); // User navigated to bank info page final
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            publicSiteBankAccountInfoPage.reload();
            publicSiteBankAccountInfoPage.waitForBankPageToLoadCompletely();
            // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            // User navigate to Thank you Page and clicked on go to my account // button
            LOG.info("User navigate to Thank you Page");
            map.put("EMAILADDRESS", emailAddress);
            map.put("PROSPECTID", prospectID);
            map.put("REFMC", refMc);
            map.put("REFAC", refAc);
            map.put("LISTINGID", listingID);
            LOG.info("User listing and Email are:" + emailAddress + "--" + listingID);
            borrowerThankYouPage.clickGoToMyAccountPage();

        }
        return map;
    }

    public HashMap<String, String> primeUserListing(String testIdentifier) throws AutomationException {

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest(testIdentifier);
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        Assert.assertNotNull(accountOverviewPage);
        map.put("EMAILADDRESS", email);
        map.put("LISTINGID", listingID);
        accountOverviewPage.close();
        return map;
    }

    public HashMap<String, String> abpPathAListing(String testIdentifier) throws AutomationException {
        // login to support site
        String pathAUrl = null;
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain(testIdentifier, "p2pcredit");
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);

            LOG.info("ABP User email is" + email);
            supportSiteMainPage.enterEmailAddress(email);
            // click on start application button
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");
            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");
            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            // Updated script as per defect BR-59. Generating URL from referral code.
            pathAUrl = abpPersonalDetailPage.getABPPathAUrl(referralCode);
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // enter bank details

            abpBankInfoPage
                    .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            abpBankInfoPage
                    .enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);

            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        }
        // Use the generated ABP PathA URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
            final String listingID = disclosurePage.getListingIdFromTILAContent();
            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            final PublicSiteThankYouPage thankYouPage = publicSiteBankAccountInfoPage.clearAndEnterBankInfoForExistingUser(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            thankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path A Borrower ListingID is:" + listingID);
            map.put("EMAILADDRESS", email);
            map.put("LISTINGID", listingID);
        }
        return map;

    }

    public void withdrawUserListing(String emailAddress) throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");

        final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(emailAddress, Constant.COMMON_PASSWORD);
        overviewPageAgain.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPageAgain.waitForAccountOverviewPageToLoad();
        overviewPageAgain.dismissCongratulationWelcomeModal();
        if (overviewPageAgain.isElementPresentOnPage(By.linkText(pageElements.get("withdrawRequest_link")))) {
            overviewPageAgain.clickWithdrawYourRequestLink();
            LOG.info("Borrower clicked for withdraw listing request");
            final BorrowerWithdrawListingPage borrowerWithdrawListingPage = overviewPageAgain.clickWithdrawLoanRequest();
            borrowerWithdrawListingPage.clickWithdrawListing();
            Assert.assertTrue(borrowerWithdrawListingPage.getWithdrawListingStatusAsElement().getText()
                    .contains("Your listing has been withdrawn."));
        } else {
            LOG.info("Borrower Listing status is already in WITHDRAWN status");
        }
        LOG.info("Borrower listing is withdraw successfully");
        LOG.info("Borrower having withdrawn listing" + emailAddress);
    }

    public String[] getExistingUserHavingLoan(String loanType) {
        String existingUserWithLoan = null;
        String password = null;
        if (loanType.equalsIgnoreCase("Paid")) {
            if (System.getProperty("environment").contains("qa32")) {
                existingUserWithLoan = MessageBundle.getMessage("existingUserPaid_qa");
                password = Constant.COMMON_PASSWORD;
            } else if (System.getProperty("environment").contains("staging2")) {
                existingUserWithLoan = MessageBundle.getMessage("existingUserPaid_stg");
                password = Constant.OLD_PASSWORD;
            }
            return new String[] {existingUserWithLoan, password};
        } else {
            if (System.getProperty("environment").contains("qa32")) {
                existingUserWithLoan = MessageBundle.getMessage("existingUserCurrentLoan_qa");
                password = Constant.COMMON_PASSWORD;
            } else if (System.getProperty("environment").contains("staging2")) {
                existingUserWithLoan = MessageBundle.getMessage("existingUserCurrentLoan_stg");
                password = Constant.OLD_PASSWORD;
            }

            return new String[] {existingUserWithLoan, password};
        }
    }

    protected String getPersonalDetailsPageUrl(String listingIdVal, String termVal, String firstDueVal, String finalDueVal,
                                               String loanAmountVal, String monthlyPayVal) {
        final String val = "&listing_id=" + listingIdVal + "&" +
                "term=" + termVal + "&" +
                "first_due=" + firstDueVal + "&" +
                "final_due=" + finalDueVal + "&" +
                "loan_amount=" + loanAmountVal + "&" +
                "monthly_pay=" + monthlyPayVal;
        final String personalDetailPageUrl = String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + "/borrower/#/personal-details?type=core" + val);

        return personalDetailPageUrl;
    }

    protected String getTilaPageUrl(String listingIdVal, String termVal, String firstDueVal, String finalDueVal,
                                    String loanAmountVal, String monthlyPayVal) {
        final String val = "&listing_id=" + listingIdVal + "&" +
                "term=" + termVal + "&" +
                "first_due=" + firstDueVal + "&" +
                "final_due=" + finalDueVal + "&" +
                "loan_amount=" + loanAmountVal + "&" +
                "monthly_pay=" + monthlyPayVal;
        final String tilaPageUrl = String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + "/borrower/#/tila?type=core" + val);

        return tilaPageUrl;
    }

    protected String getBankInfoPageUrl(String loanAmount, String listingId, String listingCategoryID) {
        final String val = "&loan_amount=" + loanAmount.replaceAll("\\.0*$", "") +
                "&listing_id=" + listingId.replaceAll("\\.0*$", "") +
                "&listing_category_id=" + listingCategoryID.replaceAll("\\.0*$", "") +
                "&loan_product=PRIME";

        final String bankInfoPageUrl = String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                publicSiteUrl + "/borrower/#/bank-info?type=core" + val);
        return bankInfoPageUrl;
    }

    public HashMap<String, String> generateAgrement(String userEmail)
            throws AutomationException, HttpRequestException, UnsupportedEncodingException, InterruptedException {
        final Map<String, String> experianUserInformation =
                ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA);
        final UserRequest userRequest = buildGenericUserRequest(userEmail, experianUserInformation);

        final UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        final Long testUserId = testUserResponse.getUserRequest().getUserId();

        final PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final OffersResponse offersResponse = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, 4);
        final List<Offer> offers = offersResponse.getListedOffers().getOffers();

        Assert.assertTrue(offers.size() >= 1);

        final String testLoanOfferId = offers.get(0).getLoanOfferId();
        final Long testListingId = offersResponse.getListedOffers().getListingId();
        accountService = new PlatformAccountImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        accountService.createBankAccount(BankAccountConstant.RANDOM_BANK_OF_AMERICA_ACCOUNT);
        documentService = new PlatformDocumentImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        final Listings listingsRequest =
                new Listings.Builder().withListingId(testListingId).withLoanOfferId(testLoanOfferId).build();
        final Listings listingResponse = listingService.updateListing(listingsRequest);
        Assert.assertNotNull(listingResponse);

        // Get all the values needed for building the url
        final Long listingIdVal = listingResponse.getListingId();
        final String listingId = String.valueOf(listingIdVal);
        final int userId = listingResponse.getUserId();

        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withEmployerName(EmploymentInfoConstant.EMPLOYER_NAME)
                .withEmploymentYear(EmploymentInfoConstant.EMPLOYMENT_YEAR)
                .withEmploymentMonth(EmploymentInfoConstant.EMPLOYMENT_MONTH)
                .withOccupationId(EmploymentInfoConstant.OCCUPATION_ID)
                .withEmploymentStatusId(EmploymentInfoConstant.EMPLOYMENT_STATUS_ID).build();

        final ContactInfo contactInfo =
                new ContactInfo.Builder().withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS).build();
        final User user = new User.Builder().withEmploymentInfo(employmentInfo)
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY)).withContactInfo(contactInfo).build();
        final UserRequest updateUserRequest = new UserRequest.Builder().withUser(user).build();

        userService.updateUser(updateUserRequest);

        final MapTemplateArguments mapTemplateArguments = new MapTemplateArguments.Builder().withListingId(testListingId).build();
        final GenerateAgreementRequest request = new GenerateAgreementRequest.Builder().withAgreementTypeId(2)
                .withMapTemplateArguments(mapTemplateArguments).build();

        final GenerateAgreementResponse response = documentService.generateAgreement(request);
        Assert.assertNotNull(response);

        final UUID agreementTransactionId = response.getAgreementTransactionId();

        final CreateAgreementRequest createAgreementRequest = new CreateAgreementRequest.Builder()
                .withAgreementTransactionId(agreementTransactionId).withIsAgreementAuthorized(true).build();
        final CreateAgreementResponse createAgreementResponse = documentService.createAgreement(createAgreementRequest);
        Assert.assertNotNull(createAgreementResponse);

        // Get email for login
        LOG.info("Listing Id :: " + listingId);
        map.put("LISTINGID", listingId);
        map.put("EMAILADDRESS", userEmail);
        map.put("USERID", Integer.toString(userId));
        return map;
    }

    /**
     * Generate offers for User with API flow and returns Personal detail page url accepting offers
     *
     * @return
     * @throws AutomationException
     * @throws HttpRequestException
     * @throws UnsupportedEncodingException
     */
    public HashMap<String, String> generateOffersAndAccept(String userEmail)
            throws AutomationException, HttpRequestException, UnsupportedEncodingException {

        final Map<String, String> experianUserInformation =
                ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA);
        final UserRequest userRequest = buildGenericUserRequest(userEmail, experianUserInformation);

        final UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        final Long testUserId = testUserResponse.getUserRequest().getUserId();

        testUserResponse.getUserRequest().getUserSsn();
        final PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final OffersResponse offersResponse = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, 4);
        final List<Offer> offers = offersResponse.getListedOffers().getOffers();

        Assert.assertTrue(offers.size() >= 1);

        final String testLoanOfferId = offers.get(0).getLoanOfferId();
        final Long testListingId = offersResponse.getListedOffers().getListingId();

        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withEmployerName(EmploymentInfoConstant.EMPLOYER_NAME)
                .withEmploymentYear(EmploymentInfoConstant.EMPLOYMENT_YEAR)
                .withEmploymentMonth(EmploymentInfoConstant.EMPLOYMENT_MONTH)
                .withOccupationId(EmploymentInfoConstant.OCCUPATION_ID)
                .withEmploymentStatusId(EmploymentInfoConstant.EMPLOYMENT_STATUS_ID).build();

        final ContactInfo contactInfo =
                new ContactInfo.Builder().withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS).build();
        final User user = new User.Builder().withEmploymentInfo(employmentInfo)
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY)).withContactInfo(contactInfo).build();
        final UserRequest updateUserRequest = new UserRequest.Builder().withUser(user).build();
        listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        userService.updateUser(updateUserRequest);

        accountService = new PlatformAccountImpl(platformPublicServiceConfig,
                userEmail, Constant.COMMON_PASSWORD);
        accountService
                .createBankAccount(BankAccountConstant.RANDOM_BANK_OF_AMERICA_ACCOUNT);
        final Listings listingsRequest =
                new Listings.Builder().withListingId(testListingId).withLoanOfferId(testLoanOfferId).build();
        final Listings listingResponse = listingService.updateListing(listingsRequest);
        Assert.assertNotNull(listingResponse);

        // Get all the values needed for building the url
        final Long listingIdVal = listingResponse.getListingId();
        final Date firstDueVal = listingResponse.getStartTime();
        final Double loanAmountVal = listingResponse.getAmount();
        final Double monthlyPayVal = listingResponse.getMonthlyPayment();
        final Double fundingTerm = listingResponse.getFundingTerm();
        listingResponse.getUserId();
        final Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String firstDueDate = formatter.format(firstDueVal) + 0000;
        final Date finalDueVal = addYear(firstDueVal, 3);
        String finalDueDate = formatter.format(finalDueVal) + 0000;

        // Encode dates to match the current url format
        LOG.info("Final Date  before encoding:: " + finalDueDate);
        finalDueDate = URLEncoder.encode(finalDueDate, "UTF-8");
        LOG.info("Final Date before encoding:: " + finalDueDate);
        LOG.info("First Date before encoding:: " + firstDueDate);
        firstDueDate = URLEncoder.encode(firstDueDate, "UTF-8");
        LOG.info("First Date after encoding:: " + firstDueDate);

        map.put("listingId", Long.toString(listingIdVal));
        map.put("fundingTerm", Double.toString(fundingTerm));
        map.put("firstDueDate", firstDueDate);
        map.put("finalDueDate", finalDueDate);
        map.put("loanAmount", Double.toString(loanAmountVal));
        map.put("monthlyPay", Double.toString(monthlyPayVal));
        return map;
    }

    // Adds 3 years to the date retrieved
    public static Date addYear(Date date, int i) {
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.YEAR, i);
        LOG.info("firstDueVal::" + cal.getTime());
        return cal.getTime();
    }

    public void removeListingHoldsFrmSpark(Long listingId) throws AutomationException {

        // login to spark site
        final ApplicationContext sparkXMLContext = new ClassPathXmlApplicationContext(
                "spark_site/spring/spark_landing_page.xml");

        final SparkLoginPage sparkLoginPage = (SparkLoginPage) sparkXMLContext.getBean("sparkLoginPage");
        sparkLoginPage.enterEmailAddress(MessageBundle.getMessage("sparkAdminUser"));
        sparkLoginPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        final SparkHeaderPage sparkHeaderPage = sparkLoginPage.clickSignIn();

        final SparkListingsPage sparkListingPage = sparkHeaderPage.searchListingOrUserId(String.valueOf(listingId));
        final SparkListingDetailsPage listingDetailsPage = sparkListingPage.clickSearchedListing(String.valueOf(listingId));

        // Remove holds from listings.
        listingDetailsPage.actionOnHold("BOV", "Approve");
        listingDetailsPage.actionOnHold("POE", "Approve");
        listingDetailsPage.actionOnHold("POI", "Approve");
        listingDetailsPage.actionOnHold("FS", "Approve");
        listingDetailsPage.actionOnHold("ADDRESS", "Approve");
        listingDetailsPage.actionOnHold("MIL", "Approve");
        listingDetailsPage.actionOnHold("POE", "Approve");
        listingDetailsPage.actionOnHold("POI", "Approve");
        listingDetailsPage.actionOnHold("SSC", "Approve");
        listingDetailsPage.actionOnHold("IDV", "Approve");

        listingDetailsPage.clickAprroveListingBtn();
        listingDetailsPage.close();
    }

    public void collectLoanDetails() throws HttpRequestException,
            AutomationException {
        listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        loanOriginationDAO = circleOneDBConnection.getDataAccessObject(LoanOriginationDAO.class);

        Origination_StatusType_Id = loanOriginationDAO.getOriginationStatusTypeId(listingId);

        Error_Result = loanOriginationDAO.getErrorResult(listingId);
        Process_Started_Date = loanOriginationDAO.getProcessStartedDate(listingId);
        Last_Modified_Date = loanOriginationDAO.getLastModifiedDate(listingId);

        Funding_Status = loanOriginationDAO.getOriginationFundingStatus(LOAN_ID);
        Number_Of_Agreement = loanOriginationDAO.getNumberOfLender(LOAN_ID);
        Listing_Status = listingsDAO.getListingStatus(LOAN_ID);
    }

    public void verifyLoanOriginationQueueStatus() throws AutomationException,
            HttpRequestException {

        LOG.info("Origination_StatusType_Id = " + Origination_StatusType_Id);
        LOG.info("listingId " + listingID);
        if (Origination_StatusType_Id == 2) {
            Assert.assertEquals(2, Origination_StatusType_Id);
            Assert.assertEquals(null, Error_Result, "No Errors");
            LOG.info("Loan Originated successfully");
        } else {
            LOG.info("Origination_StatusType_Id = " + Origination_StatusType_Id);
            LOG.info("Loan Originated Failed ");
            LOG.info("ErrorResult" + Error_Result);
            Assert.assertEquals(2, Origination_StatusType_Id);
        }
    }

    public void verifyErrorResult() throws AutomationException,
            HttpRequestException {
        LOG.info("listingId " + listingID);
        LOG.info("Origination_StatusType_Id = " + Origination_StatusType_Id);
        if (Origination_StatusType_Id == 2) {
            LOG.info("Loan Originated successfully");
            LOG.info("ErrorResult = " + Error_Result);
            Assert.assertEquals(null, Error_Result, "No Errors");

        } else {
            LOG.info("Loan Originated Failed ");
            LOG.info("ErrorResult " + Error_Result);
            Assert.assertEquals(2, Origination_StatusType_Id);
        }
    }

    public void verifyLastModifiedDate() throws AutomationException,
            HttpRequestException {
        LOG.info("Process_Started_Date = " + Process_Started_Date);
        final String result = Process_Started_Date.split(" ")[0];
        LOG.info("Process_Started_Date = " + result);
        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setTimeZone(TimeZone.getTimeZone("PST"));
        final Date date = new Date();
        LOG.info("Date = " + dateFormat.format(date));
        Assert.assertEquals(result, dateFormat.format(date));
    }

    public void verifyFundingStatus() throws HttpRequestException,
            AutomationException {
        LOG.info("FundingStatus = " + Funding_Status);
        Assert.assertEquals("Originated", Funding_Status);
    }

    public void verifyListingStatus() throws AutomationException,
            HttpRequestException {
        LOG.info("Listing Status = " + Listing_Status);
        Assert.assertEquals(6, Listing_Status);
    }

    public void verifyLoanToAgreementID() throws AutomationException,
            HttpRequestException {
        Investment_Type_ID = listingsDAO.getInvestmentTypeID(LOAN_ID);
        LOG.info("Get InvestmentType ID = " + Investment_Type_ID);
        if (Investment_Type_ID == 1) {
            Assert.assertEquals(Number_Of_Agreement / 2,
                    loanOriginationDAO.getnumberOfNotNullAgreement(LOAN_ID));
        } else if (Investment_Type_ID == 3) {
            Assert.assertEquals(Number_Of_Agreement,
                    loanOriginationDAO.getnumberOfNullAgreement(LOAN_ID));
        }
    }

    public void verifyListingsInformation() {
        // TODO: 6/21/16
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        Listings l1 = new Listings();
        LOG.info(l1 = listingsDAO.getListingsInfo(LOAN_ID));
        LOG.info("test \n " + l1.getEndingBorrowerAPR());

    }

    public void verifyLoanOverPublicSite(Long loanId, Long listingId, String email) throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        LOG.info("\n\n Login to public site to view loan detail");
        // Log into the Public site with user created above
        final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
        final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(email, MessageBundle.getMessage("password"));

        // Verify that New Account overview page is displayed on sign in
        overviewPageAgain.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPageAgain.dismissCongratulationWelcomeModal();
        LOG.info("\n\n@@@@@@@  Verified loan over public site @@@@@@@");
        overviewPageAgain.close();
        LOG.info("\n\n@@@@@@@@@@@@ LoanId = " + loanId + "\n");
        LOG.info("\n\n" +
                "@@@@@@@@@@@@ ListingId = " + listingId + "\n");
        LOG.info("\n\n" +
                "@@@@@@@@@@@@ Email = " + email + "\n");
    }
}
