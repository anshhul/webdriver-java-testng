package test.ui.pubsite.borrower.appByPhone;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja BMP-3940:DM: Verify that correct value is displayed in
 *         OriginalProspect column of LoanOfferScoreDetail table in prospect db
 */
public class ABPProspectDetailValidationForDMUser extends PartnerLandingPageTestBase {

	private static String ABP_PARTNER_CHANNEL = "Direct Mail";
	protected static final Logger LOG = Logger.getLogger(ABPProspectDetailValidationForDMUser.class.getSimpleName());

	@Autowired
	OutlookWebAppLoginPage outlookAbpWebAppPage;

	@Test(groups = { TestGroup.NIGHTLY })
	public void testLoanOfferScoreDetailForDMUser() throws AutomationException {

		LOG.info("~~~~~~~~~Executing: testLoanOfferScoreDetailForDMUser~~~~~~~~~~~~~~~~~~~~");

		final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
				"support_site/spring/support_site_landing_page.xml");

		final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
				.getBean("supportSiteLandingPage");

		supportSiteLandingPage.enterEmailAddress();
		supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
		final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
		// navigate to home page and select default abp partner as direct mail
		supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
		resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
		supportSiteMainPage.enterOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
		final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlow", "p2pcredit");
		LOG.info("ABP User email is " + email);
		supportSiteMainPage.enterEmailAddress(email);
		// click on start application button
		final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
		// navigate to ABP Registration Page
		abpRegistrationPage.selectEmploymentStatus(
				getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
		LOG.info("CSA user select employment status of borrower");

		// User enter the Yearly Income
		abpRegistrationPage
				.enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
		LOG.info("CSA user entered the yearlyincome of borrower");
		abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
				getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
		// select all disclosures agreements
		abpRegistrationPage.clickOnDisclosures();
		LOG.info("CSA user agreed to disclosures for borrower");
		abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
		abpRegistrationPage
				.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

		abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
		LOG.info("CSA user entered the loanamount for borrower");
		abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
		LOG.info("CSA user select loan purpose for borrower");

		final String prospectID = getQueryMap(abpRegistrationPage.getCurrentURL()).get("prospect_id").toString();

		final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

		// click on choose rate button
		final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
		// csa is submitting personal detail for borrower
		abpPersonalDetailPage
				.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
		abpPersonalDetailPage
				.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
		abpPersonalDetailPage
				.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
		abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
		abpPersonalDetailPage.enterStartOfEmployment(
				getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
		abpPersonalDetailPage.enterSocialSecurityNumber(
				getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
		final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
		// enter bank details

		Assert.assertTrue(abpBankInfoPage.isManualPaymentOptionDisplayed());
		abpBankInfoPage.enterAlternateAccountHolderName(
				getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
		abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
		abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
		abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
		abpBankInfoPage
				.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
		// CSA thank you page is displayed
		final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
		// assert thank you page context
		Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
				Constants.ThankYourPage.ABPTHANKYOUHEADER);
		abpThankYouPage.close();
		// Verify abp mail box and retrieve the finish request url for borrower

		final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
				getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
		// Borrower finish loan request and complete listing
		try (final PublicSiteMarketplaceLandingPage abpLandingPage = new PublicSiteMarketplaceLandingPage(
				webDriverConfig, URLUtilities.getScheme(urlFromWeb),
				URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
			abpLandingPage.setPageElements(pageElements);

			abpLandingPage.clickElectronicSignatureCheckBox();
			abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
			LOG.info("Borrower submit the ABP Landing Page and create own Password");

			final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(urlFromWeb);

			disclosurePage.confirmElectronicSignature();
			final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();

			Assert.assertEquals(publicSiteBankAccountInfoPage.getPriorUserAccountNumber(),
					getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
			Assert.assertEquals(publicSiteBankAccountInfoPage.getPriorUserConfirmAccountNumber(),
					getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));

			final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
			final AccountOverviewPage overviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();
			overviewPage.goTo(
					String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
			overviewPage.dismissCongratulationWelcomeModal();

			final List<Map<String, Object>> userIDTable = queryCircleOne(
					MessageBundle.getMessage("abandonReasonIdQuery").replace("{emailAddress}", email));

			String userID = userIDTable.get(0).get("UserID").toString();

			final List<Map<String, Object>> prospectTable = queryCircleOne(
					MessageBundle.getMessage("loanOfferScoreDetailQuery").replace("{UserID}", userID));

			String value = prospectTable.get(0).get("Value").toString();

			final List<Map<String, Object>> prospectTable1 = queryCircleOne(
					MessageBundle.getMessage("abandonReasonIdQuery").replace("{UserID}", userID));

			Assert.assertTrue(prospectTable1.get(0).get("OfferCode").toString().trim().equals(value.trim()),
					"Value should be equal to Offercode stored in the Prospect");

			LOG.info("~~~~~~~~~Executing: testLoanOfferScoreDetailForDMUser~~~~PASSED~~~~~~~~~~~~~~~");
			LOG.info(
					"BMP-3940:DM: Verify that correct value is displayed in OriginalProspect column of LoanOfferScoreDetail table in prospect db");

		}
	}
}
