
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/18/16.
 */
public class BorrowerDXGetOfferExistingUserTest extends DXCompleteListingTestBase {

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyGetOfferExistingUserListingTest() throws Exception {

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(getUserForEnvironment("testPriorBorrowerListingViaAHLClient"));
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeExistingBorrower(getUserForEnvironment("testPriorBorrowerListingViaAHLClient"));
        PollingUtilities.sleep(2000);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());

        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);

            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            PublicSiteRegistrationPage registrationPage = null;
            if (isPasswordEntered) {
                Assert.assertEquals(dxLandingPage.getUserName(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
                Assert.assertEquals(dxLandingPage.getWelcomeNote(), MessageBundle.getMessage("welcomeMessageNewUser"));
                dxLandingPage.clickElectronicSignatureCheckBox();
                registrationPage = dxLandingPage.clickAgreeAndContinueButtonToGetRegPage();
            } else {

                personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
                personalDetailsPage.waitForPersonalDetailsPage();
                personalDetailsPage.selectOccupation("Chemist");
                personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
                registrationPage = personalDetailsPage.clickContinueForNewDXListing();
            }

            registrationPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            Assert.assertTrue(
                    registrationPage.verifyPrefilledEmail(getUserForEnvironment("testPriorBorrowerListingViaAHLClient")),
                    "Pre-filled email is not correct");
            Assert.assertFalse(registrationPage.isAllFieldsEditable(), "All fields are not Editable.");

            Assert.assertTrue(registrationPage.isEmploymentStatusDropDownEditable(), "Employmentstatus is not editable");
            Assert.assertTrue(registrationPage.isYearlyIncomeFieldEditable(), "Yearly income is not editable.");

            registrationPage.clickElectronicSignatureCheckBox();
            LOG.info("User checked the creditreport checkbox successfully");

            final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
            LOG.info("User submitted the registration page successfully");
            final PublicSitePersonalDetailPage personalDetailsPageAgain = offerPage.clickGetLoan();
            LOG.info("User landed on the Personal detail page after resuming successfully");
            personalDetailsPageAgain
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPageAgain.clickContinue();
            LOG.info("User is able to submit the Personal detail page successfully");
            LOG.info(
                    "BMP-880 Get Offer: Existing: Verify that Loan Terms page displayed on submitting Personal Information page");
            LOG.info("Tila Document is loaded successfully");
            // tilPage.verifyBorrowerDetails(
            // getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase() + " "
            // + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toUpperCase(),
            // getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toUpperCase(),
            // getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toUpperCase() + "," + " "
            // + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toUpperCase() + " "
            // + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toUpperCase());
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            // submit existing bank info page
            final PublicSiteThankYouPage thankYouPage = bankAccountInfoPage.clearAndEnterBankInfoForExistingUser(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                    getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            LOG.info("BMP-867 Get Offer: Existing: Verify that Thank You page displayed on submitting Bank Info page");
            thankYouPage.clickGoToMyAccountPage();
        }
    }
}
