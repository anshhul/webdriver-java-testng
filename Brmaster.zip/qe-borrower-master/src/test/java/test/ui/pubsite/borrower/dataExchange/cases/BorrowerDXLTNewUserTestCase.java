
package test.ui.pubsite.borrower.dataExchange.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import java.io.IOException;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import org.codehaus.jettison.json.JSONException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

/**
 * Created by rsubramanyam on 4/8/16.
 */
public interface BorrowerDXLTNewUserTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Lending Tree: Verify that New User is able to complete listing via DX channel", priority = "P2", labels = {
            "qe_ecosystem_automation", "dx"}, stepToTests = {
                    "Verify that Thank You page displayed on submitting Bank Info page\n"
                            + "Verify that User is able to complete listing successfully"}, expectedResult = "Listing completed successfully and thank you page appears")
    @Test(groups = {TestGroup.SANITY})
    void verifyListingCreationLTNewUser()
            throws IOException, JAXBException, XPathExpressionException, SAXException, ParserConfigurationException,
            TransformerException, AutomationException, HttpRequestException, JSONException;
}
