
package test.ui.pubsite.borrower.appByPhone.wtQpPartner;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-1517 WT: Correct fields should be displayed on selecting 'Warm Transfer(Inbound)' option from top right drop down of Apply
 * By Phone section. BMP-1530 WT: CK: 'Continue' button should be functional on ABP section when Credit Karma partner selected
 * from Partner drop down after selecting 'Warm Transfer(Inbound)' option. BMP-1523 WT: CK: Path A : CSA should be able to drop
 * the funnel on Bank Detail page by clicking Finish button. BMP-1507 WT: CK: Path A: Path A email should be triggered to the
 * borrower who dropped the funnel on Bank Detail page by clicking Finish button. BMP-1493 WT: CK: Path A : Borrower should be
 * able to create password from Create Password landing Page. BMP-1535 WT: CK: Path A: Borrower should be navigated to Loan Terms
 * page of java funnel after creating password. BMP-1504 WT: CK: Path A : Borrower should be navigated to Create Password landing
 * Page of Path A on clicking the links in Password Creation mail. BMP-1513 WT: CK: Path A : Verify the initial TILA of the
 * borrower. BMP-1527 WT: CK: Path A: Borrower should be able to complete the funnel from public site java funnel.
 *
 * @author hnegi
 *
 */
public class ABPWTPathATest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Warm Transfers (Inbound)";
    private static String QUALIFIED_PARTNER = "WarmTransfer (Credit Karma Warm Transfers)";
    protected static final Logger LOG = Logger.getLogger(ABPWTPathATest.class.getSimpleName());
    String pathAURL = null;

    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // BMP-1517 WT: Correct fields should be displayed on selecting 'Warm Transfer(Inbound)' option from top right drop down of
    // Apply By Phone section.
    // BMP-1530 WT: CK: 'Continue' button should be functional on ABP section when Credit Karma partner selected from Partner drop
    // down after selecting 'Warm Transfer(Inbound)' option.
    // BMP-1523 WT: CK: Path A : CSA should be able to drop the funnel on Bank Detail page by clicking Finish button.
    // BMP-1507 WT: CK: Path A: Path A email should be triggered to the borrower who dropped the funnel on Bank Detail page by
    // clicking Finish button.
    // BMP-1493 WT: CK: Path A : Borrower should be able to create password from Create Password landing Page.
    // BMP-1504 WT: CK: Path A : Borrower should be navigated to Create Password landing Page of Path A on clicking the links in
    // Password Creation mail.
    // BMP-1535 WT: CK: Path A: Borrower should be navigated to Loan Terms page of java funnel after creating password.
    // BMP-1513 WT: CK: Path A : Verify the initial TILA of the borrower.
    // BMP-1527 WT: CK: Path A: Borrower should be able to complete the funnel from public site java funnel.

    @Test(groups = {TestGroup.NIGHTLY})
    void testABPWTPathAFlow() throws AutomationException {

        LOG.info("~~~~~~~Executing: testABPWTPathAFlow~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        supportSiteMainPage.selectPartner(QUALIFIED_PARTNER);

        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testABPWTPathAFlow", "p2pcredit");
        LOG.info("ABP User email is " + email);
        Assert.assertTrue(supportSiteMainPage.isPartnerDropdownDisplayed());
        Assert.assertTrue(supportSiteMainPage.isEmailTextFieldDisplayed());
        Assert.assertTrue(supportSiteMainPage.isContinueButtonDisplayed());
        Assert.assertTrue(supportSiteMainPage.isVerifyButtonDisplayed());
        LOG.info("BMP-1517 WT: Correct fields should be displayed on selecting 'Warm Transfer(Inbound)' option from top right drop down of Apply By Phone section.");

        supportSiteMainPage.enterEmailAddress(email);
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnContinue();
        LOG.info("BMP-1530 WT: CK: 'Continue' button should be functional on ABP section when Credit Karma partner selected from Partner drop down after selecting 'Warm Transfer(Inbound)' option.");

        // navigate to ABP Registration Page
        PollingUtilities.sleep(5000);
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");
        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");

        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

        // Get referal code from url
        final String referralCode = abpOfferPage.getReferalCode();

        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

        // csa is submitting personal detail for borrower
        abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        abpPersonalDetailPage
                .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        abpPersonalDetailPage
                .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        // Generate path A url from referral code
        pathAURL = abpPersonalDetailPage.getABPPathAUrl(referralCode);

        final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details
        abpBankInfoPage
                .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        abpBankInfoPage.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();

        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);
        LOG.info("BMP-1523 WT: CK: Path A : CSA should be able to drop the funnel on Bank Detail page by clicking Finish button.");

        // Verify abp mail box and retrieve the finish request url for borrower
        verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        Assert.assertNotNull(pathAURL);
        LOG.info("BMP-1507 WT: CK: Path A: Path A email should be triggered to the borrower who dropped the funnel on Bank Detail page by clicking Finish button.");
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAURL), URLUtilities.getStringURLWithoutScheme(pathAURL))) {
            Assert.assertTrue(abpLandingPage
                    .isStaticTextDisplayed(MessageBundle.getMessage("newUserGreetingMessageOnLandingPage")));
            LOG.info("BMP-1493 WT: CK: Path A : Borrower should be able to create password from Create Password landing Page.");
            LOG.info("BMP-1504 WT: CK: Path A : Borrower should be navigated to Create Password landing Page of Path A on clicking the links in Password Creation mail.");
            LOG.info("BMP-1535 WT: CK: Path A: Borrower should be navigated to Loan Terms page of java funnel after creating password");
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAURL);
            Assert.assertTrue(disclosurePage.isTilLoanPurposerHeaderDisplayed());
            LOG.info("BMP-1513 WT: CK: Path A : Verify the initial TILA of the borrower.");
            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            final AccountOverviewPage overviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();
            overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            overviewPage.dismissCongratulationWelcomeModal();
            final String listingID = overviewPage.getListingInfo().get("LISTING ID");
            // User navigate to Account Overview Page and observed the listing

            LOG.info("ABP WT Path A Borrower ListingID is:" + listingID);
            LOG.info("BMP-1527 WT: CK: Path A: Borrower should be able to complete the funnel from public site java funnel.");
        }
    }
}
