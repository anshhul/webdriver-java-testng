
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.offer.OffersUnfundedRequest;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 11-Jul-2016
 *
 */
public class DMBorrowerFirmOffer5YearTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerExpiredListingFirmOfferTest.class.getSimpleName());
    @Autowired
    IPlatformOffer platFormOffer;
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    // GEAR-864 Verify that TILA is displayed correctly for 5 years offer
    // GEAR-896 Verify that user is able to submit TILA and complete the listing for 5 years offer
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = true)
    void testExpiredDMUserTILADisplayedAndCompleteListingForFiveYearOffers() throws AutomationException, InterruptedException,
            HttpRequestException {
        LOG.info("Executing: testExpiredDMUserReceiveFirmOfferEmail");

        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            // submit DM Landing Page with User's OfferCode
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.getFirstName();
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = Constant.getGloballyUniqueEmailDomain("p2pcredit");
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
           /* if (publicSiteRegistrationPage.getNumberOfPanes() > 0) {
                LOG.info("New Registration page is displayed...");
                publicSiteRegistrationPage.enterLoanAmount(LOAN_AMOUNT);
                publicSiteRegistrationPage.selectLoanPurpose(getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));

            }*/
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            // Submit Personal Details page
            personalDetailPage.fillPersonalDetailPage(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailPage.clickContinue();

            // Accept agreement and submit Tila page
            tilPage.confirmElectronicSignature();
            String listingID = tilPage.getListingIdFromTILAContent();
            PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
            PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankInfoPage.clickAddBankInfoManually();

            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.clickAddBank();
            borrowerThankYouPage.clickGoToMyAccountPage();

            UserEmailDAO userIfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            String userId = userIfo.getUserIDByEmail(emailAddress);

            ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
            listingInfo.updateListingStatusByUserId(5, Long.valueOf(userId));
            // verify firm offer email for expired listing DM User
            OffersResponse offerResponse = platFormOffer.updateUnfundedOffers(new OffersUnfundedRequest(listingID, userId));

            String altKey = offerResponse.getUser().getAltKey();
            verifyWebMail(outlookAbpWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), emailAddress,
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("fundingListingThroughProsper"), MessageBundle.getMessage("loanExpiredMessage"));

            borrowerThankYouPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + "/borrower/#/promotions/firm-offer/alt-code/" + altKey));
            PublicSiteOfferPage offerPage = partnerLandingPage.submitFirmOfferWithPassword(Constant.COMMON_PASSWORD);
            offerPage.select5YearOffer("2000");
            PublicSitePersonalDetailPage detailPage = offerPage.clickGetThisLoanInstead();
            PublicSiteTruthInLendingDisclosurePage disclosurePage = detailPage.clickContinue();
            Assert.assertTrue(disclosurePage.isTruthInLendingDisclosurePageDisplayed());
            LOG.info(
                    "GEAR-864 Verify that TILA is displayed correctly for 5 years offer");
            disclosurePage.confirmElectronicSignature();
            bankInfoPage = disclosurePage.clickContinue();
            bankInfoPage.clickFinish();
            borrowerThankYouPage.clickGoToMyAccountPage();
            LOG.info(
                    "GEAR-896 Verify that user is able to submit TILA and complete the listing for 5 years offer");
        }
    }
}
