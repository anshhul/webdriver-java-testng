
package test.ui.pubsite.borrower.dataExchange;

import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.XMLReader;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.model.wcf.dxReferral.OfferDto;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.util.web.borrower.common.ModifyXMLUtil;
import com.prosper.automation.util.web.borrower.common.Utility;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import com.prosper.automation.wcf.client.DXReferralImpl;
import com.prosper.automation.webdriver.WebDriverConfig;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.xml.sax.SAXException;

import javax.annotation.Resource;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import test.api.WebServiceTestBase;

/**
 * Created by rsubramanyam on 3/30/16.
 */
public class DXCompleteListingTestBase extends WebServiceTestBase {

    public static Properties prop;
    public static final String GETOFFERCLIENT = "GETOFFER_CLIENTS";
    public XMLReader xml;
    @Autowired
    protected CloseableJdbcConnection circleOneDBConnection;
    @Autowired
    protected CloseableJdbcConnection adverseActionEventDBConnection;
    @Autowired
    protected WebDriverConfig webDriverConfig;
    @Resource(name = "pageElements")
    protected Map<String, String> pageElements;
    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;


    public XMLReader getxmlReader() throws AutomationException {
        // String PATH = System.getProperty("user.dir") + "/" + System.getProperty("relative.path.testdata.environment") + "/"
        // + System.getProperty("environment") + "/BorrowerTestData.xml";
        final File file = new File(
                ClassLoader.getSystemResource("testdata/environment/"
                        + System.getProperty("environment") + "/BorrowerTestData.xml").getFile());
        if (file.exists()) {
            return new XMLReader(file);
        } else {
            throw new AutomationException(String.format("Could not find file in the path %s", file));
        }
    }

    // TODO: Create a data file with environment based properties
    public String getUserForEnvironment(String testName) throws AutomationException {
        return getUserForTest(testName).get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG);
    }

    public Hashtable<String, String> getUserForTest(String testName)
            throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsList(testName).get(0);
    }

    @DataProvider(name = "DM_PAGE_TEST_DATA")
    public final Object[][] buildTestData() throws AutomationException {
        xml = getxmlReader();
        return xml.getDataAsArray("PrimeBorrowerValidDetails");
    }

    /**
     * build data for Prime Borrower Example: Gary Bawoski
     *
     * @return
     */
    public Hashtable<String, String> getPrimeBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("TuPrimeBorrowerValidDetails").get(0);
    }

    public Hashtable<String, String> getTUBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("TuPrimeBorrowerValidDetails").get(0);
    }
    /**
     * build data for low ficoscore borrower less than 640
     *
     * @return
     */
    public Hashtable<String, String> getLowFicoLessThan640BorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("LowFiscoLessthan640BorrowerDetails").get(0);
    }

    public Hashtable<String, String> getLowFicoLessThan640TuBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("testCsLessThan640TuUser").get(0);
    }

    public Hashtable<String, String> getInvalidStateBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("InvalidStateBorrowerDetails").get(0);
    }

    public Hashtable<String, String> getTestUsersWith16Plus() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("testUsersWith16Plus").get(0);
    }

    public Hashtable<String, String>  getUserWithMOBLessThan6andFicoGreaterThan640() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("testUserWithMOBLessThan6andFicoGreaterThan640").get(0);
    }

    /**
     * Get common data for all pages i.e Reg, Personal, Manual Bank detail
     *
     * @return
     */
    public Hashtable<String, String> getCommonTestData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("CommonTestDataShare").get(0);
    }

    /**
     * Get existing charge off user details
     *
     * @return
     */
    public Hashtable<String, String> getExistingChargeOfferLoanBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("ExistingChargeOfferUserDetails").get(0);
    }

    /**
     * Get existing low fico less than 640 user details
     *
     * @return
     */
    public Hashtable<String, String> getExistingLowFicoLessthan640Data() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("ExistingLowFicoLessthan640UserDetails").get(0);
    }

    /**
     * build existing prime borrower data e.g Gary BAKOWSKI
     *
     * @return
     */
    public Hashtable<String, String> getExistingPrimeBorrowerData() throws AutomationException {
        xml = getxmlReader();

        return xml.getDataAsList("ExistingPrimeBorrowerOlderThan9Months").get(0);
    }

    protected DXReferralRequest buildDXReferralOfferRequest(final Hashtable<String, String> testData,
                                                                  final String userEmail)
            throws AutomationException {
        return new DXReferralRequest.Builder()
                .withSubProgramId(SUB_PROGRAM_ID)
                // experian data for different credit ratings
                .withFirstName(testData.get(Constants.RegisterationPageConstants.FIRSTNAME_TAG))
                .withLastName(testData.get(Constants.RegisterationPageConstants.LASTNAME_TAG))
                .withDateOfBirth(testData.get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG))
                .withStreet(testData.get(Constants.RegisterationPageConstants.STREETNAME_TAG))
                .withCity(testData.get(Constants.RegisterationPageConstants.CITYNAME_TAG))
                .withState(testData.get(Constants.RegisterationPageConstants.STATE_TAG))
                .withZipCode(testData.get(Constants.RegisterationPageConstants.ZIPCODE_TAG))
                .withSsn(testData.get(Constants.RegisterationPageConstants.SSN_TAG))
                // contact information
                .withEmailAddress(userEmail)
                // loan information
                .withLoanAmount(LOAN_AMOUNT).withLoanPurposeId(LOAN_PURPOSE_ID)
                // employment information
                .withOccupationalId(OCCUPATIONAL_ID)
                .withYearlyIncome(testData.get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG))
                .withYearlyIncomeVerifiable(YEARLY_INCOME_VERIFIABLE)
                .withEmploymentStatusId(7L)
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)
                .withEmployerName(EMPLOYER_NAME)
                // reported credit score
                .withSelfReportedCreditScore(SELF_REPORTED_CREDIT_SCORE)
                .withHomePhoneAreaCode(Constants.UserCommonTestDetails.HOMEPHONEAREACODE)
                .withHomePhoneNumber(Constants.UserCommonTestDetails.HOMEPHONENUMBER)
                .withMobilePhoneAreaCode(Constants.UserCommonTestDetails.MOBILEAREACODE)
                .withMobilePhoneNumber(Constants.UserCommonTestDetails.MOBILENUMBER)
                .withWorkPhoneAreaCode(Constants.UserCommonTestDetails.WORKPHONEAREACODE)
                .withWorkPhoneNumber(Constants.UserCommonTestDetails.WORKPHONENUMBER)
                .withEmployerPhoneAreaCode(Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE)
                .withEmployerPhoneNumber(Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER)
                // bank account information
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(testData.get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();
    }

    public ModifiedXmlEntity buildDXReferralOfferExistingUserRequest(String clientVariant, String firstName, String lastName,
                                                                     String dateOfBirth, String streetName, String city,
                                                                     String state, String zipCode, String loanAmount, String ssn,
                                                                     String email)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                firstName, null, lastName, null, email, dateOfBirth, streetName, city, state, zipCode, loanAmount, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                ssn,
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        return entity;
    }

    /**
     * @return
     * @throws XPathExpressionException
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     * @throws TransformerException
     */
    public ModifiedXmlEntity updateLendingTreeRequestForNewPrimeUser(String email) throws XPathExpressionException, SAXException,
            IOException,
            ParserConfigurationException, TransformerException, AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateLTXMLFile(
                getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                email,
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG), null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG), null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        return entity;
    }

    protected String[] parseOffersResponseForUrls(List<OfferDto> loanOffers) {
        final String[] offerUrls = new String[loanOffers.size()];
        int index = 0;
        for (final OfferDto offer : loanOffers) {
            offerUrls[index++] = offer.getShowSelectedOfferUrl();
        }
        return offerUrls;
    }

    public String[] getTagValue(String responseBody, String tagName) {
        final String[] allURLs = StringUtils.substringsBetween(responseBody, "<" + tagName + ">", "</" + tagName + ">");
        Assert.assertNotNull(allURLs);
        return allURLs;
    }

    public static void init() {
        if (prop == null) {
            final InputStream fis = ClassLoader.getSystemClassLoader()
                    .getResourceAsStream("messageBundle_en.properties");

            prop = new Properties();
            try {
                prop.load(fis);
            } catch (final Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Map<String, Object>> queryProspectDb(String query) throws AutomationException {
        return prospectDBConnection.executeSelectQuery(query);
    }

    @Override
    public List<Map<String, Object>> queryCircleOne(String circleOneQuery) {
        return circleOneDBConnection.executeSelectQuery(circleOneQuery);
    }

    public List<Map<String, Object>> queryAdverseActionEvent(String adverseActionEventQuery) {
        return adverseActionEventDBConnection.executeSelectQuery(adverseActionEventQuery);
    }

    public String navigateToDxLandingPageFromLTResponse(String[] allURLs, String email) throws AutomationException {
        init();
        final Map<String, Object> row =
                queryProspectDb(MessageBundle.getMessage("lendingTreeUrlData").replace("{emailAddress}", email))
                        .get(0);
        final String loanAmount_url = row.get("LoanAmount").toString();
        String apr_url = row.get("APR").toString();
        final BigDecimal apr_url1 = new BigDecimal(apr_url).multiply(new BigDecimal(100));
        apr_url = apr_url1.toString();

        allURLs[0] = allURLs[0].replaceAll("amp;", "");
        allURLs[0] = allURLs[0].replace("{OfferAPRValue}", apr_url);
        allURLs[0] = allURLs[0].replace("{OfferLoanAmount}", loanAmount_url);
        allURLs[0] = allURLs[0].replace("{OfferTermValue}", row.get("NumMonthlyPayments").toString());
        LOG.info(allURLs[0]);
        LOG.info("LT Url is created with the email address:" + email);
        return allURLs[0];
    }

    /**
     * build get offer request for prime borrower ie Garry Bawoski for Credit Karma
     *
     * @return
     */
    public ModifiedXmlEntity buildGetOfferRequestForPrimeBorrower(String clientVariant, String emailAddress)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null,
                emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }

    public ModifiedXmlEntity buildGetOfferRequestForWithOutPersonalDetailsPrimeBorrower(String clientVariant, String emailAddress)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null,
                emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                "", "", "", "", "", "", "", "", "", "", "", "", "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }

    public ModifiedXmlEntity buildGetOfferRequestForSelfEmployedPrimeBorrower(String clientVariant, String emailAddress)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null,
                emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerSelfEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }

    public ModifiedXmlEntity buildGetOfferRequestForOtherPrimeBorrower(String clientVariant, String emailAddress)
            throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null,
                emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerOtherEmploymentStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }
    public ModifiedXmlEntity buildGetOfferRequestForLowFicoLessThan640Borrower(String clientVariant) throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(clientVariant,
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), "L",
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null,
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.EMAILADDRESS_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getLowFicoLessThan640BorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getLowFicoLessThan640BorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));

        return entity;
    }

    /**
     * build get offer request for existing borrower
     *
     * @param emailAddress
     */
    public ModifiedXmlEntity buildGetOfferRequestForPrimeExistingBorrower(String emailAddress) throws AutomationException {
        final ModifiedXmlEntity entity = ModifyXMLUtil.updateXMLFile(Constants.ClientTokenUsers.creditKarmaSubProgramID,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG), null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG), null, emailAddress,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), null, null,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG), null,
                Constants.UserEmploymentStatus.borrowerEmployedStatusID, null,
                Constants.UserCommonTestDetails.HOMEPHONEAREACODE, Constants.UserCommonTestDetails.HOMEPHONENUMBER,
                Constants.UserCommonTestDetails.MOBILEAREACODE, Constants.UserCommonTestDetails.MOBILENUMBER,
                Constants.UserCommonTestDetails.WORKPHONEAREACODE, Constants.UserCommonTestDetails.WORKPHONENUMBER,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG),
                getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                Constants.UserCommonTestDetails.EMPLOYERPHONEAREACODE,
                Constants.UserCommonTestDetails.EMPLOYERPHONENUMBER,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH,
                Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR, "2",
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        return entity;
    }

    public static String getDXUserReferralCode(String query) {
        final int start = query.indexOf("referral_code=") + 14;
        // int start = url.indexOf("list=")+5; **5 is length of ("list=")**
        int end = query.indexOf("&", start);

        end = (end == -1 ? query.length() : end);

        return query.substring(start, end);
    }

    public void expireOfferCode(String offerCode) {
        final ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.updateProspectByOfferCode(offerCode);
    }

    public void validateRunmodes(String testName, String dataRunmode, String currentUrl, String userTestDataIdentifier) {
        logger.debug("Validating runmode for " + testName + " in suite ");
        // suite runmode
        String excelFileName;
        if (userTestDataIdentifier.contains("DX")) {
            excelFileName = ModifyXMLUtil.COMMON_TEST_DATA_ENVIRONMENT + "dxUserTestData.xlsx";

        } else {
            excelFileName = ModifyXMLUtil.COMMON_TEST_DATA_ENVIRONMENT + "userTestData.xlsx";
        }

        final boolean testRunmode = Utility.isTestCaseRunnable(testName, new Xls_Reader(excelFileName));
        boolean dataSetRunmode = false;
        if (currentUrl.contains(dataRunmode)) {
            dataSetRunmode = true;
        }

        if (!(testRunmode && dataSetRunmode)) {
            logger.debug("Skipping the  test " + testName + " inside the suite ");
            throw new SkipException("Skipping the test " + testName + " inside the suite ");
        }

    }

    public HttpResponse validateResponse(DXReferralImpl dxreferral, String requestBody, String dxPath)
            throws UnsupportedEncodingException, HttpRequestException, AutomationException {
        HttpResponse dxReferralOfferResponse;
        if (dxPath.contains("GetOffer")) {
            dxReferralOfferResponse = dxreferral.getOffers(requestBody);
        } else {
            dxReferralOfferResponse = dxreferral.getLTOffers(requestBody);
        }
        LOG.info("Response is: " + dxReferralOfferResponse.getResponseBody());
        dxReferralOfferResponse.assertSuccessfulResponse();
        if (dxReferralOfferResponse.getResponseBody().contains("System Error")) {
            LOG.info("Request body is: { " + requestBody + " }");
            throw new AutomationException(
                    "[SYSTEM ERROR FOUND IN RESPONSE], response is: " + dxReferralOfferResponse.getResponseBody());
        }
        return dxReferralOfferResponse;
    }

    /**
     * Return URL Paramters
     *
     * @param query
     * @return
     */
    public Map<String, String> getQueryMap(String query) {
        final String[] params = query.split("&");
        final Map<String, String> map = new HashMap<String, String>();
        for (final String param : params) {
            final String name = param.split("=")[0];
            final String value = param.split("=")[1];
            map.put(name, value);
        }
        return map;

    }

    public String buildPersonalPageLandingUri(String referralCode, String offerId) {
        offerId = offerId.replace("#pre-screen", "");
        final String borrowerReferralCode = "/borrower/#/personal-details?type=dx&referral_code=" + referralCode;
        final String borrowerOfferId = "&selected_offer_id=" + offerId;
        final String flag = "&flags=testdx:new";
        return borrowerReferralCode + borrowerOfferId + flag;
    }

    public String buildPersonalPageLandingLendingTreeUri(String generatedLTUrl) {
        generatedLTUrl = generatedLTUrl.replace("#pre-screen", "");
        generatedLTUrl = generatedLTUrl.substring(generatedLTUrl.indexOf("?") + 1);
        final String personalDetailPageParam = "/borrower/#/personal-details?type=dx&";
        final String flag = "&flags=testdx:new";
        return personalDetailPageParam + generatedLTUrl + flag;
    }
}
