
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya created on 9 Nov 2016
 */
public class BorrowerIdentityVerificationTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerIdentityVerificationTest.class.getSimpleName());
    private static final String IDV_PAGE_URL = "ssn?";
    private static final String IDV_PAGE_HEADER = "To accurately check your rate, please provide your Social Security number";
    private static final String IDV_PLACEHOLDER_HINT = "Enter your Social Security number";
    private static final String CREDIT_FILE_NOT_FOUND = "Credit file not found";
    private static final String TRANSUNION_CREDIT_FILE_NOT_FOUND = "TransUnion does not have a credit file on record for you";
    private static final String WHY_DO_NEED_THIS_MESSAGE =
            "Your SSN is used to make sure we identify your credit history and not someone else's. All information entered into the Prosper website is kept safe and secure. For more information, please read our Prosper Privacy Policy";


    // BMP-3040 IDV: Verify URL of SSN page displayed on providing incorrect details on register page.
    // BMP-3039 IDV: Loan Offer page not displayed to borrower on providing incorrect SSN (user has provided incorrect address) on
    // "Get Rate" page.
    // BMP-3037 IDV: Text "Enter your social security number" displayed in SSN text field on SSN popup
    // BMP-3035 IDV:Get Your Rate button displayed on SSN page displayed on providing incorrect SSN.
    // BMP-3031 IDV: Correct content should be displayed on hovering the mouse over "Why do we need this?" link
    // BMP-3033 IDV:Validation displayed if user attempts to Submit "Get Rate" page without SSN or with Invalid SSN.
    // BMP-3041 IDV: Text "To accurately check you rate,Please provide your social security number" should be displayed in Bold
    // font on the SSN pop up box.
//    @Test(groups = {TestGroup.NIGHTLY})
    @Test(enabled = false)
    void testSsnPageForWrongLastName() throws AutomationException {
        LOG.info("~~~~~~Executing: testSsnPageForWrongLastName~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testIdentifier");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                RandomStringUtils.random(10, true, false),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        Assert.assertTrue(publicSiteOfferPage.getWindowLocationHref().contains(IDV_PAGE_URL));
        LOG.info("BMP-3040 IDV: Verify URL of SSN page displayed on providing incorrect details on register page.");

        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(IDV_PAGE_HEADER));
        LOG.info(
                "BMP-3041 IDV: Text \"To accurately check you rate,Please provide your social security number\" should be displayed in Bold font on the SSN pop up box.");
        Assert.assertTrue(
                publicSiteRegistrationPage.getSnnFieldAsElement().getAttribute("placeholder").contains(IDV_PLACEHOLDER_HINT));
        LOG.info("BMP-3037 IDV: Text \"Enter your social security number\" displayed in SSN text field on SSN popup");

        PollingUtilities.sleep(6000);
        publicSiteRegistrationPage.verifySSNHint(WHY_DO_NEED_THIS_MESSAGE);
        LOG.info("BMP-3031 IDV: Correct content should be displayed on hovering the mouse over \"Why do we need this?\" link");

        publicSiteRegistrationPage.getSnnFieldAsElement().sendKeys(Constants.UserCommonTestDetails.INVALIDSSN + Keys.TAB);
        publicSiteRegistrationPage.clickGetYourRateSsnPage();
        Assert.assertTrue(publicSiteRegistrationPage
                .isSsnFieldValidationDisplayed(Constants.PersonalDetailPage.SSN_FIELD_VALIDATION));
        LOG.info(
                "BMP-3033 IDV:Validation displayed if user attempts to Submit \"Get Rate\" page without SSN or with Invalid SSN.");

        publicSiteRegistrationPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN);
        LOG.info("BMP-3035 IDV:Get Your Rate button displayed on SSN page displayed on providing incorrect SSN.");
        Assert.assertFalse(publicSiteOfferPage.getWindowLocationHref().contains("offers?"));
        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
        Assert.assertTrue(publicSiteOfferPage.isStaticTextDisplayed(TRANSUNION_CREDIT_FILE_NOT_FOUND));
        LOG.info(
                "BMP-3039 IDV: Loan Offer page not displayed to borrower on providing incorrect SSN (user has provided incorrect address) on \"Get Rate\" page.");
    }

    // BMP-3030 IDV:Loan Offer page displayed to borrower on providing correct SSN (user has provided incorrect Last name) on "Get
    // Rate" page.
    // BMP-3034 IDV:Pre-filled SSN displayed on "Personal Details" page after submitting "Get rate" page with valid SSN value.
//    @Test(groups = {TestGroup.NIGHTLY})
    @Test(enabled = false)
    void testCorrectSsnFlow() throws AutomationException {
        LOG.info("~~~~~~Executing: testCorrectSsnFlow~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testIdentifier");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                RandomStringUtils.random(10, true, false),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
        Assert.assertTrue(publicSiteOfferPage.getWindowLocationHref().contains("offers?"));
        LOG.info(
                "BMP-3030 IDV:Loan Offer page displayed to borrower on providing correct SSN (user has provided incorrect Last name) on \"Get Rate\" page.");
        final PublicSitePersonalDetailPage publicSitePersonalDetailPage = publicSiteOfferPage.clickGetLoan();
        Assert.assertTrue(publicSitePersonalDetailPage.getSsnPopulated());
        Assert.assertTrue(publicSitePersonalDetailPage.getSSnFieldValue().contains("xxx-xx"));
        Assert.assertTrue(publicSitePersonalDetailPage.getSSnFieldValue()
                .contains(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).substring(
                        7, getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).length())));
        LOG.info(
                "BMP-3034 IDV:Pre-filled SSN displayed on \"Personal Details\" page after submitting \"Get rate\" page with valid SSN value.");

    }

    // BMP-3038 IDV:Loan Offer page displayed to borrower on providing correct SSN (user has provided incorrect address) on "Get
    // Rate" page.
//    @Test(groups = {TestGroup.NIGHTLY})
    @Test(enabled = false)
    void testSsnPageForWrongStreetName() throws AutomationException {
        LOG.info("~~~~~~Executing: testSsnPageForWrongStreetName~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testIdentifier");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                RandomStringUtils.random(10, true, false),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        publicSiteRegistrationPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
        Assert.assertTrue(publicSiteOfferPage.getWindowLocationHref().contains("offers?"));
        LOG.info(
                "BMP-3038 IDV:Loan Offer page displayed to borrower on providing correct SSN (user has provided incorrect address) on \"Get Rate\" page.");
        final PublicSitePersonalDetailPage publicSitePersonalDetailPage = publicSiteOfferPage.clickGetLoan();
        Assert.assertTrue(publicSitePersonalDetailPage.getSsnPopulated());
        Assert.assertTrue(publicSitePersonalDetailPage.getSSnFieldValue().contains("xxx-xx"));
        Assert.assertTrue(publicSitePersonalDetailPage.getSSnFieldValue()
                .contains(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).substring(
                        7, getPrimeBorrowerData().get(Constants.PersonalDetailPage.SSN_TAG).length())));
    }
}
