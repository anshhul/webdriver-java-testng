
package test.ui.pubsite.borrower.dataExchange.DXV2;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya
 */
public class DraftListingDXUserOnPersonalPageTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(DraftListingDXUserOnPersonalPageTest.class.getSimpleName());


    // BMP-3742 Verify that user is navigate to TILA page and able to complete listing on submitting DX personal details landing
    // page
    // BMP-3739 Verify that get-offer existing user with draft listing is navigated to personal details landing page on accessing
    // new landing URL
    // BMP-3743 Verify that personal details are saved in circleone correctly.
    // HINT :BMP-5430
    @Test(groups = {TestGroup.NIGHTLY}, enabled = true)
    void testDraftListingUserOnPersonalPage() throws AutomationException, HttpRequestException, UnsupportedEncodingException {
        LOG.info("~~~~Executing: testDraftListingUserOnPersonalPage~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(Double.parseDouble(LOAN_AMOUNT)), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage pdPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text

        pdPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = pdPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();
        Assert.assertNotNull(tilPage);

        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.AHL_SUBPROGRAM_ID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        LOG.info("DX User emailaddress is:" + email);

        final String referral_code = getDXUserReferralCode(offersUrlToUseForTesting);
        final String selected_offer_id =getQueryMap(offersUrlToUseForTesting).get("selected_offer_id").toString();

        final String newUri = buildPersonalPageLandingUri(referral_code, selected_offer_id);

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + newUri)) {
            dxLandingPage.setPageElements(pageElements);

            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());

            Assert.assertTrue(personalDetailsPage.getMobilePhone()
                    .contains(getCommonTestData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG)));
            Assert.assertTrue(personalDetailsPage.getHomePhone()
                    .contains(
                            getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG)));
            Assert.assertTrue(personalDetailsPage.getWorkPhone()
                    .contains(getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG)));
            personalDetailsPage.selectOccupation("Chemist");
            Assert.assertTrue(personalDetailsPage.verifyStartOfEmploymentDate(Constants.UserCommonTestDetails.EMPLOYMENTSTARTMONTH
                    + "/" + Constants.UserCommonTestDetails.EMPLOYMENTSTARTYEAR));

            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            LOG.info("BMP-1001 Get Offer: All the fields except SSN should be editable on Personal Information page-Passed");
            LOG.info(
                    "BMP-1354 Get Offer: User navigated to \"Personal Detail\" page on submitting \"Pre-Screen Create Password Page with Offer\" page with valid details.-Passed");
            final PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            LOG.info("BMP-1233 Get Offer: Verify that Loan Terms page displayed on submitting Personal Information page.-Passed");
            tilPage.confirmElectronicSignature();
            LOG.info(
                    "BMP-3742 Verify that user is navigate to TILA page and able to complete listing on submitting DX personal details landing page");
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilaPage.clickContinue();

            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = bankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
            // User navigate to Thank you Page and clicked on go to my account
            // button

            publicSiteThankYouPage.clickGoToMyAccountPage();
            publicSiteThankYouPage.close();
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(email);
            final List<Map<String, Object>> lendingAccreditationRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
            Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

            final List<Map<String, Object>> agreementRecord =
                    queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
            Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
            Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
            LOG.info("User navigate to Thank you  Page");
            LOG.info(
                    "BMP-3739 Verify that get-offer existing user with draft listing is navigated to personal details landing page on accessing new landing URL");

            // Verify detail on support site

            // login to support site
            final ApplicationContext supportSiteContext =
                    new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");
            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            memberPage.searchByEmail(email);
            final SupportBorrowerTabPage supportBorrowerTabPage = memberPage.clickOnView();

            Assert.assertTrue(supportBorrowerTabPage.getEmploymentInfo().contains("Employed"));
            Assert.assertTrue(supportBorrowerTabPage.getEmploymentInfo().contains("Chemist"));
            Assert.assertTrue(supportBorrowerTabPage.getHomePhoneNumber().contains(
                    Constants.UserCommonTestDetails.HOMEPHONEAREACODE + Constants.UserCommonTestDetails.HOMEPHONENUMBER));
            Assert.assertTrue(supportBorrowerTabPage.getMobilePhoneNumber().contains(
                    Constants.UserCommonTestDetails.MOBILEAREACODE + Constants.UserCommonTestDetails.MOBILENUMBER));
            Assert.assertTrue(supportBorrowerTabPage.getWorkPhoneNumber().contains(
                    Constants.UserCommonTestDetails.WORKPHONEAREACODE + Constants.UserCommonTestDetails.WORKPHONENUMBER));
            LOG.info("BMP-3743 Verify that personal details are saved in circleone correctly.");
            LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");

        }
    }
}
