
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.ChangeContactInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * BMP-4094 ABP: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name
 * and Preferred name BMP-4095 ABP: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when
 * user have different legal name and Preferred name
 *
 * @author hnegi 04-Nov-2016
 *
 */
public class ABPLegalNameOnTILATest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPLegalNameOnTILATest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    @Test(groups = {TestGroup.NIGHTLY})
    void testABPLegalNameOnTILA() throws AutomationException {

        LOG.info("~~~~~~~Executing: testABPLegalNameOnTILA~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        final ApplicationContext jobContext1 =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext1.getBean("publicSitePreRegistrationPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
        supportSiteMainPage.enterOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testABPLegalNameOnTILA", "p2pcredit");
        LOG.info("ABP User email is " + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        final String firstName = abpRegistrationPage.getFirstName();
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");
        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        abpRegistrationPage.enterDateOfBirthIfNotPrefilled(
                getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");

        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

        // click on choose rate button
        final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();
        // csa is submitting personal detail for borrower
        abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        abpPersonalDetailPage
                .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        abpPersonalDetailPage
                .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
        final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details

        abpBankInfoPage
                .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        abpBankInfoPage.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);
        abpThankYouPage.close();
        // Verify abp mail box and retrieve the finish request url for borrower

        final String urlFromWeb = verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(urlFromWeb), URLUtilities.getStringURLWithoutScheme(urlFromWeb))) {
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");

            PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(urlFromWeb);
            publicSitePreRegistrationPage = disclosurePage.clickOnProsperLogo();

            // Navigate to Settings Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = publicSitePreRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName("TestABPUser");
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage =
                    changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            final PublicSiteOfferPage publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            disclosurePage = personalDetailsPage.clickContinue();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            LOG.info("BMP-4094 ABP: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name and Preferred name");
            disclosurePage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLendingDisclosure();
            // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLendingDisclosure();
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            LOG.info("BMP-4095 ABP: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have different legal name and Preferred name");
        }
    }
}
