
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 17-Mar
 *
 */
public class AppResumeModalWithSSNPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeModalWithSSNPageTest.class.getSimpleName());

    /**
     *
     * GEAR-2587 - Verify that user dropping on SSN page coming from App resume sees blank reg page
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyAppResumeModalWithSSNPage() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyAppResumeModalWithSSNPage~~~~~~~~~~~~~~~");

        try (final ClassPathXmlApplicationContext jobContext = new ClassPathXmlApplicationContext(
                "public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext
                    .getBean("publicSitePreRegistrationPage");
            final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAppResumeModalWithSSNPage");
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    RandomStringUtils.random(10, true, false),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            // Verify that SSN page is displayed
            Assert.assertTrue(publicSiteRegistrationPage.isSSNPageDisplayed());

            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is" + altKey);
            Assert.assertNotNull(altKey);

            // Signout user
            publicSitePreRegistrationPage.deleteAllCookies();

            publicSitePreRegistrationPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationPage.checkYourRate();

            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationPage.getAppResumeModal().isDisplayed());

            // Enter details in App Resume Modal
            final PublicSiteRegistrationPage publicSiteRegistrationAgainPage =
                    publicSitePreRegistrationPage.submitAppResumeModalDeclineUser(
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                            getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            Assert.assertTrue(publicSiteRegistrationAgainPage.isRegisterPageDisplayed());
            Assert.assertNull(publicSiteRegistrationAgainPage.getCookie("alt_key"));
            LOG.info("GEAR-2587 - Verify that user dropping on SSN page coming from App resume sees blank reg page");
        }
    }
}
