
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-457 Verify that the support site user is able to allocate and activate the listing of standard borrower BMP-1817 Verify
 * welcome emails in user's personal account
 *
 * @author hisharma
 *
 */
public class ListingActivationTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ListingActivationTest.class.getSimpleName());

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    @Test(groups = {TestGroup.NIGHTLY})
    public void verifyListingActivationScenario() throws AutomationException {

        LOG.info("Test Method Name- verifyListingActivationScenario()");

        final HashMap<String, String> userInfo = primeUserListing("testListingActivation");
        final String email = userInfo.get("EMAILADDRESS");
        final String listingID = userInfo.get("LISTINGID");
        Assert.assertNotNull(listingID, "Account Overview page should be displayed");

        // Log into the Public site with user created above
        try (final ClassPathXmlApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {
            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            // Activate listing
            supportSiteMainPage.activateListing(listingID, "1");

            // Verify Bank account email notification
            verifyWebMail(outlookQAWebAppPage, FunnelNames.DIRECT_TO_SITE_FUNNEL.getFunnelProfile(), email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("bankAccountSubject"), MessageBundle.getMessage(
                            "bankAccountEmailContent"));
            // Verify Email Address notification

            verifyWebMail(outlookQAWebAppPage, FunnelNames.DIRECT_TO_SITE_FUNNEL.getFunnelProfile(), email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("verifyEmailAddress"),
                    MessageBundle.getMessage("verifyEmailAddressEmailContent"));

            // Verify Prosper - loan application notification after listing activation
            verifyWebMail(outlookQAWebAppPage, FunnelNames.DIRECT_TO_SITE_FUNNEL.getFunnelProfile(), email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("listingActivatedSubject"), MessageBundle.getMessage("listingActivatedBody"));
            LOG.info("BMP-1817 Verify welcome emails in user's personal account");
        }
    }
}
