
package test.ui.pubsite.borrower.appByPhone.mintQpPartner;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

/**
 * BMP-1893 Qualified Partner: Mint: Verify that validation appears on leaving email text field blank and clicking continue
 * BMP-1897 Qualified Partner: Mint: Verify that registration page URL appends with referral code on submitting 'Apply by Phone'
 * section with valid email address BMP-1926 Qualified Partner: Mint: Verify that registration page URL appends with refac and
 * refmc code on submitting 'Apply by Phone' section with valid email address BMP-1910 Qualified Partner: Mint: Verify that
 * Reduced pricing with Pricing ID as 23 is offered when 'Mint' is selected from partner drop down BMP-1917 Qualified Partner:
 * Mint: Correct RefAC value should be stored in 'tblCampaign' table of 'Prospect' database BMP-1899 Qualified Partner: Mint:
 * Correct RefMC value should be stored in 'tblCampaignProgram' table of 'Prospect' database BMP-1913 Qualified Partner: Mint:
 * Prospect should be updated with user details on submitting registration page BMP-1909 Qualified Partner: Mint: Prospect should
 * be updated with user details on submitting personal details page BMP-1912 Qualified Partner: Mint: Prospect should be updated
 * with user details on submitting bank information page BMP-1925 Qualified Partner: Mint: Path A: Verify that CSA is able to
 * complete ABP funnel till bank info page. BMP-1911 Qualified Partner: Mint: Path A: Verify that user receives email in mailbox
 * when ABP funnel is completed till bank info page BMP-1907 Qualified Partner: Mint: Path A: Verify that email received in user's
 * mailbox directs user to create password page. BMP-1924 Qualified Partner: Mint: Path A: Verify that TIL page is displayed after
 * user creates password BMP-1903 Qualified Partner: Mint: Path A: Verify initial TILA of user BMP-1902 Qualified Partner: Mint:
 * Path A: Verify that user is able to complete the listing from public site
 *
 * @author hnegi
 *
 */
public class AbpQpPathATest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Qualified Partners";
    private static String QUALIFIED_PARTNER = "QualifiedPartners (Mint)";
    protected static final Logger LOG = Logger.getLogger(AbpQpPathATest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;
    String pathAURL = null;


    // BMP-1893 Qualified Partner: Mint: Verify that validation appears on leaving email text field blank and clicking continue.
    // BMP-1897 Qualified Partner: Mint: Verify that registration page URL appends with referral code on submitting 'Apply by
    // Phone' section with valid email address
    // BMP-1926 Qualified Partner: Mint: Verify that registration page URL appends with refac and refmc code on submitting 'Apply
    // by Phone' section with valid email address
    // BMP-1910 Qualified Partner: Mint: Verify that Reduced pricing with Pricing ID as 23 is offered when 'Mint' is selected from
    // partner drop down
    // BMP-1917 Qualified Partner: Mint: Correct RefAC value should be stored in 'tblCampaign' table of 'Prospect' database
    // BMP-1899 Qualified Partner: Mint: Correct RefMC value should be stored in 'tblCampaignProgram' table of 'Prospect' database
    // BMP-1913 Qualified Partner: Mint: Prospect should be updated with user details on submitting registration page
    // BMP-1909 Qualified Partner: Mint: Prospect should be updated with user details on submitting personal details page
    // BMP-1912 Qualified Partner: Mint: Prospect should be updated with user details on submitting bank information page
    // BMP-1925 Qualified Partner: Mint: Path A: Verify that CSA is able to complete ABP funnel till bank info page
    // BMP-1911 Qualified Partner: Mint: Path A: Verify that user receives email in mailbox when ABP funnel is completed till bank
    // info page
    // BMP-1907 Qualified Partner: Mint: Path A: Verify that email received in user's mailbox directs user to create password page
    // BMP-1924 Qualified Partner: Mint: Path A: Verify that TIL page is displayed after user creates password
    // BMP-1903 Qualified Partner: Mint: Path A: Verify initial TILA of user
    // BMP-1902 Qualified Partner: Mint: Path A: Verify that user is able to complete the listing from public site
    @Test(groups = {TestGroup.NIGHTLY})
    void testABPQPPathAFlow() throws AutomationException {

        LOG.info("~~~~~~~Executing: testABPQPPathAFlow~~~~~~~~~~~~~~");
        // login to support site
        try (final ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
            // navigate to home page and select default abp partner as direct mail
            supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
            supportSiteMainPage.selectPartner(QUALIFIED_PARTNER);
            supportSiteMainPage.clickOnContinueButton();
            Assert.assertTrue(supportSiteMainPage.isStaticTextDisplayed(Constants.EMAILRESTRICTIONMSG));
            LOG.info(
                    "BMP-1893 Qualified Partner: Mint: Verify that validation appears on leaving email text field blank and clicking continue");

            final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testABPQPPathAFlow", "p2pcredit");
            LOG.info("ABP User email is " + email);
            supportSiteMainPage.enterEmailAddress(email);

            supportSiteMainPage.clickOnContinueButton();
            final String referalCode = supportSiteMainPage.getReferralCode("qp");
            final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplicationButton();

            Assert.assertTrue(abpRegistrationPage.getCurrentURL().contains(email));
            Assert.assertTrue(abpRegistrationPage.getCurrentURL().contains(referalCode));
            final String refMc = getQueryMap(abpRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(abpRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            Assert.assertTrue(refMc.contains("mint") && refAc.contains("mint"));
            LOG.info(
                    "BMP-1897 Qualified Partner: Mint: Verify that registration page URL appends with referral code on submitting 'Apply by Phone' section with valid email address");
            LOG.info(
                    "BMP-1926 Qualified Partner: Mint: Verify that registration page URL appends with refac and refmc code on submitting 'Apply by Phone' section with valid email address");

            // navigate to ABP Registration Page
            abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            LOG.info("CSA user entered the firstname of borrower");
            abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
            LOG.info("CSA user entered the lastname of borrower");
            abpRegistrationPage.enterMiddleName("L");
            LOG.info("CSA user entered the middle name of  borrower");
            abpRegistrationPage.selectSuffix("Jr.");
            LOG.info("CSA user entered the streetname of borrower");
            abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            LOG.info("CSA user entered the cityname of borrower");
            abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            LOG.info("CSA user select the state of borrower");
            abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
            LOG.info("CSA user entered the zipcode of borrower");
            // User enter the employment status as Employed
            abpRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            LOG.info("CSA user select employment status of borrower");
            // User enter the Yearly Income
            abpRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            LOG.info("CSA user entered the yearlyincome of borrower");
            // User enter the Date of Birth >18 years
            abpRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            LOG.info("CSA user entered the dateofbirth borrower");
            // select all disclosures agreements
            abpRegistrationPage.clickOnDisclosures();
            LOG.info("CSA user agreed to disclosures for borrower");
            abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
            LOG.info("CSA user entered the loanamount for borrower");
            abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            LOG.info("CSA user select loan purpose for borrower");

            final String prospectID = getQueryMap(abpRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            // Check Reduced pricing for prospect
            final List<Map<String, Object>> prospectOfferInfo =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectPricingId"), prospectID));

            for (final Map<String, Object> prospectRecord : prospectOfferInfo) {
                Assert.assertEquals(prospectRecord.get("PricingId").toString(), Constants.REDUCED_PRICING);
            }
            LOG.info(
                    "BMP-1910 Qualified Partner: Mint: Verify that Reduced pricing with Pricing ID as 23 is offered when 'Mint' is selected from partner drop down");

            // Check RefAC value for prospect
            final List<Map<String, Object>> prospectRefACInfo =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectRefAC"), prospectID));

            for (final Map<String, Object> prospectRecord : prospectRefACInfo) {
                Assert.assertEquals(prospectRecord.get("REFAC").toString(), Constants.REFAC);
            }
            LOG.info(
                    "BMP-1917 Qualified Partner: Mint: Correct RefAC value should be stored in 'tblCampaign' table of 'Prospect' database");

            // Check RefMC value for prospect
            final List<Map<String, Object>> prospectRefMCInfo =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectRefMC"), prospectID));

            for (final Map<String, Object> prospectRecord : prospectRefMCInfo) {
                Assert.assertEquals(prospectRecord.get("REFMC").toString(), Constants.REFMC);
            }
            LOG.info(
                    "BMP-1899 Qualified Partner: Mint: Correct RefMC value should be stored in 'tblCampaignProgram' table of 'Prospect' database");

            final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();

            // Check Prospect should be updated with user details on submitting registration page
            final List<Map<String, Object>> prospectDetails =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectDetails"), prospectID));
            for (final Map<String, Object> prospectRecord : prospectDetails) {
                Assert.assertEquals(prospectRecord.get("FirstName").toString(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase());
                Assert.assertEquals(prospectRecord.get("LastName").toString(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toUpperCase());
                Assert.assertEquals(prospectRecord.get("Address").toString(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toUpperCase());
                Assert.assertEquals(prospectRecord.get("City").toString(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toUpperCase());
                Assert.assertEquals(prospectRecord.get("State").toString(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toUpperCase());
                Assert.assertEquals(prospectRecord.get("LoanAmount").toString().replace("\\.\\d", "").replaceAll("\\.0*$", ""),
                        getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG).replace(",", "").replaceAll("\\.0*$",
                                ""));
                Assert.assertEquals(prospectRecord.get("YearlyIncome").toString().replaceAll("\\.\\d*", ""),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG).replace(",", ""));
            }
            LOG.info(
                    "BMP-1913 Qualified Partner: Mint: Prospect should be updated with user details on submitting registration page");

            // Get referal code from url
            final String referralCode = abpOfferPage.getReferalCode();
            // click on choose rate button
            final ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

            // csa is submitting personal detail for borrower
            abpPersonalDetailPage.enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            abpPersonalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            abpPersonalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            // Generate path A url from referral code
            pathAURL = abpPersonalDetailPage.getABPPathAUrl(referralCode);
            final ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
            // Check Prospect should be updated with user details on submitting personal details page
            final List<Map<String, Object>> prospectPersonalDetails =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectDetails"), prospectID));
            for (final Map<String, Object> prospectRecord : prospectPersonalDetails) {
                Assert.assertEquals(prospectRecord.get("EmployerName"),
                        getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
                Assert.assertEquals(prospectRecord.get("EmployerPhoneAreaCode").toString()
                        + prospectRecord.get("EmployerPhoneNumber").toString(),
                        getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            }
            LOG.info(
                    "BMP-1909 Qualified Partner: Mint: Prospect should be updated with user details on submitting personal details page");

            // enter bank details
            abpBankInfoPage
                    .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
            abpBankInfoPage
                    .enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
            // CSA thank you page is displayed
            final ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();

            PollingUtilities.sleep(2000);
            // Check Prospect should be updated with user details on submitting bank information page
            final List<Map<String, Object>> prospectBankInfo =
                    queryProspectDb(String.format(MessageBundle.getMessage("prospectDetails"), prospectID));
            for (final Map<String, Object> prospectRecord : prospectBankInfo) {
                Assert.assertEquals(prospectRecord.get("BankName").toString(),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
                Assert.assertEquals(prospectRecord.get("RoutingNumber").toString(),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));

            }
            LOG.info(
                    "BMP-1912 Qualified Partner: Mint: Prospect should be updated with user details on submitting bank information page");
            // assert thank you page context
            Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(),
                    Constants.ThankYourPage.ABPTHANKYOUHEADER);
            LOG.info(
                    "BMP-1925 Qualified Partner: Mint: Path A: Verify that CSA is able to complete ABP funnel till bank info page");

            // Verify abp mail box and retrieve the finish request url for borrower

            verifyWebMail(outlookAbpWebAppPage, "ABP", email,
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    MessageBundle.getMessage("followingUp"), MessageBundle.getMessage("followingUpBody"));
            Assert.assertNotNull(pathAURL);
            LOG.info(
                    "BMP-1911 Qualified Partner: Mint: Path A: Verify that user receives email in mailbox when ABP funnel is completed till bank info page");
        }
        // Borrower finish loan request and complete listing
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAURL), URLUtilities.getStringURLWithoutScheme(pathAURL))) {
            Assert.assertTrue(abpLandingPage
                    .isStaticTextDisplayed(MessageBundle.getMessage("newUserGreetingMessageOnLandingPage")));
            LOG.info(
                    "BMP-1907 Qualified Partner: Mint: Path A: Verify that email received in user's mailbox directs user to create password page");
            abpLandingPage.setPageElements(pageElements);

            abpLandingPage.clickElectronicSignatureCheckBox();
            final String offeredAprValue = abpLandingPage.getLoanAPRText();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAURL);
            Assert.assertTrue(disclosurePage.isTilLoanPurposerHeaderDisplayed());
            LOG.info("BMP-1924 Qualified Partner: Mint: Path A: Verify that TIL page is displayed after user creates password");

            Assert.assertTrue(disclosurePage.getAPR().contains(offeredAprValue));
            LOG.info("BMP-1903 Qualified Partner: Mint: Path A: Verify initial TILA of user");

            disclosurePage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");

            // User added general Bank details with routing no
            final PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            /*
             * manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG), null,
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
             * getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);
             */
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            final AccountOverviewPage overviewPage = publicSiteThankYouPage.clickGoToMyAccountPage();

            if (overviewPage.getWindowLocationHref().contains("signin")) {
                overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                overviewPage.dismissCongratulationWelcomeModal();
            }
            // User navigate to Account Overview Page and observed the listing
            final String listingId = overviewPage.getListingInfo().get("LISTING ID");
            LOG.info("ABP QP Path A Borrower ListingID is:" + listingId);
            LOG.info(
                    "BMP-1902 Qualified Partner: Mint: Path A: Verify that user is able to complete the listing from public site");
        }
    }
}
