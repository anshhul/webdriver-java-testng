
package test.ui.pubsite.borrower.appResume;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.List;
import java.util.Map;

public class AppResumeDmUserTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeDmUserTest.class.getSimpleName());


    // GEAR-2890 Verify that app resume funnel works smoothly for DM use
    // GEAR-2704 Verify DM pricing is applied even after navigating through app resume landing page and drops off at TILA
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testDmUserAppResume() throws AutomationException {
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            // submit DM Landing Page with User's OfferCode
            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG);
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));

            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String email = Constant.getGloballyUniqueEmail();
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(email);
            LOG.info("User email addresss is:" + email);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            LOG.info("User navigate to Loan Offer Page");
            // verify existing lisitng decline
            // Get alternate key from cookie
            final String altKey = publicSiteOfferPage.getCookieValue("alt_key");
            LOG.info("alternate key is " + altKey);
            Assert.assertNotNull(altKey);

            final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = publicSiteOfferPage.clickOnProsperLogo();

            // Signout user
            publicSitePreRegistrationAgainPage.deleteAllCookies();

            publicSitePreRegistrationAgainPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme,
                    publicSiteUrl + getAltKeyURL().get(0).get("URL") + "&altkey=" + altKey));

            Assert.assertTrue(publicSitePreRegistrationAgainPage.isContinueYourApplicationButtonDisplayed());
            publicSitePreRegistrationAgainPage.checkYourRate();
            // app resume modal displayed
            Assert.assertTrue(publicSitePreRegistrationAgainPage.getAppResumeModal().isDisplayed());
            final PublicSiteOfferPage offersAgainPage = publicSitePreRegistrationAgainPage.enterDetailsIntoAppResumeModal(
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.YEAROFBORN_TAG),
                    getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            final PublicSitePersonalDetailPage personalDetailPage = offersAgainPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");

            personalDetailPage.enterPrimaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage.enterSecondaryPhone(getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage.enterEmployerName(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage.enterEmployerPhone(getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage.selectOccupation(getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage
                    .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));

            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(email);
            prospectCreated.getOfferCode();

            // User navigate to Account Overview Page and observed the listing
            LOG.info("DM Borrower ListingID is:" + listingID);
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            final Map<String, Object> varID73 = loanOfferScoreDetails.get(1);
            loanOfferScoreDetails.get(2);

            Assert.assertEquals(varID38.get("Value").toString(),
                    getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG),
                    "var 38 value should be same as offer code provided");
            final String var_73_actualValue = varID73.get("Value").toString();
            Assert.assertEquals(var_73_actualValue, "DirectMail|Str201407|C");
            // verify qp reduce pricing as || corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
            LOG.info(
                    "GEAR-2704 Verify DM pricing is applied even after navigating through app resume landing page and drops off at TILA");

        }
    }
}
