
package test.ui.pubsite.borrower.directMail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 11-Jul-2016
 *
 */
public class DMBorrowerDeclineTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerDeclineTest.class.getSimpleName());
    private final static String DECLINE_CONTENT = MessageBundle.getMessage("basedOnCreditQuality");


    // BMP-1726 Make tracking declined scan application available
    // TODO: Test data not available for TU service
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testLoanOfferScoreDetailsForDMDecline() throws AutomationException {

        LOG.info("~~~~~~~~~~~Executing: testLoanOfferScoreDetailsForDMDecline~~~~~~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(Constants.RegisterationPageConstants.DM_DECLINE_TFDL_OFFER_CODE);

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            Constants.RegisterationPageConstants.DM_DECLINE_TFDL_OFFER_CODE);

            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String emailAddress = Constant.getGloballyUniqueEmail(true);

            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // Gear-1804
            /*
             * publicSiteRegistrationPage .enter5digitZipCode(Constants.RegisterationPageConstants.DM_DECLINE_TFDL_ZIP_CODE); if
             * (publicSiteRegistrationPage.getNumberOfPanes() > 0) { LOG.info("New Registration page is displayed...");
             * publicSiteRegistrationPage.enterLoanAmount(LOAN_AMOUNT);
             * publicSiteRegistrationPage.selectLoanPurpose(getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
             *
             * }
             */

            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            // Decline Page content check
            Assert.assertTrue(publicSiteOfferPage.isDeclinePageAppears(), "Decline should be displayed");
            final PublicSiteDeclinePage declinePage = publicSiteOfferPage.goToDeclinePage();
            Assert.assertTrue(declinePage.getDeclinePageContentAsElement().getText().contains(DECLINE_CONTENT));
            // Get user id
            final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userEmail.getUserIDByEmail(emailAddress);

            // Verify Prospect table
            final MarketplaceCreateProspectFromGetOffersDAO prospectRowDetailsInfo =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);
            final Prospect prospectCreated = prospectRowDetailsInfo.getProspectInfoLogByEmailId(emailAddress);
            final String offerCodeInProspecttbl = prospectCreated.getOfferCode();

            final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
            Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
                    DeclineReasonTemplate.TOOFEW_TRADE_LINES.getDeclineReasonID());
            final int listingScoreID = loanOfferDeclineInfo.getListingScoreID(userId);
            final List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("loanOfferScoreDetails").replace("{listingScoreID}",
                            Integer.toString(listingScoreID)));

            final Map<String, Object> varID38 = loanOfferScoreDetails.get(0);
            final Map<String, Object> varID73 = loanOfferScoreDetails.get(1);
            final Map<String, Object> varID515 = loanOfferScoreDetails.get(2);
            Assert.assertEquals(varID38.get("Value").toString(), Constants.RegisterationPageConstants.DM_DECLINE_TFDL_OFFER_CODE,
                    "var 38 value should be same as offer code provided");
            final String var_73_actualValue = varID73.get("Value").toString();
            Assert.assertEquals(var_73_actualValue, "DirectMail|Str201407|C");
            final String var_515_actualValue = varID515.get("Value").toString();
            Assert.assertEquals(var_515_actualValue.trim(), offerCodeInProspecttbl.trim(), "Copy prospect offercode is correct");
    }

    }
}
