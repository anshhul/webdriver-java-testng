
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;

import test.ui.pubsite.borrower.dataExchange.cases.BorrowerDXExpiredGetOfferTestCase;

/**
 * Created by rsubramanyam on 4/7/16.
 */
public class BorrowerDXExpiredGetOfferTest extends DXCompleteListingTestBase
        implements BorrowerDXExpiredGetOfferTestCase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDXExpiredGetOfferTest.class.getSimpleName());


    @Override
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyExpiredOfferDXGetOfferUserTest()
            throws AutomationException, ParserConfigurationException, IOException, SAXException, TransformerException,
            HttpRequestException, JAXBException {
        LOG.info("~~~~Executing: verifyExpiredOfferDXGetOfferUserTest~~~~~~~~~~~");

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("ExpiredOfferDXGetOffer");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0];

        // Navigate to the DX Landing page
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);

            final String dxUserOfferCode = getDXUserReferralCode(offersUrlToUseForTesting);
            // added delay with db sync
            PollingUtilities.sleep(1000);
            expireOfferCode(dxUserOfferCode);

            // Now verify that once offercode is expired (after>30 days) then user will navigate to public site home page not on
            // DX landing page.
            final PublicSitePreRegistrationPage preRegPage = dxLandingPage.reloadPageToReturnToPreRegPage();
            Assert.assertTrue(preRegPage.isBorrowerLandingPageDisplayed());
            LOG.info("~~~~ verifyExpiredOfferDXGetOfferUserTest--PASSED~~~~~~~~~~~");
        }
    }
}
