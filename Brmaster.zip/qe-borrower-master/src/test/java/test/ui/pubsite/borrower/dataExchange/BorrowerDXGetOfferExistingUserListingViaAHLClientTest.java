
package test.ui.pubsite.borrower.dataExchange;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;
import com.prosper.automation.wcf.client.DXReferralImpl;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.IOException;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 16-May-2016
 *
 */
public class BorrowerDXGetOfferExistingUserListingViaAHLClientTest extends DXCompleteListingTestBase {

    protected static final Logger LOG =
            Logger.getLogger(BorrowerDXGetOfferExistingUserListingViaAHLClientTest.class.getSimpleName());


    // BMP-860 Existing User:Get Offer :Employed:AHL: Pricing and Loan Values : User should able to create listing and standard
    // pricing should be displayed to the user.

    @Test(groups = {TestGroup.NIGHTLY})
    void testPriorBorrowerListingViaAHLClient()
            throws AutomationException, HttpRequestException, JsonParseException, JsonMappingException, IOException {

        LOG.info("Executing: testPriorBorrowerListingViaAHLClient");

        final String email = getUserForEnvironment("testPriorBorrowerListingViaAHLClient");
        // supportSiteLandingPage .checkListingStatusAndCancel(email);

        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));
        LOG.info("DX User Email is: " + email);
        final ModifiedXmlEntity entity = buildDXReferralOfferExistingUserRequest(Constants.ClientTokenUsers.AHL_SUBPROGRAM_ID,
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toString(),
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toString(), "3000",
                getExistingPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG).toString(),
                email);

        // initialise ahl wcf configuration
        final ApplicationContext jobContext2 = new ClassPathXmlApplicationContext("wcf/spring/wcf_service_context.xml");

        final DXReferralImpl ahlClientWCFService = (DXReferralImpl) jobContext2.getBean("ahlWCFService");
        PollingUtilities.sleep(2000);
        final HttpResponse response = ahlClientWCFService.getOffers(entity.getRequestBody());

        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");
        LOG.info("New Offers offered to User is:" + offersUrlToUseForTesting);
        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            PublicSiteRegistrationPage registrationPage = null;
            if (isPasswordEntered) {
                Assert.assertEquals(dxLandingPage.getUserName(),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
                Assert.assertEquals(dxLandingPage.getWelcomeNote(), MessageBundle.getMessage("welcomeMessageNewUser"));
                dxLandingPage.clickElectronicSignatureCheckBox();
                registrationPage = dxLandingPage.clickAgreeAndContinueButtonToGetRegPage();
            } else {

                personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
                personalDetailsPage.waitForPersonalDetailsPage();
                personalDetailsPage.selectOccupation("Chemist");
                personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
                registrationPage = personalDetailsPage.clickContinueForNewDXListing();
            }
            registrationPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);

            LOG.info("User clicked on Get My Loan Button successfully");
            Assert.assertTrue(registrationPage.getRegistrationPageHeader());
            Assert.assertTrue(registrationPage.verifyPrefilledEmail(email), "Pre-filled email is not correct");

            registrationPage.clickElectronicSignatureCheckBox();
            LOG.info("User checked the creditreport checkbox successfully");

            final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
            LOG.info("User submitted the registration page successfully");
            final PublicSitePersonalDetailPage personalDetailsPageAgain = offerPage.clickGetLoan();
            LOG.info("User landed on the Personal detail page after resuming successfully");
            personalDetailsPageAgain
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
            LOG.info("User verify the personal detail page with pre-filled values as per Get offer request");
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPageAgain.clickContinue();
            LOG.info("User is able to submit the Personal detail page successfully");
            LOG.info("Tila Document is loaded successfully");
            LOG.info("User navigate to TIL Page");
            final String listingId = tilPage.getListingIdFromTILAContent();
            tilPage.verifyBorrowerDetails(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase() + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG).toUpperCase(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG).toUpperCase(),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG).toUpperCase() + "," + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG).toUpperCase() + " "
                            + getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).toUpperCase());
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            final PublicSiteThankYouPage thankYouPage = bankAccountInfoPage.clickFinish();
            thankYouPage.clickGoToMyAccountPage();
            LOG.info("User listing id is: " + listingId);
            LOG.info(
                    "BMP-860 Existing User:Get Offer :Employed:AHL: Pricing and Loan Values : User should able to create listing and standard pricing should be displayed to the user.");
        }
    }
}
