
package test.ui.pubsite.borrower.dataExchange;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.clients.PlatformUserImpl;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.util.web.borrower.common.ModifiedXmlEntity;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import java.io.IOException;

/**
 * Created by rsubramanyam on 5/16/16.
 */
public class ModernizePwdStrengthTest extends DXCompleteListingTestBase {

    protected static final Logger LOG = Logger.getLogger(ModernizePwdStrengthTest.class.getSimpleName());
    private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
    @Value("${public.site.scheme}")
    String scheme;
    @Value("${public.site.url}")
    String url;
    @Resource
    PlatformUserImpl pubSiteUserService;


    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    public void verifyPasswordStrength()
            throws IOException, JAXBException, JSONException, AutomationException, TransformerException,
            ParserConfigurationException, SAXException, HttpRequestException {
        LOG.info("~~~~Executing: verifyPasswordStrength~~~~~~~~~~~");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyPasswordStrength");
        final ModifiedXmlEntity entity =
                buildGetOfferRequestForPrimeBorrower(Constants.ClientTokenUsers.creditKarmaSubProgramID, email);
        final HttpResponse response = creditKarmaWCFService.getOffers(entity.getRequestBody());
        Assert.assertTrue(response.getResponseBody().contains(Constants.dxResponse.GETOFFERURI),
                "ShowSelectedOfferUrl Tag size is 0");
        final String[] allURLs = getTagValue(response.getResponseBody(), Constants.dxResponse.GETOFFERURI);
        Assert.assertNotNull(allURLs);
        Preconditions.checkNotNull(allURLs.length > 0, "Offers size is 0");
        final String offersUrlToUseForTesting = allURLs[0].replace("amp;", "");

        try (final PublicSiteMarketplaceLandingPage dxLandingPage = new PublicSiteMarketplaceLandingPage(webDriverConfig,
                URLUtilities.getScheme(offersUrlToUseForTesting),
                URLUtilities.getStringURLWithoutScheme(offersUrlToUseForTesting))) {
            dxLandingPage.setPageElements(pageElements);
            PublicSitePersonalDetailPage personalDetailsPage = null;
            final boolean isPasswordEntered = dxLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            if (isPasswordEntered) {
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
                Assert.assertFalse(dxLandingPage.isStaticTextDisplayed("File Permission Error"));
                Assert.assertTrue(dxLandingPage.getUserName()
                        .contains(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase()));
                Assert.assertTrue(MessageBundle.getMessage("welcomeMessageNewUser")
                        .replace("{firstName}",
                                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG).toUpperCase())
                        .contains(dxLandingPage.getWelcomeNote()));

                dxLandingPage.clickElectronicSignatureCheckBox();
                personalDetailsPage =
                        dxLandingPage.clickAgreeAndContinueButton(offersUrlToUseForTesting);
            }
            personalDetailsPage = dxLandingPage.redirectToPersonalDetailPage();
            personalDetailsPage.waitForPersonalDetailsPage();
            Assert.assertFalse(personalDetailsPage.isStaticTextDisplayed("Sass Compiling Error"));
            Assert.assertTrue(personalDetailsPage.getSsnPopulated());
            Assert.assertTrue(personalDetailsPage.isAllFieldEditable());
            personalDetailsPage.selectOccupation("Chemist");
            personalDetailsPage.enterPassword(Constant.COMMON_PASSWORD, isPasswordEntered);
            final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();
            tilPage.confirmElectronicSignature();
            final PublicSiteBankAccountInfoPage bankAccountInfoPage = tilPage.clickContinue();
            bankAccountInfoPage.deleteAllCookies();
            final PublicSitePreRegistrationPage page = bankAccountInfoPage.clickProsperLogo();
            Assert.assertTrue(page.isBorrowerLandingPageDisplayed());
            final PublicSiteSignInPage signInPage = page.clickSignIn();
            final PublicSiteRequestEmailForChangePasswordPage forgotPasswordPage = signInPage.clickForgotPassword();
            forgotPasswordPage.enterEmailAddress(email);
            forgotPasswordPage.clickContinue();
            // final EmailValidationResponse responseFromEmailService = pubSiteUserService.validateUserEmail(email);
            // final UserEmailVerifyResponse verifyResponse =
            // pubSiteUserService.verifyUserEmail(responseFromEmailService.getActivationKey());
            // Assert.assertTrue(verifyResponse.getIsVerified());
            final String code = circleOneDBConnection.getDataAccessObject(UserDAO.class).getUserIDByEmail(email);
            try (final PasswordChangePage pwdChangePage =
                    new PasswordChangePage(webDriverConfig, scheme, url + "/borrower/verify-your-identity#/!?code=" + code)) {
                pwdChangePage.setPageElements(pageElements);
                pwdChangePage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
                pwdChangePage.enterDob(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
                pwdChangePage.clickContinue();
                checkPasswordStrengthMeter(pwdChangePage);
                pwdChangePage.confirmNewPassword(Constant.COMMON_PASSWORD);
                pwdChangePage.clickChangePassword();
                Assert.assertTrue(pwdChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
            }
        }
    }

    private void checkPasswordStrengthMeter(PasswordChangePage pwdChangePage) throws AutomationException {
        pwdChangePage.enterNewPassword("P");
        pwdChangePage.checkPasswordMeter("1 uppercase letter");
        pwdChangePage.enterNewPassword("@");
        pwdChangePage.checkPasswordMeter("1 symbol");
        pwdChangePage.enterNewPassword("ssword");
        pwdChangePage.checkPasswordMeter("8 characters");
        pwdChangePage.enterNewPassword("23");
        pwdChangePage.checkPasswordMeter("1 number");
    }
}
