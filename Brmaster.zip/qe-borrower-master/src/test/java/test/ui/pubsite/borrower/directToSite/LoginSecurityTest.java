
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import test.ui.pubsite.PublicSiteTestBase;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 5/10/16.
 */
// TODO: add ProsperZephyr annotation for TC definition
public final class LoginSecurityTest extends PublicSiteTestBase {

    private static final String INVALID_USER_PASSWORD_ERROR_MSG = "That password is incorrect. Please try again.";


    @Override
    @BeforeSuite
    protected void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testLoginWithValidCredential() throws AutomationException {
        try (final PublicSiteSignInPage publicSiteLoginPage = new PublicSiteSignInPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl)) {
            publicSiteLoginPage.setPageElements(pageElements);

            enterUserEmailAndPassword(publicSiteLoginPage, TEST_USER_EMAIL, TEST_USER_PASSWORD);

            final AccountOverviewPage publicSiteMyAccountPage = publicSiteLoginPage.clickContinue();
            Assert.assertTrue(publicSiteMyAccountPage.hasWelcomeMessageContainer());
        }
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testLoginWithInvalidPassword() throws AutomationException {
        try (final PublicSiteSignInPage publicSiteLoginPage = new PublicSiteSignInPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl)) {
            publicSiteLoginPage.setPageElements(pageElements);

            enterUserEmailAndPassword(publicSiteLoginPage, TEST_USER_EMAIL, INVALID_TEST_USER_PASSWORD);

            publicSiteLoginPage.clickContinue();
            Assert.assertTrue(publicSiteLoginPage.hasErrorDialogMessage(INVALID_USER_PASSWORD_ERROR_MSG));
        }
    }

    private void enterUserEmailAndPassword(final PublicSiteSignInPage publicSiteSignInPage, final String email,
                                           final String password) throws AutomationException {
        publicSiteSignInPage.enterUserEmail(email);
        publicSiteSignInPage.enterUserPassword(password);
    }
}
