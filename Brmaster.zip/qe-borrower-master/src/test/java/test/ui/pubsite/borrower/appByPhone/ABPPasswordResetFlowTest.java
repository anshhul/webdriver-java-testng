
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 05-Jul-2016
 *
 */
public class ABPPasswordResetFlowTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(ABPPasswordResetFlowTest.class.getSimpleName());
	private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
	private static final String SUCCESS_PASSWORD_MESSAGE = "Success. Your password has been changed.";

	@Autowired
	OutlookWebAppLoginPage outlookQAWebAppPage;


	/**
	 * BMP-1816 Verify that both user with c1.stg & p2pcredit domain are able to reset their password
	 *
	 */
    // NOTE: Test BMP-1816 is merged into ABPHappyPathBWithoutEmailTest/testHappyPathBFlowWithoutEmail as part of AUTO-325
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
	void testABPPasswordResetFlow() throws AutomationException, MalformedURLException {
		LOG.info("~~~~~~~Executing: testSignInUserRedirection~~~~~~~~~~");

		// setup ABP Path A User for password reset functionality
		final HashMap<String, String> testData = abpPathAListing("abpresetflow");
		final String abpUserEmail = testData.get("EMAILADDRESS");

		final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
		final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
				(PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
		final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

		final PublicSiteRequestEmailForChangePasswordPage changePasswordPage = publicSiteSignInPage.clickForgotPassword();
		changePasswordPage.enterEmailAddress(abpUserEmail);
		changePasswordPage.clickContinue();

		final String identityVerificationUrl =
				verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), abpUserEmail,
						getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
						MessageBundle.getMessage("followingUp_resetPassword"),
						MessageBundle.getMessage("followingUpBody_resetPassword"));

		final String code = changePasswordPage.getResetCodeForUser(identityVerificationUrl);

		// Navigate to zipcode, date of birth confirmation page, submit it with valid details and observe.
		try (final PublicSiteMarketplaceLandingPage verificationPage =
				new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
						publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + code)) {

			verificationPage.setPageElements(pageElements);
			final PasswordChangePage passwordChangePage = verificationPage.resetPasswordForUser(
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
					getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
			passwordChangePage.enterNewPassword("P@ssword24");
			passwordChangePage.confirmNewPassword("P@ssword24");

			final PublicSiteSignInPage publicSiteSignInAgainPage = passwordChangePage.clickChangePassword();
			Assert.assertTrue(passwordChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
			Assert.assertTrue(passwordChangePage.isStaticTextDisplayed(SUCCESS_PASSWORD_MESSAGE));

			final AccountOverviewPage accountOverviewPage = publicSiteSignInAgainPage.signIn(abpUserEmail, "P@ssword24");
			Assert.assertNotNull(accountOverviewPage);
			LOG.info("GEAR-1274 Verify that registered user is navigated back to sign-in page on resetting his password");

			accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
			accountOverviewPage.dismissCongratulationWelcomeModal();
			LOG.info("BMP-1816 Verify that both user with c1.stg & p2pcredit domain are able to reset their password");
		}
	}
}
