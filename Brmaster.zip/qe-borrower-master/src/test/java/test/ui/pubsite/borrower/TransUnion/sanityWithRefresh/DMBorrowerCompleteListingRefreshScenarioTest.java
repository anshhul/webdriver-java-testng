

package test.ui.pubsite.borrower.TransUnion.sanityWithRefresh;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.UserCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author jdoriya
 *
 */
public class DMBorrowerCompleteListingRefreshScenarioTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(DMBorrowerCompleteListingRefreshScenarioTest.class.getSimpleName());


    @Test(groups = {TestGroup.SANITY})
    void test_Listing_Prospect_RefAc_RefMc() throws AutomationException {
        LOG.info("~~~~~~~~~~~Executing: test_Listing_Prospect_RefAc_RefMc~~~~~~~~~~~~~~~~~~~~");
        // Navigat to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);
            final String offerCode = getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG);
            resetOfferCode(getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
            Assert.assertFalse(partnerLandingPage.isStaticTextDisplayed("Sass Compiling Error"));
            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.submitDmOfferWidget(
                            getCommonTestData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG),
                            getDMValidOfferCodeUserData().get(Constants.HomeWidgetPage.OFFCODE_TAG));
       
            /*----Submit un-filled details of borrower coming with offercode-----------*/
            // User enter the employment status as Employed
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            final String refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            final String refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            LOG.info("RefMc value is:" + refMc);
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            final String prospectID = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("prospect_id").toString();
            LOG.info("User prospect ID is:" + prospectID);
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            final String emailAddress = Constant.getGloballyUniqueEmail(true);
            publicSiteRegistrationPage
                    .enterCity(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            publicSiteRegistrationPage
                    .selectState(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // User entered the random email address
            publicSiteRegistrationPage.clearEmailAddress();
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);

            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            publicSiteRegistrationPage
                    .handleSSNPage(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            publicSiteOfferPage.reload();
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
            LOG.info("User navigate to Loan Offer Page");

            // verify the prospect tbl records
            final Map<String, Object> prospectRows = queryProspectDb(
                    MessageBundle.getMessage("prospectOfferCodeQuery").replace("{offerCode}", offerCode)).get(0);

            // Prospect records shouldnot be null
            Assert.assertFalse(prospectRows.isEmpty(), "Prospect is not generated yet");
            LOG.info("Prospect is generated into prospecttbl for prospect user");

            // verify engagementdate of prospect
            Assert.assertTrue(prospectRows.get("EngagementDate").toString()
                    .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                    "Correct 'CreatedDate' should be displayed");
            final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final String userId = userInfo.getUserIDByEmail(emailAddress);
            // verify userid of prospect
            Assert.assertTrue(prospectRows.get("UserId").toString().contains(userId),
                    "Correct 'userId' should be displayed");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            personalDetailPage.reload();
            personalDetailPage.waitForPersonalDetailsPage();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getDMValidOfferCodeUserData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            publicSiteTILAPage.reload();
            publicSiteTILAPage.waitForTILAPage();
            LOG.info("User navigate to TIL Page");
            final String listingID = publicSiteTILAPage.getListingIdFromTILAContent();
            publicSiteTILAPage.confirmElectronicSignature(); // User navigated to bank info page final
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            publicSiteBankAccountInfoPage.reload();
            publicSiteBankAccountInfoPage.waitForBankPageToLoadCompletely();
            // User select the Manual Bank options LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            final PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
            // User navigate to Thank you Page and clicked on go to my account // button
            LOG.info("User navigate to Thank you Page");

            // Thank you Page and clicked on go to my account // button LOG.info("User navigate to Thank you Page");
            LOG.info("DM Borrower ListingID is:" + listingID);
            circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
            final UserCreditProfilesDAO creditProfilesDAO =
                    circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
            // final UserCreditReportMappingModel creditReportMappingModel =
            // creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 1);
            //
            // // verify IsDecisionBureau is false:
            // Assert.assertEquals(creditReportMappingModel.isIsDecisionBureau(), "0");

            // final ExperianDocumentDAO experianDocumentDAO =
            // circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);
            // // verify externalCreditReportId
            // Assert.assertEquals(experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)),
            // creditReportMappingModel.getExternalCreditReportId());

            /*
             * For row having CreditBureau=2 validate following: ExternalCreditReportId should not be null. IsDecisionBureau
             * should be "1".
             */
            final UserCreditReportMappingModel creditReportMappingModelTu =
                    creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId), 2);
            // verify IsDecisionBureau is false:
            Assert.assertEquals(creditReportMappingModelTu.isIsDecisionBureau(), "1");

            final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);

            /*
             * For row having CreditBureau=1 validate following: IsDecisionBureau should be "0". ExternalCreditReportId should be
             * = Select ExternalCreditReportId from Circleone..ExperianDocuments where UserID = <userid> and
             * documentType='Response Credit Profile'
             */
            // final ListingCreditReportMappingModel listingCreditReportMappingModel =
            // listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 1);
            // // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            // Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
            // experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
            // // verify IsDecisionBureau is false:
            // Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(), "0");

            /*
             * For row having CreditBureau=2 validate following: ExternalCreditReportId should be = Select ExternalCreditReportId
             * from Circleone..UserCreditReportMapping where UserID = <UserID> and CreditBureau=2 IsDecisionBureau should be "1".
             */
            final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                    listingsDAO.getListingCreditReportMapping(Long.valueOf(userId), 2);

            // verify IsDecisionBureau is false:
            Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

            // verify ExternalCreditReportId in tbl ListingCreditReportMapping
            Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
                    creditReportMappingModelTu.getExternalCreditReportId());

            final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
            // verify ExternalModelReportId for TransUnion enabled
            Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
            LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
            // verify ExternalModelReportId for Experian enabled
            final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
            Assert.assertEquals(externalModelReportIdEx, null);

            // Temporary created Transunion DB object
            final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
            final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
            LOG.info("modelReportId is:" + modelReportId);
            Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));

            Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));

        }
    }
}
