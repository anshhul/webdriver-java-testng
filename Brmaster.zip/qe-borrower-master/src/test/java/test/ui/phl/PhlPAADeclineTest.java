package test.ui.phl;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author bhirani
 */
public class PhlPAADeclineTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PhlPAADeclineTest.class.getSimpleName());

    private static final String Provider_ID = "031143";

    @Autowired
    @Qualifier("phlProviderSearchPage")
    private PhlProviderSearchPage phlProviderSearchPage;

    @DataProvider(name = "declineData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "DeclineTestUser_1900"),
        };
    }

    @Test(dataProvider = "declineData", groups = {TestGroup.SANITY})
    public void verifyPHLEndToEndListing(String Key, String loanAmount, String creditQuality,
                                         String firstName, String lastName, String middleInitial, String dob, String homePhone,
                                         String homeAddress, String city, String state, String zipCode, String relationType, String employmentStatus,
                                         String yearlyIncome, String emailAddress, String workPhone, String employerName,
                                         String employerPhone, String occupation, String employmentMonth, String employmentYear, String SSN, String password,
                                         String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
            throws AutomationException {

        phlProviderSearchPage.enterProviderId(Provider_ID);

        PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.verifyProvider();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");

        LOG.info("Email address of the user: "+email);
        phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName, middleInitial,  dob, homePhone, emailAddress,
                homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

        phlRegistrationPage.clickElectronicSignatureCheckBox();
        LOG.info("Email address of the user: "+email);

        PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
        Assert.assertTrue(phlOfferPage.isDeclinePage(), "User declined for declineID 1900");
    }
}
