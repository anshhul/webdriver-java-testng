
package test.ui.phl.idv;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi created on 25 Nov 2016
 */
public class PHLUserIdentityVerificationTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(PHLUserIdentityVerificationTest.class.getSimpleName());
	private static final String CREDIT_FILE_NOT_FOUND = "Credit file not found";

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] {
				Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "HappyPathUser"), };
	}

    /**
     * BMP-4421 PHL: Verify that SSN page is displayed to user on providing incorrect last name. BMP-4424 PHL: Verify that offers
     * page is displayed to user on providing correct SSN on SSN page
     *
     * @throws AutomationException
     */
	@Test(dataProvider = "testData", groups = { TestGroup.ACCEPTANCE })
	void testFunnelForWrongLastNameAndValidSSN(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongLastNameAndValidSSN~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName,
					RandomStringUtils.random(5, true, false), middleInitial, dob, homePhone, emailAddress, homeAddress,
					city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(SSN);
            LOG.info("BMP-4421 PHL: Verify that SSN page is displayed to user on providing incorrect last name.");
			Assert.assertTrue(phlOfferPage.isGetThisLoanButtonDisplayed());
            LOG.info("BMP-4424 PHL: Verify that offers page is displayed to user on providing correct SSN on SSN page");
		}
	}

    /**
     * BMP-4422 PHL: Verify that SSN page is displayed to user on providing incorrect street address
     *
     * @throws AutomationException
     */
	@Test(dataProvider = "testData", groups = { TestGroup.ACCEPTANCE })
	void testFunnelForWrongAddressAndValidSSN(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndValidSSN~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
					middleInitial, dob, homePhone, emailAddress, RandomStringUtils.random(5, true, false), city, state,
					zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(SSN);
            LOG.info("BMP-4422 PHL: Verify that SSN page is displayed to user on providing incorrect street address");
			Assert.assertTrue(phlOfferPage.isGetThisLoanButtonDisplayed());
		}
	}

    /**
     * BMP-4423 PHL: Verify that credit file not found page is displayed to user on providing incorrect SSN on SSN page
     *
     * @throws AutomationException
     */
	@Test(dataProvider = "testData", groups = { TestGroup.ACCEPTANCE })
	void testFunnelForWrongLastNameAndWrongSSN(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongLastNameAndWrongSSN~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName,
					RandomStringUtils.random(5, true, false), middleInitial, dob, homePhone, emailAddress, homeAddress,
					city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN);
			Assert.assertTrue(phlOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
            LOG.info("BMP-4423 PHL: Verify that credit file not found page is displayed to user on providing incorrect SSN on SSN page");
		}
	}

	@Test(dataProvider = "testData", groups = { TestGroup.ACCEPTANCE })
	void testFunnelForWrongAddressAndWrongSSN(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndWrongSSN~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
					middleInitial, dob, homePhone, emailAddress, RandomStringUtils.random(5, true, false), city, state,
					zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN);
			Assert.assertTrue(phlOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
		}
	}

	@Test(dataProvider = "testData", groups = { TestGroup.ACCEPTANCE })
	void testFunnelForWrongFirstName(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongFirstName~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality,
					RandomStringUtils.random(5, true, false), lastName, middleInitial, dob, homePhone, emailAddress,
					homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			Assert.assertTrue(phlOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
		}
	}

	/**
	 * SSN with Hyphen
	 *GEAR-2895:User navigated to offer page when provding SSN with hyphen in ALT SSN page
	 *
	 */

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testFunnelForWrongLastNameAndValidSSNWithHyphen(String Key, String loanAmount, String creditQuality,
			String firstName, String lastName, String middleInitial, String dob, String homePhone, String homeAddress,
			String city, String state, String zipCode, String relationType, String employmentStatus,
			String yearlyIncome, String emailAddress, String workPhone, String employerName, String employerPhone,
			String occupation, String employmentMonth, String employmentYear, String SSN, String password,
			String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
			throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongLastNameAndValidSSNWithHyphen~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName,
					RandomStringUtils.random(5, true, false), middleInitial, dob, homePhone, emailAddress, homeAddress,
					city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG_HYPHEN));
			Assert.assertTrue(phlOfferPage.isGetThisLoanButtonDisplayed());
		}
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testFunnelForWrongAddressAndValidSSNWithHyphen(String Key, String loanAmount, String creditQuality,
			String firstName, String lastName, String middleInitial, String dob, String homePhone, String homeAddress,
			String city, String state, String zipCode, String relationType, String employmentStatus,
			String yearlyIncome, String emailAddress, String workPhone, String employerName, String employerPhone,
			String occupation, String employmentMonth, String employmentYear, String SSN, String password,
			String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
			throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndValidSSNWithHyphen~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);
			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
					middleInitial, dob, homePhone, emailAddress, RandomStringUtils.random(5, true, false), city, state,
					zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG_HYPHEN));
			Assert.assertTrue(phlOfferPage.isGetThisLoanButtonDisplayed());
		}
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testFunnelForWrongLastNameAndWrongSSNWithHyphen(String Key, String loanAmount, String creditQuality,
			String firstName, String lastName, String middleInitial, String dob, String homePhone, String homeAddress,
			String city, String state, String zipCode, String relationType, String employmentStatus,
			String yearlyIncome, String emailAddress, String workPhone, String employerName, String employerPhone,
			String occupation, String employmentMonth, String employmentYear, String SSN, String password,
			String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
			throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongLastNameAndWrongSSNWithHyphen~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName,
					RandomStringUtils.random(5, true, false), middleInitial, dob, homePhone, emailAddress, homeAddress,
					city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN_HYPHEN);
			Assert.assertTrue(phlOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
		}
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testFunnelForWrongAddressAndWrongSSNWithHyphen(String Key, String loanAmount, String creditQuality,
			String firstName, String lastName, String middleInitial, String dob, String homePhone, String homeAddress,
			String city, String state, String zipCode, String relationType, String employmentStatus,
			String yearlyIncome, String emailAddress, String workPhone, String employerName, String employerPhone,
			String occupation, String employmentMonth, String employmentYear, String SSN, String password,
			String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
			throws AutomationException {

		LOG.info("~~~~~~Executing: testFunnelForWrongAddressAndWrongSSNWithHyphen~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
					middleInitial, dob, homePhone, emailAddress, RandomStringUtils.random(5, true, false), city, state,
					zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(Constants.UserCommonTestDetails.INTSSN_HYPHEN);
			Assert.assertTrue(phlOfferPage.isStaticTextDisplayed(CREDIT_FILE_NOT_FOUND));
		}
    }

    /**
     * BMP-4504 PHL: Verify that correct validation on providing incorrect SSN on SSN page.
     *
     * @throws AutomationException
     */
    @Test(dataProvider = "testData", groups = {TestGroup.ACCEPTANCE})
    void testFunnelForIncorrectSSN(String Key, String loanAmount, String creditQuality, String firstName,
                                   String lastName, String middleInitial, String dob, String homePhone, String homeAddress,
                                   String city,
                                   String state, String zipCode, String relationType, String employmentStatus,
                                   String yearlyIncome,
                                   String emailAddress, String workPhone, String employerName, String employerPhone,
                                   String occupation,
                                   String employmentMonth, String employmentYear, String SSN, String password, String bankName,
                                   String routingNumber, String accountNumber, String confirmAccountNumber)
            throws AutomationException {

        LOG.info("~~~~~~Executing: testFunnelForWrongFirstName~~~~~~~~~~~~~~~");

        try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
            phlProviderSearchPage.setPageElements(pageElements);

            final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

            emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality,
                    firstName, lastName, middleInitial, dob, homePhone, emailAddress,
                    homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

            phlRegistrationPage.clickElectronicSignatureCheckBox();
            LOG.info("Email address of the user: " + emailAddress);

            final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
            final PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();

            // Submit Personal details page, p2B call will happen here
            phlPersonalDetailsPage.submitPersonalDetailPage(workPhone, employerName, employerPhone, occupation, employmentMonth,
                    employmentYear, Constants.UserCommonTestDetails.INTSSN_HYPHEN,
                    emailAddress, Constant.COMMON_PASSWORD);
            phlPersonalDetailsPage.clickToCheckValidation();
            PollingUtilities.sleep(3000);
            LOG.info("AUTO-473: Automated Scenarios where we are providing only incorrect SSN in all funnels");
            Assert.assertTrue(phlPersonalDetailsPage.getSSNValidationMessage()
                    .contains(MessageBundle.getMessage("ssnValidationMessage")));
            LOG.info("BMP-4504 PHL: Verify that correct validation on providing incorrect SSN on SSN page.");
        }
    }
}
