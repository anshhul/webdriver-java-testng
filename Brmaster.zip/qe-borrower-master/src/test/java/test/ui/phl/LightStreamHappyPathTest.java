package test.ui.phl;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.LightStreamPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.LightStreamRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProgramSelectPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author bhirani
 */
public class LightStreamHappyPathTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(LightStreamHappyPathTest.class.getSimpleName());

    private static final String Provider_ID = "031142";

    @Autowired
    @Qualifier("phlProviderSearchPage")
    private PhlProviderSearchPage phlProviderSearchPage;

    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlLightStreamTestUsers", "LightStreamUser"),
        };
    }

    @Test(dataProvider = "testData", groups = {TestGroup.SANITY})
    public void verifyPHLEndToEndListing(String Key, String loanAmount, String creditQuality,
                                         String firstName, String lastName, String middleInitial, String dob, String homePhone, String emailAddress,
                                         String relationType, String homeAddress, String city, String state, String zipCode, String residenceType,
                                         String monthlyPayment, String residentYears, String residentMonths, String SSN,
                                         String licenseNumber, String employmentStatus, String workTitle, String workPhone,
                                         String yearlyIncome, String employerName, String employerAddress, String employerCity, String employerState,
                                         String employerZip, String employmentMonths, String employmentYears)
            throws AutomationException {

        LOG.info("~~~~~~Executing: verifyLightStreamFunnel~~~~~~~~~~~~~~~");

        phlProviderSearchPage.enterProviderId(Provider_ID);

        PhlProgramSelectPage phlProgramSelectPage = phlProviderSearchPage.selectProvider();
        LightStreamRegistrationPage lightStreamRegistrationPage = phlProgramSelectPage.clickExceptionalProgram();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");

        LOG.info("Email address of the user: "+email);

        lightStreamRegistrationPage.submitRegistrationForm(loanAmount,creditQuality, firstName, lastName, middleInitial, dob, homePhone, emailAddress,
                homeAddress,city,state, zipCode, residenceType, monthlyPayment, residentYears, residentMonths);
        LightStreamPersonalDetailsPage lightStreamPersonalDetailsPage = lightStreamRegistrationPage.clickContinue();

        lightStreamPersonalDetailsPage.submitPersonalDetailsPage(SSN,licenseNumber,employmentStatus, workTitle, workPhone, yearlyIncome, employerName,
                employerAddress, employerCity, employerState, employerZip, employmentYears, employmentMonths);
        lightStreamPersonalDetailsPage.clickElectronicSignatureCheckBox();
        lightStreamPersonalDetailsPage.submitPage();


    }
}
