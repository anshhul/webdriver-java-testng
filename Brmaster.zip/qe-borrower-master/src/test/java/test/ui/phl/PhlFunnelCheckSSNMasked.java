package test.ui.phl;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja BR-207: Verify that SSN on personal details is masked when
 *         SSN is already filled by user after reg page
 */
public class PhlFunnelCheckSSNMasked extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(PhlFunnelCheckSSNMasked.class.getSimpleName());

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] {
				Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "HappyPathUser"), };
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testPhlFunnelCheckSSNMasked(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testPhlFunnelCheckSSNMasked~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName,
					RandomStringUtils.random(5, true, false), middleInitial, dob, homePhone, emailAddress, homeAddress,
					city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			phlOfferPage.handleSSNPage(SSN);
			Assert.assertTrue(phlOfferPage.isGetThisLoanButtonDisplayed());
			// go to PD page
			PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();

			// Check whether SSN value masked or not
			Assert.assertTrue(phlPersonalDetailsPage.getSSNMaskedValueMaskedValue()
					.contains((MessageBundle.getMessage("phlMaskedSSNValue"))));
		}
	}
}
