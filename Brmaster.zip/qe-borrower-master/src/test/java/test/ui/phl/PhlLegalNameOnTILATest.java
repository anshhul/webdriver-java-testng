
package test.ui.phl;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.ChangeContactInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * BMP-4088 PHL: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name
 * and Preferred name BMP-4089 PHL: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when
 * user have different legal name and Preferred name
 *
 * @author hnegi 04-Nov-2016
 */
public class PhlLegalNameOnTILATest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PhlLegalNameOnTILATest.class.getSimpleName());

    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "HappyPathUser"),
        };
    }

    @Test(dataProvider = "testData", groups = {TestGroup.NIGHTLY})
    public void testPhlLegalNameOnTILA(String Key, String loanAmount, String creditQuality,
                                       String firstName, String lastName, String middleInitial, String dob, String homePhone,
                                       String homeAddress, String city, String state, String zipCode, String relationType,
                                       String employmentStatus,
                                       String yearlyIncome, String emailAddress, String workPhone, String employerName,
                                       String employerPhone, String occupation, String employmentMonth, String employmentYear,
                                       String SSN, String password,
                                       String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
            throws AutomationException {

        LOG.info("~~~~~~Executing: testPhlLegalNameOnTILA~~~~~~~~~~~~~~~");
        try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
            phlProviderSearchPage.setPageElements(pageElements);
            final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();
            emailAddress =
                    phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName, middleInitial, dob,
                            homePhone,
                            emailAddress, homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

            phlRegistrationPage.clickElectronicSignatureCheckBox();
            LOG.info("Email address of the user: " + emailAddress);

            final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();

            // Select from 2 displayed loans
            final PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();

            // Submit Personal details page, p2B call will happen here
            phlPersonalDetailsPage.submitPersonalDetailPage(workPhone, employerName, employerPhone, occupation, employmentMonth,
                    employmentYear, SSN,
                    emailAddress, Constant.COMMON_PASSWORD);
            final PhlTruthInLendingDisclosurePage phlTruthInLendingDisclosurePage = phlPersonalDetailsPage.clickContinue();

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage = phlTruthInLendingDisclosurePage.clickOnLogo();

            // Navigate to Settings Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
            SettingsPage settingPage = publicSitePreRegistrationPage.goToSettingsPage();

            final ChangeContactInformationPage changeContactInformationPage = settingPage.clickOnEditContactInformationLink();

            changeContactInformationPage.enterPreferredFirstName("TestABPUser");
            changeContactInformationPage.selectPreferredPhone("Home");
            settingPage =
                    changeContactInformationPage.clickOnChangeButton();
            final AccountOverviewPage accountOverviewPage = settingPage.gotoAccountOverviewPage();
            final PublicSiteOfferPage publicSiteOfferPage = accountOverviewPage.clickFinishApplication();
            final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            final PublicSiteTruthInLendingDisclosurePage disclosurePage = personalDetailsPage.clickContinue();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            LOG.info(
                    "BMP-4088 PHL: Verify that Legal Name is displayed as borrowers name on initial tila page when user have different legal name and Preferred name");
            disclosurePage.confirmElectronicSignature();

            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            publicSiteBankAccountInfoPage.clickProsperLogo();

            // Navigate to History Page
            publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
            final AccountHistoryPage accountHistoryPage = publicSitePreRegistrationPage.goToHistoryPage();
            final PublicSiteEventHistoryPage eventHistoryPage = accountHistoryPage.clickEventHistoryLink();
            eventHistoryPage.clickOnLinkWithinEventDetail("truthInLendingDisclosure_linkText");
            // eventHistoryPage.clickOnLink("Listing Truth in Lending Disclosure");
            eventHistoryPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
            eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
            final PublicSiteLegalAgreementsPage legalAgreementPage = accountHistoryPage.clickLegalAgreementsLink();
            legalAgreementPage.clickOnLinkWithinEventDetail("truthInLendingDisclosure_linkText");
            legalAgreementPage.switchToNewlyOpenedWindow();
            Assert.assertTrue(disclosurePage.getBorrowerDetails().contains(firstName));
            LOG.info(
                    "BMP-4089 PHL: Verify that Legal Name as borrowers name is saved in Listing Truth in Lending Disclosure when user have different legal name and Preferred name");
        }
    }

}
