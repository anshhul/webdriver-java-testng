package test.ui.phl;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.LightStreamPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.LightStreamRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProgramSelectPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.util.logging.Level;

/**
 * @author bhirani
 */
public class LightStreamDeclineTest extends PartnerLandingPageTestBase {
    private WebDriver wd = null;

    private static final String Provider_ID = "031142";

    @Autowired
    @Qualifier("phlProviderSearchPage")
    private PhlProviderSearchPage phlProviderSearchPage;

    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][]{
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlLightStreamTestUsers", "LightStreamUser"),
        };
    }

    @BeforeMethod
    public void beforeMethod() {
        DesiredCapabilities dc = DesiredCapabilities.firefox();
        LoggingPreferences prefs = new LoggingPreferences();
        prefs.enable(LogType.BROWSER, Level.ALL);
        dc.setCapability(CapabilityType.LOGGING_PREFS, prefs);
        wd = new FirefoxDriver(dc);
    }

    @AfterMethod
    public void afterMethod() {
        //if (wd != null) {
        LogEntries logEntries = wd.manage().logs().get(LogType.BROWSER);
        for (LogEntry eachEntry : logEntries.getAll()) {
            System.out.println(eachEntry.toString());
        }
        wd.quit();
    }


    @Test(dataProvider = "testData", groups = {TestGroup.SANITY})
    public void verifyPHLEndToEndListing(String Key, String loanAmount, String creditQuality,
                                         String firstName, String lastName, String middleInitial, String dob, String homePhone, String emailAddress,
                                         String relationType, String homeAddress, String city, String state, String zipCode, String residenceType,
                                         String monthlyPayment, String residentYears, String residentMonths, String SSN,
                                         String licenseNumber, String employmentStatus, String workTitle, String workPhone,
                                         String yearlyIncome, String employerName, String employerAddress, String employerCity, String employerState,
                                         String employerZip, String employmentMonths, String employmentYears)
            throws AutomationException {

   /*     LOG.info("~~~~~~Executing: verifyLightStreamFunnel~~~~~~~~~~~~~~~");

        phlProviderSearchPage.enterProviderId(Provider_ID);

        PhlProgramSelectPage phlProgramSelectPage = phlProviderSearchPage.selectProvider();
        LightStreamRegistrationPage lightStreamRegistrationPage = phlProgramSelectPage.clickExceptionalProgram();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");

        LOG.info("Email address of the user: " + email);

        lightStreamRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName, middleInitial, dob, homePhone, emailAddress,
                homeAddress, city, state, zipCode, residenceType, monthlyPayment, residentYears, residentMonths);
        LightStreamPersonalDetailsPage lightStreamPersonalDetailsPage = lightStreamRegistrationPage.clickContinue();

        lightStreamPersonalDetailsPage.submitPersonalDetailsPage(SSN, licenseNumber, employmentStatus, workTitle, workPhone, yearlyIncome, employerName,
                employerAddress, employerCity, employerState, employerZip, employmentYears, employmentMonths);
        lightStreamPersonalDetailsPage.clickElectronicSignatureCheckBox();
        lightStreamPersonalDetailsPage.submitPage();

    }*/
    }
}




