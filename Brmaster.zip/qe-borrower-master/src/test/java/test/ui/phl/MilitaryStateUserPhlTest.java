package test.ui.phl;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.db.mapper.ProspectCreditReportMappingModel;
import com.prosper.automation.db.mapper.UserCreditReportMappingModel;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PhlBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PhlTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja
 * 
 *         BMP-4447 Verify that TU user from military state is able to complete
 *         listing successfully from PHL
 */
public class MilitaryStateUserPhlTest extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(MilitaryStateUserPhlTest.class.getSimpleName());

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] {
				Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "MilitaryStateUser"), };
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	public void testMilitaryStateUserPhl(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testMilitaryStateUserPhl~~~~~~~~~~~~~~~");

		// phlProviderSearchPage.enterProviderId(Provider_ID);

		// final PhlRegistrationPage phlRegistrationPage =
		// phlProviderSearchPage.verifyProvider();
		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();
			final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testMilitaryStateUser");
			phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName, middleInitial,
					dob, homePhone, email, homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

			phlRegistrationPage.selectStateOfResidence(
					getMilitaryStateBorrowerData().get(Constants.RegisterationPageConstants.STATE_OF_RESIDENCE_TAG));
			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + email);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();

			// Select from 2 displayed loans
			final PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();

			// Submit Personal details page, p2B call will happen here
			phlPersonalDetailsPage.submitPersonalDetailPage(workPhone, employerName, employerPhone, occupation,
					employmentMonth, employmentYear, SSN, email, Constant.COMMON_PASSWORD);
			final PhlTruthInLendingDisclosurePage phlTruthInLendingDisclosurePage = phlPersonalDetailsPage
					.clickContinue();

			// Initial Tila Submission
			phlTruthInLendingDisclosurePage.agreementSelection();
			final PhlBankAccountInfoPage phlBankAccountInfoPage = phlTruthInLendingDisclosurePage.clickContinue();

			// Bank account page
			phlBankAccountInfoPage.submitBankInfo(bankName, routingNumber, accountNumber, confirmAccountNumber);
			final PhlThankYouPage phlThankYouPage = phlBankAccountInfoPage.clickSubmitYourApplication();

			phlThankYouPage.clickGoToMyAccountPage();
			PollingUtilities.sleep(5000);

			/*
			 * For row having CreditBureau=1 validate following:
			 * IsDecisionBureau should be "0". ExternalCreditReportId for
			 * CreditBureau=1 should be = Select ExternalCreditReportId from
			 * Circleone..ExperianDocuments where UserID = <userid> and
			 * documentType='Response Credit Profile'
			 */

			final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
			final String userId = userInfo.getUserIDByEmail(email);

			final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
			final String prospectId = prospectDAO.getProspectIdByEmail(email);

			final ProspectCreditReportMappingModel prospectCreditReportMappingModelTu = prospectDAO
					.getUserCreditReportMapping(prospectId, 2);

			// verify isdecisionbureau for tu enabled service
			Assert.assertEquals(prospectCreditReportMappingModelTu.getIsDecisionBureau(), "1");

			// final ProspectCreditReportMappingModel
			// prospectCreditReportMappingModelExp =
			// prospectDAO.getUserCreditReportMapping(prospectId, 1);
			// // verify isdecisionbureau for tu enabled service
			// Assert.assertEquals(prospectCreditReportMappingModelExp.getIsDecisionBureau(),
			// "0");

			final UserCreditProfilesDAO creditProfilesDAO = circleOneDBConnection
					.getDataAccessObject(UserCreditProfilesDAO.class);
			// final UserCreditReportMappingModel creditReportMappingModel =
			// creditProfilesDAO.getUserCreditReportMapping(Long.valueOf(userId),
			// 1);
			//
			// // verify IsDecisionBureau is false:
			// Assert.assertEquals(creditReportMappingModel.isIsDecisionBureau(),
			// "0");
			//
			// final ExperianDocumentDAO experianDocumentDAO =
			// circleOneDBConnection.getDataAccessObject(ExperianDocumentDAO.class);
			// // verify externalCreditReportId
			// Assert.assertEquals(experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)),
			// creditReportMappingModel.getExternalCreditReportId());

			/*
			 * For row having CreditBureau=2 validate following:
			 * ExternalCreditReportId should not be null. IsDecisionBureau
			 * should be "1".
			 */
			final UserCreditReportMappingModel creditReportMappingModelTu = creditProfilesDAO
					.getUserCreditReportMapping(Long.valueOf(userId), 2);
			// verify IsDecisionBureau is false:
			Assert.assertEquals(creditReportMappingModelTu.isIsDecisionBureau(), "1");

			final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);

			/*
			 * For row having CreditBureau=1 validate following:
			 * IsDecisionBureau should be "0". ExternalCreditReportId should be
			 * = Select ExternalCreditReportId from Circleone..ExperianDocuments
			 * where UserID = <userid> and documentType='Response Credit
			 * Profile'
			 */
			// final ListingCreditReportMappingModel
			// listingCreditReportMappingModel =
			// listingsDAO.getListingCreditReportMapping(Long.valueOf(userId),
			// 1);
			// // verify ExternalCreditReportId in tbl
			// ListingCreditReportMapping
			// Assert.assertEquals(listingCreditReportMappingModel.getExternalCreditReportId(),
			// experianDocumentDAO.getExternalCreditReportId(Long.valueOf(userId)));
			// // verify IsDecisionBureau is false:
			// Assert.assertEquals(listingCreditReportMappingModel.getIsDecisionBureau(),
			// "0");

			/*
			 * For row having CreditBureau=2 validate following:
			 * ExternalCreditReportId should be = Select ExternalCreditReportId
			 * from Circleone..UserCreditReportMapping where UserID = <UserID>
			 * and CreditBureau=2 IsDecisionBureau should be "1".
			 */
			final ListingCreditReportMappingModel listingCreditReportMappingModelTu = listingsDAO
					.getListingCreditReportMapping(Long.valueOf(userId), 2);

			// verify IsDecisionBureau is false:
			Assert.assertEquals(listingCreditReportMappingModelTu.getIsDecisionBureau(), "1");

			// verify ExternalCreditReportId in tbl ListingCreditReportMapping
			Assert.assertEquals(listingCreditReportMappingModelTu.getExternalCreditReportId(),
					prospectCreditReportMappingModelTu.getExternalCreditReportId());

			// Submit the TILA page and validate following: (Model Report
			// Validation):
			final String externalModelReportIdTu = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 2);
			// verify ExternalModelReportId for TransUnion enabled
			Preconditions.checkNotNull(externalModelReportIdTu, "ExternalModelReportId should not be null");
			LOG.info("externalModelReportIdTu is:" + externalModelReportIdTu);
			// verify ExternalModelReportId for Experian enabled
			final String externalModelReportIdEx = creditProfilesDAO.getExternalModelReportId(Long.valueOf(userId), 1);
			Assert.assertEquals(externalModelReportIdEx, null);

			// Temporary created Transunion DB object
			final ModelReportDAO modelReportDAO = transUnionDBConnectionTemp.getDataAccessObject(ModelReportDAO.class);
			final String modelReportId = modelReportDAO.getModelReportId(externalModelReportIdTu);
			LOG.info("modelReportId is:" + modelReportId);
			Assert.assertTrue(modelReportDAO.doesRecordsExistsInModelReportRequest(modelReportId));
			Assert.assertTrue(modelReportDAO.doesRecordExistsInModelReportMiliLendingAlertAct(externalModelReportIdTu));
			LOG.info("~~~~~~Executing:~~~~~~BMP-5499~~~~~~");
			final String listingforPMI = listingsDAO.getListingIdForPMI(listingID);
			Assert.assertNull(listingforPMI);
			LOG.info("~~~~verifyGetOfferNewUserTest--PASSED~~~~~~~~~~~");
		}
	}
}
