package test.ui.phl;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.Constants.PersonalDetailPage;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlTruthInLendingDisclosurePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author ntaneja BR-206:Verify correct contact number on validation message
 *         while providing incorrect SSN on Personal Details page
 */
public class PhlCheckPhoneOnSSNValidation extends PartnerLandingPageTestBase {

	protected static final Logger LOG = Logger.getLogger(PhlCheckPhoneOnSSNValidation.class.getSimpleName());

	@DataProvider(name = "testData")
	public static Object[][] userRegisterData() {
		return new Object[][] {
				Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "HappyPathUser"), };
	}

	@Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
	void testPhlCheckPhoneOnSSNValidation(String Key, String loanAmount, String creditQuality, String firstName,
			String lastName, String middleInitial, String dob, String homePhone, String homeAddress, String city,
			String state, String zipCode, String relationType, String employmentStatus, String yearlyIncome,
			String emailAddress, String workPhone, String employerName, String employerPhone, String occupation,
			String employmentMonth, String employmentYear, String SSN, String password, String bankName,
			String routingNumber, String accountNumber, String confirmAccountNumber) throws AutomationException {

		LOG.info("~~~~~~Executing: testPhlCheckPhoneOnSSNValidation~~~~~~~~~~~~~~~");

		try (final PhlProviderSearchPage phlProviderSearchPage = new PhlProviderSearchPage(webDriverConfig,
				publicSiteUrlScheme, publicSiteUrl + getPhlPageUrl().get(0).get("URL"))) {
			phlProviderSearchPage.setPageElements(pageElements);

			final PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.gotoPublicsiteRegistrationPage();

			emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
					middleInitial, dob, homePhone, emailAddress, homeAddress, city, state, zipCode, employmentStatus,
					yearlyIncome);

			phlRegistrationPage.clickElectronicSignatureCheckBox();
			LOG.info("Email address of the user: " + emailAddress);

			final PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
			// Select from 2 displayed loans
			PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();
			// go to PD page
			phlPersonalDetailsPage.submitPersonalDetailPage(workPhone, employerName, employerPhone, occupation,
					employmentMonth, employmentYear, PersonalDetailPage.SSN_INCORRECT_VALUE, emailAddress, password);
			phlPersonalDetailsPage.clickToCheckValidation();
			PollingUtilities.sleep(2000);
			Assert.assertTrue(phlPersonalDetailsPage
					.isTextPresent(Constants.PersonalDetailPage.SSN__CHECK_CORRECT_PHONE_NUMBER_VALIDATION, false));

		}
	}
}
