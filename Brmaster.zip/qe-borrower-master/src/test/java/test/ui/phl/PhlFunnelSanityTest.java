package test.ui.phl;


import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PhlBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PhlPersonalDetailsPage;
import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PhlThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PhlTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * @author  bhirani
 */
public class PhlFunnelSanityTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PhlFunnelSanityTest.class.getSimpleName());

    private static final String Provider_ID = "031143";

    @Autowired
    @Qualifier("phlProviderSearchPage")
    private PhlProviderSearchPage phlProviderSearchPage;

    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {
                Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "HappyPathUser"),
        };
    }

    @Test(dataProvider = "testData", groups = {TestGroup.SANITY})
    public void verifyPHLEndToEndListing(String Key, String loanAmount, String creditQuality,
                                         String firstName, String lastName, String middleInitial, String dob, String homePhone,
                                         String homeAddress, String city, String state, String zipCode, String relationType, String employmentStatus,
                                         String yearlyIncome, String emailAddress, String workPhone, String employerName,
                                         String employerPhone, String occupation, String employmentMonth, String employmentYear, String SSN, String password,
                                         String bankName, String routingNumber, String accountNumber, String confirmAccountNumber)
            throws AutomationException {

        LOG.info("~~~~~~Executing: verifyPHLEndToEndListing~~~~~~~~~~~~~~~");

        password = MessageBundle.getMessage("password");

        phlProviderSearchPage.enterProviderId(Provider_ID);

        PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.verifyProvider();


        emailAddress =
                phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName, middleInitial, dob,
                        homePhone,
                        emailAddress, homeAddress, city, state, zipCode, employmentStatus, yearlyIncome);

        phlRegistrationPage.clickElectronicSignatureCheckBox();
        LOG.info("Email address of the user: " + emailAddress);

        PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();

        //Select from 2 displayed loans
        PhlPersonalDetailsPage phlPersonalDetailsPage = phlOfferPage.getThisLoan();

        // Submit Personal details page, p2B call will happen here
        phlPersonalDetailsPage.submitPersonalDetailPage(workPhone, employerName, employerPhone, occupation, employmentMonth,employmentYear , SSN,
                emailAddress, password);
        PhlTruthInLendingDisclosurePage phlTruthInLendingDisclosurePage = phlPersonalDetailsPage.clickContinue();

        //Initial Tila Submission
        phlTruthInLendingDisclosurePage.agreementSelection();
        PhlBankAccountInfoPage phlBankAccountInfoPage = phlTruthInLendingDisclosurePage.clickContinue();

        //Bank account page
        phlBankAccountInfoPage.submitBankInfo(bankName,routingNumber, accountNumber, confirmAccountNumber);
        PhlThankYouPage phlThankYouPage = phlBankAccountInfoPage.clickSubmitYourApplication();

        phlThankYouPage.clickGoToMyAccountPage();

        ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

        SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
        memberPage.searchListingByEmail(emailAddress);
        SupportBorrowerTabPage tabPage = memberPage.clickOnView();
        SupportBorrowerListingsTabPage listingPage = tabPage.clickOnListings();

        Assert.assertTrue(listingPage.getSource().contains("Web"));
        Assert.assertTrue(listingPage.getChannel().contains("Affiliates"));

    }

}
