
package test.ui;

import test.BorrowerTestBase;

/**
 * @author pbudiono
 */
public abstract class WebDriverTestBase extends BorrowerTestBase {
}
