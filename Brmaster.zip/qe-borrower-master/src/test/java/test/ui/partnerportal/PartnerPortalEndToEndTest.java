
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.prospect.PartnerPortalDAO;
import com.prosper.automation.enumeration.platform.EmailDomain;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.pubsite.enumeration.Suffix;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import java.net.MalformedURLException;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * verify complete listing with new campaing added via Partner portal
 *
 * @author jdoriya 28-Apr-2016
 *
 */
public class PartnerPortalEndToEndTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PartnerPortalEndToEndTest.class.getSimpleName());
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // PART-1200 Verify Borrower is able to create a listing using new partner campaign and support site sync
    @Deprecated
    @Test(groups = {TestGroup.SANITY})
    void testEndToEndForPartnerPortal() throws AutomationException, MalformedURLException {
        LOG.info("Executing: testEndToEndForPartnerPortal");
        // login into Partner portal as admin role
        String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        String PARTNER_REFAC = PARTNER_NAME;
        String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.addrefAcRefMc(PARTNER_REFAC, PARTNER_REFMC, true);
        // verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());

        // click on verify button and return carrefinacne plp url

        StringBuilder refinanceUrl = new StringBuilder(partnerPage.visitPageRefAcNRefMc(PARTNER_REFAC,
                PARTNER_REFMC));

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(refinanceUrl.toString()),
                URLUtilities.getStringURLWithoutScheme(refinanceUrl.toString()))) {
            partnerLandingPage.setPageElements(pageElements);

            // enter loanamount <$2000
            partnerLandingPage.enterLoanAmount(4000);
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.ClickOnCheckYouRate();
            // enter the Firstname of prime borrower
            publicSiteRegistrationPage
                    .enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            // enter the lastname of prime borrower
            publicSiteRegistrationPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));

            publicSiteRegistrationPage.selectSuffix(Suffix.JR);
            // enter the streetname
            publicSiteRegistrationPage
                    .enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            // enter the cityname
            publicSiteRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // select the state of user
            publicSiteRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // enter the zipcode of user
            publicSiteRegistrationPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = "PartnerUserEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            String ListingID = getQueryMap(publicSiteTILAPage.getListingIDFromURI()).get("listing_id");
            publicSiteTILAPage.confirmElectronicSignature();

            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            // Comment for qa34 env
            // publicSiteTILAPage.clickContinue();
            // final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
            // .clickAddBankInfoManually();
            // // User added general Bank details with routing no
            // manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            // manualBankAccountPage.enterAlternateAccountHolderName(
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            // manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            // final String accountNumber = Constant.getRandomIntegerString(10);
            // manualBankAccountPage.enterAccountNumber(accountNumber);
            // manualBankAccountPage.enterConfirmAccountNumber(accountNumber);
            //
            // final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
            // publicSiteThankYouPage.clickGoToMyAccountPage();
            // Log into the Public site with user created above
            LOG.info("Borrower ListingID is:" + ListingID);

        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(emailAddress);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        SupportBorrowerListingsTabPage borrowerListingsTabPage = supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        // TODO: un-comment once defect id BMP-381 fixed
        Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);
        LOG.info("PART-1200 Verify Borrower is able to create a listing using new partner campaign and support site sync");
    }

    // BMP-221 Verify that co-branding per RefAC/MC in Partner Portal is enable on core-home-plus landing template
    @Test(groups = {TestGroup.ACCEPTANCE}, dataProvider = HOMEPLUSPAGE)
    void testEndToEndWithHomePlusPage(String partnerUrl) throws AutomationException, MalformedURLException {
        LOG.info("Executing: testEndToEndWithHomePlusPage");
        // login into Partner portal as admin role
        String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        String PARTNER_REFAC = PARTNER_NAME;
        String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.addrefAcRefMc(PARTNER_REFAC, PARTNER_REFMC, true);
        // verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());

        // build URL for home-plus
        StringBuilder refinanceUrl = new StringBuilder(partnerUrl + "?refac=" + PARTNER_REFAC + "&refmc=" + PARTNER_REFMC);

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(refinanceUrl.toString()),
                URLUtilities.getStringURLWithoutScheme(refinanceUrl.toString()))) {
            partnerLandingPage.setPageElements(pageElements);

            // enter loanamount <$2000
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // select credit quality
            partnerLandingPage
                    .selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));
            // click on check you rate button
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.ClickOnCheckYouRate();
            // enter the Firstname of prime borrower
            publicSiteRegistrationPage
                    .enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            // enter the lastname of prime borrower
            publicSiteRegistrationPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));

            publicSiteRegistrationPage.selectSuffix(Suffix.JR);
            // enter the streetname
            publicSiteRegistrationPage
                    .enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            // enter the cityname
            publicSiteRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // select the state of user
            publicSiteRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // enter the zipcode of user
            publicSiteRegistrationPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = "PartnerUserEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            String ListingID = getQueryMap(publicSiteTILAPage.getListingIDFromURI()).get("listing_id");
            publicSiteTILAPage.confirmElectronicSignature();

            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            // Comment for qa34 env
            // publicSiteTILAPage.clickContinue();
            // final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
            // .clickAddBankInfoManually();
            // // User added general Bank details with routing no
            // manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            // manualBankAccountPage.enterAlternateAccountHolderName(
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            // manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            // final String accountNumber = Constant.getRandomIntegerString(10);
            // manualBankAccountPage.enterAccountNumber(accountNumber);
            // manualBankAccountPage.enterConfirmAccountNumber(accountNumber);
            //
            // final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
            // publicSiteThankYouPage.clickGoToMyAccountPage();
            // Log into the Public site with user created above
            LOG.info("Borrower ListingID is:" + ListingID);

        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(emailAddress);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        // TODO: un-comment once defect id BMP-381 fixed
        // Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);
        LOG.info("BMP-221 Verify that co-branding per RefAC/MC in Partner Portal is enable on core-home-plus landing template");
    }

    // BMP-221 Verify that co-branding per RefAC/MC in Partner Portal is enable on core-home-plus landing template
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testEndToEndWithRealtorPage() throws AutomationException, MalformedURLException {
        LOG.info("Executing: testEndToEndWithHomePlusPage");
        // login into Partner portal as admin role
        String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        String PARTNER_REFAC = PARTNER_NAME;
        String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.addrefAcRefMc(PARTNER_REFAC, PARTNER_REFMC, true);
        // verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());

        // build URL for home-plus
        String refinanceUrl = publicSiteUrl + "/plp/realtor/?" + PARTNER_REFAC + "&refmc=" + PARTNER_REFMC;

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, refinanceUrl)) {
            partnerLandingPage.setPageElements(pageElements);

            // enter loanamount <$2000
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // select credit quality
            partnerLandingPage.enterLoanAmount(4000);
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            // click on check you rate button
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.ClickOnCheckYouRate();
            // enter the Firstname of prime borrower
            publicSiteRegistrationPage
                    .enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            // enter the lastname of prime borrower
            publicSiteRegistrationPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));

            publicSiteRegistrationPage.selectSuffix(Suffix.JR);
            // enter the streetname
            publicSiteRegistrationPage
                    .enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            // enter the cityname
            publicSiteRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // select the state of user
            publicSiteRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // enter the zipcode of user
            publicSiteRegistrationPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = "PartnerUserEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            String ListingID = getQueryMap(publicSiteTILAPage.getListingIDFromURI()).get("listing_id");
            publicSiteTILAPage.confirmElectronicSignature();

            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            // Comment for qa34 env
            // publicSiteTILAPage.clickContinue();
            // final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
            // .clickAddBankInfoManually();
            // // User added general Bank details with routing no
            // manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            // manualBankAccountPage.enterAlternateAccountHolderName(
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            // manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            // final String accountNumber = Constant.getRandomIntegerString(10);
            // manualBankAccountPage.enterAccountNumber(accountNumber);
            // manualBankAccountPage.enterConfirmAccountNumber(accountNumber);
            //
            // final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
            // publicSiteThankYouPage.clickGoToMyAccountPage();
            // Log into the Public site with user created above
            LOG.info("Borrower ListingID is:" + ListingID);

        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(emailAddress);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        // TODO: un-comment once defect id BMP-381 fixed
        // Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);
        LOG.info("BMP-221 Verify that co-branding per RefAC/MC in Partner Portal is enable on core-home-plus landing template");
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    void testEndToEndWithPorchPage() throws AutomationException, MalformedURLException {
        LOG.info("Executing: testEndToEndWithHomePlusPage");
        // login into Partner portal as admin role
        String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        String PARTNER_REFAC = PARTNER_NAME;
        String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.addrefAcRefMc(PARTNER_REFAC, PARTNER_REFMC, true);
        // verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());

        // build URL for home-plus
        String refinanceUrl = publicSiteUrl + getAllDMPagesURI().get(1).get("URL") + PARTNER_REFAC + "&refmc=" + PARTNER_REFMC;

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, refinanceUrl)) {
            partnerLandingPage.setPageElements(pageElements);

            // enter loanamount <$2000
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // select credit quality
            partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));

            // click on check you rate button
            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    partnerLandingPage.ClickOnCheckYouRate();
            // enter the Firstname of prime borrower
            publicSiteRegistrationPage
                    .enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
            // enter the lastname of prime borrower
            publicSiteRegistrationPage
                    .enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));

            publicSiteRegistrationPage.selectSuffix(Suffix.JR);
            // enter the streetname
            publicSiteRegistrationPage
                    .enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
            // enter the cityname
            publicSiteRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
            // select the state of user
            publicSiteRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
            // enter the zipcode of user
            publicSiteRegistrationPage
                    .enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));

            // User enter the employment status as Employed
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));

            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = "PartnerUserEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            String ListingID = getQueryMap(publicSiteTILAPage.getListingIDFromURI()).get("listing_id");
            publicSiteTILAPage.confirmElectronicSignature();

            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            // Comment for qa34 env
            // publicSiteTILAPage.clickContinue();
            // final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
            // .clickAddBankInfoManually();
            // // User added general Bank details with routing no
            // manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            // manualBankAccountPage.enterAlternateAccountHolderName(
            // getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            // manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            // final String accountNumber = Constant.getRandomIntegerString(10);
            // manualBankAccountPage.enterAccountNumber(accountNumber);
            // manualBankAccountPage.enterConfirmAccountNumber(accountNumber);
            //
            // final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
            // publicSiteThankYouPage.clickGoToMyAccountPage();
            // Log into the Public site with user created above
            LOG.info("Borrower ListingID is:" + ListingID);

        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(emailAddress);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        // TODO: un-comment once defect id BMP-381 fixed
        // Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);
        LOG.info("BMP-221 Verify that co-branding per RefAC/MC in Partner Portal is enable on core-home-plus landing template");
    }
}
