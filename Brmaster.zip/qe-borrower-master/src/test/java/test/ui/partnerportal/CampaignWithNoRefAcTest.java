
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 19-Aug-2016
 *
 */
public class CampaignWithNoRefAcTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(CampaignWithNoRefAcTest.class.getSimpleName());
    private static final String PARTNER_NAME = "autoPartner" + RandomStringUtils.random(8, true, true);
    private static final String PARTNER_EMAIL = TestDataProviderUtil.getUniqueEmailIdForTest("p");
    private static final String WT_CAMPAIGN = "Warm Transfer";
    private static final String PARTNER_REFAC = PARTNER_NAME;
    private static final String PARTNER_REFMC = PARTNER_NAME;
    private String listingId;
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // BMP-2600 Verify pages with bad RefAC and good RefMC
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testCampaingWithNoRefAc() throws AutomationException, InterruptedException {
        LOG.info("Executing: testCampaingWithNoRefAc");
        // login into Partner portal as admin role

        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));

        // select DTS campaign
        partnerPage.selectCampaign(WT_CAMPAIGN);
        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);
        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());

        Assert.assertTrue(partnerPage.isLinkActive(partnerPage.visitPageRefAcNRefMc(PARTNER_REFAC,
                PARTNER_REFMC)));
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testCampaingWithNoRefAc");
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + Constants.PartnerPortalApp.PAGE_URL_REFAC + ""
                        + Constants.PartnerPortalApp.PAGE_URL_REFMC + PARTNER_REFMC)) {
            partnerLandingPage.setPageElements(pageElements);

            partnerLandingPage.enterLoanAmount(4000);
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));
            PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnCheckYouRate();
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            // Verify new Personal detail Header text

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            tilaPage.confirmElectronicSignature();
            listingId = tilaPage.getListingIdFromTILAContent();

            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(email);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        SupportBorrowerListingsTabPage borrowerListingsTabPage = supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        borrowerListingsTabPage.clickOnPartnerName("Prosper");
        Assert.assertTrue(borrowerListingsTabPage.isStaticTextDisplayed("baddata"));
        LOG.info("BMP-2600 Verify pages with bad RefAC and good RefMC");
    }
}
