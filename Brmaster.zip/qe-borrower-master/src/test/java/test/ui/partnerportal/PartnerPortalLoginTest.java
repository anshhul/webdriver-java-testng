
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.prospect.PartnerPortalDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import java.util.ArrayList;
import java.util.Arrays;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.WebDriverTestBase;

/**
 * @author rchintapalli
 */
public class PartnerPortalLoginTest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(PartnerPortalLoginTest.class.getSimpleName());
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static final String PARTNER_EMAIL = TestDataProviderUtil.getGloballyUniqueEmailDomain("autoPartner", "p");
    private static final String PARTNER_REFAC = PARTNER_NAME;
    private static final String PARTNER_REFMC = PARTNER_NAME;
    private static final String DTS_CAMPAIGN="Direct To Site";
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;
    private static ArrayList<String> expectedCampaignNames = new ArrayList<String>(
            Arrays.asList("Affiliates", "Direct Mail", "Direct To Site", "External Mail", "Mass Media",
                    "Qualified Partners", "SEM", "SEO", "Warm Transfer"));

    // PART-1199 Verify Admin is able to create a new Partner on Partner Portal
    @Test(groups = {TestGroup.SANITY})
    public void testLoginCreateUserAndAddRefAc() throws AutomationException, InterruptedException {
        LOG.info("Executing: testLoginCreateUserAndAddRefAc");
        // login into Partner portal as admin role
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));

        Assert.assertTrue(partnerPage.getAddCampaignOptions().containsAll(expectedCampaignNames));
        LOG.info("BMP-2351 Verify Add Campaign pop-up and drop-down values displayed on clicking New Campaign link.");
        // select DTS campaign
        partnerPage.selectCampaign(DTS_CAMPAIGN);

        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);

        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        // verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);
        LOG.info("New Partner details are:" + partnerData.toString());
        LOG.info("PART-1199 Verify Admin is able to create a new Partner on Partner Portal");
    }
}
