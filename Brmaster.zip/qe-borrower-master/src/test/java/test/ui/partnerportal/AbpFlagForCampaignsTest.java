
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import java.util.ArrayList;
import java.util.Arrays;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.WebDriverTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 10-Aug-2016
 *
 */
public class AbpFlagForCampaignsTest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(AbpFlagForCampaignsTest.class.getSimpleName());
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static final String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
    private static String PARTNER_REFAC = PARTNER_NAME;
    private static String PARTNER_REFMC = PARTNER_NAME;
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // BMP-2355 Verify that AppByPhone flag button(Campaign Configuration) is displayed only as per the channel requirement.
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testAbpOptionsForCampaigns() throws AutomationException, InterruptedException {
        LOG.info("Executing: testAbpOptionsForCampaigns");
        // login into Partner portal as admin role
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();
        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));
        ArrayList<String> campaignWithAbpFlag = new ArrayList<String>(
                Arrays.asList("Direct To Site", "SEO", "SEM", "Mass Media", "Affiliates", "Qualified Partners", "Warm Transfer"));
        for (String campaign : campaignWithAbpFlag) {

            PARTNER_REFAC = Constant.getGloballyUniqueString();
            PARTNER_REFMC = PARTNER_REFAC;
            partnerPage.selectCampaign(campaign);
            partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);
            partnerPage.clickOnCreateCampaign();
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
            PollingUtilities.sleep(2000);
            Assert.assertTrue(partnerPage.isAbpToggelDisplayed(PARTNER_REFAC, PARTNER_REFMC));
            partnerPage.clickOnNewCampaign();
            PollingUtilities.sleep(2000);
        }
        LOG.info(
                "BMP-2355 Verify that AppByPhone flag button(Campaign Configuration) is displayed only as per the channel requirement.");
    }
}
