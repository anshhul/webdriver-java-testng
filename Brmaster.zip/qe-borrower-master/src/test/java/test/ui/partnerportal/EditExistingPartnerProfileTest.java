
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.prospect.PartnerPortalDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author jdoriya 06-May-2016
 *
 */
public class EditExistingPartnerProfileTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(EditExistingPartnerProfileTest.class.getSimpleName());
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;
    private final String newUpdateProfile = "UpdateOn" + RandomStringUtils.random(5, true, true);
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static final String EXISTING_PARTNER_NAME_START_WITH = "aut";
    private static final String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");


    // PART-1202 Verify Admin User is able to edit Existing Partner Profile on Partner Dashboard page
    // PART-1036 Verify Admin User is able to Search newly created Partner on Partner list page via Partner Name
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testEditExistingPartnerProfile() throws AutomationException {
        LOG.info("Executing: testEditExistingPartnerProfile");
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        final PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();

        // assert 100 partner lists on one page
        Assert.assertEquals(partnerPortalMainPage.getPartnerLists().size(), 100);

        // select a partner from partner lists
        partnerPortalMainPage.searchPartnerViaName(EXISTING_PARTNER_NAME_START_WITH);

        Assert.assertTrue(
                partnerPortalMainPage.getPartnerLists().get(0).getText().contains(EXISTING_PARTNER_NAME_START_WITH));
        final PartnerPage partnerPage = partnerPortalMainPage.selectPartnerFromLists(EXISTING_PARTNER_NAME_START_WITH);
        LOG.info("PART-1036 Verify Admin User is able to Search newly created Partner on Partner list page via Partner Name");
        // click on edit partner profile
        partnerPage.clickOnEditProfile();

        // update Partner Profile
        partnerPage.editPartnerProfile(newUpdateProfile, Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New",
                Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER, PARTNER_EMAIL);
        PollingUtilities.sleep(8000);// page updating the details(reloading)
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(newUpdateProfile));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New"));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(PARTNER_EMAIL));

        // verify Updated partner profile in prospecttbl
        PollingUtilities.sleep(2000);
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        final PartnerData partnerData = partnerPortalDAO.getPartnerData(newUpdateProfile);
        Assert.assertEquals(partnerData.getPartnerName(), newUpdateProfile);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New");
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);

        LOG.info("Updated Partner details are:" + partnerData.toString());
        LOG.info("PART-1202 Verify Admin User is able to edit Existing Partner Profile on Partner Dashboard page");
    }
}
