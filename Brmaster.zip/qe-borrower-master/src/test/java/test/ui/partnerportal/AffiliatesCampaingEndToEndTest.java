
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.enumeration.platform.EmailDomain;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.URLUtilities;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 10-Aug-2016
 *
 */
public class AffiliatesCampaingEndToEndTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AffiliatesCampaingEndToEndTest.class.getSimpleName());

    private String listingId;
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // BMP-2357 Verify Campaign Channel Affiliates end-to-end
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testAffiliatesCampaign() throws AutomationException, InterruptedException {
        LOG.info("Executing: testAffiliatesCampaign");
        // login into Partner portal as admin role
        final String PARTNER_NAME = Constant.getGloballyUniqueString();
        final String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        final String AFFILIATES_CAMPAIGN = "Affiliates";
        final String PARTNER_REFAC = PARTNER_NAME;
        final String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));

        // select DTS campaign
        partnerPage.selectCampaign(AFFILIATES_CAMPAIGN);
        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);
        partnerPage.clickOnCreateCampaign();
        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());

        Assert.assertTrue(partnerPage.isLinkActive(partnerPage.visitPageRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC)));
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAffiliatesCampaign");
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + Constants.PartnerPortalApp.PAGE_URL_REFAC + PARTNER_REFAC
                        + Constants.PartnerPortalApp.PAGE_URL_REFMC + PARTNER_REFMC)) {
            partnerLandingPage.setPageElements(pageElements);

            partnerLandingPage.enterLoanAmount(4000);
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
            partnerLandingPage.selectCreditQuality(getPrimeBorrowerData().get(Constants.HomeWidgetPage.CREDITQUALTIY_TAG));
            PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.ClickOnCheckYouRate();
            publicSiteRegistrationPage.fillRegistrationForm(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                    Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                    Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
            // Verify new Personal detail Header text

            personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                    getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

            PublicSiteTruthInLendingDisclosurePage tilaPage = personalDetailsPage.clickContinue();

            tilaPage.confirmElectronicSignature();
            listingId = tilaPage.getListingIdFromTILAContent();

            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .submitManualBankOption();
            // User added general Bank details with routing no
            PublicSiteThankYouPage borrowerThankYouPage =
                    manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                            "Savings",
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                            getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            borrowerThankYouPage.clickGoToMyAccountPage();
        }
        // Log into the Public site with user created above
        final ApplicationContext supportSiteXMLContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
        SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

        // verify refac and refmc at support for user
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        supportSiteMembersPage.searchByEmail(email);
        SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
        SupportBorrowerListingsTabPage borrowerListingsTabPage = supportBorrowerTabPage.clickOnListings();
        // verify partner name on support site associate with listingid
        Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);
        Assert.assertTrue(borrowerListingsTabPage.getChannel().contains(AFFILIATES_CAMPAIGN.replaceAll("\\s+", "")));
        borrowerListingsTabPage.clickOnPartnerName(PARTNER_NAME);
        Assert.assertTrue(borrowerListingsTabPage.isStaticTextDisplayed(AFFILIATES_CAMPAIGN));
        Assert.assertTrue(borrowerListingsTabPage.isStaticTextDisplayed(PARTNER_REFAC));
        List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                        listingId));
        Assert.assertTrue(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
        LOG.info("BMP-2357 Verify Campaign Channel Affiliates end-to-end");
    }

    // BMP-258 Verify Campaign Channel Affiliates end-to-end [ABP]
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testPartnerWithAbpAffiliates() throws AutomationException, InterruptedException {
        LOG.info("Executing: testPartnerWithAbpAffiliates");
        // login into Partner portal as admin role
        final String PARTNER_NAME = "autoPartner" + RandomStringUtils.random(5, true, true);
        final String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        final String AFFILIATES_CAMPAIGN = "Affiliates";
        final String PARTNER_REFAC = PARTNER_NAME;
        final String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);

        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));

        LOG.info("BMP-2351 Verify Add Campaign pop-up and drop-down values displayed on clicking New Campaign link.");
        // select DTS campaign
        partnerPage.selectCampaign(AFFILIATES_CAMPAIGN);

        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);
        // Select Abp Option for ABP flow
        partnerPage.clickOnAbpOption();
        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(AFFILIATES_CAMPAIGN);
        supportSiteMainPage.selectPartner("Affiliates (" + PARTNER_NAME + ")");
        String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testPartnerWithAbpAffiliates", "p2pcredit");
        supportSiteMainPage.enterEmailAddress(email);
        ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnContinue();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");
        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        // Get referal code from url
        String referralCode = abpOfferPage.getReferalCode();
        // click on choose rate button
        ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

        // csa is submitting personal detail for borrower
        abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        abpPersonalDetailPage
                .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        abpPersonalDetailPage
                .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
        String pathAUrl = abpPersonalDetailPage.getABPPathAUrl(referralCode);
        ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details

        abpBankInfoPage
                .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        abpBankInfoPage.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);

        // Use the generated ABP PathA URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig,
                        URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
            disclosurePage.confirmElectronicSignature();
            listingId = disclosurePage.getListingIdFromTILAContent();
            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            publicSiteThankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path A Borrower ListingID is:" + listingId);
            // Log into the Public site with user created above
            final ApplicationContext supportSiteXMLContext =
                    new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");
            SupportSiteLandingPage supportSiteLandingAgainPage =
                    (SupportSiteLandingPage) supportSiteXMLContext.getBean("supportSiteLandingPage");

            // verify refac and refmc at support for user
            supportSiteLandingAgainPage.enterEmailAddress();
            supportSiteLandingAgainPage.enterPassword(Constant.COMMON_PASSWORD);
            SupportSiteMainPage supportSiteMainAgainPage = supportSiteLandingAgainPage.clickLogin();
            SupportSiteMembersPage supportSiteMembersPage = supportSiteMainAgainPage.clickMembersLink();
            supportSiteMembersPage.searchByEmail(email);
            SupportBorrowerTabPage supportBorrowerTabPage = supportSiteMembersPage.clickOnView();
            SupportBorrowerListingsTabPage borrowerListingsTabPage = supportBorrowerTabPage.clickOnListings();
            // verify partner name on support site associate with listingid
            // TODO: un-comment once defect id BMP-381 fixed
            Assert.assertEquals(borrowerListingsTabPage.getPartnerNameAsElement().getText(), PARTNER_NAME);

            borrowerListingsTabPage.clickOnPartnerName(PARTNER_NAME);
            Assert.assertTrue(borrowerListingsTabPage.isStaticTextDisplayed(AFFILIATES_CAMPAIGN.replaceAll("\\s+", "")));
            Assert.assertTrue(borrowerListingsTabPage.isStaticTextDisplayed(PARTNER_REFAC));
            List<Map<String, Object>> loanOfferScoreDetails = queryCircleOne(
                    MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingId));
            Assert.assertTrue(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
            LOG.info("BMP-2582 Verify Campaign Channel Affiliates end-to-end [ABP]");
        }
    }
}
