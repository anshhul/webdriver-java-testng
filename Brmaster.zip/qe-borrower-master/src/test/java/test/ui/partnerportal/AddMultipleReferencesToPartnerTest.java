
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.WebDriverTestBase;

/**
 *
 * @author jdoriya 09-May-2016
 *
 */
public class AddMultipleReferencesToPartnerTest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(AddMultipleReferencesToPartnerTest.class.getSimpleName());
    private static final String PARTNER_LABEL = "In partnership with";
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static final String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
    private static final String PARTNER_REFMC = PARTNER_NAME;
    private static final String PARTNER_REFAC = PARTNER_NAME;
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // PART-1045 Verify Admin User is able to add multiple valid reference params(refac&refmc) on Partner Dashboard page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testMultipleRefAcAndRefMcToPartner() throws AutomationException {
        LOG.info("Executing: testMultipleRefAcAndRefMcToPartner");
        // login into Partner portal as admin role
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add multiple & save the refac/ refmc
        partnerPage.addrefAcRefMc(PARTNER_REFAC, PARTNER_REFMC, true);
        PollingUtilities.sleep(3000);
        String secondRefAcAndRefMc = Constant.getGloballyUniqueString();
        partnerPage.addrefAcRefMc(secondRefAcAndRefMc, secondRefAcAndRefMc, true);
        PollingUtilities.sleep(3000);
        partnerPage.selectLabelForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC,
                PARTNER_LABEL);
        // click on save button for refc , refmc
        partnerPage.clickOnSaveForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC);

        LOG.info(
                "PART-1045 Verify Admin User is able to add multiple valid reference params(refac&refmc) on Partner Dashboard page");
    }
}
