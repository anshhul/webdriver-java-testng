
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import java.util.ArrayList;
import java.util.Arrays;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.WebDriverTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 10-Aug-2016
 *
 */
public class RefAcAndRefMcForCampaignsTest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(RefAcAndRefMcForCampaignsTest.class.getSimpleName());

    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testOnlyRefAcAndRefMcFieldsForCampaigns() throws AutomationException, InterruptedException {
        LOG.info("Executing: testOnlyRefAcAndRefMcFieldsForCampaigns");
        String PARTNER_NAME = Constant.getGloballyUniqueString();
        String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
        // login into Partner portal as admin role
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));
        ArrayList<String> campaignWithOnlyRefAcRefMc = new ArrayList<String>(
                Arrays.asList("Affiliates", "Direct To Site", "Mass Media",
                        "Qualified Partners", "SEM", "SEO", "Warm Transfer"));
        Assert.assertTrue(partnerPage.getAddCampaignOptions().containsAll(campaignWithOnlyRefAcRefMc));

        for (String addCampaign : campaignWithOnlyRefAcRefMc) {
            partnerPage.selectCampaign(addCampaign);
            Assert.assertTrue(partnerPage.isRefAcFieldDisplayed());
            Assert.assertTrue(partnerPage.isRefAcFieldDisplayed());
            // Negative Assert for campagin name,sod, eod fields

            Assert.assertFalse(partnerPage.isCampaignNameDisplayed());
            Assert.assertFalse(partnerPage.isCampaignStartDateDisplayed());
            Assert.assertFalse(partnerPage.isCampaignEndDateDisplayed());
            LOG.info("BMP-2352 Verify that only Refac and Refmc text fields are displayed for mentioned campaign channels");
        }
    }

    // BMP-2353 Verify that StartDate, EndDate, Refac and Refmc text fields are displayed for mentioned campaign channels
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testRefAc_RefMc_SOD_EOD_ForCampaigns() throws AutomationException, InterruptedException {
        LOG.info("Executing: testRefAc_RefMc_SOD_EOD_ForCampaigns");
        String PARTNER_NAME = Constant.getGloballyUniqueString();
        String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
        // login into Partner portal as admin role
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();
        PollingUtilities.sleep(3000);
        // wait for partner list page to appears
        Assert.assertNotNull(partnerPortalMainPage, "PartnerPortalMainPage is Null");
        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));
        ArrayList<String> campaignWithRefAcRefMcStartOfDateEndOfDate = new ArrayList<String>(
                Arrays.asList("Direct Mail", "External Mail"));
        Assert.assertTrue(partnerPage.getAddCampaignOptions().containsAll(campaignWithRefAcRefMcStartOfDateEndOfDate));

        for (String addCampaign : campaignWithRefAcRefMcStartOfDateEndOfDate) {
            partnerPage.selectCampaign(addCampaign);
            Assert.assertTrue(partnerPage.isRefAcFieldDisplayed());
            Assert.assertTrue(partnerPage.isRefAcFieldDisplayed());
            // Negative Assert for campagin name,sod, eod fields

            Assert.assertTrue(partnerPage.isCampaignNameDisplayed());
            Assert.assertTrue(partnerPage.isCampaignStartDateDisplayed());
            Assert.assertTrue(partnerPage.isCampaignEndDateDisplayed());
            PollingUtilities.sleep(300);
            LOG.info(
                    "BMP-2353 Verify that StartDate, EndDate, Refac and Refmc text fields are displayed for mentioned campaign channels");
        }
    }
}
