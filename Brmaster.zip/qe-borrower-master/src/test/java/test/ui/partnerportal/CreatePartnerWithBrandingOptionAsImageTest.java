
package test.ui.partnerportal;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.prospect.PartnerPortalDAO;
import com.prosper.automation.enumeration.platform.EmailDomain;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author jdoriya 06-May-2016
 *
 */
public class CreatePartnerWithBrandingOptionAsImageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(CreatePartnerWithBrandingOptionAsImageTest.class.getSimpleName());
    private static final String DTS_CAMPAIGN = "Direct To Site";
    private static final String PARTNER_LABEL = "In partnership with";
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    @Test(groups = {TestGroup.ACCEPTANCE})
    void testCreatePartnerWithBrandImage() throws AutomationException {
        LOG.info("Executing: testCreatePartnerWithBrandImage");
        final String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        final String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        final String PARTNER_REFAC = PARTNER_NAME;
        final String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        final PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();

        // assert 100 partner lists on one page
        Assert.assertEquals(partnerPortalMainPage.getPartnerLists().size(), 100);

        // click on add a new partner link and create a new partner profile
        final PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();
        // select DTS campaign
        partnerPage.selectCampaign(DTS_CAMPAIGN);
        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);

        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        // NEW PARTNER: verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        final PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());
        // select an image as partner brand image
        partnerPage.selectPartnerBrandImage(PARTNER_REFAC, PARTNER_REFMC,
                PARTNER_BRAND_IMAGE_TEST);

        partnerPage.selectLabelForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC,
                PARTNER_LABEL);
        LOG.info("PART-1028 Verify Admin User is able to add cobranding for Partner Custom with label Content");
        partnerPage.clickOnSaveForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC);
        PollingUtilities.sleep(10000);
        Assert.assertTrue(partnerPage.getPartnerBrandImageAsElement(), "Partner's Selected Image is not uploaded");
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    void testCreatePartnerWithVisaPromotion() throws AutomationException {
        LOG.info("Executing: testCreatePartnerWithVisaPromotion");
        final String PARTNER_NAME = RandomStringUtils.random(8, true, false);
        final String PARTNER_EMAIL =
                "PartnerEmail" + RandomStringUtils.random(5, true, true) + EmailDomain.C1DEV.getName();
        final String PARTNER_REFAC = PARTNER_NAME;
        final String PARTNER_REFMC = PARTNER_NAME;
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        final PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();

        // assert 100 partner lists on one page
        Assert.assertEquals(partnerPortalMainPage.getPartnerLists().size(), 100);

        // click on add a new partner link and create a new partner profile
        final PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();
        // select DTS campaign
        partnerPage.selectCampaign(DTS_CAMPAIGN);
        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);

        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        // NEW PARTNER: verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        final PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());
        // enable Visa Promotion
        partnerPage.enableVisaPromotion(PARTNER_REFAC, PARTNER_REFMC);

        partnerPage.selectLabelForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC,
                PARTNER_LABEL);
        LOG.info("PART-1028 Verify Admin User is able to add cobranding for Partner Custom with label Content");
        partnerPage.clickOnSaveForRefAcNRefMc(PARTNER_REFAC, PARTNER_REFMC);
        PollingUtilities.sleep(10000);
        Assert.assertTrue(partnerPage.isLinkActive(partnerPage.visitPageRefAcNRefMc(PARTNER_REFAC,
                PARTNER_REFMC)));
        TestDataProviderUtil.getUniqueEmailIdForTest("testPartnerWithMassMedia");
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + Constants.PartnerPortalApp.PAGE_URL_REFAC + PARTNER_REFAC
                        + Constants.PartnerPortalApp.PAGE_URL_REFMC + PARTNER_REFMC)) {
            partnerLandingPage.setPageElements(pageElements);
            Assert.assertTrue(partnerLandingPage.isStaticTextDisplayed("To be eligible for the Visa Prepaid Card"));
            Assert.assertTrue(partnerLandingPage.isStaticTextDisplayed(PARTNER_LABEL));
        }
    }
}
