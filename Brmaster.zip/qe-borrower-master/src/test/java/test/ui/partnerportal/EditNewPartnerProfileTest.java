
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.prospect.PartnerPortalDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerData;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author jdoriya 06-May-2016
 *
 */
public class EditNewPartnerProfileTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(EditNewPartnerProfileTest.class.getSimpleName());
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;
    private String newUpdateProfile = "UpdateOn" + RandomStringUtils.random(5, true, true);
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
    private static final String PARTNER_REFMC = PARTNER_NAME;
    private static final String PARTNER_REFAC = PARTNER_NAME;
    private static final String DTS_CAMPAIGN = "Direct To Site";

    // PART-1201 Verify Admin User is able to edit Newly created Partner Profile on Partner Dashboard page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testEditNewPartnerProfile() throws AutomationException {
        LOG.info("Executing: testEditPartnerProfile");
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();

        // assert 100 partner lists on one page
        Assert.assertEquals(partnerPortalMainPage.getPartnerLists().size(), 100);

        // click on add a new partner link and create a new partner profile
        PartnerPage partnerPage = partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        PollingUtilities.sleep(3000);
        // add & save the refac/ refmc
        partnerPage.clickOnNewCampaign();
        partnerPage.selectCampaign(DTS_CAMPAIGN);

        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, PARTNER_REFMC);

        partnerPage.clickOnCreateCampaign();

        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        // NEW PARTNER: verify prospect records for refac/refmc
        final PartnerPortalDAO partnerPortalDAO = prospectDBConnection.getDataAccessObject(PartnerPortalDAO.class);
        PartnerData partnerData = partnerPortalDAO.getPartnerData(PARTNER_NAME);
        // verify parnter name. contact name.email in business tbl
        Assert.assertEquals(partnerData.getPartnerName(), PARTNER_NAME);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME);
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER);
        Assert.assertEquals(partnerData.getRefAc(), PARTNER_REFAC);
        Assert.assertEquals(partnerData.getRefMc(), PARTNER_REFMC);

        LOG.info("New Partner details are:" + partnerData.toString());

        // Update Partner Profile and verify prospect records
        partnerPage.clickOnEditProfile();
        PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
        // update Partner Profile
        partnerPage.editPartnerProfile(newUpdateProfile, Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New",
                Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER_NEW, PARTNER_EMAIL);
        PollingUtilities.sleep(8000);// page updating the details(reloading)
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(newUpdateProfile));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New"));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER_NEW));
        Assert.assertTrue(partnerPage.getPartnerProfileInfo().contains(PARTNER_EMAIL));

        // verify Updated partner profile in prospecttbl
        PollingUtilities.sleep(2000);
        partnerData = partnerPortalDAO.getPartnerData(newUpdateProfile);
        Assert.assertEquals(partnerData.getPartnerName(), newUpdateProfile);
        Assert.assertEquals(partnerData.getContactName(), Constants.PartnerPortalApp.PARTNER_CONTACT_NAME + "New");
        Assert.assertEquals(partnerData.getPartnerEmail(), PARTNER_EMAIL);
        Assert.assertEquals(partnerData.getContactNumber(), Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER_NEW);

        LOG.info("Updated Partner details are:" + partnerData.toString());
        LOG.info("PART-1201 Verify Admin User is able to edit Newly created Partner Profile on Partner Dashboard page");
    }
}
