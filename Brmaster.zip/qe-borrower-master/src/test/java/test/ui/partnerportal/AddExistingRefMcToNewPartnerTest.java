
package test.ui.partnerportal;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.partnerportal.pages.PartnerPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalLandingPage;
import com.prosper.automation.partnerportal.pages.PartnerPortalMainPage;
import com.prosper.automation.util.PollingUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author jdoriya 06-May-2016
 *
 */
public class AddExistingRefMcToNewPartnerTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AddExistingRefMcToNewPartnerTest.class.getSimpleName());
    private String refMcOfPartner;
    private static final String PARTNER_NAME = Constant.getGloballyUniqueString();
    private static final String PARTNER_EMAIL = Constant.getGloballyUniqueEmailDomain("p");
    private static final String PARTNER_REFAC = PARTNER_NAME;
    private static final String DTS_CAMPAIGN = "Direct To Site";
    private static final String EXISTING_PARTNER_NAME = "a847cd07d7e645d3ab4a242afdb2767b";
    @Autowired
    protected PartnerPortalLandingPage partnerPortalLandingPage;


    // PART-1203 Verfiy Admin is not able to added existing reference(RefAC) parameter to new Partner
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testAddExistingRefAcToNewPartner() throws AutomationException {
        LOG.info("Executing : testAddExistingRefAcToNewPartner");
        partnerPortalLandingPage.enterEmailAddress();
        partnerPortalLandingPage.enterPassword(Constants.UserCommonTestDetails.LOGINPASSWORD);
        PartnerPortalMainPage partnerPortalMainPage = partnerPortalLandingPage.clickLogin();

        // assert 100 partner lists on one page
        Assert.assertEquals(partnerPortalMainPage.getPartnerLists().size(), 100);

        // select a partner from partner lists
        partnerPortalMainPage.searchPartnerViaName(EXISTING_PARTNER_NAME);
        PollingUtilities.sleep(3000);
        Assert.assertTrue(
                partnerPortalMainPage.getPartnerLists().get(0).getText().contains(EXISTING_PARTNER_NAME));
        PartnerPage partnerPage = partnerPortalMainPage.selectPartnerFromLists(EXISTING_PARTNER_NAME);
        // validate if any pre-existing references are added to partner or not
        refMcOfPartner = partnerPage.refMcOfExistingPartner();
        // navigate to Partner list page

        partnerPortalMainPage = partnerPage.clickOnPartners();
        partnerPortalMainPage.addPartner(PARTNER_NAME,
                Constants.PartnerPortalApp.PARTNER_CONTACT_NAME, Constants.PartnerPortalApp.PARTNER_CONTACT_NUMBER,
                PARTNER_EMAIL);
        // assert for waiting partner dashboard page to appears
        Assert.assertNotNull(partnerPage);

        partnerPage.clickOnNewCampaign();

        Assert.assertTrue(partnerPage.isAddCampaignPopUpDisplayed(Constants.PartnerPortalApp.ADD_CAMPAIGN));

        partnerPage.selectCampaign(DTS_CAMPAIGN);

        // enter refac and refmc
        partnerPage.enterRefAcAndRefMc(PARTNER_REFAC, refMcOfPartner);
        partnerPage.clickOnCreateCampaign();
        Assert.assertTrue(partnerPage.isCampaignConfigurationDisplayed());
        LOG.info("PART-1203 Verfiy Admin is not able to added existing reference(RefAC) parameter to new Partner");
        LOG.info("BMP-2349 Verify that partner portal agent can not create duplicate refac");
    }

}
