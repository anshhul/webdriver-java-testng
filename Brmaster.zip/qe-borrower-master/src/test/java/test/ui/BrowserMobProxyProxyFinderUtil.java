
package test.ui;

import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.util.web.borrower.common.ModifyXMLUtil;
import com.prosper.automation.webdriver.client.BrowserMobProxyClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by rsubramanyam on 7/25/16.
 */
public class BrowserMobProxyProxyFinderUtil {

    @Autowired
    BrowserMobProxyClient browserMobProxyClient;

    @Test
    public void findProxy() throws AutomationException, HttpRequestException, IOException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("spring/browser_mob_proxy.xml");
        final BrowserMobProxyClient browserMobProxyClient =
                (BrowserMobProxyClient) jobContext.getBean("browserMobProxyClient");
        String portNumber = browserMobProxyClient.postProxyPort().getPort();
        writeBrowserMobProxyJS(portNumber);
    }

    private void writeBrowserMobProxyJS(String portNumber) throws IOException {
        String path = String.format("%s/%s", ModifyXMLUtil.COMMON_TEST_DATA_ENVIRONMENT, "browsermob-template.js");
        Path pathToFile = Paths.get(path);
        String pathToWrite = String.format("%s/%s", ModifyXMLUtil.COMMON_TEST_DATA_ENVIRONMENT, "browsermob.js");
        Path filePathToWrite = Paths.get(pathToWrite);
        Charset charset = StandardCharsets.UTF_8;
        String content = new String(Files.readAllBytes(pathToFile), charset);
        content = content.replaceAll("<portNumber>", portNumber);
        Files.write(filePathToWrite, content.getBytes(charset));
    }
}
