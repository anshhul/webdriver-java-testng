
package test;

import com.google.common.collect.Lists;
import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.LendingAccreditation;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.pubsite.pages.OutlookInboxWebAppInboxPage;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.test.TestBase;

import org.apache.log4j.Logger;
import org.testng.Assert;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author pbudiono
 */
public abstract class BorrowerTestBase extends TestBase {

    private static final Logger LOG = Logger.getLogger(BorrowerTestBase.class.getSimpleName());

    private static final Long SUB_PROGRAM_ID = 2L;
    private static final boolean YEARLY_INCOME_VERIFIABLE = true;
    private static final Long SELF_REPORTED_CREDIT_SCORE = 1L;

    private static final String LOAN_AMOUNT = "3000.50";
    private static final Long LOAN_PURPOSE_ID = 1L;
    private static final Long OCCUPATIONAL_ID = 7L;

    private static final Long EMPLOYMENT_STATUS_ID = 3L;
    private static final String ANNUAL_INCOME = "120000";
    private static final int EMPLOYMENT_YEAR = 2000;
    private static final int EMPLOYMENT_MONTH = 1;
    private static final String EMPLOYER_NAME = "Prosper Marketplace";

    @Resource
    protected CloseableJdbcConnection prospectDBConnection;

    @Resource
    protected CloseableJdbcConnection circleOneDBConnection;

    @Resource
    protected CloseableJdbcConnection transUnionDBConnection;

    @Resource
    protected CloseableJdbcConnection transUnionDBConnectionTemp;


    protected DXReferralRequest buildDXReferralRequest(final String email, final Map<String, String> userEntities) {
        return new DXReferralRequest.Builder()
                .withSubProgramId(SUB_PROGRAM_ID)
                // experian data for different credit ratings
                .withFirstName(userEntities.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(userEntities.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(userEntities.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withStreet(userEntities.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(userEntities.get(ExperianUserInformation.CITY_KEY))
                .withState(userEntities.get(ExperianUserInformation.STATE_KEY))
                .withZipCode(userEntities.get(ExperianUserInformation.ZIP_KEY))
                .withSsn(userEntities.get(ExperianUserInformation.SSN_KEY))
                // contact information
                .withEmailAddress(email)
                // loan information
                .withLoanAmount(LOAN_AMOUNT).withLoanPurposeId(LOAN_PURPOSE_ID)
                // employment information
                .withOccupationalId(OCCUPATIONAL_ID)
                .withYearlyIncome(ANNUAL_INCOME)
                .withYearlyIncomeVerifiable(YEARLY_INCOME_VERIFIABLE)
                .withEmploymentStatusId(EMPLOYMENT_STATUS_ID)
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)
                .withEmployerName(EMPLOYER_NAME)
                // reported credit score
                .withSelfReportedCreditScore(SELF_REPORTED_CREDIT_SCORE)
                .withHomePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withHomePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                .withMobilePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_2)
                .withWorkPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_3)
                .withEmployerPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withEmployerPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_4)
                // bank account information
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(userEntities.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();
    }

    protected UserRequest buildGenericUserRequest(final String userEmail, final Map<String, String> experianUserInformation) {
        String state = null;
        if (experianUserInformation.get(ExperianUserInformation.STATE_OF_RESIDENCE) != null) {
            state = experianUserInformation.get(ExperianUserInformation.STATE_OF_RESIDENCE);
        }
        final PersonalInfo personalInfo = new PersonalInfo.Builder()
                .withFirstName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(experianUserInformation.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY))
                .withUserNameTypeId(Constant.TEST_USER_NAME_TYPE_ID)
                .withSourceTypeId(Constant.TEST_SOURCE_TYPE_ID)
                .build();
        final AddressInfo addressInfo = new AddressInfo.Builder()
                .withStreet(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(experianUserInformation.get(ExperianUserInformation.CITY_KEY))
                .withState(experianUserInformation.get(ExperianUserInformation.STATE_KEY))
                .withZipCode(experianUserInformation.get(ExperianUserInformation.ZIP_KEY))
                .withAddress1(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withAddressTypeId(
                        (experianUserInformation.get(ExperianUserInformation.ADDRESS_TYPE_ID_KEY) != null) ?
                                Integer.parseInt(experianUserInformation.get(ExperianUserInformation.ADDRESS_TYPE_ID_KEY))
                                : AddressInfoConstant.ADDRESS_TYPE_ID)
                .withStateOfResidence(state)
                .build();

        final ContactInfo contactInfo = new ContactInfo.Builder()
                .withEmail(userEmail)
                .build();
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME)
                .build();
        final LendingAccreditation lendingAccreditation = new LendingAccreditation.Builder()
                .withCreditProfileAuth(Constant.TEST_CREDIT_PROFILE_AUTH)
                .withPrivacyPoliciesAgreement(Constant.TEST_PRIVACY_POLICIES_AGREEMENT)
                .build();
        final List<BankAccountInfo> bankAccountInfoList = Lists.newArrayList(TestDataProviderUtil.getValidBankInfo());
        final User user = new User.Builder()
                .withPassword(Constant.COMMON_PASSWORD)
                .withBankAccountInfo(bankAccountInfoList)
                .withIntendedRole(Constant.TEST_INTENDED_ROLE)
                .withCreditGrade(Constant.TEST_CREDIT_GRADE)
                .withMonthlyDebt(Constant.TEST_MONTHLY_DEBT)
                .withAddressInfo(addressInfo)
                .withPersonalInfo(personalInfo)
                .withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo)
                .withLendingAccreditation(lendingAccreditation)
                .build();
        return new UserRequest.Builder()
                .withUser(user)
                .build();
    }

    protected UserRequest buildGenericUserRequest(final String userEmail, final String userPassword) {
        return buildGenericUserRequest(userEmail, userPassword, Constant.TEST_ANNUAL_INCOME);
    }

    protected UserRequest buildGenericUserRequest(final String userEmail, final String userPassword, Double income) {
        final AddressInfo addressInfo = new AddressInfo.Builder()
                .withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                .withCity(AddressInfoConstant.TEST_CITY)
                .withState(AddressInfoConstant.TEST_STATE_GA)
                .withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID)
                .build();
        final ContactInfo contactInfo = new ContactInfo.Builder()
                .withEmail(userEmail)
                .build();
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(income)
                .build();
        final LendingAccreditation lendingAccreditation = new LendingAccreditation.Builder()
                .withCreditProfileAuth(Constant.TEST_CREDIT_PROFILE_AUTH)
                .withPrivacyPoliciesAgreement(Constant.TEST_PRIVACY_POLICIES_AGREEMENT)
                .build();
        final PersonalInfo personalInfo = new PersonalInfo.Builder()
                .withFirstName(Constant.TEST_FIRST_NAME)
                .withLastName(Constant.TEST_LAST_NAME)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH)
                .withUserNameTypeId(Constant.TEST_USER_NAME_TYPE_ID)
                .withSourceTypeId(Constant.TEST_SOURCE_TYPE_ID)
                .build();
        final List<BankAccountInfo> bankAccountInfoList = Lists.newArrayList(TestDataProviderUtil.getValidBankInfo());
        final User user = new User.Builder()
                .withPassword(userPassword)
                .withBankAccountInfo(bankAccountInfoList)
                .withIntendedRole(Constant.TEST_INTENDED_ROLE)
                .withCreditGrade(Constant.TEST_CREDIT_GRADE)
                .withMonthlyDebt(Constant.TEST_MONTHLY_DEBT)
                .withAddressInfo(addressInfo)
                .withPersonalInfo(personalInfo)
                .withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo)
                .withLendingAccreditation(lendingAccreditation)
                .build();
        return new UserRequest.Builder()
                .withUser(user)
                .build();
    }


    protected UserRequest buildGenericUserRequest(final String userEmail) {
        return buildGenericUserRequest(userEmail, Constant.COMMON_PASSWORD);
    }

    protected UserRequest buildGenericUserRequest(final String userEmail, Double income) {
        return buildGenericUserRequest(userEmail, Constant.COMMON_PASSWORD, income);
    }





    /**
     * Select Prospect records
     *
     * @param query
     * @return
     * @throws AutomationException
     */
    public List<Map<String, Object>> queryProspectDb(String query) throws AutomationException {
        return prospectDBConnection.executeSelectQuery(query);
    }

    public List<Map<String, Object>> queryCircleOne(String circleOneQuery) {
        return circleOneDBConnection.executeSelectQuery(circleOneQuery);
    }

    /**
     * Reset Consumed OfferCode
     *
     * @param offerCode
     */
    public void resetOfferCode(String offerCode) {
        final ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.updateProspectByOfferCode(offerCode);
        logger.info("Offer code updated: "+ offerCode);
    }

    /**
     * Common webmail verfication for abp, dx, borrower funnel
     *
     * @param loginPage
     * @param account
     * @param emailAddress
     * @param firstName
     * @param mailSubject
     * @param expectedContent
     * @throws AutomationException
     */
    public String verifyWebMail(OutlookWebAppLoginPage loginPage, String account, String emailAddress, String firstName,
                                String mailSubject, String expectedContent) throws AutomationException {
        String webUrl = null;
        final OutlookInboxWebAppInboxPage inboxPage = new OutlookInboxWebAppInboxPage();

        final ArrayList<String> fromToSubjectBody =
                inboxPage.verifyMailBackEnd(loginPage.getUrl(), loginPage.getUsername(), loginPage.getPassword(),
                        emailAddress, mailSubject);
        if (fromToSubjectBody.size() == 0) {
            return null;
        }
        if ("ABP".equalsIgnoreCase(account)) {
            logger.info("From:- " + fromToSubjectBody.get(0));
            logger.info("To:- " + fromToSubjectBody.get(1));
            logger.info("Subject:- " + fromToSubjectBody.get(2));
            logger.info("Email Body:- " + fromToSubjectBody.get(3));

            // Verify mail subject here
            Assert.assertTrue(fromToSubjectBody.get(2).contains(mailSubject));

            final String userName = (firstName.toLowerCase());
            Character.toUpperCase(userName.charAt(0));
            userName.substring(1);

            OutlookInboxWebAppInboxPage.extractText(fromToSubjectBody.get(3));

            final String urlFromMail = inboxPage.getHrefFromEmailBody(fromToSubjectBody.get(3));
            System.out.println("Navigating to URL: " + urlFromMail);
            webUrl = urlFromMail;
        } else if ("QA".equalsIgnoreCase(account)) {

            // Verify Mail Subject
            Assert.assertTrue(fromToSubjectBody.get(2).contains(mailSubject));

            // Verify Mail Body
            Assert.assertTrue(OutlookInboxWebAppInboxPage.extractText(fromToSubjectBody.get(3)).contains(firstName));
            Assert.assertTrue(OutlookInboxWebAppInboxPage.extractText(fromToSubjectBody.get(3)).contains(expectedContent));
            webUrl = null;
        }
        return webUrl;
    }


    public String getForgotPasswordLink(OutlookWebAppLoginPage loginPage, String emailAddress, String mailSubject) {
        final OutlookInboxWebAppInboxPage inboxPage = new OutlookInboxWebAppInboxPage();

        final ArrayList<String> fromToSubjectBody =
                inboxPage.verifyMailBackEnd(loginPage.getUrl(), loginPage.getUsername(), loginPage.getPassword(),
                        emailAddress, mailSubject);
        return fromToSubjectBody.get(2);
    }

}
