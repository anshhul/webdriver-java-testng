
package test.api.wcf;

import test.api.WebServiceTestBase;

/**
 * @author pbudiono
 */
public abstract class WCFServiceTestBase extends WebServiceTestBase {
}
