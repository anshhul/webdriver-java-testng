
package test.api.wcf.dxreferral;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.constant.web.XMLReader;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.model.wcf.dxReferral.DXReferralResponse;
import test.api.wcf.WCFServiceTestBase;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Hashtable;
import java.util.Map;

/**
 * @author pbudiono
 */
public final class WCFDXReferralBaselineTest extends WCFServiceTestBase {
    private static final String EXCEPTION_NON_BORROWER_STATE = MessageBundle.getMessage("vtStateIneligibilityReason");
    @Test(dataProvider = EXPERIAN_USER_DATA_PROVIDER)
    @ProsperZephyr(project = "QE", testTitle = "Test a single push button for production deployment.", priority = "P1", labels = {
            "demo_labels"}, stepToTests = {
                    "first_step",
                    "second_step",
                    "third_step"
            }, expectedResult = "HTTP 200 OK")
    public void testWCFDXReferralWithProsperCreditGrade(final ProsperCreditGrade prosperCreditGrade)
            throws AutomationException, HttpRequestException {

        final String email = Constant.getGloballyUniqueEmail();
        final DXReferralRequest dxReferralRequest =
                buildDXReferralRequest(email, ExperianUserInformation.getByProsperCreditGrade(prosperCreditGrade));
        final DXReferralResponse dxReferralResponse = creditKarmaWCFService.getOffers(dxReferralRequest);

        Assert.assertNotNull(dxReferralResponse);
    }

    @Test(groups = TestGroup.ACCEPTANCE)
    public void testWCFDXReferralWithNonBorrowerState()
            throws AutomationException, HttpRequestException {
        // GEAR-1135
        final String email = Constant.getGloballyUniqueEmail();
        final DXReferralRequest dxReferralRequest =
                buildDXReferralRequestWithNonBorrowerState(email, ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA));
        final DXReferralResponse dxReferralResponse = creditKarmaWCFService.getOffers(dxReferralRequest);
        Assert.assertNotNull(dxReferralResponse);
        dxReferralResponse.getIneligibilityReason().contains(EXCEPTION_NON_BORROWER_STATE);
    }

    private DXReferralRequest buildDXReferralRequestWithNonBorrowerState(String email, Map<String, String> userEntities) {
            return new DXReferralRequest.Builder()
                    .withSubProgramId(SUB_PROGRAM_ID)
                    // experian data for different credit ratings
                    .withFirstName(userEntities.get(ExperianUserInformation.FIRST_NAME_KEY))
                    .withLastName(userEntities.get(ExperianUserInformation.LAST_NAME_KEY))
                    .withDateOfBirth(userEntities.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                    .withStreet(Constant.WV_ADDRESS_1)
                    .withCity(Constant.WV_CITY)
                    .withState(Constant.WV_STATE)
                    .withZipCode(Constant.WV_ZIP_CODE)
                    .withSsn(userEntities.get(ExperianUserInformation.SSN_KEY))
                    // contact information
                    .withEmailAddress(email)
                    // loan information
                    .withLoanAmount(LOAN_AMOUNT).withLoanPurposeId(LOAN_PURPOSE_ID)
                    // employment information
                    .withOccupationalId(OCCUPATIONAL_ID)
                    .withYearlyIncome(ANNUAL_INCOME)
                    .withYearlyIncomeVerifiable(YEARLY_INCOME_VERIFIABLE)
                    .withEmploymentStatusId(EMPLOYMENT_STATUS_ID)
                    .withEmploymentMonth(EMPLOYMENT_MONTH)
                    .withEmploymentYear(EMPLOYMENT_YEAR)
                    .withEmployerName(EMPLOYER_NAME)
                    // reported credit score
                    .withSelfReportedCreditScore(SELF_REPORTED_CREDIT_SCORE)
                    .withHomePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                    .withHomePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                    .withMobilePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                    .withMobilePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_2)
                    .withWorkPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                    .withWorkPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_3)
                    .withEmployerPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                    .withEmployerPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_4)
                    // bank account information
                    .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                    .withFirstAccountHolderName(userEntities.get(ExperianUserInformation.FIRST_NAME_KEY))
                    .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                    .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                    .build();
    }
}
