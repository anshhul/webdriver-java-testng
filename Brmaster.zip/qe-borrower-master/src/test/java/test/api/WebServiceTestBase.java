
package test.api;

import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.CsvReporter;
import com.prosper.automation.core.httpClient.AbstractHttpClient;
import test.BorrowerTestBase;

import com.prosper.automation.wcf.client.DXReferralImpl;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.AfterSuite;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * @author pbudiono
 */
public abstract class WebServiceTestBase extends BorrowerTestBase {

    protected static final Logger LOG = Logger.getLogger(WebServiceTestBase.class.getSimpleName());
    protected static final Long SUB_PROGRAM_ID = 24L;
    protected static final boolean YEARLY_INCOME_VERIFIABLE = true;
    protected static final Long SELF_REPORTED_CREDIT_SCORE = 1L;
    protected static final String LOAN_AMOUNT = "3000.50";
    protected static final Long LOAN_PURPOSE_ID = 1L;
    protected static final Long OCCUPATIONAL_ID = 7L;
    protected static final Long EMPLOYMENT_STATUS_ID = 3L;
    protected static final String ANNUAL_INCOME = "120000";
    protected static final int EMPLOYMENT_YEAR = 2000;
    protected static final int EMPLOYMENT_MONTH = 1;
    protected static final String EMPLOYER_NAME = "Prosper Marketplace";

    private static final String METRICS_DIRECTORY = String.format("%s/metrics", System.getProperty("user.dir"));

    private static final ConsoleReporter CONSOLE_REPORTER = ConsoleReporter.forRegistry(AbstractHttpClient.METRIC_REGISTRY)
            .convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build();
    private static final CsvReporter CSV_REPORTER = CsvReporter.forRegistry(AbstractHttpClient.METRIC_REGISTRY)
            .formatFor(Locale.US).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS)
            .build(new File(METRICS_DIRECTORY));

    @Autowired
    protected DXReferralImpl creditKarmaWCFService;


    /**
     * An after suite helper function to process request metrics.
     */
    @AfterSuite
    public final void processWebServiceMetrics() {
        LOG.info(String.format("Outputting metrics to %s", METRICS_DIRECTORY));

        new File(METRICS_DIRECTORY).mkdirs();

        CSV_REPORTER.report();
        CONSOLE_REPORTER.report();
    }
}
