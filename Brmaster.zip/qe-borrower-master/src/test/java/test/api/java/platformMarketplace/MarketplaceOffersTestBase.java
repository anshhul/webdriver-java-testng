
package test.api.java.platformMarketplace;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.core.enumeration.HttpMediaType;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.core.mapper.MapperService;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreatePartnerRequestLogDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreateProspectFromGetOffersDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceGetExternalClientIdDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceOffersDAO;
import com.prosper.automation.db.mapper.PartnerRequestLogDetails;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.GetOffersValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.response.IndividualErrorResponse;
import com.prosper.automation.model.platform.marketplace.response.ValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.util.PartnerRequestComparators.MarketplacePartnerRequestLogComparator;
import com.prosper.automation.model.platform.marketplace.util.ProspectComparators.MarketplaceProspectComparator;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerRequestGetResponse;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.platform.clients.PlatformMarketplaceImpl;
import com.prosper.automation.platform.clients.PlatformProspectImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import test.api.WebServiceTestBase;

/**
 * Created by rsubramanyam on 2/23/16.
 */
public class MarketplaceOffersTestBase extends WebServiceTestBase {

    static final long WAIT_TIME = 20000;
    private static final String ERROR_PREFIX = "MKTPL-";
    private static final String EMPTY_STRING = "";

    @Qualifier("platformMarketplaceServiceConfig")
    @Autowired
    protected HttpClientConfig platformMarketplaceServiceConfig;
    @Qualifier("marketplaceService")
    @Autowired
    protected IPlatformMarketplace marketplaceService;
    @Qualifier("internalProspectService")
    @Autowired
    protected PlatformProspectImpl internalProspectService;


    public static void assertErrorInResponse(String responseString, ResponseErrorsHelper malformedIdDataError)
            throws AutomationException {
        GetOffersValidationErrorResponse response =
                MapperService.deserialize(HttpMediaType.JSON, responseString, GetOffersValidationErrorResponse.class, false);

        String message = String.format("Did not find expected error message %s:%s", malformedIdDataError.getCode(),
                malformedIdDataError.getMessage());
        Assert.assertEquals(response.getCode(), malformedIdDataError.getCode(), message);
        Assert.assertEquals(response.getMessage(), malformedIdDataError.getMessage(), message);
    }

    // Assertions will be verified by default
    public static void assertErrorInResponse(GetOffersResponse response, ResponseErrorsHelper malformedIdDataError)
            throws AutomationException {
        assertErrorInResponse(response, malformedIdDataError, true);
    }

    // Assertions will be verified based on passed parameter
    public static void assertErrorInResponse(GetOffersResponse response, ResponseErrorsHelper malformedIdDataError,
                                             boolean dovalidateAssertions) throws AutomationException {

        ValidationErrorResponse errors = response.getErrors().get(0);
        Assert.assertEquals(errors.getErrorCode(), malformedIdDataError.getMainErrorsCode(), "Error main code is wrong!");
        Assert.assertEquals(errors.getMessage(), malformedIdDataError.getMainErrorsMessage(), "Error main message is wrong!");
        List<IndividualErrorResponse> allErrors = errors.getAllErrors();

        if (!dovalidateAssertions) {
            return; // No assertions to validate
        }

        searchForExpectedError(allErrors, malformedIdDataError);
    }

    private static void searchForExpectedError(List<IndividualErrorResponse> allErrors,
                                               ResponseErrorsHelper malformedIdDataError) {
        boolean found = false;
        int count = 0;
        for (int cn = 0; cn < allErrors.size(); cn++) {
            if (validateErrorHelper(allErrors.get(cn), malformedIdDataError)) {
                found = true;
                count++;
            }
        }
        String message = String.format("Did not find expected error message %s:%s", malformedIdDataError.getCode(),
                malformedIdDataError.getMessage());
        Assert.assertTrue(found, message);
        Assert.assertEquals(count, 1,
                "There should not be duplicate errors! Found duplicate error - " + malformedIdDataError.getMessage());
    }

    private static boolean validateErrorHelper(IndividualErrorResponse error, ResponseErrorsHelper expectedError) {
        return error.getErrorCode().equalsIgnoreCase(expectedError.getCode()) && error.getMessage()
                .matches(expectedError.getMessage());
    }

    public final static GetOfferRequest buildMarketplaceOfferRequest(final ProsperCreditGrade prosperCreditGrade,
                                                                     final String userEmail, final String legacyId)
            throws AutomationException {
        final Map<String, String> experianUserInformation = ExperianUserInformation.getByProsperCreditGrade(prosperCreditGrade);

        final LoanInfo marketplaceLoanInfo = TestDataProviderUtil.getValidLoanInfo();
        final IdentificationInfo marketplaceIdentificationInfo =
                TestDataProviderUtil.getValidIdentificationInfo(Integer.valueOf(legacyId));

        final PersonalInfo marketplacePersonalInfo = new PersonalInfo.Builder()
                .withFirstName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(experianUserInformation.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY))
                .build();
        final AddressInfo marketplaceAddressInfo = new AddressInfo.AddressForMarketplaceinfoBuilder()
                .withStreet(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(experianUserInformation.get(ExperianUserInformation.CITY_KEY))
                .withState(experianUserInformation.get(ExperianUserInformation.STATE_KEY))
                .withZip(experianUserInformation.get(ExperianUserInformation.ZIP_KEY))
                .build();

        final ContactInfo marketplaceContactInfo = new ContactInfo.ContactInfoBuilder()
                .withEmailAddress(userEmail)
                .withHomePhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                        .build())
                .withMobilePhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_2)
                        .build())
                .withWorkPhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_3)
                        .build())
                .build();

        final EmploymentInfo marketplaceEmploymentInfo = new EmploymentInfo.Builder()
                .withEmployerName(EMPLOYER_NAME)
                .withEmployerPhone(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                        .build())
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)

                // TODO: this is ugly, please convert; only allows 3, 5, 6, 7
                .withEmploymentStatusId(String.valueOf(EMPLOYMENT_STATUS_ID))
                .withOccupationId(String.valueOf(OCCUPATIONAL_ID))
                .withAnnualIncome(Double.valueOf(ANNUAL_INCOME))

                .withIsIncomeVerifiable(true)
                .build();

        final BankAccountInfo marketplaceBankAccountInfo = new BankAccountInfo.Builder()
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();

        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withLoanInfo(marketplaceLoanInfo)
                .withIdentification(marketplaceIdentificationInfo)
                .withPersonalInfo(marketplacePersonalInfo)
                .withAddressInfo(marketplaceAddressInfo)
                .withContactInfo(marketplaceContactInfo)
                .withEmploymentInfo(marketplaceEmploymentInfo)
                .withBankAccountInfo(marketplaceBankAccountInfo)
                .build();

        return getOfferRequest;
    }

    public int getPartnerCode() {
        final MarketplaceOffersDAO mktplaceOffersDAO = prospectDBConnection.getDataAccessObject(MarketplaceOffersDAO.class);
        final MarketplaceGetExternalClientIdDAO externalClientId =
                prospectDBConnection.getDataAccessObject(MarketplaceGetExternalClientIdDAO.class);
        return mktplaceOffersDAO.getLegacyId(externalClientId
                .getExternalClientId(platformMarketplaceServiceConfig.getClientId(),
                        platformMarketplaceServiceConfig.getClientSecret()));
    }

    UUID validateProspectCreation(Prospect expectedProspect, String emailId) {
        MarketplaceCreateProspectFromGetOffersDAO prospectDao =
                prospectDBConnection.getDataAccessObject(MarketplaceCreateProspectFromGetOffersDAO.class);

        // Compare prospect information with the request to validate the fields
        Prospect result = prospectDao.getProspectInfoLogByEmailId(emailId);
        MarketplaceProspectComparator comparatorForProspect = new MarketplaceProspectComparator();
        Assert.assertEquals(comparatorForProspect.compare(result, expectedProspect), 0);

        // validate application Id
        Assert.assertEquals(emailId, prospectDao.getApplicationId(emailId));
        Assert.assertNotNull(result.getProspectId());
        return result.getProspectId();
    }

    // To be used when emailId is also the applicationId
    void validateApplicationIdInPartnerRequestTable(String emailId) {
        validateApplicationIdInPartnerRequestTable(emailId, emailId);
    }

    // For custom applicationId
    void validateApplicationIdInPartnerRequestTable(String emailId, String expectedApplicationId) {
        MarketplaceCreatePartnerRequestLogDAO partnerRequestDao =
                prospectDBConnection.getDataAccessObject(MarketplaceCreatePartnerRequestLogDAO.class);
        Assert.assertEquals(partnerRequestDao.getApplicationId(emailId), expectedApplicationId);
    }

    Prospect buildExpectedProspect(IdentificationInfo info, AddressInfo ainfo, ContactInfo cinfo, EmploymentInfo einfo,
                                   PersonalInfo pinfo, LoanInfo linfo, BankAccountInfo binfo) {
        com.prosper.automation.model.platform.AddressInfo addressInfo =
                new com.prosper.automation.model.platform.AddressInfo.Builder().withCity(ainfo.getCity().toUpperCase())
                        .withAddress1(ainfo.getStreet()).withState(ainfo.getState().toUpperCase())
                        .withZipCode(ainfo.getZipCode().toUpperCase()).build();

        List<PhoneNumber> pnumbers = new ArrayList<PhoneNumber>();
        pnumbers.add(cinfo.getHomePhone());
        pnumbers.add(cinfo.getWorkPhone());
        pnumbers.add(cinfo.getMobilePhone());

        com.prosper.automation.model.platform.ContactInfo cInfo =
                new com.prosper.automation.model.platform.ContactInfo.Builder().withEmail(cinfo.getEmailAddress())
                        .withPhoneNumbers(pnumbers).build();

        Prospect prospect = new Prospect.Builder().withAddressInfo(addressInfo).withContactInfo(cInfo).withEmploymentInfo(einfo)
                .withLegacyId((long) getPartnerCode()).withLoanPurposeId(Integer.parseInt(linfo.getLoanPurpose()))
                .withBankAccountInfo(binfo).withLegacyId((long) Integer.parseInt(info.getPartnerSourceCode()))
                .withLoanAmount(Double.parseDouble(linfo.getLoanAmount())).withPersonalInfo(pinfo).build();
        return prospect;
    }

    ValidationErrorResponse buildValidationErrorResponse(ResponseErrorsHelper expectedResponseError) {
        IndividualErrorResponse singleError =
                new IndividualErrorResponse.IndividualErrorResponseBuilder().setErrorCode(expectedResponseError.getCode())
                        .setMessage(expectedResponseError.getMessage()).build();
        List<IndividualErrorResponse> allErrors = new ArrayList<IndividualErrorResponse>();
        allErrors.add(singleError);
        ValidationErrorResponse error = new ValidationErrorResponse.ValidationErrorResponseBuilder()
                .setErrorCode(expectedResponseError.getMainErrorsCode()).setMessage(expectedResponseError.getMainErrorsMessage())
                .setAllErrors(allErrors).build();
        return error;
    }

    PartnerRequestGetResponse buildExpectedPartnerRequestLog(IdentificationInfo info, AddressInfo ainfo, ContactInfo cinfo,
                                                             EmploymentInfo einfo, PersonalInfo pinfo, LoanInfo linfo,
                                                             BankAccountInfo binfo, ValidationErrorResponse errors)
            throws AutomationException {
        try {
            List<IndividualErrorResponse> errorsList = new ArrayList<IndividualErrorResponse>();
            if (errors != null)
                errorsList.addAll(errors.getAllErrors());
            PersonalInfo formattedInfo = new PersonalInfo();
            formattedInfo.setDateOfBirth(pinfo.getDateOfBirth());
            DateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
            DateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = originalFormat.parse(pinfo.getDateOfBirth());
            String formattedDate = originalFormat.format(date);
            formattedInfo.setDateOfBirth(formattedDate);
            formattedInfo.setFirstName(pinfo.getFirstName());
            formattedInfo.setLastName(pinfo.getLastName());
            formattedInfo.setMiddleInitial(pinfo.getMiddleInitial());
            formattedInfo.setSsn(pinfo.getSsn());
            formattedInfo.setSuffix(pinfo.getSuffix());
            PartnerRequestGetResponse response = new PartnerRequestGetResponse();
            response.setAddressInfo(ainfo);
            response.setBankAccountInfo(binfo);
            response.setContactInfo(cinfo);
            response.setEmploymentInfo(einfo);
            response.setIdentification(info);
            response.setPersonalInfo(formattedInfo);
            response.setLoanInfo(linfo);
            response.setErrors(errorsList);
            return response;
        } catch (Exception ex) {
            throw new AutomationException(ex.getMessage());
        }
    }

    GetOfferRequest buildOfferRequest(IdentificationInfo info, AddressInfo ainfo, ContactInfo cinfo, EmploymentInfo einfo,
                                      PersonalInfo pinfo, LoanInfo linfo, BankAccountInfo binfo) {
        final GetOfferRequest getOfferRequest =
                new GetOfferRequest.Builder().withIdentification(info).withPersonalInfo(pinfo).withAddressInfo(ainfo)
                        .withContactInfo(cinfo).withLoanInfo(linfo).withEmploymentInfo(einfo).withBankAccountInfo(binfo).build();
        return getOfferRequest;
    }

    void validateCreatePartnerRequestLog(String email, PartnerRequestGetResponse expectedResponse)
            throws AutomationException, HttpRequestException {
        validateCreatePartnerRequestLog(email, expectedResponse, null);
    }

    void validateCreatePartnerRequestLog(String email, PartnerRequestGetResponse expectedResponse,
                                         String expectedProspectId) throws AutomationException, HttpRequestException {
        // Check db for errors and application id
        PartnerRequestLogDetails info = getPartnerRequestTableID(email);
        if (expectedProspectId != null)
            Assert.assertEquals(info.getProspectId().toLowerCase(), expectedProspectId.toLowerCase());

        // Compare get partner request endpoint response with get offers request test expected response
        validatePartnerRequestEndpointResponseValues(info.getPartnerRequestId(), expectedResponse);
    }

    private void validatePartnerRequestEndpointResponseValues(int partnerRequestId, PartnerRequestGetResponse expectedResponse)
            throws AutomationException, HttpRequestException {
        PartnerRequestGetResponse response = internalProspectService.getPartnerRequestLog(String.valueOf(partnerRequestId));
        MarketplacePartnerRequestLogComparator comparator = new MarketplacePartnerRequestLogComparator();
        Assert.assertEquals(comparator.compare(response, expectedResponse), 0);
        Assert.assertNull(response.getErrors());
    }

    private PartnerRequestLogDetails getPartnerRequestTableID(String email) {
        MarketplaceCreatePartnerRequestLogDAO partnerRequestDao =
                prospectDBConnection.getDataAccessObject(MarketplaceCreatePartnerRequestLogDAO.class);
        PartnerRequestLogDetails info = partnerRequestDao.getDetails(email);
        return info;
    }

    List<IndividualErrorResponse> getAllErrorsList(ResponseErrorsHelper error) {
        List<IndividualErrorResponse> errorsList = new ArrayList<IndividualErrorResponse>();
        errorsList.add(new IndividualErrorResponse.IndividualErrorResponseBuilder().setErrorCode(error.getCode())
                .setMessage(error.getMessage()).build());
        return errorsList;
    }

    void pauseForPartnerRequestTableUpdation() throws AutomationException {
        // Pause since create partner request is asynchronous
        try {
            Thread.sleep(WAIT_TIME);
        } catch (InterruptedException e) {
            throw new AutomationException(e.getMessage());
        }
    }

    protected final GetOfferRequest buildMarketplaceOfferRequest(final ProsperCreditGrade prosperCreditGrade,
                                                                 final String userEmail)
            throws AutomationException {
        final Map<String, String> experianUserInformation = ExperianUserInformation.getByProsperCreditGrade(prosperCreditGrade);

        final LoanInfo marketplaceLoanInfo = TestDataProviderUtil.getValidLoanInfo();
        final IdentificationInfo marketplaceIdentificationInfo =
                TestDataProviderUtil.getValidIdentificationInfo(2);

        final PersonalInfo marketplacePersonalInfo = new PersonalInfo.Builder()
                .withFirstName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(experianUserInformation.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY))
                .build();
        final AddressInfo marketplaceAddressInfo = new AddressInfo.AddressForMarketplaceinfoBuilder()
                .withStreet(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(experianUserInformation.get(ExperianUserInformation.CITY_KEY))
                .withState(experianUserInformation.get(ExperianUserInformation.STATE_KEY))
                .withZip(experianUserInformation.get(ExperianUserInformation.ZIP_KEY))
                .build();

        final ContactInfo marketplaceContactInfo = new ContactInfo.ContactInfoBuilder()
                .withEmailAddress(userEmail)
                .withHomePhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                        .build())
                .withMobilePhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_2)
                        .build())
                .withWorkPhoneNumber(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_3)
                        .build())
                .build();

        final EmploymentInfo marketplaceEmploymentInfo = new EmploymentInfo.Builder()
                .withEmployerName(EMPLOYER_NAME)
                .withEmployerPhone(new PhoneNumber.Builder()
                        .withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                        .withPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                        .build())
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)

                // TODO: this is ugly, please convert; only allows 3, 5, 6, 7
                .withEmploymentStatusId(String.valueOf(EMPLOYMENT_STATUS_ID))
                .withOccupationId(String.valueOf(OCCUPATIONAL_ID))
                .withAnnualIncome(Double.valueOf(ANNUAL_INCOME))

                .withIsIncomeVerifiable(true)
                .build();

        final BankAccountInfo marketplaceBankAccountInfo = new BankAccountInfo.Builder()
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();

        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withLoanInfo(marketplaceLoanInfo)
                .withIdentification(marketplaceIdentificationInfo)
                .withPersonalInfo(marketplacePersonalInfo)
                .withAddressInfo(marketplaceAddressInfo)
                .withContactInfo(marketplaceContactInfo)
                .withEmploymentInfo(marketplaceEmploymentInfo)
                .withBankAccountInfo(marketplaceBankAccountInfo)
                .build();

        return getOfferRequest;
    }

    protected final DXReferralRequest buildDXReferralOfferRequest(final ProsperCreditGrade prosperCreditGrade,
                                                                  final String userEmail)
            throws AutomationException, JsonProcessingException {
        final Map<String, String> experianUserInformation = ExperianUserInformation.getByProsperCreditGrade(prosperCreditGrade);
        DXReferralRequest dxReferralRequest = new DXReferralRequest.Builder()
                .withSubProgramId(SUB_PROGRAM_ID)
                // experian data for different credit ratings
                .withFirstName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withLastName(experianUserInformation.get(ExperianUserInformation.LAST_NAME_KEY))
                .withDateOfBirth(experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY))
                .withStreet(experianUserInformation.get(ExperianUserInformation.ADDRESS_KEY))
                .withCity(experianUserInformation.get(ExperianUserInformation.CITY_KEY))
                .withState(experianUserInformation.get(ExperianUserInformation.STATE_KEY))
                .withZipCode(experianUserInformation.get(ExperianUserInformation.ZIP_KEY))
                .withSsn(experianUserInformation.get(ExperianUserInformation.SSN_KEY))
                // contact information
                .withEmailAddress(userEmail)
                // loan information
                .withLoanAmount(LOAN_AMOUNT).withLoanPurposeId(LOAN_PURPOSE_ID)
                // employment information
                .withOccupationalId(OCCUPATIONAL_ID)
                .withYearlyIncome(ANNUAL_INCOME)
                .withYearlyIncomeVerifiable(YEARLY_INCOME_VERIFIABLE)
                .withEmploymentStatusId(EMPLOYMENT_STATUS_ID)
                .withEmploymentMonth(EMPLOYMENT_MONTH)
                .withEmploymentYear(EMPLOYMENT_YEAR)
                .withEmployerName(EMPLOYER_NAME)
                // reported credit score
                .withSelfReportedCreditScore(SELF_REPORTED_CREDIT_SCORE)
                .withHomePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withHomePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_1)
                .withMobilePhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_2)
                .withWorkPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_3)
                .withEmployerPhoneAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withEmployerPhoneNumber(PhoneNumberConstant.DUMMY_PHONE_NUMBER_4)
                // bank account information
                .withBankName(BankAccountConstant.BANK_OF_AMERICA)
                .withFirstAccountHolderName(experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY))
                .withAccountNumber(BankAccountConstant.BANK_OF_AMERICA_ACCOUNT_NUMBER_1)
                .withRoutingNumber(BankAccountConstant.BANK_OF_AMERICA_ROUTING_NUMBER)
                .build();
        ObjectMapper ob = new ObjectMapper();
        LOG.info("DX Request inside Method :: " + ob.writeValueAsString(dxReferralRequest));
        return dxReferralRequest;
    }

    private HttpClientConfig buildPlatformServiceConfig(final String oauthClientId, final String oauthClientSecret,
                                                        HttpClientConfig platformServiceConfig) {
        return new HttpClientConfig.Builder()
                .withClientConnectionTimeout(String.valueOf(platformServiceConfig.getClientConnectionTimeout()))
                .withClientSocketTimeout(String.valueOf(platformServiceConfig.getClientSocketTimeout()))
                .withScheme(platformServiceConfig.getScheme()).withHosts(platformServiceConfig.getHosts())
                .withClientId(oauthClientId).withClientSecret(oauthClientSecret).build();
    }

    public void tryGetOffersWithPartnerAuthentication(String clientId, String clientSecret, String legacyId,
                                                      HttpClientConfig platformServiceConfig)
            throws AutomationException, HttpRequestException {

        final HttpClientConfig httpClientConfig = buildPlatformServiceConfig(clientId, clientSecret, platformServiceConfig);

        final IPlatformMarketplace marketplaceService = new PlatformMarketplaceImpl(httpClientConfig);
        final String email = Constant.getGloballyUniqueEmail();
        final GetOfferRequest getOfferRequest =
                buildMarketplaceOfferRequest(ProsperCreditGrade.A, email, legacyId);

        final GetOffersResponse getOffersResponse = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(getOffersResponse);
    }
}
