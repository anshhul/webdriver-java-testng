
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.CSVWriterUtil;
import com.prosper.automation.model.platform.marketplace.util.PartnerCsvRow;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.ProspectDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.interfaces.IPlatformProspect;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by rsubramanyam on 6/30/16.
 */
public class GetProspectOffersTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;

    @Resource
    IPlatformProspect internalProspectService;

    private String testUserEmail;
    private UUID prospectId;

    @BeforeMethod
    public void setup() throws AutomationException, HttpRequestException {
        testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse response =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
        testUserEmail = Constant.getGloballyUniqueEmail();
        prospectId = response.getProspect().getProspectId();
    }

    @Test
    public void testGetProspectOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse response =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = response.getProspect().getProspectId();
        final OffersResponse offersResponse =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID);
        Assert.assertNotNull(offersResponse);
    }

    @Test(expectedExceptions = HttpNotFoundException.class)
    public void testGetOffersWithInvalidProspectId() throws AutomationException, HttpRequestException {
        pubSiteOfferService.getProspectOffers(Constant.FAKE_UUID, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetInvalidOffersWithLowerBoundLoanAmountRequest() throws AutomationException, HttpRequestException {
        pubSiteOfferService.getProspectOffers(prospectId, Constant.LOWER_BOUND_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetInvalidOffersWithUpperBoundLoanAmountRequest() throws AutomationException, HttpRequestException {
        pubSiteOfferService.getProspectOffers(prospectId, Constant.UPPER_BOUND_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID);
    }
}
