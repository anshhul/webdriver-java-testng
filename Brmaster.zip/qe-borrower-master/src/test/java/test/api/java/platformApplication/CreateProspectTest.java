
package test.api.java.platformApplication;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PersonalInfoConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

/**
 * @author Peter Budiono, rsubramanyam
 * @since 0.0.1
 */
public final class
CreateProspectTest extends PlatformApplicationTestBase {

    private ProspectRequest prospectRequest;
    private ProspectRequest prospectRequestWithAllUserRelatedFieldsFilled;
    private String testEmail;


    @BeforeMethod
    public void beforeTest() throws AutomationException, HttpRequestException {
        testEmail = "eco_auto_" + Constant.newUuid() + "@c1.dev";
        prospectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, testEmail);
        prospectRequestWithAllUserRelatedFieldsFilled =
                buildGenericProspectRequestWithAllFields("eco_auto_" + Constant.newUuid(), "eco_auto_" + Constant.newUuid(),
                        testEmail);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectOnlyRefAcMc() throws AutomationException, HttpRequestException {
        ProspectRequest prospectRequestWithOnlyRefAcRefMc = new ProspectRequest.Builder().withRefMc("eco_auto_" + Constant.newUuid()).withRefAc("eco_auto_" + Constant.newUuid()).build();
        final ProspectResponse response = platformApplicationService.createProspect(prospectRequestWithOnlyRefAcRefMc);
        ProspectResponse responseFromProspectService = pubSiteProspectService.getProspectById(response.getProspect().getOfferCode().toString(), "OFFER_CODE");
        compareResponsesMiscFields(response, responseFromProspectService);
        Assert.assertNotNull(response);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspect() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        ProspectResponse responseFromProspectService = pubSiteProspectService.getProspectById(response.getProspect().getOfferCode().toString(), "OFFER_CODE");
        compareResponsesMiscFields(response, responseFromProspectService);
        System.out.println(response.getProspect().getProspectId());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectPersonalInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertEquals(response.getProspect().getPersonalInfo(), prospectRequestWithAllUserRelatedFieldsFilled.getProspect()
                .getPersonalInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectAddressInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertEquals(response.getProspect().getAddressInfo(), prospectRequestWithAllUserRelatedFieldsFilled.getProspect()
                .getAddressInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectEmploymentInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertEquals(response.getProspect().getEmploymentInfo(), prospectRequestWithAllUserRelatedFieldsFilled
                .getProspect().getEmploymentInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectContactInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertEquals(response.getProspect().getContactInfo(), prospectRequestWithAllUserRelatedFieldsFilled.getProspect()
                .getContactInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectTrackingInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getProspect().getTrackingInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectPartnerInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getProspect().getPartnerInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectPartnerApiInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getProspect().getPartnerApiInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectCampaignInfo() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getCampaign());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectCampaignChannel() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getChannel());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectCampaignProgram() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getProgram());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspectCampaignPricing() throws AutomationException, HttpRequestException {
        final ProspectResponse response =
                platformApplicationService.createProspect(prospectRequestWithAllUserRelatedFieldsFilled);
        Assert.assertNotNull(response.getPricing());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithLeftPaddedSpecialCharacterOnFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithRightPaddedSpecialCharacterOnFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithSpecialCharacterInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithLeftPaddedBlankSpaceOnFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithRightPaddedBlankSpaceOnFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithBlankSpaceInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testCreateInvalidProspectWithAlphanumericFirstName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getPersonalInfo().setFirstName(Constant.TEST_ALPHANUMERIC_FIRST_NAME);
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testCreateInvalidProspectWithAlphanumericLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getPersonalInfo().setLastName(Constant.TEST_ALPHANUMERIC_LAST_NAME);
        platformApplicationService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutEmail() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getContactInfo().setEmail(null);

        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateInvalidProspectWithZeroAnnualIncome() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getEmploymentInfo().setAnnualIncome(0.0);

        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateInvalidProspectWithoutAnnualIncome() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getEmploymentInfo().setAnnualIncome(null);

        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutAddressInfo() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setAddressInfo(null);

        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutCreditScore() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setCreditQualityId(null);

        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithLeftPaddedDashOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithRightPaddedDashOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithDashInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithLeftPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithRightPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithBlankSpaceInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithNullPhoneTypeId() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBER_WITHOUT_TYPE_IDS);
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithLeftPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithRightPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithSpecialCharacterInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }
}
