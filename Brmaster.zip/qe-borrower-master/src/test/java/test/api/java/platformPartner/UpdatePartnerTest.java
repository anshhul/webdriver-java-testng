
package test.api.java.platformPartner;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.partner.PartnerRequestResponse;
import com.prosper.automation.util.PollingUtilities;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class UpdatePartnerTest extends PlatformPartnerTestBase {

    @Test
    public void testUpdatePartner() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();

        String newCode = getReallyRandomString();
        String newDesc = getReallyRandomString();
        String newName = getReallyRandomString();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            request.setDescription(newDesc);
            request.setCode(newCode);
            request.setName(newName);
            request.setId(response.getId());
            String modifiedDate = response.getModifiedDate();
            PollingUtilities.sleep(1000);
            response = internalPartnerService.updatePartner(request);

            Assert.assertEquals(response.getCode(), newCode);
            Assert.assertEquals(response.getDescription(), newDesc);
            Assert.assertEquals(response.getName(), newName);
            Assert.assertNotNull(response.getCreatedDate());
            // Modified date should be updated
            Assert.assertNotEquals(response.getModifiedDate(), modifiedDate);
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testUpdatePartnerWithExistingCode() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();

        String newCode = getReallyRandomString() + RandomStringUtils.random(5, true, true);
        String newDesc = getReallyRandomString() + RandomStringUtils.random(5, true, true);
        String newName = getReallyRandomString() + RandomStringUtils.random(5, true, true);
        PartnerRequestResponse response = null;
        PartnerRequestResponse response1 = null;
        try {
            response = internalPartnerService.createPartner(request);

            // Second request
            PartnerRequestResponse request1 = new PartnerRequestResponse();
            request1.setCode(newCode);
            request1.setDescription(newDesc);
            request1.setName(newName);
            response1 = internalPartnerService.createPartner(request1);

            // Update code to be first request's code
            request.setDescription(request.getDescription());
            request.setCode(response1.getCode());
            request.setName(request.getName());
            request.setId(response.getId());

            // Duplicate code
            response = internalPartnerService.updatePartner(request);
            Assert.fail();
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
            if (response1 != null) {
                internalPartnerService.deletePartner(response1.getId());
            }
        }
    }


    @Test
    public void testUpdatePartnerWithExistingName() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();

        String newCode = getReallyRandomString();
        String newName = getReallyRandomString();
        PartnerRequestResponse response = null;
        PartnerRequestResponse response1 = null;
        try {
            response = internalPartnerService.createPartner(request);

            // Second request
            PartnerRequestResponse request1 = new PartnerRequestResponse();
            request1.setCode(newCode);
            request1.setName(newName);

            response1 = internalPartnerService.createPartner(request1);

            // Update name to be first request's name
            request.setDescription(request.getDescription());
            request.setCode(request.getCode());
            request.setName(response1.getName());
            request.setId(response.getId());

            // Duplicate name
            response = internalPartnerService.updatePartner(request);
            Assert.assertEquals(response.getName(), response1.getName());
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
            if (response1 != null) {
                internalPartnerService.deletePartner(response1.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testUpdatePartnerEmptyCode() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        String newDesc = getReallyRandomString();
        String newName = getReallyRandomString();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            request.setDescription(newDesc);
            request.setCode("");
            request.setName(newName);
            response = internalPartnerService.updatePartner(request);
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testUpdatePartnerEmptyName() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();

        String newCode = getReallyRandomString();
        String newDesc = getReallyRandomString();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            request.setDescription(newDesc);
            request.setCode(newCode);
            request.setName("");
            response = internalPartnerService.updatePartner(request);
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testUpdatePartnerNonExistingId() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response = null;
        try {
            request.setId("0");
            response = internalPartnerService.updatePartner(request);
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }
}
