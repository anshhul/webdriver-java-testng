
package test.api.java.platformMessageComposer;

import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.CsvReporter;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.DirectoryConstant;
import com.prosper.automation.core.httpClient.AbstractHttpClient;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;
import com.prosper.automation.platform.interfaces.IPlatformMessageComposer;
import com.prosper.automation.test.TestBase;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;

import javax.annotation.Resource;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Created by pbudiono on 7/29/16.
 */
public abstract class PlatformMessageComposerTestBase extends TestBase {

	protected static final String TEST_TEMPLATE_CODE_PREFIX = "auto";
	protected static final String TEST_DESCRIPTION_PREFIX = String.format("%s_%s", TEST_TEMPLATE_CODE_PREFIX,
			"template_description");
	protected static final String TEST_SUBJECT_PREFIX = String.format("%s_%s", TEST_TEMPLATE_CODE_PREFIX, "email_subject");
	protected static final String TEST_CONTENT = "<html><h1>this is an e-mail {template}</h1></html>";
	protected static final String DEFAULT_DELIVERY_TYPE_CODE = "SMTP";
	protected static final String DEFAULT_CONTENT_TYPE_CODE = "HTML";
	protected static final String BOOLEAN_FLAG_TEST = "BOOLEAN_FLAG_TEST";
	protected static final String RESPONSYS_DELIVERY_CODE = "RESPONSYS";
	protected static final String TEXT_CONTENT_CODE = "TEXT";
	protected static final String INVALID_DELIVERY_CODE = "INVALID_DELIVERY_CODE";
	protected static final String INVALID_CONTENT_CODE = "INVALID_CONTENT_CODE";
	protected static final String DEFAULT_MESSAGE_SUBJECT_TEMPLATE = "{{SUBJECT}}";
	protected static final String DEFAULT_MESSAGE_SUBJECT_TEMPLATE_KEY = "SUBJECT";
	protected static final String DEFAULT_MESSAGE_CONTENT_TEMPLATE = "{{CONTENT}}";
	protected static final String DEFAULT_MESSAGE_CONTENT_TEMPLATE_KEY = "CONTENT";

	private static final Logger LOG = Logger.getLogger(PlatformMessageComposerTestBase.class.getSimpleName());

	@Resource
	protected IPlatformMessageComposer internalMessageComposerService;

	@AfterSuite
	public final void processMetrics() {
		final ConsoleReporter consoleReporter = ConsoleReporter.forRegistry(AbstractHttpClient.METRIC_REGISTRY)
				.convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build();
		consoleReporter.report();

		final File metricsDirectory = new File(String.format("%s/%s", DirectoryConstant.USER_DIR, "report.csv"));
		LOG.info(String.format("Metrics directory: %s", String.format("%s/%s", DirectoryConstant.USER_DIR, "report.csv")));

		metricsDirectory.mkdir();

		final CsvReporter csvReporter = CsvReporter.forRegistry(AbstractHttpClient.METRIC_REGISTRY).formatFor(Locale.US)
				.convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build(metricsDirectory);
		csvReporter.report();
	}

	protected EmailMessageTemplate createGenericMessageTemplateRequest(final String templateCode) {
		return createGenericMessageTemplateRequest(templateCode, true, true, true);
	}

	protected EmailMessageTemplate createGenericMessageTemplateRequest(final String templateCode,
			final Boolean isShownOnPublicSite, final Boolean isSentExternally, final Boolean isActive) {
		return new EmailMessageTemplate.Builder().withMessageTemplateCode(templateCode)
				.withTemplateDescription(TEST_DESCRIPTION_PREFIX).withTemplateSubject(TEST_SUBJECT_PREFIX)
				.withTemplateContent(TEST_CONTENT).withIsShownOnPublicSite(isShownOnPublicSite)
				.withIsSentExternally(isSentExternally).withIsActive(isActive).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).build();
	}

	protected EmailMessageTemplate createGenericMessageTemplateRequest(final String templateCode, final String messageSubject,
			final String messageContent, final String contentType, final String deliveryType) {
		return new EmailMessageTemplate.Builder().withMessageTemplateCode(templateCode)
				.withTemplateDescription(TEST_DESCRIPTION_PREFIX).withTemplateSubject(messageSubject)
				.withTemplateContent(messageContent).withIsShownOnPublicSite(true).withIsSentExternally(true).withIsActive(true)
				.withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE).withContentTypeCode(contentType).build();
	}

	@DataProvider(name = BOOLEAN_FLAG_TEST, parallel = true)
	protected Object[][] createMessageTemplateTestData() {
		final Object[][] testData = {
				// isShownOnPublicSite, isSentExternally, isActive
				{ true, true, true }, { false, false, false } };
		return testData;
	}

	protected String createUniqueTemplateCode() {
		return String.format("%s_%s", TEST_TEMPLATE_CODE_PREFIX, Constant.getGloballyUniqueString());
	}

	protected String createUniqueTestMessageTemplateCode() {
		return String.format("BORROWER_%s", TEST_TEMPLATE_CODE_PREFIX, Constant.getGloballyUniqueString());
	}

	protected void deleteTestData(final String... messageTemplateKeys) throws AutomationException, HttpRequestException {
		for (final String messageTemplateKey : messageTemplateKeys) {
			try {
				LOG.info(String.format("Deleting test data; [message_template_key: %s].", messageTemplateKey));
				internalMessageComposerService.deleteMessageTemplate(messageTemplateKey, true);
			} catch (final HttpRequestException ex) {
				LOG.warn("Unable to delete test data.");
			}
		}
	}
}
