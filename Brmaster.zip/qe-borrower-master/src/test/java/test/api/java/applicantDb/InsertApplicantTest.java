
package test.api.java.applicantDb;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import test.api.java.applicantDb.cases.InsertApplicantTestCase;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/17/16.
 */
public class InsertApplicantTest extends AppDbTestBase
        implements InsertApplicantTestCase {

    private static String testEmail = null;


    @BeforeMethod
    public void beforeTest() throws AutomationException, HttpRequestException {
        testEmail = Constant.getGloballyUniqueEmail(false);
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantBasicTest() throws AutomationException, HttpRequestException {
        ProspectRequest request = buildPlatformProspectRequestWithFredData(testEmail);
        final ProspectResponse response = internalProspectService.createProspect(request);
        int applicantId = verifyApplicantMatchData(request, response);
        internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicantId);
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantEmptyProspectTest() throws AutomationException, HttpRequestException {
        ProspectRequest request = getEmptyProspect();
        final ProspectResponse response = internalProspectService.createProspect(request);
        int applicantId = getApplicantFromProspect(response.getProspect().getProspectId().toString());
        Assert.assertEquals(applicantId, 0);
        internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantWithoutContactPhoneNumbers() throws AutomationException, HttpRequestException {
        ProspectRequest request = buildPlatformProspectRequestWithoutPhoneNumbers(testEmail);
        final ProspectResponse response = internalProspectService.createProspect(request);
        int applicantId = verifyApplicantMatchData(request, response);
        internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicantId);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantWithNullAreaCodePhoneNumber() throws AutomationException, HttpRequestException {
        ProspectRequest request = buildPlatformProspectRequestWithNullAreaCode(testEmail);
        final ProspectResponse response = internalProspectService.createProspect(request);
        int applicantId = verifyApplicantMatchData(request, response);
        internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicantId);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testInsertApplicantWithInvalidPhoneNumber()
            throws AutomationException, HttpRequestException {
        ProspectRequest request = buildPlatformProspectRequestWithInvalidPhoneNumber(testEmail);
        internalProspectService.createProspect(request);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantPartiallyMatchingSSN() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = prospect1Ssn.substring(0, 7) + "12";
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect2Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantMatching7SSNDifferent9SSN() throws AutomationException, HttpRequestException {
        String randomNumber = generateRandomNumber(6);
        String prospect1Ssn = "34" + randomNumber;
        String prospect2Ssn = "12" + randomNumber;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect2Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicantSameEmailDifferentSSN() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect2Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicant7SsnDifferentSSN() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String prospect2Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect2Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicant7SsnDifferentZipDifferentLastName() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn);
        request2.getProspect().getPersonalInfo().setLastName("testInsertApplicantDifferentZipDifferentLastName");
        request2.getProspect().getAddressInfo().setZipCode("94198");
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicant7SsnDifferentFirstName() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        request1.getProspect().getPersonalInfo().setFirstName("testInsertApplicantDifferentZipDifferentLastName");
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInsertApplicant7SsnDifferentAddressDifferentLastName()
            throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn);
        request2.getProspect().getAddressInfo().setAddress1("27 Union Square");
        request2.getProspect().getPersonalInfo().setLastName("Test");
        doTestCreationOfApplicantsWithRequestData(request1, request2, false);
    }
}
