
package test.api.java.platformHealthCheck;

import com.prosper.automation.util.ResourceUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.api.java.PlatformServiceTestBase;

import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.healthCheck.HealthCheckConfiguration;
import com.prosper.automation.model.platform.healthCheck.PlatformPingResponse;
import com.prosper.automation.parser.YAMLParser;
import com.prosper.automation.platform.interfaces.IPlatformHealthCheck;
import com.prosper.automation.platform.interfaces.PlatformHealthCheckImpl;

/**
 * Created by pbudiono on 6/13/16.
 */
public final class PlatformHealthTest extends PlatformServiceTestBase {

	private static final Logger LOG = Logger.getLogger(PlatformHealthTest.class.getSimpleName());
	private static final String SERVICE_CLUSTER_TEST_DATA = "SERVICE_CLUSTER_TEST_DATA";
	private static final String CHECK_LOG_TEMPLATE = "Checking %s's %s %s service health status.";

	@Value("${platform.service.healthcheck.config}")
	private String inputFile;

	@DataProvider(name = SERVICE_CLUSTER_TEST_DATA, parallel = true)
	public Object[][] extractServiceInfo() throws AutomationException {

		final HealthCheckConfiguration healthCheckConfiguration = YAMLParser.deserialize(resourceUtilities.getFile(inputFile),
				HealthCheckConfiguration.class);
		return healthCheckConfiguration.toTestDataProvider();
	}

	@Test(dataProvider = SERVICE_CLUSTER_TEST_DATA)
	public void testPlatformServiceHealthCheck(final String environment, final String clusterName, final String clusterScheme,
			final String clusterHostName, final String connectTimeout, final String socketTimeout, final String serviceName)
					throws AutomationException, HttpRequestException {

		LOG.info(String.format(CHECK_LOG_TEMPLATE, environment, clusterName, serviceName));

		final int connectTimeoutInt = Integer.valueOf(connectTimeout);
		final int socketTimeoutInt = Integer.valueOf(socketTimeout);

		final IPlatformHealthCheck platformHealthCheck = new PlatformHealthCheckImpl(clusterScheme, clusterHostName,
				connectTimeoutInt, socketTimeoutInt);

		final PlatformPingResponse platformPingResponse = platformHealthCheck.ping(serviceName);

		Assert.assertNotNull(platformPingResponse, "Service does not return ping response.");
	}
}
