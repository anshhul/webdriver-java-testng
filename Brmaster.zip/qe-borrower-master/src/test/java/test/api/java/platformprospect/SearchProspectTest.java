
package test.api.java.platformprospect;

import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.prosper.automation.asserts.ProsperAssert;
import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.SortOrder;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.model.platform.prospect.SearchProspectQueryParameter;
import com.prosper.automation.model.platform.prospect.SearchProspectResponse;
import com.prosper.automation.platform.interfaces.IPlatformProspect;

/**
 * A test class for search prospect API.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class SearchProspectTest extends SearchProspectTestBase {

	private static final Logger LOG = Logger.getLogger(SearchProspectTest.class.getSimpleName());

	private static final String FIRST_NAME = Constant.TEST_FIRST_NAME;
	private static final String LAST_NAME = Constant.TEST_LAST_NAME;

	private static final String OFFER_CODE = Constant.getRandomString();
	private static final String SORTED_FIRST_LAST_NAME_OFFER_CODE = Constant.getRandomString();
	private static final String FAKE_OFFER_CODE = Constant.getRandomString();

	private static final int NUMBER_OF_PROSPECTS = 10;

	private static final String SORTED_OFFER_CODE_LAST_NAME = Constant.getRandomString();
	private static final String SORTED_OFFER_CODE_FIRST_NAME = Constant.getRandomString();

	private static String newlyCreatedProspectEmail = Constant.getGloballyUniqueEmail();
	private static String newlyCreatedProspectWithOfferEmail = Constant.getGloballyUniqueEmail();
	private static String newlyCreatedProspectWithAllTypeOfPhoneNumbersEmail = Constant.getGloballyUniqueEmail();
	private static String newlyCreatedProspectForUpdateTestEmail = Constant.getGloballyUniqueEmail();
	private static String newlyCreatedProspectFirstName = Constant.getRandomString();
	private static String newlyCreatedProspectLastName = Constant.getRandomString();
	private static String newlyCreatedProspectWithAllTypeOfPhoneNumbersFirstName = Constant.getRandomString();
	private static String newlyCreatedProspectWithAllTypeOfPhoneNumbersLastName = Constant.getRandomString();
	private static String newlyCreatedProspectWithOfferCodeFirstName = Constant.getRandomString();
	private static String newlyCreatedProspectWithOfferCodeLastName = Constant.getRandomString();
	private static String newlyCreatedProspectForUpdateTestFirstName = Constant.getRandomString();
	private static String newlyCreatedProspectForUpdateTestLastName = Constant.getRandomString();
	private static ProspectResponse newlyCreatedProspect;
	private static ProspectResponse newlyCreatedProspectWithOfferCode;
	private static ProspectResponse newlyCreatedProspectWithAllTypeOfPhoneNumbers;
	private static ProspectResponse newlyCreatedProspectForUpdateTest;

	@Autowired
	private IPlatformProspect pubSiteProspectService;

	// pagination test cases

	@BeforeTest(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void setupSearchProspectTest() throws HttpRequestException, AutomationException {
		LOG.info("Creating search prospect test data.");

		// creates new prospect
		newlyCreatedProspect = createProspectTestData(newlyCreatedProspectEmail, newlyCreatedProspectFirstName,
				newlyCreatedProspectLastName);
		Assert.assertNotNull(newlyCreatedProspect);

		LOG.info(newlyCreatedProspect.getProspect().getProspectId());

		// creates new prospect with offer code
		newlyCreatedProspectWithOfferCode = createProspectTestData(newlyCreatedProspectWithOfferEmail,
				newlyCreatedProspectWithOfferCodeFirstName, newlyCreatedProspectWithOfferCodeLastName, OFFER_CODE);
		Assert.assertNotNull(newlyCreatedProspectWithOfferCode);

		// creates new prospect with all type of phone numbers
		newlyCreatedProspectWithAllTypeOfPhoneNumbers = createProspectTestDataWithAllTypeOfPhoneNumbers(
				newlyCreatedProspectWithAllTypeOfPhoneNumbersEmail, newlyCreatedProspectWithAllTypeOfPhoneNumbersFirstName,
				newlyCreatedProspectWithAllTypeOfPhoneNumbersLastName);
		Assert.assertNotNull(newlyCreatedProspectWithAllTypeOfPhoneNumbers);

		// creates new prospect for update test
		newlyCreatedProspectForUpdateTest = createProspectTestData(newlyCreatedProspectForUpdateTestEmail,
				newlyCreatedProspectForUpdateTestFirstName, newlyCreatedProspectForUpdateTestLastName);
		Assert.assertNotNull(newlyCreatedProspectForUpdateTest);

		// creates new prospects
		createSortedFirstAndLastNameProspectTestData(NUMBER_OF_PROSPECTS, SORTED_FIRST_LAST_NAME_OFFER_CODE, SortOrder.ASC);
		createSortedOfferCodeProspectTestData(NUMBER_OF_PROSPECTS, SORTED_OFFER_CODE_FIRST_NAME, SORTED_OFFER_CODE_LAST_NAME,
				SortOrder.ASC);

		pollForSolrDeltaImport(newlyCreatedProspectFirstName, newlyCreatedProspectLastName);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectDataIntegrityOnCreate() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET,
						newlyCreatedProspectFirstName, newlyCreatedProspectLastName));

		final Prospect actualProspect = response.getProspects().get(0);

		// asserting personal information
		final PersonalInfo newlyCreatedPersonalInfo = actualProspect.getPersonalInfo();
		Assert.assertNotNull(newlyCreatedPersonalInfo);
		Assert.assertEquals(newlyCreatedPersonalInfo.getFirstName(), newlyCreatedProspectFirstName);
		Assert.assertEquals(newlyCreatedPersonalInfo.getLastName(), newlyCreatedProspectLastName);

		// asserting contact info
		final ContactInfo newlyCreatedContactInfo = actualProspect.getContactInfo();
		Assert.assertNotNull(newlyCreatedContactInfo);
		Assert.assertEquals(newlyCreatedContactInfo.getEmail(), newlyCreatedProspectEmail);

		// asserting address info
		final AddressInfo newlyCreatedAddressInfo = actualProspect.getAddressInfo();
		Assert.assertNotNull(newlyCreatedAddressInfo);
		Assert.assertEquals(newlyCreatedAddressInfo.getCity(), AddressInfoConstant.TEST_CITY.toUpperCase());
		Assert.assertEquals(newlyCreatedAddressInfo.getAddress1(), AddressInfoConstant.TEST_ADDRESS_1.toUpperCase());
		Assert.assertEquals(newlyCreatedAddressInfo.getState(), AddressInfoConstant.TEST_STATE_GA);
		Assert.assertEquals(newlyCreatedAddressInfo.getZipCode(), AddressInfoConstant.TEST_ZIP_CODE);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectDataIntegrityOnUpdate() throws AutomationException, HttpRequestException {
		newlyCreatedProspectForUpdateTestFirstName = Constant.getRandomString();
		newlyCreatedProspectForUpdateTestLastName = Constant.getRandomString();

		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getPersonalInfo().setFirstName(newlyCreatedProspectForUpdateTestFirstName);
		prospectRequest.getProspect().getPersonalInfo().setLastName(newlyCreatedProspectForUpdateTestLastName);

		final UUID prospectId = newlyCreatedProspectForUpdateTest.getProspect().getProspectId();
		LOG.info(prospectId);

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(prospectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);

		pollForSolrDeltaImport(newlyCreatedProspectForUpdateTestFirstName, newlyCreatedProspectForUpdateTestLastName);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByLastNameAscending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByOfferCodeSortedByLastName(DEFAULT_LIMIT, DEFAULT_OFFSET,
						SORTED_FIRST_LAST_NAME_OFFER_CODE, SortOrder.ASC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertReturnedProspectIsSortedByLastName(response.getProspects(), SortOrder.ASC);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByLastNameDescending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByOfferCodeSortedByLastName(DEFAULT_LIMIT, DEFAULT_OFFSET,
						SORTED_FIRST_LAST_NAME_OFFER_CODE, SortOrder.DESC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertReturnedProspectIsSortedByLastName(response.getProspects(), SortOrder.DESC);
	}

	// first name and last name query parameterId test cases.

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByFirstNameAscending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByOfferCodeSortedByFirstName(DEFAULT_LIMIT,
						DEFAULT_OFFSET, SORTED_FIRST_LAST_NAME_OFFER_CODE, SortOrder.ASC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertReturnedProspectIsSortedByFirstName(response.getProspects(), SortOrder.ASC);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByFirstNameDescending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByOfferCodeSortedByFirstName(DEFAULT_LIMIT,
						DEFAULT_OFFSET, SORTED_FIRST_LAST_NAME_OFFER_CODE, SortOrder.DESC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertReturnedProspectIsSortedByFirstName(response.getProspects(), SortOrder.DESC);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByOfferCodeAscending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByFirstLastNameSortedByOfferCode(DEFAULT_LIMIT,
						DEFAULT_OFFSET, SORTED_OFFER_CODE_FIRST_NAME, SORTED_OFFER_CODE_LAST_NAME, SortOrder.ASC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertProspectIsSortedByOfferCode(response.getProspects(), SortOrder.ASC);
	}

	// offer code query parameter test cases.

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetProspectSortedByOfferCodeDescending() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByFirstLastNameSortedByOfferCode(DEFAULT_LIMIT,
						DEFAULT_OFFSET, SORTED_OFFER_CODE_FIRST_NAME, SORTED_OFFER_CODE_LAST_NAME, SortOrder.DESC.toString()));
		Assert.assertNotNull(response);

		assertReturnedProspectIsGreaterThanZero(response.getProspects());
		assertProspectIsSortedByOfferCode(response.getProspects(), SortOrder.DESC);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectResultCountAttributeValue() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME, LAST_NAME));
		Assert.assertEquals(response.getResultCount(), DEFAULT_LIMIT);
	}

	// email query parameter test cases.

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectTotalCountAttributeValue() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET,
						newlyCreatedProspectFirstName, newlyCreatedProspectLastName));
		Assert.assertEquals(response.getTotalCount(), 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectLimitAttributeValue() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME, LAST_NAME));
		Assert.assertEquals(response.getLimit(), DEFAULT_LIMIT);
	}

	// ssn query parameter test cases.

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectOffsetAttributeValue() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME, LAST_NAME));
		Assert.assertEquals(response.getOffset(), DEFAULT_OFFSET);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectTotalPageAttributeValue() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET,
						newlyCreatedProspectFirstName, newlyCreatedProspectLastName));
		Assert.assertEquals(response.getTotalPages(), 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByLastName() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, newlyCreatedProspectLastName));
		ProsperAssert.assertNotNull(response);
		ProsperAssert.assertEquals(response.getProspects().size(), 1);
	}

	// phone number parameter test cases.`

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByFirstNameAndLastName() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME, LAST_NAME));
		Assert.assertNotNull(response);

		final List<Prospect> returnedProspects = response.getProspects();
		for (final Prospect prospect : returnedProspects) {
			final String firstName = prospect.getPersonalInfo().getFirstName();
			final String lastName = prospect.getPersonalInfo().getLastName();
			ProsperAssert.assertEquals(firstName, FIRST_NAME, false);
			ProsperAssert.assertEquals(lastName, LAST_NAME, false);
		}
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByFirstNameAndLastNameIsNotCaseSensitive() throws AutomationException, HttpRequestException {
		final SearchProspectResponse lowerCaseResponse = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME.toLowerCase(), LAST_NAME.toLowerCase()));
		final SearchProspectResponse upperCaseResponse = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, FIRST_NAME.toUpperCase(), LAST_NAME.toUpperCase()));
		Assert.assertNotNull(lowerCaseResponse);
		Assert.assertNotNull(upperCaseResponse);
		Assert.assertEquals(lowerCaseResponse.getProspects().size(), upperCaseResponse.getProspects().size());
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByOfferCode() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByOfferCode(DEFAULT_LIMIT, DEFAULT_OFFSET, OFFER_CODE));
		Assert.assertNotNull(response);
		Assert.assertEquals(response.getProspects().size(), 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByOfferCodeWhichDoesNotExist() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByOfferCode(DEFAULT_LIMIT, DEFAULT_OFFSET, FAKE_OFFER_CODE));
		Assert.assertNotNull(response);
		Assert.assertEquals(response.getProspects().size(), 0);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByEmail() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchByEmail(DEFAULT_LIMIT, DEFAULT_OFFSET, newlyCreatedProspectEmail));
		Assert.assertNotNull(response);
		Assert.assertEquals(response.getProspects().size(), 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByEmailWhichDoesNotExist() throws AutomationException, HttpRequestException {
		final String nonExistingEmail = Constant.getGloballyUniqueEmail();
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByEmail(DEFAULT_LIMIT, DEFAULT_OFFSET, nonExistingEmail));
		Assert.assertNotNull(response);
		Assert.assertEquals(response.getProspects().size(), 0);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithNoDashSeparatedSSN() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(
				SearchProspectQueryParameter.buildSearchBySsn(DEFAULT_LIMIT, DEFAULT_OFFSET, Constant.TEST_SSN_WITHOUT_DASH));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithDashedSeparatedSSN() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchBySsn(DEFAULT_LIMIT, DEFAULT_OFFSET, Constant.TEST_SSN));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithNonExistingSSN() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchBySsn(DEFAULT_LIMIT, DEFAULT_OFFSET, Constant.FAKE_SSN));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() == 0);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithDashSeparatedPhoneNumber() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET,
						PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_0_DASH_SEPARATED));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithParenthesisAreaCodePhoneNumber() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET,
						PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithParenthesisAreaCodeAndDashSeparatedPhoneNumber()
			throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET,
						PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE_AND_DASH_SEPARATED));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectWithParenthesisAreaCodeDashSeparatedPhoneNumberAndSpace()
			throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService
				.searchProspect(SearchProspectQueryParameter.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET,
						PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_0_PARENTHESIS_AREA_CODE_DASH_SEPARATED_AND_SPACE));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByUnspecifiedPhoneNumberType() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_0));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByResidentialPhoneNumberType() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_1));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByEmployerPhoneNumberType() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_2));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByMobilePhoneNumberType() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_3));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByWorkPhoneNumberType() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_4));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() >= 1);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProspectByNonExistingPhoneNumber() throws AutomationException, HttpRequestException {
		final SearchProspectResponse response = pubSiteProspectService.searchProspect(SearchProspectQueryParameter
				.buildSearchByPhoneNumber(DEFAULT_LIMIT, DEFAULT_OFFSET, PhoneNumberConstant.FAKE_PHONE_NUMBER));
		Assert.assertNotNull(response);
		Assert.assertTrue(response.getProspects().size() == 0);
	}
}
