package test.api.java.platformMerchant;

import com.prosper.automation.constant.StringConstant;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.merchant.MerchantType;
import com.prosper.automation.model.platform.merchant.SearchMerchantResponse;

/**
 * Created by pbudiono on 6/6/16.
 */
public final class SearchMerchantByIDTest extends PlatformMerchantTestBase {

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchMerchantWithValidId() throws HttpRequestException, AutomationException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PRD);

		final SearchMerchantResponse merchant = pubSiteMerchantService.searchMerchantById(thirdPartyId);
		Assert.assertEquals(merchant.getMerchantName(), merchantName, "Merchant name does not match.");
		Assert.assertEquals(merchant.getThirdPartyID(), thirdPartyId, "Institutional ID does not match.");
		Assert.assertEquals(merchant.getStateCode(), AddressInfoConstant.RICK_NICK_STATE, "Merchant state code does not match.");
		Assert.assertEquals(merchant.getCity().toLowerCase(), AddressInfoConstant.RICK_NICK_CITY.toLowerCase(),
				"Merchant city does not match.");
		Assert.assertEquals(merchant.getStreetAddress().toLowerCase(), AddressInfoConstant.RICK_NICK_ADDRESS_1.toLowerCase(),
				"Merchant street address does not match.");
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY })
	public void testSearchMerchantWithNonExistingId() throws AutomationException, HttpRequestException {
		pubSiteMerchantService.searchMerchantById(Constant.getGloballyUniqueString());
	}
}
