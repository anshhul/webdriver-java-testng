package test.api.java.platformPartner;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.model.platform.partner.PartnerRequestResponse;
import com.prosper.automation.platform.clients.PlatformPartnerImpl;
import test.api.java.PlatformServiceTestBase;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class PlatformPartnerTestBase extends PlatformServiceTestBase {
    @Autowired PlatformPartnerImpl internalPartnerService;

    protected String getReallyRandomString() {
       return "eco_auto_" + this.getClass().getSimpleName().substring(1, 5) + Constant.getGloballyUniqueString() + RandomStringUtils
                .random(5, true, true);
    }

    public PartnerRequestResponse setUp() {
        String code = getReallyRandomString();
        String description = getReallyRandomString();
        String name = getReallyRandomString();
        return setUpRequest(code, description, name);
    }

    protected PartnerRequestResponse setUpRequest(String code, String description, String name) {
        PartnerRequestResponse request = new PartnerRequestResponse();
        request.setCode(code);
        request.setDescription(description);
        request.setName(name);
        return request;
    }
}
