
package test.api.java.applicantDb;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/21/16.
 */
public class SplitApplicantTest extends AppDbTestBase
        implements test.api.java.applicantDb.cases.SplitApplicantTestCase {

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail);
        // Now update prospect2 to have different email id
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail);
        ContactInfo info =
                new ContactInfo.Builder().withEmail(TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()))
                        .withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS_AREA_CODE).build();
        request3.getProspect().setContactInfo(info);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy9Ssn() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 =
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        // Now update prospect2 to have different ssn from prospect1
        Assert.assertNotEquals(prospect2Ssn, prospect1Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect2Ssn);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy9SsnEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        // Now update prospect2 to have different ssn from prospect1
        Assert.assertNotEquals(prospect2Ssn, prospect1Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail, prospect2Ssn);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String prospect2Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        // Now update prospect2 to have different ssn from prospect1
        Assert.assertNotEquals(prospect2Ssn, prospect1Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail, prospect2Ssn);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnAddressEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        // Now update prospect2 to have different address from prospect1
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        request3.getProspect().getPersonalInfo().setLastName(Constant.RICK_NICK_LAST_NAME);
        request3.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnZipLastNameEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        // Now update prospect2 to have different zip, different last name from prospect1
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        request3.getProspect().getPersonalInfo().setLastName(Constant.RICK_NICK_LAST_NAME);
        request3.getProspect().getAddressInfo().setZipCode(Constant.NON_FRED_NON_RICK_ZIPCODE);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnFIEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        // Now update prospect2 to have different FI from prospect1
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        request3.getProspect().getPersonalInfo().setFirstName(Constant.RICK_NICK_FIRST_NAME);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnFirstInitialLastNameFrom9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect3Ssn = prospect1Ssn.substring(0, 5) + "99";
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 =
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn.substring(2, 9));
        request2.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect3Ssn);
        request3.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);

        // Now update prospect2 to have different 7 digit ssn
        Assert.assertNotEquals(prospect3Ssn, prospect1Ssn.substring(2, 9));
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy7SsnFirstInitialAddressZipFrom9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect3Ssn = prospect1Ssn.substring(0, 5) + "99";
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 =
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn.substring(2, 9));
        request2.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect3Ssn);
        request3.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        // Now update prospect2 to have different 7 digit ssn
        Assert.assertNotEquals(prospect3Ssn, prospect1Ssn.substring(2, 9));
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitBy9SsnFromAddressZipFirstInitial7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String prospect3Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 =
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        request2.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect3Ssn);
        request3.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);

        // Now update prospect2 to have different 9 digit ssn
        Assert.assertNotEquals(prospect1Ssn, prospect3Ssn.substring(2, 9));
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitByFirstInitial()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        String testEmail2 =
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        // Now update prospect2 to have different first intial
        String currentFI = Character.toString((char) request1.getProspect().getPersonalInfo().getFirstName().charAt(0));
        String newFI = Character.toString((char) (request1.getProspect().getPersonalInfo().getFirstName().charAt(0) + 1));
        request3.getProspect().getPersonalInfo().setFirstName(newFI);
        Assert.assertNotEquals(currentFI, newFI);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitByLastName()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);

        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        request2.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        request3.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);
        // Now update prospect2 to have the different last name
        request3.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitByAddress() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn.substring(2, 9));
        request2.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn.substring(2, 9));
        request3.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        // Now update prospect2 to have different address
        request3.getProspect().getAddressInfo().setAddress1(Constant.NON_FRED_NON_RICK_ADDRESS);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantSplitByZip() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithFredData(testEmail2, prospect1Ssn);

        // Now update prospect2 to have different zip
        request3.getProspect().getAddressInfo().setZipCode(Constant.NON_FRED_NON_RICK_ZIPCODE);
        request3.getProspect().getPersonalInfo().setLastName(Constant.NON_FRED_NON_RICK_LAST_NAME);
        doTestSplitApplicants(request1, request2, request3, 2);
    }

    private void doTestSplitApplicants(ProspectRequest request1, ProspectRequest request2, ProspectRequest request3,
                                       int prospectIdToUpdate) throws HttpRequestException, AutomationException {
        final ProspectResponse response1 = internalProspectService.createProspect(request1);
        final ProspectResponse response2 = internalProspectService.createProspect(request2);
        compareApplicantData(request1, request2, response1, response2, true);
        String prospectToUpdate;
        if (prospectIdToUpdate == 1) {
            prospectToUpdate = response1.getProspect().getProspectId().toString();
        } else {
            prospectToUpdate = response2.getProspect().getProspectId().toString();
        }
        final ProspectResponse response3 = updateProspectAndValidate(prospectToUpdate, request3);
        compareAndTeardownApplicantData(request1, request3, response1, response3, false);
    }
}
