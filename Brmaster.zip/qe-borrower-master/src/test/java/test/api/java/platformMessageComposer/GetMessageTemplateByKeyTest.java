package test.api.java.platformMessageComposer;

import java.util.UUID;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;

/**
 * Created by pbudiono on 8/9/16.
 */
public class GetMessageTemplateByKeyTest extends PlatformMessageComposerTestBase {

	private EmailMessageTemplate emailMessageTemplate;

	protected String createMessageTemplate() throws AutomationException, HttpRequestException {

		final String messageTemplateCode = createUniqueTemplateCode();
		emailMessageTemplate = createGenericMessageTemplateRequest(messageTemplateCode);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.createMessageTemplate(emailMessageTemplate);

		return emailMessageTemplateResponse.getMessageTemplateKey();
	}

	@Test(groups = {TestGroup.NIGHTLY})
	public void testGetMessageTemplate() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();
		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse, emailMessageTemplate);
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = {TestGroup.NIGHTLY})
	public void testGetNonExistingMessageTemplate() throws HttpRequestException, AutomationException {
		internalMessageComposerService.getMessageTemplate(UUID.randomUUID().toString());
	}

	@Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.NIGHTLY})
	public void testGetMessageTemplateWithInvalidKey() throws HttpRequestException, AutomationException {
		internalMessageComposerService.getMessageTemplate(Constant.getStringWithLength(10));
	}
}
