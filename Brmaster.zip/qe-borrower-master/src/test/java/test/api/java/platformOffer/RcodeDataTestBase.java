
package test.api.java.platformOffer;

import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.constant.DirectoryConstant;
import com.prosper.automation.constant.TestConstant;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.Attachment;
import com.prosper.automation.jira.model.Issue;
import com.prosper.automation.model.BorrowerPricingData;
import com.prosper.automation.model.platform.pricing.ScoreCardData;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.offer.StaggMap;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;
import com.prosper.automation.model.platform.pricing.*;
import com.prosper.automation.parser.BorrowerPricingCSVParser;
import com.prosper.automation.parser.RcodeCSVParser;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Map;
import java.util.IllegalFormatException;
import java.util.Objects;

/**
 * Created by ppatil on 12/6/16.
 */
public class RcodeDataTestBase extends PlatformOfferTestBase {

    protected static final String BUREAU_DATA = "bureauData";

    private static final Logger LOG = Logger.getLogger(RcodeDataTestBase.class.getSimpleName());

    private static final String FETCH_PRICING_TICKET_FROM_JIRA_LOG = "Fetching pricing ticket information %s from JIRA.";
    private static final String PRICING_TICKET_NOT_FOUND_LOG = "Pricing ticket %s can not be found in JIRA.";
    private static final String PRICING_TICKET_FETCHING_ERROR_LOG = "Unable to fetch pricing ticket %s from JIRA.";
    private static final String FETCH_PRICING_FILE_FROM_JIRA_LOG = "Fetching attached pricing file %s from JIRA.";
    private static final String PRICING_FILE_NOT_FOUND_LOG = "Unable to fetch pricing file from JIRA.";
    private static final String PRICING_FILE_DOWNLOAD_LOG = "Downloading pricing file from JIRA.";
    private static final String UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG = "Unable to download pricing file from JIRA.";

    @Value("${pricing.jira.ticket.number}")
    protected String pricingTicketNumber;
    @Value("${pricing.jira.file.name}")
    protected String pricingFileName;
    @Value("${pricing.test.file.version}")
    protected String pricingVersion;
    @Value("${pricing.test.state}")
    protected String pricingTestState;
    @Value("${pricing.test.number.of.threads}")
    protected String numberOfThreads;

//    protected String pricingTestState = "CA";
//    protected String numberOfThreads = "100";
//    protected String pricingVersion = "7.001";


    @Resource
    private IJiraClient jiraService;


    protected static BureauRequest buildBureauRequestTU(final ScoreCardData scoreCardData
    ) throws AutomationException {

        Double annualIncome = 0.00;

        annualIncome = scoreCardData.getAnnualIncome();

        EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withAnnualIncome(annualIncome)
                .build();

        final UserInfo userInfo = new UserInfo.Builder().withEmploymentInfo(employmentInfo).build();


        final TransunionUserCredit transunionUserCredit = new TransunionUserCredit.Builder().withBureauAttributes(scoreCardData.getbureauDataMap()).build();

        return new BureauRequest.Builder().withUserInfo(userInfo)
                .withTransunionUserCredit(transunionUserCredit)
                .build();

    }


    @DataProvider(name = BUREAU_DATA, parallel = true)
    public final Object[][] buildTestData() throws AutomationException {


        LOG.info(String.format(FETCH_PRICING_TICKET_FROM_JIRA_LOG, pricingTicketNumber));
        Issue pricingTicket = null;
        try {
            pricingTicket = jiraService.getIssue(pricingTicketNumber);
        } catch (HttpNotFoundException ex) {
            Assert.fail(String.format(PRICING_TICKET_NOT_FOUND_LOG, pricingTicketNumber), ex);
        } catch (HttpRequestException ex) {
            Assert.fail(String.format(PRICING_TICKET_FETCHING_ERROR_LOG, pricingTicketNumber), ex);
        }

        LOG.info(String.format(FETCH_PRICING_FILE_FROM_JIRA_LOG, pricingFileName));
        final Attachment attachment = pricingTicket.getAttachment(pricingFileName);
        if (Objects.isNull(attachment)) {
            Assert.fail(PRICING_FILE_NOT_FOUND_LOG);
        }

        LOG.info(PRICING_FILE_DOWNLOAD_LOG);
        final String tempPricingFilePath = String.format("%s/%s", DirectoryConstant.USER_DIR, pricingFileName);

        try {
            jiraService.downloadAttachment(attachment, tempPricingFilePath);
        } catch (HttpRequestException e) {
            Assert.fail(UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG);
        }

//      final String pricingFileName = "/Users/ppatil/Desktop/PricingFiles/Rcode/ScoreWeights/production_test_feature_engineering_input_and_pmi7_and_new_aa_50.csv";
        return RcodeCSVParser.parse(pricingFileName);
    }

    @Override
    @BeforeSuite
    protected void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @BeforeTest
    public final void initializePricingDataTest() throws HttpRequestException, AutomationException {
        System.setProperty(TestConstant.DATA_PROVIDER_THREAD_COUNT_STRING, "1");
    }


    protected final String buildValidationMessage(final String errorTemplate, final Object actual, final Object expected)
            throws AutomationException {
        String valueComparison;
        try {
            valueComparison = String.format("(actual/expected): %s/%s", actual.toString(), expected.toString());
        } catch (IllegalFormatException ex) {
            throw new AutomationException(ex.getMessage());
        }
        return String.format("%s %s", errorTemplate, valueComparison);
    }
}
