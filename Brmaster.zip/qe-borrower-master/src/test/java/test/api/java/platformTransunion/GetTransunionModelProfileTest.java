
package test.api.java.platformTransunion;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ModelReportDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.transunion.response.ModelReportResponseDTO;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.prosper.automation.platform.clients.PlatformTransunionImpl;

import java.util.UUID;

import org.apache.log4j.Logger;

/**
 * Created by pbudiono on 9/15/16.
 */
public final class GetTransunionModelProfileTest extends PlatformTransunionTestBase {
    private static final Logger LOG = Logger.getLogger(GetTransunionModelProfileTest.class.getSimpleName());

    @Test
    public void testGetValidModelProfileTest() throws HttpRequestException, AutomationException {
        ModelReportDAO modelReportDAO = transUnionDBConnection.getDataAccessObject(ModelReportDAO.class);
        String modelReportId = modelReportDAO.getSingleModelReportId();
        LOG.info("ModelReportId : " + modelReportId);
        PlatformTransunionImpl tuService = new PlatformTransunionImpl(platformPublicServiceConfig, Constant.API_USERTOKEN_EMAIL, Constant.COMMON_PASSWORD);
        final ModelReportResponseDTO getResponse =
                tuService.getModelReport(modelReportId);
        Assert.assertNotNull(getResponse);
    }

    @Test(expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ".*TU-01010.*")
    public void testGetModelProfileWithNonExistingID() throws HttpRequestException, AutomationException, JsonProcessingException {
        PlatformTransunionImpl tuService = new PlatformTransunionImpl(platformPublicServiceConfig, Constant.API_USERTOKEN_EMAIL, Constant.COMMON_PASSWORD);
        tuService.getModelReport(UUID.randomUUID().toString());
    }

    @Test(expectedExceptions = HttpNotFoundException.class)
    public void testGetModelProfileWithInvalidUUIDFormat() throws HttpRequestException, AutomationException {
        PlatformTransunionImpl tuService = new PlatformTransunionImpl(platformPublicServiceConfig, Constant.API_USERTOKEN_EMAIL, Constant.COMMON_PASSWORD);
        tuService.getModelReport(Constant.getRandomString());
    }
}
