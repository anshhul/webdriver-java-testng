package test.api.java.platformMessageComposer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;
import com.prosper.automation.model.platform.email.Message;
import com.prosper.automation.model.platform.email.MessageToken;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.UUID;

/**
 * Created by pbudiono on 9/26/16.
 */
public final class GetMessageTest extends PlatformMessageComposerTestBase {

	private static final String REPLACEMENT_STRING = "TEST";

	private String messageTemplateCode = Constant.getGloballyUniqueString();

	private Message message;

	@BeforeClass(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void createDefaultMessageTemplate() throws AutomationException, HttpRequestException {
		final EmailMessageTemplate emailMessageTemplateRequest = createGenericMessageTemplateRequest(messageTemplateCode,
				DEFAULT_MESSAGE_SUBJECT_TEMPLATE, DEFAULT_MESSAGE_CONTENT_TEMPLATE, DEFAULT_CONTENT_TYPE_CODE,
				DEFAULT_DELIVERY_TYPE_CODE);
		internalMessageComposerService.createMessageTemplate(emailMessageTemplateRequest);

		final MessageToken subject = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_SUBJECT_TEMPLATE_KEY)
				.withValue(REPLACEMENT_STRING).build();
		final MessageToken content = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_CONTENT_TEMPLATE_KEY)
				.withValue(REPLACEMENT_STRING).build();

		final Message messageRequest = new Message.Builder().withMessageTemplateCode(messageTemplateCode)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withMessageTokens(Arrays.asList(subject, content)).build();

		message = internalMessageComposerService.createMessage(messageRequest);
	}

	@Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void testGetMessage() throws AutomationException, HttpRequestException {
		final Message messageResponse = internalMessageComposerService.getMessage(message.getMessageKey());

		Assert.assertEquals(messageResponse.getContentTypeCode(),message.getContentTypeCode());
		Assert.assertEquals(messageResponse.getMessageKey(), message.getMessageKey());
		Assert.assertEquals(messageResponse.getMessageSubject(), REPLACEMENT_STRING);
		Assert.assertEquals(messageResponse.getMessageContent(), REPLACEMENT_STRING);

	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
			TestGroup.SANITY })
	public void testGetMessageWithMalformedMessageKey() throws AutomationException, HttpRequestException {
		internalMessageComposerService.getMessage(Constant.getGloballyUniqueString());
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
			TestGroup.SANITY })
	public void testGetMessageWithNonExistingMessageKey() throws AutomationException, HttpRequestException {
		internalMessageComposerService.getMessage(UUID.randomUUID().toString());
	}
}
