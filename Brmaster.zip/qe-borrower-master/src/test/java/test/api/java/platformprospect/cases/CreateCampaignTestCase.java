
package test.api.java.platformprospect.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/25/16.
 */
public interface CreateCampaignTestCase extends BorrowerTestCase {
    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Campaign Information API Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "Campaign and campaign program created"
    )
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testBasicFlow() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Campaign Information API Test by creating new ref_ac, ref_mc",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "Campaign and campaign program created with ref_Ac, ref_mc non-null."
    )
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testBasicFlowRefAcRefMcNotNull() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Campaign Information API Test by creating new ref_ac, ref_mc",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "Only campaign program newly created"
    )
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testGetPartnerOauthForExistingCampaignOnlyData()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Campaign Information API Test for non-DX channel.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testBasicFlowWithNonDXChannelName() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Missing campaign source while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 404 Exception"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class)
    void testMissingCampaignSource()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Missing channel name while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 404 Exception"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class)
    void testMissingChannel()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Missing is_upsert while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 200 OK Response with no upsert of campaign"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testMissingIsUpsert() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Missing pricing while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 200 OK Response with default pricing of 21 for creating campaigns."
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testMissingPricing() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Invalid pricing id (-1) while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 404 Response"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, enabled = false)
    void testInvalidPricing() throws AutomationException, HttpRequestException;

    @ProsperZephyr(
            project = BMP,
            testTitle = "Zero Pricing while creating campaign.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/campaign http request."},
            expectedResult = "HTTP 404 Response"
    )
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    void testZeroPricing() throws AutomationException, HttpRequestException;
}
