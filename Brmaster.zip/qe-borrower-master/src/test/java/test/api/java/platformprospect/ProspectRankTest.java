
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.marketplace.CampaignDAO;
import com.prosper.automation.db.dao.marketplace.CampaignProgramDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.*;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 6/20/16.
 */
public class ProspectRankTest extends PlatformProspectTestBase {

    private static ProspectResponse responseWith9Ssn;
    private static ProspectRequest requestWith9Ssn;
    private static ProspectResponse responseWith7Ssn;
    private static ProspectRequest requestWith7Ssn;
    private static final String DUMMY_EMAIL = "dummy@c1.dev";
    private static final Long USER_ID1 = 12346L;
    private static final Long USER_ID2 = 12347L;
    private static final Long USER_ID3 = 12348L;
    private static final Long USER_ID4 = 12349L;


    @BeforeClass
    public void setup() throws AutomationException, HttpRequestException {
        requestWith9Ssn = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        requestWith9Ssn.getProspect().getPersonalInfo().setSsn(Constant.SSN_WITHOUT_DASH);
        responseWith9Ssn = pubSiteProspectService.createProspect(requestWith9Ssn);
        Assert.assertNotNull(responseWith9Ssn);

        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.setUserId(String.valueOf(USER_ID3), responseWith9Ssn.getProspect().getProspectId().toString());

        requestWith7Ssn = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        requestWith7Ssn.getProspect().getPersonalInfo()
                .setSsn(Constant.SSN_WITHOUT_DASH.replaceAll(Constant.SSN_WITHOUT_DASH.substring(0, 2), "99"));
        requestWith7Ssn.getProspect().getAddressInfo()
                .setZipCode(requestWith7Ssn.getProspect().getAddressInfo().getZipCode().substring(0, 5));
        responseWith7Ssn = pubSiteProspectService.createProspect(requestWith7Ssn);
        Assert.assertNotNull(responseWith7Ssn);

        prospectDao.setUserId(String.valueOf(USER_ID1), responseWith7Ssn.getProspect().getProspectId().toString());
    }

    @AfterClass
    public void teardown() throws AutomationException, HttpRequestException {
        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.setUserId(null, responseWith7Ssn.getProspect().getProspectId().toString());
        prospectDao.setUserId(null, responseWith9Ssn.getProspect().getProspectId().toString());
        // TODO: Uncomment this when nukeprospect is exposed
        // internalProspectService.nukeProspect(responseWith7Ssn.getProspect().getProspectId().toString());
        // internalProspectService.nukeProspect(responseWith9Ssn.getProspect().getProspectId().toString());
    }

    @DataProvider(name = "testRankMatchInfo")
    public static Object[][] rankInfoTest() {
        String email = responseWith9Ssn.getProspect().getContactInfo().getEmail();
        String address = responseWith9Ssn.getProspect().getAddressInfo().getAddress1();
        String zip = responseWith9Ssn.getProspect().getAddressInfo().getZipCode();
        String firstName = responseWith9Ssn.getProspect().getPersonalInfo().getFirstName();
        String lastName = responseWith9Ssn.getProspect().getPersonalInfo().getLastName();
        String ssn = requestWith9Ssn.getProspect().getPersonalInfo().getSsn();
        return new Object[][]{
                // All match
                {USER_ID3, email, firstName, lastName, ssn, address, zip,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip, String.valueOf(USER_ID3))},
                // Only USER_ID3, email match
                {USER_ID3, email, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip,
                                String.valueOf(USER_ID3))},
                // Only USER_ID3 match
                {USER_ID3, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE, null},
                // Only USER_ID3, first name, last name, 9ssn match
                {USER_ID3, DUMMY_EMAIL, firstName, lastName, ssn, Constant.NON_FRED_NON_RICK_ADDRESS,
                        Constant.NON_FRED_NON_RICK_ZIPCODE,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip,
                                String.valueOf(USER_ID3))},
                // Only USER_ID3, first name, last name, 7ssn match
                {USER_ID3, DUMMY_EMAIL, firstName, lastName, ssn, Constant.NON_FRED_NON_RICK_ADDRESS,
                        Constant.NON_FRED_NON_RICK_ZIPCODE,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip,
                                String.valueOf(USER_ID3))},
                // Only USER_ID3, first initial, address, 9zip, 9ssn match
                {USER_ID3, DUMMY_EMAIL, firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, ssn, address, zip,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip,
                                String.valueOf(USER_ID3))},
                // Only 9ssn match
                {USER_ID3, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, ssn,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE, null},
                // Only first name match
                {USER_ID3, DUMMY_EMAIL, firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE, null},
                // Only last name match
                {USER_ID3, DUMMY_EMAIL, "Z" + firstName, lastName, Constant.FAKE_SSN, Constant.NON_FRED_NON_RICK_ADDRESS,
                        Constant.NON_FRED_NON_RICK_ZIPCODE, null},
                // Only address match
                {USER_ID3, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN, address,
                        Constant.NON_FRED_NON_RICK_ZIPCODE, null},
                // Only 9zip match
                {USER_ID3, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, zip, null}
        };
    }

    @DataProvider(name = "testRankMatchInfo7Ssn5zip")
    public static Object[][] rankInfoTestWith7ssn() {
        String email = responseWith7Ssn.getProspect().getContactInfo().getEmail();
        String address = responseWith7Ssn.getProspect().getAddressInfo().getAddress1();
        String zip = responseWith7Ssn.getProspect().getAddressInfo().getZipCode();
        String firstName = responseWith7Ssn.getProspect().getPersonalInfo().getFirstName();
        String lastName = responseWith7Ssn.getProspect().getPersonalInfo().getLastName();
        String ssn = requestWith7Ssn.getProspect().getPersonalInfo().getSsn();
        return new Object[][]{
                // Only USER_ID1, first name, last name, 7ssn match
                {USER_ID1, DUMMY_EMAIL, firstName, lastName, ssn, Constant.NON_FRED_NON_RICK_ADDRESS,
                        Constant.NON_FRED_NON_RICK_ZIPCODE,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip, String.valueOf(USER_ID1))},
                // Only USER_ID1, first initial, address, 5zip, 9ssn match
                {USER_ID1, DUMMY_EMAIL, firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, ssn, address, zip,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip, String.valueOf(USER_ID1))},
                // Only USER_ID3, first initial, address, 5zip, 9ssn match
                {USER_ID1, DUMMY_EMAIL, firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, ssn, address, zip.substring(0, 5),
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip, String.valueOf(USER_ID3))},
                // Only 5zip match
                {USER_ID1, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, zip.substring(0, 5), null},
                // Only 7ssn match
                {USER_ID1, DUMMY_EMAIL, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, ssn,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE, null}};
    }

    @Test(dataProvider = "testRankMatchInfo", groups = {TestGroup.SANITY})
    public void testProspectRankAndMatch(Long userId,
                                         String email,
                                         String firstName,
                                         String lastName,
                                         String ssn,
                                         String address,
                                         String zip,
                                         ExpectedProspectMatchFields expectedFields)
            throws AutomationException, HttpRequestException {
        doTestRankMatchInfo(userId, email, firstName, lastName, ssn, address, zip, expectedFields);
    }

    @Test(groups = {
            TestGroup.ACCEPTANCE}, dataProvider = "testRankMatchInfo7Ssn5zip")
    public void testProspectRankAndMatchWith7Ssn(
            Long userId, String email, String firstName, String lastName, String ssn,
            String address, String zip,
            ExpectedProspectMatchFields expectedFields) throws AutomationException,
            HttpRequestException {
        doTestRankMatchInfo(userId, email, firstName, lastName, ssn, address, zip, expectedFields);
    }

    private void doTestRankMatchInfo(Long userId, String email, String firstName, String lastName, String ssn, String address,
                                     String zip, ExpectedProspectMatchFields expectedFields)
            throws AutomationException, HttpRequestException {
        ProspectResponse[] responsesFromRank =
                internalProspectService.getProspectRank(userId, email, firstName, lastName, ssn, address, zip, "false", null);
        Assert.assertNotNull(responsesFromRank);
        if (expectedFields == null) {
            Assert.assertEquals(responsesFromRank.length, 0);
            return;
        }
        validateFieldsInResponse(responsesFromRank, expectedFields);
    }

    private void validate(ProspectResponse[] responsesFromRank, ProspectMatchIndividualResult[] responsesFromMatch) {
        Assert.assertEquals(responsesFromRank.length, responsesFromMatch.length);
        for (int indx = 0; indx < responsesFromRank.length; indx++) {
            Assert.assertEquals(responsesFromMatch[indx].getOfferCode(), responsesFromRank[indx].getProspect().getOfferCode());
        }
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testWithExpiredCampaign()
            throws AutomationException, HttpRequestException {
        final String clientId = Constant.newUuid();
        insertAuthorizedCampaignProgram(clientId, "DataExchange", 1);
        CampaignDAO campaignDao = prospectDBConnection.getDataAccessObject(CampaignDAO.class);
        String refac = campaignDao.getRefAc(clientId);
        String refmc =
                ((CampaignProgramDAO) prospectDBConnection.getDataAccessObject(CampaignProgramDAO.class)).getRefMc(clientId);
        ProspectRequest request = buildGenericProspectRequest(refac, refmc, Constant.getGloballyUniqueEmail());
        request.getProspect().getPersonalInfo().setSsn(Constant.SSN_WITHOUT_DASH);
        ProspectResponse response = pubSiteProspectService.createProspect(request);
        Assert.assertNotNull(response);
        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        try {
            prospectDao.setUserId(String.valueOf(USER_ID4), response.getProspect().getProspectId().toString());
            campaignDao.endCampaign(refac);
            String email = response.getProspect().getContactInfo().getEmail();
            String zip = response.getProspect().getAddressInfo().getZipCode();
            String firstName = response.getProspect().getPersonalInfo().getFirstName();
            String lastName = response.getProspect().getPersonalInfo().getLastName();
            String ssn = request.getProspect().getPersonalInfo().getSsn();
            doTestRankMatchInfo(USER_ID4, email, Constant.RICK_NICK_FIRST_NAME, "Z" + lastName, ssn,
                    Constant.NON_FRED_NON_RICK_ADDRESS, zip, null);
        } finally {
            prospectDao.setUserId(null, response.getProspect().getProspectId().toString());
            // TODO: Uncomment this when nukeprospect is exposed
            // internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
        }
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testWithExpiredEngagementDate()
            throws AutomationException, HttpRequestException {
        // Setup
        final String clientId = Constant.newUuid();
        insertAuthorizedCampaignProgram(clientId, "DataExchange", 1);
        CampaignDAO campaignDao = prospectDBConnection.getDataAccessObject(CampaignDAO.class);
        String refac = campaignDao.getRefAc(clientId);
        String refmc =
                ((CampaignProgramDAO) prospectDBConnection.getDataAccessObject(CampaignProgramDAO.class)).getRefMc(clientId);
        ProspectRequest request = buildGenericProspectRequest(refac, refmc, Constant.getGloballyUniqueEmail());
        request.getProspect().getPersonalInfo().setSsn(Constant.SSN_WITHOUT_DASH);
        ProspectResponse response = pubSiteProspectService.createProspect(request);
        Assert.assertNotNull(response);
        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        try {
            prospectDao.setUserId(String.valueOf(USER_ID2), response.getProspect().getProspectId().toString());
            prospectDao.expireEngagementDate(response.getProspect().getProspectId().toString());
            String email = response.getProspect().getContactInfo().getEmail();
            String zip = response.getProspect().getAddressInfo().getZipCode();
            String firstName = response.getProspect().getPersonalInfo().getFirstName();
            String lastName = response.getProspect().getPersonalInfo().getLastName();
            String ssn = request.getProspect().getPersonalInfo().getSsn();
            doTestRankMatchInfo(USER_ID2, email, "Z" + firstName, "Z" + lastName, ssn, Constant.NON_FRED_NON_RICK_ADDRESS, zip,
                    null);
        } finally {
            prospectDao.setUserId(null, response.getProspect().getProspectId().toString());
            // TODO: Uncomment this when nukeprospect is exposed
            // internalProspectService.nukeProspect(response.getProspect().getProspectId().toString());
        }
    }

    private void validateFieldsInResponse(ProspectResponse[] responsesFromRank, ExpectedProspectMatchFields fields) {
        for (ProspectResponse response : responsesFromRank) {
            if (matchResponse(response.getProspect(), fields))
                return;
        }
        Assert.fail("Should have matched at-least one response based on expected fields");
    }

    private void validateFieldsInMatchResponse(ProspectMatchIndividualResult[] responses, ExpectedProspectMatchFields fields)
            throws AutomationException, HttpRequestException {
        for (ProspectMatchIndividualResult response : responses) {
            if (matchResponseWithFlagsSet(response, fields))
                return;
        }
        Assert.fail("Should have matched at-least one response based on expected fields");
    }

    private boolean matchResponseWithFlagsSet(ProspectMatchIndividualResult response, ExpectedProspectMatchFields fields)
            throws HttpRequestException, AutomationException {
        final SearchProspectResponse responseFromSearch = internalProspectService
                .searchProspect(SearchProspectQueryParameter.buildSearchByOfferCode(2, 0, response.getOfferCode()));
        Prospect searchedProspect = responseFromSearch.getProspects().get(0);
        return isCorrectMatchedbyEmail(searchedProspect, fields.getEmail(), response.isMatchedByEmail())
                && isCorrectMatchedBySsnName(searchedProspect, fields.getSsn(), fields.getFirstName(), fields.getLastName(),
                response.isMatchedBySsnName()) && isCorrectMatchedBySsnAddress(searchedProspect, fields.getSsn(),
                fields.getAddress(), fields.getZip(), fields.getFirstName(), response.isMatchedBySsnAddress())
                && isCorrectFilterByUserID(searchedProspect, fields.getUserId(), response.getFilterByUserID());
    }

    private boolean isCorrectFilterByUserID(Prospect searchedProspect, String userId, String filterByUserID)
            throws AutomationException, HttpRequestException {
        return searchedProspect.getUserId().toString().equalsIgnoreCase(userId) && filterByUserID
                .equalsIgnoreCase(Boolean.toString(true));
    }

    private boolean isCorrectMatchedBySsnAddress(Prospect searchedProspect, String ssn, String address, String zip,
                                                 String firstName, boolean matchedBySsnAddress)
            throws AutomationException, HttpRequestException {
        return (searchedProspect.getPersonalInfo().getSsn().endsWith(ssn.substring(ssn.length() - 5, ssn.length())) &&
                searchedProspect.getAddressInfo().getAddress1().equalsIgnoreCase(address) && searchedProspect.getAddressInfo()
                .getZipCode().equalsIgnoreCase(zip) &&
                searchedProspect.getPersonalInfo().getFirstName().startsWith(firstName.substring(0, 1))) && matchedBySsnAddress;
    }

    private boolean isCorrectMatchedBySsnName(Prospect searchedProspect, String ssn, String firstName, String lastName,
                                              boolean matchedBySsnName) throws AutomationException, HttpRequestException {

        return (searchedProspect.getPersonalInfo().getSsn().endsWith(ssn.substring(ssn.length() - 5, ssn.length())) &&
                searchedProspect.getPersonalInfo().getLastName().equalsIgnoreCase(lastName) &&
                searchedProspect.getPersonalInfo().getFirstName().startsWith(firstName.substring(0, 1))) && matchedBySsnName;
    }

    private boolean isCorrectMatchedbyEmail(Prospect searchedProspect, String email, boolean matchedByEmail) {
        return searchedProspect.getContactInfo().getEmail().equalsIgnoreCase(email) && matchedByEmail;
    }

    private boolean matchResponse(Prospect response, ExpectedProspectMatchFields fields) {
        return matchEmail(response.getContactInfo().getEmail(), fields.getEmail()) &&
                matchSsn(response.getPersonalInfo().getSsn(), fields.getSsn()) && matchAddress(
                response.getAddressInfo().getAddress1(), fields.getAddress())
                && matchZip(response.getAddressInfo().getZipCode(),
                fields.getZip()) && matchFirstName(response.getPersonalInfo().getFirstName(), fields.getFirstName()) &&
                matchLastName(response.getPersonalInfo().getLastName(), fields.getLastName());
    }

    private boolean matchZip(String zipCode, String zip) {
        return zipCode.equalsIgnoreCase(zip);
    }

    private boolean matchLastName(String lastName, String lastName1) {
        return lastName.equalsIgnoreCase(lastName1);
    }

    private boolean matchFirstName(String firstName, String firstName1) {
        return firstName.equalsIgnoreCase(firstName1);
    }

    private boolean matchSsn(String ssn, String ssn1) {
        return ssn.endsWith(ssn1.substring(ssn1.length() - 4));
    }

    private boolean matchAddress(String address, String address1) {
        return address.equalsIgnoreCase(address1);
    }

    private boolean matchEmail(String email, String email1) {
        return email.equalsIgnoreCase(email1);
    }
}
