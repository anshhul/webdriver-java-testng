
package test.api.java.platformOffer;

import com.google.common.base.Objects;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.offers.LoanOfferDAO;
import com.prosper.automation.db.dao.prospect.ProspectOfferDAO;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import test.api.java.PlatformServiceTestBase;

/**
 * Created by pbudiono on 5/9/16.
 */
public abstract class PlatformOfferTestBase extends PlatformServiceTestBase {

    protected static final String RATE_API_SEED_DATA = "RATE_API_SEED_DATA";

    @Resource
    protected IPlatformOffer pubSiteOfferService;

    protected long testUserId;
    protected UserCreditProfilesDAO userCreditProfilesDAO;


    enum LoanTypes {
        BASE, UPSELL, DOWNSELL, INVALID;
    }


    @DataProvider(name = RATE_API_SEED_DATA, parallel = true)
    public Object[][] buildRateAPITestData() {
        final Object[][] testData = new Object[63][1];

        // credit score == 640 - 659
        testData[0][0] = new GetRateTest.RateTestData(640, 4999.0, 20.48, 34.99);
        testData[1][0] = new GetRateTest.RateTestData(640, 9999.0, 19.09, 33.71);
        testData[2][0] = new GetRateTest.RateTestData(640, 14999.0, 19.09, 33.21);
        testData[3][0] = new GetRateTest.RateTestData(640, 19999.0, 20.48, 33.21);
        testData[4][0] = new GetRateTest.RateTestData(640, 24999.0, 20.94, 33.21);
        testData[5][0] = new GetRateTest.RateTestData(640, 29999.0, 21.35, 34.51);
        testData[6][0] = new GetRateTest.RateTestData(640, 35000.0, 21.28, 34.03);

        // credit score == 660 - 679
        testData[7][0] = new GetRateTest.RateTestData(660, 4999.0, 16.26, 31.67);
        testData[8][0] = new GetRateTest.RateTestData(660, 9999.0, 15.64, 29.11);
        testData[9][0] = new GetRateTest.RateTestData(660, 14999.0, 15.97, 29.82);
        testData[10][0] = new GetRateTest.RateTestData(660, 19999.0, 16.26, 29.82);
        testData[11][0] = new GetRateTest.RateTestData(660, 24999.0, 17.29, 29.82);
        testData[12][0] = new GetRateTest.RateTestData(660, 29999.0, 17.29, 28.98);
        testData[13][0] = new GetRateTest.RateTestData(660, 35000.0, 17.84, 29.82);

        // credit score == 680 - 699
        testData[14][0] = new GetRateTest.RateTestData(680, 4999.0, 14.39, 28.98);
        testData[15][0] = new GetRateTest.RateTestData(680, 9999.0, 12.92, 25.36);
        testData[16][0] = new GetRateTest.RateTestData(680, 14999.0, 12.52, 24.23);
        testData[17][0] = new GetRateTest.RateTestData(680, 19999.0, 12.92, 24.22);
        testData[18][0] = new GetRateTest.RateTestData(680, 24999.0, 14.79, 26.26);
        testData[19][0] = new GetRateTest.RateTestData(680, 29999.0, 15.19, 23.51);
        testData[20][0] = new GetRateTest.RateTestData(680, 35000.0, 15.19, 26.26);

        // credit score == 700 - 719
        testData[21][0] = new GetRateTest.RateTestData(700, 4999.0, 12.48, 23.51);
        testData[22][0] = new GetRateTest.RateTestData(700, 9999.0, 11.87, 20.48);
        testData[23][0] = new GetRateTest.RateTestData(700, 14999.0, 11.31, 20.48);
        testData[24][0] = new GetRateTest.RateTestData(700, 19999.0, 11.31, 20.94);
        testData[25][0] = new GetRateTest.RateTestData(700, 24999.0, 12.52, 21.49);
        testData[26][0] = new GetRateTest.RateTestData(700, 29999.0, 12.92, 20.18);
        testData[27][0] = new GetRateTest.RateTestData(700, 35000.0, 13.31, 20.48);

        // credit score == 720 - 739
        testData[28][0] = new GetRateTest.RateTestData(720, 4999.0, 11.31, 20.48);
        testData[29][0] = new GetRateTest.RateTestData(720, 9999.0, 10.45, 17.84);
        testData[30][0] = new GetRateTest.RateTestData(720, 14999.0, 10.45, 17.84);
        testData[31][0] = new GetRateTest.RateTestData(720, 19999.0, 10.45, 17.84);
        testData[32][0] = new GetRateTest.RateTestData(720, 24999.0, 11.87, 18.30);
        testData[33][0] = new GetRateTest.RateTestData(720, 29999.0, 12.48, 18.30);
        testData[34][0] = new GetRateTest.RateTestData(720, 35000.0, 12.48, 18.30);

        // credit score == 740 - 759
        testData[35][0] = new GetRateTest.RateTestData(740, 4999.0, 8.88, 17.84);
        testData[36][0] = new GetRateTest.RateTestData(740, 9999.0, 8.73, 16.26);
        testData[37][0] = new GetRateTest.RateTestData(740, 14999.0, 8.49, 16.26);
        testData[38][0] = new GetRateTest.RateTestData(740, 19999.0, 8.88, 16.26);
        testData[39][0] = new GetRateTest.RateTestData(740, 24999.0, 10.71, 16.26);
        testData[40][0] = new GetRateTest.RateTestData(740, 29999.0, 11.31, 16.82);
        testData[41][0] = new GetRateTest.RateTestData(740, 35000.0, 11.31, 16.82);

        // credit score == 760 - 779
        testData[42][0] = new GetRateTest.RateTestData(760, 4999.0, 8.49, 15.19);
        testData[43][0] = new GetRateTest.RateTestData(760, 9999.0, 8.27, 14.79);
        testData[44][0] = new GetRateTest.RateTestData(760, 14999.0, 8.27, 14.79);
        testData[45][0] = new GetRateTest.RateTestData(760, 19999.0, 8.49, 14.39);
        testData[46][0] = new GetRateTest.RateTestData(760, 24999.0, 10.45, 15.19);
        testData[47][0] = new GetRateTest.RateTestData(760, 29999.0, 10.45, 15.19);
        testData[48][0] = new GetRateTest.RateTestData(760, 35000.0, 10.45, 15.64);

        // credit score == 780 - 799
        testData[49][0] = new GetRateTest.RateTestData(780, 4999.0, 7.81, 12.92);
        testData[50][0] = new GetRateTest.RateTestData(780, 9999.0, 7.81, 12.48);
        testData[51][0] = new GetRateTest.RateTestData(780, 14999.0, 7.81, 13.31);
        testData[52][0] = new GetRateTest.RateTestData(780, 19999.0, 7.81, 12.92);
        testData[53][0] = new GetRateTest.RateTestData(780, 24999.0, 8.88, 14.79);
        testData[54][0] = new GetRateTest.RateTestData(780, 29999.0, 8.88, 14.39);
        testData[55][0] = new GetRateTest.RateTestData(780, 35000.0, 8.49, 13.31);

        // credit score == 800 - 850
        testData[56][0] = new GetRateTest.RateTestData(800, 4999.0, 5.99, 10.45);
        testData[57][0] = new GetRateTest.RateTestData(800, 9999.0, 5.99, 10.45);
        testData[58][0] = new GetRateTest.RateTestData(800, 14999.0, 5.99, 8.88);
        testData[59][0] = new GetRateTest.RateTestData(800, 19999.0, 7.49, 10.70);
        testData[60][0] = new GetRateTest.RateTestData(800, 24999.0, 7.49, 10.71);
        testData[61][0] = new GetRateTest.RateTestData(800, 29999.0, 7.49, 10.70);
        testData[62][0] = new GetRateTest.RateTestData(800, 35000.0, 7.81, 11.87);

        return testData;
    }


    protected static class RateTestData {

        private final Integer creditScore;
        private final Double requestedLoanAmount;
        private final Double minimumAPR;
        private final Double maximumAPR;


        private RateTestData(Integer creditScore, Double requestedLoanAmount, Double minimumAPR, Double maximumAPR) {
            this.creditScore = creditScore;
            this.requestedLoanAmount = requestedLoanAmount;
            this.minimumAPR = minimumAPR;
            this.maximumAPR = maximumAPR;
        }

        public Integer getCreditScore() {
            return creditScore;
        }

        public Double getRequestedLoanAmount() {
            return requestedLoanAmount;
        }

        public Double getMinimumAPR() {
            return minimumAPR;
        }

        public Double getMaximumAPR() {
            return maximumAPR;
        }

        @Override
        public String toString() {
            return String.format("score: %s\trequested_loan_amount: %s", creditScore, requestedLoanAmount);
        }
    }


    protected void validateSavedOffersInvalidTypeCount(OffersResponse response, int savedCount) {
        // Number of offers without INVALID type
        int count = 0;
        for (Offer offerInShowAll : response.getListedOffers().getOffers()) {
            if (offerInShowAll.getOfferType().equalsIgnoreCase(LoanTypes.INVALID.toString())) {
                count++;
            }
        }
        Assert.assertEquals(count, savedCount);
    }

    protected int getCountOfOffersWithType(OffersResponse response, String loanType) {
        List<Offer> offersOfType = new ArrayList<Offer>();
        int count = 0;
        for (Offer withShowAll : response.getListedOffers().getOffers()) {
            if (withShowAll.getOfferType().equalsIgnoreCase(loanType) && (
                    withShowAll.getLoanAmount().intValue() > response.getListedOffers().getRequestedLoanAmount().doubleValue()
                            && loanType.equalsIgnoreCase(LoanTypes.UPSELL.toString())) || (
                    withShowAll.getLoanAmount().intValue() < response.getListedOffers().getRequestedLoanAmount().doubleValue()
                            && loanType.equalsIgnoreCase(LoanTypes.DOWNSELL.toString())) || (
                    withShowAll.getLoanAmount().intValue() == response.getListedOffers().getRequestedLoanAmount().doubleValue()
                            && loanType.equalsIgnoreCase(LoanTypes.BASE.toString()))) {
                count++;
                offersOfType.add(withShowAll);
            }
        }

        return count;
    }

    protected void validateSameOffersWithShowAll(OffersResponse response, OffersResponse responseWithoutShowAll) {
        Assert.assertEquals(response.getUser(), responseWithoutShowAll.getUser());
        if (responseWithoutShowAll.getListedOffers().getListingId() != null)
            Assert.assertEquals(response.getListedOffers().getListingId(), responseWithoutShowAll.getListedOffers()
                    .getListingId());
        Assert.assertEquals(response.getListedOffers().getHasLoanCapRestriction(), responseWithoutShowAll.getListedOffers()
                .getHasLoanCapRestriction());
        Assert.assertEquals(response.getListedOffers().getMaximumLoanCapAmount(), responseWithoutShowAll.getListedOffers()
                .getMaximumLoanCapAmount());
        Assert.assertEquals(response.getListedOffers().getMinimumLoanCapAmount(), responseWithoutShowAll.getListedOffers()
                .getMinimumLoanCapAmount());
        Assert.assertEquals(response.getListedOffers().getRequestedLoanAmount(), responseWithoutShowAll.getListedOffers()
                .getRequestedLoanAmount());
        int size = responseWithoutShowAll.getListedOffers().getOffers().size();
        int count = 0;
        for (Offer withShowAll : response.getListedOffers().getOffers()) {
            for (Offer withoutShowAll : responseWithoutShowAll.getListedOffers().getOffers()) {
                if (withShowAll.getLoanAmount().intValue() == ((Offer) withoutShowAll).getLoanAmount().intValue() &&
                        withShowAll.getApr().intValue() == ((Offer) withoutShowAll).getApr().intValue()
                        && withoutShowAll.getExternalLoanOfferId() != null)
                    Assert.assertNotNull(withShowAll.getExternalLoanOfferId());
                if (withShowAll.getLoanAmount().intValue() == ((Offer) withoutShowAll).getLoanAmount().intValue() &&
                        withShowAll.getApr().intValue() == ((Offer) withoutShowAll).getApr().intValue()
                        && withoutShowAll.getLoanOfferScoreId() != null)
                    Assert.assertNotNull(withShowAll.getLoanOfferScoreId());
                if (withShowAll.getLoanAmount().intValue() == ((Offer) withoutShowAll).getLoanAmount().intValue() &&
                        withShowAll.getApr().intValue() == ((Offer) withoutShowAll).getApr().intValue()
                        && withoutShowAll.getProspectLoanOfferScoreId() != null)
                    Assert.assertNotNull(withShowAll.getProspectLoanOfferScoreId());
                if (withShowAll.getLoanAmount().intValue() == ((Offer) withoutShowAll).getLoanAmount().intValue() &&
                        withShowAll.getApr().intValue() == ((Offer) withoutShowAll).getApr().intValue()
                        && withoutShowAll.getExternalLoanOfferId() != null)
                    Assert.assertNotNull(withShowAll.getExternalLoanOfferId());
                if (withShowAll.getLoanAmount().intValue() == ((Offer) withoutShowAll).getLoanAmount().intValue()
                        &&
                        withShowAll.getApr().intValue() == ((Offer) withoutShowAll).getApr().intValue()
                        &&
                        withShowAll.getMonthlyPayment().intValue() == ((Offer) withoutShowAll).getMonthlyPayment().intValue()
                        &&
                        withShowAll.getTerm() == ((Offer) withoutShowAll).getTerm()
                        &&
                        withShowAll.getOfferValid() == ((Offer) withoutShowAll).getOfferValid()
                        &&
                        withShowAll.getEffectiveYield().intValue() == ((Offer) withoutShowAll).getEffectiveYield().intValue()
                        &&
                        withShowAll.getFinanceCharge().intValue() == ((Offer) withoutShowAll).getFinanceCharge().intValue()
                        &&
                        withShowAll.getLenderYield().intValue() == ((Offer) withoutShowAll).getLenderYield().intValue()
                        &&
                        withShowAll.getLoanCap().intValue() == ((Offer) withoutShowAll).getLoanCap().intValue()
                        &&
                        withShowAll.getOriginationFee().intValue() == ((Offer) withoutShowAll).getOriginationFee().intValue()
                        &&
                        withShowAll.getOriginationFeePercent().intValue() == ((Offer) withoutShowAll).getOriginationFeePercent()
                                .intValue()
                        &&
                        withShowAll.getServicingFeePercent().intValue() == ((Offer) withoutShowAll).getServicingFeePercent()
                                .intValue() &&
                        withShowAll.getProductSpecId().equalsIgnoreCase(((Offer) withoutShowAll).getProductSpecId()) &&
                        withShowAll.getLoanProduct().equalsIgnoreCase(((Offer) withoutShowAll).getLoanProduct()) &&
                        withShowAll.getTerm() == ((Offer) withoutShowAll).getTerm() &&
                        withShowAll.getOfferType().equalsIgnoreCase(((Offer) withoutShowAll).getOfferType()) &&
                        withShowAll.getRateOffered().intValue() == ((Offer) withoutShowAll).getRateOffered().intValue()) {
                    count++;
                }
            }
        }

        Assert.assertEquals(count, size);
    }

    protected void validateDbStoredOffersInCircleOne(OffersResponse response, int expectedCount) {
        int currentCount =
                circleOneDBConnection.getDataAccessObject(LoanOfferDAO.class).getCountOfLoansWithListingID(
                        response.getListedOffers().getListingId());
        Assert.assertEquals(currentCount, expectedCount);
    }

    protected void validateDbStoredOffersInProspect(UUID prospectId, int expectedCount) {
        int currentCount =
                prospectDBConnection.getDataAccessObject(ProspectOfferDAO.class).getCountOfLoansWithProspectID(
                        prospectId.toString());
        Assert.assertEquals(currentCount, expectedCount);
    }

    protected boolean assertEquals(Offer saved, Offer offer) {
        return Double.compare(offer.getRateOffered(), saved.getRateOffered() / 100) == 0 &&
                Double.compare(offer.getApr(), saved.getApr() / 100) == 0 &&
                Double.compare(offer.getMonthlyPayment(), saved.getMonthlyPayment()) == 0 &&
                saved.getTerm() == offer.getTerm() &&
                Double.compare(offer.getFinanceCharge(), saved.getFinanceCharge()) == 0 &&
                saved.getOfferValid() == offer.getOfferValid() &&
                Objects.equal(saved.getExternalLoanOfferId(), offer.getExternalLoanOfferId()) &&
                Objects.equal(saved.getLoanAmount(), offer.getLoanAmount()) &&
                Objects.equal(saved.getOfferType(), offer.getOfferType()) &&
                Objects.equal(saved.getLoanOfferScoreId(), offer.getLoanOfferScoreId()) &&
                Objects.equal(saved.getLoanOfferId(), offer.getLoanOfferId()) &&
                Objects.equal(saved.getProspectLoanOfferScoreId(), offer.getProspectLoanOfferScoreId()) &&
                Objects.equal(saved.getProspectId(), offer.getProspectId());
    }

}
