
package test.api.java.platformprospect;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.CampaignSource;
import com.prosper.automation.model.platform.prospect.PartnerCampaign;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/3/16.
 */
public final class CreatePartnerCampaignTest extends AffiliatePartnerTestBase {

    private String campaignSourceId;
    private CampaignSource testCampaignSource;


    @BeforeClass(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void createTestPartner()
            throws AutomationException, HttpRequestException {
        testCampaignSource = createGenericCampaignSourceRequest(createUniquePartnerName());
        campaignSourceId = internalProspectService.createPartner(testCampaignSource).getCampaignSourceId();
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testCreatePartnerCampaign()
            throws AutomationException, HttpRequestException {

        final PartnerCampaign partnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(createUniqueRefAC())
                        .withRefMc(createUniqueRefMC()).build();

        final PartnerCampaign partnerCampaignResponse = internalProspectService.createPartnerCampaign(partnerCampaign);

        Assert.assertNotNull(partnerCampaignResponse.getCampaignId(), "Campaign ID is null.");
        Assert.assertNotNull(partnerCampaignResponse.getCampaignProgramId(), "Campaign program ID is null.");

        Assert.assertEquals(partnerCampaignResponse.getCampaignChannelName(), "Affiliates");
        Assert.assertNotNull(partnerCampaignResponse.getCampaignChannelId(), "Campaign channel ID is null.");
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testCreateMultiplePartnerCampaign() throws AutomationException, HttpRequestException {

        final PartnerCampaign firstPartnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(createUniqueRefAC())
                        .withRefMc(createUniqueRefMC()).build();

        internalProspectService.createPartnerCampaign(firstPartnerCampaign);

        final PartnerCampaign secondPartnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(createUniqueRefAC())
                        .withRefMc(createUniqueRefMC()).build();

        final PartnerCampaign secondPartnerCampaignResponse =
                internalProspectService.createPartnerCampaign(secondPartnerCampaign);

        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignId(), "Campaign ID is null.");
        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignProgramId(), "Campaign program ID is null.");

        Assert.assertEquals(secondPartnerCampaignResponse.getCampaignChannelName(), "Affiliates");
        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignChannelId(), "Campaign channel ID is null.");
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testCreateMultiplePartnerCampaignProgram() throws AutomationException, HttpRequestException {

        final String partnerRefAC = createUniqueRefAC();

        final PartnerCampaign firstPartnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(partnerRefAC)
                        .withRefMc(createUniqueRefMC()).build();

        internalProspectService.createPartnerCampaign(firstPartnerCampaign);

        final PartnerCampaign secondPartnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(partnerRefAC)
                        .withRefMc(createUniqueRefMC()).build();

        final PartnerCampaign secondPartnerCampaignResponse =
                internalProspectService.createPartnerCampaign(secondPartnerCampaign);

        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignId(), "Campaign ID is null.");
        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignProgramId(), "Campaign program ID is null.");

        Assert.assertEquals(secondPartnerCampaignResponse.getCampaignChannelName(), "Affiliates");
        Assert.assertNotNull(secondPartnerCampaignResponse.getCampaignChannelId(), "Campaign channel ID is null.");
    }

    @Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testCreateDuplicatePartnerCampaign()
            throws AutomationException, HttpRequestException {

        final String partnerRefAC = createUniqueRefAC();

        final PartnerCampaign partnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(partnerRefAC)
                        .withRefMc(createUniqueRefMC()).build();

        internalProspectService.createPartnerCampaign(partnerCampaign);
        internalProspectService.createPartnerCampaign(partnerCampaign);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testCreatePartnerCampaignWithoutRefACTest()
            throws AutomationException, HttpRequestException {
        final PartnerCampaign partnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefMc(createUniqueRefMC()).build();
        internalProspectService.createPartnerCampaign(partnerCampaign);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testCreatePartnerCampaignWithoutRefMCTest()
            throws AutomationException, HttpRequestException {
        final PartnerCampaign partnerCampaign =
                new PartnerCampaign.Builder().withCampaignSourceId(campaignSourceId).withRefAc(createUniqueRefAC()).build();
        internalProspectService.createPartnerCampaign(partnerCampaign);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testCreatePartnerCampaignWithoutCampaignSourceId()
            throws AutomationException, HttpRequestException {
        final PartnerCampaign partnerCampaign =
                new PartnerCampaign.Builder().withRefAc(createUniqueRefAC()).withRefMc(createUniqueRefMC()).build();
        internalProspectService.createPartnerCampaign(partnerCampaign);
    }
}
