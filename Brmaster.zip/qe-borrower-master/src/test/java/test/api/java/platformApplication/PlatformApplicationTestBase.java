package test.api.java.platformApplication;

import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.clients.PlatformApplicationImpl;
import test.api.java.platformprospect.PlatformProspectTestBase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;

/**
 * Created by rsubramanyam on 4/25/16.
 */
public class PlatformApplicationTestBase extends PlatformProspectTestBase {
    @Qualifier("platformApplicationService")
    @Autowired PlatformApplicationImpl platformApplicationService;

    protected void compareResponsesMiscFields(ProspectResponse response, ProspectResponse responseFromProspectService) {
        Assert.assertEquals(response.getProspect().getLoanAmount(), responseFromProspectService.getProspect().getLoanAmount());
//        if(responseFromProspectService.getProspect().getLoanPurposeId() != 0)
//            Assert.assertNotEquals(response.getProspect().getLoanPurposeId(), 0);
        Assert.assertNotNull(response.getProspect().getOfferCode());
        Assert.assertNotNull(response.getProspect().getOfferUserId());
        Assert.assertEquals(response.getProspect().getAbandonReason(), responseFromProspectService.getProspect().getAbandonReason());
        Assert.assertEquals(response.getProspect().getAgentId(), responseFromProspectService.getProspect().getAgentId());
        Assert.assertEquals(response.getProspect().getCampaignProgramId(), responseFromProspectService.getProspect().getCampaignProgramId());
        Assert.assertEquals(response.getProspect().getCreditQualityId(), responseFromProspectService.getProspect().getCreditQualityId());
        Assert.assertEquals(response.getProspect().getExperianId(), responseFromProspectService.getProspect().getExperianId());
        Assert.assertEquals(response.getProspect().getInstitutionId(), responseFromProspectService.getProspect().getInstitutionId());
        Assert.assertEquals(response.getProspect().getMerchantClientName(), responseFromProspectService.getProspect().getMerchantClientName());
        Assert.assertEquals(response.getProspect().getMerchantFunnelName(), responseFromProspectService.getProspect().getMerchantFunnelName());
        Assert.assertEquals(response.getProspect().getOfferUserId(), responseFromProspectService.getProspect().getOfferUserId());
        Assert.assertEquals(response.getProspect().getPassword(), responseFromProspectService.getProspect().getPassword());
        Assert.assertEquals(response.getProspect().getRelationshipId(), responseFromProspectService.getProspect().getRelationshipId());
        Assert.assertEquals(response.getProspect().getRelationshipName(), responseFromProspectService.getProspect().getRelationshipName());
        Assert.assertEquals(response.getProspect().getThirdPartyId(), responseFromProspectService.getProspect().getThirdPartyId());
        Assert.assertEquals(response.getProspect().getUserId(), responseFromProspectService.getProspect().getUserId());
        Assert.assertEquals(response.getProspect().getUsername(), responseFromProspectService.getProspect().getUsername());
        Assert.assertEquals(response.getProspect().getUserCreditPullId(), responseFromProspectService.getProspect().getUserCreditPullId());
        if(responseFromProspectService.getProspect().getReferralId() != null)
            Assert.assertNotNull(response.getProspect().getReferralId());
        Assert.assertEquals(response.getProspect().getPartnerInfo().getEligibilityStatus(), responseFromProspectService.getProspect().getPartnerInfo().getEligibilityStatus());
        Assert.assertEquals(response.getProspect().getPartnerInfo().getIneligibilityReason(), responseFromProspectService.getProspect().getPartnerInfo().getIneligibilityReason());
        Assert.assertEquals(response.getProspect().getPartnerInfo().getExternalProspectId(), responseFromProspectService.getProspect().getPartnerInfo().getExternalProspectId());
        Assert.assertEquals(response.getProspect().getPartnerInfo().getPartnerTrackingId(), responseFromProspectService.getProspect().getPartnerInfo().getPartnerTrackingId());
        if(responseFromProspectService.getProspect().getPartnerInfo().getRefD() != null)
            Assert.assertNotNull(response.getProspect().getPartnerInfo().getRefD());
        if(responseFromProspectService.getProspect().getPartnerInfo().getValidatedMembershipDate() != null)
            Assert.assertNotNull(response.getProspect().getPartnerInfo().getValidatedMembershipDate());
        Assert.assertEquals(response.getProspect().getPartnerInfo().getApplicationId(), responseFromProspectService.getProspect().getPartnerInfo().getApplicationId());

        Assert.assertNotNull(response.getProspect().getTrackingInfo().getCreatedDate());
        Assert.assertEquals(response.getProspect().getTrackingInfo().getUserAttributionMethod(), responseFromProspectService.getProspect().getTrackingInfo().getUserAttributionMethod());
        Assert.assertNotNull(response.getProspect().getTrackingInfo().getCreatedDate());
        if(responseFromProspectService.getProspect().getTrackingInfo().getSendDate() != null)
            Assert.assertNotNull(response.getProspect().getTrackingInfo().getSendDate());
        if(responseFromProspectService.getProspect().getTrackingInfo().getPrePopulate() != null)
            Assert.assertNotNull(response.getProspect().getTrackingInfo().getPrePopulate());

        Assert.assertEquals(response.getProspect().getPartnerApiInfo().getHttpResponseCode(), responseFromProspectService.getProspect().getPartnerApiInfo().getHttpResponseCode());
        Assert.assertEquals(response.getProspect().getPartnerApiInfo().getSourceRequestMessage(), responseFromProspectService.getProspect().getPartnerApiInfo().getSourceRequestMessage());
        Assert.assertEquals(response.getProspect().getPartnerApiInfo().getSourceResponseMessage(), responseFromProspectService.getProspect().getPartnerApiInfo().getSourceResponseMessage());
        if(responseFromProspectService.getProspect().getPartnerApiInfo().getSourceTransactionGuid() != null)
            Assert.assertNotNull(response.getProspect().getPartnerApiInfo().getSourceTransactionGuid());
        Assert.assertEquals(response.getProspect().getPartnerApiInfo().getStatusCode(), responseFromProspectService.getProspect().getPartnerApiInfo().getStatusCode());

        Assert.assertEquals(response.getCampaign().getCampaignChannelId(), responseFromProspectService.getCampaign().getCampaignChannelId());
        Assert.assertEquals(response.getCampaign().getCampaignSourceId(), responseFromProspectService.getCampaign().getCampaignSourceId());
        Assert.assertEquals(response.getCampaign().getCreatedDate(), responseFromProspectService.getCampaign().getCreatedDate());
        Assert.assertEquals(response.getCampaign().getDuration(), responseFromProspectService.getCampaign().getDuration());
        Assert.assertEquals(response.getCampaign().getDescription(), responseFromProspectService.getCampaign().getDescription());
        Assert.assertEquals(response.getCampaign().getEndDate(), responseFromProspectService.getCampaign().getEndDate());
        Assert.assertEquals(response.getCampaign().getLandingPage(), responseFromProspectService.getCampaign().getLandingPage());
        Assert.assertEquals(response.getCampaign().getModifiedDate(), responseFromProspectService.getCampaign().getModifiedDate());

        Assert.assertEquals(response.getChannel().getName(), responseFromProspectService.getChannel().getName());
        Assert.assertEquals(response.getChannel().getModifiedDate(), responseFromProspectService.getChannel().getModifiedDate());
        Assert.assertEquals(response.getChannel().getCreatedDate(), responseFromProspectService.getChannel().getCreatedDate());
        Assert.assertEquals(response.getChannel().getCampaignChannelId(), responseFromProspectService.getChannel().getCampaignChannelId());
        Assert.assertEquals(response.getChannel().getRank(), responseFromProspectService.getChannel().getRank());

        Assert.assertEquals(response.getProgram().getCreatedDate(), responseFromProspectService.getProgram().getCreatedDate());
        Assert.assertEquals(response.getProgram().getModifiedDate(), responseFromProspectService.getProgram().getModifiedDate());
        Assert.assertEquals(response.getProgram().getName(), responseFromProspectService.getProgram().getName());
        Assert.assertEquals(response.getProgram().getDescription(), responseFromProspectService.getProgram().getDescription());
        Assert.assertEquals(response.getProgram().getCampaignId(), responseFromProspectService.getProgram().getCampaignId());
        Assert.assertEquals(response.getProgram().getCampaignProgramId(), responseFromProspectService.getProgram().getCampaignProgramId());
        Assert.assertEquals(response.getProgram().getPricingId(), responseFromProspectService.getProgram().getPricingId());
        Assert.assertEquals(response.getProgram().getRefMc(), responseFromProspectService.getProgram().getRefMc());
        Assert.assertEquals(response.getProgram().getProgramRuleSetId(), responseFromProspectService.getProgram().getProgramRuleSetId());
        Assert.assertEquals(response.getPricing(), responseFromProspectService.getPricing());
    }
}
