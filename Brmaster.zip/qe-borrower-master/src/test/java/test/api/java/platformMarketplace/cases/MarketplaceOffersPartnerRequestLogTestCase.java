package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MarketplaceOffersPartnerRequestLogTestCase extends BorrowerTestCase {
    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log when authentication issue occurs", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide invalid partner source code in the request"}, expectedResult = "Partner request table populated. Partner Request Errors table populated correctly with authentication error")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testPartnerRequestLogForAuthenticationIssue() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log when validation issue occurs", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide invalid required field in the request"}, expectedResult = "Partner request table populated. Partner Request Errors table populated correctly with validation error")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.SANITY, TestGroup.NIGHTLY}) void testPartnerRequestLogForValidationIssue() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log when application id is missing", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Application id should not be included in the request."}, expectedResult = "Partner request table populated with null application id")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testMissingApplicationId() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log when there are no errors", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Validate partner request error table when there are no errors"}, expectedResult = "Partner request table populated. No errors in Partner Request Errors Table")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})  public void testNoErrors() throws AutomationException, HttpRequestException ;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log when there is error from offers service", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Validate offers error in partner request, partner request error table"}, expectedResult = "Partner request table populated. Errors populated in Partner Request Errors Table")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})  public void testPartnerRequestErrorsUpdationForOffersErrors() throws AutomationException, HttpRequestException;
}
