package test.api.java.platformMerchant;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import test.api.java.PlatformServiceTestBase;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.MerchantConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.OfficeRoles;
import com.prosper.automation.model.platform.OfficeRolesName;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.merchant.MerchantOfferedProductSpecs;
import com.prosper.automation.model.platform.merchant.MerchantRequest;
import com.prosper.automation.model.platform.merchant.MerchantResponse;
import com.prosper.automation.model.platform.merchant.MerchantType;
import com.prosper.automation.model.platform.merchant.MerchantsContactInformation;
import com.prosper.automation.platform.interfaces.IPlatformMerchant;

/**
 * Created by pbudiono on 6/6/16.
 */
public abstract class PlatformMerchantTestBase extends PlatformServiceTestBase {

	protected static final int DEFAULT_SEARCH_LIMIT = 2;

	@Resource
	protected IPlatformMerchant pubSiteMerchantService;

	protected MerchantResponse createMerchant(final String email, final String providerId, final String merchantName,
			final MerchantType merchantType) throws AutomationException, HttpRequestException {

		final List<OfficeRoles> officeRoles = Arrays.asList(
				new OfficeRoles.Builder().withIsPrimary(true).withOfficeRoleName(OfficeRolesName.PRIMARY_CONTACT).build());
		final List<MerchantsContactInformation> merchantsContacts = Arrays.asList(new MerchantsContactInformation.Builder()
				.withFirstName(MerchantConstant.DEFAULT_MERCHANT_FIRST_NAME)
				.withLastName(MerchantConstant.DEFAULT_MERCHANT_LAST_NAME).withSalutation(MerchantConstant.DEFAULT_SALUTATION)
				.withSignerDateOfBirth(MerchantConstant.DEFAULT_SIGNER_DOB).withAddress(MerchantConstant.DEFAULT_ADDRESS)
				.withTitle(MerchantConstant.DEFAULT_TITLE).withEmail(MerchantConstant.DEFAULT_EMAIL)
				.withPhone(MerchantConstant.DEFAULT_PHONE_NUMBER).withIsMainPointOfContact(true)
				.withContactThirdPartyId(MerchantConstant.DEFAULT_CONTACT_THIRD_PARTY_ID).withOfficeRoles(officeRoles).build());

		final List<MerchantOfferedProductSpecs> merchantOfferedProductSpecs = Arrays
				.asList(new MerchantOfferedProductSpecs.Builder().withLowerThreshold(MerchantConstant.DEFAULT_LOWER_THRESHOLD)
						.withUpperThreshold(MerchantConstant.DEFAULT_UPPER_THRESHOLD)
						.withTermInMonths(MerchantConstant.DEFAULT_TERMS_IN_MONTH)
						.withPromoLengthMonths(MerchantConstant.DEFAULT_PROMO_LENGTH)
						.withFundingDestinationTypeId(MerchantConstant.DEFAULT_FUNDING_DESTINATION_ID).build());

		final List<AddressInfo> billingAddress = Arrays.asList(AddressInfoConstant.buildDefaultAddressInfo());
		final List<PhoneNumber> phoneNumbers = Arrays.asList(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER);
		final List<BankAccountInfo> bankAccountInfos = Arrays.asList(BankAccountConstant.BANK_OF_AMERICA_BANK_ACCOUNT_1);

		final MerchantRequest merchantRequest = new MerchantRequest.Builder().withRole(MerchantConstant.DEFAULT_ROLE)
				.withPartnerName(MerchantConstant.DEFAULT_PARTNER_NAME).withEmailAddress(email)
				.withMerchantsContactInformation(merchantsContacts).withLegalName(merchantName)
				.withDoingBusinessAs(MerchantConstant.DEFAULT_PURPOSE).withIndustry(MerchantConstant.DEFAULT_INDUSTRY)
				.withMerchantFunnelName(MerchantConstant.DEFAULT_MERCHANT_FUNNEL_NAME).withProviderId(providerId)
				.withPromoOption(MerchantConstant.DEFAULT_PROMO_OPTION)
				.withNextReviewDate(MerchantConstant.DEFAULT_NEXT_REVIEW_DATE)
				.withMerchantOfferedProductSpecs(merchantOfferedProductSpecs)
				.withIntendedRole(MerchantConstant.DEFAULT_INTENDED_ROLE).withBillingAddress(billingAddress)
				.withPhoneNumbers(phoneNumbers).withBankAccountinfo(bankAccountInfos)
				.withComplianceStatus(MerchantConstant.DEFAULT_COMPLIANCE_STATUS).withMerchantType(merchantType).build();

		return pubSiteUserService.createMerchant(merchantRequest);
	}
}
