
package test.api.java.applicantDb.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/4/16.
 */
public interface SplitApplicantTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by email", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email A. Update prospect B with email B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by 9 digit SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with SSN A, Create prospect B with SSN A. Update prospect B with SSN B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy9Ssn() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with same email by different 9 digit SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, SSN A. Create prospect B with email A, SSN A. Update prospect B with SSN B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy9SsnEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with same email by different 7 digit SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email A, 7 SSN B. Update prospect B with email A, 7 SSN A"}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with same email by different 7 digit SSN, address", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email A, 7 SSN A. Update prospect B with 7 SSN B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnAddressEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with same email by different 7 digit SSN, address, zipcode", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, 7 SSN A, Address, zip, last name A. Create prospect B with email A, 7 SSN A, Address, zip, last name A. Update prospect B with email A, 7 SSN B, (last name, address, zip) B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnZipLastNameEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with same email by different 7 digit SSN, first initial, last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email A, 7 SSN A. Update prospect B with email A, 7 SSN B, FI B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnFIEmailTrumped()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with 9 digit SSN by different 7 digit SSN, first initial, last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, 9 digit SSN A, Create prospect B with email A, 7SSN A, First initial A, Last Name A. Update prospect B with email A, 7SSN B, First initial B, Last Name B"}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnFirstInitialLastNameFrom9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with 9 digit SSN by different 7 digit SSN, first initial, address, zipcode.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, 9 digit SSN A, Create prospect B with email A, 7 digit SSN A, Address A, Zipcode A. Update prospect B with 7 digit SSN B, Address B, Zipcode B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy7SsnFirstInitialAddressZipFrom9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant with 9 digit SSN from different 7 digit SSN, first initial.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, 7 SSNA, Create prospect B with email A, 7 SSNA. Update prospect B with email A, different 9 SSN, Address, Zip First Initial"}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitBy9SsnFromAddressZipFirstInitial7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by first initial.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with First Initial A, Create prospect B with First Initial A, all details same as A. Update prospect B with First Initial B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitByFirstInitial()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by last name.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 7 digit SSN A, last name A, Create prospect B with last name A, all details same as A. Update prospect B with last name B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitByLastName()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by address.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 7 digit SSN A, address A, Create prospect B with address A, all details same as A. Update prospect B with address B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitByAddress() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test split applicant by zipcode.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 7 digit SSN A, zipcode A, Create prospect B with zipcode A, all details same as A. Update prospect B with zipcode B."}, expectedResult = "New applicant created for prospect B")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantSplitByZip() throws AutomationException, HttpRequestException, CloneNotSupportedException;
}
