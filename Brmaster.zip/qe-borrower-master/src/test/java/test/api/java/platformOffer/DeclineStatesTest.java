
package test.api.java.platformOffer;

import com.prosper.automation.db.dao.StateLendingRegulationsDAO;

import org.testng.Assert;
import org.testng.annotations.Test;

import test.api.java.PlatformServiceTestBase;

/**
 * Created by rsubramanyam on 6/24/16.
 */
public class DeclineStatesTest extends PlatformServiceTestBase {

    private static final String[] declineTests = {"WV", "IA", "ME", "ND"};

    @Test
    public void testDeclineStates() {
        StateLendingRegulationsDAO dao = circleOneDBConnection.getDataAccessObject(StateLendingRegulationsDAO.class);
        for (String state : declineTests) {
            String flagStatus = dao.getAcceptingNewLoans(state);
            Assert.assertTrue(flagStatus.equalsIgnoreCase("0"), "State should not accept Prosper loans!");
        }
    }
}
