
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.offer.UserOfferRequest;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.io.IOException;

/**
 * Created by gzhou on 2/3/17.
 */
public class GenerateDraftOffersTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;


    @BeforeMethod
    public void createNewBorrowerData() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
    }

    @Test
    public void testGenerateDraftOffers() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long userId = testUserResponse.getUserRequest().getUserId();
        final OffersResponse offers = pubSiteOfferService
                .getUserOffers(userId, 5000, Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_CREDIT_RANGE_ID, false);
        Assert.assertNotNull(offers);

        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingsDAO.updateListingStatusAndLoanProductIdByUserId(1, 1, userId);

        UserOfferRequest userOfferRequest = new UserOfferRequest();
        userOfferRequest.setUserAnnualIncome(testUserResponse.getUserRequest().getUserEmploymentInfo().getAnnualIncome());
        final OffersResponse draftOffers = pubSiteOfferService.generateUserDraftOffers(userOfferRequest);
        Assert.assertNotNull(draftOffers);
        Assert.assertEquals(offers.getListedOffers().getRequestedLoanAmount(),
                draftOffers.getListedOffers().getRequestedLoanAmount());
        Assert.assertEquals(offers.getListedOffers().getListingId(), draftOffers.getListedOffers().getListingId());
        Assert.assertEquals(offers.getListedOffers().getOffers().size(), draftOffers.getListedOffers().getOffers().size());
        Assert.assertEquals(offers.getListedOffers().getOffers().get(0).getApr(),
                draftOffers.getListedOffers().getOffers().get(0).getApr());

    }
}
