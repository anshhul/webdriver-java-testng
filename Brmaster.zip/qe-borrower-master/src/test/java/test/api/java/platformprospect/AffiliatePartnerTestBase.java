
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PartnerConstant;
import com.prosper.automation.model.platform.prospect.CampaignSource;

/**
 * Created by pbudiono on 8/2/16.
 */
public abstract class AffiliatePartnerTestBase extends PlatformProspectTestBase {

    protected static final String DEFAULT_COMPANY_NAME = "Prosper Marketplace";
    protected static final String DEFAULT_CONTACT_NAME = "Borrower Marketplace";
    protected static final String DEFAULT_CONTACT_EMAIL = "bmp@prosper.com";
    protected static final String DEFAULT_CONTACT_PHONE = "(866) 615-6319";

    protected static final String NON_EXISTING_CAMPAIGN_SOURCE_ID = Constant.getGloballyUniqueString();

    protected static final String DEFAULT_REF_AC_PREFIX = "DEFAULT_REF_ACS";
    protected static final String DEFAULT_REF_MC_PREFIX = "DEFAULT_REF_MCS";


    protected CampaignSource createGenericCampaignSourceRequest(final String partnerName) {
        return new CampaignSource.Builder()
                .withName(partnerName)
                .withCompanyName(DEFAULT_COMPANY_NAME)
                .withContactName(DEFAULT_CONTACT_NAME)
                .withContactEmail(DEFAULT_CONTACT_EMAIL)
                .withContactPhone(DEFAULT_CONTACT_PHONE)
                .build();
    }

    protected String createUniquePartnerName() {
        return String.format("%s_%s", PartnerConstant.PARTNER_NAME_PREFIX, Constant.getGloballyUniqueString());
    }

    protected String createUniqueRefAC() {
        return String.format("%s_%s", DEFAULT_REF_AC_PREFIX, Constant.getGloballyUniqueString());
    }

    protected String createUniqueRefMC() {
        return String.format("%s_%s", DEFAULT_REF_MC_PREFIX, Constant.getGloballyUniqueString());
    }
}
