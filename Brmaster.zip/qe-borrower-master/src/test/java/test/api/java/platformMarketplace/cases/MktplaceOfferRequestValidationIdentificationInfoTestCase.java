
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationIdentificationInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test identification_info with different values", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different identification_info values"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testIdInfo")
    void testIdInfoWithParameters(String code, ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing identification_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Skip identification_info fields"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMissingIdInfo")
    void testIdInfoWithMissingParameters(String fieldName,
                                         ResponseErrorsHelper expectedError)
                                                 throws AutomationException, HttpRequestException;
}
