
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.interfaces.IPlatformOffer;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rsubramanyam on 6/30/16.
 */
public class GetUserOffersTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;

    @BeforeMethod
    public void createNewBorrowerData() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
    }

    @Test
    public void testGetBorrowerOffers() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response =
                pubSiteOfferService.getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
        Assert.assertNotNull(response);

    }

    @Test
    public void testGetUserOffersHappyPath() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService.getUserOffer();
        Assert.assertNotNull(response);
    }
}
