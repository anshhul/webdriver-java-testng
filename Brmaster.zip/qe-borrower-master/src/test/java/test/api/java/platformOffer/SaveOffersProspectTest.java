
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.prospect.ProspectOfferDAO;
import com.prosper.automation.enumeration.platform.UserSourceSystem;
import com.prosper.automation.enumeration.platform.UserType;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.ProspectDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.interfaces.IPlatformProspect;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Created by rsubramanyam on 7/1/16.
 */
public class SaveOffersProspectTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;
    ProspectOfferDAO loanOfferDao;

    @Resource
    IPlatformProspect internalProspectService;


    @BeforeMethod(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void createNewBorrowerData() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
        loanOfferDao = prospectDBConnection.getDataAccessObject(ProspectOfferDAO.class);
    }

    @DataProvider(name = "differentOffers")
    public static Object[][] differentOfferParams() {
        return new Object[][] { {null}, {new Offer()}};
    }

    @Test(dataProvider = "differentOffers", expectedExceptions = HttpBadRequestException.class,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveInvalidOfferBorrowerOffers(Offer offer) throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        if(offer != null)
            offer.setProspectId(prospectId.toString());
        pubSiteOfferService.saveProspectOffers(offer);
    }

    @DataProvider(name = "differentProspects")
    public static Object[][] differentProspectParams() {
        return new Object[][] {{UUID.randomUUID()}};
    }

    @Test(dataProvider = "differentProspects", expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_0009,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveInvalidProspectBorrowerOffers(UUID prospectId) throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        response.getListedOffers().getOffers().get(0).setProspectId(prospectId.toString());
        pubSiteOfferService.saveProspectOffers(response.getListedOffers().getOffers().get(0));
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInProspect(prospectId, 10);
        testSaveCachedBorrowerOffers(response, prospectId);
        testSavePersistedBorrowerOffers(response, prospectId);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersUser2Offers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail, 38000.00));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse responseWithoutShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID);
        validateDbStoredOffersInProspect(prospectId, 4);
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        validateSameOffersWithShowAll(response, responseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, 8);
        response.getListedOffers().getOffers().get(0).setProspectId(prospectId.toString());
        pubSiteOfferService.saveProspectOffers(response.getListedOffers().getOffers().get(0));
        validateDbStoredOffersInProspect(prospectId, 8);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersMilitaryState() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithMilitaryState(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInProspect(prospectId, 10);
        testSaveCachedBorrowerOffers(response, prospectId);
        testSavePersistedBorrowerOffers(response, prospectId);
    }

    @Test(enabled = false, description = "https://jira.prosper.com/browse/BMP-2348",
            expectedExceptions = HttpBadRequestException.class,
            groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerInvalidType() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        response.getListedOffers().getOffers().get(0).setProspectId(prospectId.toString());
        pubSiteOfferService.saveProspectOffers(response.getListedOffers().getOffers().get(0), UserType.USER,
                UserSourceSystem.PARTNER_REFERRAL);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersAllPersistedMatchCached() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        Offer[] offer = getPersistedOffers(response, 11);
        List<Offer> offersList = new ArrayList<Offer>(Arrays.asList(offer));
        offersList.remove(null);
        Assert.assertEquals(offersList.size(), 10);
    }

    private void testSaveCachedBorrowerOffers(OffersResponse response, UUID prospectId)
            throws AutomationException, HttpRequestException {
        Offer[] offer = getCachedOffers(response, 2);
        offer[0].setProspectId(prospectId.toString());
        Offer saved = pubSiteOfferService.saveProspectOffers(offer[0]);
        assertEquals(saved, offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInProspect(prospectId, 11);
        offer[0].setProspectId(prospectId.toString());
        saved = pubSiteOfferService.saveProspectOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInProspect(prospectId, 11);
        offer[1].setProspectId(prospectId.toString());
        saved = pubSiteOfferService.saveProspectOffers(offer[1]);
        assertEquals(saved, offer[1]);
        validateDbStoredOffersInProspect(prospectId, 12);
    }

    private void testSavePersistedBorrowerOffers(OffersResponse response, UUID prospectId)
            throws AutomationException, HttpRequestException {
        Offer[] offer = getPersistedOffers(response, 2);
        offer[0].setProspectId(prospectId.toString());
        Offer saved = pubSiteOfferService.saveProspectOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInProspect(prospectId, 12);
        offer[0].setProspectId(prospectId.toString());
        saved = pubSiteOfferService.saveProspectOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInProspect(prospectId, 12);
        offer[1].setProspectId(prospectId.toString());
        pubSiteOfferService.saveProspectOffers(offer[1]);
        validateDbStoredOffersInProspect(prospectId, 12);
    }

    @DataProvider(name = "differentUserSourceSystems")
    public static Object[][] getUserSourceSystems() {
        return new Object[][] { {UserSourceSystem.APP_BY_PHONE}, {UserSourceSystem.PUBLIC_SITE},
                {UserSourceSystem.PARTNER_REFERRAL}};
    }

    @Test(dataProvider = "differentUserSourceSystems",groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveProspectOffersDifferentSourceSystems(UserSourceSystem system) throws AutomationException,
            HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse response =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = response.getProspect().getProspectId();
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, true, UserType.PROSPECT, system);
        offersResponseWithShowAll.getListedOffers().getOffers().get(0).setProspectId(prospectId.toString());
        Offer offer =
                pubSiteOfferService
                        .saveProspectOffers(offersResponseWithShowAll.getListedOffers().getOffers().get(0));
        Assert.assertNotNull(offer);
    }

    private Offer[] getPersistedOffers(OffersResponse response, int numberOfOffers) {
        return getOffers(response, numberOfOffers, true);
    }

    private Offer[] getCachedOffers(OffersResponse response, int numberOfOffers) {
        return getOffers(response, numberOfOffers, false);
    }

    private Offer[] getOffers(OffersResponse response, int numberOfOffers, boolean persisted) {
        String prospectId = response.getListedOffers().getOffers().get(0).getProspectId();
        Offer[] offers = new Offer[numberOfOffers];
        int count = 0;
        List<Integer> loanAmounts = loanOfferDao.getLoanAmountPersisted(prospectId);
        for (Offer offer : response.getListedOffers().getOffers()) {
            if (count == numberOfOffers) {
                break;
            }
            boolean found = false;
            for (Integer amount : loanAmounts) {
                if (offer.getLoanAmount().intValue() == amount.intValue()) {
                    found = true;
                    break;
                }
            }
            if (!found && !persisted) {
                offers[count++] = offer;
            } else if ((!found && persisted) || (found && !persisted)) {
                continue;
            } else {
                int countOfPersistedOffers = loanOfferDao
                        .isOfferPersisted(offer.getLoanAmount(), offer.getApr() / 100, prospectId);
                if ((persisted && countOfPersistedOffers > 0) || (!persisted && countOfPersistedOffers == 0)) {
                    offers[count++] = offer;
                }
            }
        }
        return offers;
    }

}
