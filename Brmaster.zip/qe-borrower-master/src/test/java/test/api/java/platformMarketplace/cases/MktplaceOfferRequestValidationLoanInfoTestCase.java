
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationLoanInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test different values for loan_info", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Check with different values of loan_info fields"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testloanInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testloanInfoWithParameters(String loanAmount, String loanPurposeId,
                                    String selfReportedCreditScore,
                                    ResponseErrorsHelper expectedError)
                                            throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing loan_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Check with missing loan_info fields"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMissingLoanInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testLoanInfoWithMissingParameters(String fieldName,
                                           ResponseErrorsHelper expectedError)
                                                   throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test marketplace get offers with double loan amount", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide double loan amount"}, expectedResult = "HTTP 200 OK Response without errors")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testValidationSuccessNoOffersWithDoubleLoanAmount() throws AutomationException, HttpRequestException;
}
