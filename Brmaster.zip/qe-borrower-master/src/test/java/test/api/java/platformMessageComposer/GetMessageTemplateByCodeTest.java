
package test.api.java.platformMessageComposer;

import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;
import com.prosper.automation.model.platform.email.PaginatedEmailMessageTemplate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/12/16.
 */
public class GetMessageTemplateByCodeTest extends PlatformMessageComposerTestBase {

    private EmailMessageTemplate emailMessageTemplate;


    @BeforeClass(groups = {TestGroup.NIGHTLY})
    public void createMessageTemplate() throws AutomationException, HttpRequestException {
        emailMessageTemplate = internalMessageComposerService
                .createMessageTemplate(createGenericMessageTemplateRequest(createUniqueTemplateCode()));
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testGetMessageTemplateByCode() throws AutomationException, HttpRequestException {
        final PaginatedEmailMessageTemplate paginatedEmailMessageTemplate =
                internalMessageComposerService
                        .getMessageTemplateByCode(emailMessageTemplate.getMessageTemplateCode(), 10, 0);
        Assert.assertFalse(paginatedEmailMessageTemplate.getResults().isEmpty());
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testGetMessageTemplateByEmptyCode() throws AutomationException, HttpRequestException {
        final PaginatedEmailMessageTemplate paginatedEmailMessageTemplate =
                internalMessageComposerService.getMessageTemplateByCode(StringConstant.EMPTY, 10, 0);
        Assert.assertTrue(paginatedEmailMessageTemplate.getResults().isEmpty());
    }
}
