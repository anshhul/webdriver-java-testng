
package test.api.java.platformprospect;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.LendingAccreditationConstant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.model.platform.user.ProspectToBorrowerRequest;
import com.prosper.automation.model.platform.user.ProspectToBorrowerResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.platform.interfaces.IPlatformProspect;
import com.prosper.automation.platform.interfaces.IPlatformUser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public final class CreateDigitalMarketingProspectTest extends PlatformProspectTestBase {

    private static final String EXPECTED_CHANNEL_NAME = "Digital";

    private static final String DIGITAL_CAMPAIGN_PROGRAM = "DIGITAL_CAMPAIGN_PROGRAM";

    @Autowired
    private IPlatformProspect internalProspectService;

    @Autowired
    @Qualifier("pubSiteUserService")
    private IPlatformUser pubSiteUserService;

    @Autowired
    private IPlatformOffer pubSiteOfferService;


    // @DataProvider(name = "DIGITAL_CAMPAIGN_PROGRAM")
    private static ProspectRequest buildProspectRequest(final String email, final String refAC, final String refMC) {
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(EMPLOYMENT_STATUS_ID.toString())
                .withAnnualIncome(Double.valueOf(ANNUAL_INCOME))
                .build();
        final PersonalInfo personalInfo = new PersonalInfo.Builder()
                .withFirstName(Constant.TEST_FIRST_NAME)
                .withLastName(Constant.TEST_LAST_NAME)
                .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH)
                .build();
        final ContactInfo contactInfo = new ContactInfo.Builder()
                .withEmail(email)
                .build();
        final AddressInfo addressInfo = new AddressInfo.Builder()
                .withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                .withCity(AddressInfoConstant.TEST_CITY)
                .withState(AddressInfoConstant.TEST_STATE_GA)
                .withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID)
                .build();
        final Prospect prospect = new Prospect.Builder()
                .withCreditQualityId(SELF_REPORTED_CREDIT_SCORE.toString())
                .withPersonalInfo(personalInfo)
                .withAddressInfo(addressInfo)
                .withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo)
                .build();
        return new ProspectRequest.Builder()
                .withRefAc(refAC)
                .withRefMc(refMC)
                .withProspect(prospect)
                .build();
    }

    @Test
    public void testCreateDigitalMarketingProspect() throws AutomationException, HttpRequestException {
        final String email = Constant.getGloballyUniqueEmail();

        final ProspectRequest prospectRequest = buildProspectRequest(email, "Facebook", "Recent-Approval-App-lal1-mnf");
        final ProspectResponse prospectResponse = internalProspectService.createProspect(prospectRequest);

        final String actualChannelName = prospectResponse.getChannel().getName();
        Assert.assertEquals(EXPECTED_CHANNEL_NAME, actualChannelName);

        final OffersResponse offersResponse = pubSiteOfferService.getProspectOffers(
                prospectResponse.getProspect().getProspectId(),
                Double.valueOf(LOAN_AMOUNT),
                LOAN_PURPOSE_ID,
                LOAN_PURPOSE_ID);

        final String offerId = offersResponse.getListedOffers().getOffers().get(0).getLoanOfferId();
        final ProspectToBorrowerRequest prospectToBorrowerRequest = new ProspectToBorrowerRequest.Builder()
                .withLendingAccreditation(LendingAccreditationConstant.AGREED_LANDING_ACCREDITATION)
                .withOfferId(offerId)
                .withPassword(Constant.COMMON_PASSWORD)
                .withProspectId(prospectResponse.getProspect().getProspectId())
                .build();

        final ProspectToBorrowerResponse prospectToBorrowerResponse =
                pubSiteUserService.convertProspectToBorrower(prospectToBorrowerRequest);

    }
}
