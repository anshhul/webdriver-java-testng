
package test.api.java.platformprospect.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/22/16.
 */
public interface GetRecentProspectInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(
            project = BMP,
            testTitle = "Verify that we can execute recent prospect changes dao query",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "platform-prospect"},
            stepToTests = {"Create [GET] /prospects/prospect/test/inquiry/recentprospectinfo/{listingId}/{userId}/{offerCode}/{termsApprovalDateMillis} http request."},
            expectedResult = "Valid channel name and campaign returned from the query"
            )
            @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
            void testGetRecentProspectInfo() throws AutomationException, HttpRequestException;
}
