
package test.api.java.platformMarketplace;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationEmploymentInfoTestCase;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public class MktplaceOfferRequestValidationEmploymentInfoTest extends MarketplaceOffersTestBase implements
        MktplaceOfferRequestValidationEmploymentInfoTestCase {

    private static final String EMPLOYMENT_STATUS_ID = "status";
    private static final String EMPLOYMENT_INCOME = "income";
    private static final String SUCCESS_RESPONSE = "Success";
    @Autowired
    private IPlatformMarketplace marketplaceService;

    @DataProvider(name = "testEmploymentInfo")
    public static Object[][] employmentInfoTest() {
        return new Object[][]{
                {"-1", 35.00, 3, 3005, ResponseErrorsHelper.EMP_STATUS_INVALID},
                {"3.4", 35.12, 3, 3005, ResponseErrorsHelper.EMP_STATUS_INVALID},
                // Amount checks
                {"3", 9999999.1, 3, 3005, ResponseErrorsHelper.YEARLY_INCOME_EXCEEDS_MAX},
                // Month invalid
                {"3.4", 35.12, -34, 3005, ResponseErrorsHelper.EMP_MONTH_INVALID},
                // 0 - Month invalid
                {"7", 35.12, 0, 3005, ResponseErrorsHelper.EMP_MONTH_INVALID},
                // Year invalid
                {"3.4", 35.12, 0, -3, ResponseErrorsHelper.EMP_YEAR_INVALID},
                // Status invalid
                // {"4", 35.12, 3, -3, ResponseErrorsHelper.EMP_STATUS_INVALID},
                {"", 5000, 3, 3000, ResponseErrorsHelper.EMP_STATUS_NULL_EMPTY},
                // character status
                {"A", 455, 3, 3000, ResponseErrorsHelper.EMP_STATUS_INVALID}};
    }

    @DataProvider(name = "testEmploymentMonthInfo")
    public static Object[][] employmentMonthInfoTest() {
        return new Object[][]{

                // 1 to 12  - Month valid check
                {"7", 120000, 1, 2012},

                // 0 - Month valid
                {"7", 120000, 11, 2012},

                // 0 - Month valid
                {"7", 120000, 12, 2012}};
    }


    @DataProvider(name = "testMissingEmpInfo")
    public static Object[][] employmentInfoMissingTest() {
        return new Object[][]{
                // Missing status
                {EMPLOYMENT_STATUS_ID, ResponseErrorsHelper.EMP_STATUS_NULL_EMPTY},
                // Missing income
                {EMPLOYMENT_INCOME, ResponseErrorsHelper.YEARLY_INCOME_NULL_EMPTY},};
    }

    @DataProvider(name = "testEmploymentStatusBoundsCheck")
    public static Object[][] employmentStatusInfoTest() {
        return new Object[][]{{"3", ResponseErrorsHelper.NO_MATCHING_OFFERS},
                {"5", ResponseErrorsHelper.NO_MATCHING_OFFERS}, {"6", ResponseErrorsHelper.NO_MATCHING_OFFERS},
                {"7", ResponseErrorsHelper.NO_MATCHING_OFFERS}};
    }

    @Override
    @Test(dataProvider = "testEmploymentInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoWithParameters(String statusId,
                                                 double annualIncome,
                                                 int empMonth, int empYear,
                                                 ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        EmploymentInfo info = new EmploymentInfo.Builder().withEmploymentStatusId(String.valueOf(statusId))
                .withAnnualIncome(annualIncome).withEmploymentMonth(empMonth).withEmploymentYear(empYear).build();
        validateResponseForEmploymentInfo(info, expectedError, true);
    }

    @Test(dataProvider = "testEmploymentMonthInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoMonthsAllow0to12(String statusId,
                                                   double annualIncome,
                                                   int empMonth, int empYear
    )
            throws AutomationException, HttpRequestException, JsonProcessingException {
        EmploymentInfo info = new EmploymentInfo.Builder().withEmploymentStatusId(String.valueOf(statusId))
                .withAnnualIncome(annualIncome).withEmploymentMonth(empMonth).withEmploymentYear(empYear).build();

        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withEmploymentInfo(info)
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfoTahir()).build();


        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(response);
        Assert.assertTrue(response.getOffers().size() > 0);

    }


    @Override
    @Test(dataProvider = "testEmploymentStatusBoundsCheck", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentStatusBoundsCheck(String statusId,
                                                ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        EmploymentInfo info = new EmploymentInfo.Builder().withEmploymentStatusId(String.valueOf(statusId))
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
        validateResponseForEmploymentInfo(info, expectedError, false);
    }

    @Override
    @Test(dataProvider = "testMissingEmpInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoWithMissingParameters(String fieldName,
                                                        ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        EmploymentInfo info = buildInfo(fieldName);
        validateResponseForEmploymentInfo(info, expectedError, true);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoTotallyMissing() throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo())
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();

        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.EMP_STATUS_NULL_EMPTY);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoNegativeAnnualIncome() throws AutomationException, HttpRequestException {
        validateResponseForEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfoWithNegativeIncome(),
                ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoCharOccupationId() throws AutomationException, HttpRequestException {
        validateResponseForEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfoWithCharOccId(),
                ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoCharEmployeeMonth() throws AutomationException, HttpRequestException {
        validateResponseForEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfoWithBadEmploymentMonth(),
                ResponseErrorsHelper.EMP_MONTH_INVALID, true);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testEmploymentInfoCharEmployeeYear() throws AutomationException, HttpRequestException {
        validateResponseForEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfoWithBadEmploymentYear(),
                ResponseErrorsHelper.EMP_YEAR_INVALID, true);
    }

    private void validateResponseForEmploymentInfo(EmploymentInfo info, ResponseErrorsHelper expectedError,
                                                   boolean doVerifyAssertions)
            throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withEmploymentInfo(info)
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();

        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, expectedError, doVerifyAssertions);
    }

    private EmploymentInfo buildInfo(String fieldName) {
        if (fieldName.equalsIgnoreCase(EMPLOYMENT_STATUS_ID))
            return new EmploymentInfo.Builder().withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
        if (fieldName.equalsIgnoreCase(EMPLOYMENT_INCOME))
            return new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID).build();
        return TestDataProviderUtil.getValidEmploymentInfo();
    }
}
