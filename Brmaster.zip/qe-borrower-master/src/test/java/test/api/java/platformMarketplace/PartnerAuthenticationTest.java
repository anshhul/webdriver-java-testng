
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.testdata.PartnerAuthenticationInfo;
import com.prosper.automation.parser.MarketplacePartnerCSVParser;
import com.prosper.automation.platform.clients.PlatformMarketplaceImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public final class PartnerAuthenticationTest extends MarketplaceOffersTestBase {
    protected static final Logger LOG = Logger.getLogger(PartnerAuthenticationTest.class.getSimpleName());

    private static final String MARKETPLACE_PARTNER = "MARKETPLACE_PARTNER";

    // TODO: pick from resource loader.
    private static final String MARKETPLACE_PARTNER_CSV_FILE_PATH =
            System.getProperty("user.dir") + "/" + System.getProperty("relative.path.testdata.environment") + "/"
                    + System.getProperty("environment") + "/marketplace_partners.csv";


    @Autowired
    private HttpClientConfig platformServiceConfig;


    private HttpClientConfig buildPlatformServiceConfig(final String oauthClientId, final String oauthClientSecret) {
        return new HttpClientConfig.Builder()
                .withClientConnectionTimeout(String.valueOf(platformServiceConfig.getClientConnectionTimeout()))
                .withClientSocketTimeout(String.valueOf(platformServiceConfig.getClientSocketTimeout()))
                .withScheme(platformServiceConfig.getScheme())
                .withHosts(platformServiceConfig.getHosts())
                .withClientId(oauthClientId)
                .withClientSecret(oauthClientSecret)
                .build();
    }

    @Test(dataProvider = MARKETPLACE_PARTNER)
    public void testPartnerAuthentication(final PartnerAuthenticationInfo partnerAuthenticationInfo)
            throws AutomationException, HttpRequestException {

        LOG.info(partnerAuthenticationInfo);
        final HttpClientConfig httpClientConfig = buildPlatformServiceConfig(
                partnerAuthenticationInfo.getOAuthClientId(),
                partnerAuthenticationInfo.getOAuthClientSecret());

        final IPlatformMarketplace marketplaceService = new PlatformMarketplaceImpl(httpClientConfig);
        Assert.assertNotNull(marketplaceService,
                String.format("Unable to perform OAuth handshake for %s.", partnerAuthenticationInfo));

        final String email = Constant.getGloballyUniqueEmail();
        final GetOfferRequest getOfferRequest =
                buildMarketplaceOfferRequest(ProsperCreditGrade.A, email, partnerAuthenticationInfo.getLegacyId());

        final GetOffersResponse getOffersResponse = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(getOffersResponse);
    }

    @DataProvider(name = MARKETPLACE_PARTNER, parallel = true)
    public Object[][] buildMarketplacePartnerInformationFromCSV() throws AutomationException {
        return MarketplacePartnerCSVParser.parse(MARKETPLACE_PARTNER_CSV_FILE_PATH);
    }
}
