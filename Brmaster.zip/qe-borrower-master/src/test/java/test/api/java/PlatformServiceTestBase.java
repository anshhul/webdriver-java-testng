
package test.api.java;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.prospect.CampaignChannelDAO;
import com.prosper.automation.db.dao.prospect.CampaignDao;
import com.prosper.automation.db.dao.prospect.CampaignProgramDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.campaign.CampaignAndCampaignProgram;
import com.prosper.automation.model.platform.prospect.Campaign;
import com.prosper.automation.model.platform.prospect.CampaignProgram;
import com.prosper.automation.platform.interfaces.IPlatformUser;

import javax.annotation.Resource;

import org.testng.Assert;
import test.api.WebServiceTestBase;

/**
 * @author pbudiono
 */
public abstract class PlatformServiceTestBase extends WebServiceTestBase {

    protected static final String GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID = "1";
    protected static final Double GENERIC_PROSPECT_ANNUAL_INCOME = 150000.0;
    protected static final Double GENERIC_PROSPECT_LOAN_AMOUNT = 10000.0;
    protected static final String GENERIC_PROSPECT_CREDIT_SCORE = "650";
    protected static final Integer GENERIC_PROSPECT_LOAN_PURPOSE_ID = 1;
    protected static final Long GENERIC_PROSPECT_LISTING_CATEGORY_ID = 1L;
    protected static final Long GENERIC_PROSPECT_CREDIT_RANGE_ID = 4L;

    protected static final String NON_GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID = "1";
    protected static final Double NON_GENERIC_PROSPECT_ANNUAL_INCOME = 150000.0;
    protected static final Double NON_GENERIC_PROSPECT_LOAN_AMOUNT = 10000.0;
    protected static final String NON_GENERIC_PROSPECT_CREDIT_SCORE = "650";
    protected static final Integer NON_GENERIC_PROSPECT_LOAN_PURPOSE_ID = 1;
    protected static final Long NON_GENERIC_PROSPECT_LISTING_CATEGORY_ID = 1L;
    protected static final Long NON_GENERIC_PROSPECT_CREDIT_RANGE_ID = 4L;
    @Resource
    protected HttpClientConfig platformPublicServiceConfig;

    @Resource
    protected IPlatformUser pubSiteUserService;

    protected int insertCampaignTestData(Campaign campaign) {
        final CampaignDao campaignDao = prospectDBConnection.getDataAccessObject(CampaignDao.class);
        return campaignDao.insertCampaign(campaign);
    }

    protected int insertCampaignProgramTestData(CampaignProgram campaignProgram) {
        final CampaignProgramDAO campaignProgramDAO = prospectDBConnection.getDataAccessObject(CampaignProgramDAO.class);
        return campaignProgramDAO.insertCampaignProgram(campaignProgram);
    }

    protected String getCampaignChannelId(final String channelName) {
        final CampaignChannelDAO campaignChannelDAO = prospectDBConnection.getDataAccessObject(CampaignChannelDAO.class);
        return campaignChannelDAO.getChannelId(channelName);
    }

    protected CampaignAndCampaignProgram insertCampaignAndProgram(String campaignSourceId, String campaignId, String campaignChannelName,
                                                                  int campaignProgramLegacyId) throws HttpRequestException, AutomationException {
        Campaign campaign = insertCampaignOnly(campaignSourceId, campaignId, campaignChannelName);
        CampaignProgram program = insertCampaignProgramOnly(campaignId, campaignProgramLegacyId, campaignChannelName);
        CampaignAndCampaignProgram cp = new CampaignAndCampaignProgram();
        cp.setCampaign(campaign);
        cp.setCampaignProgram(program);
        return cp;
    }

    protected CampaignProgram insertCampaignProgramOnly(String campaignId, int campaignProgramLegacyId, String campaignChannelName) {
        final String campaignProgramId = Constant.newUuid();
        final String fallBackProgramUsed = Constant.newUuid();

        final com.prosper.automation.model.platform.prospect.CampaignProgram campaignProgram =
                com.prosper.automation.model.platform.prospect.CampaignProgram
                        .createCampaignProgram(campaignProgramId, campaignId, 1, 21, campaignProgramLegacyId, campaignChannelName,
                                fallBackProgramUsed, 1, false);
        Assert.assertEquals(insertCampaignProgramTestData(campaignProgram), 1);
        return campaignProgram;
    }

    protected Campaign insertCampaignOnly(String campaignSourceId, String campaignId, String campaignChannelName) {
        final String campaignChannelId = getCampaignChannelId(campaignChannelName);
        Assert.assertNotNull(campaignChannelId, String.format("Unable to find campaign channel name %s.", campaignChannelName));

        final com.prosper.automation.model.platform.prospect.Campaign campaign =
                com.prosper.automation.model.platform.prospect.Campaign
                        .createCampaign(campaignId, campaignSourceId, campaignChannelId, 1, 1, campaignChannelName, 60);
        Assert.assertEquals(insertCampaignTestData(campaign), 1);
        return campaign;
    }
}
