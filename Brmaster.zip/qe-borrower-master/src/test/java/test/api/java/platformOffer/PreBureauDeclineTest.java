package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.LoansDAO;
import com.prosper.automation.db.dao.StateLendingRegulationsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.tool.BorrowerDataService;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Map;


/**
 * Created by bhirani on 5/8/17.
 */
public class PreBureauDeclineTest extends PlatformOfferTestBase{

    @Resource
    private BorrowerDataService borrowerDataService;

    private static final String[] declineTests = {"WV", "IA", "ME", "ND"};

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testDeclineStates() {
        StateLendingRegulationsDAO dao = circleOneDBConnection.getDataAccessObject(StateLendingRegulationsDAO.class);
        for (String state : declineTests) {
            String flagStatus = dao.getAcceptingNewLoans(state);
            Assert.assertTrue(flagStatus.equalsIgnoreCase("0"), "State should not accept Prosper loans!");
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"USR0008\",\"message\":\"Borrower is less than 18 years old.\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testUserLessThen18Years() throws AutomationException, HttpRequestException, IOException{
        String testUserEmail = Constant.getAAUniqueEmail();
        final Map<String, String> userData = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.DOB_18);
        final BorrowerTestData.Builder borrowerTestDataBuilder = new BorrowerTestData.Builder()
                .withEmail(testUserEmail)
                .withUserData(userData);
        final UserRequest userRequest = borrowerDataService.buildGenericUserRequest(testUserEmail, userData);
        final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);

    }

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"OFF-40\",\"message\":\"ANNUAL_INCOMELESS_THAN_OR_EQUAL_ZERO\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testAnnualIncomeLessThanZero() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        Double income = 0.0;
        UserRequest userRequest = buildGenericUserRequest(testUserEmail, income);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response =
                pubSiteOfferService.getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testMAStateUserForLoanAmount() throws AutomationException, HttpRequestException, IOException{
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.MA_STATE);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-30\",\"message\":\"STATE_AND_LOAN_AMOUNT\"}");
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testActiveLoanDelinquentUser() throws AutomationException, HttpRequestException, IOException{
        LoansDAO loansDAO = circleOneDBConnection.getDataAccessObject(LoansDAO.class);
        String loanID = loansDAO.getLoanID();
        long userID = loansDAO.getBorrowerIDWithLoanID(loanID);
        UserEmailDAO emailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String testUserEmail = emailDAO.getEmailWithUserId(userID);
        HttpRequestException offerResponse = borrowerDataService.priorBorrowerOffer(testUserEmail, userID);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-50\",\"message\":\"ACTIVE_LOAN_IS_DELINQUENT\"}");
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testChargeOffUser() throws AutomationException, HttpRequestException, IOException{
        LoansDAO loansDAO = circleOneDBConnection.getDataAccessObject(LoansDAO.class);
        String loanID = loansDAO.getChargeOffLoanID();
        long userID = loansDAO.getBorrowerIDWithLoanID(loanID);
        UserEmailDAO emailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String testUserEmail = emailDAO.getEmailWithUserId(userID);
        HttpRequestException offerResponse = borrowerDataService.priorBorrowerOffer(testUserEmail, userID);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-45\",\"message\":\"PRIOR_LOAN_CHARGED_OFF\"}");
    }

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"OFF-80\",\"message\":\"ALREADY_TWO_ACTIVE_LOANS\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testTwoActiveLoanUser() throws AutomationException, HttpRequestException, IOException{
        String testUserEmail = "user1301918@prosper.stg";
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService.getUserOffer();
        throw new HttpBadRequestException("{\"code\":\"OFF-80\",\"message\":\"ALREADY_TWO_ACTIVE_LOANS\"}");
    }
}

