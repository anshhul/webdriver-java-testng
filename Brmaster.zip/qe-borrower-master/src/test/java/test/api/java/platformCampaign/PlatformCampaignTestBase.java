package test.api.java.platformCampaign;

import com.prosper.automation.platform.clients.PlatformCampaignImpl;
import test.api.java.PlatformServiceTestBase;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class PlatformCampaignTestBase extends PlatformServiceTestBase {
    @Autowired PlatformCampaignImpl internalCampaignService;
}
