package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationAddressInfoTestCase extends BorrowerTestCase {
    @ProsperZephyr(project = BMP, testTitle = "Test different invalid values of address_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide invalid address_info in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testAddressInfo") void testAddressInfoWithParameters(String street, String city, String state,
                                                                               String zipcode, ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test missing invalid values of address_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide invalid partner source code in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMissingAddressInfo") void testAddressInfoWithMissingParameters(String fieldName,
                                                                                             ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test long zip code in address_info field", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide invalid partner source code in the request"}, expectedResult = "HTTP 200 OK Response without errors")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testValidationSuccessWithValidLongZipNoOffers() throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test without address_info field", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, No address_info in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testValidationSuccessWithNoAddress() throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test zip code without dash, long state name and non-existing street", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers, Provide zip code without dash, long state name and non-existing street in the request"}, expectedResult = "HTTP 200 OK Response without errors")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testValidationSuccessWithValidZipWithoutDashesLongStateNameAndNonExistingStreet() throws AutomationException, HttpRequestException;
}
