package test.api.java.platformMerchant;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.merchant.MerchantType;
import com.prosper.automation.model.platform.merchant.SearchMerchantResponse;

/**
 * Created by pbudiono on 6/6/16.
 */
public final class SearchMerchantTest extends PlatformMerchantTestBase {

	@Test(expectedExceptions = HttpBadRequestException.class, groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY })
	public void testSearchWithLimitEqualToZero() throws AutomationException, HttpRequestException {
		pubSiteMerchantService.searchMerchant(Constant.getGloballyUniqueString(), 0);
	}

	@Test(groups = { TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchWithEmptyString() throws AutomationException, HttpRequestException {
		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(StringConstant.EMPTY,
				DEFAULT_SEARCH_LIMIT);
		Assert.assertEquals(searchMerchantResponses.size(), 0, "Search with empty string should return empty list.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchMerchantWithSpecialCharacter() throws HttpRequestException, AutomationException {
		final String merchantNameWithSpecialCharacters = Constant.getGloballyUniqueStringWithSpecialCharacters();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantNameWithSpecialCharacters, MerchantType.PRD);

		final List<SearchMerchantResponse> response = pubSiteMerchantService.searchMerchant(merchantNameWithSpecialCharacters,
				DEFAULT_SEARCH_LIMIT);
		Assert.assertEquals(response.size(), 1, "Unable to search merchant with special character name.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testCaseInsensitivityInMerchantSearch() throws HttpRequestException, AutomationException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PRD);

		final List<SearchMerchantResponse> lowerCaseResponse = pubSiteMerchantService.searchMerchant(merchantName.toLowerCase(),
				DEFAULT_SEARCH_LIMIT);
		final List<SearchMerchantResponse> upperCaseResponse = pubSiteMerchantService.searchMerchant(merchantName.toUpperCase(),
				DEFAULT_SEARCH_LIMIT);

		Assert.assertEquals(lowerCaseResponse.size(), upperCaseResponse.size(), "Merchant search is case sensitive.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchProviderDirectMerchant() throws AutomationException, HttpRequestException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PRD);

		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(merchantName,
				DEFAULT_SEARCH_LIMIT);

		Assert.assertEquals(searchMerchantResponses.size(), 1, "Search response size does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getMerchantName(), merchantName, "Merchant name does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getThirdPartyID(), thirdPartyId, "Institutional ID does not match.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchPatientDirectWithNoLightStreamIntegration() throws AutomationException, HttpRequestException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PAD_NO_LS);

		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(merchantName,
				DEFAULT_SEARCH_LIMIT);

		Assert.assertEquals(searchMerchantResponses.size(), 1, "Search response size does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getMerchantName(), merchantName, "Merchant name does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getThirdPartyID(), thirdPartyId, "Institutional ID does not match.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchPatientDirectWithLightStreamIntegration() throws AutomationException, HttpRequestException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PAD_LS);

		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(merchantName,
				DEFAULT_SEARCH_LIMIT);

		Assert.assertEquals(searchMerchantResponses.size(), 1, "Search response size does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getMerchantName(), merchantName, "Merchant name does not match.");
		Assert.assertEquals(searchMerchantResponses.get(0).getThirdPartyID(), thirdPartyId, "Institutional ID does not match.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testReturnedSearchResponseAttributes() throws HttpRequestException, AutomationException {
		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PAD_LS);

		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(merchantName,
				DEFAULT_SEARCH_LIMIT);
		Assert.assertEquals(searchMerchantResponses.size(), 1, "Search response size does not match.");

		final SearchMerchantResponse merchant = searchMerchantResponses.get(0);
		Assert.assertEquals(merchant.getMerchantName(), merchantName, "Merchant name does not match.");
		Assert.assertEquals(merchant.getThirdPartyID(), thirdPartyId, "Institutional ID does not match.");
		Assert.assertEquals(merchant.getStateCode(), AddressInfoConstant.RICK_NICK_STATE, "Merchant state code does not match.");
		Assert.assertEquals(merchant.getCity().toLowerCase(), AddressInfoConstant.RICK_NICK_CITY.toLowerCase(),
				"Merchant city does not match.");
		Assert.assertEquals(merchant.getStreetAddress().toLowerCase(), AddressInfoConstant.RICK_NICK_ADDRESS_1.toLowerCase(),
				"Merchant street address does not match.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testReturnedSearchResponseLimit() throws HttpRequestException, AutomationException {

		final String merchantName = Constant.getGloballyUniqueString();
		final List<String> thirdPartyIds = Lists.newArrayList();
		for (int i = 0; i < 3; i++) {

			final String thirdPartyId = Constant.getGloballyUniqueString();
			thirdPartyIds.add(thirdPartyId);

			createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PRD);
		}

		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(merchantName,
				DEFAULT_SEARCH_LIMIT);
		Assert.assertEquals(searchMerchantResponses.size(), DEFAULT_SEARCH_LIMIT,
				"Search limit response size does not match the expected.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testSearchWithPartialString() throws HttpRequestException, AutomationException {

		final String merchantName = Constant.getGloballyUniqueString();
		final String thirdPartyId = Constant.getGloballyUniqueString();

		createMerchant(Constant.getGloballyUniqueEmail(), thirdPartyId, merchantName, MerchantType.PAD_LS);

		final String partialMerchantName = merchantName.substring(0, merchantName.length() - 2);
		final List<SearchMerchantResponse> searchMerchantResponses = pubSiteMerchantService.searchMerchant(partialMerchantName,
				DEFAULT_SEARCH_LIMIT);
		Assert.assertEquals(searchMerchantResponses.size(), 1, "Search response size does not match.");
	}
}
