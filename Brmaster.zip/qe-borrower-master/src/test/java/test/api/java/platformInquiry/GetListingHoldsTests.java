
package test.api.java.platformInquiry;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.inquiry.ListingHoldRequest;
import com.prosper.automation.model.platform.inquiry.ListingHoldResponse;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.platform.interfaces.IPlatformInquiry;
import com.prosper.automation.test.TestBase;
import com.prosper.automation.tool.BorrowerDataService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class GetListingHoldsTests extends TestBase {

	private static final Logger LOG = Logger.getLogger(GetListingHoldsTests.class.getSimpleName());

	private static final String NO_ERROR_RESPONSE = "NONE";

	@Value("${ff.credit.profile.shredding.enabled:true}")
	private Boolean creditProfileShreddingEnabled;

	@Resource
	private IPlatformInquiry pubSiteInquiryService;

	@Resource
	private BorrowerDataService borrowerTestDataService;

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testListingHoldsAppearsAfterProcessing() throws AutomationException, HttpRequestException {

		final String userEmail = Constant.getGloballyUniqueEmail();
		final BorrowerTestData borrowerTestData = borrowerTestDataService.createNewBorrower(userEmail, ProsperCreditGrade.AA);

		LOG.info(borrowerTestData);

		final Long listingId = borrowerTestData.getListingId().get(0);
		final ListingHoldRequest listingHoldRequest = new ListingHoldRequest.Builder().withListingId(listingId).build();

		ListingHoldResponse listingHoldResponse;
		if (creditProfileShreddingEnabled) {
			listingHoldResponse = pubSiteInquiryService.getListingHolds(listingHoldRequest);
		} else {
			pubSiteInquiryService.getListingHolds(listingHoldRequest);
			listingHoldResponse = pubSiteInquiryService.getListingHolds(listingHoldRequest);
		}

		Assert.assertEquals(listingHoldResponse.getListingId(), listingId);
		Assert.assertTrue(listingHoldResponse.getHolds().size() > 0);
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = {TestGroup.NIGHTLY })
	public void testGetListingHoldWithNonExistingListingId() throws AutomationException, HttpRequestException {
		final ListingHoldRequest listingHoldRequest = new ListingHoldRequest.Builder()
				.withListingId(Long.parseLong(String.valueOf(Integer.MAX_VALUE)))
				.build();
		pubSiteInquiryService.getListingHolds(listingHoldRequest);
	}
}
