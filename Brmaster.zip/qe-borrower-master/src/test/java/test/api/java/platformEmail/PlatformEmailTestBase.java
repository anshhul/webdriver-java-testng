
package test.api.java.platformEmail;

import javax.annotation.Resource;

import com.prosper.automation.db.dao.UserEmailDAO;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import test.api.java.PlatformServiceTestBase;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.email.ProsperEmailService;
import com.prosper.automation.email.ProsperEmailServiceConfig;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessage;
import com.prosper.automation.platform.clients.PlatformEmailImpl;
import com.prosper.automation.platform.interfaces.IPlatformEmail;
import com.prosper.automation.tool.BorrowerDataService;
import com.prosper.automation.util.PollingUtilities;

import java.util.UUID;

/**
 * Created by pbudiono on 7/21/16.
 */
public abstract class PlatformEmailTestBase extends PlatformServiceTestBase {

	protected static final String REFERENCE_ID = "F80F6A3E-8085-405A-8355-AF93F022B620";
	protected static final String DEFAULT_FROM_EMAIL = "noreply@prosper.com";
	protected static final String DEFAULT_EMAIL_BODY = "<html><h1>QA BORROWER AUTO TEST</h1></html>";
	protected static final String DEFAULT_EMAIL_TEMPLATE_CODE = "DEFAULT_EMAIL_TEMPLATE_CODE";
	protected static final Integer DEFAULT_LEGACY_TEMPLATE_ID = 1;

	protected static final String PROSPECT_REF_TYPE = "PROSPECT";
	protected static final String USER_REF_TYPE = "USER";
	protected static final String CAMPAIGN_CODE = "PlatformEmailGenericTEST";

	protected IPlatformEmail pubSiteEmailService;

	@Resource
	protected BorrowerDataService borrowerDataService;

	@Resource
	protected ProsperEmailServiceConfig prosperEmailServiceConfig;

	@Value("${email.wait.time:45000}")
	private Integer EMAIL_WAIT_THRESHOLD;

	@Resource
	private HttpClientConfig platformPublicServiceConfig;

	@BeforeClass(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void initializeEmailServiceClient() throws HttpRequestException, AutomationException {
		pubSiteEmailService = new PlatformEmailImpl(platformPublicServiceConfig);
	}

	/*protected void assertEmailIsReceived(final String emailAddress, final String emailSubject) throws AutomationException {
		PollingUtilities.sleep(EMAIL_WAIT_THRESHOLD);

		try (final ProsperEmailService prosperEmailService = new ProsperEmailService(prosperEmailServiceConfig)) {
			Assert.assertNotNull(prosperEmailService.getUniqueEmail(emailAddress, emailSubject));
		}
	} */

	protected String getReferenceID(final String userID) throws AutomationException{
		final UserEmailDAO userEmailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
		final String referenceID = userEmailDAO.getExternaluserID(userID);
		return referenceID;
	}
	protected void assertEmailIsReceived(final String emailAddress, final String emailSubject) throws AutomationException {
		//PollingUtilities.sleep(EMAIL_WAIT_THRESHOLD);

		final UserEmailDAO userEmailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
		final String subject = userEmailDAO.getMessage(emailAddress);
		Assert.assertEquals(subject,emailSubject);
		}


	protected EmailMessage createGenericEmailMessage(String email, String emailSubject) {
		return new EmailMessage.Builder().withReferenceId(REFERENCE_ID).withReferenceType(USER_REF_TYPE)
				.withLegacyTemplateId(DEFAULT_LEGACY_TEMPLATE_ID).withTemplateCode(DEFAULT_EMAIL_TEMPLATE_CODE)
				.withIsShowOnPublicSite(true).withIsSentExternally(true).withToAddress(email).withFromAddress(DEFAULT_FROM_EMAIL)
				.withSubject(emailSubject).withMessage(DEFAULT_EMAIL_BODY).withCampaignCode(CAMPAIGN_CODE).build();
	}

	protected EmailMessage createGenericEmailMessage(String email, String emailSubject, String REFERENCE_ID) {
		return new EmailMessage.Builder().withReferenceId(REFERENCE_ID).withReferenceType(USER_REF_TYPE)
				.withLegacyTemplateId(DEFAULT_LEGACY_TEMPLATE_ID).withTemplateCode(DEFAULT_EMAIL_TEMPLATE_CODE)
				.withIsShowOnPublicSite(true).withIsSentExternally(true).withToAddress(email).withFromAddress(DEFAULT_FROM_EMAIL)
				.withSubject(emailSubject).withMessage(DEFAULT_EMAIL_BODY).withCampaignCode(CAMPAIGN_CODE).build();
	}
}
