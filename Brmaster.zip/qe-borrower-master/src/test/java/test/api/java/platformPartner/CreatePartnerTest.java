
package test.api.java.platformPartner;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.partner.PartnerRequestResponse;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class CreatePartnerTest extends PlatformPartnerTestBase {

    @Test
    public void testCreatePartner() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            Assert.assertEquals(response.getCode(), request.getCode());
            Assert.assertEquals(response.getDescription(), request.getDescription());
            Assert.assertEquals(response.getName(), request.getName());
            Assert.assertNotNull(response.getCreatedDate());
            Assert.assertNotNull(response.getModifiedDate());
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testCreatePartnerDuplicateCode() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            response = internalPartnerService.createPartner(request);
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test
    public void testCreatePartnerMissingDescription() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUpRequest(getReallyRandomString(), "", getReallyRandomString());
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            Assert.assertEquals(response.getCode(), request.getCode());
            Assert.assertEquals(response.getName(), request.getName());
            Assert.assertNotNull(response.getCreatedDate());
            Assert.assertNotNull(response.getModifiedDate());
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testCreatePartnerInvalidRequestMissingName() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUpRequest(getReallyRandomString(), getReallyRandomString(), "");
        internalPartnerService.createPartner(request);
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testCreatePartnerInvalidRequestMissingCode() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUpRequest("", getReallyRandomString(), getReallyRandomString());
        internalPartnerService.createPartner(request);
    }

    @DataProvider(name = "testRequestParams")
    public static Object[][] requestParams() {
        return new Object[][] {{"", "", ""}, {" ", "A", "A"}, {"AB CD", "", ""}, {getLongCode(), "A", "A"}, {"A", "A", getLongName()}, {"A", getLongName(), "A"} };
    }

    @Test(dataProvider = "testRequestParams", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testRequestParams(String code,
                                  String name, String description)
            throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = new PartnerRequestResponse();
        request.setCode(code);
        request.setDescription(description);
        request.setName(name);
        try {
            internalPartnerService.createPartner(request);
            Assert.fail();
        } catch (Exception ex) {
            Assert.assertNotNull(ex.getMessage());
        }
    }

    private static String getLongCode() {
        return RandomStringUtils.random(51, String.valueOf(System.currentTimeMillis()));
    }

    private static String getLongName() {
        return RandomStringUtils.random(256, String.valueOf(System.currentTimeMillis()));
    }
}
