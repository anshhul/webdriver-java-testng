
package test.api.java.platformprospect;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.CampaignSource;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/3/16.
 */
public final class GetPartnerByCampaignSourceIdTest extends AffiliatePartnerTestBase {

    private String campaignSourceId;

    private CampaignSource testCampaignSource;


    @BeforeClass(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void createTestPartner() throws AutomationException, HttpRequestException {
        testCampaignSource = createGenericCampaignSourceRequest(createUniquePartnerName());
        campaignSourceId = internalProspectService.createPartner(testCampaignSource).getCampaignSourceId();
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testGetPartnerByCampaignSourceId() throws AutomationException, HttpRequestException {
        final CampaignSource campaignSourceResponse = internalProspectService.getPartner(campaignSourceId);
        Assert.assertEquals(campaignSourceResponse, testCampaignSource);
    }

    @Test(expectedExceptions = HttpInternalServerErrorException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testGetPartnerByNonExistingCampaignSourceId() throws AutomationException, HttpRequestException {
        internalProspectService.getPartner(NON_EXISTING_CAMPAIGN_SOURCE_ID);
    }
}
