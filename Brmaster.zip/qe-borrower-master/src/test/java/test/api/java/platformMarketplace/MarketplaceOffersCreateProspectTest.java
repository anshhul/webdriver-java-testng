
package test.api.java.platformMarketplace;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.ValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerRequestGetResponse;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.platform.clients.PlatformProspectImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MarketplaceOffersCreateProspectTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * End to end tests for verifying prospect creation on success, partner request table population and application id persistence
 * Created by rsubramanyam on 2/29/16.
 */
public class MarketplaceOffersCreateProspectTest extends MarketplaceOffersTestBase
        implements MarketplaceOffersCreateProspectTestCase {

    @Autowired
    protected PlatformProspectImpl internalProspectService;
    @Autowired
    private IPlatformMarketplace marketplaceService;

    @Override
    @Test(groups = {TestGroup.NIGHTLY})
    public void testCreationOfProspectInDB() throws AutomationException, HttpRequestException {
        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        ContactInfo cinfo = TestDataProviderUtil.getValidContactInfoWithEmailWithPhoneWithAreaCode(emailId);
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfo();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode(), emailId);
        final GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, null);

        // Generate expected output
        ValidationErrorResponse error = buildValidationErrorResponse(ResponseErrorsHelper.NO_MATCHING_OFFERS);
        Prospect expectedProspect = buildExpectedProspect(info, ainfo, cinfo, einfo, pinfo, linfo, null);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, null, error);

        // Make a request
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(response);

        pauseForPartnerRequestTableUpdation();

        // Validate
        UUID prospectId = validateProspectCreation(expectedProspect, emailId);
        validateCreatePartnerRequestLog(emailId, expectedResponse);
        validateApplicationIdInPartnerRequestTable(emailId);
    }

    @Override
    @Test(groups = {TestGroup.NIGHTLY})
    public void testCreationOfProspectInDBWithPartiallyCorrectEmploymentPhone()
            throws AutomationException, HttpRequestException {

        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfoWithNullAreaCode();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode(), emailId);
        BankAccountInfo binfo = null;

        // Make a request
        final GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(response);

        // Pause since create partner request is asynchronous
        pauseForPartnerRequestTableUpdation();

        // Build expected response
        ValidationErrorResponse error = buildValidationErrorResponse(ResponseErrorsHelper.NO_MATCHING_OFFERS);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, binfo, error);
        // Prospect table should have null values since it is invalid
        einfo.setEmployerPhone(null);
        Prospect expectedProspect = buildExpectedProspect(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);

        // Validate
        UUID prospectId = validateProspectCreation(expectedProspect, emailId);
        validateCreatePartnerRequestLog(emailId, expectedResponse);
        validateApplicationIdInPartnerRequestTable(emailId);
    }
}
