package test.api.java.platformTransunion;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.listing.ListingCRMappingDTO;
import com.prosper.automation.model.platform.listing.ListingCreditReportMapping;
import com.prosper.automation.model.platform.transUnion.*;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.model.testdata.TransunionTestData;
import com.prosper.automation.platform.clients.PlatformListingImpl;
import com.prosper.automation.platform.interfaces.IPlatformListing;
import com.prosper.automation.test.restSeeder.TestDataService;
import com.prosper.automation.tool.BorrowerDataService;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Created by rchintapalli on 11/28/16.
 */
public class GetListingCreditReportMappingTest extends PlatformTransunionTestBase {

    private static final Logger LOG = Logger.getLogger(GetListingCreditReportMappingTest.class.getSimpleName());

    @Resource
    private BorrowerDataService borrowerDataService;


    @Test(groups = {TestGroup.SANITY})
    public void getValidListingCreditReportMappingTest() throws AutomationException, HttpRequestException {
        String userEmail = Constant.getGloballyUniqueEmail();
        BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(userEmail, ProsperCreditGrade.NC);
        IPlatformListing listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        Long listingId = borrowerTestData.getListingId().get(0);
        ListingCreditReportMapping listingCreditReportMapping = listingService.getListingCreditReportMapping(listingId);
        Assert.assertNotNull(listingCreditReportMapping);
        List<ListingCRMappingDTO> listingMappingResponse = listingCreditReportMapping.getListingMappingResponse();
        Assert.assertEquals(listingId,listingMappingResponse.get(0).getListingId());
    }

    @Test(groups = {TestGroup.SANITY}, expectedExceptions = HttpNotFoundException.class,expectedExceptionsMessageRegExp = ".*LST1003.*")
    public void getListingCreditReportMappingWithInvalidListingIdTest() throws HttpRequestException, AutomationException {
        String userEmail = Constant.getGloballyUniqueEmail();
        BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(userEmail, ProsperCreditGrade.NC);
        IPlatformListing listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        //get invalid listingId
        Long listingId = 2*borrowerTestData.getListingId().get(0);
        listingService.getListingCreditReportMapping(listingId);
    }

}
