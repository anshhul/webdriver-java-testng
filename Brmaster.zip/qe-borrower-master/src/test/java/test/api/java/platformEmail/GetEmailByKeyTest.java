
package test.api.java.platformEmail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessage;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * Created by pbudiono on 7/22/16.
 */
public final class GetEmailByKeyTest extends PlatformEmailTestBase {

    private static final Integer DEFAULT_EMAIL_SUBJECT_LENGTH = 10;
    private static final String USER_TEST_EMAIL = Constant.getGloballyUniqueEmail();
    private static final String USER_EMAIL_SUBJECT = Constant.getStringWithLength(DEFAULT_EMAIL_SUBJECT_LENGTH);

    private EmailMessage emailMessageRequest;
    private EmailMessage emailMessage;


    @BeforeClass(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void prepareTestData() throws AutomationException, HttpRequestException {
        emailMessageRequest = createGenericEmailMessage(USER_TEST_EMAIL, USER_EMAIL_SUBJECT);
        emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetEmailByValidEmailKey() throws AutomationException, HttpRequestException {
        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse, emailMessageRequest);
    }

    @Test(expectedExceptions = HttpNotFoundException.class, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetEmailByNonExistingEmailKey() throws AutomationException, HttpRequestException {
        pubSiteEmailService.getEmail(UUID.randomUUID());
    }
}
