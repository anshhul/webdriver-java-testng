
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationPersonalInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test with different personal_info field values", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different values for personal_info fields"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testPersonalInfo")
    void testPersonalInfoWithParameters(String fname, String lname, String dob,
                                        ResponseErrorsHelper expectedError)
                                                throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with different values for middle initial ", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different values for middle initial"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMiddleInitial")
    void testMiddleInitialWithParameters(String fname, String lname, String dob,
                                         String middleinitial,
                                         ResponseErrorsHelper expectedError)
                                                 throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with different values for SSN information", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different values for SSN"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testSSNInfo")
    void testSSNInfoWithParameters(String fname, String lname, String dob, String ssn,
                                   ResponseErrorsHelper expectedError)
                                           throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing personal_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Skip personal_info fields"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMissingPersonalInfo")
    void testPersonalInfoWithMissingParameters(String fieldName,
                                               ResponseErrorsHelper expectedError)
                                                       throws AutomationException, HttpRequestException;
}
