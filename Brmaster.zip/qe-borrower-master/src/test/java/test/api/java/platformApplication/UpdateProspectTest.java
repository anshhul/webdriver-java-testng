package test.api.java.platformApplication;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PersonalInfoConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

/**
 * A test class for /prospect/:prospectId endpoint.
 *
 * @author Peter Budiono, rsubramanyam
 * @since 0.0.1
 */
public final class UpdateProspectTest extends PlatformApplicationTestBase {

    private String prospectTestEmail;

    private ProspectRequest testProspectRequest;

    private String testProspectId;

    /**
     * Creates new prospect data.
     *
     * @throws AutomationException
     * @throws HttpRequestException
     */
    @BeforeMethod public void createNewProspect() throws AutomationException, HttpRequestException {
        prospectTestEmail = Constant.getGloballyUniqueEmail();

        final ProspectRequest prospectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, prospectTestEmail);
        final ProspectResponse testProspectResponse = platformApplicationService.createProspect(prospectRequest);
        Assert.assertNotNull(testProspectResponse);

        testProspectId = testProspectResponse.getProspect().getOfferCode();
        testProspectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeAllUserFields()
            throws AutomationException, HttpRequestException {
        ProspectRequest genericTestProspectRequest =
                buildNonGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        ProspectRequest nonGenericTestProspectRequest =
                buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        final ProspectResponse createProspectResponse = platformApplicationService.createProspect(genericTestProspectRequest);
        final ProspectResponse updateProspectWithTypeResponse = platformApplicationService
                .updateProspectWithType(createProspectResponse.getProspect().getOfferCode(), nonGenericTestProspectRequest);
        compareUserRelatedInformation(updateProspectWithTypeResponse, nonGenericTestProspectRequest);
    }

    private void compareUserRelatedInformation(ProspectResponse response, ProspectRequest expectedRequest) {
        Assert.assertEquals(response.getProspect().getAddressInfo(), expectedRequest.getProspect().getAddressInfo());
        Assert.assertEquals(response.getProspect().getContactInfo(), expectedRequest.getProspect().getContactInfo());
        Assert.assertEquals(response.getProspect().getBankAccountInfo(), expectedRequest.getProspect().getBankAccountInfo());
        Assert.assertEquals(response.getProspect().getPersonalInfo(), expectedRequest.getProspect().getPersonalInfo());
        Assert.assertEquals(response.getProspect().getEmploymentInfo(), expectedRequest.getProspect().getEmploymentInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeFirstNameWithLeftPaddedSpecialCharacter()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeFirstNameWithRightPaddedSpecialCharacter()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeWithSpecialCharacterInTheMiddleOfFirstName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeFirstNameWithLeftPaddedBlankSpace()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeFirstNameWithRightPaddedBlankSpace()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithBlankSpaceInTheMiddleOfFirstName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
        platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithLeftPaddedDashOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.DASH_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithRightPaddedDashOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.DASH_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithDashInTheMiddleOfLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.DASH_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithLeftPaddedBlankSpaceOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithRightPaddedBlankSpaceOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithBlankSpaceInTheMiddleOfLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testUpdateProspectWithTypeWithNullPhoneTypeId()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBER_WITHOUT_TYPE_IDS);

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, enabled = false, description = "https://jira.prosper.com/browse/BOR-2745") public void testUpdateProspectWithTypePhoneNumber()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().getContactInfo()
                .setPhoneNumber(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS);

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);

        final List<PhoneNumber> actualPhoneNumbers = prospectResponse.getProspect().getContactInfo().getPhoneNumbers();
        final List<PhoneNumber> expectedPhoneNumbers = testProspectRequest.getProspect().getContactInfo().getPhoneNumbers();

        // assert number of phone numbers correctness
        Assert.assertEquals(actualPhoneNumbers.size(), expectedPhoneNumbers.size());
        // assert phone numbers are equal
        Assert.assertEquals(actualPhoneNumbers, expectedPhoneNumbers);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, enabled = false, description = "https://jira.prosper.com/browse/BOR-2745") public void testUpdateProspectWithTypeEmployerPhoneNumber()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().getEmploymentInfo().setEmployerPhone(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1);

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);

        final PhoneNumber actualPhoneNumber = prospectResponse.getProspect().getEmploymentInfo().getEmployerPhone();
        final PhoneNumber expectedPhoneNumber = testProspectRequest.getProspect().getEmploymentInfo().getEmployerPhone();
        Assert.assertEquals(actualPhoneNumber, expectedPhoneNumber);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeWithLeftPaddedSpecialCharacterOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeWithRightPaddedSpecialCharacterOnLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008) public void testUpdateProspectWithTypeWithSpecialCharacterInTheMiddleOfLastName()
            throws AutomationException, HttpRequestException {
        testProspectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

        final ProspectResponse prospectResponse = platformApplicationService.updateProspectWithType(testProspectId, testProspectRequest);
        Assert.assertNotNull(prospectResponse);
    }
}
