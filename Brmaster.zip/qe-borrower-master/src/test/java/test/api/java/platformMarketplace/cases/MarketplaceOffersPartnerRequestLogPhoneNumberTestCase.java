package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MarketplaceOffersPartnerRequestLogPhoneNumberTestCase extends BorrowerTestCase {
    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log with invalid home phone", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers"}, expectedResult = "Partner request table populated correctly with invalid data")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testPartnerRequestLogForInvalidHomePhoneNumber() throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log with invalid mobile phone", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers"}, expectedResult = "Partner request table populated correctly with invalid data")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testPartnerRequestLogForInvalidMobilePhone() throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log with invalid work phone", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers"}, expectedResult = "Partner request table populated correctly with invalid data")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testPartnerRequestLogForInvalidWorkPhone() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log with missing phone number", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers"}, expectedResult = "Partner request table populated correctly with invalid data")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testInvalidEmploymentPhoneMissingNumber() throws AutomationException, HttpRequestException;
    @ProsperZephyr(project = BMP, testTitle = "Test create partner request log with invalid employment phone number", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/application/offers"}, expectedResult = "Partner request table populated correctly with invalid data")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testInvalidEmploymentPhone() throws AutomationException, HttpRequestException;
}
