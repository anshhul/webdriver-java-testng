
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationPersonalInfoTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Calendar;

/**
 * Negative tests for Personal info Created by rsubramanyam on 2/20/16.
 */
public class MktplaceOfferRequestValidationPersonalInfoTest extends MarketplaceOffersTestBase implements
        MktplaceOfferRequestValidationPersonalInfoTestCase {

    private static final String FNAME_IDENTIFIER = "firstName";
    private static final String LNAME_IDENTIFIER = "lastName";
    private static final String DOB_IDENTIFIER = "dob";
    @Autowired
    private IPlatformMarketplace marketplaceService;


    @DataProvider(name = "testPersonalInfo")
    public static Object[][] personalInfoTest() {
        int year = Calendar.getInstance().get(Calendar.YEAR);
        String fiveYearsBack = String.valueOf(year - 5);
        return new Object[][] {
                // Invalid first name
                {"1Albert", "Hopkins", "01/01/1998", ResponseErrorsHelper.FIRST_NAME_INVALID},
                // Invalid last name
                {"Albert", "1Hopkins", "01/01/1998", ResponseErrorsHelper.LAST_NAME_INVALID},
                // Invalid dates --?
                {"Albert", "Hopkins", "01/01///1998", ResponseErrorsHelper.DOB_INVALID},
                {"Albert", "Hopkins", "01/45/1998", ResponseErrorsHelper.DOB_INVALID},
                {"Albert", "Hopkins", "21/21/1997", ResponseErrorsHelper.DOB_INVALID},
                {"Albert", "Hopkins", "02/30/1996", ResponseErrorsHelper.DOB_INVALID},
                {"Albert", "Hopkins", "01/30/A996", ResponseErrorsHelper.DOB_INVALID},
                // Less than 18 years old
                {"Albert", "Hopkins", "01/01/" + fiveYearsBack, ResponseErrorsHelper.INVALID_AGE_REQUIREMENT},
                // More than 100 years old
                {"Albert", "Hopkins", "01/01/1800", ResponseErrorsHelper.INVALID_AGE_REQUIREMENT},
                // Future date
                {"Albert", "Hopkins", "01/01/2200", ResponseErrorsHelper.INVALID_AGE_REQUIREMENT},
                // Null first name
                {null, "Hopkins", "01/01/1990", ResponseErrorsHelper.FIRST_NAME_NULL_EMPTY},
                // Null last name
                {"Albert", null, "01/01/1990", ResponseErrorsHelper.LAST_NAME_NULL_EMPTY},
                // Null DOB
                {"Albert", "Hopkins", null, ResponseErrorsHelper.DOB_NULL_EMPTY},
                // Empty first name
                {"", "Hopkins", "01/01/1998", ResponseErrorsHelper.FIRST_NAME_NULL_EMPTY},
                // Empty last name
                {"Albert", "", "01/01/1998", ResponseErrorsHelper.LAST_NAME_NULL_EMPTY},
                // Empty dateofBirth
                {"Albert", "Hopkins", "", ResponseErrorsHelper.DOB_NULL_EMPTY},};
    }

    @DataProvider(name = "testMiddleInitial")
    public static Object[][] middleInitialTest() {
        return new Object[][] {
                // Invalid middle initial
                {"Albert", "Hopkins", "01/01/1998", "H?", ResponseErrorsHelper.MIDDLE_INITIAL_INVALID},};
    }

    @DataProvider(name = "testSSNInfo")
    public static Object[][] ssnInfoTest() {
        int year = Calendar.getInstance().get(Calendar.YEAR);
        String FiveYearsBack = String.valueOf(year - 5);
        return new Object[][] {
                // Invalid ssn length based same length
                {"Albert", "Hopkins", "01/01/1998", "123456789PA", ResponseErrorsHelper.SSN_INVALID},
                // Invalid ssn length based 1 extra char
                {"Albert", "Hopkins", "01/01/1998", "12345678910W", ResponseErrorsHelper.SSN_INVALID},
                // Invalid ssn
                {"Albert", "Hopkins", "01/01/1998", "12335637891", ResponseErrorsHelper.SSN_INVALID},
                // Invalid ssn
                {"Albert", "Hopkins", "01/01/1998", "123/56/7891", ResponseErrorsHelper.SSN_INVALID},

        };
    }

    @DataProvider(name = "testMissingPersonalInfo")
    public static Object[][] personalInfoMissingTest() {
        return new Object[][] {
                // Missing first name
                {"firstName", ResponseErrorsHelper.FIRST_NAME_NULL_EMPTY},
                // Missing last name
                {"lastName", ResponseErrorsHelper.LAST_NAME_NULL_EMPTY},
                // Missing date of birth
                {"dob", ResponseErrorsHelper.DOB_NULL_EMPTY},};
    }

    @Override
    @Test(dataProvider = "testPersonalInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testPersonalInfoWithParameters(String fname, String lname,
                                               String dob,
                                               ResponseErrorsHelper expectedError)
                                                       throws AutomationException, HttpRequestException {
        PersonalInfo info = new PersonalInfo.Builder().withFirstName(fname).withLastName(lname).withDateOfBirth(dob).build();

        validateResponseForPersonalInfo(info, expectedError);
    }

    @Override
    @Test(dataProvider = "testMiddleInitial", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testMiddleInitialWithParameters(String fname, String lname,
                                                String dob,
                                                String middleinitial,
                                                ResponseErrorsHelper expectedError)
                                                        throws AutomationException, HttpRequestException {
        boolean foundException = false;
        PersonalInfo info = new PersonalInfo.Builder().withFirstName(fname).withLastName(lname).withDateOfBirth(dob)
                .withMiddleInitial(middleinitial).build();

        validateResponseForPersonalInfo(info, expectedError);
    }

    @Override
    @Test(dataProvider = "testSSNInfo", groups = {
            TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSSNInfoWithParameters(String fname, String lname, String dob,
                                          String ssn,
                                          ResponseErrorsHelper expectedError)
                                                  throws AutomationException, HttpRequestException {
        PersonalInfo info =
                new PersonalInfo.Builder().withFirstName(fname).withLastName(lname).withDateOfBirth(dob).withSsn(ssn).build();

        validateResponseForPersonalInfo(info, expectedError);
    }

    @Override
    @Test(dataProvider = "testMissingPersonalInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testPersonalInfoWithMissingParameters(String fieldName,
                                                      ResponseErrorsHelper expectedError)
                                                              throws AutomationException, HttpRequestException {
        PersonalInfo info = buildInfo(fieldName);
        validateResponseForPersonalInfo(info, expectedError);
    }

    private void validateResponseForPersonalInfo(PersonalInfo info, ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).withPersonalInfo(info).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, expectedError);
    }

    private PersonalInfo buildInfo(String fieldName) {
        PersonalInfo info = new PersonalInfo.Builder().build();
        if (!fieldName.equalsIgnoreCase(FNAME_IDENTIFIER))
            info.setFirstName(Constant.TEST_FIRST_NAME);
        if (!fieldName.equalsIgnoreCase(LNAME_IDENTIFIER))
            info.setLastName(Constant.TEST_LAST_NAME);
        if (!fieldName.equalsIgnoreCase(DOB_IDENTIFIER))
            info.setDateOfBirth(Constant.TEST_DATE_OF_BIRTH);
        return info;
    }
}
