
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.StatesSupported;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.offers.LoanOfferDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.enumeration.platform.UserSourceSystem;
import com.prosper.automation.enumeration.platform.UserType;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.clients.PlatformUserImpl;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by rsubramanyam on 7/1/16.
 */
public class SaveOffersUserTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;
    LoanOfferDAO loanOfferDao;


    @BeforeMethod(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void createNewBorrowerData() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
        loanOfferDao = circleOneDBConnection.getDataAccessObject(LoanOfferDAO.class);
    }

    @DataProvider(name = "differentOffers")
    public static Object[][] differentOfferParams() {
        return new Object[][] { {null}, {new Offer()}};
    }

    @Test(dataProvider = "differentOffers", expectedExceptions = HttpBadRequestException.class,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveInvalidOfferBorrowerOffers(Offer offer) throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        if(offer != null)
            offer.setProspectId(testUserId.toString());
        pubSiteOfferService.saveUserOffers(offer);
    }

    @DataProvider(name = "differentUsers")
    public static Object[][] differentUsersParams() {
        return new Object[][] { {0L}, {111L}};
    }

    @Test(dataProvider = "differentUsers", expectedExceptions = HttpBadRequestException.class,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveInvalidUserBorrowerOffers(Long userId) throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Offer offerWithExternalOfferId = new Offer();
        offerWithExternalOfferId.setExternalLoanOfferId("1");
        offerWithExternalOfferId.setUserId(testUserId);
        pubSiteOfferService.saveUserOffers(offerWithExternalOfferId);
    }

    @Test(expectedExceptions = HttpBadRequestException.class ,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveWithoutLoanOfferScoreIdBorrowerOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
        new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.saveUserOffers(new Offer());
    }

    @Test(expectedExceptions = HttpBadRequestException.class,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveNullLoanOfferScoreIdBorrowerOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.saveUserOffers(null);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 10);
        testSaveCachedBorrowerOffers(response, testUserId, pubSiteOfferService);
        testSavePersistedBorrowerOffers(response, testUserId, pubSiteOfferService);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersMaxLoanCap() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, 25000, Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 10);
        testSaveCachedBorrowerOffers(response, testUserId, pubSiteOfferService);
        testSavePersistedBorrowerOffers(response, testUserId, pubSiteOfferService);
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersUser2Offers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail, ExperianUserInformation.getByProsperCreditGrade(
                ProsperCreditGrade.AA));
        userRequest.getUserEmploymentInfo().setAnnualIncome(18000.00);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, 4);
        validateDbStoredOffersInCircleOne(responseWithoutShowAll, 2);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, 4, true);
        validateSameOffersWithShowAll(response, responseWithoutShowAll);
        validateDbStoredOffersInCircleOne(response, 4);
        pubSiteOfferService.saveUserOffers(response.getListedOffers().getOffers().get(0));
        validateDbStoredOffersInCircleOne(response, 4);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersForMilitaryStateUser() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail, ExperianUserInformation.getByState(StatesSupported.MILITARY_STATE));
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 10);
        testSaveCachedBorrowerOffers(response, testUserId, pubSiteOfferService);
        testSavePersistedBorrowerOffers(response, testUserId, pubSiteOfferService);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersMatchCached() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        Offer[] offer = getPersistedOffers(response, testUserId.toString(), 11);
        List<Offer> offersList = new ArrayList<Offer>(Arrays.asList(offer));
        offersList.remove(null);
        Assert.assertEquals(offersList.size(), 10);;
    }

    private void testSaveCachedBorrowerOffers(OffersResponse response, Long testUserId, PlatformOfferImpl pubSiteOfferService)
            throws AutomationException, HttpRequestException {
        Offer[] offer = getCachedOffers(response, testUserId.toString(), 2);
        offer[0].setUserId(testUserId);
        Offer saved = pubSiteOfferService.saveUserOffers(offer[0]);
        assertEquals(saved, offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInCircleOne(response, 11);
        saved = pubSiteOfferService.saveUserOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInCircleOne(response, 11);
        offer[1].setUserId(testUserId);
        pubSiteOfferService.saveUserOffers(offer[1]);
        validateDbStoredOffersInCircleOne(response, 12);
    }

    private void testSavePersistedBorrowerOffers(OffersResponse response, Long testUserId, PlatformOfferImpl pubSiteOfferService)
            throws AutomationException, HttpRequestException {
        Offer[] offer = getPersistedOffers(response, testUserId.toString(), 2);
        offer[0].setUserId(testUserId);
        Offer saved = pubSiteOfferService.saveUserOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInCircleOne(response, 12);
        saved = pubSiteOfferService.saveUserOffers(offer[0]);
        Assert.assertNotNull(saved.getLoanOfferId());
        validateDbStoredOffersInCircleOne(response, 12);
        offer[1].setUserId(testUserId);
        pubSiteOfferService.saveUserOffers(offer[1]);
        validateDbStoredOffersInCircleOne(response, 12);
    }

    @Test(expectedExceptions = HttpBadRequestException.class,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveInvalidLoanOffer()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 10);

        Offer[] offer = getCachedOffers(response, testUserId.toString(), 1);
        offer[0].setLoanOfferScoreId(null);
        offer[0].setExternalLoanOfferId(null);
        offer[0].setUserId(testUserId);
        pubSiteOfferService.saveUserOffers(offer[0]);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_20,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerOffersAfterExpiry() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserRequest userRequestChangedIncome = buildGenericUserRequest(testUserEmail, Constant.TEST_ANNUAL_INCOME - 1);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);

        // Request offers
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 10);

        // Get cached offer
        Offer[] offer = getCachedOffers(response, testUserId.toString(), 1);

        // Update user income
        userRequestChangedIncome.getUserEmploymentInfo().setAnnualIncome(Constant.TEST_ANNUAL_INCOME - 1);
        PlatformUserImpl userService = new PlatformUserImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        userService.updateUser(userRequestChangedIncome);

        // Request offers
        pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, false);
        offer[0].setUserId(testUserId);
        Offer offerFromSave = pubSiteOfferService.saveUserOffers(offer[0]);
        Assert.assertEquals(offerFromSave, offer[0]);
    }

    @DataProvider(name = "differentUserSourceSystems")
    public static Object[][] getUserSourceSystems() {
        return new Object[][] { {UserSourceSystem.APP_BY_PHONE}, {UserSourceSystem.PUBLIC_SITE},
                {UserSourceSystem.PARTNER_REFERRAL}};
    }

    @Test(dataProvider = "differentUserSourceSystems" ,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveUserOffersDifferentSourceSystems(UserSourceSystem system) throws AutomationException,
            HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long userId = testUserResponse.getUserRequest().getUserId();
        final OffersResponse responseWithShowAll =
                pubSiteOfferService
                        .getUserOffers(userId, Constant.GENERIC_LOAN_AMOUNT,
                                Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                                Constant.GENERIC_CREDIT_RANGE_ID, true,
                                UserType.USER, system);
        responseWithShowAll.getListedOffers().getOffers().get(0).setUserId(userId);
        Offer offer = pubSiteOfferService.saveUserOffers(responseWithShowAll.getListedOffers().getOffers().get(0));
        Assert.assertNotNull(offer);
    }

    @Test(expectedExceptions = HttpNotFoundException.class ,groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSaveBorrowerInvalidType() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);

        // Request offers
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        response.getListedOffers().getOffers().get(0).setUserId(testUserId);
        pubSiteOfferService.saveUserOffers(response.getListedOffers().getOffers().get(0), UserType.PROSPECT,
                UserSourceSystem.PARTNER_REFERRAL);
    }

    private Offer[] getPersistedOffers(OffersResponse response, String testUserId, int numberOfOffers) {
        return getOffers(response, numberOfOffers, testUserId, true);
    }

    private Offer[] getCachedOffers(OffersResponse response, String testUserId, int numberOfOffers) {
        return getOffers(response, numberOfOffers, testUserId, false);
    }

    private Offer[] getOffers(OffersResponse response, int numberOfOffers, String testUserId, boolean persisted) {
        Offer[] offers = new Offer[numberOfOffers];
        int count = 0;
        List<Integer> loanAmounts = loanOfferDao.getLoanAmountPersisted(testUserId);
        for (Offer offer : response.getListedOffers().getOffers()) {
            if (count == numberOfOffers) {
                break;
            }
            boolean found = false;
            for (Integer amount : loanAmounts) {
                if (offer.getLoanAmount().intValue() == amount.intValue()) {
                    found = true;
                    break;
                }
            }
            if (!found && !persisted) {
                offers[count++] = offer;
            } else if ((!found && persisted) || (found && !persisted)) {
                continue;
            } else {
                int countOfPersistedOffers = loanOfferDao.isOfferPersisted(offer.getLoanAmount(), offer.getApr() / 100, offer.getLoanOfferScoreId(), testUserId);
                if (persisted && countOfPersistedOffers > 0) {
                    offers[count++] = offer;
                }
            }
        }
        return offers;
    }

}




