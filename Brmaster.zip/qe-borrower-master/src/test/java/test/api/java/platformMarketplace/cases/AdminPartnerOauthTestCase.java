
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/16/16.
 */
public interface AdminPartnerOauthTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for a new campaign source", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/admin/partneroauth"}, expectedResult = "Partner oauth credentials created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testGetPartnerOauthBasicTest() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test is_upsert=false for create partner oauth for a new campaign source", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/admin/partneroauth"}, expectedResult = "Partner oauth credentials not created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) void testGetPartnerOauthTestWithUpsertFalse()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for the same campaign source twice", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/admin/partneroauth"}, expectedResult = "Partner oauth credentials created just once and used again")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testGetPartnerOauthTwiceForSameCampaignSource() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for the existing campaign data", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/admin/partneroauth"}, expectedResult = "Partner oauth credentials created once using the existing campaign data")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testGetPartnerOauthForExistingCampaignData() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for existing campaign", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
            "[POST] /marketplace/admin/partneroauth"}, expectedResult = "New partner oauth credentials, new campaign program created for the same campaign")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) void testGetPartnerOauthForExistingCampaignOnlyData()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for invalid campaign source id", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/admin/partneroauth"}, expectedResult = "Internal Server Error")
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpInternalServerErrorException.class, expectedExceptionsMessageRegExp = ".*1015.*Internal system error.*")
    void testGetPartnerOauthForInvalidCampaignSource() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for non-existing campaign source id", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/admin/partneroauth"}, expectedResult = "HttpBadRequestException")
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ".*10002.*campaignSourceId is invalid/doesn't exist.*")
    void testGetPartnerOauthForNonExistingCampaignSource() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create partner oauth for a missing campaign source id", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/admin/partneroauth"}, expectedResult = "HttpBadRequestException")
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ".*10001.*campaignSourceId is required.*")
    void testGetPartnerOauthForEmptyCampaignSource()
            throws AutomationException, HttpRequestException;
}
