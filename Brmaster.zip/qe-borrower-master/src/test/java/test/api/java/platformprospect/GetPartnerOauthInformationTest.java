
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import test.api.java.platformprospect.cases.GetPartnerOauthInformationTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;

/**
 * @author pbudiono
 */
public final class GetPartnerOauthInformationTest extends PlatformProspectTestBase implements GetPartnerOauthInformationTestCase {

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetPartnerOAuthInformationHappyPath() throws HttpRequestException, AutomationException {
        final PartnerOauthInfo newlyCreatedPartnerOauthInfo = addPartnerOauthInfo();

        final PartnerOauthInfo partnerOauthInfo = internalProspectService
                .getPartnerOauthInfoById(String.valueOf(newlyCreatedPartnerOauthInfo.getPartnerOauthId()));

        Assert.assertEquals(partnerOauthInfo, newlyCreatedPartnerOauthInfo);

        final HashMap<String, String> mapOfSourceAndId = new HashMap<>();
        mapOfSourceAndId.put("campaign_source_id", newlyCreatedPartnerOauthInfo.getCampaignSourceId());
        final PartnerOauthInfo partnerOauthInfoResponse =
                internalProspectService.getPartnerOauthInfo(mapOfSourceAndId);
        Assert.assertEquals(partnerOauthInfoResponse, partnerOauthInfo);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewPartnerOAuthInformationAfterSoftDelete() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();
        internalProspectService.softDeletePartnerOAuth(partnerOauthInfo.getPartnerOauthId());

        final String newClientId = Constant.newUuid();
        final PartnerOauthInfo request = new PartnerOauthInfo.Builder().withExternalClientId(newClientId)
                .withCampaignSourceId(partnerOauthInfo.getCampaignSourceId()).build();
        internalProspectService.addPartnerOAuth(request);
        final HashMap<String, String> mapOfSourceAndId = new HashMap<>();
        mapOfSourceAndId.put("external_client_id", request.getExternalClientId());
        final PartnerOauthInfo partnerOauthInfoResponse =
                internalProspectService.getPartnerOauthInfo(mapOfSourceAndId);
        Assert.assertEquals(partnerOauthInfoResponse.getExternalClientId(), newClientId);
    }

    @Test(expectedExceptions = Exception.class, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOAuthInformationWithEmptyClientID() throws AutomationException, HttpRequestException {
        final HashMap<String, String> mapOfSourceAndId = new HashMap<>();
        mapOfSourceAndId.put("external_client_id", "");
        internalProspectService.getPartnerOauthInfo(mapOfSourceAndId);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetPartnerOAuthInformationWithNonExistingClientID() throws AutomationException, HttpRequestException {
        final HashMap<String, String> mapOfSourceAndId = new HashMap<>();
        mapOfSourceAndId.put("external_client_id", Constant.newUuid());
        Assert.assertNull(internalProspectService.getPartnerOauthInfo(mapOfSourceAndId));
    }
}
