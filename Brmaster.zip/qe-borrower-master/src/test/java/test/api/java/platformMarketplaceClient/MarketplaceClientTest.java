
package test.api.java.platformMarketplaceClient;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformSecurity;
import test.api.java.platformMarketplace.MarketplaceOffersTestBase;
import test.api.java.platformMarketplaceClient.cases.MarketplaceClientTestCase;
import com.prosper.marketplace.client.model.OffersRequestVO;
import com.prosper.marketplace.client.model.OffersResponseVO;
import com.prosper.marketplace.client.model.core.ContactInfo;
import com.prosper.marketplace.client.model.core.EmploymentInfo;
import com.prosper.marketplace.client.model.core.Identification;
import com.prosper.marketplace.client.model.core.LoanInfo;
import com.prosper.marketplace.client.model.core.PersonalInfo;
import com.prosper.marketplace.client.service.MarketplaceService;
import com.prosper.marketplace.client.service.impl.OAuthServiceImpl;

import javax.ws.rs.NotAuthorizedException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/11/16.
 */
public class MarketplaceClientTest extends MarketplaceOffersTestBase implements MarketplaceClientTestCase {

    private final String SEPARATOR = "://";
    @Autowired
    protected HttpClientConfig platformMarketplaceServiceConfig;
    @Autowired
    protected HttpClientConfig platformInternalServiceConfig;
    ApplicationContext context;
    private OAuthServiceImpl oAuthService;
    private MarketplaceService marketplaceService;

    public MarketplaceClientTest() {
        context = new ClassPathXmlApplicationContext("classpath:spring/marketplace-restclient-beans.xml");
        marketplaceService = (MarketplaceService) context.getBean("marketplaceService");
        oAuthService = (OAuthServiceImpl) context.getBean("oAuthService");
    }

    @Override
    @Test
    public void testMarketplaceServiceUsingClient() {
        OffersResponseVO response = marketplaceService.getLoanOffers(buildErrorRequest(true));
        Assert.assertNotNull(response);
        // Exercise the part where token previously created is used.
        response = marketplaceService.getLoanOffers(buildValidRequest());
        Assert.assertNotNull(response);
    }

    @Override
    @Test(expectedExceptions = NotAuthorizedException.class)
    public void testMarketplaceServiceUsingClientForUnauthorizedException() throws NotAuthorizedException {
        marketplaceService.getLoanOffers(buildErrorRequest(false));
    }

    @Override
    @Test
    public void testOauthServiceUsingClient() {
        String endpoint = platformInternalServiceConfig.getScheme() + SEPARATOR
                + platformInternalServiceConfig.getHost(IPlatformSecurity.SERVICE_NAME);
        Assert.assertNotNull(oAuthService.getClientTokenValue());
        Assert.assertNotNull(oAuthService.getClientTokenValue(endpoint, platformInternalServiceConfig.getClientId(),
                platformInternalServiceConfig.getClientSecret()));
    }

    private OffersRequestVO buildValidRequest() {
        OffersRequestVO request = new OffersRequestVO();

        request.setIdentification(new Identification());
        request.setLoanInfo(new LoanInfo());
        request.setEmploymentInfo(new EmploymentInfo());
        request.setContactInfo(new ContactInfo());
        PersonalInfo info = new PersonalInfo();
        info.setDateOfBirth(Constant.TEST_DATE_OF_BIRTH);
        request.setPersonalInfo(info);
        request.setAddressInfo(new com.prosper.marketplace.client.model.core.AddressInfo());

        request.getIdentification().setPartnerSourceCode(String.valueOf(getPartnerCode()));
        request.getLoanInfo().setLoanAmount(Constant.GENERIC_LOAN_AMOUNT);
        request.getLoanInfo().setLoanPurposeId((int) (Constant.GENERIC_LOAN_PURPOSE_ID));
        request.getLoanInfo().setSelfReportedCreditScore(Integer.parseInt(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE));
        request.getEmploymentInfo().setEmploymentStatusId(Integer.parseInt(Constant.TEST_EMPLOYMENT_STATUS_ID));
        request.getEmploymentInfo().setAnnualIncome(Constant.TEST_ANNUAL_INCOME);

        request.getContactInfo().setEmailAddress(Constant.getGloballyUniqueEmail(false));
        request.getPersonalInfo().setFirstName(TestDataProviderUtil.TEST_DATA_NON_MARY_FNAME);
        request.getPersonalInfo().setLastName(TestDataProviderUtil.TEST_DATA_NON_MARY_LNAME);

        request.getAddressInfo().setStreet(TestDataProviderUtil.TEST_DATA_MD_STREET);
        request.getAddressInfo().setCity(TestDataProviderUtil.TEST_DATA_MD_CITY);
        request.getAddressInfo().setState(TestDataProviderUtil.TEST_DATA_MD_STATE);
        request.getAddressInfo().setZipCode(TestDataProviderUtil.TEST_DATA_MD_ZIP);
        return request;
    }

    private OffersRequestVO buildErrorRequest(boolean includePartnerCode) {
        OffersRequestVO request = new OffersRequestVO();

        request.setIdentification(new Identification());
        request.setLoanInfo(new LoanInfo());
        request.setEmploymentInfo(new EmploymentInfo());
        request.setContactInfo(new ContactInfo());
        PersonalInfo info = new PersonalInfo();
        info.setDateOfBirth(Constant.TEST_DATE_OF_BIRTH);
        request.setPersonalInfo(info);
        request.setAddressInfo(new com.prosper.marketplace.client.model.core.AddressInfo());

        request.getIdentification().setPartnerSourceCode(includePartnerCode ? String.valueOf(getPartnerCode()) : "");
        request.getLoanInfo().setLoanAmount(Constant.GENERIC_LOAN_AMOUNT);
        request.getLoanInfo().setLoanPurposeId((int) (Constant.GENERIC_LOAN_PURPOSE_ID));
        request.getLoanInfo().setSelfReportedCreditScore(Constant.TEST_CREDIT_GRADE);
        request.getEmploymentInfo().setEmploymentStatusId(Integer.parseInt(Constant.TEST_EMPLOYMENT_STATUS_ID));
        request.getEmploymentInfo().setAnnualIncome(Constant.TEST_ANNUAL_INCOME);

        request.getContactInfo().setEmailAddress("");
        request.getPersonalInfo().setFirstName("");
        request.getPersonalInfo().setLastName("");
        request.getPersonalInfo().setMiddleInitial("");

        request.getAddressInfo().setStreet("");
        request.getAddressInfo().setCity("");
        request.getAddressInfo().setState("");
        request.getAddressInfo().setZipCode("");
        return request;
    }
}
