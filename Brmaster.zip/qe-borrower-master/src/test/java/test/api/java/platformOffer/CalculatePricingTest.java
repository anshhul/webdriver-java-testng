package test.api.java.platformOffer;

import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PricingConstant;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.offer.StaggMap;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;
import com.prosper.automation.model.platform.pricing.*;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Arrays;

import static com.prosper.automation.constant.DateConstant.PRICING_DATE_FORMAT;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class CalculatePricingTest extends PlatformOfferTestBase {

    private static final Double INITIAL_AMOUNT_REQUESTED = 15000.;
    private static final String LISTING_CATEGORY_ID = "1";


    private static final double MONTHLY_INCOME = 100000;
    private static final double DTI_PROSPER_LOAN = 0.002;
    private static final double PROBABILITY_SCORE = 0.02;

    private static final String ALL_803 = "0";
    private static final String REV_201 = "7279";
    private static final String BAC_302 = "8500";
    private static final String BAC_042 = "0.5";
    private static final String ALL_201 = "200000";
    protected static final String SCORE_MODEL_TYPE = "FICO_SCORE";

    private static final String ZIP_CODE = "94105";
    private static final String PRICING_BIN = "DirectMail|Str201407|T1";
    private static final String SUPER_PRIME_RULES = "Control|67,Test|33";

    private static final int EXPERIAN_SCORE = 766;

    private static final double REQUESTED_LOAN_AMOUNT = 15000;
    private static final int LOAN_TERM = 3;
    private static final int FICO_BINRAND = 773;

//    private static final String SCORE_CARD_TYPE = "PMI6_PRIOR_640_PL";
    private static final String SCORE_CARD_TYPE = "PMI7";

    private static final double DTI_CHG_10K_36MO_LOAN_ALL_EMP = 0.2278;

    private PricingRequest pricingRequest;

    private static final String DEFAULT_LOAN_STATE = "CA";
    private static final String DEFAULT_PRICING_VERSION = "7.001";
//    private static final String DEFAULT_PRICING_VERSION = "6.018";

    private static final String DEFAULT_LOAN_PRODUCT = "PRIME";
    private Boolean ISEMPLOYED = true;

    @Autowired
    private IPlatformOffer pubSiteOfferService;

    /**
     * Test setup function to build calculate pricing request object.
     *
     * @throws AutomationException
     */
    @BeforeMethod
    public void buildPricingRequest() throws AutomationException {
        AddressInfo addressInfo = new AddressInfo.Builder()
                .withZipCode(ZIP_CODE)
                .withState(DEFAULT_LOAN_STATE)
                .build();
        EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withMonthlyIncome(MONTHLY_INCOME)
                .withIsSelfEmployed(ISEMPLOYED)
                .build();
        UserInfo userInfo = new UserInfo.Builder()
                .withAddressInfo(addressInfo)
                .withEmploymentInfo(employmentInfo)
                .withInitialAmountRequested(INITIAL_AMOUNT_REQUESTED)
                .withInitialRequestedListingCategoryId(LISTING_CATEGORY_ID)
                .build();
        CalculatedPmiAttributes calculatedPmiAttributes = new CalculatedPmiAttributes.Builder()
                .withDtiWoProspLoan(DTI_PROSPER_LOAN)
                .withDtiChg10K36MoLoanAllEmp(DTI_CHG_10K_36MO_LOAN_ALL_EMP)
                .build();
        ScoreCard scoreCard = new ScoreCard.Builder()
                .withProbabilityScore(PROBABILITY_SCORE)
                .withScoreCardType(SCORE_CARD_TYPE)
                .build();
        PricingInfo pricingInfo = new PricingInfo.Builder()
                .withBreDmPricingBin(PRICING_BIN)
                .withSuperPrimeRules(SUPER_PRIME_RULES)
                .build();
        StaggMap staggMap = new StaggMap.Builder()
                .withAll803(ALL_803)
                .withRev201(REV_201)
                .withBac302(BAC_302).withBac042(BAC_042)
                .withAll201(ALL_201)
                .build();
        ExperianUserCredit experianUserCredit = new ExperianUserCredit.Builder()
                .withScore(EXPERIAN_SCORE)
                .withStaggMap(staggMap)
                .build();
        UserLoanAttributes userLoanAttributes = new UserLoanAttributes.Builder()
                .withIsPriorBorrower(true)
                .build();
        ScoreModel scoreModel = new ScoreModel.Builder().withScoreModelType(SCORE_MODEL_TYPE).withResults(FICO_BINRAND).build();
        TransunionUserCredit transunionUserCredit = new TransunionUserCredit.Builder().withScoreModel(Arrays.asList(scoreModel)).
                build();

        pricingRequest = new PricingRequest.Builder()
                .withUserInfo(userInfo)
                .withCalculatedPmiAttributes(calculatedPmiAttributes)
                .withScoreCard(scoreCard)
                .withPricingInfo(pricingInfo)
                .withPricingVersion(DEFAULT_PRICING_VERSION)
                .withExperianUserCredit(experianUserCredit)
                .withUserLoanAttributes(userLoanAttributes)
                .withLoanProduct(DEFAULT_LOAN_PRODUCT)
                .withRequestedLoanAmount(REQUESTED_LOAN_AMOUNT)
                .withLoanTerm(LOAN_TERM)
                .withOriginationDate(DateConstant.getTodayDateString(PRICING_DATE_FORMAT))
                .withTransunionUserCredit(transunionUserCredit)
                .build();

    }

    @Test
    public void testCalculatePricingHappyPath() throws AutomationException, HttpRequestException {
        LOG.info("Pricing Request:" + pricingRequest.toString());
        final PricingResponse pricingResponse = pubSiteOfferService.calculatePricing(pricingRequest);
        LOG.info("Pricing Response " + pricingResponse.toString());
        Assert.assertNotNull(pricingResponse);
        Assert.assertTrue(pricingResponse.isValid());
    }

    @Test(expectedExceptions = {HttpBadRequestException.class}, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_0001)
    public void testCalculatePricingWithInvalidPricingVersion() throws AutomationException, HttpRequestException {
        pricingRequest.setPricingVersion(PricingConstant.INVALID_PRICING_VERSION);

        final PricingResponse response = pubSiteOfferService.calculatePricing(pricingRequest);
        Assert.assertFalse(response.isValid());
    }
}
