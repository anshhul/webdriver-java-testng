package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.*;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.tool.BorrowerDataService;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.api.java.platformOffer.PlatformOfferTestBase;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

/**
 * Created by bhirani on 5/8/17.
 */
public class PostBureauNewUserDeclineTest extends PlatformOfferTestBase {

    @Resource
    private BorrowerDataService borrowerDataService;

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testUserWithBankruptcy() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.BANKRUPTCY);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-1200\",\"message\":\"FILED_FOR_BANKRUPTY_LAST_12_MONTHS\"}");
        UserCreditReportMappingDAO mappingDAO = circleOneDBConnection.getDataAccessObject(UserCreditReportMappingDAO.class);
        String externalCreditReportID = mappingDAO.getExternalCreditReportIDByEmail(testUserEmail);
        TransunionDAO attributeDAO = transUnionDBConnection.getDataAccessObject(TransunionDAO.class);
        List<Integer> bankruptcyAttributes = attributeDAO.getBankruptcyAttributes(externalCreditReportID);
        Assert.assertTrue(bankruptcyAttributes.get(0) > 0);
        Assert.assertTrue(bankruptcyAttributes.get(1) <= 12);
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testUserWithCreditScoreTooLow() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.LOW_CREDITSCORE);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-1300\",\"message\":\"CREDIT_SCORE_TOO_LOW_NEW_BORROWER\"}");
        UserCreditReportMappingDAO mappingDAO = circleOneDBConnection.getDataAccessObject(UserCreditReportMappingDAO.class);
        String externalCreditReportID = mappingDAO.getExternalCreditReportIDByEmail(testUserEmail);
        TransunionDAO attributeDAO = transUnionDBConnection.getDataAccessObject(TransunionDAO.class);
        int ficoValue = attributeDAO.getFicoScore(externalCreditReportID);
        Assert.assertTrue(ficoValue < 640);
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testUserWithMoreInquires() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.HIGH_INQUIRY);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-1500\",\"message\":\"TOO_MANY_CREDIT_INQUIRIES_LAST_6_MONTHS\"}");
        UserCreditReportMappingDAO mappingDAO = circleOneDBConnection.getDataAccessObject(UserCreditReportMappingDAO.class);
        String externalCreditReportID = mappingDAO.getExternalCreditReportIDByEmail(testUserEmail);
        TransunionDAO attributeDAO = transUnionDBConnection.getDataAccessObject(TransunionDAO.class);
        int inquiryAttribute = attributeDAO.getInquiryAttributes(externalCreditReportID);
        Assert.assertTrue(inquiryAttribute >= 5);
    }

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"OFF-1600\",\"message\":\"NON_MORTGAGE_PAYMENT_TOO_HIGH\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testHighDTIUser() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        Double income = 10.0;
        UserRequest userRequest = buildGenericUserRequest(testUserEmail, income);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response =
                pubSiteOfferService.getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testUserWithTooFewTradeLines() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.TOO_FEW_TRADELINES);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-1900\",\"message\":\"TOO_FEW_TRADE_LINES\"}");
        UserCreditReportMappingDAO mappingDAO = circleOneDBConnection.getDataAccessObject(UserCreditReportMappingDAO.class);
        String externalCreditReportID = mappingDAO.getExternalCreditReportIDByEmail(testUserEmail);
        TransunionDAO attributeDAO = transUnionDBConnection.getDataAccessObject(TransunionDAO.class);
        int tradelineAttribute = attributeDAO.getTradeLinesAttributes(externalCreditReportID);
        Assert.assertTrue(tradelineAttribute <= 2);
    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testUserWithHighPMIScore() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = Constant.getAAUniqueEmail();
        HttpRequestException offerResponse = borrowerDataService.createNewAABorrower(testUserEmail, ProsperCreditGrade.HIGH_PMI_SCORE);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-2000\",\"message\":\"PMI_SCORE_TOO_HIGH\"}");
        UserDAO userDao = circleOneDBConnection.getDataAccessObject(UserDAO.class);
        String userID = userDao.getUserIDWithEmail(testUserEmail);
        LoanOfferDAO scoreDao = circleOneDBConnection.getDataAccessObject(LoanOfferDAO.class);
        Double pmiScore = scoreDao.getScoreWithUserID(userID);
        Assert.assertTrue(pmiScore > 0.13);
    }

}
