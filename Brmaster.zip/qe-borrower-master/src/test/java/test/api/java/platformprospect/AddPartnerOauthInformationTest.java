
package test.api.java.platformprospect;

import com.prosper.automation.asserts.ProsperAssert;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.prospect.CampaignSourceDAO;
import com.prosper.automation.db.dao.prospect.PartnerOAuthDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import test.api.java.platformprospect.cases.AddPartnerOauthInformationTestCase;

import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public final class AddPartnerOauthInformationTest extends PlatformProspectTestBase implements AddPartnerOauthInformationTestCase {

    @Test
    public void testCreatePartnerOauthInfoHappyPath() throws AutomationException, HttpRequestException {
        addPartnerOauthInfo();
    }

    @Test(expectedExceptions = HttpRequestException.class)
    public void testCreatePartnerOauthInfoIsNotInsertingDuplicateData() throws AutomationException, HttpRequestException {

        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final String newClientId = Constant.newUuid();
        final PartnerOauthInfo request = new PartnerOauthInfo.Builder().withExternalClientId(newClientId)
                .withCampaignSourceId(partnerOauthInfo.getCampaignSourceId()).build();

        internalProspectService.addPartnerOAuth(request);

    }

    @Test(expectedExceptions = HttpInternalServerErrorException.class)
    public void testCreatePartnerOauthInfoWithNonExistingCampaignSourceId() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo request = new PartnerOauthInfo.Builder().withExternalClientId(Constant.newUuid())
                .withCampaignSourceId(Constant.newUuid()).build();
        internalProspectService.addPartnerOAuth(request);
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testCreatePartnerOauthInfoWithNullClientId() throws AutomationException, HttpRequestException {
        final CampaignSourceDAO campaignSourceDAO = prospectDBConnection.getDataAccessObject(CampaignSourceDAO.class);
        final String campaignSourceId = campaignSourceDAO.getLatestCampaignSourceId();

        final PartnerOauthInfo request = new PartnerOauthInfo.Builder().withCampaignSourceId(campaignSourceId).build();
        internalProspectService.addPartnerOAuth(request);
    }

    @Test
    public void testCreatePartnerOauthInfoPersistCorrectData() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final PartnerOAuthDAO partnerOauthDAO = prospectDBConnection.getDataAccessObject(PartnerOAuthDAO.class);
        final PartnerOauthInfo partnerOauthInfoFromDatabase =
                partnerOauthDAO.getPartnerOauthInfo(partnerOauthInfo.getExternalClientId());

        ProsperAssert.assertEquals(partnerOauthInfoFromDatabase.getPartnerOauthId(), partnerOauthInfo.getPartnerOauthId());
        ProsperAssert.assertEquals(partnerOauthInfoFromDatabase.getExternalClientId(), partnerOauthInfo.getExternalClientId());
        ProsperAssert.assertEquals(partnerOauthInfoFromDatabase.getCampaignSourceId(), partnerOauthInfo.getCampaignSourceId());

        ProsperAssert.assertTimestampWithinRange(partnerOauthInfoFromDatabase.getCreatedDate(), DB_PERSIST_DELAY_IN_MS);
        ProsperAssert.assertTimestampWithinRange(partnerOauthInfoFromDatabase.getModifiedDate(), DB_PERSIST_DELAY_IN_MS);
        ProsperAssert.assertTimestampWithinRange(partnerOauthInfoFromDatabase.getVersionStartDate(), DB_PERSIST_DELAY_IN_MS);

        ProsperAssert.assertEquals(partnerOauthInfoFromDatabase.getModifiedBy(), null);
        ProsperAssert.assertEquals(partnerOauthInfoFromDatabase.getVersionEndDate(), null);
    }
}
