
package test.api.java.platformMarketplace;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.MarketplaceOffer;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.OfferDetails;
import com.prosper.automation.model.wcf.dxReferral.DXReferralRequest;
import com.prosper.automation.model.wcf.dxReferral.DXReferralResponse;
import com.prosper.automation.model.wcf.dxReferral.OfferDto;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import com.prosper.automation.util.Rounding;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Objects;

/**
 * @author pbudiono
 */
public class MarketplaceOfferComparisonTest extends MarketplaceOffersTestBase {

    private static final Logger LOG = Logger.getLogger(MarketplaceOfferComparisonTest.class.getSimpleName());

    @Autowired
    private IPlatformMarketplace marketplaceService;

    @Test(dataProvider = EXPERIAN_USER_DATA_PROVIDER, enabled = false) // TODO: PPATIL Fix (Auto ticket created)
    public void testMarketplaceOfferComparisonForProsperCreditGrade(final ProsperCreditGrade prosperCreditGrade)
            throws AutomationException, HttpRequestException, JsonProcessingException {
        LOG.info(String.format("Comparing marketplace offer against DXReferral offer for user with Prosper credit grade %s",
                prosperCreditGrade));

        final String marketplaceUserEmail = Constant.getGloballyUniqueEmail();
        final String dxReferralUserEmail = Constant.getGloballyUniqueEmail();

        final GetOfferRequest getOfferRequest = buildMarketplaceOfferRequest(prosperCreditGrade, marketplaceUserEmail, "255");
        final DXReferralRequest dxReferralOfferRequest = buildDXReferralOfferRequest(prosperCreditGrade, dxReferralUserEmail);

        final GetOffersResponse marketplaceOfferResponse = marketplaceService.getOffer(getOfferRequest);
        final DXReferralResponse dxReferralOfferResponse = creditKarmaWCFService.getOffers(dxReferralOfferRequest);

        validateOfferResponses(marketplaceOfferResponse, dxReferralOfferResponse);
    }

    private void validateOfferResponses(final GetOffersResponse marketplaceOfferResponse,
                                        final DXReferralResponse dxReferralOfferResponse) {

        final List<OfferDetails> marketplaceOffers = marketplaceOfferResponse.getOffers();
        final List<OfferDto> dxReferralOffers = dxReferralOfferResponse.getLoanOffers();

        final int numberOfMarketplaceOffers = marketplaceOffers.size();
        final int numberOfDXReferralOffers = dxReferralOffers.size();

        // validate number of offers returned by both services.
        Assert.assertEquals(numberOfMarketplaceOffers, numberOfDXReferralOffers,
                "Number of offers do not match between DXReferral and Marketplace services.");

        // iterating through DX Referral offers as test baseline.
        for (final OfferDto dxReferralOffer : dxReferralOffers) {
            // using loan amount and loan term to get Marketplace offer.
            final MarketplaceOfferPredicate marketplaceOfferPredicate =
                    new MarketplaceOfferPredicate(dxReferralOffer.getLoanAmount(), dxReferralOffer.getLoanTerm());

            final List<MarketplaceOffer> foundMarketplaceOffers =
                    (List<MarketplaceOffer>) CollectionUtils.select(marketplaceOffers, marketplaceOfferPredicate);
            Assert.assertEquals(1, foundMarketplaceOffers.size(), "Unable to find matching offer.");

            final MarketplaceOffer marketplaceOffer = foundMarketplaceOffers.get(0);

            final SoftAssert softAssert = new SoftAssert();

            // soft assert comparison on APRs.
            final boolean isAcceptableAPR =
                    Rounding.ONE_TEN_THOUSANDTH.isAcceptable(dxReferralOffer.getApr() * 100, marketplaceOffer.getBorrowerAPR());
            softAssert.assertTrue(isAcceptableAPR, "APRs do not match.");

            // soft assert comparison on loan amounts.
            softAssert.assertEquals(dxReferralOffer.getLoanAmount(), marketplaceOffer.getLoanAmount(),
                    "Loan amounts do not match.");

            // soft assert comparison on loan rate.
            softAssert.assertTrue(
                    Rounding.ONE_TEN_THOUSANDTH.isAcceptable(dxReferralOffer.getLoanRate() * 100, marketplaceOffer.getLoanRate()),
                    "Loan rates do not match.");

            // soft assert comparison on loan terms.
            softAssert.assertEquals((double) dxReferralOffer.getLoanTerm(), marketplaceOffer.getLoanTermInYears(),
                    "Loan terms do not match.");

            // soft assert comparison on monthly payments.
            softAssert.assertEquals(dxReferralOffer.getMonthlyPayment(), marketplaceOffer.getMonthlyPayment(),
                    "Monthly payments do not match.");

            softAssert.assertAll();
        }
    }


    private class MarketplaceOfferPredicate implements Predicate {

        private final Double loanAmount;
        private final Integer loanTerm;


        public MarketplaceOfferPredicate(Double loanAmount, Integer loanTerm) {
            this.loanAmount = loanAmount;
            this.loanTerm = loanTerm;
        }

        @Override
        public boolean evaluate(Object object) {
            final MarketplaceOffer marketplaceOffer = (MarketplaceOffer) object;
            return Objects.equals(marketplaceOffer.getLoanAmount(), loanAmount)
                    && Objects.equals(marketplaceOffer.getLoanTermInYears(), Double.valueOf(loanTerm));
        }
    }
}
