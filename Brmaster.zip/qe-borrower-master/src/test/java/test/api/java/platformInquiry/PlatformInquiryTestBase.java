package test.api.java.platformInquiry;

import java.util.List;

import com.prosper.automation.constant.test.TestGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import test.api.java.PlatformServiceTestBase;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ListingActivationWorkflowDAO;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.inquiry.PlatformAnalyticsInquiryDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.LendingAccreditation;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformAccountImpl;
import com.prosper.automation.platform.clients.PlatformDocumentImpl;
import com.prosper.automation.platform.clients.PlatformListingImpl;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.clients.PlatformUserImpl;
import com.prosper.automation.platform.interfaces.IPlatformAccount;
import com.prosper.automation.platform.interfaces.IPlatformDocument;
import com.prosper.automation.platform.interfaces.IPlatformInquiry;
import com.prosper.automation.platform.interfaces.IPlatformListing;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.platform.interfaces.IPlatformUser;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
@Deprecated
public abstract class PlatformInquiryTestBase extends PlatformServiceTestBase {

	protected IPlatformDocument documentService;
	protected IPlatformListing listingService;
	protected IPlatformUser userService;
	protected IPlatformAccount accountService;

	protected ListingActivationWorkflowDAO listingActivationWorkflowDAO;
	protected ListingsDAO listingsDAO;
	protected PlatformAnalyticsInquiryDAO inquiryDAO;

	protected Long testListingId;
	protected String testLoanOfferId;

	@Autowired
	protected IPlatformInquiry pubSiteInquiryService;

	private String userEmail;

	@Qualifier("platformPublicServiceConfig")
	@Autowired
	private HttpClientConfig platformPublicServiceConfig;

	@Qualifier("circleOneDBConnection")
	@Autowired
	private CloseableJdbcConnection circleOneDBConnection;

	@Qualifier("pubSiteUserService")
	@Autowired
	private IPlatformUser pubSiteUserService;

	@BeforeMethod(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
	public final void initializePlatformInquiryTest() throws HttpRequestException, AutomationException {
		userEmail = Constant.getGloballyUniqueEmail();

		final Long userId = createNewBorrower(userEmail);
		final OffersResponse offersResponse = getBorrowerOffer(platformPublicServiceConfig, userId);

		final List<Offer> offers = offersResponse.getListedOffers().getOffers();

		Assert.assertTrue(offers.size() >= 1);

		testLoanOfferId = offers.get(0).getLoanOfferId();
		testListingId = offersResponse.getListedOffers().getListingId();

		documentService = new PlatformDocumentImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
		listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
		userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

		listingActivationWorkflowDAO = circleOneDBConnection.getDataAccessObject(ListingActivationWorkflowDAO.class);
		listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
		inquiryDAO = circleOneDBConnection.getDataAccessObject(PlatformAnalyticsInquiryDAO.class);
	}

	private OffersResponse getBorrowerOffer(HttpClientConfig httpClientConfig, Long userId)
			throws AutomationException, HttpRequestException {
		final IPlatformOffer offerService = new PlatformOfferImpl(httpClientConfig, userEmail, Constant.COMMON_PASSWORD);
		return offerService.getUserOffers(userId, GENERIC_PROSPECT_LOAN_AMOUNT, GENERIC_PROSPECT_LISTING_CATEGORY_ID,
				GENERIC_PROSPECT_LOAN_PURPOSE_ID, GENERIC_PROSPECT_CREDIT_RANGE_ID);
	}

	@AfterMethod
	public final void closeDatabaseConnection() {
		circleOneDBConnection.close();
	}

	protected Long createNewBorrower(final String userEmail) throws HttpRequestException, AutomationException {
		final AddressInfo addressInfo = AddressInfoConstant.ADDRESS_INFO;
		final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(userEmail).build();
		final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
				.withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID).withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
		final LendingAccreditation lendingAccreditation = new LendingAccreditation.Builder()
				.withCreditProfileAuth(Constant.TEST_CREDIT_PROFILE_AUTH)
				.withPrivacyPoliciesAgreement(Constant.TEST_PRIVACY_POLICIES_AGREEMENT).build();
		final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME)
				.withLastName(Constant.TEST_LAST_NAME).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH)
				.withUserNameTypeId(Constant.TEST_USER_NAME_TYPE_ID).withSourceTypeId(Constant.TEST_SOURCE_TYPE_ID).build();
		final User user = new User.Builder().withPassword(Constant.COMMON_PASSWORD).withIntendedRole(Constant.TEST_INTENDED_ROLE)
				.withCreditGrade(Constant.TEST_CREDIT_GRADE).withMonthlyDebt(Constant.TEST_MONTHLY_DEBT)
				.withAddressInfo(addressInfo).withPersonalInfo(personalInfo).withContactInfo(contactInfo)
				.withEmploymentInfo(employmentInfo).withLendingAccreditation(lendingAccreditation).build();
		final UserRequest userRequest = new UserRequest.Builder().withUser(user).build();
		final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);

		accountService = new PlatformAccountImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
		accountService.createBankAccount(BankAccountConstant.RANDOM_BANK_OF_AMERICA_ACCOUNT);

		return userResponse.getUserRequest().getUserId();
	}
}
