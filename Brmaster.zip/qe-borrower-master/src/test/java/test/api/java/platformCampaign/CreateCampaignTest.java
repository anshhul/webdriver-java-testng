package test.api.java.platformCampaign;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.campaign.CampaignRequestResponse;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class CreateCampaignTest extends PlatformCampaignTestBase {

    private static final String START_DATE = "2015-01-01 13:01:02 +0000";
    private static final String END_DATE = "2015-01-01 13:01:02 +0000";
    private static final String DURATION = "1";

    @Test public void testCreateCampaign() throws HttpRequestException, AutomationException {
        doTestCreateCampaign(true);
        doTestCreateCampaign(false);
    }

    public void doTestCreateCampaign(boolean nullEndDate) throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        if (!nullEndDate) {
            request.setEndDate(END_DATE);
        }
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
            Assert.assertEquals(response.getDescription(), description);
            Assert.assertEquals(response.getStartDate(), request.getStartDate().split("\\+")[0].trim());
            if (!nullEndDate) {
                Assert.assertEquals(response.getEndDate(), request.getEndDate().split("\\+")[0].trim());
            }
            Assert.assertEquals(response.getDuration(), request.getDuration());
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }

    @DataProvider(name = "testInvalidFields") public static Object[][] invalidFields() {
        return new Object[][] {{getRequestWithoutStartDate()}, {getRequestWithoutDuration()}, {getRequestWithoutDesc()}, {getRequestWithLongDesc()}};
    }

    private static CampaignRequestResponse getRequestWithoutStartDate() {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        return request;
    }

    private static CampaignRequestResponse getRequestWithLongDesc() {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        request.setDescription(RandomStringUtils.random(256, String.valueOf(System.currentTimeMillis())));
        request.setDuration(DURATION);
        return request;
    }

    private static CampaignRequestResponse getRequestWithoutDesc() {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        request.setDuration(DURATION);
        return request;
    }

    private static CampaignRequestResponse getRequestWithoutDuration() {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        return request;
    }

    @Test(dataProvider = "testInvalidFields", groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class) public void testInvalidFields(
            CampaignRequestResponse request) throws AutomationException, HttpRequestException {
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }
}
