package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpUnprocessableEntityException;
import com.prosper.automation.core.httpClient.exception.HttpConflictException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectCreditReportMappingDTO;
import com.prosper.automation.model.platform.prospect.ProspectCreditReportMappingRequest;
import com.prosper.automation.model.platform.prospect.ProspectCreditReportMappingResponse;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by rchintapalli on 12/02/16.
 */
public class ProspectCreditReportMappingTest extends PlatformProspectTestBase {

    private static final Logger LOG = Logger.getLogger(ProspectCreditReportMappingTest.class.getSimpleName());


    @Test(groups = {TestGroup.SANITY})
    public void postProspectCreditReportMappingTest() throws AutomationException, HttpRequestException {
        final ProspectResponse response = pubSiteProspectService.createProspect(buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail()));
        UUID prospectId = response.getProspect().getProspectId();
        UUID externalCreditReportId = UUID.randomUUID();
        ProspectCreditReportMappingDTO prospectCreditReportMappingDTO = new ProspectCreditReportMappingDTO.Builder().
                withProspectId(prospectId).withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).
                withIsDecisionBureau(true).withCreditPullDate(new Date()).build();
        List requestList = new ArrayList<ProspectCreditReportMappingDTO>();
        requestList.add(prospectCreditReportMappingDTO);

        ProspectCreditReportMappingRequest prospectCreditReportMappingRequest = new ProspectCreditReportMappingRequest.Builder().
                withProspectCreditReportMappingDTO(requestList).build();
        ProspectCreditReportMappingResponse prospectCreditReportMappingResponse = pubSiteProspectService.postCreditReportMapping(prospectCreditReportMappingRequest);
        Assert.assertNotNull(prospectCreditReportMappingResponse);
        Assert.assertEquals(String.valueOf(prospectId), String.valueOf(prospectCreditReportMappingResponse.getProspectMappingResponse().get(0).getProspectId()));
    }

    // TODO update after fix to POST endpoint
    @Test(groups = {TestGroup.SANITY}, expectedExceptions = HttpConflictException.class, expectedExceptionsMessageRegExp = ".*PRS-0039.*")
    public void postProspectCreditReportMappingWithExistingIdTest() throws AutomationException, HttpRequestException, SkipException {
        final ProspectResponse response = pubSiteProspectService.createProspect(buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail()));
        UUID prospectId = response.getProspect().getProspectId();
        UUID externalCreditReportId = UUID.randomUUID();
        ProspectCreditReportMappingDTO prospectCreditReportMappingDTO = new ProspectCreditReportMappingDTO.Builder().
                withProspectId(prospectId).withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).
                withIsDecisionBureau(true).withCreditPullDate(new Date()).build();
        List requestList = new ArrayList<ProspectCreditReportMappingDTO>();
        requestList.add(prospectCreditReportMappingDTO);

        ProspectCreditReportMappingRequest prospectCreditReportMappingRequest = new ProspectCreditReportMappingRequest.Builder().
                withProspectCreditReportMappingDTO(requestList).build();
        pubSiteProspectService.postCreditReportMapping(prospectCreditReportMappingRequest);
        pubSiteProspectService.postCreditReportMapping(prospectCreditReportMappingRequest);
        throw new HttpConflictException(".*PRS-0039.*");
    }

    @Test(groups = {TestGroup.SANITY})
    public void getProspectCreditReportMappingTest() throws AutomationException, HttpRequestException {
        final ProspectResponse response = pubSiteProspectService.createProspect(buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail()));
        UUID prospectId = response.getProspect().getProspectId();
        UUID externalCreditReportId = UUID.randomUUID();
        ProspectCreditReportMappingDTO prospectCreditReportMappingDTO = new ProspectCreditReportMappingDTO.Builder().
                withProspectId(prospectId).withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).
                withIsDecisionBureau(true).withCreditPullDate(new Date()).build();
        List requestList = new ArrayList<ProspectCreditReportMappingDTO>();
        requestList.add(prospectCreditReportMappingDTO);

        ProspectCreditReportMappingRequest prospectCreditReportMappingRequest = new ProspectCreditReportMappingRequest.Builder().
                withProspectCreditReportMappingDTO(requestList).build();
        pubSiteProspectService.postCreditReportMapping(prospectCreditReportMappingRequest);
        ProspectCreditReportMappingResponse prospectCreditReportMappingResponse = pubSiteProspectService.getCreditReportMapping(prospectId);
        Assert.assertNotNull(prospectCreditReportMappingResponse);
        Assert.assertEquals(String.valueOf(prospectId), String.valueOf(prospectCreditReportMappingResponse.getProspectMappingResponse().get(0).getProspectId()));
    }

    @Test(groups = {TestGroup.SANITY}, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ".*PRS-0039.*")
    public void getProspectCreditReportMappingWithInvalidProspectIdTest() throws AutomationException, HttpRequestException {
        final ProspectResponse response = pubSiteProspectService.createProspect(buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail()));
        UUID prospectId = response.getProspect().getProspectId();
        pubSiteProspectService.getCreditReportMapping(prospectId);
    }

}
