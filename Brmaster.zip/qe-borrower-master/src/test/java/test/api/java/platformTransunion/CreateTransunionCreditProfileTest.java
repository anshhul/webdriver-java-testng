package test.api.java.platformTransunion;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.transUnion.*;
import com.prosper.automation.model.testdata.TransunionTestData;
import com.prosper.automation.test.restSeeder.TestDataService;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 9/8/16.
 */
public class CreateTransunionCreditProfileTest extends PlatformTransunionTestBase {

    private static final Logger LOG = Logger.getLogger(CreateTransunionCreditProfileTest.class.getSimpleName());

    private static final TestDataService TEST_DATA_SERVICE = new TestDataService();

/*    @DataProvider(name = TRANSUNION_DATA, parallel = true) public Object[][] provideData() {
        final Object[][] data =
            {{1, 15000}, {15001, 30000}, {30001, 45000}, {45001, 60000}, {60001, 75000}, {75001, 90000},
                         {90001, 105000}, {105001, 120000}, {120001, 135000}, {135001, 150000}};
        return data;
    }

    @Test(dataProvider = TRANSUNION_DATA) public void test(int lower, int upper)
            throws AutomationException, HttpRequestException {
        LOG.info(lower + " " + upper);

        while (lower < upper) {
            LOG.info("Page " + ((lower/100) + 1));
            TEST_DATA_SERVICE.getTransunionTestData(100, (lower / 100) + 1).forEach(this::performRequest);
            lower += 100;
        }
    }*/

    @Test(groups = {TestGroup.SANITY})
    public void createTUCreditProfileTest() throws AutomationException, HttpRequestException {
//        TUCreditReportResponse tuMCreditReportResponse = performRequest(TEST_DATA_SERVICE.getTransunionTestData(1, 1).get(0));
        TUCreditReportResponse tuMCreditReportResponse = performRequestWithConstants();
        Assert.assertNotNull(tuMCreditReportResponse);
        LOG.info("ExternalCreditReportId: " + tuMCreditReportResponse.getExternalCreditReportId());
    }

    private TUCreditReportResponse performRequest(TransunionTestData transunionTestData) throws HttpRequestException, AutomationException {
        final String[] fullZipCode = transunionTestData.getZipCode().split("-");
        final String zipCode = fullZipCode[0];
        final String zipCodeExtension = fullZipCode.length > 1 ? fullZipCode[1] : null;

        final AddressRequestDTO addressRequestDTO =
                new AddressRequestDTO.Builder().withCity(transunionTestData.getCity())
                        .withState(transunionTestData.getState()).withAddressStatus("CURRENT")
                        .withNumber(transunionTestData.getHouseNumber())
                        .withStreetName(transunionTestData.getStreetName()).withZipCode(zipCode)
                        .withZipExtension(zipCodeExtension).build();
        final PersonNameRequestDTO personNameRequestDTO =
                new PersonNameRequestDTO.Builder().withFirst(transunionTestData.getFirstName())
                        .withLast(transunionTestData.getLastName())
                        .withMiddle(transunionTestData.getMiddleName()).build();
        final SocialSecurityRequestDTO socialSecurityRequestDTO =
                new SocialSecurityRequestDTO.Builder().withNumber(transunionTestData.getSsn()).build();
        final TUCreditReportRequest tuCreditReportRequest =
                new TUCreditReportRequest.Builder().withAddress(addressRequestDTO).withPersonName(personNameRequestDTO)
                        .withSocialSecurity(socialSecurityRequestDTO)
                        .withDateOfBirth("1984-10-30").build();

        return pubSiteTransunionService.createCreditReport(tuCreditReportRequest);
    }


    private TUCreditReportResponse performRequestWithConstants() throws HttpRequestException, AutomationException {

        final AddressRequestDTO addressRequestDTO =
                new AddressRequestDTO.Builder().withCity(Constant.MARY_CITY)
                        .withState(Constant.MARY_STATE).withAddressStatus("CURRENT")
                        .withNumber(Constant.MARY_HOUSENUMBER)
                        .withStreetName(Constant.MARY_STREET).withZipCode(Constant.MARY_ZIPCODE).build();
        final PersonNameRequestDTO personNameRequestDTO =
                new PersonNameRequestDTO.Builder().withFirst(Constant.MARY_FIRST)
                        .withLast(Constant.MARY_LAST).build();
//                        .withMiddle("E").build();
        final SocialSecurityRequestDTO socialSecurityRequestDTO =
                new SocialSecurityRequestDTO.Builder().withNumber(Constant.MARY_SSN).build();
        final TUCreditReportRequest tuCreditReportRequest =
                new TUCreditReportRequest.Builder().withAddress(addressRequestDTO).withPersonName(personNameRequestDTO)
                        .withSocialSecurity(socialSecurityRequestDTO)
                        .withDateOfBirth(Constant.MARY_DOB).build();

        return pubSiteTransunionService.createCreditReport(tuCreditReportRequest);
    }


}
