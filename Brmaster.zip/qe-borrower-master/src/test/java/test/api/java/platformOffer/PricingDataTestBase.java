package test.api.java.platformOffer;

import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.constant.DirectoryConstant;
import com.prosper.automation.constant.TestConstant;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.Industry;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.jira.interfaces.IJiraClient;
import com.prosper.automation.jira.model.Attachment;
import com.prosper.automation.jira.model.Issue;
import com.prosper.automation.model.BorrowerPricingData;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.offer.StaggMap;
import com.prosper.automation.model.platform.pmiAttributes.CalculatedPmiAttributes;
import com.prosper.automation.model.platform.pricing.*;
import com.prosper.automation.parser.BorrowerPricingCSVParser;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public class PricingDataTestBase extends PlatformOfferTestBase {

    protected static final double MIN_LOAN_AMOUNT = 2000.0;

    protected static final String PRICING_DATA = "pricingData";

    protected static final String PRICING_VERSION_VALIDATION_TEMPLATE = "Validating pricing version";
    protected static final String MONTHLY_PAYMENT_VALIDATION_TEMPLATE = "Validating monthly payment";
    protected static final String FINAL_PAYMENT_VALIDATION_TEMPLATE = "Validating final payment";
    protected static final String FINANCE_CHARGE_VALIDATION_TEMPLATE = "Validating finance charge";
    protected static final String LOSS_RATE_VALIDATION_TEMPLATE = "Validating loss rate";
    protected static final String PARTIAL_FUNDING_VALIDATION_TEMPLATE = "Validating partial funding";
    protected static final String BORROWER_APR_VALIDATION_TEMPLATE = "Validating borrower APR";
    protected static final String ORIGINATION_FEE_VALIDATION_TEMPLATE = "Validating origination fee";
    protected static final String LOAN_CAP_VALIDATION_TEMPLATE = "Validating loan cap";
    //	protected static final String SCORE_MODEL_TYPE = "00Q88";
    protected static final String SCORE_MODEL_TYPE_FICO = "FICO_SCORE";
    protected static final String SCORE_MODEL_TYPE_VANTAGE = "VANTAGE_SCORE";

    private static final Logger LOG = Logger.getLogger(PricingDataTestBase.class.getSimpleName());

    private static final String FETCH_PRICING_TICKET_FROM_JIRA_LOG = "Fetching pricing ticket information %s from JIRA.";
    private static final String PRICING_TICKET_NOT_FOUND_LOG = "Pricing ticket %s can not be found in JIRA.";
    private static final String PRICING_TICKET_FETCHING_ERROR_LOG = "Unable to fetch pricing ticket %s from JIRA.";
    private static final String FETCH_PRICING_FILE_FROM_JIRA_LOG = "Fetching attached pricing file %s from JIRA.";
    private static final String PRICING_FILE_NOT_FOUND_LOG = "Unable to fetch pricing file from JIRA.";
    private static final String PRICING_FILE_DOWNLOAD_LOG = "Downloading pricing file from JIRA.";
    private static final String UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG = "Unable to download pricing file from JIRA.";

    private static String SCORE_CARD_TYPE = "PMI7";
//    private static String SCORE_CARD_TYPE = "PMI6_PRIOR_640_PL";

    @Value("${pricing.jira.ticket.number}")
    protected String pricingTicketNumber;
    @Value("${pricing.jira.file.name}")
    protected String pricingFileName;
    @Value("${pricing.test.file.version}")
    protected String pricingVersion;
    @Value("${pricing.test.state}")
    protected String pricingTestState;
    @Value("${pricing.test.number.of.threads}")
    protected String numberOfThreads;

//    protected String pricingTestState = "CA";
//    protected String numberOfThreads = "100";
//    protected String pricingVersion = "7.003";
//    protected String pricingVersion="6.018";

    @Resource
    private IJiraClient jiraService;

    protected static PricingRequest buildPricingRequest(final BorrowerPricingData pricing, final String testState,
                                                        final String pricingVersion) throws AutomationException {
        SCORE_CARD_TYPE = "PMI6_PRIOR_640_PL";
        final AddressInfo addressInfo = new AddressInfo.Builder().withState(testState).withZipCode(pricing.getZip3Rand()).build();
        EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withMonthlyIncome(pricing.getMonthlyIncomeRand()).build();

        final UserInfo userInfo = new UserInfo.Builder().withAddressInfo(addressInfo).withEmploymentInfo(employmentInfo)
                .withInitialAmountRequested(pricing.getInitialLoanAmount())
                .withInitialRequestedListingCategoryId(pricing.getInCateRand()).build();
        final CalculatedPmiAttributes calculatedPmiAttributes = new CalculatedPmiAttributes.Builder()
                .withDtiWoProspLoan(pricing.getDtiWoProspLoanValueRand()).withDtiChg10K36MoLoanAllEmp(pricing.getDti10KchgRand())
                .build();
        final ScoreCard scoreCard = new ScoreCard.Builder().withScoreCardType(SCORE_CARD_TYPE)
                .withProbabilityScore(pricing.getPmi61ValueRand()).build();
        final PricingInfo pricingInfo = new PricingInfo.Builder().withBreDmPricingBin(pricing.getPartnershipChannelRand())
                .withSuperPrimeRules(pricing.getSuperPrimeRules()).build();
        final StaggMap staggMap = new StaggMap.Builder().withAll803(pricing.getInquiryRand()).withRev201(pricing.getRevbalRand())
                .withBac302(pricing.getBac302Rand()).withBac042(pricing.getBac042Rand()).withAll201(pricing.getAll201Rand())
                .build();
        final ScoreModel scoreModel = new ScoreModel.Builder().withScoreModelType(SCORE_MODEL_TYPE_FICO).withResults(pricing.getFicoValueRand()).build();

        final Integer moLastTradeRand = pricing.getMoLastTradeRand();

        Integer totalTradeLinesAvailable = null;
        if (moLastTradeRand != null) {
            totalTradeLinesAvailable = 1;
        }

        // final Integer totalTradeLinesAvailable = moLastTradeRand > 0 ? 1 : 0;

        String normalizedSSN = pricing.getSSNRand();
        if (normalizedSSN.length() == 1) {
            normalizedSSN = "0" + normalizedSSN;
        }

        final ExperianUserCredit experianUserCredit = new ExperianUserCredit.Builder().withSsn(normalizedSSN)
                .withScore(pricing.getFicoValueRand()).withLastUnsecureTradeLineOpenDateBelow60MonthTerm(moLastTradeRand)
                .withTotalTradeLinesAvailable(totalTradeLinesAvailable).withStaggMap(staggMap).build();


        if (normalizedSSN != null) {
            normalizedSSN = "9993999" + normalizedSSN;
        }
        final SocialSecurityNumber socialSecuritynumber = new SocialSecurityNumber.Builder().withNumber(normalizedSSN).build();

        final TransunionUserCredit transunionUserCredit = new TransunionUserCredit.Builder().withSsn(socialSecuritynumber).withScoreModel(Arrays.asList(scoreModel)).build();


        final UserLoanAttributes userLoanAttributes = new UserLoanAttributes.Builder()
                .withIsPriorBorrower(pricing.getPreviousLoanValueRand()).build();


        return new PricingRequest.Builder().withUserInfo(userInfo).withCalculatedPmiAttributes(calculatedPmiAttributes)
                .withScoreCard(scoreCard).withPricingInfo(pricingInfo).withPricingVersion(pricingVersion)
                .withExperianUserCredit(experianUserCredit).withUserLoanAttributes(userLoanAttributes)
                .withLoanProduct(pricing.getLoanProduct()).withRequestedLoanAmount(pricing.getLoanAmountRand())
                .withLoanTerm(pricing.getLoanTerm())
                .withOriginationDate(DateConstant.PRICING_DATE_FORMAT.format(pricing.getOriginationDate()))
                .build();


    }

    protected static PricingRequest buildPricingRequestTU(final BorrowerPricingData pricing, final String testState,
                                                          final String pricingVersion) throws AutomationException {
        final AddressInfo addressInfo = new AddressInfo.Builder().withState(testState).withZipCode(pricing.getZip3Rand()).build();
        EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withMonthlyIncome(pricing.getMonthlyIncomeRand()).withIsSelfEmployed(pricing.getEmployRand().equals("2"))
                .build();

        final UserInfo userInfo = new UserInfo.Builder().withAddressInfo(addressInfo).withEmploymentInfo(employmentInfo)
                .withInitialAmountRequested(pricing.getInitialLoanAmount()).withUserId(pricing.getUseridRand())
                .withInitialRequestedListingCategoryId(pricing.getInCateRand()).build();
        final CalculatedPmiAttributes calculatedPmiAttributes = new CalculatedPmiAttributes.Builder()
                .withDtiWoProspLoan(pricing.getDtiWoProspLoanValueRand()).withDtiChg10K36MoLoanAllEmp(pricing.getDti10KchgRand())
                .build();
        final ScoreCard scoreCard = new ScoreCard.Builder().withScoreCardType(SCORE_CARD_TYPE)
                .withProbabilityScore(pricing.getPmi61ValueRand()).build();
        final PricingInfo pricingInfo = new PricingInfo.Builder().withBreDmPricingBin(pricing.getPartnershipChannelRand())
                .withSuperPrimeRules(pricing.getSuperPrimeRules()).build();
        final StaggMap staggMap = new StaggMap.Builder().withAll803(pricing.getInquiryRand()).withRev201(pricing.getRevbalRand())
                .withBac302(pricing.getBac302Rand()).withBac042(pricing.getBac042Rand()).withAll201(pricing.getAll201Rand())
                .build();
        List<ScoreModel> scoreModels = new ArrayList<ScoreModel>();
        final ScoreModel ficoScoreModel = new ScoreModel.Builder().withScoreModelType(SCORE_MODEL_TYPE_FICO).withResults(pricing.getFicoValueRand()).build();
        scoreModels.add(ficoScoreModel);
        final ScoreModel vantageScoreModel = new ScoreModel.Builder().withScoreModelType(SCORE_MODEL_TYPE_VANTAGE).withResults(pricing.getVantageRand()).build();
        scoreModels.add(vantageScoreModel);


        final Integer moLastTradeRand = pricing.getMoLastTradeRand();

        Integer totalTradeLinesAvailable = null;
        if (moLastTradeRand != null) {
            totalTradeLinesAvailable = 1;
        }

        // final Integer totalTradeLinesAvailable = moLastTradeRand > 0 ? 1 : 0;

        String normalizedSSN = pricing.getSSNRand();
        if (normalizedSSN.length() == 1) {
            normalizedSSN = "0" + normalizedSSN;
        }

        final ExperianUserCredit experianUserCredit = new ExperianUserCredit.Builder().withSsn(normalizedSSN)
                .withScore(pricing.getFicoValueRand()).withLastUnsecureTradeLineOpenDateBelow60MonthTerm(moLastTradeRand)
                .withTotalTradeLinesAvailable(totalTradeLinesAvailable).withStaggMap(staggMap).build();


        if (normalizedSSN != null) {
            normalizedSSN = "99939" + normalizedSSN;
        }
        final SocialSecurityNumber socialSecuritynumber = new SocialSecurityNumber.Builder().withNumber(normalizedSSN).build();

        Map<String, Double> bureauAttributes = new HashMap<String, Double>();
        bureauAttributes.put("BC102S", pricing.getBc102sRand().doubleValue());
        bureauAttributes.put("RE33S", pricing.getRe33sRand().doubleValue());
        bureauAttributes.put("RE27S",pricing.getRe27sRand().doubleValue());
        bureauAttributes.put("G066S",pricing.getG066sRand());
        bureauAttributes.put("AT34B", (pricing.getAt34B_Rand().doubleValue()));
        final TransunionUserCredit transunionUserCredit = new TransunionUserCredit.Builder().withBureauAttributes(bureauAttributes)
                .withSsn(socialSecuritynumber).withScoreModel(scoreModels).build();


        final UserLoanAttributes userLoanAttributes = new UserLoanAttributes.Builder()
                .withIsPriorBorrower(pricing.getPreviousLoanValueRand()).build();


        final Industry industry =  (StringUtils.isEmpty(pricing.getThirdPartyIdRand())? null : Industry.DENTAL);
        return new PricingRequest.Builder().withIndustry(industry).withUserInfo(userInfo).withCalculatedPmiAttributes(calculatedPmiAttributes)
                .withScoreCard(scoreCard).withPricingInfo(pricingInfo).withPricingVersion(pricingVersion)
//                .withExperianUserCredit(experianUserCredit)
                .withUserLoanAttributes(userLoanAttributes)
                .withLoanProduct(pricing.getLoanProduct()).withRequestedLoanAmount(pricing.getLoanAmountRand())
                .withLoanTerm(pricing.getLoanTerm())
                .withOriginationDate(DateConstant.PRICING_DATE_FORMAT.format(pricing.getOriginationDate()))
                .withTransunionUserCredit(transunionUserCredit)
                .build();

    }


    @DataProvider(name = PRICING_DATA, parallel = true)
    public final Object[][] buildTestData() throws AutomationException {

        LOG.info(String.format(FETCH_PRICING_TICKET_FROM_JIRA_LOG, pricingTicketNumber));
        Issue pricingTicket = null;
        try {
            pricingTicket = jiraService.getIssue(pricingTicketNumber);
        } catch (HttpNotFoundException ex) {
            Assert.fail(String.format(PRICING_TICKET_NOT_FOUND_LOG, pricingTicketNumber), ex);
        } catch (HttpRequestException ex) {
            Assert.fail(String.format(PRICING_TICKET_FETCHING_ERROR_LOG, pricingTicketNumber), ex);
        }

        LOG.info(String.format(FETCH_PRICING_FILE_FROM_JIRA_LOG, pricingFileName));
        final Attachment attachment = pricingTicket.getAttachment(pricingFileName);
        if (Objects.isNull(attachment)) {
            Assert.fail(PRICING_FILE_NOT_FOUND_LOG);
        }

        LOG.info(PRICING_FILE_DOWNLOAD_LOG);
        final String tempPricingFilePath = String.format("%s/%s", DirectoryConstant.USER_DIR, pricingFileName);

        try {
            jiraService.downloadAttachment(attachment, tempPricingFilePath);
        } catch (HttpRequestException e) {
            Assert.fail(UNABLE_TO_DOWNLOAD_ATTACHMENT_LOG);
        }
//        final String pricingFileName = "/Users/ppatil/Desktop/PricingFiles/007/7003/BRE_7003_v3.csv";
        return BorrowerPricingCSVParser.parse(pricingFileName);
    }

    @Override
    @BeforeSuite
    protected void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @BeforeTest
    public final void initializePricingDataTest() throws HttpRequestException, AutomationException {
        System.setProperty(TestConstant.DATA_PROVIDER_THREAD_COUNT_STRING, "1");
    }

    protected final String buildValidationMessage(final String errorTemplate, final Object actual, final Object expected)
            throws AutomationException {
        String valueComparison;
        try {
            valueComparison = String.format("(actual/expected): %s/%s", actual.toString(), expected.toString());
        } catch (IllegalFormatException ex) {
            throw new AutomationException(ex.getMessage());
        }
        return String.format("%s %s", errorTemplate, valueComparison);
    }
}