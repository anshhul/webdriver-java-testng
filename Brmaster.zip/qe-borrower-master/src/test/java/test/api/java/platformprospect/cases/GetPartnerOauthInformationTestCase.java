package test.api.java.platformprospect.cases;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import test.BorrowerTestCase;
import com.prosper.automation.annotation.test.ProsperZephyr;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public interface GetPartnerOauthInformationTestCase extends BorrowerTestCase {

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Partner OAuth Information API Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/partner/security/:clientId http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    void testGetPartnerOAuthInformationHappyPath() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Partner OAuth Information API Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/partner/security/:clientId http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    void testGetNewPartnerOAuthInformationAfterSoftDelete() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Partner OAuth Information API With Empty Client ID Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [GET] /prospects/partner/security/:clientId http request."},
            expectedResult = "HTTP 500 Internal Server Error Response"
    )
    void testGetPartnerOAuthInformationWithEmptyClientID() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Get Partner OAuth Information API With Non Existing Client ID Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {
                    "Create [GET] /prospects/partner/security/:nonExistingClientId http request."},
            expectedResult = "HTTP 204 No Content Response"
    )
    void testGetPartnerOAuthInformationWithNonExistingClientID() throws AutomationException, HttpRequestException;
}
