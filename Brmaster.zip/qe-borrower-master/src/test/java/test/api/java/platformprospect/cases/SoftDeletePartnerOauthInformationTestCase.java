
package test.api.java.platformprospect.cases;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import test.BorrowerTestCase;
import com.prosper.automation.annotation.test.ProsperZephyr;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public interface SoftDeletePartnerOauthInformationTestCase extends BorrowerTestCase {
    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Soft Delete Partner OAuth Information API Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [DELETE] /prospects/partner/security/:partnerOauthId http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    void testSoftDeletePartnerOauthInfoHappyPath() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Soft Delete Partner OAuth Information API Sets VersionEndDate Field Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [DELETE] /prospects/partner/security/:partnerOauthId http request."},
            expectedResult = "VersionEndDate column field is set with correct value"
    )
    void testSoftDeletePartnerOauthInfoSetsVersionEndDateField() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Soft Delete Partner OAuth Information API With Non Existing Client ID Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [DELETE] /prospects/partner/security/:partnerOauthId http request."},
            expectedResult = "HTTP 400 Bad Request Response"
    )
    void testSoftDeletePartnerOauthInfoWithNonExistingClientID() throws AutomationException, HttpRequestException;
}
