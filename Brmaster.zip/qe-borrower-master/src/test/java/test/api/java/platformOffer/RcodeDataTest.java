
package test.api.java.platformOffer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.BureauRequest;
import com.prosper.automation.model.platform.pricing.BureauResponse;
import com.prosper.automation.model.platform.pricing.ScoreCardData;
import com.prosper.automation.parser.RcodeCSVParser;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.util.Rounding;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;


/**
 * Created by ppatil on 12/6/16.
 */
public final class RcodeDataTest extends RcodeDataTestBase {

    private static final Logger LOG = Logger.getLogger(RcodeDataTest.class.getSimpleName());

    @Autowired
    private IPlatformOffer pubSiteOfferService;

    @Test(dataProvider = BUREAU_DATA, alwaysRun = true)
    public void testRCodeScoreTest(final ScoreCardData scoreCardData) throws HttpRequestException, AutomationException {
        if (scoreCardData == null) {
            LOG.info("Score Data is  null");
            return;
        }

        final SoftAssert softAssert = new SoftAssert();
        BureauRequest bureauRequest = buildBureauRequestTU(scoreCardData);
        try {
            LOG.info("BureauRequest :" + (new ObjectMapper()).writeValueAsString(bureauRequest));
            final BureauResponse bureauResponse = pubSiteOfferService.calculateScoreCard(bureauRequest);
            if (bureauResponse != null) {
                LOG.info(MessageFormat.format("Probability Score RowId {0}: Actual PMI7Score: {1} , Expected PMI7Score: {2}", scoreCardData.getRowId(), bureauResponse.getProbabilityScore().toString(), scoreCardData.getPmi7Score().toString()));
                Assert.assertEquals(String.valueOf(bureauResponse.getProbabilityScore()).substring(0, 7),
                        String.valueOf(scoreCardData.getPmi7Score()).substring(0, 7), "Scores are not matching ");

             /*Logic for varifying the variables and weights.*/

                LOG.info(MessageFormat.format("Weights #1 RowId {0}: Actual Weight: {1} , Expected Weight: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(0).getWeight().toString(), scoreCardData.getAA_Weights_Var1().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(0).getWeight().toString().substring(0, 7), scoreCardData.getAA_Weights_Var1().toString().substring(0, 7), "Weights #1 are not matching ");
                LOG.info(MessageFormat.format("Weights #2 RowId {0}: Actual Weight: {1} , Expected Weight: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(1).getWeight().toString(), scoreCardData.getAA_Weights_Var2().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(1).getWeight().toString().substring(0, 7), scoreCardData.getAA_Weights_Var2().toString().substring(0, 7), "Weights #2 are not matching ");
                LOG.info(MessageFormat.format("Weights #3 RowId {0}: Actual Weight: {1} , Expected Weight: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(2).getWeight().toString(), scoreCardData.getAA_Weights_Var3().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(2).getWeight().toString().substring(0, 7), scoreCardData.getAA_Weights_Var3().toString().substring(0, 7), "Weights #3 are not matching ");
                LOG.info(MessageFormat.format("Weights #4 RowId {0}: Actual Weight: {1} , Expected Weight: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(3).getWeight().toString(), scoreCardData.getAA_Weights_Var4().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(3).getWeight().toString().substring(0, 7), scoreCardData.getAA_Weights_Var4().toString().substring(0, 7), "Weights #4 are not matching ");


                LOG.info(MessageFormat.format("VariableName #1 RowId {0}: Actual VarName: {1} , Expected  VarName: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(0).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var1().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(0).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var1(), "VariableNames #1 are not matching ");

                LOG.info(MessageFormat.format("VariableName #2 RowId {0}: Actual VarName: {1} , Expected  VarName: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(1).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var2().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(1).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var2(), "VariableNames #2 are not matching ");

                LOG.info(MessageFormat.format("VariableName #3 RowId {0}: Actual VarName: {1} , Expected  VarName: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(2).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var3().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(2).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var3(), "VariableNames #3 are not matching ");

                LOG.info(MessageFormat.format("VariableName #4 RowId {0}: Actual VarName: {1} , Expected  VarName: {2}", scoreCardData.getRowId(), bureauResponse.getTopFourReasons().get(3).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var4().toString()));
                Assert.assertEquals(bureauResponse.getTopFourReasons().get(3).getScoreVarType().getVariableName(), scoreCardData.getAA_Vars_Var4(), "VariableNames #4 are not matching");

            } else {
                LOG.info("Scorecard response is Null");
                LOG.info(MessageFormat.format("Probability Score RowId {0}: Expected : {1}", scoreCardData.getRowId(), scoreCardData.getPmi7Score()));
                LOG.info("BureauRequest :" + (new ObjectMapper()).writeValueAsString(bureauRequest));
                Assert.assertTrue(scoreCardData.getPmi7Score() == null, "Scores are not matching ");
            }
        } catch (Exception e) {
            LOG.info(MessageFormat.format("Caught Exception Probability Score RowId {0}: Expected : {1}", scoreCardData.getRowId(), scoreCardData.getPmi7Score()));
            Assert.assertTrue(scoreCardData.getPmi7Score() == null, "Scores are not matching ");
            try {
                LOG.info("BureauRequest :" + (new ObjectMapper()).writeValueAsString(bureauRequest));
            } catch (JsonProcessingException e1) {
                LOG.error(" Json Parse Exception :: ", e1);
            }
            LOG.error("Exception Handeling Catch:: ", e);
        }

    }

}

