
package test.api.java.platformMarketplaceClient.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import test.BorrowerTestCase;
import javax.ws.rs.NotAuthorizedException;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/11/16.
 */
public interface MarketplaceClientTestCase extends BorrowerTestCase {

	@Test
	@ProsperZephyr(project = BMP, testTitle = "Get offers using marketplace client service", priority = "P1", labels = {
			"qe_ecosystem_automation", "platform-marketplace-client" }, stepToTests = {
					"Get loan offers from marketplaceService client" }, expectedResult = "HTTP 200 OK Response with offers response")

	void testMarketplaceServiceUsingClient();

	@Test
	@ProsperZephyr(project = BMP, testTitle = "Get oauth token value using client id, secret and endpoint", priority = "P1", labels = {
			"qe_ecosystem_automation", "platform-marketplace-client" }, stepToTests = {
					"Get oauth token value by passing client id and secret" }, expectedResult = "HTTP 200 OK Response with token value")

	void testOauthServiceUsingClient();

	@Test
	@ProsperZephyr(project = BMP, testTitle = "Get unauthorized exception using marketplace client service", priority = "P1", labels = {
			"qe_ecosystem_automation", "platform-marketplace-client" }, stepToTests = {
					"Get loan offers from marketplaceService client without partner source code" }, expectedResult = "HTTP 401 Unauthorized Exception")

	void testMarketplaceServiceUsingClientForUnauthorizedException() throws NotAuthorizedException;
}
