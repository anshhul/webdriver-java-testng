package test.api.java.platformTransunion;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.mapper.ListingCreditReportMappingModel;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.listing.ListingCRMappingDTO;
import com.prosper.automation.model.platform.listing.ListingCreditReportMapping;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.platform.clients.PlatformListingImpl;
import com.prosper.automation.platform.interfaces.IPlatformListing;
import com.prosper.automation.tool.BorrowerDataService;
import com.prosper.automation.util.TimeUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by rchintapalli on 11/28/16.
 */
public class PatchListingCreditReportMappingTest extends PlatformTransunionTestBase {

    private static final Logger LOG = Logger.getLogger(PatchListingCreditReportMappingTest.class.getSimpleName());

    @Resource
    private BorrowerDataService borrowerDataService;

    @Test(groups = TestGroup.SANITY)
    public void patchIsDecisionBureauTest() throws HttpRequestException, AutomationException, JsonProcessingException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(userEmail, ProsperCreditGrade.NC);
        final IPlatformListing listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final Long listingId = borrowerTestData.getListingId().get(0);

        final ListingCreditReportMapping beforePatchMapping = listingService.getListingCreditReportMapping(listingId);
        final List<ListingCRMappingDTO> beforePatchMappingResponse = beforePatchMapping.getListingMappingResponse();
        final ListingCRMappingDTO beforePatchBureau1Mapping = beforePatchMappingResponse.get(0);
//        final ListingCRMappingDTO beforePatchBureau2Mapping = beforePatchMappingResponse.get(1);

        final ListingCRMappingDTO ListingCRMappingDTO;
        ListingCRMappingDTO = new ListingCRMappingDTO.Builder().
                withListingId(listingId).withCreditBureau(beforePatchBureau1Mapping.getCreditBureau()).
                withExternalCreditReportId(beforePatchBureau1Mapping.getExternalCreditReportId()).
                withIsDecisionBureau(!beforePatchBureau1Mapping.getIsDecisionBureau()).build();
        final Boolean isDecisionBureau = !beforePatchBureau1Mapping.getIsDecisionBureau();
        final ListingCreditReportMapping afterPatchMapping = listingService.patchListingCreditReportMapping(ListingCRMappingDTO);
        final List<ListingCRMappingDTO> afterPatchMappingResponse = afterPatchMapping.getListingMappingResponse();

        final ListingCRMappingDTO afterPatchBureau1Mapping = afterPatchMappingResponse.get(0);
//      ListingCRMappingDTO afterPatchBureau2Mapping = afterPatchMappingResponse.get(1);
        Assert.assertNotNull(afterPatchBureau1Mapping);

        final UUID reportId = beforePatchBureau1Mapping.getExternalCreditReportId();

        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final ListingCreditReportMappingModel listingCreditReportMappingModelTu =
                listingsDAO.getListingCreditReportMappingInfo(reportId.toString(), String.valueOf(listingId));

        new SimpleDateFormat("yyyy-MM-dd HH:mm");
        new Date();
        Assert.assertEquals(listingCreditReportMappingModelTu.getListingId(), listingId);
        Assert.assertEquals(("1").equals(listingCreditReportMappingModelTu.getIsDecisionBureau()) ? "true" : "false", isDecisionBureau.toString(), "First bureau isDecisionBureau response is not updated in DB correctly");
        Assert.assertTrue(
                listingCreditReportMappingModelTu.getUpdatedDate()
                        .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "First bureau isDecisionBureau response is not updated in DB correctly");

        //Verifying the second Credit bureau.If one is true the 2nd one should be false.
//        final UUID externalReportIdBureau2 = beforePatchBureau2Mapping.getExternalCreditReportId();
//        final Boolean isDecisionBureau2 = !isDecisionBureau;
//        final ListingCreditReportMappingModel listingCreditReportMappingModelEx =
//                listingsDAO.getListingCreditReportMappingInfo(externalReportIdBureau2.toString(), String.valueOf(listingId));
//        Assert.assertEquals(("1").equals(listingCreditReportMappingModelEx.getIsDecisionBureau()) ? "true" : "false", isDecisionBureau2.toString(), "Second bureau isDecisionBureau response is not updated in DB correctly");
//        Assert.assertTrue(
//                listingCreditReportMappingModelEx.getUpdatedDate().toString()
//                        .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
//                "Second bureau updatedDate  is not updated in DB correctly");


        Assert.assertNotEquals(beforePatchBureau1Mapping.getIsDecisionBureau(), afterPatchBureau1Mapping.getIsDecisionBureau());
//        Assert.assertNotEquals(beforePatchBureau2Mapping.getIsDecisionBureau(), afterPatchBureau2Mapping.getIsDecisionBureau());
    }

    @Test(groups = TestGroup.SANITY)
    public void patchExternalCreditReportIdTest() throws HttpRequestException, AutomationException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(userEmail, ProsperCreditGrade.NC);
        final IPlatformListing listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final Long listingId = borrowerTestData.getListingId().get(0);

        final ListingCreditReportMapping beforePatchMapping = listingService.getListingCreditReportMapping(listingId);
        final List<ListingCRMappingDTO> beforePatchMappingResponse = beforePatchMapping.getListingMappingResponse();
        final ListingCRMappingDTO beforePatchBureau1Mapping = beforePatchMappingResponse.get(0);

        final UUID randomExternalCreditReportId = UUID.randomUUID();

        final ListingCRMappingDTO ListingCRMappingDTO;
        ListingCRMappingDTO = new ListingCRMappingDTO.Builder().
                withListingId(listingId).withCreditBureau(beforePatchBureau1Mapping.getCreditBureau()).
                withExternalCreditReportId(randomExternalCreditReportId).
                withIsDecisionBureau(beforePatchBureau1Mapping.getIsDecisionBureau()).build();

        final ListingCreditReportMapping afterPatchMapping = listingService.patchListingCreditReportMapping(ListingCRMappingDTO);
        final List<ListingCRMappingDTO> afterPatchMappingResponse = afterPatchMapping.getListingMappingResponse();
        final ListingCRMappingDTO afterPatchBureau1Mapping = afterPatchMappingResponse.get(0);

        Assert.assertEquals(randomExternalCreditReportId, afterPatchBureau1Mapping.getExternalCreditReportId());
    }

    @Test(groups = TestGroup.SANITY, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ".*LST1003.*")
    public void patchIncorrectListingIdTest() throws HttpRequestException, AutomationException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(userEmail, ProsperCreditGrade.NC);
        final IPlatformListing listingService = new PlatformListingImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final Long listingId = 2 * borrowerTestData.getListingId().get(0);

        final ListingCreditReportMapping beforePatchMapping = listingService.getListingCreditReportMapping(listingId);
        final List<ListingCRMappingDTO> beforePatchMappingResponse = beforePatchMapping.getListingMappingResponse();
        final ListingCRMappingDTO beforePatchBureau1Mapping = beforePatchMappingResponse.get(0);

        listingService.patchListingCreditReportMapping(beforePatchBureau1Mapping);
    }

}
