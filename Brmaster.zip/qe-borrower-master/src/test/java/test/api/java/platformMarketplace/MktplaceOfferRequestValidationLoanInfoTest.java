
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationLoanInfoTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Negative tests for Loan Info Created by rsubramanyam on 2/20/16.
 */
public class MktplaceOfferRequestValidationLoanInfoTest extends MarketplaceOffersTestBase
        implements MktplaceOfferRequestValidationLoanInfoTestCase {

    private static final String LAMOUNT_IDENTIFIER = "loanAmount";
    private static final String LPURPOSE_IDENTIFIER = "loanPurposeId";
    private static final String CREDIT_SCORE_IDENTIFIER = "selfReportedCreditScore";
    @Autowired
    private IPlatformMarketplace marketplaceService;


    @DataProvider(name = "testloanInfo")
    public static Object[][] loanInfoTest() {
        return new Object[][] {{"35000.01", "3", "100", ResponseErrorsHelper.LOAN_AMOUNT_MORE_THAN_ALLOWED},
                {"1000", "1", "6", ResponseErrorsHelper.LOAN_AMOUNT_LESS_THAN_ALLOWED},
                {"-35.000", "3", "4", ResponseErrorsHelper.LOAN_AMOUNT_LESS_THAN_ALLOWED},
                {"-35", "3", "4", ResponseErrorsHelper.LOAN_AMOUNT_LESS_THAN_ALLOWED},
                // Invalid data
                {"A35000", "1", "6", ResponseErrorsHelper.LOAN_AMOUNT_INVALID},
                // Loan Purpose Id checks
                {"35000", ".1", "2", ResponseErrorsHelper.LOAN_PURPOSE_ID_INVALID},
                {"35000", "22", "2", ResponseErrorsHelper.LOAN_PURPOSE_ID_INVALID},
                {"35000", "0", "2", ResponseErrorsHelper.LOAN_PURPOSE_ID_INVALID},
                {"35000", "-1", "-6", ResponseErrorsHelper.LOAN_PURPOSE_ID_INVALID},
                {"35000", "A", "6", ResponseErrorsHelper.LOAN_PURPOSE_ID_INVALID},
                // Credit score checks
                {"35000", "1", "A", ResponseErrorsHelper.CREDIT_SCORE_INVALID},
                {"", "1", "-3", ResponseErrorsHelper.CREDIT_SCORE_INVALID},
                // BMP-2132
                // {"12", "", "6", ResponseErrorsHelper.CREDIT_SCORE_INVALID},
                // Empty
                {"", "1", "-3", ResponseErrorsHelper.LOAN_AMOUNT_NULL_OR_EMPTY},
                {"12", "", "6", ResponseErrorsHelper.LOAN_PURPOSE_ID_NOT_NULL_EMPTY},
                {"12000", "1", "", ResponseErrorsHelper.CREDIT_SCORE_NULL_EMPTY},
                // Null check
                {null, "A", "6", ResponseErrorsHelper.LOAN_AMOUNT_NULL_OR_EMPTY},
                {"35000", null, "-6", ResponseErrorsHelper.LOAN_PURPOSE_ID_NOT_NULL_EMPTY},
                {"35000", "1", null, ResponseErrorsHelper.CREDIT_SCORE_NULL_EMPTY}};
    }

    @DataProvider(name = "testMissingLoanInfo")
    public static Object[][] loanInfoMissingTest() {
        return new Object[][] {
                // Missing loan amount
                {LAMOUNT_IDENTIFIER, ResponseErrorsHelper.LOAN_AMOUNT_NULL_OR_EMPTY},
                // Missing loan purpose id
                {LPURPOSE_IDENTIFIER, ResponseErrorsHelper.LOAN_PURPOSE_ID_NOT_NULL_EMPTY}};
    }

    @Override
    @Test(dataProvider = "testloanInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testloanInfoWithParameters(String loanAmount, String loanPurposeId,
                                           String selfReportedCreditScore,
                                           ResponseErrorsHelper expectedError)
                                                   throws AutomationException, HttpRequestException {
        LoanInfo info = new LoanInfo.LoanInfoBuilder().withLoanAmount(loanAmount).withLoanPurpose(loanPurposeId)
                .withSelfReportedCreditScore(selfReportedCreditScore).build();

        validateResponseForLoanInfo(info, expectedError, true);
    }

    @Override
    @Test(dataProvider = "testMissingLoanInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testLoanInfoWithMissingParameters(String fieldName,
                                                  ResponseErrorsHelper expectedError)
                                                          throws AutomationException, HttpRequestException {
        LoanInfo info = buildInfo(fieldName);
        validateResponseForLoanInfo(info, expectedError, true);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testValidationSuccessNoOffersWithDoubleLoanAmount() throws AutomationException, HttpRequestException {
        LoanInfo info = new LoanInfo.LoanInfoBuilder().withLoanAmount("3560.15").withLoanPurpose("1")
                .withSelfReportedCreditScore("1").build();
        validateResponseForLoanInfo(info, ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    private void validateResponseForLoanInfo(LoanInfo info, ResponseErrorsHelper expectedError, boolean doVerifyAssertions)
            throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode())).withLoanInfo(info)
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo())
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();

        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, expectedError, doVerifyAssertions);
    }

    private LoanInfo buildInfo(String fieldName) {
        if (fieldName.equalsIgnoreCase(LAMOUNT_IDENTIFIER))
            return new LoanInfo.LoanInfoBuilder().withLoanPurpose(TestDataProviderUtil.TEST_DATA_LOAN_PURPOSE)
                    .withSelfReportedCreditScore(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE).build();
        if (fieldName.equalsIgnoreCase(LPURPOSE_IDENTIFIER))
            return new LoanInfo.LoanInfoBuilder().withLoanAmount(TestDataProviderUtil.TEST_DATA_LOAN_AMOUNT)
                    .withSelfReportedCreditScore(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                    .build();
        if (fieldName.equalsIgnoreCase(CREDIT_SCORE_IDENTIFIER))
            return new LoanInfo.LoanInfoBuilder().withLoanPurpose(TestDataProviderUtil.TEST_DATA_LOAN_PURPOSE)
                    .withLoanAmount(TestDataProviderUtil.TEST_DATA_LOAN_AMOUNT).build();
        return TestDataProviderUtil.getValidLoanInfo();
    }
}
