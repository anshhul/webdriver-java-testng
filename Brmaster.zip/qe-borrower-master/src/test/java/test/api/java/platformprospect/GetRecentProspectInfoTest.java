package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.inquiry.PlatformProspectInquiryDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.RecentProspectInfo;
import com.prosper.automation.model.platform.user.ProspectToBorrowerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by rsubramanyam on 4/20/16.
 */
public class GetRecentProspectInfoTest extends PlatformProspectTestBase
        implements test.api.java.platformprospect.cases.GetRecentProspectInfoTestCase {
    private static final double LOAN_AMOUNT = 5000;

    private static final long LOAN_PURPOSE_ID = 1;
    private static final long LISTING_CATEGORY_ID = 2;

    private ProspectRequest prospectRequest;
    private String testEmail;

    @Autowired CloseableJdbcConnection circleOneDBConnection;

    @BeforeMethod
    public void setupTestData() throws AutomationException, HttpRequestException {
        testEmail = Constant.getGloballyUniqueEmail();
        prospectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, testEmail);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetRecentProspectInfo() throws AutomationException, HttpRequestException {
        ProspectToBorrowerResponse
                response = runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
        updateTermApprovalDate(response.getListingId());

        String offerId = getOfferId(response.getUserId().toString());

        // Add 5 days to now
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);
        String approvalDateInMillis = String.valueOf(c.getTime().getTime());

        // Hit endpoint
        RecentProspectInfo info = internalProspectService.getRecentProspectInfo(response.getListingId().toString(), response.getUserId().toString(), offerId, approvalDateInMillis);
        // Verify campaign name, channel name
        ProspectDAO dao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        String campaignProgramId = dao.getCampaignProgramId(response.getUserId());
        Assert.assertEquals(info.getCampaignChannelName(), dao.getCampaignChannelName(campaignProgramId));
        Assert.assertEquals(info.getCampaignName(), dao.getCampaignName(campaignProgramId));
    }

    private String getOfferId(String userId) {
        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        return prospectDao.getOfferCodeByUserId(userId);
    }

    private void updateTermApprovalDate(long listingId) {
        PlatformProspectInquiryDAO dao = circleOneDBConnection.getDataAccessObject(PlatformProspectInquiryDAO.class);
        dao.updateTermsApprovalDate(listingId);
        Assert.assertNotNull(dao.getTermsApprovalDate(listingId));
    }

}
