
package test.api.java.platformOffer;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.offer.OfferRateDetail;
import com.prosper.automation.model.platform.offer.RateResponse;
import com.prosper.automation.model.platform.offer.RateResult;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by pbudiono on 5/31/16.
 */
public final class GetRateTest extends PlatformOfferTestBase {

    private static final Double VALID_LOAN_AMOUNT = 10000.0;
    private static final Double NEGATIVE_REQUESTED_LOAN_AMOUNT = -10000.;
    private static final Double INVALID_LOAN_AMOUNT = 35001.;

    private static final Integer INVALID_FICO_CREDIT_SCORE = 851;
    private static final Integer VALID_FICO_CREDIT_SCORE = 850;
    private static final Integer NEGATIVE_CREDIT_SCORE = -1;

    private static final Double EXPECTED_MIN_APR = 5.99;
    private static final Double EXPECTED_MAX_APR = 8.88;


    @Override
    @BeforeSuite(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetRateWithValidQueryParameters() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(VALID_FICO_CREDIT_SCORE, VALID_LOAN_AMOUNT);

        Assert.assertNotNull(rateResponse.getRateResult());
        Assert.assertEquals(rateResponse.getResultCount(), 1, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 1, "Total count does not match.");

        final List<RateResult> rateResults = rateResponse.getRateResult();

        Assert.assertNotNull(rateResults, "Rate result is null.");
        Assert.assertEquals(rateResults.size(), 1, "Rate result count is not one.");

        final List<OfferRateDetail> offerRateDetails = rateResults.get(0).getOfferRateDetail();
        Assert.assertNotNull(offerRateDetails, "Offer rate details is null.");
        Assert.assertEquals(offerRateDetails.size(), 1, "Offer rate details is not one.");

        final OfferRateDetail offerRateDetail = offerRateDetails.get(0);
        Assert.assertEquals(offerRateDetail.getMinimumAPR(), EXPECTED_MIN_APR, "Minimum APR does not match.");
        Assert.assertEquals(offerRateDetail.getMaximumAPR(), EXPECTED_MAX_APR, "Maximum APR does not match.");
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, enabled = false)
    public void testGetRateWithInvalidFICOCreditScore() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(INVALID_FICO_CREDIT_SCORE, VALID_LOAN_AMOUNT);

        Assert.assertNull(rateResponse.getRateResult());

        Assert.assertEquals(rateResponse.getResultCount(), 0, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 0, "Total count does not match.");
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, enabled = false)
    public void testGetRateWithNegativeCreditScoreValue() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(NEGATIVE_CREDIT_SCORE, VALID_LOAN_AMOUNT);

        Assert.assertNull(rateResponse.getRateResult());

        Assert.assertEquals(rateResponse.getResultCount(), 0, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 0, "Total count does not match.");
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, enabled = false)
    public void testGetRateWithNegativeRequestedLoanAmount() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(VALID_FICO_CREDIT_SCORE, NEGATIVE_REQUESTED_LOAN_AMOUNT);

        Assert.assertNull(rateResponse.getRateResult());

        Assert.assertEquals(rateResponse.getResultCount(), 0, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 0, "Total count does not match.");
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, enabled = false)
    public void testGetRateWithInvalidRequestedLoanAmount() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(VALID_FICO_CREDIT_SCORE, INVALID_LOAN_AMOUNT);

        Assert.assertNull(rateResponse.getRateResult());

        Assert.assertEquals(rateResponse.getResultCount(), 0, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 0, "Total count does not match.");
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, enabled = false)
    public void testGetRateWithoutCreditScoreAndLoanAmount() throws AutomationException, HttpRequestException {
        final RateResponse rateResponse = pubSiteOfferService.getRate(null, null);

        Assert.assertEquals(rateResponse.getResultCount(), 9, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 63, "Total count does not match.");
    }

    @Test(dataProvider = RATE_API_SEED_DATA, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testAPRValuesOnCreditScoreRanges(final RateTestData testData) throws AutomationException, HttpRequestException {
        final RateResponse rateResponse =
                pubSiteOfferService.getRate(testData.getCreditScore(), testData.getRequestedLoanAmount());

        Assert.assertEquals(rateResponse.getResultCount(), 1, "Result count does not match.");
        Assert.assertEquals(rateResponse.getTotalCount(), 1, "Total count does not match.");

        final List<RateResult> rateResults = rateResponse.getRateResult();

        Assert.assertNotNull(rateResults, "Rate result is null.");
        Assert.assertEquals(rateResults.size(), 1, "Rate result count is not one.");

        final List<OfferRateDetail> offerRateDetails = rateResults.get(0).getOfferRateDetail();
        Assert.assertNotNull(offerRateDetails, "Offer rate details is null.");
        Assert.assertEquals(offerRateDetails.size(), 1, "Offer rate details is not one.");

        final OfferRateDetail offerRateDetail = offerRateDetails.get(0);
        Assert.assertEquals(offerRateDetail.getMinimumAPR(), testData.getMinimumAPR(), "Minimum APR does not match.");
        Assert.assertEquals(offerRateDetail.getMaximumAPR(), testData.getMaximumAPR(), "Maximum APR does not match.");
    }
}
