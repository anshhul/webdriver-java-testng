package test.api.java.platformUser;

import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.platform.interfaces.IPlatformUser;
import com.prosper.automation.test.TestBase;
import com.prosper.automation.tool.BorrowerDataService;

import javax.annotation.Resource;

/**
 * Created by pbudiono on 8/16/16.
 */
public class PlatformUserTestBase extends TestBase {

	protected BorrowerTestData borrowerTestData;

	@Resource
	protected IPlatformUser pubSiteUserService;

	@Resource
	protected BorrowerDataService borrowerDataService;

	@Resource
	protected HttpClientConfig platformPublicServiceConfig;

	@Resource
	protected CloseableJdbcConnection circleOneDBConnection;


}
