package test.api.java.platformCampaign;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class DeleteCampaignTest extends PlatformCampaignTestBase {

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testDeleteCampaignInvalid() throws AutomationException, HttpRequestException {
        internalCampaignService.deleteCampaign("INVALID");
    }
}

