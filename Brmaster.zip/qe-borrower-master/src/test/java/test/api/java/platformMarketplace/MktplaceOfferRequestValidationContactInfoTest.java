
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationContactInfoTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public class MktplaceOfferRequestValidationContactInfoTest extends MarketplaceOffersTestBase implements
        MktplaceOfferRequestValidationContactInfoTestCase {

    private static final String EMAIL_ADDRESS = "email";
    @Autowired
    private IPlatformMarketplace marketplaceService;


    @DataProvider(name = "testContactInfo")
    public static Object[][] contactInfoTest() {
        return new Object[][] {
                {"@", PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, ResponseErrorsHelper.EMAIL_INVALID},
                {"a", PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, ResponseErrorsHelper.EMAIL_INVALID}};
    }

    @DataProvider(name = "testMissingContactInfo")
    public static Object[][] contactInfoMissingTest() {
        return new Object[][] {
                // Missing email
                {"email", ResponseErrorsHelper.EMAIL_NULL_EMPTY},};
    }

    @DataProvider(name = "testWrongOptionalParams")
    public static Object[][] phoneInfoTest() {
        return new Object[][] {
                {TestDataProviderUtil.TEST_DATA_EMP_EMAIL, new PhoneNumber.Builder().withPhoneNumber("56789").build(),
                        PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        ResponseErrorsHelper.NO_MATCHING_OFFERS},
                {TestDataProviderUtil.TEST_DATA_EMP_EMAIL, PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        new PhoneNumber.Builder().withPhoneNumber("56789").build(),
                        PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER, ResponseErrorsHelper.NO_MATCHING_OFFERS},
                {TestDataProviderUtil.TEST_DATA_EMP_EMAIL, PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER,
                        new PhoneNumber.Builder().withPhoneNumber("56789").build(), ResponseErrorsHelper.NO_MATCHING_OFFERS}};
    }

    @Override
    @Test(dataProvider = "testContactInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testContactInfoWithParameters(String emailAddress,
                                              PhoneNumber homePnumber,
                                              PhoneNumber workPnumber,
                                              PhoneNumber mobilePnumber,
                                              ResponseErrorsHelper expectedError)
                                                      throws AutomationException, HttpRequestException {
        ContactInfo info = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailAddress).withHomePhoneNumber(homePnumber)
                .withWorkPhoneNumber(workPnumber).withMobilePhoneNumber(mobilePnumber).build();
        validateResponseForContactInfo(info, expectedError, true);
    }

    @Override
    @Test(dataProvider = "testMissingContactInfo", groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testContactInfoWithMissingParameters(String fieldName,
                                                     ResponseErrorsHelper expectedError)
                                                             throws AutomationException, HttpRequestException {
        ContactInfo info = buildInfo(fieldName);
        validateResponseForContactInfo(info, expectedError, true);
    }

    @Override
    @Test(dataProvider = "testWrongOptionalParams", groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testPhoneInfoWithParameters(String emailAddress, PhoneNumber homePnumber,
                                            PhoneNumber workPnumber, PhoneNumber mobilePnumber,
                                            ResponseErrorsHelper expectedError)
                                                    throws AutomationException, HttpRequestException {
        ContactInfo info = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailAddress).withHomePhoneNumber(homePnumber)
                .withWorkPhoneNumber(workPnumber).withMobilePhoneNumber(mobilePnumber).build();
        validateResponseForContactInfo(info, expectedError, false);
    }

    private void validateResponseForContactInfo(ContactInfo info, ResponseErrorsHelper expectedError, boolean doVerifyAssertions)
            throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo()).withContactInfo(info)
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo())
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();

        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, expectedError, doVerifyAssertions);
    }

    private ContactInfo buildInfo(String fieldName) {
        if (fieldName.equalsIgnoreCase(EMAIL_ADDRESS))
            return new ContactInfo.ContactInfoBuilder()
                    .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                    .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                    .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        return TestDataProviderUtil.getValidContactInfo();
    }
}
