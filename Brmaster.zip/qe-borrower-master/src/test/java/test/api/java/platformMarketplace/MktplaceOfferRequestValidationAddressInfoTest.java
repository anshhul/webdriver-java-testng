package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationAddressInfoTestCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 2/21/16.
 */
public class MktplaceOfferRequestValidationAddressInfoTest extends MarketplaceOffersTestBase implements
        MktplaceOfferRequestValidationAddressInfoTestCase {

    @Autowired private IPlatformMarketplace marketplaceService;
    private static final String STREET = "street";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String ZIP = "zip";

    @DataProvider(name = "testAddressInfo") public static Object[][] addressInfoTest() {
        return new Object[][] {
                // Invalid Zip
                {"221 Main Street", "Sf", "t", "76850\\-6789", ResponseErrorsHelper.ZIPCODE_INVALID},
                // Character zip
                {"221 Main Street", "Sf", "t", "76850-a567", ResponseErrorsHelper.ZIPCODE_INVALID},
                {"221 Main Street", "Sf", "t", "7685", ResponseErrorsHelper.ZIPCODE_INVALID},
                // State invalid
                {"221 Main Street", "Sf", "1+=?$^*&()#@$!~23", "76853", ResponseErrorsHelper.STATE_INVALID},
                // PO Box Address
                {"PO BOX 59", "Sf", "t", "76850", ResponseErrorsHelper.PO_BOX_ERROR},
                // Empty params
                {"", "Sf", "t", "76850", ResponseErrorsHelper.STREET_NULL_EMPTY},
                {"A", "", "TX", "76850", ResponseErrorsHelper.CITY_NULL_EMPTY},
                {"A", "A", "", "76850", ResponseErrorsHelper.STATE_NULL_EMPTY},
                {"a", "Sf", "t", "", ResponseErrorsHelper.ZIPCODE_NULL_EMPTY},
                // For checking the count of error messages
                {"", "", "", "", ResponseErrorsHelper.STREET_NULL_EMPTY},};
    }

    @Override @Test(dataProvider = "testAddressInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) public void testAddressInfoWithParameters(String street, String city,
                                                                                                String state, String zipcode,
                                                                                                ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        AddressInfo info = new AddressInfo.AddressForMarketplaceinfoBuilder().withCity(city).
                withState(state).withStreet(street).withZip(zipcode).build();
        validateResponseForAddressInfo(info, expectedError, true);
    }

    @DataProvider(name = "testMissingAddressInfo") public static Object[][] addressInfoMissingTest() {
        return new Object[][] {
                // Missing address info values
                {STREET, ResponseErrorsHelper.STREET_NULL_EMPTY},
                {CITY, ResponseErrorsHelper.CITY_NULL_EMPTY},
                {STATE, ResponseErrorsHelper.STATE_NULL_EMPTY},
                {ZIP, ResponseErrorsHelper.ZIPCODE_NULL_EMPTY},};
    }

    @Override @Test(dataProvider = "testMissingAddressInfo") public void testAddressInfoWithMissingParameters(String fieldName,
                                                                                                              ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        AddressInfo info = buildInfo(fieldName);
        validateResponseForAddressInfo(info, expectedError, true);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) public void testValidationSuccessWithValidLongZipNoOffers() throws AutomationException, HttpRequestException {
        AddressInfo info = new AddressInfo.
                AddressForMarketplaceinfoBuilder().
                withCity(TestDataProviderUtil.TEST_DATA_ADDRESS_CITY).
                withState(TestDataProviderUtil.TEST_DATA_ADDRESS_STATE).
                withStreet(TestDataProviderUtil.TEST_DATA_ADDRESS_STREET).
                withZip(TestDataProviderUtil.TEST_DATA_ADDRESS_LONG_ZIP).build();
        validateResponseForAddressInfo(info, ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) public void testValidationSuccessWithNoAddress() throws AutomationException, HttpRequestException {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).
                        withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.ADDRESS_NULL_EMPTY, true);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) public void testValidationSuccessWithValidZipWithoutDashesLongStateNameAndNonExistingStreet() throws AutomationException, HttpRequestException {
        AddressInfo info = new AddressInfo.
                AddressForMarketplaceinfoBuilder().
                withCity(TestDataProviderUtil.TEST_DATA_ADDRESS_CITY).
                withState(TestDataProviderUtil.TEST_DATA_LONG_STATE).
                withStreet(TestDataProviderUtil.TEST_DATA_ADDRESS__NON_EXISTING_STREET).
                withZip(TestDataProviderUtil.TEST_DATA_ADDRESS_LONG_ZIP_NO_DASH).build();
        validateResponseForAddressInfo(info, ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    private void validateResponseForAddressInfo(AddressInfo info, ResponseErrorsHelper expectedError, boolean doVerifyAssertions)
            throws AutomationException, HttpRequestException {
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder().
                withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode())).
                withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).
                withAddressInfo(info).
                withBankAccountInfo(TestDataProviderUtil.getValidBankInfo()).
                withContactInfo(TestDataProviderUtil.getValidContactInfo()).
                withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).
                withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();

        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, expectedError, doVerifyAssertions);
    }

    private AddressInfo buildInfo(String fieldName) {
        if (fieldName.equalsIgnoreCase(STREET))
            return new AddressInfo.AddressForMarketplaceinfoBuilder().
                    withCity(TestDataProviderUtil.TEST_DATA_ADDRESS_CITY).
                    withState(TestDataProviderUtil.TEST_DATA_ADDRESS_STATE).
                    withZip(TestDataProviderUtil.TEST_DATA_ADDRESS_ZIP).build();
        if (fieldName.equalsIgnoreCase(CITY))
            return new AddressInfo.AddressForMarketplaceinfoBuilder().
                    withStreet(TestDataProviderUtil.TEST_DATA_ADDRESS_STREET).
                    withState(TestDataProviderUtil.TEST_DATA_ADDRESS_STATE).
                    withZip(TestDataProviderUtil.TEST_DATA_ADDRESS_ZIP).build();
        if (fieldName.equalsIgnoreCase(STATE))
            return new AddressInfo.AddressForMarketplaceinfoBuilder().
                    withStreet(TestDataProviderUtil.TEST_DATA_ADDRESS_STREET).
                    withCity(TestDataProviderUtil.TEST_DATA_ADDRESS_CITY).
                    withZip(TestDataProviderUtil.TEST_DATA_ADDRESS_ZIP).build();
        if (fieldName.equalsIgnoreCase(ZIP))
            return new AddressInfo.AddressForMarketplaceinfoBuilder().
                    withStreet(TestDataProviderUtil.TEST_DATA_ADDRESS_STREET).
                    withCity(TestDataProviderUtil.TEST_DATA_ADDRESS_CITY).
                    withState(TestDataProviderUtil.TEST_DATA_ADDRESS_STATE).build();

        return TestDataProviderUtil.getValidAddressInfo();
    }
}
