package test.api.java.platformUser;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpConflictException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.user.UserCreditReportMappingRequest;
import com.prosper.automation.model.platform.user.UserCreditReportMappingRequestDTO;
import com.prosper.automation.model.platform.user.UserModelReportMappingRequest;
import com.prosper.automation.model.platform.user.UserModelReportMappingResponse;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.platform.clients.PlatformUserImpl;
import com.prosper.automation.platform.interfaces.IPlatformUser;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by rchintapalli on 12/02/16.
 */
public class UserModelReportMappingTest extends PlatformUserTestBase {

    private static final Logger LOG = Logger.getLogger(UserModelReportMappingTest.class.getSimpleName());

    @Test(groups = {TestGroup.SANITY})
    public void postUserModelReportMappingTest() throws AutomationException, HttpRequestException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final Map<String, String> userData = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.NC);
        final BorrowerTestData.Builder borrowerTestDataBuilder = new BorrowerTestData.Builder()
                .withEmail(userEmail)
                .withUserData(userData);
        final UserRequest userRequest = borrowerDataService.buildGenericUserRequest(userEmail, userData);
        final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);
        borrowerTestDataBuilder.withUserId(userResponse.getUserRequest().getUserId());
        final Long userId = userResponse.getUserRequest().getUserId();
        final IPlatformUser userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        final UUID externalCreditReportId = UUID.randomUUID();
        final UserCreditReportMappingRequestDTO userCreditReportMappingRequestDTO = new UserCreditReportMappingRequestDTO.Builder().
                withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).withIsDecisionBureau(true).
                withCreditPullDate(new Date()).build();
        final List requestList = new ArrayList<UserCreditReportMappingRequestDTO>();
        requestList.add(userCreditReportMappingRequestDTO);
        final UserCreditReportMappingRequest userCreditReportMappingRequest = new UserCreditReportMappingRequest.Builder().
                withUserCreditReportMappingRequestDTO(requestList).withEntityCount(0).withEntityTotalCount(0).build();
        userService.postUserCreditReportMapping(userCreditReportMappingRequest);

        final UUID externalModelReportId = UUID.randomUUID();
        final UserModelReportMappingRequest userModelReportMappingRequest = new UserModelReportMappingRequest.Builder().
                withExternalCreditReportId(externalCreditReportId).withExternalModelReportId(externalModelReportId).build();
        final UserModelReportMappingResponse userModelReportMappingResponse = userService.postUserModelReportMapping(userModelReportMappingRequest);

        Assert.assertNotNull(userModelReportMappingResponse);
        Assert.assertEquals(0,userModelReportMappingResponse.getExternalCreditReportId().compareTo(externalCreditReportId), "Credit report ID not matching");
        Assert.assertEquals(0,userModelReportMappingResponse.getExternalModelReportId().compareTo(externalModelReportId), "Model report ID not matching");

        final UserDAO userDAO = circleOneDBConnection.getDataAccessObject(UserDAO.class);
        final String externalUserId = userDAO.getExternalUserId(userId);
        Assert.assertEquals(externalUserId.toLowerCase(),String.valueOf(userModelReportMappingResponse.getExternalUserId()), "External UserId not matching");
    }

    @Test(groups = {TestGroup.SANITY}, expectedExceptions = HttpConflictException.class, expectedExceptionsMessageRegExp = ".*USR2013.*")
    public void postUserModelReportMappingWithExistingIdTest() throws AutomationException, HttpRequestException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final Map<String, String> userData = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.NC);
        final BorrowerTestData.Builder borrowerTestDataBuilder = new BorrowerTestData.Builder()
                .withEmail(userEmail)
                .withUserData(userData);
        final UserRequest userRequest = borrowerDataService.buildGenericUserRequest(userEmail, userData);
        final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);
        borrowerTestDataBuilder.withUserId(userResponse.getUserRequest().getUserId());

        final IPlatformUser userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        final UUID externalCreditReportId = UUID.randomUUID();
        final UserCreditReportMappingRequestDTO userCreditReportMappingRequestDTO = new UserCreditReportMappingRequestDTO.Builder().
                withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).withIsDecisionBureau(true).
                withCreditPullDate(new Date()).build();
        final List requestList = new ArrayList<UserCreditReportMappingRequestDTO>();
        requestList.add(userCreditReportMappingRequestDTO);
        final UserCreditReportMappingRequest userCreditReportMappingRequest = new UserCreditReportMappingRequest.Builder().
                withUserCreditReportMappingRequestDTO(requestList).withEntityCount(0).withEntityTotalCount(0).build();
        userService.postUserCreditReportMapping(userCreditReportMappingRequest);

        final UUID externalModelReportId = UUID.randomUUID();
        final UserModelReportMappingRequest userModelReportMappingRequest = new UserModelReportMappingRequest.Builder().
                withExternalCreditReportId(externalCreditReportId).withExternalModelReportId(externalModelReportId).build();
        userService.postUserModelReportMapping(userModelReportMappingRequest);
        userService.postUserModelReportMapping(userModelReportMappingRequest);
    }

    @Test(groups = {TestGroup.SANITY})
    public void getUserModelReportMappingTest() throws AutomationException, HttpRequestException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final Map<String, String> userData = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA);
        final BorrowerTestData.Builder borrowerTestDataBuilder = new BorrowerTestData.Builder()
                .withEmail(userEmail)
                .withUserData(userData);
        final UserRequest userRequest = borrowerDataService.buildGenericUserRequest(userEmail, userData);
        final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);
        borrowerTestDataBuilder.withUserId(userResponse.getUserRequest().getUserId());
        final Long userId = userResponse.getUserRequest().getUserId();
        final IPlatformUser userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);

        final UUID externalCreditReportId = UUID.randomUUID();
        final UserCreditReportMappingRequestDTO userCreditReportMappingRequestDTO = new UserCreditReportMappingRequestDTO.Builder().
                withExternalCreditReportId(externalCreditReportId).withCreditBureau(Constant.CREDIT_BUREAU_TU).withIsDecisionBureau(true).
                withCreditPullDate(new Date()).build();
        final List requestList = new ArrayList<UserCreditReportMappingRequestDTO>();
        requestList.add(userCreditReportMappingRequestDTO);
        final UserCreditReportMappingRequest userCreditReportMappingRequest = new UserCreditReportMappingRequest.Builder().
                withUserCreditReportMappingRequestDTO(requestList).withEntityCount(0).withEntityTotalCount(0).build();
        userService.postUserCreditReportMapping(userCreditReportMappingRequest);

        final UUID externalModelReportId = UUID.randomUUID();
        final UserModelReportMappingRequest userModelReportMappingRequest = new UserModelReportMappingRequest.Builder().
                withExternalCreditReportId(externalCreditReportId).withExternalModelReportId(externalModelReportId).build();
        userService.postUserModelReportMapping(userModelReportMappingRequest);

        final UserModelReportMappingResponse userModelReportMappingResponse = userService.getUserModelReportMapping(externalCreditReportId);


        Assert.assertNotNull(userModelReportMappingResponse);
        Assert.assertEquals(0,userModelReportMappingResponse.getExternalCreditReportId().compareTo(externalCreditReportId), "Credit report ID not matching");
        Assert.assertEquals(0,userModelReportMappingResponse.getExternalModelReportId().compareTo(externalModelReportId), "Model report ID not matching");

        final UserDAO userDAO = circleOneDBConnection.getDataAccessObject(UserDAO.class);
        final String externalUserId = userDAO.getExternalUserId(userId);
        Assert.assertEquals(externalUserId.toLowerCase(),String.valueOf(userModelReportMappingResponse.getExternalUserId()), "External UserId not matching");
    }

    @Test(groups = {TestGroup.SANITY},expectedExceptions = HttpNotFoundException.class,expectedExceptionsMessageRegExp = ".*USR2012.*")
    public void getUserModelReportMappingWithInvalidIdTest() throws AutomationException, HttpRequestException {
        final String userEmail = Constant.getGloballyUniqueEmail();
        final Map<String, String> userData = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.NC);
        final BorrowerTestData.Builder borrowerTestDataBuilder = new BorrowerTestData.Builder()
                .withEmail(userEmail)
                .withUserData(userData);
        final UserRequest userRequest = borrowerDataService.buildGenericUserRequest(userEmail, userData);
        final UserResponse userResponse = pubSiteUserService.createBorrower(userRequest);
        borrowerTestDataBuilder.withUserId(userResponse.getUserRequest().getUserId());
        final IPlatformUser userService = new PlatformUserImpl(platformPublicServiceConfig, userEmail, Constant.COMMON_PASSWORD);
        final UUID externalCreditReportId = UUID.randomUUID();
        userService.getUserModelReportMapping(externalCreditReportId);
   }


}
