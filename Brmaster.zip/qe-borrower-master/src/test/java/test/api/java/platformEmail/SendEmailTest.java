
package test.api.java.platformEmail;

import com.google.common.collect.Lists;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessage;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.UUID;

/**
 * Created by pbudiono on 7/21/16.
 */
public final class SendEmailTest extends PlatformEmailTestBase {

    private static final Integer EMAIL_SUBJECT_LENGTH = 10;


    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendAsynchronousEmail() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail(true);
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        pubSiteEmailService.sendEmail(createGenericEmailMessage(emailAddress, emailSubject), true);
        assertEmailIsReceived(emailAddress, emailSubject);
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendSynchronousEmail() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail(true);
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        pubSiteEmailService.sendEmail(createGenericEmailMessage(emailAddress, emailSubject), false);
        assertEmailIsReceived(emailAddress, emailSubject);

    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendEmailPersistCorrectTemplateCode() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        final String templateCode = Constant.getRandomIntegerString(10);
        emailMessageRequest.setTemplateCode(templateCode);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getTemplateCode(), templateCode);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendEmailPersistCorrectLegacyTemplateId() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        final Integer legacyTemplateId = 7;
        emailMessageRequest.setLegacyTemplateId(legacyTemplateId);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getLegacyTemplateId(), legacyTemplateId);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendEmailPersistCorrectIsShownOnPublicSiteFlag()
            throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        final Boolean isShownToPublicSite = true;
        emailMessageRequest.setIsShownToPublicSite(isShownToPublicSite);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getIsShownOnPublicSite(), isShownToPublicSite);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendEmailPersistCorrectIsSentExternallyFlag()
            throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        final Boolean isSentExternally = true;
        emailMessageRequest.setIsSentExternally(isSentExternally);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getIsSentExternally(), isSentExternally);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendEmailPersistCorrectEmailMetadata() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());

        Assert.assertEquals(emailMessageResponse.getToAddress(), emailMessageRequest.getToAddress());
        Assert.assertEquals(emailMessageResponse.getFromAddress(), emailMessageRequest.getFromAddress());
        Assert.assertEquals(emailMessageResponse.getSubject(), emailMessageRequest.getSubject());
        Assert.assertEquals(emailMessageResponse.getMessage(), emailMessageRequest.getMessage());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendProspectBaseEmailReference() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        emailMessageRequest.setReferenceType(PROSPECT_REF_TYPE);
        emailMessageRequest.setReferenceId(UUID.randomUUID().toString());

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getReferenceType(), emailMessage.getReferenceType());
        Assert.assertEquals(emailMessageResponse.getReferenceId(), emailMessage.getReferenceId());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendUserBaseEmailReference() throws AutomationException, HttpRequestException {
        final String emailAddress = Constant.getGloballyUniqueEmail();
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(emailAddress, emailSubject);

        emailMessageRequest.setReferenceType(USER_REF_TYPE);
        emailMessageRequest.setReferenceId(REFERENCE_ID);

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertEquals(emailMessageResponse.getReferenceType(), emailMessage.getReferenceType());
        Assert.assertEquals(emailMessageResponse.getReferenceId(), emailMessage.getReferenceId());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSendBCCEmail() throws AutomationException, HttpRequestException {

        final String toEmailAddress = DEFAULT_FROM_EMAIL;
        final String emailSubject = Constant.getStringWithLength(EMAIL_SUBJECT_LENGTH);

        final EmailMessage emailMessageRequest = createGenericEmailMessage(toEmailAddress, emailSubject);

        final List<String> bccEmailAddress = Lists.newArrayList(
                Constant.getGloballyUniqueEmail(true),
                Constant.getGloballyUniqueEmail(true),
                Constant.getGloballyUniqueEmail(true));
        emailMessageRequest.setBccAddress(Lists.newArrayList(bccEmailAddress));

        final EmailMessage emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, true);
        Assert.assertNotNull(emailMessage);
    }
}
