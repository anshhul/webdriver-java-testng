package test.api.java.platformUser;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.user.AppResumeLoginResponse;
import org.testng.annotations.Test;
import com.prosper.automation.platform.clients.PlatformUserImpl;
import org.apache.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;

/**
 * Created by ppatil on 11/6/16.
 */
public final class AppResumeAltKeyLoginTest extends PlatformUserTestBase {

    protected static final Logger LOG = Logger.getLogger(AppResumeAltKeyLoginTest.class.getSimpleName());

//    @Value("${public.site.scheme}")
//    String scheme;
//    @Value("${public.site.url}")
//    String url;
//    @Resource
//    PlatformUserImpl pubSiteUserService;

    private static final String altKey = "EE7C5072585611464ACE";


    @Test
    public void validateAltKeyResponse() throws IOException, HttpRequestException, AutomationException {
        pubSiteUserService = new PlatformUserImpl(platformPublicServiceConfig, Constant.API_USERTOKEN_EMAIL, Constant.COMMON_PASSWORD);
        AppResumeLoginResponse appResumeLoginResponse = pubSiteUserService.verifyAppResumeLogin(altKey);
        Assert.assertNotNull(appResumeLoginResponse);
        LOG.info("AppResume  Altkey api response is not null");
    }

}
