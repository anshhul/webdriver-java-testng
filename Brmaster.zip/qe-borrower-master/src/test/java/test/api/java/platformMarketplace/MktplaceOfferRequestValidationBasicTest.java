
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationBasicTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Test end to end flow till offers service. Created by rsubramanyam on 2/20/16.
 */
public class MktplaceOfferRequestValidationBasicTest extends MarketplaceOffersTestBase
        implements MktplaceOfferRequestValidationBasicTestCase {

    @Autowired
    private IPlatformMarketplace marketplaceService;


    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testValidationSuccess() throws AutomationException, HttpRequestException {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
    }

    // Check for another offers service error
    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testValidationSuccessNoOffersInUnsupportedStates() throws AutomationException, HttpRequestException {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfoWithUnsupportedState())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.UNSUPPORTED_STATE, false);
    }

    // Check for another offers service error
    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testLoanAmountInStateLessThanAllowed() throws AutomationException, HttpRequestException {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfoWithLoanAmountMinAsk())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.MIN_LOAN_STATE, false);
    }
}
