
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.GetApplicationOfferTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public final class GetApplicationOfferTest extends MarketplaceOffersTestBase implements GetApplicationOfferTestCase {

    @Autowired
    private IPlatformMarketplace marketplaceService;


    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetApplicationOfferHappyPath() throws AutomationException, HttpRequestException {

        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo())
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();
        Assert.assertNotNull(marketplaceService.getOffer(getOfferRequest));
    }
}
