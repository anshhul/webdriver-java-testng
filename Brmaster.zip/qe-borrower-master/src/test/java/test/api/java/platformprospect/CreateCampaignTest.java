package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.CampaignAndProgramResponse;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.api.java.platformprospect.cases.CreateCampaignTestCase;

import java.util.HashMap;

/**
 * Created by rsubramanyam on 4/21/16.
 */
public class CreateCampaignTest extends PlatformProspectTestBase
        implements CreateCampaignTestCase {

    private String DX_PRICING = "21";
    private String DX_PRICING_NEW = "1";
    private static final String DATA_EXCHANGE = "DataExchange";
    private static final String NON_DATA_EXCHANGE = "DirectMail";


//    @BeforeMethod
//    public void setUp() {
//        CampaignProgramPricingDao dao = prospectDBConnection.getDataAccessObject(CampaignProgramPricingDao.class);
//        DX_PRICING = String.valueOf(dao.getPricingIdForDataExchange());
//        DX_PRICING_NEW = String.valueOf(dao.getPricingId("NON_DATA_EXCHANGE"));
//    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testBasicFlow() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        CampaignAndProgramResponse response =
                internalProspectService.createCampaign(campaignSourceId, DATA_EXCHANGE, "true", DX_PRICING);
        CampaignAndProgramResponse responseAgain =
                internalProspectService.createCampaign(campaignSourceId, DATA_EXCHANGE, "true", DX_PRICING);
        Assert.assertEquals(response.getCampaign(), responseAgain.getCampaign());
        Assert.assertEquals(response.getCampaignProgram(), responseAgain.getCampaignProgram());
        Assert.assertEquals(response.getCampaignProgram().getPricingId().toString(), DX_PRICING);
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testBasicFlowRefAcRefMcNotNull() throws AutomationException, HttpRequestException {
        String thisTestCampaignSourceId = insertCampaignSourceTestData();
        setUpData(thisTestCampaignSourceId);
        CampaignAndProgramResponse response =
                internalProspectService.createCampaign(thisTestCampaignSourceId, DATA_EXCHANGE, "true", DX_PRICING);
        CampaignAndProgramResponse responseAgain =
                internalProspectService.createCampaign(thisTestCampaignSourceId, DATA_EXCHANGE, "true", DX_PRICING);
        Assert.assertNotNull(response.getCampaign().getRefac());
        Assert.assertNotNull(response.getCampaignProgram().getRefMc());
        Assert.assertEquals(response.getCampaign().getRefac(), responseAgain.getCampaign().getRefac());
        Assert.assertEquals(response.getCampaignProgram().getRefMc(), responseAgain.getCampaignProgram().getRefMc());
    }

    private void setUpData(String thisTestCampaignSourceId) {
        final String campaignProgramId = Constant.newUuid();
        final String fallBackProgramUsed = Constant.newUuid();
        String testCampaignId = Constant.newUuid();
        final String campaignChannelId = getCampaignChannelId(DATA_EXCHANGE);
        Assert.assertNotNull(campaignChannelId, String.format("Unable to find campaign channel name %s.", DATA_EXCHANGE));
        final com.prosper.automation.model.platform.prospect.Campaign campaign =
                com.prosper.automation.model.platform.prospect.Campaign
                        .createCampaign(testCampaignId, thisTestCampaignSourceId, campaignChannelId, 1, 1, DATA_EXCHANGE, 60,
                                null, this.getClass().getSimpleName());
        Assert.assertEquals(insertCampaignTestData(campaign), 1);

        final com.prosper.automation.model.platform.prospect.CampaignProgram campaignProgram =
                com.prosper.automation.model.platform.prospect.CampaignProgram
                        .createCampaignProgram(campaignProgramId, testCampaignId, 1, Integer.parseInt(DX_PRICING), 1, DATA_EXCHANGE, fallBackProgramUsed, 1,
                                false, null, DATA_EXCHANGE);
        Assert.assertEquals(insertCampaignProgramTestData(campaignProgram), 1);
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testGetPartnerOauthForExistingCampaignOnlyData()
            throws AutomationException, HttpRequestException {
        String thisTestCampaignSourceId = insertCampaignSourceTestData();
        String testCampaignId = Constant.newUuid();
        insertCampaignOnly(thisTestCampaignSourceId, testCampaignId, DATA_EXCHANGE);

    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testBasicFlowWithNonDXChannelName() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        CampaignAndProgramResponse response =
                internalProspectService.createCampaign(campaignSourceId, NON_DATA_EXCHANGE, "true", DX_PRICING_NEW);
        CampaignAndProgramResponse responseAgain =
                internalProspectService.createCampaign(campaignSourceId, NON_DATA_EXCHANGE, "true", DX_PRICING_NEW);
        Assert.assertEquals(response.getCampaign(), responseAgain.getCampaign());
        Assert.assertEquals(response.getCampaignProgram(), responseAgain.getCampaignProgram());
        Assert.assertEquals(response.getCampaign().getName(), NON_DATA_EXCHANGE);
        Assert.assertEquals(response.getCampaignProgram().getPricingId().toString(), DX_PRICING_NEW);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class) public void testMissingCampaignSource()
            throws AutomationException, HttpRequestException {
        final HashMap<String, String> queryParameter = new HashMap<String, String>();
        queryParameter.put("channel_name", DATA_EXCHANGE);
        queryParameter.put("pricing_id", DX_PRICING);
        internalProspectService.createCampaign(queryParameter);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class) public void testMissingChannel()
            throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        final HashMap<String, String> queryParameter = new HashMap<String, String>();
        queryParameter.put("campaign_source_id", campaignSourceId);
        queryParameter.put("pricing_id", DX_PRICING);
        internalProspectService.createCampaign(queryParameter);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testMissingIsUpsert() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        final HashMap<String, String> queryParameter = new HashMap<String, String>();
        queryParameter.put("campaign_source_id", campaignSourceId);
        queryParameter.put("channel_name", DATA_EXCHANGE);
        queryParameter.put("pricing_id", DX_PRICING);
        CampaignAndProgramResponse response = internalProspectService.createCampaign(queryParameter);
        Assert.assertNull(response.getCampaign());
        Assert.assertNull(response.getCampaignProgram());
    }

    @Override
    @Test(groups = { TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}) public void testMissingPricing() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        final HashMap<String, String> queryParameter = new HashMap<String, String>();
        queryParameter.put("campaign_source_id", campaignSourceId);
        queryParameter.put("is_upsert", "true");
        queryParameter.put("channel_name", DATA_EXCHANGE);
        CampaignAndProgramResponse response = internalProspectService.createCampaign(queryParameter);
        Assert.assertNotNull(response.getCampaign());
        Assert.assertNotNull(response.getCampaignProgram());
    }

    //  Enable after this bug is fixed BMP-185
    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, enabled = true) public void testInvalidPricing() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        internalProspectService.createCampaign(campaignSourceId, DATA_EXCHANGE, "true", "-1");
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class) public void testZeroPricing() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        internalProspectService.createCampaign(campaignSourceId, DATA_EXCHANGE, "true", "0");
    }
}
