
package test.api.java.applicantDb;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/23/16.
 */
public class MergeApplicantByCreateProspectTest extends AppDbTestBase
        implements test.api.java.applicantDb.cases.MergeApplicantByCreateProspectTestCase {

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchByEmail() throws AutomationException, HttpRequestException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void _testApplicantMatchByEmailSsnUpdate() throws AutomationException, HttpRequestException {
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail, prospect2Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(
                        TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()),
                        prospect1Ssn);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFirstInitialLastName() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.RICK_NICK_LAST_NAME;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, true);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(
                        TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()),
                        prospect1Ssn, initial1, lastName1, true);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFirstInitialLastNameOn9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.RICK_NICK_LAST_NAME;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, true);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(
                        TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()),
                        prospect1Ssn.substring(2, 9), initial1, lastName1, true);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFIAddressZip() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.RICK_NICK_LAST_NAME;
        String lastName2 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String address1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1;
        String zipCode1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 =
                buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, address1, zipCode1);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(
                        TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()),
                        prospect1Ssn, initial1, lastName2, address1, zipCode1);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFIAddressZipOn9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.RICK_NICK_LAST_NAME;
        String lastName2 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String address1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1;
        String zipCode1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 =
                buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, address1, zipCode1);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(
                        TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()),
                        prospect1Ssn.substring(2, 9), initial1, lastName2, address1, zipCode1);
        doTestCreationOfApplicantsWithRequestData(request1, request2, true);
    }
}
