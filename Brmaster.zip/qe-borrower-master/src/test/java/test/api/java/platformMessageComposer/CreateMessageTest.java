package test.api.java.platformMessageComposer;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpUnprocessableEntityException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;
import com.prosper.automation.model.platform.email.Message;
import com.prosper.automation.model.platform.email.MessageToken;

/**
 * Created by pbudiono on 9/26/16.
 */
public class CreateMessageTest extends PlatformMessageComposerTestBase {

	private static final int NUMBER_OF_TEMPLATES = 5;

	private String messageTemplateCode = Constant.getGloballyUniqueString();

	@BeforeClass(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void createDefaultMessageTemplate() throws AutomationException, HttpRequestException {
		final EmailMessageTemplate emailMessageTemplateRequest = createGenericMessageTemplateRequest(messageTemplateCode,
				DEFAULT_MESSAGE_SUBJECT_TEMPLATE, DEFAULT_MESSAGE_CONTENT_TEMPLATE, DEFAULT_CONTENT_TYPE_CODE,
				DEFAULT_DELIVERY_TYPE_CODE);
		internalMessageComposerService.createMessageTemplate(emailMessageTemplateRequest);
	}

	@Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void testCreateMessageWithSingleToken() throws AutomationException, HttpRequestException {

		final String replacementString = "test";

		final MessageToken subject = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_SUBJECT_TEMPLATE_KEY)
				.withValue(replacementString).build();
		final MessageToken content = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_CONTENT_TEMPLATE_KEY)
				.withValue(replacementString).build();

		final Message message = new Message.Builder().withMessageTemplateCode(messageTemplateCode)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withMessageTokens(Arrays.asList(subject, content)).build();

		final Message messageResponse = internalMessageComposerService.createMessage(message);
		Assert.assertTrue(messageResponse.getMessageContent().contains(replacementString));
		Assert.assertTrue(messageResponse.getMessageSubject().contains(replacementString));
	}

	@Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void testCreateMessageWithMultipleTokensWithoutDelimiter() throws AutomationException, HttpRequestException {

		final String messageCode = Constant.getGloballyUniqueString();

		final List<String> messageSubjectTokens = Lists.newArrayList();
		final List<String> messageContentTokens = Lists.newArrayList();

		final StringBuilder subjectToken = new StringBuilder();
		final StringBuilder contentToken = new StringBuilder();

		for (int i = 0; i < NUMBER_OF_TEMPLATES; i++) {

			final String subjectTemplate = Constant.getGloballyUniqueString();
			final String messageTemplate = Constant.getGloballyUniqueString();

			subjectToken.append("{{" + subjectTemplate + "}}");
			contentToken.append("{{" + messageTemplate + "}}");

			messageSubjectTokens.add(subjectTemplate);
			messageContentTokens.add(messageTemplate);
		}

		final EmailMessageTemplate emailMessageTemplateRequest = createGenericMessageTemplateRequest(messageCode,
				subjectToken.toString(), contentToken.toString(), DEFAULT_CONTENT_TYPE_CODE, DEFAULT_DELIVERY_TYPE_CODE);

		internalMessageComposerService.createMessageTemplate(emailMessageTemplateRequest);

		final List<MessageToken> messageTokens = Lists.newArrayList();
		for (int i = 0; i < messageSubjectTokens.size(); i++) {
			messageTokens.add(new MessageToken.Builder().withKey(messageSubjectTokens.get(i)).withValue("A").build());
		}
		for (int i = 0; i < messageContentTokens.size(); i++) {
			messageTokens.add(new MessageToken.Builder().withKey(messageContentTokens.get(i)).withValue("A").build());
		}

		final Message message = new Message.Builder().withMessageTemplateCode(messageCode)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withMessageTokens(messageTokens).build();

		final Message messageResponse = internalMessageComposerService.createMessage(message);

		Assert.assertTrue(messageResponse.getMessageContent().length() == NUMBER_OF_TEMPLATES);
		Assert.assertTrue(messageResponse.getMessageSubject().length() == NUMBER_OF_TEMPLATES);
	}

	@Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE, TestGroup.SANITY })
	public void testCreateMessageWithoutTokenReplacement() throws AutomationException, HttpRequestException {

		final String messageTemplateCode = Constant.getGloballyUniqueString();

		final String messageSubject = Constant.getGloballyUniqueString();
		final String messageContent = Constant.getGloballyUniqueString();

		final EmailMessageTemplate emailMessageTemplateRequest = createGenericMessageTemplateRequest(messageTemplateCode,
				messageSubject, messageContent, DEFAULT_CONTENT_TYPE_CODE, DEFAULT_DELIVERY_TYPE_CODE);

		internalMessageComposerService.createMessageTemplate(emailMessageTemplateRequest);

		final String replacementString = "test";

		final MessageToken subject = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_SUBJECT_TEMPLATE_KEY)
				.withValue(replacementString).build();
		final MessageToken content = new MessageToken.Builder().withKey(DEFAULT_MESSAGE_CONTENT_TEMPLATE_KEY)
				.withValue(replacementString).build();

		final Message message = new Message.Builder().withMessageTemplateCode(messageTemplateCode)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withMessageTokens(Arrays.asList(subject, content)).build();

		final Message messageResponse = internalMessageComposerService.createMessage(message);

		Assert.assertEquals(messageResponse.getMessageContent(), messageContent);
		Assert.assertEquals(messageResponse.getMessageSubject(), messageSubject);
	}

	@Test(expectedExceptions = HttpUnprocessableEntityException.class, expectedExceptionsMessageRegExp="UNABLE_TO_CREATE_MESSAGE_MESSAGE_TEMPLATE_NOT_FOUND",groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
			TestGroup.SANITY })
	public void testCreateMessageWithNonExistingTemplate() throws AutomationException, HttpRequestException {
		final Message message = new Message.Builder().withMessageTemplateCode(Constant.getGloballyUniqueString())
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE).build();
		internalMessageComposerService.createMessage(message);
		throw new HttpUnprocessableEntityException("UNABLE_TO_CREATE_MESSAGE_MESSAGE_TEMPLATE_NOT_FOUND");
	}

	@Test(expectedExceptions = HttpUnprocessableEntityException.class, expectedExceptionsMessageRegExp = "VALIDATION_ERROR", groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
			TestGroup.SANITY })
	public void testCreateMessageWithMissingToken() throws AutomationException, HttpRequestException {
		final Message message = new Message.Builder().withMessageTemplateCode(messageTemplateCode)
				.withContentTypeCode(DEFAULT_CONTENT_TYPE_CODE).withDeliveryTypeCode(DEFAULT_DELIVERY_TYPE_CODE)
				.withMessageTokens(Lists.newArrayList()).build();
		internalMessageComposerService.createMessage(message);
		throw new HttpUnprocessableEntityException("VALIDATION_ERROR");
	}
}
