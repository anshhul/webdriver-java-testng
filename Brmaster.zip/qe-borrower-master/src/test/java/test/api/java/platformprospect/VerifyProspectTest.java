package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by ppatil on 7/20/16.
 */
public class VerifyProspectTest extends PlatformProspectTestBase {
    @Test
    public void testverifyActiveOfferCode() throws AutomationException, HttpRequestException {
        String emailAddress = Constant.getGloballyUniqueEmail();
        // Create prospect request
        String testOfferCode = "TEST-" + emailAddress.substring(0, 10);
        ProspectRequest prospectInRequest = ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields("auto_"
                + Constant.getRandomString(), "auto_" + Constant.getRandomString(), emailAddress);
        prospectInRequest.getProspect().setOfferCode(testOfferCode);
        internalProspectService.createProspect(prospectInRequest);
        // Call the API
        ProspectResponse response = internalProspectService.verifyAndCopyProspect(prospectInRequest);
        Assert.assertNotNull(response);


    }

}
