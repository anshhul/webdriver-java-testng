
package test.api.java.applicantDb;

import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/20/16.
 */
public class MergeApplicantTest extends AppDbTestBase
        implements test.api.java.applicantDb.cases.MergeApplicantTestCase {

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(testEmail2); // Now update prospect2 to have the same email id
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2);
        ContactInfo info = new ContactInfo.Builder().withEmail(testEmail)
                .withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS_AREA_CODE).build();
        request3.getProspect().setContactInfo(info);
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeApplicantIdOldRetained()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 =
                buildPlatformProspectRequestWithRickData(testEmail2); // Now update prospect2 to have the same email id
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2);
        ContactInfo info = new ContactInfo.Builder().withEmail(testEmail)
                .withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS_AREA_CODE).build();
        request3.getProspect().setContactInfo(info);

        final ProspectResponse response1 = internalProspectService.createProspect(request1);
        int applicantId1 = getApplicantFromProspect(response1.getProspect().getProspectId().toString());
        String createdDate1 = getCreatedDate(applicantId1);
        String modifiedDate1 = getModifiedDate(applicantId1);

        final ProspectResponse response2 = internalProspectService.createProspect(request2);
        int applicantId2 = getApplicantFromProspect(response2.getProspect().getProspectId().toString());

        final ProspectResponse response3 =
                updateProspectAndValidate(response2.getProspect().getProspectId().toString(), request3);
        int applicantId3 = getApplicantFromProspect(response3.getProspect().getProspectId().toString());
        String createdDate2 = getCreatedDate(applicantId3);
        String modifiedDate2 = getModifiedDate(applicantId3);
        String prospectModifiedDate = getProspectModifiedDate(response3.getProspect().getProspectId().toString());

        // Validate dates and applicant id
        Assert.assertTrue(applicantId1 < applicantId2);
        Assert.assertEquals(applicantId1, applicantId3);
        Assert.assertEquals(createdDate1, createdDate2);
        Assert.assertTrue(modifiedDate1.compareTo(modifiedDate2) < 1);
        Assert.assertEquals(prospectModifiedDate, modifiedDate2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeProspect(response2.getProspect().getProspectId().toString());
        internalProspectService.nukeProspect(response3.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicantId1);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeBy9Ssn() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());

        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        // Now update prospect2 to have the same ssn as prospect1
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        request3.getProspect().getPersonalInfo().setSsn(prospect1Ssn);
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeBy7SsnFirstInitialLastNameInto9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String prospect2Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        // Now update prospect2 to have the same 7 digit ssn, First Initial, Last Name as prospect1
        request3.getProspect().getPersonalInfo().setSsn(prospect1Ssn.substring(2, 9));
        request3.getProspect().getPersonalInfo().setFirstName(request1.getProspect().getPersonalInfo().getFirstName());
        request3.getProspect().getPersonalInfo().setLastName(request1.getProspect().getPersonalInfo().getLastName());
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeBy7SsnFirstInitialLastNameInto7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String prospect2Ssn = generateRandomNumber(6);
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        // Now update prospect2 to have the same 7 digit ssn, First Initial, Last Name as prospect1
        request3.getProspect().getPersonalInfo().setSsn(prospect1Ssn);
        request3.getProspect().getPersonalInfo().setFirstName(request1.getProspect().getPersonalInfo().getFirstName());
        request3.getProspect().getPersonalInfo().setLastName(request1.getProspect().getPersonalInfo().getLastName());
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeBy7ssnSsnLastNameAddressZipInto9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail2);
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2);
        // Now update prospect2 to have the same email id
        request3.getProspect().getPersonalInfo().setSsn(prospect1Ssn.substring(2, 9));
        request3.getProspect().getPersonalInfo().setFirstName(request1.getProspect().getPersonalInfo().getFirstName());
        request3.getProspect().getAddressInfo().setAddress1(request1.getProspect().getAddressInfo().getAddress1());
        request3.getProspect().getAddressInfo().setZipCode(request1.getProspect().getAddressInfo().getZipCode());
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMergeBy7ssnSsnFIAddressZipInto7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect1Ssn = generateRandomNumber(6);
        String prospect2Ssn = generateRandomNumber(6);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        String testEmail2 = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        ProspectRequest request3 = buildPlatformProspectRequestWithRickData(testEmail2, prospect2Ssn);
        // Now update prospect2 to have the same email id
        request3.getProspect().getPersonalInfo().setSsn(prospect1Ssn);
        request3.getProspect().getPersonalInfo().setFirstName(request1.getProspect().getPersonalInfo().getFirstName());
        request3.getProspect().getAddressInfo().setAddress1(request1.getProspect().getAddressInfo().getAddress1());
        request3.getProspect().getAddressInfo().setZipCode(request1.getProspect().getAddressInfo().getZipCode());
        doTestMergeApplicants(request1, request2, request3, 2);
    }

    private void doTestMergeApplicants(ProspectRequest request1, ProspectRequest request2, ProspectRequest request3,
                                       int prospectIdToUpdate) throws HttpRequestException, AutomationException {
        final ProspectResponse response1 = internalProspectService.createProspect(request1);
        final ProspectResponse response2 = internalProspectService.createProspect(request2);
        compareApplicantData(request1, request2, response1, response2, false);
        String prospectToUpdate;
        if (prospectIdToUpdate == 1) {
            prospectToUpdate = response1.getProspect().getProspectId().toString();
        } else {
            prospectToUpdate = response2.getProspect().getProspectId().toString();
        }
        final ProspectResponse response3 = updateProspectAndValidate(prospectToUpdate, request3);
        compareAndTeardownApplicantData(request1, request3, response1, response3, true);
    }
}
