package test.api.java.platformPartner;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class DeletePartnerTest extends PlatformPartnerTestBase {

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testDeletePartner() throws AutomationException, HttpRequestException {
        internalPartnerService.deletePartner(this.getClass().getSimpleName());
    }
}

