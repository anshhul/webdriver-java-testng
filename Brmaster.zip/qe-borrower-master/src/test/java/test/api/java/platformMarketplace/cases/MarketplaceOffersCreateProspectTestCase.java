
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MarketplaceOffersCreateProspectTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test create prospect from marketplace offers service", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers"}, expectedResult = "Prospect created in database")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testCreationOfProspectInDB() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test create prospect with partially correct employment phone", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers"}, expectedResult = "Prospect created in database")

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testCreationOfProspectInDBWithPartiallyCorrectEmploymentPhone()
            throws AutomationException, HttpRequestException;
}
