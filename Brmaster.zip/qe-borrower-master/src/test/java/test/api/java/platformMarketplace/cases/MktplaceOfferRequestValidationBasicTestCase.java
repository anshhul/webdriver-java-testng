
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationBasicTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test successful offer request", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Valid fields in the request"}, expectedResult = "HTTP 200 OK Response without errors")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testValidationSuccess() throws AutomationException, HttpRequestException;

    // Check for another offers service error
    @ProsperZephyr(project = BMP, testTitle = "Test get offers with residence in unsupported state", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Use address having a Prosper unsupported state"}, expectedResult = "HTTP 200 OK Response with errors")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testValidationSuccessNoOffersInUnsupportedStates() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test get offers with loan amount less than min in certain states", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Use address having a Prosper state with minimum loan requirement and loan amount less than minimum needed"}, expectedResult = "HTTP 200 OK Response with errors")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testLoanAmountInStateLessThanAllowed() throws AutomationException, HttpRequestException;

}
