
package test.api.java.platformTransunion;

import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.transUnion.AddressRequestDTO;
import com.prosper.automation.model.platform.transUnion.PersonNameRequestDTO;
import com.prosper.automation.model.platform.transUnion.SocialSecurityRequestDTO;
import com.prosper.automation.model.platform.transUnion.TUCreditReportRequest;
import com.prosper.automation.model.platform.transUnion.TUCreditReportResponse;
import com.prosper.automation.platform.interfaces.IPlatformTransunion;
import com.prosper.automation.test.TestBase;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;

/**
 * Created by pbudiono on 9/8/16.
 */
public class PlatformTransunionTestBase extends TestBase {

    protected static final String TRANSUNION_DATA = "TRANSUNION_DATA";

    private static final String TRANSUNION_SEED_FILE_PATH = "/Users/pbudiono/Desktop/transunion.csv";

    private static final String CITY = "NEWBURGH";
    private static final String STATE = "NY";
    private static final String ADDRESS_STATUS = "CURRENT";
    private static final String HOUSE_NUMBER = "11";
    private static final String STREET_NAME = "CATHY";
    private static final String ZIP_CODE = "12550";
    private static final String ZIP_EXTENTION = "2706";
    private static final String FIRST_NAME = "WILLIAM";
    private static final String LAST_NAME = "SHILLING";
    private static final String MIDDLE_NAME = "L";
    private static final String SSN = "666529160";
    private static final String DOB = "1980-01-01";

    @Resource
    protected IPlatformTransunion pubSiteTransunionService;

    @Autowired
    protected HttpClientConfig platformPublicServiceConfig;

    @Resource
    protected CloseableJdbcConnection transUnionDBConnection;

    @Resource
    protected CloseableJdbcConnection circleOneDBConnection;


    // @DataProvider(name = TRANSUNION_DATA, parallel = true)
    // public final Object[][] buildTestData() throws AutomationException {
    // return TransunionUserCSVParser.parse(TRANSUNION_SEED_FILE_PATH);
    // }

    protected TUCreditReportRequest buildTransunionCreditProfileRequest() {
        final AddressRequestDTO addressRequestDTO = new AddressRequestDTO.Builder()
                .withCity(CITY)
                .withState(STATE)
                .withAddressStatus(ADDRESS_STATUS)
                .withNumber(HOUSE_NUMBER)
                .withStreetName(STREET_NAME)
                .withZipCode(ZIP_CODE)
                .withZipExtension(ZIP_EXTENTION)
                .build();
        final PersonNameRequestDTO personNameRequestDTO = new PersonNameRequestDTO.Builder()
                .withFirst(FIRST_NAME)
                .withLast(LAST_NAME)
                .withMiddle(MIDDLE_NAME)
                .build();
        final SocialSecurityRequestDTO socialSecurityRequestDTO = new SocialSecurityRequestDTO.Builder()
                .withNumber(SSN)
                .build();
        return new TUCreditReportRequest.Builder()
                .withAddress(addressRequestDTO)
                .withPersonName(personNameRequestDTO)
                .withSocialSecurity(socialSecurityRequestDTO)
                .withDateOfBirth(DOB)
                .build();
    }

    protected TUCreditReportResponse createTransunionCreditProfile() throws HttpRequestException, AutomationException {
        final AddressRequestDTO addressRequestDTO = new AddressRequestDTO.Builder()
                .withCity(CITY)
                .withState(STATE)
                .withAddressStatus(ADDRESS_STATUS)
                .withNumber(HOUSE_NUMBER)
                .withStreetName(STREET_NAME)
                .withZipCode(ZIP_CODE)
                .withZipExtension(ZIP_EXTENTION)
                .build();
        final PersonNameRequestDTO personNameRequestDTO = new PersonNameRequestDTO.Builder()
                .withFirst(FIRST_NAME)
                .withLast(LAST_NAME)
                .withMiddle(MIDDLE_NAME)
                .build();
        final SocialSecurityRequestDTO socialSecurityRequestDTO = new SocialSecurityRequestDTO.Builder()
                .withNumber(SSN)
                .build();
        final TUCreditReportRequest tuCreditReportRequest = new TUCreditReportRequest.Builder()
                .withAddress(addressRequestDTO)
                .withPersonName(personNameRequestDTO)
                .withSocialSecurity(socialSecurityRequestDTO)
                .withDateOfBirth(DOB)
                .build();

        return pubSiteTransunionService.createCreditReport(tuCreditReportRequest);
    }
}
