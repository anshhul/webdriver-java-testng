
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpForbiddenException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.offers.LoanOfferDAO;
import com.prosper.automation.db.dao.prospect.ProspectOfferDAO;
import com.prosper.automation.enumeration.platform.UserSourceSystem;
import com.prosper.automation.enumeration.platform.UserType;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import com.prosper.automation.model.platform.pricing.Offer;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;

import com.prosper.automation.util.MonthlyPaymentCalculator;
import com.prosper.automation.util.PollingUtilities;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;

/**
 * Created by rsubramanyam on 6/30/16.
 */
public class GetUserOffersShowAllTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;


    @BeforeMethod
    public void createNewBorrowerData() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
    }

    @Test
    public void testGetBorrowerOffersDifferentOfferTypes() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, 5000, Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        int countofDownSell = getCountOfOffersWithType(response, LoanTypes.DOWNSELL.toString());
        int countofUpSell = getCountOfOffersWithType(response, LoanTypes.UPSELL.toString());
        int countOfBasic = getCountOfOffersWithType(response, LoanTypes.BASE.toString());
        int countOfInvalid = getCountOfOffersWithType(response, LoanTypes.INVALID.toString());
        Assert.assertEquals(countofDownSell + countOfBasic + countofUpSell, response.getListedOffers().getOffers().size());
        Assert.assertEquals(countOfInvalid, 0);
    }

    @Test
    public void testGetBorrowerOffersMaxLoanCap() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();
        OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, 25000, Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
    }

    @Test
    public void testGetBorrowerOffersResponse() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();

        final OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        Assert.assertNull(response.getListedOffers().getOffers().get(0).getProspectLoanOfferScoreId());
        validateSameOffersWithShowAll(response, responseWithoutShowAll);
        PollingUtilities.sleep(5000);
        LoanOfferDAO offerDao = circleOneDBConnection.getDataAccessObject(LoanOfferDAO.class);
        String listingScoreId = offerDao.getlistingScoreID(responseWithoutShowAll.getListedOffers().getListingId().toString());
        String listingScoreIdFromShowAll = offerDao.getlistingScoreID(response.getListedOffers().getListingId().toString());
        Assert.assertTrue(offerDao.isLoanOfferPersisted(listingScoreId) > 0);
        Assert.assertTrue(offerDao.isLoanOfferPersisted(listingScoreIdFromShowAll) > 0);
    }

    @Test
    public void testGetBorrowerOffersResponseVerifyCalculatedAPR() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();

        final OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        for(Offer offer: response.getListedOffers().getOffers()) {
            Double monthlyPayment = MonthlyPaymentCalculator.calculateMonthlyPayment(offer.getLoanAmount().doubleValue(), offer.getApr()/100, offer.getTerm());
            Assert.assertTrue((monthlyPayment.intValue() > offer.getMonthlyPayment().intValue() - 5) || (monthlyPayment.intValue() < offer.getMonthlyPayment().intValue() + 5));
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersNoShowAllUpperBoundLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService
                .getUserOffers(testUserResponse.getUserRequest().getUserId(), 35500, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersNoShowAllLowerBoundLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.getUserOffers(testUserResponse.getUserRequest().getUserId(), 0, Constant.GENERIC_LISTING_CATEGORY_ID,
                Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test(expectedExceptions = HttpForbiddenException.class)
    public void testGetBorrowerOffersInvalidUserid()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.getUserOffers(123L, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test(enabled = false)
    public void testGetBorrowerOffersInvalidPurpose()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT,
                Constant.GENERIC_LISTING_CATEGORY_ID,
                25, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test(expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_26)
    public void testGetBorrowerOffersInvalidListingCategory()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        pubSiteOfferService.getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT, 100,
                Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test
    public void testGetBorrowerOffersMultipleHitsDbValidation() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        Long testUserId = testUserResponse.getUserRequest().getUserId();

        OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        validateDbStoredOffersInCircleOne(responseWithoutShowAll, 10);
        responseWithoutShowAll = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        validateDbStoredOffersInCircleOne(responseWithoutShowAll, 20);
        OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 30);
        response = pubSiteOfferService
                .getUserOffers(testUserId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInCircleOne(response, 40);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersInvalidLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        HttpBadRequestException oldException = null;
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        try {
            pubSiteOfferService.getUserOffers(testUserResponse.getUserRequest().getUserId(),
                    Constant.GENERIC_LOAN_AMOUNT + 35500,
                    Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID,
                    true);
        } catch (HttpBadRequestException ex) {
            oldException = ex;
        }
        Assert.assertNotNull(oldException);
        pubSiteOfferService.getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT + 35500,
                Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true);
    }

    @Test(enabled = false)
    public void testGetBorrowerOffersBusiness() throws AutomationException, HttpRequestException {
        // BMP-2067
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT,
                        3, 3, Constant.GENERIC_CREDIT_RANGE_ID,
                        true);
        Assert.assertNotNull(response);
    }

    @DataProvider(name="differentUserSourceSystems")
    public static Object[][] getUserSourceSystems() {
        return new Object[][] {{UserSourceSystem.APP_BY_PHONE}, {UserSourceSystem.PUBLIC_SITE},{UserSourceSystem.PARTNER_REFERRAL}};
    }

    @Test(dataProvider="differentUserSourceSystems")
    public void testGetUserOffersDifferentSourceSystems(UserSourceSystem system) throws AutomationException,
            HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(testUserEmail);
        UserResponse testUserResponse = pubSiteUserService.createBorrower(userRequest);
        PlatformOfferImpl pubSiteOfferService =
                new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService
                .getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, false,
                        UserType.USER, system);
        final OffersResponse responseWithShowAll = pubSiteOfferService
                .getUserOffers(testUserResponse.getUserRequest().getUserId(), Constant.GENERIC_LOAN_AMOUNT,
                        Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_CREDIT_RANGE_ID, true,
                        UserType.USER, system);
        Assert.assertNotNull(response);
        validateSameOffersWithShowAll(responseWithShowAll, response);
    }
}
