
package test.api.java.applicantDb.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/4/16.
 */
public interface UpdateApplicantByUpdateProspectTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test update applicant by matching email", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update prospect by using same email."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test modified date of applicant on update", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update prospect. Ensure only modified date changes."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantUpdateApplicantModifiedDateOnlyChanges()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test update applicant by matching email", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update SSN of prospect by using same email."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchByEmailSsnUpdate()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test update applicant by matching 9 SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update prospect by using same 9 digit SSN."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy9Ssn() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test update applicant by matching 7 SSN, first initial, last name.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update prospect by using same 7 SSN, first initial, last name."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFirstInitialLastName() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test update 9 digit SSN applicant by matching 7 SSN, first initial, last name.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A with 9 digit SSN. Update prospect by using same 7 SSN, first initial, last name."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFirstInitialLastNameOn9Ssn() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test update applicant with matching 7 SSN, first initial, address, zip.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A. Update prospect by using same 7 SSN, first initial, address, zip."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFIAddressZip() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test update 9 digit SSN applicant with matching 7 SSN, first initial, address, zip.", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create Prospect A with 9 digit SSN. Update prospect by using same 7 SSN, first initial, address, zip."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFIAddressZipOn9Ssn() throws AutomationException, HttpRequestException;
}
