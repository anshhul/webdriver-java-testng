
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import test.api.java.platformprospect.cases.UpdatePartnerOauthInformationTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public final class UpdatePartnerOauthInformationTest extends PlatformProspectTestBase
        implements UpdatePartnerOauthInformationTestCase {

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testUpdatePartnerOauthInfoHappyPath() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final String newClientId = Constant.newUuid();
        final PartnerOauthInfo updateRequest = new PartnerOauthInfo.Builder()
                .withPartnerOauthId(partnerOauthInfo.getPartnerOauthId()).withExternalClientId(newClientId).build();

        final PartnerOauthInfo updateResponse = internalProspectService.updatePartnerOauth(updateRequest);
        Assert.assertNotNull(updateResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testUpdateClientIdIsPersistedCorrectly() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final String newClientId = Constant.newUuid();
        final PartnerOauthInfo updateRequest = new PartnerOauthInfo.Builder()
                .withPartnerOauthId(partnerOauthInfo.getPartnerOauthId()).withExternalClientId(newClientId).build();
        internalProspectService.updatePartnerOauth(updateRequest);

        final PartnerOauthInfo partnerOauthInfoFromDatabase = getPartnerOauthInfoFromDatabase(newClientId);
        Assert.assertEquals(partnerOauthInfoFromDatabase.getExternalClientId(), newClientId);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpRequestException.class)
    public void testUpdatePartnerOauthInfoWithNonExistingPartnerOauthId() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo updateRequest = new PartnerOauthInfo.Builder().withPartnerOauthId(Integer.MAX_VALUE)
                .withExternalClientId(Constant.newUuid()).build();
        internalProspectService.updatePartnerOauth(updateRequest);
    }
}
