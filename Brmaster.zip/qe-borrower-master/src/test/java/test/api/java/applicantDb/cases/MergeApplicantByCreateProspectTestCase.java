
package test.api.java.applicantDb.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/4/16.
 */
public interface MergeApplicantByCreateProspectTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by email", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email A"}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchByEmail() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by email with update on SSN later", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A null SSN, Create prospect B with email A, SSN B"}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void _testApplicantMatchByEmailSsnUpdate() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 9 digit SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A SSN A, Create prospect B with email B, SSN A"}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy9Ssn() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First initial, Last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create 2 prospects matching on 7 digit SSN, First initial, Last name"}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFirstInitialLastName() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First Initial, Last Name matching with 9 digit SSN applicant data", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create 2 prospects matching on 7 digit SSN, First initial, Last name. First prospect should have 9 digit SSN."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFirstInitialLastNameOn9Ssn() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First Initial, Address, Zipcode", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospects matching on 7 digit SSN, First Initial, Address, Zipcode."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFIAddressZip() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First Initial, Address, Zipcode matching with 9 digit SSN applicant data", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospects matching on 7 digit SSN, First Initial, Address, Zipcode. first prospect should have 9 digit SSN."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) void testApplicantMatchBy7SsnFIAddressZipOn9Ssn() throws AutomationException, HttpRequestException;
}
