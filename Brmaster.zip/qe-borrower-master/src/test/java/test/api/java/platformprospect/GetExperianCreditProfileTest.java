
package test.api.java.platformprospect;

import java.io.IOException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;

/**
 * A test class for decrypting Experian credit profile report.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class GetExperianCreditProfileTest extends PlatformProspectTestBase {

	private String prospectTestEmail;

	private UUID testProspectId;

	@Autowired
	private IPlatformOffer pubSiteOfferService;

	/**
	 * Creates prospect test data.
	 *
	 * @throws AutomationException
	 * @throws HttpRequestException
	 */
	@BeforeMethod(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void createNewProspect() throws AutomationException, HttpRequestException {
		prospectTestEmail = Constant.getGloballyUniqueEmail();

		final ProspectRequest testProspectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC,
				prospectTestEmail);
		final ProspectResponse testProspectResponse = pubSiteProspectService.createProspect(testProspectRequest);
		Assert.assertNotNull(testProspectResponse);

		testProspectId = testProspectResponse.getProspect().getProspectId();
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetExperianCreditProfileBeforeGettingProspectOffer() throws AutomationException, HttpRequestException {
		final String experianDoc = pubSiteProspectService.getExperianCreditProfile(testProspectId.toString());
		Assert.assertTrue(experianDoc.isEmpty());
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetExperianCreditProfileAfterGettingProspectOffer()
			throws AutomationException, HttpRequestException, IOException, SAXException {
		final OffersResponse offersResponse = pubSiteOfferService.getProspectOffers(testProspectId, Constant.GENERIC_LOAN_AMOUNT,
				Constant.GENERIC_LOAN_PURPOSE_ID, Constant.GENERIC_LISTING_CATEGORY_ID);
		Assert.assertNotNull(offersResponse, "Unable to get prospect offers.");

		final String actualCreditProfile = pubSiteProspectService.getExperianCreditProfile(testProspectId.toString());
		Assert.assertNotNull(actualCreditProfile);

		Assert.assertTrue(actualCreditProfile.contains(Constant.TEST_FIRST_NAME.toUpperCase()));
		Assert.assertTrue(actualCreditProfile.contains(Constant.TEST_LAST_NAME.toUpperCase()));
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class)
	public void testGetExperianCreditProfileWithNonExistingProspectUUID() throws AutomationException, HttpRequestException {
		pubSiteProspectService.getExperianCreditProfile(Constant.FAKE_UUID.toString());
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpNotFoundException.class)
	public void testGetExperianCreditProfileWithEmptyProspectUUID() throws AutomationException, HttpRequestException {
		pubSiteProspectService.getExperianCreditProfile(Constant.BLANK_STRING);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class)
	public void testGetExperianCreditProfileWithInvalidProspectUUID() throws AutomationException, HttpRequestException {
		pubSiteProspectService.getExperianCreditProfile(Constant.INVALID_UUID_STRING);
	}
}
