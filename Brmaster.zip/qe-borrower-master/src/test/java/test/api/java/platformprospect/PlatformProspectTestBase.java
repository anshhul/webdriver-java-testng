
package test.api.java.platformprospect;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.BankAccountConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.LendingAccreditationConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.prospect.CampaignChannelDAO;
import com.prosper.automation.db.dao.prospect.CampaignDao;
import com.prosper.automation.db.dao.prospect.CampaignProgramDAO;
import com.prosper.automation.db.dao.prospect.CampaignProgramPricingDao;
import com.prosper.automation.db.dao.prospect.CampaignSourceDAO;
import com.prosper.automation.db.dao.prospect.PartnerOAuthDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.Campaign;
import com.prosper.automation.model.platform.prospect.CampaignProgram;
import com.prosper.automation.model.platform.prospect.PartnerApiInfo;
import com.prosper.automation.model.platform.prospect.PartnerInfo;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.model.platform.prospect.TrackingInfo;
import com.prosper.automation.model.platform.user.ProspectToBorrowerRequest;
import com.prosper.automation.model.platform.user.ProspectToBorrowerResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.platform.interfaces.IPlatformProspect;
import com.prosper.automation.platform.interfaces.IPlatformUser;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import javax.annotation.Resource;

import java.util.List;
import java.util.UUID;

import test.api.java.PlatformServiceTestBase;

/**
 * @author pbudiono
 */
public abstract class PlatformProspectTestBase extends PlatformServiceTestBase {

    protected static final String DEFAULT_REF_AC = "DEFAULT";
    protected static final String DEFAULT_REF_MC = "DEFAULT";

    protected static final int DB_PERSIST_DELAY_IN_MS = 2000;

    @Resource
    protected IPlatformProspect pubSiteProspectService;
    @Resource
    protected IPlatformProspect internalProspectService;
    @Resource
    private IPlatformUser pubSiteUserService;
    @Resource
    private IPlatformOffer pubSiteOfferService;


    protected int insertCampaignTestData(Campaign campaign) {
        final CampaignDao campaignDao = prospectDBConnection.getDataAccessObject(CampaignDao.class);
        return campaignDao.insertCampaign(campaign);
    }

    protected int insertCampaignProgramTestData(CampaignProgram campaignProgram) {
        final CampaignProgramDAO campaignProgramDAO = prospectDBConnection.getDataAccessObject(CampaignProgramDAO.class);
        return campaignProgramDAO.insertCampaignProgram(campaignProgram);
    }

    protected void insertAuthorizedCampaignProgram(String clientId, String campaignChannelName, int campaignProgramLegacyId)
            throws HttpRequestException, AutomationException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo(clientId);
        Assert.assertNotNull(partnerOauthInfo);

        final String campaignId = Constant.newUuid();
        final String campaignSourceId = partnerOauthInfo.getCampaignSourceId();

        final String campaignChannelId = getCampaignChannelId(campaignChannelName);
        Assert.assertNotNull(campaignChannelId, String.format("Unable to find campaign channel name %s.", campaignChannelName));

        final Campaign campaign = Campaign.createCampaign(campaignId, campaignSourceId, campaignChannelId, 1, 1,
                campaignChannelName, 60);
        Assert.assertEquals(insertCampaignTestData(campaign), 1);

        final String campaignProgramId = Constant.newUuid();
        final String fallBackProgramUsed = Constant.newUuid();

        // Find pricing
        CampaignProgramPricingDao dao = prospectDBConnection.getDataAccessObject(CampaignProgramPricingDao.class);
        String name = campaignChannelName;
        if (campaignChannelName.contains("DataExchange")) {
            name = StringUtils.EMPTY; // Wierd: DB stores actually an empty string but returns as null on select
        }
        int pricing = dao.getPricingId(name);

        // Set to 21 is pricing is not found for a channel
        // TODO: This is a temporary fix. Handle different types of channels which tests currently don't use next.
        if (pricing == 0)
            pricing = 21;
        final CampaignProgram campaignProgram = CampaignProgram.createCampaignProgram(campaignProgramId, campaignId, 1, pricing,
                campaignProgramLegacyId, campaignChannelName, fallBackProgramUsed, 1, false);
        Assert.assertEquals(insertCampaignProgramTestData(campaignProgram), 1);
    }

    protected PartnerOauthInfo addPartnerOauthInfo() throws AutomationException, HttpRequestException {
        return addPartnerOauthInfo(Constant.newUuid());
    }

    protected PartnerOauthInfo addPartnerOauthInfo(String externalClientId) throws AutomationException, HttpRequestException {
        final String campaignSourceId = insertCampaignSourceTestData();
        final PartnerOauthInfo request = new PartnerOauthInfo.Builder().withExternalClientId(externalClientId)
                .withCampaignSourceId(campaignSourceId).build();

        return internalProspectService.addPartnerOAuth(request);
    }

    // TODO: refactor duplicate code.
    public String insertCampaignSourceTestData() {
        final CampaignSourceDAO campaignSourceDAO = prospectDBConnection.getDataAccessObject(CampaignSourceDAO.class);

        final String campaignSourceId = Constant.newUuid();
        final String campaignSourceName = String.format("auto_eco_%s", Constant.getGloballyUniqueString());

        final int returnCode = campaignSourceDAO.insertCampaignSourceData(campaignSourceId, campaignSourceName);
        Assert.assertEquals(returnCode, 1);

        return campaignSourceId;
    }

    protected List<String> getCampaignChannelNames() {
        final CampaignChannelDAO campaignChannelDAO = prospectDBConnection.getDataAccessObject(CampaignChannelDAO.class);
        return campaignChannelDAO.getChannelNames();
    }

    protected String getCampaignChannelId(final String channelName) {
        final CampaignChannelDAO campaignChannelDAO = prospectDBConnection.getDataAccessObject(CampaignChannelDAO.class);
        return campaignChannelDAO.getChannelId(channelName);
    }

    protected String getLatestCampaignSourceId() {
        final CampaignSourceDAO campaignSourceDAO = prospectDBConnection.getDataAccessObject(CampaignSourceDAO.class);
        return campaignSourceDAO.getLatestCampaignSourceId();
    }

    protected String getOldestCampaignSourceId() {
        final CampaignSourceDAO campaignSourceDAO = prospectDBConnection.getDataAccessObject(CampaignSourceDAO.class);
        return campaignSourceDAO.getOldestCampaignSourceId();
    }

    protected PartnerOauthInfo getPartnerOauthInfoFromDatabase(final String clientId) {
        final PartnerOAuthDAO partnerOAuthDAO = prospectDBConnection.getDataAccessObject(PartnerOAuthDAO.class);
        return partnerOAuthDAO.getPartnerOauthInfo(clientId);
    }

    protected ProspectRequest buildGenericProspectRequest(final String refAC, final String refMC, final String email) {
        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
                .withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME)
                .build();

        final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME)
                .withLastName(Constant.TEST_LAST_NAME).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();

        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();

        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                        .withCity(AddressInfoConstant.TEST_CITY).withAddress(AddressInfoConstant.TEST_ADDRESS_1)
                        .withAddressType(String.valueOf(AddressInfoConstant.ADDRESS_TYPE_ID))
                        .withState(AddressInfoConstant.TEST_STATE_GA).withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC).withProspect(prospect).build();
    }

    protected ProspectRequest buildNonGenericProspectRequest(final String refAC, final String refMC, final String email) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId("Self Employed")
                        .withAnnualIncome(12345333.).build();

        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(Constant.RICK_NICK_FIRST_NAME)
                        .withLastName(Constant.RICK_NICK_LAST_NAME)
                        .withDateOfBirth(Constant.RICK_NICK_DATE_OF_BIRTH).withSuffix(Constant.RICK_NICK_FIRST_NAME)
                        .withMiddleInitial(Constant.RICK_NICK_LAST_NAME)
                        // .withDateOfDeath(Constant.TEST_DATE_OF_DEATH)
                        .build();

        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();

        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress(Constant.NON_FRED_NON_RICK_ADDRESS)
                        .withCity(AddressInfoConstant.RICK_NICK_CITY)
                        .withState(AddressInfoConstant.RICK_NICK_STATE).withZipCode(AddressInfoConstant.RICK_NICK_ZIP_CODE)
                        .withAddressType(String.valueOf(AddressInfoConstant.ADDRESS_TYPE_ID)).build();

        BankAccountInfo info = BankAccountConstant.BANK_OF_AMERICA_BANK_ACCOUNT_1;
        info.setBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.BUSINESS);
        info.setBankAccountType(BankAccountInfo.BankAccountType.CHECKING);
        info.setSecondAccountHolderName("DUMMY");
        info.setWithdrawalType(BankAccountInfo.PaymentOption.MANUAL);
        info.setAccountId(123456L);

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId("700").withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withBankAccountInfo(info).withContactInfo(contactInfo)
                        .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC).withProspect(prospect).build();
    }

    protected ProspectRequest buildGenericProspectRequestWithAllFields(final String refAC, final String refMC,
                                                                       final String email)
            throws AutomationException, HttpRequestException {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME).withEmploymentMonth(1)
                        .withEmployerPhone(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE).withEmploymentYear(1999)
                        .withOccupationId("1").withEmployerName("Test").withIsIncomeVerifiable(true)
                        .withIsSelfEmployed(true).withEmployerId("1").withMonthlyIncome(9000.)
                        .withEmploymentStatusMonths("32")
                        .withJobTitle("Senior")
                        .build();

        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                        .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH)
                        .withSsn(Constant.SSN_WITHOUT_DASH)
                        .withSuffix(Constant.FRED_RUIZ_CRUZ_FIRST_NAME)
                        .withMiddleName(Constant.FRED_RUIZ_CRUZ_FIRST_NAME)
                        .withMiddleInitial(Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1))
                        .withDateOfDeath(Constant.TEST_DATE_OF_DEATH)
                        .withSourceTypeId(1)
                        .withIsVerified(true)
                        .withSearchLastName(Constant.TEST_LAST_NAME)
                        .withUserNameTypeId(1)
                        .build();

        final ContactInfo contactInfo =
                new ContactInfo.Builder().withEmail(email)
                        .withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_ALL_TYPES_WITH_CODE_EXT)
                        .build();

        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
                        .withCity(AddressInfoConstant.TEST_CITY)
                        .withState(AddressInfoConstant.TEST_STATE_GA).withZipCode(AddressInfoConstant.TEST_ZIP_CODE)
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID)
                        .withSourceTypeId(1)
                        .withAddress2(" 123").withStateOfResidence(AddressInfoConstant.TEST_STATE_GA)
                        .build();

        BankAccountInfo info = BankAccountConstant.BANK_OF_AMERICA_BANK_ACCOUNT_1;
        info.setBankAccountOwnershipType(BankAccountInfo.BankAccountOwnershipType.BUSINESS);
        info.setBankAccountType(BankAccountInfo.BankAccountType.CHECKING);
        info.setSecondAccountHolderName("DUMMY");
        info.setWithdrawalType(BankAccountInfo.PaymentOption.MANUAL);
        info.setAccountId(123456L);

        String dateToUse = "2016-02-03 12:01:02 +0000";
        TrackingInfo tinfo = new TrackingInfo();
        tinfo.setSendDate(dateToUse);
        tinfo.setModifiedDate(dateToUse);
        tinfo.setPrePopulate(dateToUse);
        tinfo.setUserAttributionMethod("1");

        PartnerApiInfo partnerApiInfo = new PartnerApiInfo();
        partnerApiInfo.setErrors("1009");
        partnerApiInfo.setHttpResponseCode("1009");
        partnerApiInfo.setSourceStatusMessage("Test");
        partnerApiInfo.setSourceRequestMessage("Test");
        partnerApiInfo.setSourceResponseMessage("Test");
        partnerApiInfo.setSourceTransactionGuid(UUID.randomUUID());
        partnerApiInfo.setStatusCode("1009");

        PartnerInfo pinfo = new PartnerInfo();
        pinfo.setApplicationId(1L);
        pinfo.setEligibilityStatus("PENDING");
        pinfo.setIneligibilityReason("TEST");
        pinfo.setValidatedMembershipDate(dateToUse);

        final Prospect prospect =
                new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo)
                        .withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo)
                        .withBankAccountInfo(info).withTrackingInfo(tinfo).withLoanAmount(Constant.GENERIC_LOAN_AMOUNT)
                        .withLoanPurposeId((int) Constant.GENERIC_LOAN_PURPOSE_ID)
                        .withUsername(Constant.FRED_RUIZ_CRUZ_FIRST_NAME)
                        .withPassword(Constant.COMMON_PASSWORD)
                        // .withUserCreditPullId(1248470L)
                        .withPartnerApiInfo(partnerApiInfo)
                        .withPartnerInfo(pinfo)
                        .withLegacyId(1000L)
                        .withAbandonReason(1)
                        .withAgentId(1)
                        .withInstitutionId(1)
                        .withMerchantClientName("1")
                        .withMerchantFunnelName("2")
                        .withReferralId("3")
                        .withRelationshipId(1) // Check with lower case as well
                        .withThirdPartyId("1")
                        .build();

        String campaignSource = insertCampaignSourceTestData();
        final Campaign campaignInfo =
                insertCampaignAndProgram(campaignSource, "DataExchange", "DataExchange", 1000).getCampaign();
        return new ProspectRequest.Builder().withRefAc(refAC).withRefMc(refMC)
                .withCampaign(campaignInfo).withProspect(prospect)
                .build();
    }

    protected ProspectToBorrowerResponse runAppByPhoneE2EFlow(final ProspectRequest prospectRequest, final double loanAmount,
                                                              final long loanPurposeId, final long listingCategoryId)
            throws HttpRequestException, AutomationException {
        // create new prospect
        final UUID prospectUUID = createNewProspect(prospectRequest);

        // get prospect offers
        final OffersResponse offersResponse = getProspectOffers(prospectUUID, loanAmount, loanPurposeId, listingCategoryId);
        final String loanOfferId = offersResponse.getListedOffers().getOffers().get(0).getLoanOfferId();

        // create prospect to borrower request
        final ProspectToBorrowerRequest prospectToBorrowerRequest = buildProspectToBorrowerRequest(prospectUUID, loanOfferId);

        // convert prospect to borrower
        final ProspectToBorrowerResponse prospectToBorrowerResponse =
                pubSiteUserService.convertProspectToBorrower(prospectToBorrowerRequest);

        Assert.assertNotNull(prospectToBorrowerResponse);
        return prospectToBorrowerResponse;
    }

    final ProspectToBorrowerRequest buildProspectToBorrowerRequest(final UUID prospectUUID, final String loanOfferId) {
        return new ProspectToBorrowerRequest.Builder()
                .withLendingAccreditation(LendingAccreditationConstant.AGREED_LANDING_ACCREDITATION).withOfferId(loanOfferId)
                .withPassword(Constant.COMMON_PASSWORD).withProspectId(prospectUUID).build();
    }

    final UUID createNewProspect(final ProspectRequest prospectRequest) throws AutomationException, HttpRequestException {
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);

        final UUID prospectId = prospectResponse.getProspect().getProspectId();
        Assert.assertNotNull(prospectId);

        return prospectResponse.getProspect().getProspectId();
    }

    final OffersResponse getProspectOffers(final UUID prospectID, final double requestedLoanAmount, final long loanPurposeId,
                                           final long listingCategoryId) throws AutomationException, HttpRequestException {
        final OffersResponse offersResponse =
                pubSiteOfferService.getProspectOffers(prospectID, requestedLoanAmount, loanPurposeId, listingCategoryId);
        Assert.assertNotNull(offersResponse);

        return offersResponse;
    }
}
