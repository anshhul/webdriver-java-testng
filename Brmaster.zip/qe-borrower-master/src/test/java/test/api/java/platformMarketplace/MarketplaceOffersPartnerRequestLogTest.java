
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.core.enumeration.HttpMediaType;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.core.httpClient.exception.HttpUnauthorizedAccessException;
import com.prosper.automation.core.mapper.MapperService;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreatePartnerRequestErrorDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceCreatePartnerRequestLogDAO;
import com.prosper.automation.db.mapper.PartnerRequestErrors;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.ValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerRequestGetResponse;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.api.java.platformMarketplace.cases.MarketplaceOffersPartnerRequestLogTestCase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * End to end tests for verifying partner request table population and application id persistence Created by rsubramanyam on
 * 2/28/16.
 */
public class MarketplaceOffersPartnerRequestLogTest extends MarketplaceOffersTestBase
        implements MarketplaceOffersPartnerRequestLogTestCase {

    private static final String MARKETPLACE_ERROR_PREFIX = "MKTPL-";


    public enum QUERY_MODE {
        BY_EMAIL(0),
        BY_APPLICATION(1);

        private int type;


        QUERY_MODE(int type) {
            this.type = type;
        }
    }


    @Override
//    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}) //Temp for build fixes
    public void testPartnerRequestLogForAuthenticationIssue()
            throws AutomationException, HttpRequestException {

        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        BankAccountInfo binfo = TestDataProviderUtil.getValidBankInfo();
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfo();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(12345, emailId);

        // Build expected response
        ValidationErrorResponse error = buildValidationErrorResponse(ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, binfo, error);

        // Make a request
        GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);

        try {
            marketplaceService.getOfferWithErrorResponse(getOfferRequest);
        } catch (HttpUnauthorizedAccessException ex) {
            ValidationErrorResponse response =
                    MapperService.deserialize(HttpMediaType.JSON, ex.getMessage(), ValidationErrorResponse.class, false);
            // Pause since create partner request is asynchronous
            pauseForPartnerRequestTableUpdation();

            // Check partner request log table row and applicationId
            // Also compare get Partner Request response
            ValidationErrorResponse recievedErrorResponse =
                    new ValidationErrorResponse.ValidationErrorResponseBuilder().setErrorCode(response.getErrorCode())
                            .setMessage(response.getMessage()).build();
            validateCreatePartnerRequestLog(emailId, expectedResponse);
            validateApplicationIdInPartnerRequestTable(emailId);
            List<ResponseErrorsHelper> expectedErrors = new ArrayList<ResponseErrorsHelper>();
            expectedErrors.add(ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE);
            validatePartnerRequestErrorsTable(emailId, expectedErrors, QUERY_MODE.BY_EMAIL);
        }
    }

    // TODO: Enable the test when EP-864 is pushed to develop
    @Override
//    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.SANITY,
//            TestGroup.NIGHTLY}, enabled = false)
    @Test(enabled = false)
    public void testPartnerRequestLogForValidationIssue()
            throws AutomationException, HttpRequestException {

        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfoWithNumericFirstName();
        BankAccountInfo binfo = TestDataProviderUtil.getValidBankInfo();
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfoWithInvalidCreditScore();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfo();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode(), emailId);

        // Build expected response
        ValidationErrorResponse error = buildValidationErrorResponse(ResponseErrorsHelper.FIRST_NAME_INVALID);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, binfo, error);

        // Make request
        GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);
        marketplaceService.getOffer(getOfferRequest);

        pauseForPartnerRequestTableUpdation();

        // Validate
        validateCreatePartnerRequestLog(emailId, expectedResponse);
        validateApplicationIdInPartnerRequestTable(emailId);
        List<ResponseErrorsHelper> expectedErrors = new ArrayList<ResponseErrorsHelper>();
        expectedErrors.add(ResponseErrorsHelper.FIRST_NAME_INVALID);
        expectedErrors.add(ResponseErrorsHelper.CREDIT_SCORE_INVALID);
        validatePartnerRequestErrorsTable(emailId, expectedErrors, QUERY_MODE.BY_EMAIL);
    }

    @Override
//    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    @Test(enabled = false)
    public void testMissingApplicationId()
            throws AutomationException, HttpRequestException {
        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        BankAccountInfo binfo = TestDataProviderUtil.getValidBankInfo();
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfo();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfoWithoutClientReference(getPartnerCode());
        GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);

        // Make request
        marketplaceService.getOffer(getOfferRequest);
        // Pause since create partner request is asynchronous
        pauseForPartnerRequestTableUpdation();

        // Validate
        validateApplicationIdInPartnerRequestTable(emailId, null);
    }

    @Override
//    @Test
    @Test(enabled = false)
    public void testNoErrors() throws AutomationException, HttpRequestException {
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        GetOffersResponse response = marketplaceService.getOffer(buildMarketplaceOfferRequest(ProsperCreditGrade.AA, emailId, String.valueOf(getPartnerCode())));
        Assert.assertNotNull(response);
        pauseForPartnerRequestTableUpdation();
        validatePartnerRequestErrorsTable(emailId, Collections.EMPTY_LIST,
                QUERY_MODE.BY_EMAIL);
    }

    @Override
//    @Test
    @Test(enabled = false)
    public void testPartnerRequestErrorsUpdationForOffersErrors()
            throws AutomationException, HttpRequestException {
        final GetOfferRequest getOfferRequest = new GetOfferRequest.Builder()
                .withIdentification(TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode()))
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo())
                .withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo()).withLoanInfo(TestDataProviderUtil.getValidLoanInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo()).build();
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        assertErrorInResponse(response, ResponseErrorsHelper.NO_MATCHING_OFFERS, false);
        pauseForPartnerRequestTableUpdation();
        List<ResponseErrorsHelper> expectedErrors = new ArrayList<ResponseErrorsHelper>();
        expectedErrors.add(ResponseErrorsHelper.NO_MATCHING_OFFERS);
        validatePartnerRequestErrorsTable(getOfferRequest.getContactInfo().getEmailAddress(), expectedErrors,
                QUERY_MODE.BY_EMAIL);
    }

    private void validatePartnerRequestErrorsTable(String identifier, List<ResponseErrorsHelper> responseErrorsList,
                                                   QUERY_MODE mode) {
        List<PartnerRequestErrors> expectedErrorsList = buildExpectedPartnerRequestErrors(responseErrorsList);
        MarketplaceCreatePartnerRequestErrorDAO partnerRequestErrorDao =
                prospectDBConnection.getDataAccessObject(MarketplaceCreatePartnerRequestErrorDAO.class);
        String partnerRequestId = null;
        if (mode.equals(QUERY_MODE.BY_EMAIL)) {
            partnerRequestId = partnerRequestErrorDao.getPartnerRequestId(identifier);
        } else {
            MarketplaceCreatePartnerRequestLogDAO partnerRequestLogDao =
                    prospectDBConnection.getDataAccessObject(MarketplaceCreatePartnerRequestLogDAO.class);
            partnerRequestId = String.valueOf(partnerRequestLogDao.getDetailsByApplicationId(identifier).getPartnerRequestId());
        }
        Assert.assertNotNull(partnerRequestId);
        List<PartnerRequestErrors> errors = partnerRequestErrorDao.getErrors(partnerRequestId);
        Collections.sort(errors);
        Collections.sort(expectedErrorsList);
        Assert.assertEquals(errors.size(), responseErrorsList.size());
        for (int index = 0; index < responseErrorsList.size(); index++) {
            Assert.assertEquals(errors.get(index).getErrorCode(), expectedErrorsList.get(index).getErrorCode());
            Assert.assertNotNull(errors.get(index).getMessage());
            Assert.assertTrue(expectedErrorsList.get(index).getErrorCode().matches(errors.get(index).getErrorCode()));
        }
    }

    private List<PartnerRequestErrors> buildExpectedPartnerRequestErrors(List<ResponseErrorsHelper> expectedErrors) {
        List<PartnerRequestErrors> errors = new ArrayList<PartnerRequestErrors>();
        for (ResponseErrorsHelper error : expectedErrors) {
            errors.add(new PartnerRequestErrors(error.getCode().replaceAll(MARKETPLACE_ERROR_PREFIX, StringUtils.EMPTY),
                    error.getMessage()));
        }
        return errors;
    }
}
