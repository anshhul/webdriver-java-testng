
package test.api.java.applicantDb;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.db.dao.appDb.ApplicantDAO;
import com.prosper.automation.model.platform.appDb.ApplicantMatch;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.clients.PlatformProspectImpl;
import test.api.java.platformprospect.PlatformProspectTestBase;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by rsubramanyam on 3/17/16.
 */
public class AppDbTestBase extends PlatformProspectTestBase {

    private static final String DEFAULT_VALUE = "DEFAULT";

    @Autowired
    protected PlatformProspectImpl internalProspectService;


    public static ProspectRequest buildPlatformProspectRequestWithFredData(final String email) {
        return buildPlatformProspectRequestWithFredData(email, null, Constant.TEST_FIRST_NAME.substring(0, 1),
                Constant.TEST_LAST_NAME, AddressInfoConstant.TEST_ADDRESS_1, AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5));
    }

    public static ProspectRequest buildPlatformProspectRequestWithFredData(final String email, final String ssn) {
        return buildPlatformProspectRequestWithFredData(email, ssn, Constant.TEST_FIRST_NAME.substring(0, 1),
                Constant.TEST_LAST_NAME, AddressInfoConstant.TEST_ADDRESS_1, AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5));
    }

    public static ProspectRequest buildPlatformProspectRequestWithFredData(final String email, final String ssn,
                                                                           final String initial, final String lastName,
                                                                           boolean dummy) {
        return buildPlatformProspectRequestWithFredData(email, ssn, initial, lastName, AddressInfoConstant.TEST_ADDRESS_1,
                AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5));
    }

    public static ProspectRequest buildPlatformProspectRequestWithRickData(final String email) {
        return buildPlatformProspectRequestWithRickData(email, null, Constant.RICK_NICK_FIRST_NAME.substring(0, 1),
                Constant.RICK_NICK_LAST_NAME, AddressInfoConstant.RICK_NICK_ADDRESS_1, AddressInfoConstant.RICK_NICK_ZIP_CODE);
    }

    public static ProspectRequest buildPlatformProspectRequestWithRickData(final String email, final String ssn) {
        return buildPlatformProspectRequestWithRickData(email, ssn, Constant.RICK_NICK_FIRST_NAME.substring(0, 1),
                Constant.RICK_NICK_LAST_NAME, AddressInfoConstant.RICK_NICK_ADDRESS_1, AddressInfoConstant.RICK_NICK_ZIP_CODE);
    }

    public static ProspectRequest buildPlatformProspectRequestWithRickData(final String email, final String ssn,
                                                                           final String initial, final String lastName,
                                                                           boolean dummy) {
        return buildPlatformProspectRequestWithRickData(email, ssn, initial, lastName, AddressInfoConstant.RICK_NICK_ADDRESS_1,
                AddressInfoConstant.RICK_NICK_ZIP_CODE);
    }

    public static ProspectRequest buildPlatformProspectRequestWithRickData(final String email, final String ssn,
                                                                           final String initial, final String lastName,
                                                                           final String address, final String zipCode) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(Constant.TEST_ANNUAL_INCOME)
                        .withEmployerPhone(PhoneNumberConstant.VALID_WA_EMP_PHONE_NUMBER_2_WITH_AREA_CODE).build();
        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(initial + Constant.getStringWithLength(5)).withLastName(lastName)
                        .withDateOfBirth(Constant.RICK_NICK_DATE_OF_BIRTH).withSuffix(Constant.getRandomIntegerString(1))
                        .withSsn(ssn).withMiddleName(initial).build();
        List<PhoneNumber> validPhoneNumberList = new ArrayList<PhoneNumber>();
        validPhoneNumberList.addAll(PhoneNumberConstant.PROSPER_PHONE_NUMBERS);
        validPhoneNumberList.get(0).setAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE);
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).withPhoneNumbers(validPhoneNumberList).build();
        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(address).withCity(AddressInfoConstant.RICK_NICK_CITY)
                        .withState(AddressInfoConstant.RICK_NICK_STATE).withZipCode(zipCode)
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
        final Prospect prospect = new Prospect.Builder().withCreditQualityId(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                .withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    public static ProspectRequest getEmptyProspect() {
        final Prospect prospect = new Prospect.Builder().build();
        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    public static ProspectRequest buildPlatformProspectRequestWithoutPhoneNumbers(final String email) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                        .withMiddleName(Constant.getRandomIntegerString(1)).withSuffix(Constant.getRandomIntegerString(1))
                        .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();
        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1).withCity(AddressInfoConstant.TEST_CITY)
                        .withState(AddressInfoConstant.TEST_STATE_GA)
                        .withZipCode(AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5))
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
        final Prospect prospect = new Prospect.Builder().withCreditQualityId(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                .withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    public static ProspectRequest buildPlatformProspectRequestWithFredData(final String email, final String SSN,
                                                                           final String initial, final String lastName,
                                                                           final String address, final String zipCode) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(Constant.TEST_ANNUAL_INCOME)
                        .withEmployerPhone(PhoneNumberConstant.VALID_WA_EMP_PHONE_NUMBER_2_WITH_AREA_CODE).build();
        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(initial + Constant.TEST_FIRST_NAME).withLastName(lastName)
                        .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).withSuffix("H").withSsn(SSN).withMiddleName("Henry")
                        .build();
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email)
                .withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS_AREA_CODE).build();
        final AddressInfo addressInfo = new AddressInfo.Builder().withAddress1(address).withCity(AddressInfoConstant.TEST_CITY)
                .withState(AddressInfoConstant.TEST_STATE_GA).withZipCode(zipCode)
                .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
        final Prospect prospect = new Prospect.Builder().withCreditQualityId(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                .withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    public static ProspectRequest buildPlatformProspectRequestWithNullAreaCode(final String email) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                        .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).withSuffix("H").withMiddleName("Henry").build();
        List<PhoneNumber> phoneNumbers = new ArrayList<PhoneNumber>();
        phoneNumbers.add(PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_1);
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).withPhoneNumbers(phoneNumbers).build();
        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1).withCity(AddressInfoConstant.TEST_CITY)
                        .withState(AddressInfoConstant.TEST_STATE_GA)
                        .withZipCode(AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5))
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
        final Prospect prospect = new Prospect.Builder().withCreditQualityId(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                .withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    public static ProspectRequest buildPlatformProspectRequestWithInvalidPhoneNumber(final String email) {
        final EmploymentInfo employmentInfo =
                new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                        .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).build();
        final PersonalInfo personalInfo =
                new PersonalInfo.Builder().withFirstName(Constant.TEST_FIRST_NAME).withLastName(Constant.TEST_LAST_NAME)
                        .withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).withSuffix("H").withMiddleName("Henry").build();
        List<PhoneNumber> phoneNumbers = new ArrayList<PhoneNumber>();
        phoneNumbers.add(PhoneNumberConstant.FAKE_PHONE_NUMBER);
        final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).withPhoneNumbers(phoneNumbers).build();
        final AddressInfo addressInfo =
                new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1).withCity(AddressInfoConstant.TEST_CITY)
                        .withState(AddressInfoConstant.TEST_STATE_GA)
                        .withZipCode(AddressInfoConstant.TEST_ZIP_CODE.substring(0, 5))
                        .withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
        final Prospect prospect = new Prospect.Builder().withCreditQualityId(TestDataProviderUtil.TEST_DATA_CREDIT_SCORE)
                .withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo).build();

        return new ProspectRequest.Builder().withRefAc(DEFAULT_VALUE).withRefMc(DEFAULT_VALUE).withProspect(prospect).build();
    }

    int verifyApplicantMatchData(ProspectRequest request, ProspectResponse response)
            throws AutomationException, HttpRequestException {
        String prospectId = response.getProspect().getProspectId().toString();
        int applicantId = getApplicantFromProspect(prospectId);
        ApplicantMatch[] expectedMatchList = buildExpectedMatchFromResponse(request, response, applicantId);
        ApplicantMatch[] actualMatchList = internalProspectService.getApplicantMatch(applicantId);
        compareMatchData(expectedMatchList, actualMatchList);
        validateNumberOfApplicantRows(applicantId);
        return applicantId;
    }

    int verifyApplicantMatchData(ProspectRequest request1, ProspectResponse response1, ProspectRequest request2,
                                 ProspectResponse response2) throws AutomationException, HttpRequestException {
        String prospectId = response1.getProspect().getProspectId().toString();
        int applicantId = getApplicantFromProspect(prospectId);
        ApplicantMatch[] expectedMatchList1 = buildExpectedMatchFromResponse(request1, response1, applicantId);
        ApplicantMatch[] expectedMatchList2 = buildExpectedMatchFromResponse(request2, response2, applicantId);
        ApplicantMatch[] expectedMatchList = (ApplicantMatch[]) ArrayUtils.addAll(expectedMatchList1, expectedMatchList2);
        ApplicantMatch[] actualMatchList = internalProspectService.getApplicantMatch(applicantId);
        compareMatchData(expectedMatchList, actualMatchList);
        validateNumberOfApplicantRows(applicantId);
        return applicantId;
    }

    private void compareMatchData(ApplicantMatch[] expectedMatchList, ApplicantMatch[] actualMatchList) {
        for (int index = 0; index < expectedMatchList.length; index++) {
            Assert.assertTrue(actualMatchList[index].prospectId.equalsIgnoreCase(expectedMatchList[index].prospectId));
            Assert.assertTrue(actualMatchList[index].decValue.equalsIgnoreCase(expectedMatchList[index].decValue));
            Assert.assertTrue(actualMatchList[index].applicantId == (expectedMatchList[index].applicantId));
            Assert.assertTrue(actualMatchList[index].applicantMatchTypeId == (expectedMatchList[index].applicantMatchTypeId));
        }
    }

    private ApplicantMatch[] buildExpectedMatchFromResponse(ProspectRequest request, ProspectResponse response, int applicantId) {
        List<ApplicantMatch> matches = new ArrayList<>();
        Prospect responseProspect = response.getProspect();
        Prospect requestProspect = request.getProspect();
        String prospectId = responseProspect.getProspectId().toString().toUpperCase();
        String email = requestProspect.getContactInfo().getEmail();
        String ssn = requestProspect.getPersonalInfo().getSsn();
        String firstIntial = requestProspect.getPersonalInfo().getFirstName().substring(0, 1);
        String lastName = requestProspect.getPersonalInfo().getLastName().toUpperCase();
        String address = requestProspect.getAddressInfo().getAddress1().toUpperCase();
        String zip = request.getProspect().getAddressInfo().getZipCode();
        if (ssn != null && ssn.length() == 9) {
            matches.add(new ApplicantMatch(applicantId, 0, 1, ssn, prospectId, "0"));
        }
        if (ssn != null && firstIntial != null && address != null && zip != null) {
            String ssnToUse = (ssn.length() == 9) ? ssn.substring(2, 9) : ssn;
            matches.add(
                    new ApplicantMatch(applicantId, 0, 2, ssnToUse + "|" + firstIntial + "|" + address + "|" + zip, prospectId,
                            "0"));
        }
        if (ssn != null && firstIntial != null && lastName != null) {
            String ssnToUse = (ssn.length() == 9) ? ssn.substring(2, 9) : ssn;
            matches.add(new ApplicantMatch(applicantId, 0, 3, ssnToUse + "|" + firstIntial + "|" + lastName, prospectId, "0"));
        }
        if (email != null) {
            matches.add(new ApplicantMatch(applicantId, 0, 4, email, prospectId, "0"));
        }
        ApplicantMatch[] container = matches.toArray(new ApplicantMatch[matches.size()]);
        return container;
    }

    int getApplicantFromProspect(String prospectId) {
        final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        int applicantIdInProspectTable = prospectDAO.getApplicantId(prospectId);
        return applicantIdInProspectTable;
    }

    private void validateNumberOfApplicantRows(int applicantId) throws AutomationException {
        Assert.assertEquals(getApplicantData(applicantId), 1);
    }

    int getApplicantData(int applicantId) throws AutomationException {
        final ApplicantDAO applicantDao = prospectDBConnection.getDataAccessObject(ApplicantDAO.class);
        return applicantDao.getNumberOfApplicants(applicantId);
    }

    String getCreatedDate(int applicantId) throws AutomationException {
        final ApplicantDAO applicantDao = prospectDBConnection.getDataAccessObject(ApplicantDAO.class);
        return applicantDao.getCreatedDate(applicantId);
    }

    String getModifiedDate(int applicantId) throws AutomationException {
        final ApplicantDAO applicantDao = prospectDBConnection.getDataAccessObject(ApplicantDAO.class);
        return applicantDao.getModifiedDate(applicantId);
    }

    String getProspectModifiedDate(String prospectId) throws AutomationException {
        final ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        return prospectDao.getModifiedDate(prospectId);
    }

    ProspectResponse updateProspectAndValidate(String prospect1Id, ProspectRequest request2)
            throws AutomationException, HttpRequestException {
        ProspectResponse response2 = internalProspectService.updateProspect(UUID.fromString(prospect1Id), request2);
        Assert.assertEquals(response2.getProspect().getProspectId().toString(), prospect1Id);
        return response2;
    }

    void doTestCreationOfApplicantsWithRequestData(ProspectRequest request1, ProspectRequest request2, boolean isEquals)
            throws AutomationException, HttpRequestException {
        final ProspectResponse response1 = internalProspectService.createProspect(request1);
        final ProspectResponse response2 = internalProspectService.createProspect(request2);
        compareAndTeardownApplicantData(request1, request2, response1, response2, isEquals);
    }

    void compareApplicantData(ProspectRequest request1, ProspectRequest request2, ProspectResponse response1,
                              ProspectResponse response2, boolean isEquals) throws AutomationException, HttpRequestException {
        compareAndTeardownApplicantData(request1, request2, response1, response2, isEquals, false);
    }

    void compareAndTeardownApplicantData(ProspectRequest request1, ProspectRequest request2, ProspectResponse response1,
                                         ProspectResponse response2, boolean isEquals)
                                                 throws AutomationException, HttpRequestException {
        compareAndTeardownApplicantData(request1, request2, response1, response2, isEquals, true);
    }

    void compareAndTeardownApplicantData(ProspectRequest request1, ProspectRequest request2, ProspectResponse response1,
                                         ProspectResponse response2, boolean isEquals, boolean doTeardown)
                                                 throws AutomationException, HttpRequestException {

        if (isEquals) {
            int applicant1 = verifyApplicantMatchData(request1, response1, request2, response2);
            if (doTeardown) {
                internalProspectService.nukeApplicant(applicant1);
                internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
                internalProspectService.nukeProspect(response2.getProspect().getProspectId().toString());
            }
        } else {
            int applicant1 = verifyApplicantMatchData(request1, response1);
            int applicant2 = verifyApplicantMatchData(request2, response2);
            Assert.assertNotEquals(applicant1, applicant2);
            if (doTeardown) {
                internalProspectService.nukeApplicant(applicant1);
                internalProspectService.nukeApplicant(applicant2);
                internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
                internalProspectService.nukeProspect(response2.getProspect().getProspectId().toString());
            }
        }
    }

    String generateRandomNumber(int length) {
        long pow = (long) Math.pow(10, length);
        long number = (long) Math.floor(Math.random() * 9 * pow) + (1 * pow);
        return String.valueOf(number);
    }
}
