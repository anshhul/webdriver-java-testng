
package test.api.java.platformprospect;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class GetProspectByIdTest extends PlatformProspectTestBase {

    private static final String PROSPECT_TYPE = "OFFER_CODE";
    private static final String INVALID_OFFER_CODE = "INVALID_OFFER_CODE";

    @Resource
    private CloseableJdbcConnection prospectDBConnection;


    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetProspectByOfferCode() throws AutomationException, HttpRequestException {
        final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);

        final String prospectId = prospectDAO.getActiveOfferCode();
        final ProspectResponse prospectResponse = pubSiteProspectService.getProspectById(prospectId, PROSPECT_TYPE);

        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = {
            HttpInternalServerErrorException.class})
    public void testGetProspectByInvalidOfferCode() throws AutomationException, HttpRequestException {
        pubSiteProspectService.getProspectById(INVALID_OFFER_CODE, PROSPECT_TYPE);
    }
}
