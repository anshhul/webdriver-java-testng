
package test.api.java.platformEmail;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessage;
import com.prosper.automation.model.platform.email.UpdateEmailMessage;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 7/25/16.
 */
public final class UpdateEmailTest extends PlatformEmailTestBase {

    private static final Integer DEFAULT_EMAIL_SUBJECT_LENGTH = 10;
    private static final String USER_TEST_EMAIL = Constant.getUniqueEmail();
    private static final String USER_EMAIL_SUBJECT = Constant.getStringWithLength(DEFAULT_EMAIL_SUBJECT_LENGTH);

    private EmailMessage emailMessageRequest;
    private EmailMessage emailMessage;


    @BeforeClass
    public void prepareTestData() throws AutomationException, HttpRequestException {
        emailMessageRequest = createGenericEmailMessage(USER_TEST_EMAIL, USER_EMAIL_SUBJECT);
        emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testUpdateEmailIsDeleted() throws AutomationException, HttpRequestException {
        final UpdateEmailMessage updateEmailMessage = new UpdateEmailMessage.Builder()
                .withIsDeleted(true)
                .build();

        pubSiteEmailService.updateEmail(emailMessage.getMessageRequestKey(), updateEmailMessage);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertTrue(emailMessageResponse.getIsDeleted());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testUpdateEmailIsUserRead() throws AutomationException, HttpRequestException {
        final UpdateEmailMessage updateEmailMessage = new UpdateEmailMessage.Builder()
                .withIsUserRead(true)
                .build();

        pubSiteEmailService.updateEmail(emailMessage.getMessageRequestKey(), updateEmailMessage);

        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getMessageRequestKey());
        Assert.assertTrue(emailMessageResponse.getIsUserRead());
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testUpdateEmailWithoutRequestBody() throws AutomationException, HttpRequestException {
        pubSiteEmailService.updateEmail(emailMessage.getMessageRequestKey(), null);
    }
}
