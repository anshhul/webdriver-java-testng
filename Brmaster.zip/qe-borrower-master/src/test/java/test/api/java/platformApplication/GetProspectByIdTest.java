
package test.api.java.platformApplication;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

import java.util.List;

/**
 * @author by rsubramanyam
 * @since 0.0.1
 */
public final class GetProspectByIdTest extends PlatformApplicationTestBase {

    private static final String PROSPECT_TYPE = "OFFER_CODE";
    private static final String INVALID_OFFER_CODE = "INVALID_OFFER_CODE";
    @Autowired
    private CloseableJdbcConnection prospectDBConnection;
    String emailAddress;
    private static ProspectRequest request;
    ProspectResponse response;
    ProspectResponse prospectResponse;
    ProspectResponse prospectResponseByProspectService;


    @BeforeClass
    public void setUp() throws AutomationException, HttpRequestException {
        emailAddress = "eco_auto_" + Constant.newUuid() + "@c1.dev";
        request =
                buildGenericProspectRequestWithAllFields("eco_auto_" + Constant.newUuid(), "eco_auto_" + Constant.newUuid(),
                        emailAddress);
        response = platformApplicationService.createProspect(request);

        final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        final String prospectId = prospectDAO.getOfferCodeByEmailId(request.getProspect().getContactInfo().getEmail());
        prospectResponse = platformApplicationService.getProspectById(prospectId, "OFFER_CODE");

        Assert.assertNotNull(prospectResponse);

        prospectResponseByProspectService =
                pubSiteProspectService.getProspectById(prospectId, PROSPECT_TYPE);
        AddressInfo infoFromProspectServiceCall = prospectResponseByProspectService.getProspect().getAddressInfo();

        // Sync up the two types of AddressInfo responses to match
        prospectResponseByProspectService.getProspect().getAddressInfo().setAddress(infoFromProspectServiceCall.getAddress1());
        prospectResponseByProspectService.getProspect().getAddressInfo()
                .setAddressAsStringForApplication(infoFromProspectServiceCall.getAddressAsString());
        prospectResponseByProspectService.getProspect().getAddressInfo()
                .setAddressType(String.valueOf(infoFromProspectServiceCall.getAddressTypeId()));
        response.getProspect().getAddressInfo().setAddress(infoFromProspectServiceCall.getAddress1());
        response.getProspect().getAddressInfo()
                .setAddressAsStringForApplication(infoFromProspectServiceCall.getAddressAsString());
        response.getProspect().getAddressInfo().setAddressType(String.valueOf(infoFromProspectServiceCall.getAddressTypeId()));

        prospectResponse.getProspect().getAddressInfo().setAddress1(infoFromProspectServiceCall.getAddress1());
        prospectResponse.getProspect().getAddressInfo().setAddressAsString(infoFromProspectServiceCall.getAddressAsString());
        prospectResponse.getProspect().getAddressInfo()
                .setAddressTypeId(Integer.valueOf(infoFromProspectServiceCall.getAddressType()));

    }

    @AfterClass
    public void tearDown() throws AutomationException, HttpRequestException {
        platformApplicationService.nukeProspectByOfferCode(response.getProspect().getOfferCode());
       // platformApplicationService.nukeProspect(response.getProspect().getProspectId().toString());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchAddressInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getAddressInfo().getState(), prospectResponseByProspectService.getProspect()
                .getAddressInfo().getState());
        Assert.assertEquals(prospectResponse.getProspect().getAddressInfo().getSourceTypeId(), prospectResponseByProspectService.getProspect()
                .getAddressInfo().getSourceTypeId());
        Assert.assertEquals(prospectResponse.getProspect().getAddressInfo().getStateOfResidence(), prospectResponseByProspectService.getProspect()
                .getAddressInfo().getStateOfResidence());
        Assert.assertFalse(prospectResponse.getProspect().getAddressInfo().getZipCode().contains("-"));
        Assert.assertTrue(StringUtils.isAllUpperCase(prospectResponse.getProspect().getAddressInfo().getCity()));
        Assert.assertEquals(prospectResponse.getProspect().getAddressInfo().getAddress(), response.getProspect().getAddressInfo().getAddress());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeTrackingInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getTrackingInfo(), prospectResponseByProspectService.getProspect()
                .getTrackingInfo());
        Assert.assertEquals(prospectResponse.getProspect().getTrackingInfo(), response.getProspect().getTrackingInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodePartnerInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getPartnerInfo(), prospectResponseByProspectService.getProspect()
                .getPartnerInfo());
        Assert.assertEquals(prospectResponse.getProspect().getPartnerInfo(), response.getProspect().getPartnerInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodePartnerApiInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getPartnerApiInfo(), prospectResponseByProspectService
                .getProspect().getPartnerApiInfo());
        Assert.assertEquals(prospectResponse.getProspect().getPartnerApiInfo(), response.getProspect().getPartnerApiInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchContactInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getContactInfo().getEmail(), response
                .getProspect()
                .getContactInfo().getEmail());
        List<PhoneNumber> pNumbersFromApplication = prospectResponse.getProspect().getContactInfo().getPhoneNumbers();
        List<PhoneNumber> pNumbersByProspectService = response.getProspect().getContactInfo().getPhoneNumbers();
        for (int index = 0; index < pNumbersFromApplication.size(); index++) {
            Assert.assertEquals(pNumbersFromApplication.get(index).getPhoneNumber(), pNumbersByProspectService.get(index)
                    .getPhoneNumber());
            Assert.assertEquals(pNumbersFromApplication.get(index).getAreaCode(), pNumbersByProspectService.get(index)
                    .getAreaCode());
            Assert.assertEquals(pNumbersFromApplication.get(index).getPhoneType(), pNumbersByProspectService.get(index)
                    .getPhoneType());
            if (request.getProspect().getContactInfo().getPhoneNumbers().get(index).getExtension() != null)
                Assert.assertNotNull(pNumbersFromApplication.get(index).getCountryCode());
            Assert.assertEquals(pNumbersFromApplication.get(index).getExtension(), pNumbersByProspectService.get(index)
                    .getExtension());
            Assert.assertEquals(pNumbersFromApplication.get(index).getVisible(), pNumbersByProspectService.get(index)
                    .getVisible());
            Assert.assertEquals(pNumbersFromApplication.get(index).getPhoneTypeId(), pNumbersByProspectService.get(index)
                    .getPhoneTypeId());
        }
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchEmploymentInfo() throws AutomationException, HttpRequestException {
        EmploymentInfo infoFromApplication = prospectResponse.getProspect().getEmploymentInfo();
        EmploymentInfo infoFromProspect = prospectResponseByProspectService.getProspect().getEmploymentInfo();
        Assert.assertEquals(infoFromApplication.getAnnualIncome(), infoFromProspect.getAnnualIncome());
        Assert.assertEquals(infoFromApplication.getEmployerName(), infoFromProspect.getEmployerName());
        Assert.assertEquals(infoFromApplication.getEmploymentStatusId(), infoFromProspect.getEmploymentStatusId());
        Assert.assertEquals(infoFromApplication.getOccupationId(), infoFromProspect.getOccupationId());
        Assert.assertEquals(infoFromApplication.getEmploymentMonth(), infoFromProspect.getEmploymentMonth());
        Assert.assertEquals(infoFromApplication.getEmploymentYear(), infoFromProspect.getEmploymentYear());
        Assert.assertEquals(infoFromApplication.getIsIncomeVerifiable(), infoFromProspect.getIsIncomeVerifiable());
        Assert.assertEquals(infoFromApplication.getIsSelfEmployed(), infoFromProspect.getIsSelfEmployed());
        Assert.assertEquals(infoFromApplication.getMonthlyIncome(), infoFromProspect.getMonthlyIncome());

        // Phone Information
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getPhoneNumber(), infoFromProspect.getEmployerPhone()
                .getPhoneNumber());
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getAreaCode(), infoFromProspect.getEmployerPhone()
                .getAreaCode());
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getPhoneType(), infoFromProspect.getEmployerPhone()
                .getPhoneType());
        if (request.getProspect().getEmploymentInfo().getEmployerPhone().getExtension() != null)
            Assert.assertNotNull(infoFromApplication.getEmployerPhone().getCountryCode());
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getExtension(), infoFromProspect.getEmployerPhone()
                .getExtension());
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getVisible(), infoFromProspect.getEmployerPhone()
                .getVisible());
        Assert.assertEquals(infoFromApplication.getEmployerPhone().getPhoneTypeId(), infoFromProspect.getEmployerPhone()
                .getPhoneTypeId());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchLoanInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getLoanAmount(), response.getProspect().getLoanAmount());
        Assert.assertEquals(prospectResponse.getProspect().getLoanPurposeId(),
                prospectResponseByProspectService.getProspect().getLoanPurposeId());
        Assert.assertEquals(prospectResponse.getProspect().getLoanPurposeId(), response.getProspect().getLoanPurposeId());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchPersonalInfo() throws AutomationException, HttpRequestException {
        Assert.assertNotNull(prospectResponse);
        Assert.assertEquals(prospectResponse.getProspect().getPersonalInfo(), response.getProspect().getPersonalInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchBankAccountInfo() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getProspect().getBankAccountInfo(), prospectResponseByProspectService
                .getProspect()
                .getBankAccountInfo());
        Assert.assertEquals(prospectResponse.getProspect().getBankAccountInfo(), response.getProspect().getBankAccountInfo());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchChannel() throws AutomationException, HttpRequestException {
        // Set expected channelGroupID to be null because it is no more included
        prospectResponseByProspectService.getChannel().setChannelGroupId(null);
        response.getChannel().setChannelGroupId(null);
        Assert.assertEquals(prospectResponse.getChannel(), prospectResponseByProspectService.getChannel());
        Assert.assertEquals(prospectResponse.getChannel(), response.getChannel());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchCampaign() throws AutomationException, HttpRequestException {
        // These are old .NET legacy ids being removed
        prospectResponseByProspectService.getCampaign().setLegacyChannel(null);
        response.getCampaign().setLegacyChannel(null);
        prospectResponseByProspectService.getCampaign().setLegacyId(null);
        response.getCampaign().setLegacyId(null);
        Assert.assertEquals(prospectResponse.getCampaign(), prospectResponseByProspectService.getCampaign());
        Assert.assertEquals(prospectResponse.getCampaign(), response.getCampaign());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchProgram() throws AutomationException, HttpRequestException {
        prospectResponseByProspectService.getProgram().setFallBackProgramUsed(null);
        response.getProgram().setFallBackProgramUsed(null);
        prospectResponseByProspectService.getProgram().setLegacyChannel(null);
        response.getProgram().setLegacyChannel(null);
        prospectResponseByProspectService.getProgram().setLegacyId(null);
        response.getProgram().setLegacyId(null);
        prospectResponseByProspectService.getProgram().setWorkFlowTypeId(null);
        response.getProgram().setWorkFlowTypeId(null);
        Assert.assertEquals(prospectResponse.getProgram().getRefMc(), prospectResponseByProspectService.getProgram().getRefMc());
        Assert.assertEquals(prospectResponse.getProgram().getPricingId(), prospectResponseByProspectService.getProgram().getPricingId());
        Assert.assertEquals(prospectResponse.getProgram().getRefMc(), response.getProgram().getRefMc());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchPricing() throws AutomationException, HttpRequestException {
        Assert.assertEquals(prospectResponse.getPricing(), prospectResponseByProspectService.getPricing());
        Assert.assertEquals(prospectResponse.getPricing(), response.getPricing());
    }

    @DataProvider(name = "testRelationshipType") public Object[][] relationshipType()
            throws HttpRequestException, AutomationException, CloneNotSupportedException {
        String emailAddress2 = "eco_auto_" + Constant.newUuid() + "@c1.dev";
        ProspectRequest request2 = (ProspectRequest) request.clone();
        request2.getProspect().setRelationshipName("FAMILY");
        request2.getProspect().getContactInfo().setEmail(emailAddress2);
        // Create prospect
        platformApplicationService.createProspect(request);
        final ProspectDAO prospectDAO = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        final String prospectId = prospectDAO.getOfferCodeByEmailId(request2.getProspect().getContactInfo().getEmail());
        // Get prospect
        ProspectResponse prospectResponse2 = platformApplicationService.getProspectById(prospectId, "OFFER_CODE");
        ProspectResponse prospectResponseByProspectService2 = pubSiteProspectService.getProspectById(prospectId, PROSPECT_TYPE);

        return new Object[][] {
                // With relationship type id
                {prospectResponse, prospectResponseByProspectService},
                // With relationship type name
                {prospectResponse2, prospectResponseByProspectService2}};
    }

    @Test(dataProvider = "testRelationshipType", groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetNewProspectByOfferCodeMatchProspectWithRelationshipType(ProspectResponse prospectResponse, ProspectResponse prospectResponseByProspectService) throws AutomationException, HttpRequestException {
        compareResponsesMiscFields(prospectResponse, prospectResponseByProspectService);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = {
            Exception.class})
    public void testGetProspectByEmptyOfferCode() throws AutomationException, HttpRequestException {
        final ProspectResponse prospectResponse = platformApplicationService.getProspectById("", "OFFER_CODE");
        Assert.assertNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetProspectByInvalidOfferCode() throws AutomationException, HttpRequestException {
        final ProspectResponse prospectResponse = platformApplicationService.getProspectById(INVALID_OFFER_CODE, "OFFER_CODE");
        Assert.assertNull(prospectResponse);
    }
}
