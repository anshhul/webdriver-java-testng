
package test.api.java.applicantDb.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/4/16.
 */
public interface MergeApplicantTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by email", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email B. Update prospect B with email A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test to ensure old applicant retained", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with Email A, Create prospect B with email B and update it later to have email A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeApplicantIdOldRetained()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 9 digit SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, (9 digit SSN) Create prospect A with SSN A, Create prospect B with SSN B. Update Prospect B to have SSN A"}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeBy9Ssn() throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test match 9 digit SSN holding applicant by 7 digit SSN, First initial, Last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 9 digit SSN A, Create prospect B with 7 digit SSN B. Update prospect B to match 7 digit SSN A, first initial A, last name A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeBy7SsnFirstInitialLastNameInto9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First initial, Last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 7 digit SSN A, Create prospect B with 7 digit SSN B. Update prospect B to match 7 digit SSN A, first initial A, last name A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeBy7SsnFirstInitialLastNameInto7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test match 9 digit SSN applicant by 7 digit SSN, First Initial, Address, Zipcode", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 9 digit SSN A, Create prospect B with 7 digit SSN B. Update prospect B to match 7 digit SSN A, first initial A, address A, zipcode A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeBy7ssnSsnLastNameAddressZipInto9Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;

    @ProsperZephyr(project = BMP, testTitle = "Test match applicant by 7 digit SSN, First Initial, Address, Zipcode", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect A with 9 digit SSN A, Create prospect B with 7 digit SSN B. Update prospect B to match 7 digit SSN A, first initial A, address A, zipcode A."}, expectedResult = "Single applicant finally created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testApplicantMergeBy7ssnSsnFIAddressZipInto7Ssn()
            throws AutomationException, HttpRequestException, CloneNotSupportedException;
}
