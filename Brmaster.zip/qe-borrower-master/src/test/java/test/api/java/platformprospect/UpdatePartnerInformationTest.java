
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.CampaignSource;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/3/16.
 */
public final class UpdatePartnerInformationTest extends AffiliatePartnerTestBase {

    private String campaignSourceId;
    private String partnerName;

    private CampaignSource testCampaignSource;


    @BeforeClass(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void createTestPartner() throws AutomationException, HttpRequestException {
        partnerName = createUniquePartnerName();

        testCampaignSource = createGenericCampaignSourceRequest(partnerName);
        campaignSourceId = internalProspectService.createPartner(testCampaignSource).getCampaignSourceId();
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testUpdatePartnerName() throws AutomationException, HttpRequestException {
        final CampaignSource campaignSourceUpdateRequest =
                createUpdatePartnerNameRequest(campaignSourceId, createUniquePartnerName());
        runUpdatePartnerInformationTest(campaignSourceUpdateRequest);
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testUpdatePartnerContactName() throws AutomationException, HttpRequestException {
        final CampaignSource campaignSourceUpdateRequest =
                createUpdateContactNameRequest(campaignSourceId, Constant.getRandomString());
        runUpdatePartnerInformationTest(campaignSourceUpdateRequest);
    }

    @Test(enabled = false, description = "BMP-2309", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testUpdatePartnerContactPhoneNumber() throws AutomationException, HttpRequestException {
        final CampaignSource campaignSourceUpdateRequest =
                createUpdateContactPhoneNumberRequest(campaignSourceId, "(866) 615-6320");
        runUpdatePartnerInformationTest(campaignSourceUpdateRequest);
    }

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testUpdatePartnerContactEmail() throws AutomationException, HttpRequestException {
        final CampaignSource campaignSourceUpdateRequest =
                createUpdateContactEmailRequest(campaignSourceId, Constant.getGloballyUniqueEmail());
        runUpdatePartnerInformationTest(campaignSourceUpdateRequest);
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testUpdatePartnerWithNonExistingCampaignSourceId() throws HttpRequestException, AutomationException {
        final CampaignSource campaignSourceUpdateRequest =
                createUpdateContactEmailRequest(NON_EXISTING_CAMPAIGN_SOURCE_ID, Constant.getGloballyUniqueEmail());
        runUpdatePartnerInformationTest(campaignSourceUpdateRequest);
    }

    private void runUpdatePartnerInformationTest(final CampaignSource campaignSourceUpdateRequest)
            throws AutomationException, HttpRequestException {
        internalProspectService.updatePartner(campaignSourceUpdateRequest);

        final CampaignSource campaignSourceResponse =
                internalProspectService.getPartner(campaignSourceUpdateRequest.getCampaignSourceId());
        Assert.assertEquals(campaignSourceResponse, campaignSourceUpdateRequest);
    }

    private CampaignSource createUpdatePartnerNameRequest(final String campaignSourceId, final String newPartnerName) {
        return new CampaignSource.Builder()
                .withCampaignSourceId(campaignSourceId)
                .withName(newPartnerName)
                .withCompanyName(DEFAULT_COMPANY_NAME)
                .withContactName(DEFAULT_CONTACT_NAME)
                .withContactEmail(DEFAULT_CONTACT_EMAIL)
                .withContactPhone(DEFAULT_CONTACT_PHONE)
                .build();
    }

    private CampaignSource createUpdateContactNameRequest(final String campaignSourceId, final String contactName) {
        return new CampaignSource.Builder()
                .withCampaignSourceId(campaignSourceId)
                .withName(partnerName)
                .withCompanyName(DEFAULT_COMPANY_NAME)
                .withContactName(contactName)
                .withContactEmail(DEFAULT_CONTACT_EMAIL)
                .withContactPhone(DEFAULT_CONTACT_PHONE)
                .build();
    }

    private CampaignSource createUpdateContactPhoneNumberRequest(final String campaignSourceId, final String contactPhoneNumber) {
        return new CampaignSource.Builder()
                .withCampaignSourceId(campaignSourceId)
                .withName(partnerName)
                .withCompanyName(DEFAULT_COMPANY_NAME)
                .withContactName(DEFAULT_CONTACT_NAME)
                .withContactEmail(DEFAULT_CONTACT_EMAIL)
                .withContactPhone(contactPhoneNumber)
                .build();
    }

    private CampaignSource createUpdateContactEmailRequest(final String campaignSourceId, final String contactEmail) {
        return new CampaignSource.Builder()
                .withCampaignSourceId(campaignSourceId)
                .withName(partnerName)
                .withCompanyName(DEFAULT_COMPANY_NAME)
                .withContactName(DEFAULT_CONTACT_NAME)
                .withContactEmail(contactEmail)
                .withContactPhone(DEFAULT_CONTACT_PHONE)
                .build();
    }
}
