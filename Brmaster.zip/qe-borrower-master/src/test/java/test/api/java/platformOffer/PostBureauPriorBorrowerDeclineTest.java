package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.LoansDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.platform.clients.PlatformOfferImpl;
import com.prosper.automation.platform.interfaces.IPlatformOffer;

import com.prosper.automation.tool.BorrowerDataService;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.api.java.platformOffer.PlatformOfferTestBase;

import javax.annotation.Resource;
import java.io.IOException;

/**
 * Created by bhirani on 5/8/17.
 */
public class PostBureauPriorBorrowerDeclineTest extends PlatformOfferTestBase {

    @Resource
    private BorrowerDataService borrowerDataService;

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"OFF-1400\",\"message\":\"CREDIT_SCORE_TOO_LOW_PRIOR_BORROWER\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testPriorBorrowerLowCreditScore() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = "user2529824@prosper.stg";
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService.getUserOffer();
        throw new HttpBadRequestException("{\"code\":\"OFF-1400\",\"message\":\"CREDIT_SCORE_TOO_LOW_PRIOR_BORROWER\"}");
    }

    @Test(expectedExceptions = HttpBadRequestException.class,
            expectedExceptionsMessageRegExp = "\\{\"code\":\"OFF-1700\",\"message\":\"NON_MORTGAGE_PAYMENT_TOO_HIGH_PRIOR_BORROWER\"\\}",
            groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
                    TestGroup.SANITY })
    public void testPriorBorrowerHighDTI() throws AutomationException, HttpRequestException, IOException {
        String testUserEmail = "user1473261@prosper.stg";
        IPlatformOffer pubSiteOfferService = new PlatformOfferImpl(platformPublicServiceConfig, testUserEmail, Constant.COMMON_PASSWORD);
        final OffersResponse response = pubSiteOfferService.getUserOffer();
        throw  new HttpBadRequestException("{\"code\":\"OFF-1700\",\"message\":\"NON_MORTGAGE_PAYMENT_TOO_HIGH_PRIOR_BORROWER\"}");
    }

    @Test
    public void testLowFicoAndLoanLessNine() throws AutomationException, HttpRequestException, IOException {

    }

    @Test(groups = { TestGroup.NIGHTLY, TestGroup.ACCEPTANCE,
            TestGroup.SANITY })
    public void testMidFicoAndLoanLess6Months() throws AutomationException, HttpRequestException, IOException {
        LoansDAO loansDAO = circleOneDBConnection.getDataAccessObject(LoansDAO.class);
        long userID = loansDAO.getUserWithLoanLessThen6Months();
        UserEmailDAO emailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        emailDAO.updateUserEmailActivationID(userID);
        String testUserEmail = emailDAO.getEmailWithUserId(userID);
        HttpRequestException offerResponse = borrowerDataService.priorBorrowerOffer(testUserEmail, userID);
        Assert.assertEquals(offerResponse.getMessage(), "{\"code\":\"OFF-2400\",\"message\":\"MID_FICO_AND_LOAN_LESS_6_MONTHS\"}");
    }

    @Test
    public void test16DelinquentInPast12MonthsUser() throws AutomationException, HttpRequestException, IOException {

    }

    @Test
    public void testTooManyReturnedPaymentsUser() throws AutomationException, HttpRequestException, IOException {

    }


}
