
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationEmploymentInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test with different employment_info", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide invalid fields in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testEmploymentInfo")
    void testEmploymentInfoWithParameters(String statusId, double annualIncome,
                                          int empMonth, int empYear,
                                          ResponseErrorsHelper expectedError)
                                                  throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with different employment status bounds check", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different employment status values in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testEmploymentStatusBoundsCheck")
    void testEmploymentStatusBoundsCheck(String statusId,
                                         ResponseErrorsHelper expectedError)
                                                 throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing employment_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide missing employment_info fields in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test(dataProvider = "testMissingEmpInfo")
    void testEmploymentInfoWithMissingParameters(String fieldName,
                                                 ResponseErrorsHelper expectedError)
                                                         throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing employment_info from the request", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide no employment_info in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test
    void testEmploymentInfoTotallyMissing() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with negative annual income", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide negative annual income in the request"}, expectedResult = "HTTP 200 OK Response without errors")

    @Test
    void testEmploymentInfoNegativeAnnualIncome() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with char occupation id", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide char occupation id in the request"}, expectedResult = "HTTP 200 OK Response without errors")

    @Test
    void testEmploymentInfoCharOccupationId() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with char employee month", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide char employee month in the request"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test
    void testEmploymentInfoCharEmployeeMonth() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with char employee year", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide char employee year"}, expectedResult = "HTTP 200 OK Response with errors")

    @Test
    void testEmploymentInfoCharEmployeeYear() throws AutomationException, HttpRequestException;
}
