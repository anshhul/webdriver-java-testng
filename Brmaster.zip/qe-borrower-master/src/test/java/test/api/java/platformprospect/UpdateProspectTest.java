
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PersonalInfoConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.UUID;

/**
 * A test class for /prospects/prospect/:prospectId endpoint.
 *
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class UpdateProspectTest extends PlatformProspectTestBase {

	/**
	 * Creates new prospect data.
	 *
	 * @throws AutomationException
	 * @throws HttpRequestException
	 */
	private ProspectRequest createProspectRequest() throws AutomationException, HttpRequestException {
		final ProspectResponse testProspectResponse = pubSiteProspectService
				.createProspect(buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail()));
		Assert.assertNotNull(testProspectResponse);

		final ProspectRequest prospectRequest = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC,
				Constant.getGloballyUniqueEmail());
		prospectRequest.getProspect().setProspectId(testProspectResponse.getProspect().getProspectId());

		return prospectRequest;
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectFirstNameWithLeftPaddedSpecialCharacter() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectFirstNameWithRightPaddedSpecialCharacter() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectWithSpecialCharacterInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectFirstNameWithLeftPaddedBlankSpace() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectFirstNameWithRightPaddedBlankSpace() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithBlankSpaceInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
		pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithLeftPaddedDashOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.DASH_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithRightPaddedDashOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.DASH_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(enabled = false, groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithDashInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.DASH_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithLeftPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithRightPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect()
				.setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithBlankSpaceInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testUpdateProspectWithNullPhoneTypeId() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBER_WITHOUT_TYPE_IDS);

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, enabled = false, description = "https://jira.prosper.com/browse/BOR-2745")
	public void testUpdateProspectPhoneNumber() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBERS_WITH_DIFFERENT_TYPE_IDS);

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		org.testng.Assert.assertNotNull(prospectResponse);

		final List<PhoneNumber> actualPhoneNumbers = prospectResponse.getProspect().getContactInfo().getPhoneNumbers();
		final List<PhoneNumber> expectedPhoneNumbers = prospectRequest.getProspect().getContactInfo().getPhoneNumbers();

		// assert number of phone numbers correctness
		org.testng.Assert.assertEquals(actualPhoneNumbers.size(), expectedPhoneNumbers.size());
		// assert phone numbers are equal
		org.testng.Assert.assertEquals(actualPhoneNumbers, expectedPhoneNumbers);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, enabled = false, description = "https://jira.prosper.com/browse/BOR-2745")
	public void testUpdateProspectEmployerPhoneNumber() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().getEmploymentInfo().setEmployerPhone(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1);

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		org.testng.Assert.assertNotNull(prospectResponse);

		final PhoneNumber actualPhoneNumber = prospectResponse.getProspect().getEmploymentInfo().getEmployerPhone();
		final PhoneNumber expectedPhoneNumber = prospectRequest.getProspect().getEmploymentInfo().getEmployerPhone();
		Assert.assertEquals(actualPhoneNumber, expectedPhoneNumber);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectWithLeftPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectWithRightPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
	public void testUpdateProspectWithSpecialCharacterInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = createProspectRequest();
		final UUID testProspectId = prospectRequest.getProspect().getProspectId();
		prospectRequest.getProspect().setPersonalInfo(
				PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));

		final ProspectResponse prospectResponse = pubSiteProspectService.updateProspect(testProspectId, prospectRequest);
		Assert.assertNotNull(prospectResponse);
	}
}
