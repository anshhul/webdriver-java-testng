
package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PersonalInfoConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class CreateProspectTest extends PlatformProspectTestBase {

    private ProspectRequest createProspectRequest() throws AutomationException, HttpRequestException {
        return buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateValidProspect() throws AutomationException, HttpRequestException {
        final ProspectResponse response = pubSiteProspectService.createProspect(createProspectRequest());
        Assert.assertNotNull(response);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithLeftPaddedSpecialCharacterOnFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithRightPaddedSpecialCharacterOnFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateWithSpecialCharacterInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithLeftPaddedBlankSpaceOnFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithRightPaddedBlankSpaceOnFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsFirstNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateWithBlankSpaceInTheMiddleOfFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsFirstNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testCreateInvalidProspectWithAlphanumericFirstName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getPersonalInfo().setFirstName(Constant.TEST_ALPHANUMERIC_FIRST_NAME);
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testCreateInvalidProspectWithAlphanumericLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getPersonalInfo().setLastName(Constant.TEST_ALPHANUMERIC_LAST_NAME);
        pubSiteProspectService.createProspect(prospectRequest);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutEmail() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getContactInfo().setEmail(null);

        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateInvalidProspectWithZeroAnnualIncome() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getEmploymentInfo().setAnnualIncome(0.0);

        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateInvalidProspectWithoutAnnualIncome() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getEmploymentInfo().setAnnualIncome(null);

        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutAddressInfo() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setAddressInfo(null);

        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithoutCreditScore() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setCreditQualityId(null);

        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithLeftPaddedDashOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithRightPaddedDashOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithDashInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.DASH_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithLeftPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithRightPaddedBlankSpaceOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect()
                .setPersonalInfo(PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithBlankSpaceInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.SINGLE_SPACE_STRING));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreateProspectWithNullPhoneTypeId() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBER_WITHOUT_TYPE_IDS);
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithLeftPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameLeftPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithRightPaddedSpecialCharacterOnLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNameRightPaddedWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.AP_1008)
    public void testCreateProspectWithSpecialCharacterInTheMiddleOfLastName() throws AutomationException, HttpRequestException {
        final ProspectRequest prospectRequest = createProspectRequest();
        prospectRequest.getProspect().setPersonalInfo(
                PersonalInfoConstant.buildMaryHopkinsLastNamePaddedInTheMiddleWith(Constant.STRING_WITH_SPECIAL_CHARACTERS));
        final ProspectResponse prospectResponse = pubSiteProspectService.createProspect(prospectRequest);
        Assert.assertNotNull(prospectResponse);
    }
}
