
package test.api.java.platformOffer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.asserts.PricingTestAssert;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.BorrowerPricingData;
import com.prosper.automation.model.platform.pricing.PricingRequest;
import com.prosper.automation.model.platform.pricing.PricingResponse;
import com.prosper.automation.platform.interfaces.IPlatformOffer;
import com.prosper.automation.util.Rounding;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class PricingDataTest extends PricingDataTestBase {

    private static final Logger LOG = Logger.getLogger(PricingDataTest.class.getSimpleName());

    @Autowired
    private IPlatformOffer pubSiteOfferService;


    @Test(dataProvider = PRICING_DATA, alwaysRun = true)
    public void testApplicantPrice(final BorrowerPricingData pricingData) throws HttpRequestException, AutomationException, JsonProcessingException {
        if (pricingData == null) {
            LOG.info("Pricing Data is  null");
            return;
        }

        final SoftAssert softAssert = new SoftAssert();
        PricingRequest pricingRequest = null;
        final long applicantId = pricingData.getApplicantId();
        LOG.info(String.format("Validating applicant with id: %d", applicantId));
        if (pricingVersion.equals("6.018")) {
            pricingRequest = buildPricingRequest(pricingData, pricingTestState, pricingVersion);
        } else {
            pricingRequest = buildPricingRequestTU(pricingData, pricingTestState, pricingVersion);
        }
        ObjectMapper ob = new ObjectMapper();
        LOG.info("Pricing Request: :  " + ob.writeValueAsString(pricingRequest));
        final PricingResponse pricingResponse = pubSiteOfferService.calculatePricing(pricingRequest);

        // Assert platform-offers returns correct pricing version
        final String actualPricingVersion = pricingResponse.getPricingVersion();
        final String expectedPricingVersion = pricingVersion;
        final String pricingVersionMessage = buildValidationMessage(PRICING_VERSION_VALIDATION_TEMPLATE, actualPricingVersion,
                expectedPricingVersion);
        Assert.assertEquals(actualPricingVersion, expectedPricingVersion, pricingVersionMessage);

        if (pricingResponse.isValid() == pricingData.isValid()) {
            if (pricingResponse.isValid()) {
                // monthly payment
                final double actualMonthlyPayment = pricingResponse.getMonthlyPayment();
                final double expectedMonthlyPayment = pricingData.getMonthlyPayment();
                final String monthlyPaymentMessage = buildValidationMessage(MONTHLY_PAYMENT_VALIDATION_TEMPLATE,
                        actualMonthlyPayment, expectedMonthlyPayment);
                LOG.info(monthlyPaymentMessage);
                softAssert.assertTrue(Rounding.ONE_FIFTH.isAcceptable(expectedMonthlyPayment, actualMonthlyPayment),
                        monthlyPaymentMessage);

                // final/last payment
                final double actualFinalPayment = pricingResponse.getLastPayment();
                final double expectedFinalPayment = pricingData.getFinalPaymentAmount();
                final String finalPaymentMessage = buildValidationMessage(FINAL_PAYMENT_VALIDATION_TEMPLATE, actualFinalPayment,
                        expectedFinalPayment);
                LOG.info(finalPaymentMessage);
                softAssert.assertTrue(Rounding.ONE_FIFTH.isAcceptable(actualFinalPayment, expectedFinalPayment),
                        finalPaymentMessage);

                // finance charge
                final double actualFinanceCharge = pricingResponse.getFinanceCharge();
                final double expectedFinanceCharge = pricingData.getFinanceCharge();
                final String financeChargeMessage = buildValidationMessage(FINANCE_CHARGE_VALIDATION_TEMPLATE,
                        actualFinanceCharge, expectedFinanceCharge);
                LOG.info(financeChargeMessage);
                softAssert.assertTrue(Rounding.ONE_FIFTH.isAcceptable(actualFinanceCharge, expectedFinanceCharge),
                        financeChargeMessage);

                // loss rate
                final double actualLossRate = pricingResponse.getLossRate();
                final double expectedLossRate = pricingData.getLossRate();
                final String lossRateMessage = buildValidationMessage(LOSS_RATE_VALIDATION_TEMPLATE, actualLossRate,
                        expectedLossRate);
                LOG.info(lossRateMessage);
                softAssert.assertTrue(Rounding.NONE.isAcceptable(actualLossRate, expectedLossRate), lossRateMessage);

                // partial funding
                final boolean actualIsPartialFunding = pricingResponse.getPartialFunding();
                final boolean expectedIsPartialFunding = pricingData.getPartialFundingElig();
                final String partialFundingMessage = buildValidationMessage(PARTIAL_FUNDING_VALIDATION_TEMPLATE,
                        actualIsPartialFunding, expectedIsPartialFunding);
                LOG.info(partialFundingMessage);
                softAssert.assertEquals(actualIsPartialFunding, expectedIsPartialFunding, partialFundingMessage);

                // borrower APR
                final double actualBorrowerApr = pricingResponse.getBorrowerApr();
                final double expectedBorrowerApr = pricingData.getBorrowerApr();
                final String borrowerAprMessage = buildValidationMessage(BORROWER_APR_VALIDATION_TEMPLATE, actualBorrowerApr,
                        expectedBorrowerApr);
                LOG.info(borrowerAprMessage);
                softAssert.assertTrue(Rounding.ONE_TEN_THOUSANDTH.isAcceptable(actualBorrowerApr, expectedBorrowerApr),
                        borrowerAprMessage);

                // origination fee
                final double actualOriginationFee = pricingResponse.getOriginationFee();
                final double expectedOriginationFee = pricingData.getOriginationFee();
                final String originationFeeMessage = buildValidationMessage(ORIGINATION_FEE_VALIDATION_TEMPLATE,
                        actualOriginationFee, expectedOriginationFee);
                LOG.info(originationFeeMessage);
                softAssert.assertTrue(Rounding.NONE.isAcceptable(actualOriginationFee, expectedOriginationFee),
                        originationFeeMessage);

                // loan cap
                final double actualLoanCap = pricingResponse.getLoanCap();
                final double expectedLoanCap = pricingData.getLoanCap();
                final String loanCapMessage = buildValidationMessage(LOAN_CAP_VALIDATION_TEMPLATE, actualLoanCap,
                        expectedLoanCap);
                LOG.info(loanCapMessage);
                softAssert.assertTrue(Rounding.ONE_TEN_THOUSANDTH.isAcceptable(actualLoanCap, expectedLoanCap), loanCapMessage);
            } else {
                LOG.info(String.format("Pricing data for applicant id: %d is not valid; no validation needed", applicantId));
            }
        } else {
            final double loanAmount = pricingResponse.getLoanAmount();
            if (loanAmount < MIN_LOAN_AMOUNT) {
                LOG.info("Requested loan amount is less than the minimum allowed loan amount.");
            } else if (loanAmount > pricingData.getLoanCap()) {
                LOG.info("Requested loan amount is greater than to the borrower loan cap.");
            } else {
                final String invalidFlagMessage = String.format("Applicant with id %d has invalid valid value.", applicantId);
                LOG.warn(invalidFlagMessage);
                Assert.fail(invalidFlagMessage);
            }
        }

        PricingTestAssert.assertPricing(softAssert, pricingData, pricingResponse, applicantId);
    }
}
