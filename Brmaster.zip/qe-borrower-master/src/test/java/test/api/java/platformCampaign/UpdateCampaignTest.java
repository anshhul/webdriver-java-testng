
package test.api.java.platformCampaign;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.campaign.CampaignRequestResponse;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class UpdateCampaignTest extends PlatformCampaignTestBase {

    private static final String START_DATE = "2015-01-01 13:01:02";
    private static final String END_DATE = "2015-01-01 13:01:02";
    private static final String DURATION = "1";


    @Test
    public void testUpdateCampaign() throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response1 = null;
        CampaignRequestResponse response2 = null;
        try {
            response1 = internalCampaignService.createCampaign(request);
            request.setDescription("New");
            request.setId(response1.getId());
            response2 = internalCampaignService.updateCampaign(request);
            Assert.assertEquals(response2.getDescription(), request.getDescription());
            Assert.assertEquals(response2.getStartDate(), request.getStartDate());
            Assert.assertEquals(response2.getEndDate(), request.getEndDate());
            Assert.assertEquals(response2.getDuration(), request.getDuration());
        } finally {
            if (response1 != null) {
                internalCampaignService.deleteCampaign(response1.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testUpdateCampaignInvalidId() throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response1 = null;
        try {
            response1 = internalCampaignService.createCampaign(request);
            request.setDescription("New");
            request.setId("-1");
            internalCampaignService.updateCampaign(request);
        } finally {
            if (response1 != null) {
                internalCampaignService.deleteCampaign(response1.getId());
            }
        }
    }

    @DataProvider(name = "testDescription")
    public static Object[][] updateDescription() {
        return new Object[][] {{StringUtils.EMPTY}};
    }

    @Test(dataProvider = "testDescription", groups = {
            TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testUpdateDescription(String description)
            throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
            Assert.assertEquals(response.getDescription(), description);
            Assert.assertEquals(response.getStartDate(), START_DATE);
            Assert.assertEquals(response.getEndDate(), END_DATE);
            Assert.assertEquals(response.getDuration(), DURATION);
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }

    @DataProvider(name = "testStartDateEndDate")
    public static Object[][] updateStartEndDates() {
        return new Object[][] { {"2015/01/01 13:01:02 +0000", "2015-01-01 13:01:02 +0000"},
                {"2017-01-01 13:01:02 +0000", "2015-01-01 13:01:02 +0000"},
                {"2015-01-01 13:01:02", "2015-01-01 13:01:02 +0000"},
                {"2015-01-01 13:01:02 +0000", "2015-01-01 13:01:02"},
                {"", "2015-01-01 13:01:02"},
                {"2015-01-01 13:01:02", ""}};
    }

    @Test(dataProvider = "testStartDateEndDate", groups = {
            TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testStartDateEndDateDescription(String startDate, String endDate)
            throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(startDate);
        request.setEndDate(endDate);
        request.setDuration(DURATION);
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }

    @DataProvider(name = "testDuration")
    public static Object[][] durationTest() {
        return new Object[][] { {"0"}, {"-1"}, {"A"}};
    }

    @Test(dataProvider = "testDuration", groups = {
            TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testDuration(String duration)
            throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        request.setDuration(duration);
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }
}
