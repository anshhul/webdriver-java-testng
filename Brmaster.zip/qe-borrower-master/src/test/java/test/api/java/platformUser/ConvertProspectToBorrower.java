
package test.api.java.platformUser;

import org.testng.annotations.Test;

import test.api.java.platformprospect.PlatformProspectTestBase;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProspectRequest;

/**
 * @author Peter Budiono
 * @since 0.0.1
 */
public final class ConvertProspectToBorrower extends PlatformProspectTestBase {

	private static final double LOAN_AMOUNT = 5000;

	private static final long LOAN_PURPOSE_ID = 1;
	private static final long LISTING_CATEGORY_ID = 2;

	private ProspectRequest buildGenericProspectRequest() throws AutomationException, HttpRequestException {
		return buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testValidFlow() throws AutomationException, HttpRequestException {
		runAppByPhoneE2EFlow(buildGenericProspectRequest(), LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testFlowWithNullPhoneTypeId() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getContactInfo().setPhoneNumber(PhoneNumberConstant.PHONE_NUMBER_WITHOUT_TYPE_IDS);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.USR002)
	public void testInvalidFlowWithoutCreditScore() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().setCreditQualityId(null);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_40)
	public void testInvalidFlowWithZeroIncome() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getEmploymentInfo().setAnnualIncome(0.0);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.USR002)
	public void testInvalidFlowWithEmptyEmail() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getContactInfo().setEmail(Constant.BLANK_STRING);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_600)
	public void testInvalidFlowWithWrongFirstName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getPersonalInfo().setFirstName(Constant.RICK_NICK_FIRST_NAME);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class)
	public void testInvalidFlowWithMissingFirstName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getPersonalInfo().setFirstName(Constant.BLANK_STRING);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class)
	public void testInvalidFlowWithMissingLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getPersonalInfo().setLastName(Constant.BLANK_STRING);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_600)
	public void testInvalidFlowWithWrongLastName() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getPersonalInfo().setLastName(Constant.RICK_NICK_LAST_NAME);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE,
			TestGroup.NIGHTLY }, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_600)
	public void testInvalidFlowWithWrongAddress() throws AutomationException, HttpRequestException {
		final ProspectRequest prospectRequest = buildGenericProspectRequest();
		prospectRequest.getProspect().getAddressInfo().setAddress1(AddressInfoConstant.RICK_NICK_ADDRESS_1);
		runAppByPhoneE2EFlow(prospectRequest, LOAN_AMOUNT, LOAN_PURPOSE_ID, LISTING_CATEGORY_ID);
	}
}
