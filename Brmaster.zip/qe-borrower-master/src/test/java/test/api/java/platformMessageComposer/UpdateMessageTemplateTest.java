package test.api.java.platformMessageComposer;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;

/**
 * Created by pbudiono on 8/10/16.
 */
public final class UpdateMessageTemplateTest extends PlatformMessageComposerTestBase {

	protected String createMessageTemplate() throws AutomationException, HttpRequestException {

		final String messageTemplateCode = createUniqueTemplateCode();
		final EmailMessageTemplate emailMessageTemplate = createGenericMessageTemplateRequest(messageTemplateCode);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.createMessageTemplate(emailMessageTemplate);

		return emailMessageTemplateResponse.getMessageTemplateKey();
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateCode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newMessageTemplateCode = Constant.getStringWithLength(10);
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withMessageTemplateCode(newMessageTemplateCode).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getMessageTemplateCode(), newMessageTemplateCode);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateDescription() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String messageTemplateDescription = Constant.getStringWithLength(10);
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withTemplateDescription(messageTemplateDescription).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getTemplateDescription(), messageTemplateDescription);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateContent() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String messageTemplateContent = Constant.getStringWithLength(10);
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withTemplateContent(messageTemplateContent).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getTemplateContent(), messageTemplateContent);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateSubject() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String messageTemplateSubject = Constant.getStringWithLength(10);
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withTemplateSubject(messageTemplateSubject).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getTemplateSubject(), messageTemplateSubject);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateIsShownOnPublicSite() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final Boolean isShownOnPublicSite = false;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withIsShownOnPublicSite(isShownOnPublicSite).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertFalse(emailMessageTemplateResponse.getShownOnPublicSite());
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateIsSentExternally() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final Boolean isSentExternally = false;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder()
				.withIsSentExternally(isSentExternally).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertFalse(emailMessageTemplateResponse.getSentExternally());
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateIsActive() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final Boolean isActive = false;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withIsActive(isActive).build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);
		internalMessageComposerService.getMessageTemplate(messageTemplateKey);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateDeliveryCode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newDeliveryCode = RESPONSYS_DELIVERY_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withDeliveryTypeCode(newDeliveryCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getDeliveryTypeCode(), newDeliveryCode);
	}

	@Test(expectedExceptions = HttpBadRequestException.class, groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateWithInvalidDeliveryCode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newDeliveryCode = INVALID_DELIVERY_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withDeliveryTypeCode(newDeliveryCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);
	}

	@Test(groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateContentCode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newContentCode = TEXT_CONTENT_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withContentTypeCode(newContentCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.getMessageTemplate(messageTemplateKey);
		Assert.assertEquals(emailMessageTemplateResponse.getContentTypeCode(), newContentCode);
	}

	@Test(expectedExceptions = HttpBadRequestException.class, groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateWithInvalidContentCode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newContentCode = INVALID_CONTENT_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withContentTypeCode(newContentCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(messageTemplateKey, emailMessageTemplate);
	}

	@Test(expectedExceptions = HttpBadRequestException.class, groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateWithInvalidKey() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newContentCode = INVALID_CONTENT_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withContentTypeCode(newContentCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(Constant.getRandomIntegerString(10), emailMessageTemplate);
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = { TestGroup.NIGHTLY })
	public void testUpdateMessageTemplateWithNonExistingKey() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();

		final String newContentCode = INVALID_CONTENT_CODE;
		final EmailMessageTemplate emailMessageTemplate = new EmailMessageTemplate.Builder().withContentTypeCode(newContentCode)
				.build();

		internalMessageComposerService.updateMessageTemplate(UUID.randomUUID().toString(), emailMessageTemplate);
	}
}
