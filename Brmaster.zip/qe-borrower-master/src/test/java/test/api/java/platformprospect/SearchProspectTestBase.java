package test.api.java.platformprospect;

import java.util.Collection;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeSuite;

import com.google.common.collect.ImmutableList;
import com.prosper.automation.asserts.ProsperAssert;
import com.prosper.automation.collection.ProspectFirstName;
import com.prosper.automation.collection.ProspectLastName;
import com.prosper.automation.collection.ProspectOfferCode;
import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.SortOrder;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.AddressInfo;
import com.prosper.automation.model.platform.ContactInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.prospect.Prospect;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.model.platform.prospect.SearchProspectQueryParameter;
import com.prosper.automation.model.platform.prospect.SearchProspectResponse;
import com.prosper.automation.solr.interfaces.ISolrClient;

/**
 * Created by pbudiono on 4/19/16.
 */
public abstract class SearchProspectTestBase extends PlatformProspectTestBase {

	// default returned prospect size
	protected static final int DEFAULT_LIMIT = 10;
	// default returned prospect
	protected static final int DEFAULT_OFFSET = 0;

	// do not set this to true; otherwise Solr will clean insert all Prospect
	// data.
	private static final Boolean CLEAN_INSERT = false;
	private static final String PROSPECT_SOLR_ENTITY = "prospect";
	private static final String SOLR_INSERT_COMMAND = "delta-import";

	@Autowired
	private ISolrClient solrService;

	@Override
	@BeforeSuite(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	protected void springTestContextPrepareTestInstance() throws AutomationException {
		initializeSpringContextForTestSetup();
	}

	protected void assertReturnedProspectIsGreaterThanZero(final List<Prospect> prospectList) {
		ProsperAssert.assertTrue(prospectList.size() > 0);
	}

	protected void assertReturnedProspectIsSortedByLastName(final List<Prospect> prospectList, final SortOrder sortOrder) {
		final Collection<String> lastNames = CollectionUtils.collect(prospectList, new ProspectLastName());
		ProsperAssert.assertIsSorted(lastNames, sortOrder);
	}

	protected void assertReturnedProspectIsSortedByFirstName(final List<Prospect> prospectList, final SortOrder sortOrder) {
		final Collection<String> firstNames = CollectionUtils.collect(prospectList, new ProspectFirstName());
		ProsperAssert.assertIsSorted(firstNames, sortOrder);
	}

	protected void assertProspectIsSortedByOfferCode(final List<Prospect> prospectList, final SortOrder sortOrder) {
		final Collection<String> offerCodes = CollectionUtils.collect(prospectList, new ProspectOfferCode());
		ProsperAssert.assertIsSorted(offerCodes, sortOrder);
	}

	protected final void pollForSolrDeltaImport(final String firstName, final String lastName)
			throws AutomationException, HttpRequestException {
		solrService.importData(PROSPECT_SOLR_ENTITY, SOLR_INSERT_COMMAND, CLEAN_INSERT);

		final SearchProspectQueryParameter searchProspectQueryParameter = SearchProspectQueryParameter
				.buildSearchByFirstAndLastName(DEFAULT_LIMIT, DEFAULT_OFFSET, firstName, lastName);

		int binarySequence = 0;
		int sleepTimeInMillis = 0;
		while (10000 >= sleepTimeInMillis) {
			final SearchProspectResponse searchProspectResponse = pubSiteProspectService
					.searchProspect(searchProspectQueryParameter);
			if (searchProspectResponse.getProspects().size() >= 1) {
				return;
			} else {
				sleepTimeInMillis = ((int) Math.pow(2.0, binarySequence) * 1000);
				try {
					Thread.sleep(sleepTimeInMillis);
				} catch (InterruptedException e) {
					throw new AutomationException("Interrupted exception is caught.", e);
				}
				binarySequence++;
			}
		}
		throw new AutomationException("Unable to find new prospect data on Solr.");
	}

	protected ProspectResponse createProspectTestData(final String email, final String firstName, final String lastName)
			throws AutomationException, HttpRequestException {
		return createProspectTestData(email, firstName, lastName, null);
	}

	// clients data integrity test

	protected ProspectResponse createProspectTestData(final String email, final String firstName, final String lastName,
			final String offerCode) throws AutomationException, HttpRequestException {
		final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
				.withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withIsSelfEmployed(false)
				.withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME).build();
		final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(firstName).withLastName(lastName)
				.withSsn(Constant.TEST_SSN_WITHOUT_DASH).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
		final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email).build();
		final AddressInfo addressInfo = new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
				.withCity(AddressInfoConstant.TEST_CITY).withState(AddressInfoConstant.TEST_STATE_GA)
				.withZipCode(AddressInfoConstant.TEST_ZIP_CODE).withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
		final Prospect prospect = new Prospect.Builder().withLoanAmount(GENERIC_PROSPECT_LOAN_AMOUNT).withLoanPurposeId(1)
				.withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE).withPersonalInfo(personalInfo).withOfferCode(offerCode)
				.withAddressInfo(addressInfo).withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();
		final ProspectRequest prospectRequest = new ProspectRequest.Builder().withRefAc(DEFAULT_REF_AC).withRefMc(DEFAULT_REF_MC)
				.withProspect(prospect).build();
		return pubSiteProspectService.createProspect(prospectRequest);
	}

	protected List<ProspectResponse> createSortedFirstAndLastNameProspectTestData(final int numberOfProspects,
			final String offerCode, final SortOrder sortOrder) throws AutomationException, HttpRequestException {
		final ImmutableList.Builder<ProspectResponse> listBuilder = new ImmutableList.Builder();

		// number of items has to match.
		final List<String> emailStrings = Constant.generateSortedListOfEmails(numberOfProspects, sortOrder);
		final List<String> dataStrings = Constant.generateSortedListOfStrings(numberOfProspects, sortOrder);

		for (int i = 0; i < numberOfProspects; i++) {
			LOG.info(String.format("Creating prospect #%d", i + 1));

			final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
					.withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID)
					.withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME).build();
			final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(dataStrings.get(i))
					.withLastName(dataStrings.get(i)).withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
			final ContactInfo contactInfo = new ContactInfo.Builder().withPhoneNumbers(PhoneNumberConstant.PROSPER_PHONE_NUMBERS)
					.withEmail(emailStrings.get(i)).build();
			final AddressInfo addressInfo = new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
					.withCity(AddressInfoConstant.TEST_CITY).withState(AddressInfoConstant.TEST_STATE_GA)
					.withZipCode(AddressInfoConstant.TEST_ZIP_CODE).withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID)
					.build();
			final Prospect prospect = new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE)
					.withPersonalInfo(personalInfo).withOfferCode(offerCode).withAddressInfo(addressInfo)
					.withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();
			final ProspectRequest prospectRequest = new ProspectRequest.Builder().withRefAc(DEFAULT_REF_AC)
					.withRefMc(DEFAULT_REF_MC).withProspect(prospect).build();
			listBuilder.add(pubSiteProspectService.createProspect(prospectRequest));
		}

		return listBuilder.build();
	}

	// sorting test

	protected List<ProspectResponse> createSortedOfferCodeProspectTestData(final int numberOfProspects, final String firstName,
			final String lastName, final SortOrder sortOrder) throws AutomationException, HttpRequestException {
		final ImmutableList.Builder<ProspectResponse> listBuilder = new ImmutableList.Builder();

		// number of items has to match.
		final List<String> emailStrings = Constant.generateSortedListOfEmails(numberOfProspects, sortOrder);
		final List<String> dataStrings = Constant.generateSortedListOfStrings(numberOfProspects, sortOrder);

		for (int i = 0; i < numberOfProspects; i++) {
			LOG.info(String.format("Creating prospect #%d", i + 1));

			final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
					.withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID)
					.withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME).build();
			final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(firstName).withLastName(lastName)
					.withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
			final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(emailStrings.get(i)).build();
			final AddressInfo addressInfo = new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
					.withCity(AddressInfoConstant.TEST_CITY).withState(AddressInfoConstant.TEST_STATE_GA)
					.withZipCode(AddressInfoConstant.TEST_ZIP_CODE).withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID)
					.build();
			final Prospect prospect = new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE)
					.withPersonalInfo(personalInfo).withOfferCode(dataStrings.get(i)).withAddressInfo(addressInfo)
					.withContactInfo(contactInfo).withEmploymentInfo(employmentInfo).build();
			final ProspectRequest prospectRequest = new ProspectRequest.Builder().withRefAc(DEFAULT_REF_AC)
					.withRefMc(DEFAULT_REF_MC).withProspect(prospect).build();
			listBuilder.add(pubSiteProspectService.createProspect(prospectRequest));
		}

		return listBuilder.build();
	}

	protected ProspectResponse createProspectTestDataWithAllTypeOfPhoneNumbers(final String email, final String firstName,
			final String lastName) throws AutomationException, HttpRequestException {
		LOG.info("Creating prospect with employer phone number.");
		final EmploymentInfo employmentInfo = new EmploymentInfo.Builder()
				.withEmploymentStatusId(GENERIC_PROSPECT_EMPLOYMENT_STATUS_ID).withAnnualIncome(GENERIC_PROSPECT_ANNUAL_INCOME)
				.withEmployerPhone(PhoneNumberConstant.PHONE_NUMBER_WITH_TYPE_ID_2).build();
		final PersonalInfo personalInfo = new PersonalInfo.Builder().withFirstName(firstName).withLastName(lastName)
				.withDateOfBirth(Constant.TEST_DATE_OF_BIRTH).build();
		final ContactInfo contactInfo = new ContactInfo.Builder().withEmail(email)
				.withPhoneNumbers(PhoneNumberConstant.PHONE_NUMBERS_WITH_ALL_TYPES).build();
		final AddressInfo addressInfo = new AddressInfo.Builder().withAddress1(AddressInfoConstant.TEST_ADDRESS_1)
				.withCity(AddressInfoConstant.TEST_CITY).withState(AddressInfoConstant.TEST_STATE_GA)
				.withZipCode(AddressInfoConstant.TEST_ZIP_CODE).withAddressTypeId(AddressInfoConstant.ADDRESS_TYPE_ID).build();
		final Prospect prospect = new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE)
				.withPersonalInfo(personalInfo).withAddressInfo(addressInfo).withContactInfo(contactInfo)
				.withEmploymentInfo(employmentInfo).build();
		final ProspectRequest prospectRequest = new ProspectRequest.Builder().withRefAc(DEFAULT_REF_AC).withRefMc(DEFAULT_REF_MC)
				.withProspect(prospect).build();
		return pubSiteProspectService.createProspect(prospectRequest);
	}

	protected ProspectRequest buildGenericProspectRequest() {
		final PersonalInfo personalInfo = new PersonalInfo.Builder().build();
		final Prospect prospect = new Prospect.Builder().withCreditQualityId(GENERIC_PROSPECT_CREDIT_SCORE)
				.withPersonalInfo(personalInfo).build();
		return new ProspectRequest.Builder().withProspect(prospect).build();
	}
}
