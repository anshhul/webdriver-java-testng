
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.CoApplicant;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.OfferDetails;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import com.prosper.automation.util.URLUtilities;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.List;
import java.util.Map;

/**
 * Created by pbudiono on 6/21/16.
 */
public final class GetExternalOfferTest extends MarketplaceExternalOfferTestBase {

    private static final Logger LOG = Logger.getLogger(GetExternalOfferTest.class.getSimpleName());

    private static final String ASSERTION_MSG_TEMPLATE = "%s field is not returned.";
    private static final String LIGHT_STREAM_HOST_SCHEME = "https";
    private static final String LIGHT_STREAM_HOST_NAME = "test.lightstream.com";
    private static final String LIGHT_STREAM_SIGN_IN_PATH = "/customer-sign-in";
    private static final String LIGHT_STREAM_SIGN_IN_UID = "UID";
    private static final String SUCCESS_RESPONSE = "Success";

    private static final String LS_OFFER_URL_LOG_TEMPLATE = "Light Stream offer URL %s.";

    @Resource
    private IPlatformMarketplace internalMarketplaceService;


    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, dataProvider = DP_VALID_LOAN_INFO)
    public void testGetExternalOfferWithValidLoanInfo(String loanPurposeId, String selfReportedCreditScore, String loanAmount,
                                                      String relationToPatient, String patientName)
            throws AutomationException, HttpRequestException {
        final LoanInfo loanInfo = new LoanInfo.LoanInfoBuilder()
                .withLoanPurpose(loanPurposeId)
                .withSelfReportedCreditScore(selfReportedCreditScore)
                .withLoanAmount(loanAmount)
                .withRelationToApplicant(relationToPatient)
                .withPatientName(patientName)
                .build();

        final GetOfferRequest externalOfferRequest = buildGenericExternalOfferRequest();
        externalOfferRequest.setLoanInfo(loanInfo);

        final GetOffersResponse externalOfferResponse = internalMarketplaceService.getExternalOffer(externalOfferRequest);
        validateExternalOfferResponse(externalOfferResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, dataProvider = DP_VALID_PERSONAL_INFO)
    public void testGetExternalOfferWithValidPersonalInfo(String firstName, String lastName, String middleName, String suffix,
                                                          String ssn, String dateOfBirth, String driverLicense)
            throws AutomationException, HttpRequestException {
        final PersonalInfo personalInfo = new PersonalInfo.Builder()
                .withFirstName(firstName)
                .withLastName(lastName)
                .withMiddleInitial(middleName)
                .withSuffix(suffix)
                .withSsn(ssn)
                .withDateOfBirth(dateOfBirth)
                .withDriverLicense(driverLicense)
                .build();

        final GetOfferRequest externalOfferRequest = buildGenericExternalOfferRequest();
        externalOfferRequest.setPersonalInfo(personalInfo);

        final GetOffersResponse externalOfferResponse = internalMarketplaceService.getExternalOffer(externalOfferRequest);
        validateExternalOfferResponse(externalOfferResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, dataProvider = DP_VALID_CONTACT_INFO)
    public void testGetExternalOfferWithValidContactInfo(String email, String areaCode, String phoneNumber)
            throws AutomationException, HttpRequestException {
        final PhoneNumber homePhone = new PhoneNumber.Builder()
                .withAreaCode(areaCode)
                .withPhoneNumber(phoneNumber)
                .build();
        final ContactInfo contactInfo = new ContactInfo.ContactInfoBuilder()
                .withEmailAddress(email)
                .withHomePhoneNumber(homePhone)
                .build();

        final GetOfferRequest externalOfferRequest = buildGenericExternalOfferRequest();
        externalOfferRequest.setContactInfo(contactInfo);

        final GetOffersResponse externalOfferResponse = internalMarketplaceService.getExternalOffer(externalOfferRequest);
        validateExternalOfferResponse(externalOfferResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, dataProvider = DP_VALID_ADDRESS_INFO)
    // ownership type, housing payment, address verification enabled, street, city, state, zip code, month duration, day duration
    public void testGetExternalOfferWithValidAddressInfo(String ownershipType, Double monthlyHousingPayment,
                                                         Boolean addressVerificationEnabled, String street, String city,
                                                         String state, String zipCode, String monthlyDuration,
                                                         String yearlyDuration) throws AutomationException, HttpRequestException {
        final AddressInfo addressInfo = new AddressInfo.AddressForMarketplaceinfoBuilder()
                .withOwnershipType(ownershipType)
                .withMonthlyHousingPayment(monthlyHousingPayment)
                .withAddressVerificationEnabled(false)
                .withStreet(street)
                .withCity(city)
                .withState(state)
                .withZip(zipCode)
                .withTimeAtAddress(monthlyDuration, yearlyDuration)
                .build();

        final GetOfferRequest externalOfferRequest = buildGenericExternalOfferRequest();
        externalOfferRequest.setAddressInfo(addressInfo);

        final GetOffersResponse externalOfferResponse = internalMarketplaceService.getExternalOffer(externalOfferRequest);
        validateExternalOfferResponse(externalOfferResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, dataProvider = DP_VALID_CO_APPLICANTS)
    // personal info, address info, employment info, contact info
    public void testGetExternalOfferWithValidCoApplicants(PersonalInfo personalInfo,
                                                          AddressInfo addressInfo,
                                                          EmploymentInfo employmentInfo,
                                                          ContactInfo contactInfo)
            throws AutomationException, HttpRequestException {
        final CoApplicant coApplicant = new CoApplicant.Builder()
                .withPersonalInfo(personalInfo)
                .withAddressInfo(addressInfo)
                .withEmploymentInfo(employmentInfo)
                .withContactInfo(contactInfo)
                .build();

        final GetOfferRequest externalOfferRequest = buildGenericExternalOfferRequest();
        externalOfferRequest.setCoApplicant(coApplicant);

        final GetOffersResponse externalOfferResponse = internalMarketplaceService.getExternalOffer(externalOfferRequest);
        validateExternalOfferResponse(externalOfferResponse);
    }

    private void validateExternalOfferResponse(final GetOffersResponse externalOfferResponse) throws AutomationException {
        Assert.assertEquals(externalOfferResponse.getStatus(), SUCCESS_RESPONSE);

        final List<OfferDetails> offers = externalOfferResponse.getOffers();
        Assert.assertEquals(offers.size(), 1, "Unable to see LightStream offer.");

        final OfferDetails offer = offers.get(0);
        Assert.assertNotNull(offer.getApr(), String.format(ASSERTION_MSG_TEMPLATE, "APR"));
        Assert.assertNotNull(offer.getLoan(), String.format(ASSERTION_MSG_TEMPLATE, "Loan amount"));
        Assert.assertNotNull(offer.getMonthlypay(), String.format(ASSERTION_MSG_TEMPLATE, "Monthly payment"));
        Assert.assertNotNull(offer.getTermMonths(), String.format(ASSERTION_MSG_TEMPLATE, "Loan term in month"));
        Assert.assertNotNull(offer.getTermYears(), String.format(ASSERTION_MSG_TEMPLATE, "Loan term in year"));
        Assert.assertNotNull(offer.getRate(), String.format(ASSERTION_MSG_TEMPLATE, "Rate"));

        final String offerUrl = offer.getOffersUrl();

        LOG.info(String.format(LS_OFFER_URL_LOG_TEMPLATE, offerUrl));

        Assert.assertEquals(URLUtilities.getScheme(offerUrl), LIGHT_STREAM_HOST_SCHEME);
        Assert.assertEquals(URLUtilities.getHost(offerUrl), LIGHT_STREAM_HOST_NAME);
        Assert.assertEquals(URLUtilities.getURLPath(offerUrl), LIGHT_STREAM_SIGN_IN_PATH);

        final Map<String, String> queryParameters = URLUtilities.getQueryParameters(offerUrl);
        Assert.assertTrue(queryParameters.containsKey(LIGHT_STREAM_SIGN_IN_UID));
        Assert.assertNotNull(queryParameters.get(LIGHT_STREAM_SIGN_IN_UID));
    }
}
