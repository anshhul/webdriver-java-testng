package test.api.java.platformprospect;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ProspectDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.*;
import com.prosper.automation.model.platform.prospect.ProspectMatchRequest;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by ppatil on 7/31/16.
 */
public class ProspectMatch extends PlatformProspectTestBase {
    private static ProspectResponse responseWith9Ssn;
    private static ProspectRequest requestWith9Ssn;
    private static ProspectResponse responseWith7Ssn;
    private static ProspectRequest requestWith7Ssn;
    private static ProspectMatchRequest matchRequest;
    private static ProspectMatchResponse matchResponse;
    private static final String DUMMY_EMAIL = "dummy@c1.dev";
    private static final Long USER_ID1 = 12346L;
    private static final Long USER_ID2 = 12347L;
    private static final Long USER_ID3 = 12348L;
    private static final Long USER_ID4 = 12349L;


    @BeforeClass
    public void setup() throws AutomationException, HttpRequestException {
        requestWith9Ssn = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        requestWith9Ssn.getProspect().getPersonalInfo().setSsn(Constant.SSN_WITHOUT_DASH);
        responseWith9Ssn = pubSiteProspectService.createProspect(requestWith9Ssn);
        Assert.assertNotNull(responseWith9Ssn);

        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.setUserId(String.valueOf(USER_ID3), responseWith9Ssn.getProspect().getProspectId().toString());

        requestWith7Ssn = buildGenericProspectRequest(DEFAULT_REF_AC, DEFAULT_REF_MC, Constant.getGloballyUniqueEmail());
        requestWith7Ssn.getProspect().getPersonalInfo()
                .setSsn(Constant.SSN_WITHOUT_DASH.replaceAll(Constant.SSN_WITHOUT_DASH.substring(0, 2), "99"));
        requestWith7Ssn.getProspect().getAddressInfo()
                .setZipCode(requestWith7Ssn.getProspect().getAddressInfo().getZipCode().substring(0, 5));
        responseWith7Ssn = pubSiteProspectService.createProspect(requestWith7Ssn);
        Assert.assertNotNull(responseWith7Ssn);

        prospectDao.setUserId(String.valueOf(USER_ID1), responseWith7Ssn.getProspect().getProspectId().toString());
    }

    @AfterClass
    public void teardown() throws AutomationException, HttpRequestException {
        ProspectDAO prospectDao = prospectDBConnection.getDataAccessObject(ProspectDAO.class);
        prospectDao.setUserId(null, responseWith7Ssn.getProspect().getProspectId().toString());
        prospectDao.setUserId(null, responseWith9Ssn.getProspect().getProspectId().toString());
        // TODO: Uncomment this when nukeprospect is exposed
        // internalProspectService.nukeProspect(responseWith7Ssn.getProspect().getProspectId().toString());
        // internalProspectService.nukeProspect(responseWith9Ssn.getProspect().getProspectId().toString());
    }

    @DataProvider(name = "testRankMatchInfo")
    public static Object[][] rankInfoTest() {
        String email = responseWith9Ssn.getProspect().getContactInfo().getEmail();
        String address = responseWith9Ssn.getProspect().getAddressInfo().getAddress1();
        String zip = responseWith9Ssn.getProspect().getAddressInfo().getZipCode();
        String firstName = responseWith9Ssn.getProspect().getPersonalInfo().getFirstName();
        String lastName = responseWith9Ssn.getProspect().getPersonalInfo().getLastName();
        String ssn = requestWith9Ssn.getProspect().getPersonalInfo().getSsn();
        return new Object[][]{
                // All match
                {USER_ID3, email, firstName, lastName, ssn, address, zip,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip, String.valueOf(USER_ID3))},
                // Only USER_ID3, email match
                {USER_ID3, email, "Z" + firstName, Constant.NON_FRED_NON_RICK_LAST_NAME, Constant.FAKE_SSN,
                        Constant.NON_FRED_NON_RICK_ADDRESS, Constant.NON_FRED_NON_RICK_ZIPCODE,
                        new ExpectedProspectMatchFields(email, firstName, lastName, ssn, address, zip,
                                String.valueOf(USER_ID3))},

        };
    }

    @Test(dataProvider = "testRankMatchInfo", groups = {TestGroup.SANITY})
    public void testProspectMatchValidData(Long userId,
                                           String email,
                                           String firstName,
                                           String lastName,
                                           String ssn,
                                           String address,
                                           String zip,
                                           ExpectedProspectMatchFields expectedFields)
            throws AutomationException, HttpRequestException {
        doTestMatchInfo(userId, email, firstName, lastName, ssn, address, zip, expectedFields);
    }

    private void doTestMatchInfo(Long userId, String email, String firstName, String lastName, String ssn, String address,
                                 String zip, ExpectedProspectMatchFields expectedFields)
            throws AutomationException, HttpRequestException {
        ProspectMatchResponse responsesFromMatch =
                internalProspectService.getProspectMatch(userId, email, firstName, lastName, ssn, address, zip, "false", null);
        Assert.assertNotNull(responsesFromMatch);
        LOG.info("**Match Result Length**" + responsesFromMatch.getResults().length);
        if (expectedFields == null) {
            Assert.assertEquals(responsesFromMatch.getResults().length, 0);
            return;
        }
        ProspectMatchIndividualResult[] matchResponseArray = responsesFromMatch.getResults();
        validateFieldsInMatchResponse(matchResponseArray, expectedFields);
    }

    private void validateFieldsInMatchResponse(ProspectMatchIndividualResult[] responses, ExpectedProspectMatchFields fields)
            throws AutomationException, HttpRequestException {
        for (ProspectMatchIndividualResult response : responses) {
            if (matchResponseWithFlagsSet(response, fields))
                return;
        }
        Assert.fail("Should have matched at-least one response based on expected fields");
    }

    private boolean matchResponseWithFlagsSet(ProspectMatchIndividualResult response, ExpectedProspectMatchFields fields)
            throws HttpRequestException, AutomationException {
        final SearchProspectResponse responseFromSearch = internalProspectService
                .searchProspect(SearchProspectQueryParameter.buildSearchByOfferCode(2, 0, response.getOfferCode()));
        Prospect searchedProspect = responseFromSearch.getProspects().get(0);
        return isCorrectMatchedbyEmail(searchedProspect, fields.getEmail(), response.isMatchedByEmail())
                || isCorrectMatchedBySsnName(searchedProspect, fields.getSsn(), fields.getFirstName(), fields.getLastName(),
                response.isMatchedBySsnName()) && isCorrectMatchedBySsnAddress(searchedProspect, fields.getSsn(),
                fields.getAddress(), fields.getZip(), fields.getFirstName(), response.isMatchedBySsnAddress())
                || isCorrectFilterByUserID(searchedProspect, fields.getUserId(), response.getFilterByUserID());
    }

    private boolean isCorrectFilterByUserID(Prospect searchedProspect, String userId, String filterByUserID)
            throws AutomationException, HttpRequestException {
        return searchedProspect.getUserId().toString().equalsIgnoreCase(userId) && filterByUserID
                .equalsIgnoreCase(Boolean.toString(true));
    }

    private boolean isCorrectMatchedBySsnAddress(Prospect searchedProspect, String ssn, String address, String zip,
                                                 String firstName, boolean matchedBySsnAddress)
            throws AutomationException, HttpRequestException {
        return (searchedProspect.getPersonalInfo().getSsn().endsWith(ssn.substring(ssn.length() - 5, ssn.length())) &&
                searchedProspect.getAddressInfo().getAddress1().equalsIgnoreCase(address) && searchedProspect.getAddressInfo()
                .getZipCode().equalsIgnoreCase(zip) &&
                searchedProspect.getPersonalInfo().getFirstName().startsWith(firstName.substring(0, 1))) && matchedBySsnAddress;
    }

    private boolean isCorrectMatchedBySsnName(Prospect searchedProspect, String ssn, String firstName, String lastName,
                                              boolean matchedBySsnName) throws AutomationException, HttpRequestException {

        return (searchedProspect.getPersonalInfo().getSsn().endsWith(ssn.substring(ssn.length() - 5, ssn.length())) &&
                searchedProspect.getPersonalInfo().getLastName().equalsIgnoreCase(lastName) &&
                searchedProspect.getPersonalInfo().getFirstName().startsWith(firstName.substring(0, 1))) && matchedBySsnName;
    }

    private boolean isCorrectMatchedbyEmail(Prospect searchedProspect, String email, boolean matchedByEmail) {
        return searchedProspect.getContactInfo().getEmail().equalsIgnoreCase(email) && matchedByEmail;
    }

}
