
package test.api.java.platformprospect.cases;

import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import test.BorrowerTestCase;
import com.prosper.automation.annotation.test.ProsperZephyr;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public interface AddPartnerOauthInformationTestCase extends BorrowerTestCase {

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Create Partner OAuth Information API Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [POST] /prospects/partner/security http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    void testCreatePartnerOauthInfoHappyPath() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Create Partner OAuth Information API Does Not Insert Duplicate Entries Test.",
            priority = "P2",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {
                    "Create [POST] /prospects/partner/security http request.",
                    "Create [POST] /prospects/partner/security http request."
            },
            expectedResult = "HTTP 200 OK Response"
    )
    void testCreatePartnerOauthInfoIsNotInsertingDuplicateData() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Create Partner OAuth Information API With Non-existing Campaign Source ID Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {
                    "Create payload request with invalid or non-existing campaign source ID",
                    "Create [POST] /prospects/partner/security http request."},
            expectedResult = "HTTP 500 Internal Server Error Response"
    )
    void testCreatePartnerOauthInfoWithNonExistingCampaignSourceId() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Create Partner OAuth Information API Persists Correct Data Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {
                    "Create [POST] /prospects/partner/security http request."},
            expectedResult = "HTTP 200 OK Response and data is persisted correctly in the database"
    )
    void testCreatePartnerOauthInfoPersistCorrectData() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Create Partner OAuth Information API With Null Client ID Test.",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {
                    "Create request body with null client id.",
                    "Create [POST] /prospects/partner/security http request."
            },
            expectedResult = "HTTP 500 Internal Server Error Response"
    )
    void testCreatePartnerOauthInfoWithNullClientId() throws AutomationException, HttpRequestException;
}
