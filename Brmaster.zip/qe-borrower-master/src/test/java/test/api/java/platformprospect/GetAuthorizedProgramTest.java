
package test.api.java.platformprospect;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.ProgramVo;

import java.util.HashMap;

/**
 * @author pbudiono
 */
public final class GetAuthorizedProgramTest extends PlatformProspectTestBase {

    private static final String CAMPAIGN_TEST_NAME = "DataExchange";
    private static final String FAKE_ID = Constant.newUuid();


    @Test(dataProvider = CAMPAIGN_NAMES, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetAuthorizedCampaignProgramFor(String campaignChannelName) throws AutomationException, HttpRequestException {
        final String clientId = Constant.newUuid();
        insertAuthorizedCampaignProgram(clientId, campaignChannelName, 1);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetAuthorizedCampaignProgramIsNotCaseSensitive() throws AutomationException, HttpRequestException {
        final String clientId = Constant.newUuid();
        insertAuthorizedCampaignProgram(clientId, CAMPAIGN_TEST_NAME, 1);

        final SoftAssert softAssert = new SoftAssert();
        softAssert.assertNotNull(internalProspectService.getAuthorizedProgram(clientId, CAMPAIGN_TEST_NAME.toLowerCase(), 1));
        softAssert.assertNotNull(internalProspectService.getAuthorizedProgram(clientId, CAMPAIGN_TEST_NAME.toUpperCase(), 1));
        softAssert.assertNotNull(internalProspectService.getAuthorizedProgram(clientId.toLowerCase(), CAMPAIGN_TEST_NAME, 1));
        softAssert.assertNotNull(internalProspectService.getAuthorizedProgram(clientId.toUpperCase(), CAMPAIGN_TEST_NAME, 1));
        softAssert.assertAll();
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetAuthorizedCampaignProgramWithSoftDeletedOauthClientId() throws AutomationException, HttpRequestException {
        final String clientId = Constant.newUuid();
        insertAuthorizedCampaignProgram(clientId, CAMPAIGN_TEST_NAME, 1);
        final HashMap<String, String> mapOfSourceAndId = new HashMap<>();
        mapOfSourceAndId.put("external_client_id", clientId);
        final int partnerOauthId =
                internalProspectService.getPartnerOauthInfo(mapOfSourceAndId).getPartnerOauthId();

        Assert.assertNotNull(internalProspectService.softDeletePartnerOAuth(partnerOauthId));

        final ProgramVo programVo = internalProspectService.getAuthorizedProgram(clientId, CAMPAIGN_TEST_NAME, 1);
        Assert.assertNull(programVo);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.APP1011)
    public void testGetAuthorizedCampaignProgramWithNullClientId() throws AutomationException, HttpRequestException {
        internalProspectService.getAuthorizedProgram(null, CAMPAIGN_TEST_NAME, 1);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.APP1011)
    public void testGetAuthorizedCampaignProgramWithEmptyClientId() throws AutomationException, HttpRequestException {
        internalProspectService.getAuthorizedProgram("", CAMPAIGN_TEST_NAME, 1);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.APP1011)
    public void testGetAuthorizedCampaignProgramWithNullCampaignName() throws AutomationException, HttpRequestException {
        internalProspectService.getAuthorizedProgram(FAKE_ID, null, 1);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.APP1011)
    public void testGetAuthorizedCampaignProgramWithEmptyCampaignName() throws AutomationException, HttpRequestException {
        internalProspectService.getAuthorizedProgram(FAKE_ID, "", 1);
    }
}
