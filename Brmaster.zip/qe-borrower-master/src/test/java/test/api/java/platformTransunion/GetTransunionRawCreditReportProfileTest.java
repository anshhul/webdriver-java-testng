
package test.api.java.platformTransunion;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.transUnion.TUCreditReportResponse;
import com.prosper.automation.util.PollingUtilities;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * Created by pbudiono on 9/15/16.
 */
public final class GetTransunionRawCreditReportProfileTest extends PlatformTransunionTestBase {

    @Test
    public void testGetValidCreditProfileTest() throws HttpRequestException, AutomationException {

        final TUCreditReportResponse createResponse = createTransunionCreditProfile();
        PollingUtilities.sleep(3000);
        final String getResponse =
                pubSiteTransunionService.getRawCreditReportXml(createResponse.getExternalCreditReportId().toString());
        Assert.assertNotNull(getResponse);
    }

    @Test(expectedExceptions = HttpNotFoundException.class, expectedExceptionsMessageRegExp = ".*TU-01010.*")
    public void testGetCreditProfileWithNonExistingID() throws HttpRequestException, AutomationException {
        final String getResponseNonExistingId =  pubSiteTransunionService.getRawCreditReport(UUID.randomUUID().toString());
        Assert.assertNotNull(getResponseNonExistingId);
//        LOG.info(getResponseNonExistingId);
    }

    @Test(expectedExceptions = HttpNotFoundException.class)
    public void testGetCreditProfileWithInvalidUUIDFormat() throws HttpRequestException, AutomationException {
        final String getResponseWithInvalidUUID = pubSiteTransunionService.getRawCreditReport(Constant.getRandomString());
        Assert.assertNotNull(getResponseWithInvalidUUID);
    }
}
