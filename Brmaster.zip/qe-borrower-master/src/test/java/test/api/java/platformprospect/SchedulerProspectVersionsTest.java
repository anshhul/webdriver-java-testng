package test.api.java.platformprospect;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpResponse;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by rsubramanyam on 4/26/16.
 */
public class SchedulerProspectVersionsTest extends PlatformProspectTestBase {

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testGetLastProcessedVersion() throws AutomationException, HttpRequestException {
        final List<HttpResponse> message = pubSiteProspectService.getLastProcessedVersion("1000");
        Assert.assertTrue(message.size() > 0);
    }
}