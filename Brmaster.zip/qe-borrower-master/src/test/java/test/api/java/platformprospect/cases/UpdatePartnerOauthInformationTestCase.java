
package test.api.java.platformprospect.cases;

import test.BorrowerTestCase;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.annotation.test.ProsperZephyr;
import org.testng.annotations.Test;

/**
 * @author pbudiono
 */
public interface UpdatePartnerOauthInformationTestCase extends BorrowerTestCase {

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Update Partner OAuth Information API Test",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [UPDATE] /prospects/partner/security/ http request."},
            expectedResult = "HTTP 200 OK Response"
    )
    void testUpdatePartnerOauthInfoHappyPath() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Update Partner OAuth Information API Sets Client ID Correctly Test",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [UPDATE] /prospects/partner/security/ http request."},
            expectedResult = "Client ID is updated properly in the database"
    )
    void testUpdateClientIdIsPersistedCorrectly() throws AutomationException, HttpRequestException;

    @Test
    @ProsperZephyr(
            project = BMP,
            testTitle = "Update Partner OAuth Information API With Non Existing Partner OAuth ID Test",
            priority = "P1",
            labels = {"qe_ecosystem_automation", "dxreferral"},
            stepToTests = {"Create [UPDATE] /prospects/partner/security/ http request."},
            expectedResult = "HTTP 400 Bad Request Response"
    )
    void testUpdatePartnerOauthInfoWithNonExistingPartnerOauthId() throws AutomationException, HttpRequestException;
}
