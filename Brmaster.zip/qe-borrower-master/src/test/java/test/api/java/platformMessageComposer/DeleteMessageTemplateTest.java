package test.api.java.platformMessageComposer;

import java.util.UUID;

import org.testng.annotations.Test;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;

/**
 * Created by pbudiono on 8/8/16.
 */
public final class DeleteMessageTemplateTest extends PlatformMessageComposerTestBase {

	private static final String INVALID_MESSAGE_TEMPLATE = UUID.randomUUID().toString();

	protected String createMessageTemplate() throws AutomationException, HttpRequestException {

		final String messageTemplateCode = createUniqueTemplateCode();
		final EmailMessageTemplate emailMessageTemplate = createGenericMessageTemplateRequest(messageTemplateCode);

		final EmailMessageTemplate emailMessageTemplateResponse = internalMessageComposerService
				.createMessageTemplate(emailMessageTemplate);

		return emailMessageTemplateResponse.getMessageTemplateKey();
	}

	@Test(groups = {TestGroup.NIGHTLY})
	public void testDeleteInNonTestMode() throws HttpRequestException, AutomationException {
		final String messageTemplateKey = createMessageTemplate();
		internalMessageComposerService.deleteMessageTemplate(messageTemplateKey, false);
	}

	@Test(groups = {TestGroup.NIGHTLY})
	public void testDeleteInTestMode() throws AutomationException, HttpRequestException {
		final String messageTemplateKey = createMessageTemplate();
		internalMessageComposerService.deleteMessageTemplate(messageTemplateKey, true);
	}

	@Test(expectedExceptions = HttpNotFoundException.class, groups = {TestGroup.NIGHTLY})
	public void testDeleteNonExistingMessageTemplate() throws AutomationException, HttpRequestException {
		internalMessageComposerService.deleteMessageTemplate(INVALID_MESSAGE_TEMPLATE, true);
	}
}
