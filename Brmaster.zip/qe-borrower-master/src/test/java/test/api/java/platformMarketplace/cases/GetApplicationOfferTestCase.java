
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface GetApplicationOfferTestCase extends BorrowerTestCase {

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    @ProsperZephyr(project = BMP, testTitle = "Happy path for marketplace get offers", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "Get offers from marketplaceService happy path"}, expectedResult = "HTTP 200 OK Response")

    void testGetApplicationOfferHappyPath() throws AutomationException, HttpRequestException;
}
