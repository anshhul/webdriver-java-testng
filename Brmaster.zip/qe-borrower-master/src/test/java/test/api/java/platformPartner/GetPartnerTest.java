
package test.api.java.platformPartner;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.partner.PartnerRequestResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class GetPartnerTest extends PlatformPartnerTestBase {

    @Test
    public void testGetAllPartners() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response1 = null;
        PartnerRequestResponse response2 = null;
        try {
            response1 = internalPartnerService.createPartner(request);
            Assert.assertEquals(response1.getCode(), request.getCode());
            Assert.assertEquals(response1.getDescription(), request.getDescription());
            Assert.assertEquals(response1.getName(), request.getName());
            Assert.assertNotNull(response1.getCreatedDate());
            Assert.assertNotNull(response1.getModifiedDate());

            List<PartnerRequestResponse> allPartners = internalPartnerService.getAllPartners();
            Assert.assertFalse(allPartners.isEmpty());

            // Create one more so that there are at-least 2 partners to return
            request = setUp();
            internalPartnerService.createPartner(request);
            allPartners = internalPartnerService.getAllPartnersWithPagination("0", "2");
            Assert.assertEquals(allPartners.size(), 2);
            allPartners = internalPartnerService.getAllPartnersWithPagination("1", "1");
            Assert.assertEquals(allPartners.size(), 1);
        } finally {
            if (response1 != null) {
                internalPartnerService.deletePartner(response1.getId());
            }
            if (response2 != null) {
                internalPartnerService.deletePartner(response2.getId());
            }
        }
    }

    @Test
    public void testGetPartnerById() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            Assert.assertEquals(response.getCode(), request.getCode());
            Assert.assertEquals(response.getDescription(), request.getDescription());
            Assert.assertEquals(response.getName(), request.getName());
            Assert.assertNotNull(response.getCreatedDate());
            Assert.assertNotNull(response.getModifiedDate());

            PartnerRequestResponse thisPartner = internalPartnerService.getPartnerById(response.getId());
            Assert.assertNotNull(thisPartner);
            Assert.assertEquals(thisPartner.getId(), response.getId());
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test
    public void testGetPartnerByCode() throws AutomationException, HttpRequestException {
        PartnerRequestResponse request = setUp();
        PartnerRequestResponse response = null;
        try {
            response = internalPartnerService.createPartner(request);
            Assert.assertEquals(response.getCode(), request.getCode());
            Assert.assertEquals(response.getDescription(), request.getDescription());
            Assert.assertEquals(response.getName(), request.getName());
            Assert.assertNotNull(response.getCreatedDate());
            Assert.assertNotNull(response.getModifiedDate());

            PartnerRequestResponse thisPartner = internalPartnerService.getPartnerByCode(request.getCode());
            Assert.assertNotNull(thisPartner);
            Assert.assertEquals(thisPartner.getId(), response.getId());
            Assert.assertEquals(thisPartner.getCode(), response.getCode());
        } finally {
            if (response != null) {
                internalPartnerService.deletePartner(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testGetPartnerNonExisting() throws AutomationException, HttpRequestException {
        internalPartnerService.getPartnerById("INVALID");
    }
}
