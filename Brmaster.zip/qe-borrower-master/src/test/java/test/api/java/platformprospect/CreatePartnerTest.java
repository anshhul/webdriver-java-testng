
package test.api.java.platformprospect;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.CampaignSource;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/2/16.
 */
public final class CreatePartnerTest extends AffiliatePartnerTestBase {

    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY, TestGroup.SANITY})
    public void testCreatePartner() throws AutomationException, HttpRequestException {

        final String partnerName = createUniquePartnerName();

        final CampaignSource campaignSourceRequest = createGenericCampaignSourceRequest(partnerName);
        final CampaignSource campaignSourceResponse = internalProspectService.createPartner(campaignSourceRequest);

        final CampaignSource campaignSource = internalProspectService.getPartner(campaignSourceResponse.getCampaignSourceId());

        Assert.assertNotNull(campaignSource.getCampaignSourceId(), "Campaign source id is null.");
        Assert.assertNotNull(campaignSource.getBusinessContactId(), "Business contact id is null.");
        Assert.assertEquals(campaignSource, campaignSourceRequest, "Campaign source data does not match.");
    }

    @Test(expectedExceptions = HttpBadRequestException.class, groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY,
            TestGroup.SANITY})
    public void testCreateDuplicatePartner() throws AutomationException, HttpRequestException {

        final String partnerName = createUniquePartnerName();

        final CampaignSource campaignSourceRequest = createGenericCampaignSourceRequest(partnerName);

        internalProspectService.createPartner(campaignSourceRequest);
        internalProspectService.createPartner(campaignSourceRequest);
    }
}
