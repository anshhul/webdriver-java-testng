
package test.api.java.applicantDb.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import test.BorrowerTestCase;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 4/4/16.
 */
public interface InsertApplicantTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect with personal, address, contact information"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantBasicTest() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant from empty prospect", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect without any user information"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantEmptyProspectTest() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with no contact numbers", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect without phone number"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantWithoutContactPhoneNumbers() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with null area code", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create prospect with null area code phone number"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantWithNullAreaCodePhoneNumber() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with invalid phone number", priority = "P1",
            labels = {"qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"},
            stepToTests = {"[POST] /prospects/prospect, Create prospect with invalid phone number"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class) void testInsertApplicantWithInvalidPhoneNumber()
            throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with partially matching SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with different partially matching SSN"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantPartiallyMatchingSSN() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with different 9 digit SSN having same 7 digits", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with same 7 digit SSN, different 9 SSN"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantMatching7SSNDifferent9SSN() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with same email different SSN", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with same email, different SSN"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicantSameEmailDifferentSSN() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with different 7 digit SSNs", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with different 7 digit SSN"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicant7SsnDifferentSSN() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with mismatching last name, zipcode", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with same 7 digit SSN, different zipcode, last name"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicant7SsnDifferentZipDifferentLastName() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with mismatching first initial", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with same 7 digit SSN, different first initial"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicant7SsnDifferentFirstName() throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test insert applicant with mismatching address, last name", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-prospect", "prospect-upgrade"}, stepToTests = {
                    "[POST] /prospects/prospect, Create two prospects with same 7 digit SSN, different address, last name"}, expectedResult = "New applicant created")
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    void testInsertApplicant7SsnDifferentAddressDifferentLastName()
            throws AutomationException, HttpRequestException;
}
