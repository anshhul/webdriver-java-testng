
package test.api.java.applicantDb;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectRequest;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * Created by rsubramanyam on 3/20/16.
 */
public class UpdateApplicantByUpdateProspectTest extends AppDbTestBase
        implements test.api.java.applicantDb.cases.UpdateApplicantByUpdateProspectTestCase {

    private static String testEmail = null;


    @BeforeMethod
    public void beforeTest() throws AutomationException, HttpRequestException {
        testEmail = Constant.getGloballyUniqueEmail(false);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchByEmail() throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeApplicant(applicant1);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantUpdateApplicantModifiedDateOnlyChanges()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);

        ProspectResponse response1 = internalProspectService.createProspect(request1);

        String prospect1Id = response1.getProspect().getProspectId().toString();
        int applicantId1 = getApplicantFromProspect(response1.getProspect().getProspectId().toString());
        String createdDate1 = getCreatedDate(applicantId1);
        String modifiedDate1 = getModifiedDate(applicantId1);

        internalProspectService.updateProspect(UUID.fromString(prospect1Id), request1);

        int applicantId2 = getApplicantFromProspect(prospect1Id);
        String createdDate2 = getCreatedDate(applicantId2);
        String modifiedDate2 = getModifiedDate(applicantId2);
        String prospectModifiedDate = getProspectModifiedDate(prospect1Id);

        // Validate dates
        Assert.assertEquals(applicantId1, applicantId2);
        Assert.assertEquals(createdDate1, createdDate2);
        Assert.assertEquals(prospectModifiedDate, modifiedDate2);
        Assert.assertTrue(modifiedDate1.compareTo(modifiedDate2) < 1);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicantId1);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchByEmailSsnUpdate()
            throws AutomationException, HttpRequestException, CloneNotSupportedException {
        String prospect2Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(testEmail);
        request2.getProspect().getPersonalInfo().setSsn(prospect2Ssn);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeApplicant(applicant1);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn);
        ProspectRequest request2 = buildPlatformProspectRequestWithRickData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicant1);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFirstInitialLastName() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, true);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn, initial1, lastName1,
                true);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicant1);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFirstInitialLastNameOn9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 = buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, true);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn.substring(2, 9),
                initial1, lastName1, true);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicant1);
    }

    @Override @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFIAddressZip() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(6);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String lastName2 = Constant.RICK_NICK_LAST_NAME;
        String address1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1;
        String zipCode1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 =
                buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, address1, zipCode1);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn, initial1, lastName2,
                address1, zipCode1);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicant1);
    }

    @Override @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testApplicantMatchBy7SsnFIAddressZipOn9Ssn() throws AutomationException, HttpRequestException {
        String prospect1Ssn = generateRandomNumber(8);
        String initial1 = Constant.FRED_RUIZ_CRUZ_FIRST_NAME.substring(0, 1);
        String lastName1 = Constant.FRED_RUIZ_CRUZ_LAST_NAME;
        String lastName2 = Constant.RICK_NICK_LAST_NAME;
        String address1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1;
        String zipCode1 = AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE;
        String testEmail = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ProspectRequest request1 =
                buildPlatformProspectRequestWithFredData(testEmail, prospect1Ssn, initial1, lastName1, address1, zipCode1);
        ProspectRequest request2 = buildPlatformProspectRequestWithFredData(
                TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName()), prospect1Ssn.substring(2, 9),
                initial1, lastName2, address1, zipCode1);
        ProspectResponse response1 = internalProspectService.createProspect(request1);
        ProspectResponse response2 = updateProspectAndValidate(response1.getProspect().getProspectId().toString(), request2);
        int applicant1 = verifyApplicantMatchData(request2, response2);
        internalProspectService.nukeProspect(response1.getProspect().getProspectId().toString());
        internalProspectService.nukeApplicant(applicant1);
    }
}
