
package test.api.java.platformMarketplace.cases;

import com.prosper.automation.annotation.test.ProsperZephyr;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import test.BorrowerTestCase;

import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 3/14/16.
 */
public interface MktplaceOfferRequestValidationContactInfoTestCase extends BorrowerTestCase {

    @ProsperZephyr(project = BMP, testTitle = "Test different contact_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide different contact_info field values"}, expectedResult = "HTTP 200 OK Response with errors")
    @Test(dataProvider = "testContactInfo")
    void testContactInfoWithParameters(String emailAddress, PhoneNumber homePnumber,
                                       PhoneNumber workPnumber, PhoneNumber mobilePnumber,
                                       ResponseErrorsHelper expectedError)
                                               throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with missing contact_info fields", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Do not provide contact_info in the request"}, expectedResult = "HTTP 200 OK Response with errors")
    @Test(dataProvider = "testMissingContactInfo")
    void testContactInfoWithMissingParameters(String fieldName,
                                              ResponseErrorsHelper expectedError)
                                                      throws AutomationException, HttpRequestException;

    @ProsperZephyr(project = BMP, testTitle = "Test with invalid phone number information", priority = "P1", labels = {
            "qe_ecosystem_automation", "platform-marketplace"}, stepToTests = {
                    "[POST] /marketplace/application/offers, Provide invalid phone numbers in the request"}, expectedResult = "HTTP 200 OK Response with errors")
    @Test(dataProvider = "testWrongOptionalParams")
    void testPhoneInfoWithParameters(String emailAddress, PhoneNumber homePnumber,
                                     PhoneNumber workPnumber,
                                     PhoneNumber mobilePnumber,
                                     ResponseErrorsHelper expectedError)
                                             throws AutomationException, HttpRequestException;
}
