
package test.api.java.platformMessageComposer;

import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;
import com.prosper.automation.model.platform.email.PaginatedEmailMessageTemplate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 8/11/16.
 */
public class GetMessageTemplateByContentTypeCodeTest extends PlatformMessageComposerTestBase {

    private EmailMessageTemplate emailMessageTemplate;


    @BeforeClass(groups = {TestGroup.SANITY, TestGroup.NIGHTLY, TestGroup.ACCEPTANCE})
    public void createMessageTemplate() throws AutomationException, HttpRequestException {
        emailMessageTemplate = internalMessageComposerService
                .createMessageTemplate(createGenericMessageTemplateRequest(createUniqueTemplateCode()));
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testGetMessageTemplateByContentCode() throws AutomationException, HttpRequestException {
        final PaginatedEmailMessageTemplate paginatedEmailMessageTemplate =
                internalMessageComposerService
                        .getMessageTemplateByContentCode(emailMessageTemplate.getContentTypeCode(), 10, 0);
        Assert.assertFalse(paginatedEmailMessageTemplate.getResults().isEmpty());
    }

    @Test(groups = {TestGroup.NIGHTLY})
    public void testGetMessageTemplateByEmptyCode() throws AutomationException, HttpRequestException {
        final PaginatedEmailMessageTemplate paginatedEmailMessageTemplate =
                internalMessageComposerService.getMessageTemplateByContentCode(StringConstant.EMPTY, 10, 0);
        Assert.assertTrue(paginatedEmailMessageTemplate.getResults().isEmpty());
    }
}
