
package test.api.java.platformCampaign;

import java.util.List;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.model.platform.campaign.CampaignRequestResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;

/**
 * Created by rsubramanyam on 5/5/16.
 */
public class GetCampaignTest extends PlatformCampaignTestBase {
    private static final String START_DATE = "2015-01-01 13:01:02 +0000";
    private static final String END_DATE = "2015-01-01 13:01:02 +0000";
    private static final String DURATION = "1";

    @Test
    public void testGetAllCampaigns() throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response1 = null;
        CampaignRequestResponse response2 = null;
        try {
            response1 = internalCampaignService.createCampaign(request);
            response2 = internalCampaignService.createCampaign(request);
            List<CampaignRequestResponse> responses = internalCampaignService.getAllCampaigns();
            Assert.assertNotNull(responses);
            responses = internalCampaignService.getAllCampaignsWithPagination("0", "2");
            Assert.assertEquals(responses.size(), 2);
            responses = internalCampaignService.getAllCampaignsWithPagination("1", "1");
            Assert.assertEquals(responses.size(), 1);
        } finally {
            if (response1 != null) {
                internalCampaignService.deleteCampaign(response1.getId());
            }
            if (response2 != null) {
                internalCampaignService.deleteCampaign(response2.getId());
            }
        }
    }

    @Test
    public void testGetCampaignById() throws AutomationException, HttpRequestException {
        CampaignRequestResponse request = new CampaignRequestResponse();
        request.setStartDate(START_DATE);
        request.setEndDate(END_DATE);
        String description = "eco_auto_" + Constant.getGloballyUniqueString();
        request.setDescription(description);
        request.setDuration(DURATION);
        CampaignRequestResponse response = null;
        try {
            response = internalCampaignService.createCampaign(request);
            Assert.assertEquals(response.getDescription(), description);
            Assert.assertEquals(response.getStartDate(), request.getStartDate().split("\\+")[0].trim());
            Assert.assertEquals(response.getEndDate(), request.getEndDate().split("\\+")[0].trim());
            Assert.assertEquals(response.getDuration(), request.getDuration());

            CampaignRequestResponse responseFromGet = internalCampaignService.getCampaign(response.getId());
            Assert.assertEquals(responseFromGet.getDescription(), description);
            Assert.assertEquals(responseFromGet.getStartDate(), request.getStartDate().split("\\+")[0].trim());
            Assert.assertEquals(responseFromGet.getEndDate(), request.getEndDate().split("\\+")[0].trim());
            Assert.assertEquals(responseFromGet.getDuration(), request.getDuration());
        } finally {
            if (response != null) {
                internalCampaignService.deleteCampaign(response.getId());
            }
        }
    }

    @Test(expectedExceptions = HttpBadRequestException.class)
    public void testGetCampaignNonExisting() throws AutomationException, HttpRequestException {
        internalCampaignService.deleteCampaign("INVALID");
    }
}
