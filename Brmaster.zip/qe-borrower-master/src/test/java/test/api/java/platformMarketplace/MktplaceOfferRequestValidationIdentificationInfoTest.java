
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.core.httpClient.exception.HttpUnauthorizedAccessException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import test.api.java.platformMarketplace.cases.MktplaceOfferRequestValidationIdentificationInfoTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by rsubramanyam on 2/23/16.
 */
public class MktplaceOfferRequestValidationIdentificationInfoTest extends MarketplaceOffersTestBase implements
        MktplaceOfferRequestValidationIdentificationInfoTestCase {

    private static final String PARTNER_CODE = "id";
    @Autowired
    private IPlatformMarketplace marketplaceService;


    @DataProvider(name = "testIdInfo")
    public static Object[][] idInfoTest() {
        return new Object[][] {
                // Invalid Code
                {"10000000000", ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE},
                {"A", ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE},
                {"-1", ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE},
                {"1.2", ResponseErrorsHelper.INVALID_PARTNER_SOURCE_CODE},
                // Empty Code
                {"", ResponseErrorsHelper.MISSING_PARTNER_SOURCE_CODE},

        };
    }

    @DataProvider(name = "testMissingIdInfo")
    public static Object[][] idInfoMissingTest() {
        return new Object[][] {
                // Missing address info values
                {PARTNER_CODE, ResponseErrorsHelper.MISSING_PARTNER_SOURCE_CODE}};
    }

    @Override
    @Test(dataProvider = "testIdInfo", groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testIdInfoWithParameters(String code,
                                         ResponseErrorsHelper expectedError)
                                                 throws AutomationException, HttpRequestException {
        IdentificationInfo info = new IdentificationInfo.Builder().withPartnerSourceCode(code).build();
        validateResponseForIDInfo(info, expectedError);
    }

    @Override
    @Test(dataProvider = "testMissingIdInfo", groups = {
            TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testIdInfoWithMissingParameters(String fieldName,
                                                ResponseErrorsHelper expectedError)
                                                        throws AutomationException, HttpRequestException {
        IdentificationInfo info = buildInfo(fieldName);
        validateResponseForIDInfo(info, expectedError);
    }

    private void validateResponseForIDInfo(IdentificationInfo info, ResponseErrorsHelper expectedError)
            throws AutomationException, HttpRequestException {
        boolean foundException = false;
        GetOfferRequest getOfferRequest = new GetOfferRequest.Builder().withIdentification(info)
                .withLoanInfo(TestDataProviderUtil.getValidLoanInfo()).withAddressInfo(TestDataProviderUtil.getValidAddressInfo())
                .withBankAccountInfo(TestDataProviderUtil.getValidBankInfo())
                .withContactInfo(TestDataProviderUtil.getValidContactInfo())
                .withEmploymentInfo(TestDataProviderUtil.getValidEmploymentInfo())
                .withPersonalInfo(TestDataProviderUtil.getValidPersonalInfo()).build();
        try {
            GetOffersValidationErrorResponse response = marketplaceService.getOfferWithErrorResponse(getOfferRequest);
        } catch (HttpUnauthorizedAccessException ex) {
            foundException = true;
            assertErrorInResponse(ex.getMessage(), expectedError);
        }
        Assert.assertTrue(foundException);
    }

    private IdentificationInfo buildInfo(String fieldName) {
        if (fieldName.equalsIgnoreCase(PARTNER_CODE))
            return new IdentificationInfo.Builder().build();
        return TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode());
    }
}
