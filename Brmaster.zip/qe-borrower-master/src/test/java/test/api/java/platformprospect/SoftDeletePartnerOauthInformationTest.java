
package test.api.java.platformprospect;

import com.prosper.automation.asserts.ProsperAssert;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.prospect.PartnerOAuthDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import test.api.java.platformprospect.cases.SoftDeletePartnerOauthInformationTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.Timestamp;

/**
 * @author pbudiono
 */
public class SoftDeletePartnerOauthInformationTest extends PlatformProspectTestBase
        implements SoftDeletePartnerOauthInformationTestCase {

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSoftDeletePartnerOauthInfoHappyPath() throws HttpRequestException, AutomationException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final Integer deleteResponse = internalProspectService.softDeletePartnerOAuth(partnerOauthInfo.getPartnerOauthId());
        ProsperAssert.assertNotNull(deleteResponse);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testSoftDeletePartnerOauthInfoSetsVersionEndDateField() throws AutomationException, HttpRequestException {
        final PartnerOauthInfo partnerOauthInfo = addPartnerOauthInfo();

        final Integer deleteResponse = internalProspectService.softDeletePartnerOAuth(partnerOauthInfo.getPartnerOauthId());
        Assert.assertNotNull(deleteResponse);

        final PartnerOAuthDAO partnerOAuthDAO = prospectDBConnection.getDataAccessObject(PartnerOAuthDAO.class);
        final PartnerOauthInfo partnerOauthInfoFromDatabase = partnerOAuthDAO
                .getPartnerOauthInfo(partnerOauthInfo.getExternalClientId());

        final Timestamp versionEndDate = partnerOauthInfoFromDatabase.getVersionEndDate();
        ProsperAssert.assertNotNull(versionEndDate);
        ProsperAssert.assertTimestampWithinRange(versionEndDate, DB_PERSIST_DELAY_IN_MS);
    }

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class)
    public void testSoftDeletePartnerOauthInfoWithNonExistingClientID()
            throws AutomationException, HttpRequestException {
        internalProspectService.softDeletePartnerOAuth(Integer.MAX_VALUE);
    }
}
