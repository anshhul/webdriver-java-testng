
package test.api.java.platformOffer;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ErrorMessageConstant;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.MerchantDAO;
import com.prosper.automation.db.dao.UserCreditProfilesDAO;
import com.prosper.automation.db.dao.prospect.ProspectOfferDAO;
import com.prosper.automation.enumeration.platform.UserSourceSystem;
import com.prosper.automation.enumeration.platform.UserType;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.pricing.OffersResponse;
import com.prosper.automation.model.platform.prospect.ProspectDataProviderUtil;
import com.prosper.automation.model.platform.prospect.ProspectResponse;
import com.prosper.automation.platform.interfaces.IPlatformProspect;

import com.prosper.automation.util.PollingUtilities;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Created by rsubramanyam on 7/1/16.
 */
public class GetProspectOffersWithShowAllTest extends PlatformOfferTestBase {

    @Resource
    HttpClientConfig platformPublicServiceConfig;

    @Resource
    IPlatformProspect internalProspectService;


    @BeforeClass
    public void setup() throws AutomationException, HttpRequestException {
        userCreditProfilesDAO = circleOneDBConnection.getDataAccessObject(UserCreditProfilesDAO.class);
    }

    @Test
    public void testGetProspectOffers() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse response =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = response.getProspect().getProspectId();
        final OffersResponse offersResponseWithoutShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID);
        validateDbStoredOffersInProspect(prospectId, 10);
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, true);
        Assert.assertNull(offersResponseWithShowAll.getListedOffers().getOffers().get(0).getLoanOfferScoreId());
        validateSameOffersWithShowAll(offersResponseWithShowAll, offersResponseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, 20);
    }

    @Test
    public void testGetProspectOffersForThirdParty() throws AutomationException, HttpRequestException {
        MerchantDAO dao = circleOneDBConnection.getDataAccessObject(MerchantDAO.class);
        String thirdPartyId = dao.getThirdPartyId();
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspectWithThirdPartyIdPOS(ProspectDataProviderUtil.buildGenericProspectRequestWithThirdPartyId(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail, thirdPartyId));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse offersResponseWithoutShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, false, UserType.PROSPECT, UserSourceSystem.PUBLIC_SITE, thirdPartyId);
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, true, UserType.PROSPECT, UserSourceSystem.PUBLIC_SITE, thirdPartyId);
        Assert.assertNotNull(offersResponseWithShowAll);
        validateSameOffersWithShowAll(offersResponseWithShowAll, offersResponseWithoutShowAll);
        int numOffersWithoutShowAll = offersResponseWithoutShowAll.getListedOffers().getOffers().size();
        validateDbStoredOffersInProspect(prospectId, numOffersWithoutShowAll + 1);
        final OffersResponse offersResponseWithShowAllPublicSite =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, true, UserType.PROSPECT, UserSourceSystem.PUBLIC_SITE, thirdPartyId);
        Assert.assertNotNull(offersResponseWithShowAllPublicSite);
        validateSameOffersWithShowAll(offersResponseWithShowAll, offersResponseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, numOffersWithoutShowAll + 2);
    }

    @Test
    public void testGetProspectOffersForReferralCode() throws AutomationException, HttpRequestException {
        MerchantDAO dao = circleOneDBConnection.getDataAccessObject(MerchantDAO.class);
        String thirdPartyId = dao.getThirdPartyId();
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspectWithThirdPartyIdPOS(ProspectDataProviderUtil.buildGenericProspectRequestWithThirdPartyId(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail, thirdPartyId));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse offersResponseWithoutShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, presponse.getProspect().getOfferCode(), false, UserType.PROSPECT, UserSourceSystem.PUBLIC_SITE);
        validateDbStoredOffersInProspect(prospectId, 10);
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, presponse.getProspect().getOfferCode(), true, UserType.PROSPECT, UserSourceSystem.PUBLIC_SITE);
        Assert.assertNotNull(offersResponseWithShowAll);
        validateSameOffersWithShowAll(offersResponseWithShowAll, offersResponseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, 20);
    }

    @Test(expectedExceptions = HttpNotFoundException.class)
    public void testGetOffersWithInvalidProspectId() throws AutomationException, HttpRequestException {
        pubSiteOfferService.getProspectOffers(Constant.FAKE_UUID, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID, true);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetInvalidOffersWithLowerBoundLoanAmountRequest() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        pubSiteOfferService.getProspectOffers(prospectId, Constant.LOWER_BOUND_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID, true);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetInvalidOffersWithUpperBoundLoanAmountRequest() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        pubSiteOfferService.getProspectOffers(prospectId, Constant.UPPER_BOUND_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID, true);
    }

    @Test
    public void testGetBorrowerOffersDifferentOfferTypes() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse response =
                pubSiteOfferService
                        .getProspectOffers(prospectId, 5000, Constant.GENERIC_LISTING_CATEGORY_ID,
                                Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        int countofDownSell = getCountOfOffersWithType(response, LoanTypes.DOWNSELL.toString());
        int countofUpSell = getCountOfOffersWithType(response, LoanTypes.UPSELL.toString());
        int countOfBasic = getCountOfOffersWithType(response, LoanTypes.BASE.toString());
        int countOfInvalid = getCountOfOffersWithType(response, LoanTypes.INVALID.toString());
        Assert.assertEquals(countofDownSell + countOfBasic + countofUpSell, response.getListedOffers().getOffers().size());
        Assert.assertEquals(countOfInvalid, 0);
    }

    @Test
    public void testGetBorrowerOffersMaxLoanCap() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        OffersResponse response = pubSiteOfferService
                .getProspectOffers(prospectId, 25000, Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID,
                        true);
        Assert.assertNotNull(response);
    }

    @Test
    public void testGetBorrowerOffersResponse() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        final OffersResponse response = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        validateSameOffersWithShowAll(response, responseWithoutShowAll);
        PollingUtilities.sleep(5000);
        ProspectOfferDAO offerDao = prospectDBConnection.getDataAccessObject(ProspectOfferDAO.class);
        Assert.assertTrue(offerDao.isLoanOfferPersisted(response.getListedOffers().getOffers().get(0).getProspectLoanOfferScoreId()) == 3);
        Assert.assertTrue(offerDao.isLoanOfferPersisted(responseWithoutShowAll.getListedOffers().getOffers().get(0).getProspectLoanOfferScoreId()) == 3);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersNoShowAllUpperBoundLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        pubSiteOfferService
                .getProspectOffers(prospectId, 35500, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersNoShowAllLowerBoundLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        pubSiteOfferService.getProspectOffers(prospectId, 0, Constant.GENERIC_LISTING_CATEGORY_ID,
                Constant.GENERIC_LOAN_PURPOSE_ID, true);
    }

    @Test
    public void testGetBorrowerOffersMultipleHitsDbValidation() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        OffersResponse responseWithoutShowAll = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, 10);
        responseWithoutShowAll = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID);
        Assert.assertNotNull(responseWithoutShowAll);
        validateDbStoredOffersInProspect(prospectId, 20);
        OffersResponse response = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInProspect(prospectId, 30);
        response = pubSiteOfferService
                .getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LISTING_CATEGORY_ID,
                        Constant.GENERIC_LOAN_PURPOSE_ID, true);
        Assert.assertNotNull(response);
        validateDbStoredOffersInProspect(prospectId, 40);
    }

    @Test(expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ErrorMessageConstant.OFF_30)
    public void testGetBorrowerOffersInvalidLoanAmount()
            throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                Constant.GENERIC_LISTING_CATEGORY_ID);
        validateDbStoredOffersInProspect(prospectId, 10);
        HttpBadRequestException oldException = null;
        try {
            pubSiteOfferService.getProspectOffers(prospectId, 0,
                    Constant.GENERIC_LOAN_PURPOSE_ID,
                    Constant.GENERIC_LISTING_CATEGORY_ID, true);
        } catch (HttpBadRequestException ex) {
            oldException = ex;
        }
        Assert.assertNotNull(oldException);
        pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT + 35500,
                Constant.GENERIC_LISTING_CATEGORY_ID, Constant.GENERIC_LOAN_PURPOSE_ID, true);
    }

    @Test(enabled = false)
    public void testGetBorrowerOffersBusiness() throws AutomationException, HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse presponse =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = presponse.getProspect().getProspectId();
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, 3,
                        3, true);
        Assert.assertNotNull(offersResponseWithShowAll);
    }

    @DataProvider(name="differentUserSourceSystems")
    public static Object[][] getUserSourceSystems() {
        return new Object[][] {{UserSourceSystem.APP_BY_PHONE}, {UserSourceSystem.PUBLIC_SITE},{UserSourceSystem.PARTNER_REFERRAL}};
    }

    @Test(dataProvider="differentUserSourceSystems")
    public void testGetProspectOffersDifferentSourceSystems(UserSourceSystem system) throws AutomationException,
            HttpRequestException {
        String testUserEmail = Constant.getGloballyUniqueEmail();
        ProspectResponse response =
                internalProspectService.createProspect(ProspectDataProviderUtil.buildGenericProspectRequestWithAllFields(
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        String.format("auto_eco_%s", Constant.getGloballyUniqueString()),
                        testUserEmail));
        UUID prospectId = response.getProspect().getProspectId();
        final OffersResponse offersResponseWithoutShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, false, UserType.PROSPECT, system);
        final OffersResponse offersResponseWithShowAll =
                pubSiteOfferService.getProspectOffers(prospectId, Constant.GENERIC_LOAN_AMOUNT, Constant.GENERIC_LOAN_PURPOSE_ID,
                        Constant.GENERIC_LISTING_CATEGORY_ID, true, UserType.PROSPECT, system);
        validateSameOffersWithShowAll(offersResponseWithShowAll, offersResponseWithoutShowAll);
    }
}
