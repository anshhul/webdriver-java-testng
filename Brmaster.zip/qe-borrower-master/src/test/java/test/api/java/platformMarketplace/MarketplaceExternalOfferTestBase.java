
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.AddressInfoConstant;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.EmploymentInfoConstant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.StringConstant;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;

import org.apache.log4j.Logger;
import org.testng.annotations.DataProvider;

/**
 * Created by pbudiono on 6/27/16.
 */
public abstract class MarketplaceExternalOfferTestBase extends MarketplaceOffersTestBase {

    protected static final String DP_VALID_LOAN_INFO = "VALID_LOAN_INFO";
    protected static final String DP_VALID_PERSONAL_INFO = "DP_VALID_PERSONAL_INFO";
    protected static final String DP_VALID_CONTACT_INFO = "DP_VALID_CONTACT_INFO";
    protected static final String DP_VALID_ADDRESS_INFO = "DP_VALID_ADDRESS_INFO";
    protected static final String DP_VALID_CO_APPLICANTS = "DP_VALID_CO_APPLICANTS";
    protected static final String DP_INVALID_LOAN_INFO = "INVALID_LOAN_INFO";
    protected static final String DP_INVALID_PERSONAL_INFO = "DP_INVALID_PERSONAL_INFO";
    // default loan info values
    protected static final String DEFAULT_LOAN_PURPOSE_ID = "15";
    protected static final String DEFAULT_SELF_REPORTED_CREDIT_SCORE = "2";
    protected static final String DEFAULT_LOAN_AMOUNT = "100000.00";
    protected static final String DEFAULT_OCCUPATION = "Accountant";
    protected static final String DEFAULT_EMPLOYMENT_STATUS_ID = "7";
    // default personal info values
    protected static final String DEFAULT_MIDDLE_NAME = "Z";
    protected static final String DEFAULT_SUFFIX = "Jr.";
    protected static final String DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE = "L1C3";
    protected static final String DEFAULT_DURATION_IN_MONTHS = "0";
    protected static final String DEFAULT_DURATION_IN_YEARS = "5";
    protected static final Integer DEFAULT_EMPLOYMENT_DURATION_IN_YEARS = 2;
    protected static final Integer DEFAULT_EMPLOYMENT_DURATION_IN_MONTHS = 2;
    protected static final Double DEFAULT_MONTHLY_HOUSING_PAYMENT = 1000.0;
    protected static final String DEFAULT_PROVIDER_THIRD_PARTY_ID = "035145";
    protected static final Boolean DEFAULT_ADDRESS_VERIFICATION_ENABLED = false;
    protected static final String DEFAULT_RELATION_TO_APPLICANT = "SELF";
    protected static final String DEFAULT_PATIENT_NAME = "John Doe";

    private static final String SSN_LOG_TEMPLATE = "Newly created ssn %s.";

    private static final Logger LOG = Logger.getLogger(MarketplaceExternalOfferTestBase.class.getSimpleName());


    @DataProvider(name = DP_VALID_LOAN_INFO)
    // loan purpose id, self reported credit score, loan amount, relation to patient, patient name.
    public Object[][] buildValidLoanInfoTest() {
        final Object[][] testData = {
                {DEFAULT_LOAN_PURPOSE_ID, "1", "5000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "100000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "2", "5000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "3", "5000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "4", "5000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "$5000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "$5,000", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "$5000.00", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "$5,000.00", DEFAULT_RELATION_TO_APPLICANT, null},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "5000", "FAMILY", DEFAULT_PATIENT_NAME},
                {DEFAULT_LOAN_PURPOSE_ID, "1", "5000", "OTHER", DEFAULT_PATIENT_NAME},
        };
        return testData;

    }

    @DataProvider(name = DP_VALID_PERSONAL_INFO)
    // first name, last name, middle name, suffix, ssn, date of birth, driver license
    public Object[][] buildValidPersonalInfoTest() {
        final Object[][] testData = {
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, DEFAULT_SUFFIX,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        StringConstant.EMPTY, DEFAULT_SUFFIX,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, StringConstant.EMPTY,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, StringConstant.EMPTY,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH_WITH_HYPHEN,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, StringConstant.EMPTY,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH_WITH_HYPHEN,
                        StringConstant.EMPTY
                }
        };
        return testData;
    }

    @DataProvider(name = DP_VALID_CONTACT_INFO)
    // email, phone area code, phone number
    public Object[][] buildValidContactInfoTest() {
        final Object[][] testData = {
                {
                        Constant.getGloballyUniqueProsperEmail(),
                        PhoneNumberConstant.PROSPER_AREA_CODE,
                        PhoneNumberConstant.PROSPER_PHONE_NUMBER
                }
        };
        return testData;
    }

    @DataProvider(name = DP_VALID_CO_APPLICANTS)
    // personal info, address info, employment info, contact info
    public Object[][] buildValidCoApplicantsTest() {
        final Object[][] testData = {
                {
                        buildGenericPersonalInfo(),
                        buildGenericAddressInfo(),
                        buildGenericEmploymentInfo(),
                        buildGenericContactInfo()
                }
        };
        return testData;
    }

    @DataProvider(name = DP_VALID_ADDRESS_INFO)
    // ownership type, housing payment, address verification enabled, street, city, state, zip code, month duration, year duration
    public Object[][] buildAddressInfoTest() {
        final Object[][] testData = {
                {
                        AddressInfoConstant.RENT_OWNERSHIP_TYPE,
                        DEFAULT_MONTHLY_HOUSING_PAYMENT,
                        DEFAULT_ADDRESS_VERIFICATION_ENABLED,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_CITY,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_STATE,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE,
                        "0",
                        "0"
                },
                {
                        AddressInfoConstant.RENT_OWNERSHIP_TYPE,
                        DEFAULT_MONTHLY_HOUSING_PAYMENT,
                        DEFAULT_ADDRESS_VERIFICATION_ENABLED,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_CITY,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_STATE,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE,
                        DEFAULT_DURATION_IN_MONTHS,
                        DEFAULT_DURATION_IN_YEARS
                },
                {
                        AddressInfoConstant.OWN_OWNERSHIP_TYPE,
                        DEFAULT_MONTHLY_HOUSING_PAYMENT,
                        DEFAULT_ADDRESS_VERIFICATION_ENABLED,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_CITY,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_STATE,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE,
                        DEFAULT_DURATION_IN_MONTHS,
                        DEFAULT_DURATION_IN_YEARS
                },
                {
                        AddressInfoConstant.OTHER_OWNERSHIP_TYPE,
                        DEFAULT_MONTHLY_HOUSING_PAYMENT,
                        DEFAULT_ADDRESS_VERIFICATION_ENABLED,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_CITY,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_STATE,
                        AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE,
                        DEFAULT_DURATION_IN_MONTHS,
                        DEFAULT_DURATION_IN_YEARS
                }
        };
        return testData;
    }

    @DataProvider(name = DP_INVALID_LOAN_INFO)
    // loan purpose id, self reported credit score, and loan amount.
    public Object[][] buildInvalidLoanInfoTest() {
        final Object[][] testData = {
                {DEFAULT_LOAN_PURPOSE_ID, "2", "4999.99"},
                {DEFAULT_LOAN_PURPOSE_ID, "2", "100000.01"}
        };
        return testData;
    }

    @DataProvider(name = DP_INVALID_PERSONAL_INFO)
    public Object[][] buildInvalidPersonalInfoTest() {

        // first name, last name, middle name, ssn, date of birth, driver license
        final Object[][] testData = {
                {
                        // empty first name
                        StringConstant.EMPTY,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, DEFAULT_SUFFIX,
                        Constant.buildTimeStampBasedSSNWithoutDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        StringConstant.EMPTY,
                        DEFAULT_MIDDLE_NAME, DEFAULT_SUFFIX,
                        Constant.buildTimeStampBasedSSNWithDash(),
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                },
                {
                        Constant.FRED_RUIZ_CRUZ_FIRST_NAME,
                        Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH,
                        DEFAULT_MIDDLE_NAME, StringConstant.EMPTY,
                        StringConstant.EMPTY,
                        Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH,
                        DEFAULT_LAST_FOUR_DIGITS_OF_DRIVER_LICENSE
                }
        };
        return testData;
    }

    private AddressInfo buildGenericAddressInfo() {
        return new AddressInfo.AddressForMarketplaceinfoBuilder()
                .withAddressVerificationEnabled(false)
                .withStreet(AddressInfoConstant.FRED_RUIZ_CRUZ_ADDRESS_1)
                .withCity(AddressInfoConstant.FRED_RUIZ_CRUZ_CITY)
                .withState(AddressInfoConstant.FRED_RUIZ_CRUZ_STATE)
                .withZip(AddressInfoConstant.FRED_RUIZ_CRUZ_ZIP_CODE)
                .withMonthlyHousingPayment(DEFAULT_MONTHLY_HOUSING_PAYMENT)
                .withTimeAtAddress(DEFAULT_DURATION_IN_MONTHS, DEFAULT_DURATION_IN_YEARS)
                .withOwnershipType(AddressInfoConstant.RENT_OWNERSHIP_TYPE)
                .build();
    }

    private PersonalInfo buildGenericPersonalInfo() {
        final String ssn = Constant.buildTimeStampBasedSSNWithoutDash();
        LOG.info(String.format(SSN_LOG_TEMPLATE, ssn));

        return new PersonalInfo.Builder()
                .withFirstName(Constant.FRED_RUIZ_CRUZ_FIRST_NAME)
                .withLastName(Constant.FRED_RUIZ_CRUZ_LAST_NAME_WITHOUT_DASH)
                .withSsn(Constant.buildTimeStampBasedSSNWithoutDash())
                .withDateOfBirth(Constant.FRED_RUIZ_CRUZ_DATE_OF_BIRTH)
                .withDriverLicense(Constant.DEFAULT_DRIVER_LICENSE)
                .build();
    }

    private EmploymentInfo buildGenericEmploymentInfo() {
        final AddressInfo employerAddressInfo = new AddressInfo.AddressForMarketplaceinfoBuilder()
                .withAddressVerificationEnabled(false)
                .withStreet(AddressInfoConstant.PROSPER_ADDRESS)
                .withCity(AddressInfoConstant.PROSPER_CITY)
                .withState(AddressInfoConstant.PROSPER_STATE)
                .withZip(AddressInfoConstant.PROSPER_ZIP_CODE)
                .build();

        final PhoneNumber employerPhoneNumber = new PhoneNumber.Builder()
                .withAreaCode(PhoneNumberConstant.PROSPER_AREA_CODE)
                .withPhoneNumber(PhoneNumberConstant.PROSPER_PHONE_NUMBER)
                .build();

        return new EmploymentInfo.Builder()
                .withEmploymentMonth(DEFAULT_EMPLOYMENT_DURATION_IN_MONTHS)
                .withEmploymentYear(DEFAULT_EMPLOYMENT_DURATION_IN_YEARS)
                .withOccupation(DEFAULT_OCCUPATION)
                .withEmployerName(EmploymentInfoConstant.EMPLOYER_NAME)
                .withEmploymentStatusId(DEFAULT_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Double.parseDouble(ANNUAL_INCOME))
                .withEmployerAddressInfo(employerAddressInfo)
                .withEmployerPhone(employerPhoneNumber)
                .build();
    }

    private ContactInfo buildGenericContactInfo() {
        final PhoneNumber phoneNumber = new PhoneNumber.Builder()
                .withAreaCode(PhoneNumberConstant.PROSPER_AREA_CODE)
                .withPhoneNumber(PhoneNumberConstant.PROSPER_PHONE_NUMBER)
                .build();

        return new ContactInfo.ContactInfoBuilder()
                .withEmailAddress(Constant.getGloballyUniqueProsperEmail())
                .withHomePhoneNumber(phoneNumber)
                .build();
    }

    protected GetOfferRequest buildGenericExternalOfferRequest() {

        final IdentificationInfo identificationInfo = new IdentificationInfo.Builder()
                .withProviderThirdPartyId(DEFAULT_PROVIDER_THIRD_PARTY_ID)
                .build();

        final LoanInfo loanInfo = new LoanInfo.LoanInfoBuilder()
                .withLoanAmount(DEFAULT_LOAN_AMOUNT)
                .withLoanPurpose(DEFAULT_LOAN_PURPOSE_ID)
                .withSelfReportedCreditScore(DEFAULT_SELF_REPORTED_CREDIT_SCORE)
                .withRelationToApplicant(DEFAULT_RELATION_TO_APPLICANT)
                .build();

        final AddressInfo addressInfo = buildGenericAddressInfo();
        final PersonalInfo personalInfo = buildGenericPersonalInfo();
        final EmploymentInfo employmentInfo = buildGenericEmploymentInfo();
        final ContactInfo contactInfo = buildGenericContactInfo();

        return new GetOfferRequest.Builder()
                .withIdentification(identificationInfo)
                .withAddressInfo(addressInfo)
                .withLoanInfo(loanInfo)
                .withPersonalInfo(personalInfo)
                .withContactInfo(contactInfo)
                .withEmploymentInfo(employmentInfo)
                .build();
    }
}
