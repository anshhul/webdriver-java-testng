
package test.api.java.platformMarketplace;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.PhoneNumberConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.BankAccountInfo;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.PersonalInfo;
import com.prosper.automation.model.platform.PhoneNumber;
import com.prosper.automation.model.platform.marketplace.properties.AddressInfo;
import com.prosper.automation.model.platform.marketplace.properties.ContactInfo;
import com.prosper.automation.model.platform.marketplace.properties.IdentificationInfo;
import com.prosper.automation.model.platform.marketplace.properties.LoanInfo;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.ValidationErrorResponse;
import com.prosper.automation.model.platform.marketplace.util.ResponseErrorsHelper;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.model.platform.prospect.PartnerRequestGetResponse;
import test.api.java.platformMarketplace.cases.MarketplaceOffersPartnerRequestLogPhoneNumberTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * This is to test request with invalid phone numbers but returning success Created by rsubramanyam on 3/2/16.
 */
public class MarketplaceOffersPartnerRequestLogPhoneNumberTest extends MarketplaceOffersTestBase implements
        MarketplaceOffersPartnerRequestLogPhoneNumberTestCase {

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testPartnerRequestLogForInvalidHomePhoneNumber() throws AutomationException, HttpRequestException {
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(
                        new PhoneNumber.Builder().withPhoneNumber(TestDataProviderUtil.TEST_DATA_PHONE_NUMBER).build())
                .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_2_WITH_AREA_CODE)
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        doTestWithContact(cinfo, emailId);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testPartnerRequestLogForInvalidMobilePhone() throws AutomationException, HttpRequestException {
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ContactInfo cinfo = new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE).withMobilePhoneNumber(
                        new PhoneNumber.Builder().withPhoneNumber(TestDataProviderUtil.TEST_DATA_PHONE_NUMBER).build())
                .withWorkPhoneNumber(PhoneNumberConstant.VALID_PROSPER_PHONE_NUMBER_WITH_AREA_CODE).build();
        doTestWithContact(cinfo, emailId);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testPartnerRequestLogForInvalidWorkPhone() throws AutomationException, HttpRequestException {
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        ContactInfo cinfo =
                new ContactInfo.ContactInfoBuilder().withEmailAddress(emailId)
                        .withHomePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                        .withMobilePhoneNumber(PhoneNumberConstant.VALID_WA_PHONE_NUMBER_1_WITH_AREA_CODE)
                        .withWorkPhoneNumber(
                                new PhoneNumber.Builder().withPhoneNumber(TestDataProviderUtil.TEST_DATA_PHONE_NUMBER).build())
                        .build();
        doTestWithContact(cinfo, emailId);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInvalidEmploymentPhoneMissingNumber() throws AutomationException, HttpRequestException {
        PhoneNumber pnumber = new PhoneNumber.Builder().withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE).build();
        EmploymentInfo einfo = new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TestDataProviderUtil.TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TestDataProviderUtil.TEST_DATA_EMP_YEAR)
                .withEmployerName(TestDataProviderUtil.TEST_DATA_EMP_NAME).withEmployerPhone(pnumber)
                .withIsIncomeVerifiable(true).withOccupationId(TestDataProviderUtil.TEST_DATA_OCCUPATION_ID).build();
        doTestInvalidEmploymentPhoneMissingNumber(einfo);
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testInvalidEmploymentPhone() throws AutomationException, HttpRequestException {
        PhoneNumber pnumber = new PhoneNumber.Builder().withAreaCode(PhoneNumberConstant.SAN_FRANCISCO_AREA_CODE)
                .withPhoneNumber(TestDataProviderUtil.TEST_DATA_PHONE_NUMBER).build();
        EmploymentInfo einfo = new EmploymentInfo.Builder().withEmploymentStatusId(Constant.TEST_EMPLOYMENT_STATUS_ID)
                .withAnnualIncome(Constant.TEST_ANNUAL_INCOME).withEmploymentMonth(TestDataProviderUtil.TEST_DATA_EMP_MONTH)
                .withEmploymentYear(TestDataProviderUtil.TEST_DATA_EMP_YEAR)
                .withEmployerName(TestDataProviderUtil.TEST_DATA_EMP_NAME).withEmployerPhone(pnumber)
                .withIsIncomeVerifiable(true).withOccupationId(TestDataProviderUtil.TEST_DATA_OCCUPATION_ID).build();
        doTestInvalidEmploymentPhoneMissingNumber(einfo);
    }

    private void doTestWithContact(ContactInfo cinfo, String emailId) throws AutomationException, HttpRequestException {
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        BankAccountInfo binfo = TestDataProviderUtil.getValidBankInfo();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();
        EmploymentInfo einfo = TestDataProviderUtil.getValidEmploymentInfo();
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode(), emailId);

        // Build expected response
        ValidationErrorResponse expectedErrorResponse = buildValidationErrorResponse(ResponseErrorsHelper.NO_MATCHING_OFFERS);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, binfo, expectedErrorResponse);

        // Make a request
        GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(response);

        // Pause since create partner request is asynchronous
        pauseForPartnerRequestTableUpdation();

        // Check partner request log table row and applicationId
        // Also compare get partner request response
        validateCreatePartnerRequestLog(emailId, expectedResponse);
        validateApplicationIdInPartnerRequestTable(emailId);
    }

    void doTestInvalidEmploymentPhoneMissingNumber(EmploymentInfo einfo) throws AutomationException, HttpRequestException {

        // Input
        String emailId = TestDataProviderUtil.getUniqueEmailIdForTest(this.getClass().getSimpleName());
        IdentificationInfo info = TestDataProviderUtil.getValidIdentificationInfo(getPartnerCode(), emailId);
        ContactInfo cinfo = TestDataProviderUtil.getContactInfoWithEmail(emailId);
        AddressInfo ainfo = TestDataProviderUtil.getValidAddressInfo();
        PersonalInfo pinfo = TestDataProviderUtil.getValidPersonalInfo();
        BankAccountInfo binfo = TestDataProviderUtil.getValidBankInfo();
        LoanInfo linfo = TestDataProviderUtil.getValidLoanInfo();

        // Build expected response
        ValidationErrorResponse expectedErrorResponse = buildValidationErrorResponse(ResponseErrorsHelper.NO_MATCHING_OFFERS);
        PartnerRequestGetResponse expectedResponse =
                buildExpectedPartnerRequestLog(info, ainfo, cinfo, einfo, pinfo, linfo, binfo, expectedErrorResponse);

        // Make a request
        GetOfferRequest getOfferRequest = buildOfferRequest(info, ainfo, cinfo, einfo, pinfo, linfo, binfo);
        GetOffersResponse response = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(response);

        // Pause since create partner request is asynchronous
        pauseForPartnerRequestTableUpdation();

        // Check partner request log table row and applicationId
        // Also compare Get Partner Request response
        validateCreatePartnerRequestLog(emailId, expectedResponse);
        validateApplicationIdInPartnerRequestTable(emailId);
    }
}
