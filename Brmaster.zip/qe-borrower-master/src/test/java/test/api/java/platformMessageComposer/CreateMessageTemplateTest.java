
package test.api.java.platformMessageComposer;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpNotFoundException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessageTemplate;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by pbudiono on 7/29/16.
 */
public final class CreateMessageTemplateTest extends PlatformMessageComposerTestBase {

    @Test(dataProvider = BOOLEAN_FLAG_TEST, groups = {TestGroup.NIGHTLY})
    public void testCreateMessageTemplate(final Boolean isShownOnPublicSite, final Boolean isSentExternally,
                                          final Boolean isActive) throws AutomationException, HttpRequestException {

        final String messageTemplateCode = createUniqueTemplateCode();
        final EmailMessageTemplate emailMessageTemplate =
                createGenericMessageTemplateRequest(messageTemplateCode, isShownOnPublicSite,
                        isSentExternally, isActive);

        final String messageTemplateKey = internalMessageComposerService
                .createMessageTemplate(emailMessageTemplate).getMessageTemplateKey();

        if (isActive) {
            final EmailMessageTemplate emailMessageTemplateResponse =
                    internalMessageComposerService.getMessageTemplate(messageTemplateKey);

            Assert.assertNotNull(emailMessageTemplateResponse.getMessageTemplateKey(), "Message template key is not returned.");
            Assert.assertEquals(emailMessageTemplateResponse, emailMessageTemplate, "Template does not match.");
        } else {
            try {
                internalMessageComposerService.getMessageTemplate(messageTemplateKey);
                Assert.fail("Message template is retrievable.");
            } catch (final HttpNotFoundException ex) {
                Assert.assertNotNull(ex);
            }
        }

        deleteTestData(messageTemplateKey);
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.NIGHTLY})
    public void testCreateMessageTemplateWithNonExistingContentCode() throws AutomationException, HttpRequestException {

        final String messageTemplateCode = createUniqueTemplateCode();
        final EmailMessageTemplate emailMessageTemplate = createGenericMessageTemplateRequest(messageTemplateCode);

        emailMessageTemplate.setContentTypeCode(INVALID_CONTENT_CODE);

        internalMessageComposerService.createMessageTemplate(emailMessageTemplate);
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.NIGHTLY})
    public void testCreateMessageTemplateWithNonExistingDeliveryCode() throws AutomationException, HttpRequestException {

        final String messageTemplateCode = createUniqueTemplateCode();
        final EmailMessageTemplate emailMessageTemplate = createGenericMessageTemplateRequest(messageTemplateCode);

        emailMessageTemplate.setDeliveryTypeCode(INVALID_DELIVERY_CODE);

        internalMessageComposerService.createMessageTemplate(emailMessageTemplate);
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.NIGHTLY})
    public void testCreateDuplicatesMessageTemplateCode() throws AutomationException, HttpRequestException {

        final String messageTemplateCode = createUniqueTestMessageTemplateCode();

        final EmailMessageTemplate EmailMessageTemplate1 = createGenericMessageTemplateRequest(messageTemplateCode);
        final EmailMessageTemplate EmailMessageTemplate2 = createGenericMessageTemplateRequest(messageTemplateCode);

        internalMessageComposerService.createMessageTemplate(EmailMessageTemplate1);
        internalMessageComposerService.createMessageTemplate(EmailMessageTemplate2);
    }

    @Test(expectedExceptions = HttpRequestException.class, groups = {TestGroup.NIGHTLY})
    public void testCreateMessageTemplateWithEmptyRequestBody() throws AutomationException, HttpRequestException {
        internalMessageComposerService.createMessageTemplate(null);
    }
}
