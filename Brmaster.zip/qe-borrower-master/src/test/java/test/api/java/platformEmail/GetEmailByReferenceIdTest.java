
package test.api.java.platformEmail;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.DateConstant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.email.EmailMessage;
import com.prosper.automation.model.testdata.BorrowerTestData;

/**
 * Created by pbudiono on 7/25/16.
 */
public final class GetEmailByReferenceIdTest extends PlatformEmailTestBase {

	private static final Integer DEFAULT_EMAIL_SUBJECT_LENGTH = 10;
	private static final String USER_TEST_EMAIL = Constant.getUniqueEmail();
	private static final String USER_EMAIL_SUBJECT = Constant.getStringWithLength(DEFAULT_EMAIL_SUBJECT_LENGTH);

	private EmailMessage emailMessageRequest;
	private EmailMessage emailMessage;

	private BorrowerTestData borrowerTestData;

	@BeforeClass(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void prepareTestData() throws AutomationException, HttpRequestException {
        borrowerTestData = borrowerDataService.createNewBorrower(Constant.getGloballyUniqueEmail(), ProsperCreditGrade.AA);
		emailMessageRequest = createGenericEmailMessage(USER_TEST_EMAIL, USER_EMAIL_SUBJECT, getReferenceID(String.valueOf(borrowerTestData.getUserId())));
		emailMessage = pubSiteEmailService.sendEmail(emailMessageRequest, false);

		//borrowerTestData = borrowerDataService.createNewBorrower(Constant.getGloballyUniqueEmail(), ProsperCreditGrade.AA);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetEmailByUserReference() throws AutomationException, HttpRequestException {
		final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(USER_REF_TYPE,
                getReferenceID(String.valueOf(borrowerTestData.getUserId())));
		Assert.assertTrue(emailMessageResponse.getResult().size() > 0, "Unable to get e-mail by user reference.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetEmailByUserReferenceAndDateStampInterval() throws AutomationException, HttpRequestException {
		final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(USER_REF_TYPE,
                getReferenceID(String.valueOf(borrowerTestData.getUserId())));
		Assert.assertTrue(emailMessageResponse.getResult().size() > 0, "Unable to get e-mail by user reference.");
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetEmailByReferenceID() throws AutomationException, HttpRequestException {
		final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(emailMessage.getReferenceType(),
				String.valueOf(emailMessage.getReferenceId()));
		Assert.assertEquals(emailMessageResponse.getResult().get(0), emailMessage);
	}

	@Test(expectedExceptions = HttpRequestException.class, groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetEmailByNonExistingReferenceType() throws AutomationException, HttpRequestException {
		final String randomString = Constant.getStringWithLength(10);
		pubSiteEmailService.getEmail(randomString, randomString);
	}

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testGetEmailByNonExistingReferenceId() throws AutomationException, HttpRequestException {
        final EmailMessage emailMessageResponse = pubSiteEmailService.getEmail(PROSPECT_REF_TYPE, UUID.randomUUID().toString());
        Assert.assertEquals(emailMessageResponse.getResult().size(), 0);
	}
}
