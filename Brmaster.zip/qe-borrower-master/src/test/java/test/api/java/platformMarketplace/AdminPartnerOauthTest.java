
package test.api.java.platformMarketplace;

import com.prosper.automation.asserts.ProsperAssert;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpBadRequestException;
import com.prosper.automation.core.httpClient.exception.HttpInternalServerErrorException;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.marketplace.CampaignDAO;
import com.prosper.automation.db.dao.marketplace.CampaignProgramDAO;
import com.prosper.automation.db.dao.marketplace.MarketplaceAdminPartnerOauthDAO;
import com.prosper.automation.db.dao.prospect.CampaignSourceDAO;
import com.prosper.automation.db.dao.prospect.PartnerOAuthDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.AdminPartnerOauthResponse;
import com.prosper.automation.model.platform.marketplace.response.Campaign;
import com.prosper.automation.model.platform.marketplace.response.CampaignProgram;
import com.prosper.automation.model.platform.marketplace.response.ClientInfo;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.prospect.PartnerOauthInfo;
import com.prosper.automation.platform.clients.PlatformMarketplaceImpl;
import com.prosper.automation.platform.clients.PlatformProspectImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import com.prosper.automation.platform.interfaces.IPlatformMarketplaceAdminPartnerOauth;
import test.api.java.PlatformServiceTestBase;
import test.api.WebServiceTestBase;
import test.api.java.PlatformServiceTestBase;
import test.api.java.platformMarketplace.cases.AdminPartnerOauthTestCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.UUID;

/**
 * Created by rsubramanyam on 3/15/16.
 */
public class AdminPartnerOauthTest extends PlatformServiceTestBase implements AdminPartnerOauthTestCase {

    public String testCampaignSourceId = null;
    @Autowired
    private HttpClientConfig platformServiceConfig;
    @Autowired
    private IPlatformMarketplaceAdminPartnerOauth marketplaceAdminPartnerOauthService;
    @Autowired
    protected PlatformProspectImpl internalProspectService;
    private final static String REF_AC_PREFIX = com.prosper.automation.model.platform.prospect.Campaign.REF_AC_PREFIX;
    private final static String REF_MC_PREFIX = com.prosper.automation.model.platform.prospect.CampaignProgram.REF_MC_PREFIX;

    @BeforeClass
    public void getCampaignSourceForTest() {
        MarketplaceAdminPartnerOauthDAO partnerOauthDao =
                prospectDBConnection.getDataAccessObject(MarketplaceAdminPartnerOauthDAO.class);
        testCampaignSourceId = partnerOauthDao.getCampaignSource();
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOauthBasicTest() throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(campaignSourceId);
        verify(response, campaignSourceId);
        Assert.assertEquals(Integer.parseInt(response.getCampaign().getRank()), 4, "Campaign rank not same");
        Assert.assertEquals(response.getCampaignProgram().getRank().intValue(), 7, "Campaign program rank not same");
        Assert.assertEquals(response.getCampaignProgram().getPricingId().intValue(), 21, "Campaign program pricing not same");

        ClientInfo clientInfo = response.getClientInfoAssignedRoles().getClientInfo();
        tryGetOffersWithPartnerAuthentication(clientInfo.getOauth_client_id(), clientInfo.getOauth_client_secret(), String.valueOf(response.getCampaignProgram().partnerSourceCode));
        cleanup(response.getClientWithRolesInfo().getClientInfo().getExternal_client_id());
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOauthTestWithUpsertFalse()
            throws AutomationException, HttpRequestException {
        String campaignSourceId = insertCampaignSourceTestData();
        AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(campaignSourceId, "false");
        Assert.assertNull(response.getClientWithRolesInfo().getClientInfo());

        response = marketplaceAdminPartnerOauthService.getOauthDetails(campaignSourceId, "true");
        verify(response, campaignSourceId);
        AdminPartnerOauthResponse responseAgain = marketplaceAdminPartnerOauthService.getOauthDetails(campaignSourceId);

        Assert.assertEquals(response.getClientWithRolesInfo().getClientInfo(),
                responseAgain.getClientWithRolesInfo().getClientInfo());
        cleanup(response.getClientWithRolesInfo().getClientInfo().getExternal_client_id());
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOauthTwiceForSameCampaignSource()
            throws AutomationException, HttpRequestException {
        String thisTestCampaignSourceId = insertCampaignSourceTestData();
        AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId, "true");
        AdminPartnerOauthResponse responseAgain = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId, "true");
        Assert.assertEquals(response.getClientWithRolesInfo().getClientInfo(),
                responseAgain.getClientWithRolesInfo().getClientInfo());
        cleanup(response.getClientWithRolesInfo().getClientInfo().getExternal_client_id());
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOauthForExistingCampaignData()
            throws AutomationException, HttpRequestException {
        String thisTestCampaignSourceId = insertCampaignSourceTestData();
        String testCampaignId = Constant.newUuid();
        String testProgramId = insertCampaignAndProgram(thisTestCampaignSourceId, testCampaignId, "DataExchange", 0).getCampaignProgram().campaignProgramId;
        AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId);
        AdminPartnerOauthResponse responseAgain = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId);
        Assert.assertEquals(response.getClientWithRolesInfo().getClientInfo(),
                responseAgain.getClientWithRolesInfo().getClientInfo());
        Assert.assertEquals(response.getCampaign(), responseAgain.getCampaign());
        Assert.assertTrue(response.getCampaign().getRefac().startsWith(REF_AC_PREFIX));
        Assert.assertEquals(response.getCampaignProgram(), responseAgain.getCampaignProgram());
        Assert.assertTrue(response.getCampaignProgram().getRefMc().startsWith(REF_MC_PREFIX));
        Assert.assertEquals(response.getCampaign().getCampaignId(), testCampaignId);
        Assert.assertEquals(response.getCampaignProgram().getCampaignProgramId(), testProgramId);
        Assert.assertEquals(response.getCampaign().getCampaignSourceId(), thisTestCampaignSourceId);
        Assert.assertEquals(response.getCampaign().getLegacyChannel(), "DataExchange");
        cleanup(response.getClientWithRolesInfo().getClientInfo().getExternal_client_id());
    }

    @Override
    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY})
    public void testGetPartnerOauthForExistingCampaignOnlyData()
            throws AutomationException, HttpRequestException {
        String thisTestCampaignSourceId = insertCampaignSourceTestData();
        String testCampaignId = Constant.newUuid();
        insertCampaignOnly(thisTestCampaignSourceId, testCampaignId, "DataExchange");
        AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId);
        AdminPartnerOauthResponse responseAgain = marketplaceAdminPartnerOauthService.getOauthDetails(thisTestCampaignSourceId);
        Assert.assertEquals(response.getClientWithRolesInfo().getClientInfo(),
                responseAgain.getClientWithRolesInfo().getClientInfo());
        Campaign campaignFromResponse = response.getCampaign();
        Assert.assertEquals(response.getCampaign(), responseAgain.getCampaign());
        Assert.assertTrue(campaignFromResponse.getRefac().startsWith(REF_AC_PREFIX));
        Assert.assertEquals(response.getCampaignProgram(), responseAgain.getCampaignProgram());
        Assert.assertEquals(response.getCampaign().getCampaignId(), testCampaignId);
        Assert.assertEquals(response.getCampaign().getCampaignSourceId(), thisTestCampaignSourceId);
        Assert.assertEquals(response.getCampaign().getLegacyChannel(), "DataExchange");
        cleanup(response.getClientWithRolesInfo().getClientInfo().getExternal_client_id());
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpInternalServerErrorException.class, expectedExceptionsMessageRegExp = ".*1015.*Internal system error.*")
    public void testGetPartnerOauthForInvalidCampaignSource()
            throws AutomationException, HttpRequestException {
        marketplaceAdminPartnerOauthService.getOauthDetails("invalid");
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ".*10002.*campaignSourceId is invalid/doesn't exist.*")
    public void testGetPartnerOauthForNonExistingCampaignSource()
            throws AutomationException, HttpRequestException {
        marketplaceAdminPartnerOauthService.getOauthDetails(UUID.randomUUID().toString());
    }

    @Override
    @Test(groups = {TestGroup.ACCEPTANCE,
            TestGroup.NIGHTLY}, expectedExceptions = HttpBadRequestException.class, expectedExceptionsMessageRegExp = ".*10001.*campaignSourceId is required.*")
    public void testGetPartnerOauthForEmptyCampaignSource()
            throws AutomationException, HttpRequestException {
        marketplaceAdminPartnerOauthService.getOauthDetails("");
    }


    private HttpClientConfig buildPlatformServiceConfig(final String oauthClientId, final String oauthClientSecret, HttpClientConfig platformServiceConfig) {
        return new HttpClientConfig.Builder()
                .withClientConnectionTimeout(String.valueOf(platformServiceConfig.getClientConnectionTimeout()))
                .withClientSocketTimeout(String.valueOf(platformServiceConfig.getClientSocketTimeout()))
                .withScheme(platformServiceConfig.getScheme()).withHosts(platformServiceConfig.getHosts())
                .withClientId(oauthClientId).withClientSecret(oauthClientSecret).build();
    }

    public void tryGetOffersWithPartnerAuthentication(String clientId, String clientSecret, String legacyId)
            throws AutomationException, HttpRequestException {

        final HttpClientConfig httpClientConfig = buildPlatformServiceConfig(clientId, clientSecret, platformServiceConfig);

        final IPlatformMarketplace marketplaceService = new PlatformMarketplaceImpl(httpClientConfig);
        final String email = Constant.getGloballyUniqueEmail();
        final GetOfferRequest getOfferRequest =
                MarketplaceOffersTestBase.buildMarketplaceOfferRequest(ProsperCreditGrade.A, email, legacyId);

        final GetOffersResponse getOffersResponse = marketplaceService.getOffer(getOfferRequest);
        Assert.assertNotNull(getOffersResponse);
    }

    private void verify(AdminPartnerOauthResponse response, String campaignSourceId) {
        // Verify oauth_role
        String role = (String) response.getClientWithRolesInfo().getAssignedRoles().get(0).getRole_name();
        ProsperAssert.assertEquals(role, "ROLE_MARKETPLACE", false);
        ProsperAssert.assertEquals(response.getPartner().getCampaignSourceId(), campaignSourceId);
        String externalClientId = response.getClientWithRolesInfo().getClientInfo().getExternal_client_id();
        // Verify oauth_client info
        MarketplaceAdminPartnerOauthDAO partnerOauthDao =
                prospectDBConnection.getDataAccessObject(MarketplaceAdminPartnerOauthDAO.class);
        AdminPartnerOauthResponse fromDbValues = partnerOauthDao.getClientInfo(campaignSourceId, externalClientId);
        Assert.assertTrue(
                fromDbValues.getClientWithRolesInfo().getClientInfo().equals(response.getClientWithRolesInfo().getClientInfo()),
                "Client info data does not match");
        CampaignDAO campaignDao = prospectDBConnection.getDataAccessObject(CampaignDAO.class);
        Campaign campaignFromDao = campaignDao.getCampaignInfo(campaignSourceId);
        Campaign campaignFromResponse = response.getCampaign();
        Assert.assertTrue(campaignFromDao.equalsWithoutDates(campaignFromResponse),
                "Campaign data does not match");
        CampaignProgramDAO campaignProgramDao = prospectDBConnection.getDataAccessObject(CampaignProgramDAO.class);
        CampaignProgram program = campaignProgramDao.getCampaignProgramInfo(campaignFromResponse.getCampaignId());
        CampaignProgram programFromResponse = response.getCampaignProgram();
        // Check ref_mc, pricing, rank, legacy_id, legacy_channel, fallback program, isABPEligible
        Assert.assertTrue(program.equals(programFromResponse), "Campaign Program data does not match");
    }

    public String insertCampaignSourceTestData() {
        final CampaignSourceDAO campaignSourceDAO = prospectDBConnection.getDataAccessObject(CampaignSourceDAO.class);
        final String campaignSourceId = Constant.newUuid();
        final String campaignSourceName = String.format("auto_eco_%s", Constant.getGloballyUniqueString());
        final int returnCode = campaignSourceDAO.insertCampaignSourceData(campaignSourceId, campaignSourceName);
        Assert.assertEquals(returnCode, 1);
        return campaignSourceId;
    }

    private void cleanup(String clientId) throws AutomationException, HttpRequestException {
        final PartnerOAuthDAO partnerOAuthDAO = prospectDBConnection.getDataAccessObject(PartnerOAuthDAO.class);
        final PartnerOauthInfo partnerOauthInfoFromDatabase = partnerOAuthDAO.getPartnerOauthInfo(clientId);
        try {
            final Integer deleteResponse =
                    internalProspectService.softDeletePartnerOAuth(partnerOauthInfoFromDatabase.getPartnerOauthId());

            Assert.assertNotNull(deleteResponse);
        } catch (NullPointerException ex) {
            // do nothing if there is nothing to delete
        }
    }
}
