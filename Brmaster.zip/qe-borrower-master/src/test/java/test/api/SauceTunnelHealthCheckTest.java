package test.api;

import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.webdriver.WebDriverConfig;
import com.prosper.automation.webdriver.client.SauceClient;
import com.prosper.automation.webdriver.model.TunnelDetailsResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by rsubramanyam on 7/1/16.
 */
public class SauceTunnelHealthCheckTest extends WebServiceTestBase {

    @Test
    public void checkHealthOfSauceTunnel() throws HttpRequestException, AutomationException {
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("classpath:webdriver/spring/web_driver_context.xml");
        final SauceClient sauceClient = (SauceClient) jobContext.getBean("sauceClient");
        List<String> tunnelIds = sauceClient.getTunnelId("prosper-auto");
        Assert.assertTrue(tunnelIds.size() > 0);
        boolean found = false;
        for(String tunnelId: tunnelIds) {
            TunnelDetailsResponse response = sauceClient.getTunnelDescription("prosper-auto", tunnelId);
            if(response.getTunnelIdentifier().equals(WebDriverConfig.getTunnelIdentifier())) {
                found = true;
            }
        }
        Assert.assertTrue(found, "Could not find sauce tunnel open with name: " + WebDriverConfig.getTunnelIdentifier());
    }
}
