
package test.apiui;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.util.TimeUtilities;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 28-Jul-2016
 *
 */
public class BorrowerAgreementsAndLendingAccreditationTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerAgreementsAndLendingAccreditationTest.class.getSimpleName());
    private String testUserEmail;
    private HashMap<String, String> testData;


    @Test(groups = {TestGroup.NIGHTLY}, enabled = true)
    void testAgreements_LendingAccreditation()
            throws UnsupportedEncodingException, AutomationException, HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~~~~Executing test : testBorrowerLoginByProxy~~~~~~~~~~~~~~~~~~");

        testUserEmail = Constant.getGloballyUniqueEmail(false);
        // create a user listing with agreement
        testData = generateAgrement(testUserEmail);
        listingID = testData.get("LISTINGID");

        UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        String userId =userInfo.getUserIDByEmail(testUserEmail);

        List<Map<String, Object>> lendingAccreditationRecord =
                queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
        Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

        List<Map<String, Object>> agreementRecord = queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
        Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
        Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
    }
}
