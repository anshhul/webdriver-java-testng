package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.UserResponse;
import java.io.UnsupportedEncodingException;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class PasswordResponseTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PasswordResponseTest.class.getSimpleName());
    private String userEmail;


    /**
     * GEAR-1643 verify Post user method with old password 'Password23'
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testoldPasswordResponse()
            throws AutomationException, UnsupportedEncodingException, HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~~~~Executing test : testBorrowerLoginByProxy~~~~~~~~~~~~~~~~~~");

        userEmail = Constant.getGloballyUniqueEmail();
        UserRequest userRequest = buildGenericUserRequest(userEmail, Constant.OLD_PASSWORD);

        UserResponse testUserResponse = null; ;
        try {
        	testUserResponse = pubSiteUserService.createBorrower(userRequest);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage().contains(MessageBundle.getMessage("incorrectPasswordResponse")));
		}
        Assert.assertNull(testUserResponse);
        LOG.info("GEAR-1643 verify Post user method with old password 'Password23'");
    }
}
