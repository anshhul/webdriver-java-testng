
package test.apiui;

import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmailValidationResponse;
import com.prosper.automation.model.platform.UserEmailVerifyResponse;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 29-Aug-2016
 *
 */
public class PasswordResetWith5digitZipUserDetailTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PasswordResetWith5digitZipUserDetailTest.class.getSimpleName());
    private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
    private static final String SUCCESS_PASSWORD_MESSAGE = "Success. Your password has been changed.";
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;
    private String testUserEmail;


    // Merged test flow into RedirectToAOSignInUserTest
    // BOR-7430
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testPassResetWith5digitZip() throws AutomationException, MalformedURLException, UnsupportedEncodingException,
            HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~Executing: testPassResetWith5digitZip~~~~~~~~~~");
        final Map<String, String> experianUserInformation =
                ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA);

        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("testPassResetWith5digitZip");
        generateAgrement(testUserEmail);
        // Navigate to sign-in page and click on forgot password.
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                    (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");

            final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

            final PublicSiteRequestEmailForChangePasswordPage changePasswordPage = publicSiteSignInPage.clickForgotPassword();
            changePasswordPage.enterEmailAddress(testUserEmail);
            changePasswordPage.clickContinue();
        }
        PollingUtilities.sleep(4000);
        verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), testUserEmail,
                experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY),
                MessageBundle.getMessage("followingUp_resetPassword"), MessageBundle.getMessage("followingUpBody_resetPassword"));
        // final String code = changePasswordPage.getResetCodeForUser(identityVerificationUrl);
        final EmailValidationResponse responseFromEmailService = pubSiteUserService.validateUserEmail(testUserEmail);
        final UserEmailVerifyResponse verifyResponse =
                pubSiteUserService.verifyUserEmail(responseFromEmailService.getActivationKey());
        Assert.assertTrue(verifyResponse.getIsVerified());
        final String code = circleOneDBConnection.getDataAccessObject(UserDAO.class).getUserIDByEmail(testUserEmail);
        // Navigate to zipcode, date of birth confirmation page, submit it with valid details and observe.
        try (final PublicSiteMarketplaceLandingPage verificationPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
                        publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + code)) {
            verificationPage.setPageElements(pageElements);
            final String fiveDigitZip = experianUserInformation.get(ExperianUserInformation.ZIP_KEY).substring(0, 5);
            final PasswordChangePage passwordChangePage = verificationPage.resetPasswordForUser(
                    fiveDigitZip,
                    experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY));
            passwordChangePage.enterNewPassword(Constants.UserCommonTestDetails.NEW_PASSWORD);
            passwordChangePage.confirmNewPassword(Constants.UserCommonTestDetails.NEW_PASSWORD);
            passwordChangePage.clickChangePassword();
            Assert.assertTrue(passwordChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
            Assert.assertTrue(passwordChangePage.isStaticTextDisplayed(SUCCESS_PASSWORD_MESSAGE));
            LOG.info(
                    "BOR-7430 Verify that user is able to submit  Security Question page with 5 digit Zip code for default questions");
        }
    }
}
