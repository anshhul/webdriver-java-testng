
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.RegistrationPageMessageConstants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteEditAddressPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 24-Jun-2016
 *
 */
public class PriorBorrowerMigrateToWVStateTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PriorBorrowerMigrateToWVStateTest.class.getSimpleName());
    private String testUserEmail;
    private HashMap<String, String> testData;


    // GEAR-1372 Verify that decline page displayed to user after submitting Register page who changes his address to WV state
    @Test(groups = {TestGroup.NIGHTLY})
    void testPriorBorrowerMigrateToWVState() throws AutomationException, UnsupportedEncodingException, HttpRequestException {
        LOG.info("~~~~~~~~Executing: testPriorBorrowerMigrateToWVState~~~~~~~~~~~~");

        testUserEmail = Constant.getGloballyUniqueEmail();
        testData = generateOffersAndAccept(testUserEmail);
        // Log into the Support site with user created above and change the address as per WV State
        try (ClassPathXmlApplicationContext supportSiteContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml")) {

            final SupportSiteLandingPage supportSiteLandingPage =
                    (SupportSiteLandingPage) supportSiteContext.getBean("supportSiteLandingPage");

            supportSiteLandingPage.enterEmailAddress();
            supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

            final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

            final SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
            LOG.info("click on members link");

            memberPage.searchByEmail(testUserEmail);
            final SupportBorrowerTabPage viewMemberPage = memberPage.clickOnView();

            final SupportSiteEditAddressPage addressPage = viewMemberPage.editAddress();
            addressPage.setAddress(getNonBorrowerStateData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                    getNonBorrowerStateData().get(Constants.RegisterationPageConstants.CITYNAME_TAG), "West Virginia",
                    getNonBorrowerStateData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG).substring(0, 5));
        }
        // User re-try new listing after falling into WV non borrowing state

        try (ClassPathXmlApplicationContext publicSiteContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

            final PublicSitePreRegistrationPage modernizePreRegistrationPage =
                    (PublicSitePreRegistrationPage) publicSiteContext.getBean("modernizePreRegistrationPage");

            PublicSiteRegistrationPage publicSiteRegistrationPage =
                    modernizePreRegistrationPage.checkYourRate();
            publicSiteRegistrationPage.enterEmailAddress(testUserEmail);
            LOG.info("User email addresss is:" + testUserEmail);
            if (publicSiteRegistrationPage.isTextPresent(Constants.RegisterationPageConstants.EXISTING_USER_EMAIL_NOTIFY, false)) {

                final PublicSiteSignInPage publicSiteSignInPage = publicSiteRegistrationPage.clickLogin();
                final AccountOverviewPage accountOverviewPage =
                        publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
                final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = accountOverviewPage.clickOnProsperLogo();
                publicSiteRegistrationPage =
                        publicSitePreRegistrationAgainPage.checkYourRate();
            } else {
                publicSiteRegistrationPage.signInViaModal(testUserEmail);
            }

            Assert.assertTrue(publicSiteRegistrationPage
                    .verifyPrefilledState(getNonBorrowerStateData().get(Constants.RegisterationPageConstants.STATE_TAG)));
            Assert.assertTrue(
                    publicSiteRegistrationPage.isTextPresent(RegistrationPageMessageConstants.ZIP_CODE_NOT_ALLOWED_BY_PROSPER,
                            false));
        }
    }
}
