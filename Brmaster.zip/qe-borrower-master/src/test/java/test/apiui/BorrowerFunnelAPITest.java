package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.inquiry.ListingHoldResponse;
import com.prosper.automation.model.platform.listing.Listings;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;

import java.net.URLEncoder;

import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import test.api.java.platformInquiry.PlatformInquiryTestBase;

import java.util.Calendar;
import java.util.Date;
import java.text.*;
import javax.annotation.Resource;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * Created by ppatil on 6/22/16.
 */

public final class BorrowerFunnelAPITest extends PlatformInquiryTestBase {

    private static final Long INVALID_LISTING_ID = 00000L;
    int userId;
    String pdpUrl = "";
    String userEmail = "";
    @Resource
    private CloseableJdbcConnection circleOneDBConnection;
    private ListingHoldResponse listingHoldResponse;
    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;

    @Override
    @BeforeSuite(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @BeforeMethod(enabled = false, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public String generateOffersAndAccept() throws AutomationException, HttpRequestException, UnsupportedEncodingException, InterruptedException {
        final Listings listingsRequest = new Listings.Builder().withListingId(testListingId).withLoanOfferId(testLoanOfferId)
                .build();
        final Listings listingResponse = listingService.updateListing(listingsRequest);
        Assert.assertNotNull(listingResponse);

        //Get all the values needed for building the url
        Long listingIdVal = listingResponse.getListingId();
        Date firstDueVal = listingResponse.getStartTime();
        Double loanAmountVal = listingResponse.getAmount();
        Double monthlyPayVal = listingResponse.getMonthlyPayment();
        Double fundingTerm = listingResponse.getFundingTerm();
        userId = listingResponse.getUserId();
        Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String firstDueDate = formatter.format(firstDueVal) + 0000;
        Date finalDueVal = addYear(firstDueVal, 3);
        String finalDueDate = formatter.format(finalDueVal) + 0000;

        //Get email for login
        UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        userEmail = userInfo.getEmailId(userId);

        //Encode dates to match the current url format
        LOG.info("Final Date  before encoding:: " + finalDueDate);
        finalDueDate = URLEncoder.encode(finalDueDate, "UTF-8");
        LOG.info("Final Date before encoding:: " + finalDueDate);
        LOG.info("First Date before encoding:: " + firstDueDate);
        firstDueDate = URLEncoder.encode(firstDueDate, "UTF-8");
        LOG.info("First Date after encoding:: " + firstDueDate);
        String finalPdpUrl = getPersonalDetailsPageUrl(Long.toString(listingIdVal), Double.toString(fundingTerm), firstDueDate, finalDueDate, Double.toString(loanAmountVal), Double.toString(monthlyPayVal));

        return finalPdpUrl;

    }

    //Adds 3 years to the date retrieved
    public static Date addYear(Date date, int i) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.YEAR, i);
        LOG.info("firstDueVal::" + cal.getTime());
        return cal.getTime();
    }

    //Builds personal details page url
    public String getPersonalDetailsPageUrl(String listingIdVal, String termVal, String firstDueVal, String finalDueVal, String loanAmountVal, String monthlyPayVal) {
        String val = "&listing_id=" + listingIdVal + "&" +
                "term=" + termVal + "&" +
                "first_due=" + firstDueVal + "&" +
                "final_due=" + finalDueVal + "&" +
                "loan_amount=" + loanAmountVal + "&" +
                "monthly_pay=" + monthlyPayVal;
        pdpUrl = String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/borrower/#/personal-details?type=core" + val);
        LOG.info("pdpUrl After Encoding ::" + pdpUrl);
        return pdpUrl;
    }

    @Test()
    void testApiFEDSTFunnelTest() throws AutomationException, NoSuchPaddingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, IOException, BadPaddingException, InvalidKeyException, InvalidKeySpecException, HttpRequestException, InterruptedException {
        LOG.info("*******Executing-testApiFEDSTFunnelTest()*******");

        //Generates offers and returns personal details page  parameterized url
        pdpUrl = generateOffersAndAccept();

        //Initiating FE funnel
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");

        //SignIn with the new user email created by api in generateOffersAndAccept()
        PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();
        AccountOverviewPage accountOverviewPage =
                publicSiteSignInPage.signIn(userEmail, Constant.COMMON_PASSWORD);

        //Navigate to personal details page deirectly
        accountOverviewPage.goTo(pdpUrl);

        // Submit Personal Details page
        PublicSitePersonalDetailPage personalDetailsPage = accountOverviewPage.verifyPersonalDetailPage();
        personalDetailsPage.fillPersonalDetailPage(Constants.PersonalDetailPage.HOMEPHONE,
                Constants.PersonalDetailPage.HOMEPHONE,
                Constants.PersonalDetailPage.WORKPHONE,
                Constants.PersonalDetailPage.EMPLOYERNAME,
                Constants.PersonalDetailPage.EMPLOYERPHONE,
                Constants.PersonalDetailPage.OCCUPATION,
                Constants.PersonalDetailPage.STARTEMPLOYMENTDATE,
                Constants.PersonalDetailPage.SSN);

        PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();
        PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
        PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

        // Submit Bank Information Page
        PublicSiteThankYouPage borrowerThankYouPage = manualBankPage.clickAddBank();

        //Todo: Need to uncomment when the FE code is fixed
        //manualBankPage.enterBankInfo(Constants.BankInfoPage.BANKNAME, Constants.BankInfoPage.ACCOUNTHOLDERNAME, "", "", Constants.BankInfoPage.ROUTING,
        //Constants.BankInfoPage.ACCOUNTNUMBER, Constants.BankInfoPage.CONFIRMACCOUNTNUMBER, "");


        // Submit Thank you page
        AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        LOG.info("Verify that Thank You page displayed on submitting Bank Info page and navigate to AO");

        // Delete cookies
        overviewPage.deleteAllCookies();
    }

}






