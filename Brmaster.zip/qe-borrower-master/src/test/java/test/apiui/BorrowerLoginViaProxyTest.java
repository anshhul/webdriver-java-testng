
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.supportsite.pages.SupportBorrowerTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.supportsite.pages.SupportSiteProxyLoginPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 26-Jul-2016
 *
 */
public class BorrowerLoginViaProxyTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerLoginViaProxyTest.class.getSimpleName());
    private String testUserEmail;
    private HashMap<String, String> testData;


    @Test(groups = {TestGroup.NIGHTLY})
    void testBorrowerLoginByProxy()
            throws AutomationException, UnsupportedEncodingException, HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~~~~Executing test : testBorrowerLoginByProxy~~~~~~~~~~~~~~~~~~");

        ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.A);

        testUserEmail = Constant.getGloballyUniqueEmail();
        // create a user listing with agreement
        testData = generateAgrement(testUserEmail);
        listingID = testData.get("LISTINGID");

        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);

        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

        SupportSiteMembersPage memberPage = supportSiteMainPage.clickMembersLink();
        memberPage.searchByEmail(testUserEmail);
        // When we search by email it takes directly to profile page.BR-574
        // SupportBorrowerTabPage supportBorrowerTabPage = memberPage.clickOnView();

        SupportBorrowerTabPage supportBorrowerTabPage = memberPage.goToSupportBorrowerTabPage();
        SupportSiteProxyLoginPage supportSiteProxyLoginPage = supportBorrowerTabPage.clickOnLoginByProxy();
        supportBorrowerTabPage.switchToNewlyOpenedWindow();

        // Added polling time to wait for page to load completely
        PollingUtilities.sleep(3000);
        supportSiteProxyLoginPage.customerAgentSignIn(Constant.COMMON_PASSWORD);
        LOG.info("BMP-1813 Verify that account overview page is displayed when login-ed by proxy");
        supportSiteProxyLoginPage.waitForPageToLoad("myaccount");
    }
}
