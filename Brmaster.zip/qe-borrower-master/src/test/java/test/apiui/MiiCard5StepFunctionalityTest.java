
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.MiiCardAtBankInfoPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage.MiiCard;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 21-Jul-2016
 *
 */
public class MiiCard5StepFunctionalityTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(MiiCard5StepFunctionalityTest.class.getSimpleName());
    private String testUserEmail, listingIdVal, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal, fundingTerm;
    private HashMap<String, String> testData;


    @Test(groups = {TestGroup.NIGHTLY})
    void verifyMiiCard5StepFunctionality() throws AutomationException, UnsupportedEncodingException, HttpRequestException {
        LOG.info("~~~~~~~~Executing:verifyMiiCard5StepFunctionality~~~~~~~~~~~");
        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("testMiiCard5Steps");
        testData = generateOffersAndAccept(testUserEmail);
        listingIdVal = testData.get("listingId");
        firstDueDate = testData.get("firstDueDate");
        finalDueDate = testData.get("finalDueDate");
        loanAmountVal = testData.get("loanAmount");
        monthlyPayVal = testData.get("monthlyPay");
        fundingTerm = testData.get("fundingTerm");
        final String pdpUrl = getTilaPageUrl(listingIdVal, fundingTerm, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal);
        // Log into the Public site with user created above
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
        final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
        overviewPageAgain.waitForAccountOverviewPageToLoad();
        overviewPageAgain.goTo(pdpUrl);

        // Navigate to TIL Page and continue FE flow
        final PublicSiteTruthInLendingDisclosurePage tilPage = overviewPageAgain.goToTilaPage();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();

        // Accept agreement and submit Tila page
        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        publicSiteBankAccountInfoPage.showMiiCard(MiiCardAtBankInfoPage.MII_CARD_FIVE_STEP);
        Assert.assertFalse(publicSiteBankAccountInfoPage.is5stepMiiCardDisplayed(), "5Step MiiCardPage is Displayed");

        LOG.info("Verified that mii card section is displayed on Bank page");

        final MiiCard miiCard = publicSiteBankAccountInfoPage.goToMiCardPage();
        miiCard.clickLinkBankAccount();
        // selecting bank name to link with the account
        miiCard.selectBankName(Constants.BankInfoPage.MII_CARD_BANK_NAME);

        // entered credentials for bank details
        miiCard.submitLoginForm(Constants.BankInfoPage.MII_CARD_USER_NAME, Constants.BankInfoPage.MII_CARD_PASSWORD);

        miiCard.enterMiiCardUserRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        // User navigate to Thank you Page and clicked on go to my account
        // button
        final PublicSiteThankYouPage borrowerThankYouPage = miiCard.selectPaymentMethod();
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage overviewAgainPage = borrowerThankYouPage.clickGoToMyAccountPage();
        overviewAgainPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewAgainPage.waitForAccountOverviewPageToLoad();
        overviewAgainPage.dismissCongratulationWelcomeModal();
    }
}
