
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.MiiCardAtBankInfoPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage.MiiCard;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 21-Jul-2016
 *
 */
public class MiiCard3StepFunctionalityTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(MiiCard3StepFunctionalityTest.class.getSimpleName());
    private String testUserEmail, listingIdVal, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal, fundingTerm;
    private HashMap<String, String> testData;


    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyMiiCard3StepFunctionality() throws AutomationException, UnsupportedEncodingException, HttpRequestException {
        LOG.info("~~~~~~~~verifyMiiCard3StepFunctionality~~~~~~~~~~~");
        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("testMiiCard3Steps");
        testData = generateOffersAndAccept(testUserEmail);
        listingIdVal = testData.get("listingId");
        firstDueDate = testData.get("firstDueDate");
        finalDueDate = testData.get("finalDueDate");
        loanAmountVal = testData.get("loanAmount");
        monthlyPayVal = testData.get("monthlyPay");
        fundingTerm = testData.get("fundingTerm");

        final String pdpUrl = getTilaPageUrl(listingIdVal, fundingTerm, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal);
        // Log into the Public site with user created above
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        final PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
        final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
        overviewPageAgain.waitForAccountOverviewPageToLoad();
        overviewPageAgain.goTo(pdpUrl);

        // Navigate to TIL Page and continue FE flow
        final PublicSiteTruthInLendingDisclosurePage tilaPage = overviewPageAgain.goToTilaPage();

        // Accept agreement and submit Tila page
        tilaPage.confirmElectronicSignature();
        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
        // Navigate to the 3 step mii card
        publicSiteBankAccountInfoPage.showMiiCard(MiiCardAtBankInfoPage.MII_CARD_THREE_STEP);
        Assert.assertTrue(publicSiteBankAccountInfoPage.is3StepMiiCardDisplayed());

        LOG.info("Verify that mii card section is displayed on Bank page");
        final MiiCard miiCard = publicSiteBankAccountInfoPage.goToMiCardPage();

        // selecting bank name to link with the account
        miiCard.selectBankName(Constants.BankInfoPage.MII_CARD_BANK_NAME);

        // entered credentials for bank details
        miiCard.submitLoginForm(Constants.BankInfoPage.MII_CARD_USER_NAME, Constants.BankInfoPage.MII_CARD_PASSWORD);
        final PublicSiteThankYouPage borrowerThankYouPage =
                miiCard.enterMiiCardUserRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));

        // User navigate to Thank you Page and clicked on go to my account button
        LOG.info("User navigate to Thank you  Page");
        borrowerThankYouPage.clickGoToMyAccountPage();
    }
}
