package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.EmploymentInfoConstant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.model.platform.EmploymentInfo;
import com.prosper.automation.model.platform.User;
import com.prosper.automation.model.platform.UserRequest;
import com.prosper.automation.model.platform.document.*;
import com.prosper.automation.pubsite.pages.borrower.*;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.util.SystemPropertyUtilities;
import com.prosper.automation.util.URLUtilities;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.inquiry.ListingHoldResponse;
import com.prosper.automation.model.platform.listing.Listings;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;

import java.net.URLEncoder;

import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import test.api.java.platformInquiry.PlatformInquiryTestBase;

import java.util.*;
import java.text.*;
import javax.annotation.Resource;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;


/**
 * Created by ppatil on 6/22/16.
 */

public final class APIAndFEWithdrawListingTest extends PlatformInquiryTestBase {

    private static final Long INVALID_LISTING_ID = 00000L;
    int userId;
    String listingId = "";
    String userEmail = "";
    @Resource
    private CloseableJdbcConnection circleOneDBConnection;
    private ListingHoldResponse listingHoldResponse;
    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;
    @Resource(name = "pageElements")
    protected Map<String, String> pageElements;

    @Override
    @BeforeSuite(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void springTestContextPrepareTestInstance() throws AutomationException {
        initializeSpringContextForTestSetup();
    }

    @BeforeMethod(enabled = false, groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public String generateAgrement() throws AutomationException, HttpRequestException, UnsupportedEncodingException, InterruptedException {
        final Listings listingsRequest = new Listings.Builder().withListingId(testListingId).withLoanOfferId(testLoanOfferId)
                .build();
        final Listings listingResponse = listingService.updateListing(listingsRequest);
        Assert.assertNotNull(listingResponse);

        //Get all the values needed for building the url
        Long listingIdVal = listingResponse.getListingId();
        String listingId = String.valueOf(listingIdVal);
        userId = listingResponse.getUserId();

        final EmploymentInfo employmentInfo = new EmploymentInfo.Builder().withEmployerName(EmploymentInfoConstant.EMPLOYER_NAME)
                .withEmploymentYear(EmploymentInfoConstant.EMPLOYMENT_YEAR)
                .withEmploymentMonth(EmploymentInfoConstant.EMPLOYMENT_MONTH)
                .withOccupationId(EmploymentInfoConstant.OCCUPATION_ID)
                .withEmploymentStatusId(EmploymentInfoConstant.EMPLOYMENT_STATUS_ID).build();

        final User user = new User.Builder().withEmploymentInfo(employmentInfo).withSsn(Constant.TEST_SSN).build();
        final UserRequest updateUserRequest = new UserRequest.Builder().withUser(user).build();

        userService.updateUser(updateUserRequest);

        final MapTemplateArguments mapTemplateArguments = new MapTemplateArguments.Builder().withListingId(testListingId).build();
        final GenerateAgreementRequest request = new GenerateAgreementRequest.Builder().withAgreementTypeId(2)
                .withMapTemplateArguments(mapTemplateArguments).build();

        final GenerateAgreementResponse response = documentService.generateAgreement(request);
        Assert.assertNotNull(response);

        final UUID agreementTransactionId = response.getAgreementTransactionId();

        final CreateAgreementRequest createAgreementRequest = new CreateAgreementRequest.Builder()
                .withAgreementTransactionId(agreementTransactionId).withIsAgreementAuthorized(true).build();
        final CreateAgreementResponse createAgreementResponse = documentService.createAgreement(createAgreementRequest);
        Assert.assertNotNull(createAgreementResponse);

        //Get email for login
        UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        userEmail = userInfo.getEmailId(userId);
        LOG.info("Listing Id :: " + listingId);

        return userEmail;

    }

    @Test()
    void testAPIAndFEWithdrawListing() throws AutomationException, NoSuchPaddingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, IOException, BadPaddingException, InvalidKeyException, InvalidKeySpecException, HttpRequestException, InterruptedException {
        LOG.info("*******Executing-testAPIAndFEWithdrawListing()*******");

        //Create  a listing by accepting TILA through API
        userEmail = generateAgrement();


        //Initiating FE funnel
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");

        //SignIn with the new user email created by api in generateOffersAndAccept()
        PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();
        AccountOverviewPage accountOverviewPage =
                publicSiteSignInPage.signIn(userEmail, Constant.COMMON_PASSWORD);

        accountOverviewPage
                .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.dismissCongratulationWelcomeModal();
        //Withdraw Listing from FE
        if (accountOverviewPage.isElementPresentOnPage(By.linkText(pageElements.get("withdrawRequest_link")))) {
            accountOverviewPage.clickWithdrawYourRequestLink();
            LOG.info("Borrower clicked for withdraw listing request");
            BorrowerWithdrawListingPage borrowerWithdrawListingPage = accountOverviewPage.clickWithdrawLoanRequest();
            borrowerWithdrawListingPage.clickWithdrawListing();
            Assert.assertTrue(borrowerWithdrawListingPage.getWithdrawListingStatusAsElement().getText()
                    .contains("Your listing has been withdrawn."));
        } else {
            LOG.info("Borrower Listing status is already in WITHDRAWN status");
        }
        LOG.info("Borrower listing is withdraw successfully");
        LOG.info("Borrower having withdrawn listing" + userEmail);

    }

}






