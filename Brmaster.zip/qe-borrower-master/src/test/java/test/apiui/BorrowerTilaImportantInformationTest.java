
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 26-Jul-2016
 *
 */
public class BorrowerTilaImportantInformationTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerTilaImportantInformationTest.class.getSimpleName());
    private String testUserEmail, listingIdVal, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal, fundingTerm;
    private HashMap<String, String> testData;


    // AUTO-233 Automate 'Important information' section in new TILA page
    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyBorrowerTila() throws AutomationException, UnsupportedEncodingException, HttpRequestException {
        LOG.info("~~~~~~~~verifyBorrowerTila~~~~~~~~~~~");
        testUserEmail = Constant.getGloballyUniqueEmail();
        testData = generateOffersAndAccept(testUserEmail);
        listingIdVal = testData.get("listingId");
        firstDueDate = testData.get("firstDueDate");
        finalDueDate = testData.get("finalDueDate");
        loanAmountVal = testData.get("loanAmount");
        monthlyPayVal = testData.get("monthlyPay");
        fundingTerm = testData.get("fundingTerm");

        String pdpUrl = getTilaPageUrl(listingIdVal, fundingTerm, firstDueDate, finalDueDate, loanAmountVal, monthlyPayVal);
        // Log into the Public site with user created above
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        PublicSiteSignInPage publicSiteSignInPage = (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
        AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
        overviewPageAgain.waitForAccountOverviewPageToLoad();
        overviewPageAgain.goTo(pdpUrl);
        // Navigate to TIL Page and continue FE flow
        PublicSiteTruthInLendingDisclosurePage tilaPage = overviewPageAgain.goToTilaPage();

        // Accept agreement and submit Tila page
        tilaPage.confirmElectronicSignature();
        Assert.assertTrue(tilaPage.isStaticTextDisplayed(MessageBundle.getMessage("tilaInformation")));
        PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        Assert.assertNotNull(accountOverviewPage);
    }
}
