
package test.apiui;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Resource;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.inquiry.ListingHoldRequest;
import com.prosper.automation.model.platform.inquiry.ListingHoldResponse;
import com.prosper.automation.model.platform.investor.BidRequests;
import com.prosper.automation.model.platform.investor.Bids;
import com.prosper.automation.model.platform.investor.InvestOrders;
import com.prosper.automation.model.testdata.BorrowerTestData;
import com.prosper.automation.model.wcf.allocateListing.AllocateFractionalRequest;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.spark.interfaces.IPlatformSpark;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsEditPage;
import com.prosper.automation.supportsite.pages.SupportBorrowerListingsTabPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.SupportSiteMembersPage;
import com.prosper.automation.tool.BorrowerDataService;
import com.prosper.automation.util.PollingUtilities;
import test.api.java.PlatformServiceTestBase;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class LoanOriginationTest extends PartnerLandingPageTestBase {

    private static final Logger LOG = Logger.getLogger(LoanOriginationTest.class);

    Double bidAmount;
    private String testUserEmail;

    @Resource
    private BorrowerDataService borrowerDataService;
    
    @Resource
    protected IPlatformSpark platformSparkService;


    @Test(groups = {TestGroup.ACCEPTANCE})
    public void createNewListingThroughAPI()
            throws HttpRequestException, AutomationException, UnsupportedEncodingException, InterruptedException {

        testUserEmail = Constant.getGloballyUniqueEmail();

        final BorrowerTestData borrowerTestData = borrowerDataService.createNewBorrower(testUserEmail, ProsperCreditGrade.AA);
        LOG.info("Listing ID : " + borrowerTestData.getListingId());
        listingId = borrowerTestData.getListingId().get(0);

        // Log as Borrower into Public site.
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();
        final AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
        accountOverviewPage.close();
    }

    @Test(dependsOnMethods = "createNewListingThroughAPI", groups = {TestGroup.ACCEPTANCE})
    public void applyGDSOnListing() throws AutomationException, HttpRequestException {
        LOG.info("******Applying GDS on " + listingId + " listing******");

        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final ListingHoldRequest listingHoldRequest = new ListingHoldRequest.Builder().withListingId(listingId).build();
        final ListingHoldResponse listingHoldResponce = pubSiteInquiryService.getListingHolds(listingHoldRequest);
        Assert.assertNotNull(listingHoldResponce, "Listing hold responce is Null.");
        Assert.assertEquals(String.valueOf(listingInfo.getListingStatusByListingID(listingId)), "1",
                "Listing Status not updated on applying GDS");
    }

    @Test(dependsOnMethods = "applyGDSOnListing", groups = {TestGroup.ACCEPTANCE})
    public void allocateListingToLender()
            throws UnsupportedOperationException, HttpRequestException, AutomationException, SOAPException, IOException,
            TransformerException {
        LOG.info("******Allocating listing " + listingId + " as Partial******");
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final String serviceHostRequest = new AllocateFractionalRequest.Builder().withListingID(String.valueOf(listingId))
                .withInvestmentType("Fractional").build();
        final SOAPMessage serviceHostResponse = allocateListing.allocateListing(serviceHostRequest);
        Assert.assertNotNull(serviceHostResponse);
        Assert.assertEquals(listingInfo.getInvestmentTypeByListingID(listingId), 1, "Listing is not allocated.");
        Assert.assertEquals(String.valueOf(listingInfo.getListingStatusByListingID(listingId)), "1",
                "Listing Status not updated after allocation");
    }

    @Test(dependsOnMethods = "allocateListingToLender", groups = {TestGroup.ACCEPTANCE})
    public void publishFractionalListing() throws AutomationException, HttpRequestException, InterruptedException,
            UnsupportedOperationException, TransformerConfigurationException, SOAPException, IOException, TransformerException {
        LOG.info("******Publishing Fractional listing " + listingId + " from support site.");

        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        final ApplicationContext supportJobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) supportJobContext.getBean("supportSiteLandingPage");
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(MessageBundle.getMessage("password"));
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        SupportSiteMembersPage supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        final SupportBorrowerListingsTabPage supportBorrowerListingsTabPage =
                supportSiteMembersPage.searchListingByID(String.valueOf(listingId));

        final SupportBorrowerListingsEditPage supportBorrowerListingsEditPage =
                supportBorrowerListingsTabPage.clickOnEditStatusLink();
        supportBorrowerListingsEditPage.activateLsiting();
        supportSiteMembersPage = supportSiteMainPage.clickMembersLink();
        PollingUtilities.sleep(15000);
        Assert.assertEquals(String.valueOf(listingInfo.getListingStatusByListingID(listingId)), "2",
                "Listing Status not updated after publishing");
        supportSiteMembersPage.close();
    }

    @Test(dependsOnMethods = "publishFractionalListing", groups = {TestGroup.ACCEPTANCE})
    public void investFractionalLoan() throws AutomationException, HttpRequestException, InterruptedException {
        LOG.info("******Investing on Partial listing " + listingId);
        LOG.info("****Build bids*********");
        PollingUtilities.sleep(10000);
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        bidAmount = PlatformServiceTestBase.GENERIC_PROSPECT_LOAN_AMOUNT / 10;
        final Bids bids = Bids.newBuilder().bidAmount(bidAmount).listingId((int) listingId).build();
        final List<Bids> allBids = new ArrayList<Bids>();
        allBids.add(bids);
        final BidRequests bidRequest = BidRequests.newBuilder().bidRequests(allBids).build();
        final UserEmailDAO userEmailDAO = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        PollingUtilities.sleep(10000);
        LOG.info("******Posting Bid******");
        Assert.assertNotNull(bidRequest);
        final List<InvestOrders> investment =
                platformOrder.postPartailInvestment(bidRequest, userEmailDAO.get10FractionalInvestorEmails());
        Assert.assertNotNull(investment);
        final UUID orderId = investment.get(0).getOrderId();
        final Double effectiveYield = investment.get(0).getEffectiveYield();
        Assert.assertNotNull(orderId);
        Assert.assertNotNull(effectiveYield);
        PollingUtilities.sleep(15000);
        Assert.assertEquals(String.valueOf(listingInfo.getListingStatusByListingID(listingId)), "8",
                "Listing Status not updated after investment");
    }

    @Test(dependsOnMethods = "investFractionalLoan", groups = {TestGroup.ACCEPTANCE})
    public void removeListingHolds() throws AutomationException, HttpRequestException {
        LOG.info("******Removing Workflow over listing " + listingId + " through Spark UI");
        platformSparkService.approveWorkFlows(Long.toString(listingId));
        listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        PollingUtilities.sleep(20000);
        Assert.assertEquals(listingsDAO.isLoanCreated(listingId), true,
                "Loan is not created after removing all holds from Spark.");
        LOAN_ID = listingsDAO.getLoanID(listingId);
        
        
        
//        removeListingHoldsFrmSpark(listingId);
//        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
//        PollingUtilities.sleep(15000);
//        Assert.assertEquals(listingsDAO.isLoanCreated(listingId), true,
//                "Loan is npt created after removing all holds from Spark UI.");
//        LOAN_ID = listingsDAO.getLoanID(listingId);
    }

//    @Test(dependsOnMethods = "removeListingHolds", groups = {TestGroup.ACCEPTANCE})
//    public void verifyLoanInSpectrum() throws AutomationException {
//        LOG.info("******Verifying loan " + LOAN_ID + " Syncing with Spectrum DB");
//        PollingUtilities.sleep(10000);
//        final ServicingDAO servicingDAO = spectrumDBConnection.getDataAccessObject(ServicingDAO.class);
//        Assert.assertTrue(servicingDAO.isLoanSyncWithSpectrum(LOAN_ID, spectrumDbName));
//    }
//
//    @Test(dependsOnMethods = "verifyLoanInSpectrum", groups = {TestGroup.ACCEPTANCE})
//    public void verifyDbVerification() throws AutomationException, HttpRequestException {
//        LOG.info("******Verifying DB verification on orginated loan***********");
//        collectLoanDetails();
//        verifyLoanOriginationQueueStatus();
//        verifyErrorResult();
//        verifyLastModifiedDate();
//        verifyFundingStatus();
//        verifyListingStatus();
//        verifyLoanToAgreementID();
//        verifyListingsInformation();
//    }

    @Test(dependsOnMethods = "removeListingHolds", groups = {TestGroup.ACCEPTANCE})
    public void verifyOverPubicSite() throws AutomationException {
        LOG.info("Verifying loan over public site. Loan ID : " + LOAN_ID);
        if (Investment_Type_ID == 1) {
            LOG.info("\n\n" +
                    "@@@@@@@@@@@@ Originated Fractional loan \n");
        } else {
            LOG.info("\n\n" +
                    "@@@@@@@@@@@@ Originated Whole loan \n");
        }
        verifyLoanOverPublicSite(LOAN_ID, listingId, testUserEmail);
    }
}
