package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;


public final class WithdrawListingMailTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(WithdrawListingMailTest.class.getSimpleName());

	private String testUserEmail;

    private HashMap<String, String> testData;
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    @Test(groups = {TestGroup.ACCEPTANCE})
    void verifyWithdrawnListingMail()
            throws UnsupportedEncodingException, AutomationException, HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~~verifyWithdrawnListingMail()~~~~~~~~~~~");

        final Map<String, String> experianUserInformation = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.A);

        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("verifyWithdrawnListingMail");
        testData = generateAgrement(testUserEmail);
        listingID = testData.get("LISTINGID");

        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        		 supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();

        // Activate listing
        supportSiteMainPage.activateListing(listingID, "1");

        final ListingsDAO listingsTable = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);

        final long amount = listingsTable.getAmount(listingID);
        final double rate = listingsTable.getCurrentRate(listingID);
        final String title = listingsTable.getTitle(listingID);

        final String contents = MessageBundle.getMessage("withdrawnListingContent").replace("{listingID}", listingID).replace("{title}", title).replace("{amount}", String.valueOf(amount)).replace("{currentRate}", String.valueOf(rate));

     // Verify Bank account email notification
        verifyWebMail(outlookQAWebAppPage, FunnelNames.DIRECT_TO_SITE_FUNNEL.getFunnelProfile(), emailAddress, experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY),
                MessageBundle.getMessage("withdrawnListingSubject"), contents);
    }

}
