
package test.apiui;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PasswordChangePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.SecretQuestionAndAnswerPage;
import com.prosper.automation.pubsite.pages.borrower.SettingsPage;
import com.prosper.automation.util.PollingUtilities;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 29-Aug-2016
 *
 */
public class PasswordResetWithUserSecretQuestionTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PasswordResetWithUserSecretQuestionTest.class.getSimpleName());
    private static final String SHOW_NOTICE_PASSWORD_CHANGE = "showNotice=passwordChanged";
    private static final String SUCCESS_PASSWORD_MESSAGE = "Success. Your password has been changed.";
    private static final String SECRET_ANSWER="ProsperTest23";
    String[] secretQuestions = {"What's your mother's maiden name?", "What city were you born in?",
            "What was your first boyfriend/girlfriend's first name?", "What is the name of street you grew up on?"};
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;
    private String testUserEmail;


    // See comments on ticket BMP-2662
    // BOR-7437 Verify that correct security question is displayed on Security question page if user have set the one
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testPassResetWithSecretQuestion() throws AutomationException, MalformedURLException, UnsupportedEncodingException,
            HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~Executing: testPassResetWithSecretQuestion~~~~~~~~~~");
        Map<String, String> experianUserInformation = ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.A);

        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("testPassResetWithSecretQuestion");
        generateAgrement(testUserEmail);
        // Navigate to sign-in page and click on forgot password.
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");

        PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

        AccountOverviewPage accountOverviewPage = publicSiteSignInPage.signIn(testUserEmail, Constant.COMMON_PASSWORD);
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.selectFromUserHeaderDropdown(HeaderOptions.SETTINGS.getValue());
        SettingsPage settingsPage = accountOverviewPage.goToUserSetting();
        Assert.assertNotNull(settingsPage);
        SecretQuestionAndAnswerPage secretQuestionAndAnswerPage = settingsPage.clickEditSecretQuestion(Constant.COMMON_PASSWORD);
        Assert.assertNotNull(secretQuestionAndAnswerPage);
        Collections.shuffle(Arrays.asList(secretQuestions));
        secretQuestionAndAnswerPage.selectSecretQuestion(secretQuestions[1]);
        secretQuestionAndAnswerPage.enterSecretAnswer(SECRET_ANSWER);
        secretQuestionAndAnswerPage.clickChangeSecretSetting();
        SettingsPage settingsAgainPage=secretQuestionAndAnswerPage.clickOnContinueSetting();
        Assert.assertNotNull(settingsAgainPage);
        settingsAgainPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.ACCOUNT_OVERVIEW.getValue());

        PublicSiteRequestEmailForChangePasswordPage changePasswordPage = publicSiteSignInPage.clickForgotPassword();
        changePasswordPage.enterEmailAddress(testUserEmail);
        changePasswordPage.clickContinue();
        PollingUtilities.sleep(4000);
        // Access personal inbox of user and access unexpired reset password link.
        String identityVerificationUrl =
                verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), testUserEmail,
                        experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY),
                MessageBundle.getMessage("followingUp_resetPassword"), MessageBundle.getMessage("followingUpBody_resetPassword"));
        String code = changePasswordPage.getResetCodeForUser(identityVerificationUrl);
        // Navigate to zipcode, date of birth confirmation page, submit it with valid details and observe.
        try (final PublicSiteMarketplaceLandingPage verificationPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
                        publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + code)) {
            verificationPage.setPageElements(pageElements);
            String fiveDigitZip = experianUserInformation.get(ExperianUserInformation.ZIP_KEY).substring(0, 5);
            PasswordChangePage passwordChangePage = verificationPage.resetPasswordForUser(
                    fiveDigitZip,
                    experianUserInformation.get(ExperianUserInformation.DATE_OF_BIRTH_KEY));
            passwordChangePage.enterNewPassword("P@ssword23");
            passwordChangePage.confirmNewPassword("P@ssword23");
            passwordChangePage.clickChangePassword();
            Assert.assertTrue(passwordChangePage.getWindowLocationHref().contains(SHOW_NOTICE_PASSWORD_CHANGE));
            Assert.assertTrue(passwordChangePage.isStaticTextDisplayed(SUCCESS_PASSWORD_MESSAGE));
        }
    }
}
