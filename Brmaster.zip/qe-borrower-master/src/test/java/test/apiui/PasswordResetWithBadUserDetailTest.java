
package test.apiui;

import com.prosper.automation.constant.ExperianUserInformation;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.db.dao.UserDAO;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.EmailValidationResponse;
import com.prosper.automation.model.platform.UserEmailVerifyResponse;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.FunnelNames;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRequestEmailForChangePasswordPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.util.PollingUtilities;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 29-Aug-2016
 *
 */
public class PasswordResetWithBadUserDetailTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(PasswordResetWithBadUserDetailTest.class.getSimpleName());
    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;
    private String testUserEmail;


    // BMP-1816 Verify that both user with c1.stg & p2pcredit domain are able to reset their password
    // GEAR-1274 Verify that registered user is navigated back to sign-in page on resetting his password
    @Test(groups = {TestGroup.NIGHTLY})
    void testPassResetWithBadDetail() throws AutomationException, MalformedURLException, UnsupportedEncodingException,
            HttpRequestException, InterruptedException {
        LOG.info("~~~~~~~Executing: testPassResetWithBadDetail~~~~~~~~~~");
        final Map<String, String> experianUserInformation =
                ExperianUserInformation.getByProsperCreditGrade(ProsperCreditGrade.AA);

        testUserEmail = TestDataProviderUtil.getUniqueEmailIdForTest("testPassResetWithBadDetail");
        generateAgrement(testUserEmail);
        // Navigate to sign-in page and click on forgot password.
        try (final ClassPathXmlApplicationContext jobContext =
                new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {

        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");

        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

        final PublicSiteRequestEmailForChangePasswordPage changePasswordPage = publicSiteSignInPage.clickForgotPassword();
        changePasswordPage.enterEmailAddress(testUserEmail);
        changePasswordPage.clickContinue();
        }
        PollingUtilities.sleep(4000);
        verifyWebMail(outlookQAWebAppPage, FunnelNames.ABP_FUNNEL.getFunnelProfile(), testUserEmail,
                experianUserInformation.get(ExperianUserInformation.FIRST_NAME_KEY),
        MessageBundle.getMessage("followingUp_resetPassword"), MessageBundle.getMessage("followingUpBody_resetPassword"));
        // final String code = changePasswordPage.getResetCodeForUser(identityVerificationUrl);
        final EmailValidationResponse responseFromEmailService = pubSiteUserService.validateUserEmail(testUserEmail);
        final UserEmailVerifyResponse verifyResponse =
                pubSiteUserService.verifyUserEmail(responseFromEmailService.getActivationKey());
        Assert.assertTrue(verifyResponse.getIsVerified());
        final String code = circleOneDBConnection.getDataAccessObject(UserDAO.class).getUserIDByEmail(testUserEmail);
        // Navigate to zipcode, date of birth confirmation page, submit it with valid details and observe.
        try (final PublicSiteMarketplaceLandingPage verificationPage =
                new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
                        publicSiteUrl + "/borrower/verify-your-identity#/!?code=" + code)) {
            verificationPage.setPageElements(pageElements);
            verificationPage.enterUserZip(Constants.UserCommonTestDetails.INVALIDZIPCODE);
            verificationPage
                    .enterUserDateOfBirth(Constants.UserCommonTestDetails.INVALID_DOB);

            verificationPage.clickContinueUserVerificationBtn();
            verificationPage.waitForPageToLoad("verification-issue");
            PollingUtilities.sleep(4000);
            Assert.assertTrue(verificationPage.getMessagePanelAsElement().isDisplayed());
            Assert.assertTrue(
                    verificationPage.getMessagePanelAsElement().getText().contains((Constants.INVALID_USER_INFO_MESSAGE)));
            LOG.info(
                    "BOR-7432 Verify that user is navigated to error page on submitting Security Question page with incorrect DOB and Zipcode for default questions");
        }
    }
}
