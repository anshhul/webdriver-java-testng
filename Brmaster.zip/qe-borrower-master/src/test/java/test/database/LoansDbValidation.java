
package test.database;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.db.dao.LoansDAO;
import com.prosper.automation.exception.AutomationException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Verify Loans DB for Data issues for data created in past 24 hours
 *
 * Created by Anish
 */
public class LoansDbValidation extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(LoansDbValidation.class.getSimpleName());


    // Note: Validate that if any borrower have 02 active loans within 9 months
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyTwoActiveLoansForOneUserWithin9Months()
            throws AutomationException {
        final LoansDAO loansDAO = circleOneDBConnection.getDataAccessObject(LoansDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyTwoActiveLoansForOneUserWithin9Months: Validate that if any borrower have 02 active loans within 9 months~~~~~~~~~~~~~~~");
        Assert.assertEquals(loansDAO.getNumberOfBorrowerhaving02loansWithin9Months(), 0,
                "Users Should not have Validate that 02 active loans within 9 months");
    }
}
