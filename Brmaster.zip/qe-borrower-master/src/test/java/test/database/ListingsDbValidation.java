
package test.database;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.exception.AutomationException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Verify Listing DB for Data issues for data created in past 24 hours
 *
 * Created by Anish
 */
public class ListingsDbValidation extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ListingsDbValidation.class.getSimpleName());


    // Note: Validate Listing table to check user with 02 active listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyTwoActiveListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyTwoActiveListingsForOneUser: Validate Listing table to check user with 02 active listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("2"), "0", "Users Should not have duplicate active listings");
    }

    // Note: Validate Listing table to check user with 02 Pending activation listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyTwoPendingActiveListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyTwoPendingActiveListingsForOneUser: Validate Listing table to check user with 02 Pending activation listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("1"), "0", "Users Should not have duplicate active listings");
    }

    // Note: Validate Listing table to check user with 02 Pending Completion listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyTwoPendingCompletionListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyTwoPendingCompletionListingsForOneUser: Validate Listing table to check user with 02 Pending Completionlistings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("8"), "0", "Users Should not have duplicate active listings");
    }

    // Note: Validate Listing table to check user with 02 draft listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyTwoDraftListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyTwodraftForOneUser: Validate Listing table to check user with 02 drfat listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("0"), "0", "Users Should not have duplicate draft listings");
    }

    // Note: Validate Listing table to check user with 01 Pending Activation and 01 Active listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyActiveAndPendingActivationListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyActiveAndPendingActivationListingsForOneUser: Validate Listing table to check user with 01 Pending Activation and 01 Active listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("1", "2"), "0",
                "Users Should not have duplicate active listings");
    }

    // Note: Validate Listing table to check user with 01 Pending Activation and 01 Pending Completion listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyPendingCompletionAndPendingActivationListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyPendingCompletionAndPendingActivationListingsForOneUser: Validate Listing table to check user with 01 Pending Activation and 01 Pending Completion listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("8", "1"), "0", "Users Should not have duplicate listings");
    }

    // Note: Validate Listing table to check user with 01 Pending Activation and 01 Active listings
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyPendingCompletionAndActiveListingsForOneUser()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyPendingCompletionAndActiveListingsForOneUser: Validate Listing table to check user with 01 Pending Completion and 01 Active listings~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getduplicatelistingcount("8", "2"), "0", "Users Should not have duplicate listings");
    }

    // Note: Validate Listing table to check Listings with <2k loan amount
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyUserwithlowLoanAmount()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyUserwithlowLoanAmount: Validate Listing table to check user with <2k listing amount~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getCountOfUsersWithLowListingAmount(), "0",
                "Users Should not have Listing with <2k loan amount");
    }

    // Note: Validate Listing table to check Listings with <2k loan amount
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyUserwithighLoanAmount()
            throws AutomationException {
        final ListingsDAO listingsDAO = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        LOG.info(
                "~~~~~~Executing: verifyUserwithlowLoanAmount: Validate Listing table to check user with >35k listing amount~~~~~~~~~~~~~~~");
        Assert.assertEquals(listingsDAO.getCountOfUsersWithMoreThan35KListingAmount(), "0",
                "Users Should not have Listing with >35k loan amount");
    }
}
