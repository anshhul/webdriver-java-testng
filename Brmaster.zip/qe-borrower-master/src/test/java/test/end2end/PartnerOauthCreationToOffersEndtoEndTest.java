
package test.end2end;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.AdminPartnerOauthResponse;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.util.CSVWriterUtil;
import com.prosper.automation.model.platform.marketplace.util.PartnerCsvRow;
import com.prosper.automation.platform.clients.PlatformMarketplaceImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import com.prosper.automation.platform.interfaces.IPlatformMarketplaceAdminPartnerOauth;
import test.api.java.platformMarketplace.MarketplaceOffersTestBase;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * This is used to create oauth for different partners on different environments from csv input Created by rsubramanyam on 4/1/16.
 */
public class PartnerOauthCreationToOffersEndtoEndTest extends MarketplaceOffersTestBase {

    String env = System.getProperty("environment");
    String CSV_INPUT_PATH = System.getProperty("relative.path.testdata.environment") + "/" + env + "/partner_legacy_id_to_create_oauth.csv";
//    String CSV_OUTPUT_PATH = System.getProperty("relative.path.resources") + "/test-generated-output/oauth.csv." + "/" + env;
    String CSV_OUTPUT_PATH = System.getProperty("relative.path.resources") + "/test-generated-output/oauth.csv.";
    @Autowired
    private IPlatformMarketplaceAdminPartnerOauth marketplaceAdminPartnerOauthService;
    @Autowired
    private HttpClientConfig platformServiceConfig;

    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testCreation() throws IOException, HttpRequestException, AutomationException {
        String csvPath = CSV_INPUT_PATH;
        List<PartnerCsvRow> partnerRows = parse(csvPath);
        CSVWriterUtil.write(CSV_OUTPUT_PATH, partnerRows);
    }

    public List<PartnerCsvRow> parse(final String csvFilePath) throws AutomationException, HttpRequestException {
        List<PartnerCsvRow> partnerRows = new ArrayList<PartnerCsvRow>();
        try (final FileInputStream fileInputStream = new FileInputStream(csvFilePath);
                final Reader reader = new InputStreamReader(fileInputStream);
                final CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader())) {
            final List<CSVRecord> records = parser.getRecords();
            for (CSVRecord record : records) {
                AdminPartnerOauthResponse response = marketplaceAdminPartnerOauthService.getOauthDetails(record.get(2), "true");
                partnerRows.add(new PartnerCsvRow(record.get(0), record.get(1), response.getClientWithRolesInfo().getClientInfo().getOauth_client_id(),
                        response.getClientWithRolesInfo().getClientInfo().getOauth_client_secret()));
                tryGetOffersWithPartnerAuthentication(response.getClientWithRolesInfo().getClientInfo().getOauth_client_id(),
                        response.getClientWithRolesInfo().getClientInfo().getOauth_client_secret(), record.get(1), platformServiceConfig);
            }
        } catch (IOException e) {
            throw new AutomationException(e.getMessage());
        }
        return partnerRows;
    }
}
