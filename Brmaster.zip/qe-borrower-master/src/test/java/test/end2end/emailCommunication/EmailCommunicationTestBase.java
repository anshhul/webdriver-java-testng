package test.end2end.emailCommunication;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.testng.annotations.BeforeSuite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.email.ProsperEmailService;
import com.prosper.automation.email.ProsperEmailServiceConfig;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.platform.interfaces.IPlatformInquiry;
import com.prosper.automation.test.TestBase;

/**
 * Created by pbudiono on 8/1/16.
 */
public class EmailCommunicationTestBase extends TestBase {

	@Resource
	protected ProsperEmailService prosperEmailService;
	@Resource
	protected ProsperEmailServiceConfig prosperEmailServiceConfig;
	@Resource
	protected IPlatformInquiry pubSiteInquiryService;

    @Value("${email.wait.time:30000}")
	protected Integer EMAIL_WAIT_THRESHOLD;

	@Override
	@BeforeSuite(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void springTestContextPrepareTestInstance() throws AutomationException {
		initializeSpringContextForTestSetup();
	}
}
