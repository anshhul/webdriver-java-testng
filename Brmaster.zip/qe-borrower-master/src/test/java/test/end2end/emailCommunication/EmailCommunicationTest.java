package test.end2end.emailCommunication;

import javax.annotation.Resource;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.tool.BorrowerDataService;
import com.prosper.automation.util.PollingUtilities;

/**
 * Created by pbudiono on 8/1/16.
 */
public class EmailCommunicationTest extends EmailCommunicationTestBase {

	private static final String EMAIL_VERIFICATION_EMAIL_SUBJECT = "Please verify your email address";

	@Resource
	private BorrowerDataService borrowerTestDataService;

	@Test(groups = { TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY })
	public void testEmailVerificationIsReceivedAfterBorrowerRegistration() throws AutomationException, HttpRequestException {

		final String userEmail = Constant.getGloballyUniqueEmail(true);
		borrowerTestDataService.createNewBorrower(userEmail, ProsperCreditGrade.AA);

		PollingUtilities.sleep(EMAIL_WAIT_THRESHOLD);

		Assert.assertNotNull(prosperEmailService.getUniqueEmail(userEmail, EMAIL_VERIFICATION_EMAIL_SUBJECT));
	}
}
