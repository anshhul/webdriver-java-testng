
package test.end2end;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.core.httpClient.HttpClientConfig;
import com.prosper.automation.core.httpClient.exception.HttpRequestException;
import com.prosper.automation.enumeration.platform.ProsperCreditGrade;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.request.GetOfferRequest;
import com.prosper.automation.model.platform.marketplace.response.GetOffersResponse;
import com.prosper.automation.model.platform.marketplace.response.OfferDetails;
import com.prosper.automation.platform.clients.PlatformMarketplaceImpl;
import com.prosper.automation.platform.interfaces.IPlatformMarketplace;
import com.prosper.automation.webdriver.WebDriverConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.api.java.platformMarketplace.MarketplaceOffersTestBase;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author pbudiono
 */
public final class MarketplaceServiceEndToEndTest extends MarketplaceOffersTestBase {

    @Autowired
    private HttpClientConfig platformMarketplaceServiceConfig;

    @Autowired
    private WebDriverConfig webDriverConfig;

    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;
    @Resource(name = "pageElements")
    private Map<String, String> pageElements;


    @Test(groups = {TestGroup.SANITY, TestGroup.ACCEPTANCE, TestGroup.NIGHTLY})
    public void testMarketplaceOfferReturnCorrectLandingPage() throws AutomationException, HttpRequestException {

        final IPlatformMarketplace platformMarketplace = new PlatformMarketplaceImpl(platformMarketplaceServiceConfig);

        final String marketplaceUserEmail = Constant.getGloballyUniqueEmail();
        final GetOfferRequest getOfferRequest = buildMarketplaceOfferRequest(ProsperCreditGrade.F, marketplaceUserEmail, "2");

        final GetOffersResponse getOffersResponse = platformMarketplace.getOffer(getOfferRequest);

        final List<OfferDetails> marketplaceOffers = getOffersResponse.getOffers();
        Assert.assertNotEquals(0, marketplaceOffers.size(), "Offers size is 0.");

        final String requestedOfferUrl = marketplaceOffers.get(0).getOffersUrl();
        LOG.info("Marketplace url"+requestedOfferUrl);
//        try (final PublicSiteMarketplaceLandingPage publicSiteMarketplaceLandingPage =
//                new PublicSiteMarketplaceLandingPage(webDriverConfig, URLUtilities.getScheme(requestedOfferUrl),
//                        URLUtilities.getStringURLWithoutScheme(requestedOfferUrl)))
//TODO:PPATIL :Update the test(Auto ticket created)
        ObjectMapper ob = new ObjectMapper();
//        try (final PublicSiteMarketplaceLandingPage publicSiteMarketplaceLandingPage =
//                     new PublicSiteMarketplaceLandingPage(webDriverConfig, publicSiteUrlScheme,
//                             publicSiteUrl + requestedOfferUrl))
//        {
//            publicSiteMarketplaceLandingPage.setPageElements(pageElements);
//            final MarketplaceOffer pageMarketplaceOffer = publicSiteMarketplaceLandingPage.getMarketplaceOffer();
//            try {
//                LOG.info("MarketPlaceOfferResponse ::"+ob.writeValueAsString(pageMarketplaceOffer));
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//            }
//
//
//            Assert.assertEquals(pageMarketplaceOffer, marketplaceOffers.get(0));
//        }
    }
}
