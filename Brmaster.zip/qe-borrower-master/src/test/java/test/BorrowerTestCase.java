
package test;

/**
 * @author pbudiono
 */
public interface BorrowerTestCase {

    String BMP = "BMP";
    String GEAR = "GEAR";
}
