
package test.ui.pubsite.borrower.directToSite;

import com.google.common.base.Preconditions;
import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.List;
import java.util.Map;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-527 Verify that new user is able to complete DTS funnel
 *
 * Created by rsubramanyam on 5/10/16.
 */
public class BorrowDTSFunnelSmokeTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowDTSFunnelSmokeTest.class.getSimpleName());

    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // Note: AUTO-183 - DTS funnel (with moved fields) with miicard bank page
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyDTSFunnel() throws AutomationException {

        LOG.info("~~~~~~Executing: verifyDTSFunnel~~~~~~~~~~~~~~~");
        final PublicSiteRegistrationPage publicSiteRegistrationPage = publicSitePreRegistrationPage.checkYourRate();

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyDTSFunnel");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        final PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();
        // Verify new Personal detail Header text

        personalDetailsPage.fillPersonalDetailPage(getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        final String listingID = tilPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                .submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage =
                manualBankAccountPage.enterBankInfo(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                        "Savings",
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                        getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG), null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        final AccountOverviewPage accountOverviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        Assert.assertNotNull(accountOverviewPage);
        final List<Map<String, Object>> listingInfo = queryCircleOne(MessageBundle.getMessage("listingsTable") + listingID);

        Assert.assertEquals(listingInfo.get(0).get("BRERuleVersion").toString(), Constants.BRE_RULE_VERSION);
        if (accountOverviewPage.getWindowLocationHref().contains("signin")) {
            accountOverviewPage.close();
            // Log into the Public site with user created above
            try (final ClassPathXmlApplicationContext jobContext =
                    new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml")) {
                final PublicSiteSignInPage publicSiteSignInPage =
                        (PublicSiteSignInPage) jobContext.getBean("publicSiteSignInPage");
                final AccountOverviewPage overviewPageAgain = publicSiteSignInPage.signIn(email, Constant.COMMON_PASSWORD);
                // Verify that New Account overview page is displayed on sign in
                overviewPageAgain
                        .goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
                overviewPageAgain.dismissCongratulationWelcomeModal();
                Assert.assertNotNull(overviewPageAgain.getListingDetail(), "Account Overview page should be displayed");
            }
        }
        final String listingId = accountOverviewPage.getListingInfo().get("LISTING ID");
        LOG.info("Borrower from DTS funnel is able to complete listing" + listingId);
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(email);

        final List<Map<String, Object>> lendingAccreditationRecord =
                queryCircleOne(String.format(MessageBundle.getMessage("lendingAccreditation"), userId));
        Assert.assertEquals(lendingAccreditationRecord.get(0).get("IsDataTermsOfUseApproved"), Boolean.TRUE);

        final List<Map<String, Object>> agreementRecord =
                queryCircleOne(String.format(MessageBundle.getMessage("agreements"), userId));
        Preconditions.checkNotNull(agreementRecord, "Agreements record is null");
        Assert.assertTrue(agreementRecord.get(0).get("CreatedDate").toString()
                .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")));
    }
}
