
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-450 Verify that decline is displayed to new user eligible for EP offers
 *
 * @author hisharma
 *
 */
public class EPNewUserBORTest extends PartnerLandingPageTestBase {

    protected static String environment;

    @DataProvider(name = "fico581UserData")
    public static Object[][] userDetails() {
        environment = System.getProperty("environment");
        if ("staging2".equalsIgnoreCase(environment)) {
            return new Object[][] {Xls_Reader.readExcelData(
                    "userRegistrationData.xlsx", "unconsumedOfferCodeUsers",
                    "fico581User_stg2")};
        } else
        {
            return new Object[][] {Xls_Reader.readExcelData(
                    "userRegistrationData.xlsx", "unconsumedOfferCodeUsers",
                    "fico581User_qa32")};
        }
    }

    @Test(dataProvider = "fico581UserData", groups = {TestGroup.ACCEPTANCE}, enabled = false)
    public void verifyEPNewUserDecline(String key, String offerCode, String loanAmount, String loanPurpose, String creditQuality,
                                       String firstName, String lastName, String middleInitial, String suffix, String dob,
                                       String homeAddress, String city, String state,
                                       String zipCode, String employmentStatus, String yearlyIncome, String emailAddress,
                                       String password, String primaryPhone, String secondaryPhone, String workPhone,
                                       String employerName,
                                       String employerPhone, String occupation, String startOfEmployment, String ssn,
                                       String bankName, String AAHolderName, String routingNumber, String accountNumber)
            throws Exception {

        // Navigate to partner page
        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + getDMPagesURI().get(0).get("URL"))) {
            partnerLandingPage.setPageElements(pageElements);

            resetOfferCode(getPrimeBorrowerData().get(offerCode));

            // submit DM Landing Page with User's OfferCode
            final PublicSiteRegistrationPage publicSiteRegistrationPage = partnerLandingPage.submitDmOfferWidget(loanAmount, offerCode);

            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledFirstNameDisplayed(), "First Name should  prefilled");
            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledLastNameDisplayed(), "Last Name should prefilled");
            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledStateDisplayed(), "State should prefilled");
            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledCityDisplayed(), "City should prefilled");
            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledAddressDisplayed(), "Address should prefilled");
            Assert.assertTrue(publicSiteRegistrationPage.isPrefilledZipDisplayed(), "Zip Should prefilled");

            final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyEPNewUserDecline");
            LOG.info("User email is: " + email);
            publicSiteRegistrationPage.submitRegistrationForm(null, null, null, null, null, null, null, null, employmentStatus,
                    yearlyIncome, dob, email, password);

            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // Verify that decline is displayed with correct contents
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage
                    .clickGetYourRate(false, false);

            // publicSiteRegistrationPage.handleSSNPage(ssn);

            Assert.assertNotNull(publicSiteOfferPage);
            PollingUtilities.sleep(3000);
            if (publicSiteOfferPage.isDeclinePageAppears()) {
                final PublicSiteDeclinePage publicSiteDeclinePage = publicSiteOfferPage.goToDeclinePage();
                Assert.assertTrue(publicSiteDeclinePage.getDeclinePageContentAsElement().getText()
                        .contains("We've partnered with AmOne to provide you with additional options."));
            }
        }
    }
}
