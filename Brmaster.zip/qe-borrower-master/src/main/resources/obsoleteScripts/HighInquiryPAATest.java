
package test.ui.pubsite.borrower.directToSite.primeAA;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;

import test.ui.WebDriverTestBase;

/**
 *
 * BOR-11011 Verify that decline is displayed to having A user having HIGH Inquiry (ALL803>6)
 *
 * @author hisharma
 *
 */
public class HighInquiryPAATest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(CSLessThan640PAABorrowerTest.class);


    @DataProvider(name = "highInquiryUser")
    public static Object[][] highInquiryUserData() {

        return new Object[][] {
                Xls_Reader.readExcelData("borTestData.xlsx", "newUserAA", "highInquiryUser")};

    }


    @Autowired
    protected CloseableJdbcConnection adverseActionEventDBConnection;

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

    private static String messageId;


    // Defect GEAR-1619
    @Test(dataProvider = "highInquiryUser", groups = {TestGroup.ACCEPTANCE}, enabled = true)
    public void verifyHighInquiryPAA(String adverseAction, String loanAmount,
                                     String loanPurpose, String creditQuality, String firstName, String lastName,
                                     String homeAddress, String city, String state, String zipCode,
                                     String employmentStatus, String yearlyIncome, String dob, String emailAddress,
                                     String password) throws AutomationException, IOException {

        LOG.info("Test Method Name - verifyHighInquiryPAA()");

        // Submit Home page
        final PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyHighInquiryPAA");
        LOG.info("User email is: " + email);
        emailAddress = registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email,
                password, firstName, lastName, homeAddress, city, state, employmentStatus,
                yearlyIncome, dob);
        LOG.info("Email address of the user: " + emailAddress);

        registrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // Decline Page content check
        Assert.assertTrue(offerPage.isDeclinePageAppears(), "Decline should be displayed");


        final PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
        PollingUtilities.sleep(4000);
        Assert.assertTrue(declinePage.isStaticTextDisplayed(Constants.AMONE_PARTNER_DECLINE),
                "Decline Message is not correct");
        Assert.assertTrue(declinePage.isStaticTextDisplayed(Constants.BASED_ON_CREDIT_DECLINE),
                "Decline Message is not correct");
        Assert.assertTrue(declinePage.isStaticTextDisplayed(Constants.CONTINUE_ANYWAY_ON_DECLINE),
                "Decline Message is not correct");
        declinePage.clickOnProsperLogo();


        Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());

        // Navigate to History page through dropdown: a workaround due to NGMA-1006
        publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
        
        // Navigate to Messages Page
        publicSitePreRegistrationPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.MESSAGES.getValue());
        final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();

        // check url response for 503 or 400 bad request
        messagesPage.waitForPageToLoad("messages.aspx");
        if (!messagesPage.isLinkActive(messagesPage.getWindowLocationHref())) {
            messagesPage.reload();
        }
        // Verify message and navigate to View Messages Page
        final ViewMessagePage viewmessagesPage = messagesPage.verifyAndClickMessage(Constants.MessagesPage.UNABLE_TO_APPLY);

        messageId = viewmessagesPage.getMessageIdFromURL();

        // Verify message content
        viewmessagesPage.verifyMessageContent(firstName,
                MessageBundle.getMessage("tooManyRecentInquiries"));

        // To check HTML tags. Refer ticket BMP-2652
        Assert.assertFalse(viewmessagesPage.messageContains("<"));

        // Navigate to History Page
        viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());

        // Navigate to 'Event History' Page
        final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
        final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();

        // Verify that appropriate events are displayed on the 'Event History' page
        eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
                Constants.EventHistorypage.CREDIT_SCORE_UNAVAILABLE_EVENT_NAME);
        eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
                Constants.EventHistorypage.AALETTERDETAILS);

        // Click on 'Adverse Action Letter' link displayed within event details and verify Agreement Page content
        eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
        // switched to newly opened window
        eventHistoryPage.switchToNewlyOpenedWindow();
        Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
                .contains(MessageBundle.getMessage("tooManyRecentInquiries")));
        eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);

        // Navigate to History Page
        eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
        final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();

        // Verify Agreement page content and get AgreementID from URL for further use
        final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(MessageBundle.getMessage("AALetter"),
                MessageBundle.getMessage("tooManyRecentInquiries"));

        // Get user id
        final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userEmail.getUserIDByEmail(emailAddress);

        // Verify the values displayed in table AdverseActionEvent
        final AdverseActionEventDAO adverseActionEventInfo =
                circleOneDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
                AdverseActionTemplate.TOOMANY_RECENT_INQUIRIES_LAST6MONTHS.getAdverseActionEventTypeID());

        // Get 'AdverseActionEventID' from the query result
        final String adverseActionEventId =
                adverseActionEventInfo.getAdverseActionEventID(emailAddress);
        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
                "messagesent data should not be null");

        // Verify the values displayed in MessageSent tabl
        Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));

        Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));

        // Verify the values displayed in AdverseActionEventSquareCutInfo table
        Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
                SquareCutTemplate.TOOMANY_RECENT_INQUIRIES_LAST6MONTHS.getSquareCutTypeID());

        // Verify the values displayed in tblloanofferdecline table
        final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
        Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
                DeclineReasonTemplate.TOOMANY_RECENT_INQUIRIES_LAST6MONTHS.getDeclineReasonID());
        // Note: Message is not triggered instantly(https://saucelabs.com/beta/tests/b5354c6442a04e2da6f741b355e924b1/watch),
        // hence assert webmail box before validation of AA letter and message section
        // Verify An email notification "Information about your loan request" should be triggered to user in his personal email
        // inbox
        verifyWebMail(outlookQAWebAppPage, "QA", emailAddress, firstName,
                MessageBundle.getMessage("infoAboutLoanRequest"),
                MessageBundle.getMessage("notEligibleForLoan"));

        LOG.info("**** Passed ****");

    }

}
