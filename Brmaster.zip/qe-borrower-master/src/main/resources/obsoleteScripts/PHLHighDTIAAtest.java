// package test.ui.pubsite.borrower.directToSite.primeAA;
//
// import org.apache.log4j.Logger;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Qualifier;
// import org.springframework.context.ApplicationContext;
// import org.springframework.context.support.ClassPathXmlApplicationContext;
// import org.testng.Assert;
// import org.testng.annotations.DataProvider;
// import org.testng.annotations.Test;
//
// import com.prosper.automation.constant.test.TestGroup;
// import com.prosper.automation.constant.web.Constants;
// import com.prosper.automation.constant.web.MessageBundle;
// import com.prosper.automation.db.dao.AdverseActionEventDAO;
// import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
// import com.prosper.automation.db.dao.UserEmailDAO;
// import com.prosper.automation.exception.AutomationException;
// import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
// import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
// import com.prosper.automation.pubsite.enumeration.HeaderOptions;
// import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
// import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
// import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
// import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
// import com.prosper.automation.pubsite.pages.borrower.PhlOfferPage;
// import com.prosper.automation.pubsite.pages.borrower.PhlProviderSearchPage;
// import com.prosper.automation.pubsite.pages.borrower.PhlRegistrationPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
// import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
// import com.prosper.automation.util.web.borrower.common.Xls_Reader;
//
// import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;
//
/// **
// * @author ntaneja BMP-4284:PHL: Verify that decline is displayed to user having
// * DTI>50%
// */
// public class PHLHighDTIAAtest extends PartnerLandingPageTestBase {
//
// protected static final Logger LOG = Logger.getLogger(PHLHighDTIAAtest.class.getSimpleName());
//
// private static final String Provider_ID = "031143";
// private static String messageId;
//
// @Autowired
// OutlookWebAppLoginPage outlookQAWebAppPage;
//
// @Qualifier("phlProviderSearchPage")
// private PhlProviderSearchPage phlProviderSearchPage;
//
// @DataProvider(name = "testData")
// public static Object[][] userRegisterData() {
// return new Object[][] { Xls_Reader.readExcelData("userRegistrationData.xlsx", "PhlTestUsers", "highDTIUser"), };
// }
//
// @Test(dataProvider = "testData", groups = { TestGroup.NIGHTLY })
// public void testPHLHighDTIAA(String Key, String loanAmount, String creditQuality, String firstName, String lastName,
// String middleInitial, String dob, String homePhone, String homeAddress, String city, String state,
// String zipCode, String relationType, String employmentStatus, String yearlyIncome, String emailAddress,
// String workPhone, String employerName, String employerPhone, String occupation, String employmentMonth,
// String employmentYear, String SSN, String password, String bankName, String routingNumber,
// String accountNumber, String confirmAccountNumber) throws AutomationException {
//
// LOG.info("~~~~~~Executing: verifyPHLEndToEndListing~~~~~~~~~~~~~~~");
//
// password = MessageBundle.getMessage("password");
//
// phlProviderSearchPage.enterProviderId(Provider_ID);
//
// PhlRegistrationPage phlRegistrationPage = phlProviderSearchPage.verifyProvider();
//
// emailAddress = phlRegistrationPage.submitRegistrationForm(loanAmount, creditQuality, firstName, lastName,
// middleInitial, dob, homePhone, emailAddress, homeAddress, city, state, zipCode, employmentStatus,
// yearlyIncome);
//
// phlRegistrationPage.clickElectronicSignatureCheckBox();
// LOG.info("Email address of the user: " + emailAddress);
//
// PhlOfferPage phlOfferPage = phlRegistrationPage.clickGetYourLoanOption();
//
// /// Go to Public Site
//
// ApplicationContext jobContext1 = new ClassPathXmlApplicationContext(
// "public_site/spring/public_site_context.xml");
// PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext1
// .getBean("publicSitePreRegistrationPage");
//
// Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());
//
// PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();
//
// publicSiteSignInPage.enterUserEmail(emailAddress);
// publicSiteSignInPage.enterUserPassword("P@ssword23");
// publicSiteSignInPage.clickContinue();
//
// publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
//
// // Navigate to Messages Page
// publicSitePreRegistrationPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.MESSAGES.getValue());
// final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();
// // check url response for 503 or 400 bad request
// messagesPage.waitForPageToLoad("messages.aspx");
// if (!messagesPage.isLinkActive(messagesPage.getWindowLocationHref())) {
// messagesPage.reload();
// }
// // Verify message and navigate to View Messages Page
// final ViewMessagePage viewmessagesPage = messagesPage
// .verifyAndClickMessage(Constants.MessagesPage.UNABLE_TO_APPLY);
//
// messageId = viewmessagesPage.getMessageIdFromURL();
//
// // Verify message content
// viewmessagesPage.verifyMessageContent(firstName, MessageBundle.getMessage("debtIsTooLarge"));
//
// // To check HTML tags. Refer ticket BMP-2652
// Assert.assertFalse(viewmessagesPage.messageContains("<"));
//
// // Navigate to History Page
// viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
//
// // Navigate to 'Event History' Page
// final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
// final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();
//
// // Verify that appropriate events are displayed on the 'Event History'
// // page
// eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
// Constants.EventHistorypage.CREDIT_SCORE_UNAVAILABLE_EVENT_NAME);
// eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
// Constants.EventHistorypage.AALETTERDETAILS);
//
// // Click on 'Adverse Action Letter' link displayed within event details
// // and verify Agreement Page content
// eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
// // switched to newly opened window
// eventHistoryPage.switchToNewlyOpenedWindow();
// Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
// .contains(MessageBundle.getMessage("debtIsTooLarge")));
// eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
//
// // Navigate to History Page
// eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
// final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();
//
// // Verify Agreement page content and get AgreementID from URL for
// // further use
// final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(
// MessageBundle.getMessage("AALetter"), MessageBundle.getMessage("debtIsTooLarge"));
//
// // Get user id
// final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
// final String userId = userEmail.getUserIDByEmail(emailAddress);
//
// // Verify the values displayed in table AdverseActionEvent
// final AdverseActionEventDAO adverseActionEventInfo = circleOneDBConnection
// .getDataAccessObject(AdverseActionEventDAO.class);
//
// Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
// AdverseActionTemplate.NONMORTGAGE_PAYMENT_TOOHIGH_TU.getAdverseActionEventTypeID());
//
// // Get 'AdverseActionEventID' from the query result
// final String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(emailAddress);
// Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
// "messagesent data should not be null");
//
// // Verify the values displayed in MessageSent tabl
// Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));
//
// Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));
//
// // Verify the values displayed in AdverseActionEventSquareCutInfo table
//
// Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
// SquareCutTemplate.NONMORTGAGE_PAYMENT_TOOHIGH.getSquareCutTypeID());
//
// // Verify the values displayed in tblloanofferdecline table
// final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection
// .getDataAccessObject(LoanOfferDeclineDAO.class);
//
// Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
// DeclineReasonTemplate.NONMORTGAGE_PAYMENT_TOOHIGH.getDeclineReasonID());
//
// // Note: Message is not triggered
// // instantly(https://saucelabs.com/beta/tests/b5354c6442a04e2da6f741b355e924b1/watch),
// // hence assert webmail box before validation of AA letter and message
// // section
// // Verify An email notification "Information about your loan request"
// // should be triggered to user in his personal email
// // inbox
// verifyWebMail(outlookQAWebAppPage, "QA", emailAddress, firstName,
// MessageBundle.getMessage("infoAboutLoanRequest"), MessageBundle.getMessage("notEligibleForLoan"));
// LOG.info("**** Passed ****");
//
// LOG.info(
// "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~verifyPHLEndToEndListing
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PASSED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
// LOG.info(
// "BMP-4284:PHL: Verify that decline is displayed to user having DTI>50%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PASSED");
//
// }
// }
