
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * GEAR - 1463 Verify funnel flow from original landing page
 *
 *
 */
public class BorrowDTSOriginalFunnelTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowDTSFunnelSmokeTest.class
            .getSimpleName());

    @Resource
    private PublicSitePreRegistrationPage originalPreRegistrationPage;

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;


    @DataProvider(name = "testData")
    public static Object[][] userRegisterData() {
        return new Object[][] {Xls_Reader.readExcelData(
                "userRegistrationData.xlsx", "preRegisterPageLoanPurpose",
                "homeImprovementListing"),};
    }

    // GEAR-1773
    @Deprecated
    @Test(dataProvider = "testData", groups = {TestGroup.ACCEPTANCE})
    public void verifyDtsOriginalFunnel(String Key, String jiraID,
                                        String loanAmount, String loanPurpose, String creditQuality,
                                        String firstName, String middleInitial, String lastName,
                                        String homeAddress, String city, String state, String zipCode,
                                        String employmentStatus, String yearlyIncome, String dob,
                                        String emailAddress, String password, String homePhone,
                                        String mobilePhone, String workPhone, String employerName,
                                        String employerPhone, String occupation,
                                        String employmentStartDate, String SSN, String bankName,
                                        String accountType, String accountholderName,
                                        String AlternateAccountHolderName, String routingNumber,
                                        String accountNumber, String confirmAccountNumber,
                                        String paymentType) throws AutomationException {

        LOG.info("Test Method Name- verifyDtsOriginalFunnel");
        // Comment due to GEAR-1773
        // Assert.assertTrue(originalPreRegistrationPage.isOldLandingPageDisplayed(),
        // "OLD Landing Page with original flag is successfully displayed");

        // Submit Home page
        PublicSiteRegistrationPage registrationPage =
                originalPreRegistrationPage.checkYourRate();
        // Check Old Page is displayed
        // Assert.assertFalse(registrationPage.isNewRegisterationPageDisplayed(), "OLD DTS Registeration Page is displayed");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");

        // Submit Register page

        emailAddress = registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email,
                MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // Submit Loan Offers page

        PublicSitePersonalDetailPage detailsPage = offerPage.clickGetLoan();

        // Submit Personal Details page
        Assert.assertFalse(detailsPage.isNewPersonalDetailPageDisplayed(), "OLD Personal Details page is displayed");

        detailsPage.fillPersonalDetailPage(homePhone, mobilePhone, workPhone, employerName, employerPhone, occupation,
                employmentStartDate, SSN);
        PublicSiteTruthInLendingDisclosurePage tilPage = detailsPage.clickContinue();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();
        PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
        PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage.submitManualBankOption();

        // Submit Bank Information Page
        PublicSiteThankYouPage borrowerThankYouPage = manualBankPage.enterBankInfo(bankName, accountType, accountholderName,
                AlternateAccountHolderName, routingNumber, accountNumber, confirmAccountNumber, paymentType);

        // Submit Thank you page
        AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPage.waitForAccountOverviewPageToLoad();
        overviewPage.dismissCongratulationWelcomeModal();
        String listingID = overviewPage.getListingInfo().get("LISTING ID");
        Assert.assertNotNull(listingID, "Account Overview page should be displayed");

        LOG.info("GEAR - 1463 Verify funnel flow from original landing page");
    }
}
