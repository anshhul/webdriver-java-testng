package test.ui.pubsite.borrower.appByPhone.withoutEmailInboxCheck;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteMarketplaceLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPBankInfoPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPPersonalDetailPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPThankYouPage;
import com.prosper.automation.util.URLUtilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;
/**
 * Created by ppatil on 5/27/16.
 */

public class ABPHappyPathAWithoutEmailTest extends PartnerLandingPageTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPHappyPathAWithoutEmailTest.class.getSimpleName());
    /*
     * @Autowired SupportSiteLandingPage supportSiteLandingPage;
     */
    @Autowired
    OutlookWebAppLoginPage outlookAbpWebAppPage;


    // PART-1325 [Direct Mail] Path A: Borrower should be able to complete the funnel from public site java funnel.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testHappyPathAFlowWithoutEmail() throws AutomationException {

        LOG.info("~~~~~~~~~~Executing: testHappyPathAFlowWithoutEmail~~~~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");
        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testHappyPathAFlowWithoutEmail", "p2pcredit");
        LOG.info("ABP User email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage.enterFirstName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of borrower");
        abpRegistrationPage.enterLastName(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of borrower");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  borrower");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of borrower");
        abpRegistrationPage.enterHomeAddress(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of borrower");
        abpRegistrationPage.selectState(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage.enterZipCode(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of borrower");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of borrower");
        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of borrower");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth borrower");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for borrower");
        abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage.enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
        abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        // Get referal code from url
        String  referralCode = abpOfferPage.getReferalCode();
        // click on choose rate button
        ABPPersonalDetailPage abpPersonalDetailPage = abpOfferPage.clickOnChooseRate();

        // csa is submitting personal detail for borrower
        abpPersonalDetailPage.enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
        abpPersonalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
        abpPersonalDetailPage.selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
        abpPersonalDetailPage
                .enterStartOfEmployment(getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
        abpPersonalDetailPage
                .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
        String pathAUrl = abpPersonalDetailPage.getABPPathAUrl(referralCode);
        ABPBankInfoPage abpBankInfoPage = abpPersonalDetailPage.clickContinue();
        // enter bank details

        abpBankInfoPage
                .enterAlternateAccountHolderName(getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
        abpBankInfoPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
        abpBankInfoPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
        abpBankInfoPage.enterAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG));
        abpBankInfoPage.enterConfirmAccountNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG));
        // CSA thank you page is displayed
        ABPThankYouPage abpThankYouPage = abpBankInfoPage.clickOnFinish();
        // assert thank you page context
        Assert.assertEquals(abpThankYouPage.getThankYouHeaderAsElement().getText(), Constants.ThankYourPage.ABPTHANKYOUHEADER);
        abpThankYouPage.close();
        // Use the generated ABP PathA URL(Skipping Mailbox)
        try (final PublicSiteMarketplaceLandingPage abpLandingPage =
                     new PublicSiteMarketplaceLandingPage(webDriverConfig,
                             URLUtilities.getScheme(pathAUrl), URLUtilities.getStringURLWithoutScheme(pathAUrl))) {
            abpLandingPage.setPageElements(pageElements);
            abpLandingPage.clickElectronicSignatureCheckBox();
            abpLandingPage.enterPassword(Constant.COMMON_PASSWORD);
            LOG.info("Borrower submit the ABP Landing Page and create own Password");
            PublicSiteTruthInLendingDisclosurePage disclosurePage = abpLandingPage.finishYourLoan(pathAUrl);
            String listingID = disclosurePage.getListingIdFromTILAContent();
            disclosurePage.confirmElectronicSignature();
            PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = disclosurePage.clickContinue();
            PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
            publicSiteThankYouPage.clickGoToMyAccountPage();
            // User navigate to Account Overview Page and observed the listing
            LOG.info("ABP  Path A Borrower ListingID is:" + listingID);
            LOG.info("PART-1325 [Direct Mail] Path A: Borrower should be able to complete the funnel from public site java funnel.");

        }
        LOG.info("~~~~~~~~~~testHappyPathAFlowWithoutEmail--PASSED~~~~~~~~~~~~~~~~~~~~");
    }

}
