
package test.ui.pubsite.borrower.directToSite.primeAA;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * BMP-538 Verify that decline is displayed to user having FICO 720+ and Age of 1st Loan < 6 months
 *
 *
 * @author hisharma
 *
 */
public class CS720PlusLoanAgeLessThan6MonthsTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(CS720PlusLoanAgeLessThan6MonthsTest.class);


    @DataProvider(name = "loanAge6MonthsPAA")
    public static Object[][] userData() {

        final String env = System.getProperty("environment");

        if (env.equals("staging2")) {
            return new Object[][] {Xls_Reader.readExcelData("borTestData.xlsx", "existingUserPAA", "loanAge6Months_stg2")};
        } else if (env.equals("qa32")) {
            return new Object[][] {Xls_Reader.readExcelData("borTestData.xlsx", "existingUserPAA", "loanAge6Months_qa32")};
        } else {
            return null;
        }

    }


    @Autowired
    protected CloseableJdbcConnection adverseActionEventDBConnection;

    @Autowired
    OutlookWebAppLoginPage outlookQAWebAppPage;

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

    private final static String DECLINE_CONTENT = MessageBundle.getMessage("existingProsperLoan");
    private static String messageId;


    @Test(dataProvider = "loanAge6MonthsPAA", groups = {TestGroup.ACCEPTANCE})
    public void verify6MonthsLoanAgeUserPAA(String adverseAction, String loanAmount, String loanPurpose,
                                            String creditQuality, String emailAddress, String password, String firstName,
                                            String lastName)
            throws AutomationException {

        LOG.info("Test Method Name - verify6MonthsLoanAgeUserPAA()");

        // Sign in with Existing user
        final PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();
        final AccountOverviewPage overviewPage = publicSiteSignInPage.signIn(emailAddress, MessageBundle.getMessage("password"));
        if (overviewPage.getWindowLocationHref().contains("signin")) {
            overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
            overviewPage.waitForAccountOverviewPageToLoad();
            overviewPage.dismissCongratulationWelcomeModal();
        }
        // Navigate to Home page
        overviewPage.clickOnProsperLogo();

        // Submit Home page
        final PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage
                .checkYourRate();

        // Reset Adverse action event date to avoid 120 decline
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userID = userInfo.getUserIDByEmail(emailAddress);

        final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
        loanOfferDeclineInfo.updateCreatedDate(userID);

        final AdverseActionEventDAO adverseActionEventInfo =
                adverseActionEventDBConnection.getDataAccessObject(AdverseActionEventDAO.class);
        adverseActionEventInfo.updateAdverseActionEventDate(userID);

        // Submit pre-populated Register page
        registrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // Decline Page content check
        final PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
        Assert.assertTrue(declinePage.getDeclinePageContentAsElement().getText().contains(DECLINE_CONTENT));
        declinePage.clickOnProsperLogo();

        Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());

        // Navigate to History page through dropdown: a workaround due to NGMA-1006
        publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());

        // Navigate to Messages Page
        publicSitePreRegistrationPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.MESSAGES.getValue());
        final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();
        // check url response for 503 or 400 bad request
        messagesPage.waitForPageToLoad("messages.aspx");
        if (!messagesPage.isLinkActive(messagesPage.getWindowLocationHref())) {
            messagesPage.reload();
        }
        // Verify message and navigate to View Messages Page
        final ViewMessagePage viewmessagesPage =
                messagesPage.verifyAndClickMessage(Constants.MessagesPage.UNABLE_TO_APPLY_ANOTHER_LOAN);

        messageId = viewmessagesPage.getMessageIdFromURL();

        // Verify message content
        viewmessagesPage.verifyMessageContent(firstName, MessageBundle.getMessage("loanAge6MonthMessage"));

        // To check HTML tags. Refer ticket BMP-2652
        Assert.assertFalse(viewmessagesPage.messageContains("<"));

        // Navigate to History Page
        viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());

        // Navigate to 'Event History' Page
        final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
        final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();

        // Verify that appropriate events are displayed on the 'Event History'
        // page
        eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
                Constants.EventHistorypage.UNABLE_TO_APPLY_ANOTHER);
        eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
                Constants.EventHistorypage.AALETTERDETAILS);

        // Click on 'Adverse Action Letter' link displayed within event details
        // and verify Agreement Page content
        eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
        // switched to newly opened window
        eventHistoryPage.switchToNewlyOpenedWindow();
        Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
                .contains(MessageBundle.getMessage("loanAge6MonthMessage")));
        eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);

        // Navigate to History Page
        eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
        final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();

        // Verify Agreement page content and get AgreementID from URL for
        // further use
        final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(MessageBundle.getMessage("AALetter"),
                MessageBundle.getMessage("loanAge6MonthMessage"));

        // Get user id
        final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userEmail.getUserIDByEmail(emailAddress);

        // Verify the values displayed in table AdverseActionEvent
        Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
                AdverseActionTemplate.LOWFICO_AND_LESSTHAN_6MONTHS.getAdverseActionEventTypeID());

        // Get 'AdverseActionEventID' from the query result
        final String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(emailAddress);
        Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
                "messagesent data should not be null");

        // Verify the values displayed in MessageSent tabl
        Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));

        Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));

        // Verify the values displayed in AdverseActionEventSquareCutInfo table
        Assert.assertFalse(adverseActionEventInfo.isSquareCutTypeID(adverseActionEventId));

        // Verify the values displayed in tblloanofferdecline table
        Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
                DeclineReasonTemplate.LOWFICO_AND_LESSTHAN_6MONTHS.getDeclineReasonID());

        // Verify An email notification "Information about your loan request"
        // should be triggered to user in his personal email inbox
        verifyWebMail(outlookQAWebAppPage, "QA", emailAddress, firstName,
                MessageBundle.getMessage("infoAboutLoanRequest"), MessageBundle.getMessage("notEligibleForLoan"));
        LOG.info("**** Passed ****");

    }

}
