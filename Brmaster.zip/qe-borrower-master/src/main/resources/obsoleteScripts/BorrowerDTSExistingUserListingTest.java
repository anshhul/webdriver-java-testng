
package test.ui.pubsite.borrower.directToSite;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 15-Jun-2016
 *
 */
@Deprecated
public class BorrowerDTSExistingUserListingTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(BorrowerDTSExistingUserListingTest.class.getSimpleName());


    // AUTO-183 DTS funnel with old bank page.(without movedFields)[Existing User listing process]
    @Test
    void testListingForExistingUserViaSignInPage() throws AutomationException {

        LOG.info("~~~~~~Executing-testListingForExistingUserViaSignInPage~~~~~~~~~~~~~~~");

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickSignIn();

        AccountOverviewPage accountOverviewPage = publicSiteSignInPage
                .signIn(getUserForEnvironment("testListingForExistingUserViaSignInPage"), Constant.COMMON_PASSWORD);

        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.dismissCongratulationWelcomeModal();
        PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = accountOverviewPage.clickOnProsperLogo();
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationAgainPage.checkYourRate();
        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        publicSiteOfferPage.getThreeYearFixedMonthlyPaymentAmount();
        PublicSitePersonalDetailPage personalDetailsPage = publicSiteOfferPage.clickGetLoan();

        // Verify new Personal detail Header text
        personalDetailsPage.verifyPersonalDetailPageHeaderContent();

        // need to enter employer phone because user is coming via old pre-reg page
        personalDetailsPage.enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));

        Assert.assertTrue(personalDetailsPage.getSsnPopulated());
        LOG.info("Verified - Personal Detail Page is pre-filled for existing User have submitted Personal info earlier");
        PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage.clickContinue();

        tilPage.confirmElectronicSignature();
        String newListing = getQueryMap(tilPage.getListingIdFromTILAContent()).get("listing_id");

        PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilPage.clickContinue();
        PublicSiteThankYouPage publicSiteThankYouPage = publicSiteBankAccountInfoPage.clickFinish();
        // User navigate to Thank you Page and clicked on go to my account button
        LOG.info("User navigate to Thank you  Page");
        publicSiteThankYouPage.clickGoToMyAccountPage();

        accountOverviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        accountOverviewPage.waitForAccountOverviewPageToLoad();
        accountOverviewPage.dismissCongratulationWelcomeModal();

        Assert.assertNotNull(accountOverviewPage.getListingInfo().get("LISTING ID"));
        LOG.info("New Listing for Withdrawn Listing User :" + newListing);

        LOG.info("~~~~~~testListingForExistingUserViaSignInPage-- PASSED~~~~~~~~~~~~~~~");
    }

    @BeforeMethod
    void testCreatePendingActivationListing() throws AutomationException {
        // Pre-requisite for existing user new listing flow
        withdrawUserListing(getUserForEnvironment("testListingForExistingUserViaSignInPage"));
    }

}
