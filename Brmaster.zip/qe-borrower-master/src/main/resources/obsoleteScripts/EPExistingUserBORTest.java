
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.sql.SQLException;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * BMP-448 Verify that decline is displayed to existing user with loan eligible for NP offers
 *
 * @author hisharma
 *
 */
public class EPExistingUserBORTest extends DXCompleteListingTestBase {

    protected static String environment;

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    @DataProvider(name = "npaaUserTest")
    public static Object[][] userDetails() {
        environment = System.getProperty("environment");
        if ("staging2".equalsIgnoreCase(environment)) {
            return new Object[][] {Xls_Reader.readExcelData(
                    "userRegistrationData.xlsx", "NPAAExistingUserDetails",
                    "npOffersExistingUser_stg2")};
        } else {
            return new Object[][] {Xls_Reader.readExcelData(
                    "userRegistrationData.xlsx", "NPAAExistingUserDetails",
                    "npOffersExistingUser_qa32")};
        }
    }

    @Test(dataProvider = "npaaUserTest", groups = {TestGroup.ACCEPTANCE}, enabled = false)
    public void verifyExistingEPUserDecline(String adverseAction,
                                            String emailAddress, String password, String loanAmount,
                                            String loanPurpose, String creditQuality, String firstName,
                                            String lastName) throws SQLException, NumberFormatException,
            AutomationException {

        logger.info("Test method : verifyExistingEPUserDecline()");

        // Submit Home page
        final PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage.checkYourRate();

        // reset Adverse action event date to avoid 120 decline
        final UserEmailDAO userInfo = circleOneDBConnection
                .getDataAccessObject(UserEmailDAO.class);
        final String userID = userInfo.getUserIDByEmail(emailAddress);
        final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection
                .getDataAccessObject(LoanOfferDeclineDAO.class);
        loanOfferDeclineInfo.updateCreatedDate(userID);
        final AdverseActionEventDAO adverseActionEventInfo = adverseActionEventDBConnection
                .getDataAccessObject(AdverseActionEventDAO.class);
        adverseActionEventInfo.updateAdverseActionEventDate(userID);

        registrationPage.enterEmailAddress(emailAddress);

        // login modal displayed
        Assert.assertTrue(registrationPage.getLoginModalAsElement().isDisplayed());
        // User entered the common Password: "Password23"
        registrationPage
                .enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
        registrationPage.clickOnSignInToContinue();
        // user navigate to pre-filled reg page
        registrationPage.clickElectronicSignatureCheckBox();

        // Verify that decline is displayed with correct contents
        final PublicSiteOfferPage publicSiteOfferPage = registrationPage
                .clickGetYourRate(false, false);

        Assert.assertNotNull(publicSiteOfferPage);
        if (publicSiteOfferPage.isDeclinePageAppears()) {
            final PublicSiteDeclinePage publicSiteDeclinePage = publicSiteOfferPage.goToDeclinePage();

            Assert.assertTrue(publicSiteDeclinePage.getDeclinePageContentAsElement().getText()
                    .contains("We've partnered with AmOne to provide you with additional options."));
        }
    }

}
