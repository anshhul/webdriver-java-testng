
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author hnegi 14-Jul-2016
 *
 */

public class OfferSliderPayOffBarVerification extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(OfferSliderPayOffBarVerification.class.getSimpleName());
    @Resource
    private PublicSitePreRegistrationPage modernizePreRegistrationPage;


    // Deprecated: Gear-1948
    // GEAR-1327 Verify that prosper 3 year to payoff bar displays correct amount
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testThreeYearPayOffBar() throws AutomationException, InterruptedException {
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                modernizePreRegistrationPage.checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email_dts = TestDataProviderUtil.getUniqueEmailIdForTest("WvAuto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), Double.toString(LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email_dts, Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
            publicSiteOfferPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        }

        final String threeYearPayOffAmount = publicSiteOfferPage.getThreeYearPayOffAmount();

        publicSiteOfferPage.openOfferUrlInNewTab();
        final PublicSitePersonalDetailPage publicSitePersonalDetailPage = publicSiteOfferPage.clickOnGetThisLoanButtonForThreeYears();
        publicSitePersonalDetailPage.fillPersonalDetailPage(
                getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = publicSitePersonalDetailPage.clickContinue();
        final String threeYearPayOffAmountOnTILAPage = tilPage.getTotalOfPaymentFromTILAContent();

        Assert.assertEquals(threeYearPayOffAmount, threeYearPayOffAmountOnTILAPage);
        LOG.info("GEAR-1327 Verify that prosper 3 year to payoff bar displays correct amount");
    }

    // GEAR-1297 Verify that prosper 5 year to payoff bar displays correct amount
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testFiveYearPayOffBar() throws AutomationException, InterruptedException {
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                modernizePreRegistrationPage.checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email_dts = TestDataProviderUtil.getUniqueEmailIdForTest("WvAuto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), Double.toString(LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email_dts, Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
            publicSiteOfferPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        }

        final String fiveYearPayOffAmount = publicSiteOfferPage.getFiveYearPayOffAmount();

        publicSiteOfferPage.openOfferUrlInNewTab();
        final PublicSitePersonalDetailPage publicSitePersonalDetailPage = publicSiteOfferPage.clickOnGetThisLoanButtonForFiveYears();
        publicSitePersonalDetailPage.fillPersonalDetailPage(
                getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilPage = publicSitePersonalDetailPage.clickContinue();
        final String fiveYearPayOffAmountOnTILAPage = tilPage.getTotalOfPaymentFromTILAContent();

        Assert.assertEquals(fiveYearPayOffAmount, fiveYearPayOffAmountOnTILAPage);
        LOG.info("GEAR-1297 Verify that prosper 5 year to payoff bar displays correct amount");
    }
}

