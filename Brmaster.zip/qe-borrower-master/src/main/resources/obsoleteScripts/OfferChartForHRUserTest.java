
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 08-Jul-2016
 *
 */
public class OfferChartForHRUserTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(OfferChartForHRUserTest.class.getSimpleName());
    private static final String HR_USER_YEARLY_INCOME = "15000";
    private static final Double HR_USER_LOAN_AMOUNT = 5000.0;
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

    // GEAR-1316 Verify that offers at correctly displayed to HR user
    // GEAR-1491 Verify that only 1 offer of 3 year loan term are displayed to HR rating user
    // TODO: Disabled Test data not available
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testOfferForHRUser() throws AutomationException {
        LOG.info("~~~~~~~Executing: testOfferForHRUser~~~~~~~~~~");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("testOfferForHRUser");
        publicSiteRegistrationPage.fillRegistrationForm(
                Constants.RegisterationPageConstants.HR_USER_DARRELL_ZIP_CODE,
                Double.toString(HR_USER_LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email, Constant.COMMON_PASSWORD,
                Constants.RegisterationPageConstants.HR_USER_DARRELL_FIRST_NAME,
                Constants.RegisterationPageConstants.HR_USER_DARRELL_LAST_NAME,
                Constants.RegisterationPageConstants.HR_USER_DARRELL_STREET_NAME,
                Constants.RegisterationPageConstants.HR_USER_DARRELL_CITY_NAME,
                null, getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                HR_USER_YEARLY_INCOME, Constants.RegisterationPageConstants.HR_USER_DARRELL_DATEOFBIRTH);

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed());
        // Assert False for 5 Year loan Term button
        Assert.assertFalse(publicSiteOfferPage.isGetThisLoanButtonForFiveYearsDisplayed());
        Assert.assertFalse(publicSiteOfferPage.isSliderDisplayed());
        LOG.info("GEAR-1316 Verify that offers at correctly displayed to HR user");
        LOG.info("GEAR-1491 Verify that only 1 offer of 3 year loan term are displayed to HR rating user");
    }
}
