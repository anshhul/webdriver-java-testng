
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

public class OfferChartviaManualBankInfoTest extends PartnerLandingPageTestBase {

    private static final Double LOAN_AMOUNT = 8000.0;
    protected static final Logger LOG = Logger.getLogger(OfferChartviaManualBankInfoTest.class.getSimpleName());

    @Autowired
    @Qualifier("originalPreRegistrationPage")
    private PublicSitePreRegistrationPage originalPreRegistrationPage;


    // GEAR-1465 Verify funnel flow from slider chart page
	/**
	 * @deprecated  this method is deprecated as per GEAR-1773 </br>
	 *
	 * @throws AutomationException
	 * @throws InterruptedException
	 */
	@Deprecated
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled=false)
	void testOfferChartviaManualBankInfo() throws AutomationException,
			InterruptedException {
        LOG.info("~~~~~~~Executing: testOfferChartviaManualBankInfo~~~~~~~~~~");
        // Comment Assert as per GEAR-1773
        // Assert.assertTrue(originalPreRegistrationPage.isOldLandingPageDisplayed(), "OLD Landing Page is displayed");
        // LOG.info("Successfully Navigated to Old Registration Page");

        final PublicSiteRegistrationPage publicSiteRegistrationPage = originalPreRegistrationPage
                .checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("WvAuto");
        publicSiteRegistrationPage
                .fillRegistrationForm(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                        Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                        email, Constant.COMMON_PASSWORD,
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                        getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                        getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                        getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
            publicSiteOfferPage
                    .navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        }

        Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed(), "Navigated to Loan Offer Page Chart");
        LOG.info("Successfully Navigated to Loan Offer Slider Chart Page");

        final PublicSitePersonalDetailPage publicSitePersonalDetailPage = publicSiteOfferPage.clickOnGetThisLoanButtonForThreeYears();
        publicSitePersonalDetailPage.fillPersonalDetailPage(
                getCommonTestData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.WORKPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.OCCUPATION_TAG),
                getCommonTestData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));

        final PublicSiteTruthInLendingDisclosurePage tilaPage = publicSitePersonalDetailPage.clickContinue();

        tilaPage.confirmElectronicSignature();
        listingID = tilaPage.getListingIdFromTILAContent();

        final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = tilaPage.clickContinue();
        final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage.submitManualBankOption();
        // User added general Bank details with routing no
        final PublicSiteThankYouPage borrowerThankYouPage = manualBankAccountPage.enterBankInfo(
                getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG),
                "Savings", getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.ACCOUNTNUMBER_TAG),
                getPrimeBorrowerData().get(Constants.BankInfoPage.CONFIRMACCOUNTNUMBER_TAG),
                null);

        // User navigate to Thank you Page and clicked on go to my account
        // button
        LOG.info("User navigate to Thank you  Page");
        borrowerThankYouPage.clickGoToMyAccountPage();
        LOG.info("Borrower with new Offer Chart listing id is:" + listingID);
        LOG.info("GEAR-1465 Verify funnel flow from slider chart page");
    }
}
