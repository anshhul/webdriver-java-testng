
package test.ui.pubsite.borrower.directToSite.gear_647;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;


/**
 * 
 * GEAR-575 Verify that correct offers at correct intervals are displayed on slider to prior borrower eligible for 2nd loan (Paid Loan)
 * 
 * @author hisharma
 *
 */
public class ExistingUsersOfferSliderTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(ExistingUsersOfferSliderTest.class.getSimpleName());
    
    @Resource
    private PublicSitePreRegistrationPage modernizePreRegistrationPage;


    /**
     * GEAR-575 Verify that correct offers at correct intervals are displayed on slider to prior borrower eligible for 2nd loan (Paid Loan)
     * 
     * 
     * @throws AutomationException
     * @throws InterruptedException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
   public void verifyOffersForPaidLoanUser() throws AutomationException, InterruptedException {
    	 LOG.info("~~~~~~~Executing: verifyOffersForPaidLoanUser()~~~~~~~~~~");
    	
    	final PublicSiteRegistrationPage registrationPage =
                modernizePreRegistrationPage.checkYourRate();

    	// Sign in through Sign In modal
    	registrationPage.enterEmailAddress(getUserForEnvironment("verifyOffersForPaidLoanUser"));
    	registrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
    	registrationPage.clickOnSignInToContinue();
    	
    	// Submit pre-populated Register Page
         registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
        
        // Navigate to Old Offers Page
        if (!offerPage.getWindowLocationHref().contains("offers?")) {
        	offerPage.navigateToOldOfferPage(NewOfferPageWithSlider.OLD_OFFER_PAGE.getOfferPageUrlParam());
        }
        
        List<ArrayList<String>> test = offerPage.get3YearsOffersDetails();
        
        // Navigate to Offers Slider Chart Page
        if (!offerPage.getWindowLocationHref().contains("offersSlider?")) {
        	offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
        }
        
        for (int i = 0; i < test.size(); i++) {
        	ArrayList<String> offerRow = test.get(i);
        	
        	 offerPage.clickEditPencilIcon();
        	 offerPage.submitEditLoanAmountOnOfferChart(offerRow.get(0), false, null);
        	 offerPage.waitForLoanOfferPageToLoadCompletely();
             
        	// Verify loan amounts
        	Assert.assertEquals(offerPage.getLoanAmount(), offerRow.get(0));
        	
        	// Verify APR
        	Assert.assertEquals(offerPage.get3YearAPRValueOnOffersChart(), offerRow.get(1));
        	
        	// Verify Interest
        	Assert.assertTrue(offerPage.getFeeBreakdown().contains(offerRow.get(2)));
        	
        	// Verify Monthly Payment
        	Assert.assertEquals(offerPage.getThreeYearFixedMonthlyPaymentAmount(), offerRow.get(3));
        }
        LOG.info("GEAR-575 Verify that correct offers at correct intervals are displayed on slider to prior borrower eligible for 2nd loan (Paid Loan)");
    }

    
    /**
     * GEAR-586 Verify that correct offers at correct intervals are displayed on slider to prior borrower eligible for 2nd loan (Current Loan)
     * 
     * @throws AutomationException
     * @throws InterruptedException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void verifyOffersForCurrentLoanUser() throws AutomationException, InterruptedException {
     	 LOG.info("~~~~~~~Executing: verifyOffersForCurrentLoanUser()~~~~~~~~~~");
     	
     	final PublicSiteRegistrationPage registrationPage =
                 modernizePreRegistrationPage.checkYourRate();

     	// Sign in through Sign In modal
     	registrationPage.enterEmailAddress(getUserForEnvironment("verifyOffersForCurrentLoanUser"));
     	registrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
     	registrationPage.clickOnSignInToContinue();
     	
     	// Submit pre-populated Register Page
          registrationPage.clickElectronicSignatureCheckBox();
         PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);
         
         // Navigate to Old Offers Page
         if (!offerPage.getWindowLocationHref().contains("offers?")) {
         	offerPage.navigateToOldOfferPage(NewOfferPageWithSlider.OLD_OFFER_PAGE.getOfferPageUrlParam());
         }
         
         List<ArrayList<String>> test = offerPage.get3YearsOffersDetails();
         
         // Navigate to Offers Slider Chart Page
         if (!offerPage.getWindowLocationHref().contains("offersSlider?")) {
         	offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
         }
         
         for (int i = 0; i < test.size(); i++) {
         	ArrayList<String> offerRow = test.get(i);
         	
         	 offerPage.clickEditPencilIcon();
         	 offerPage.submitEditLoanAmountOnOfferChart(offerRow.get(0), false, null);
         	 offerPage.waitForLoanOfferPageToLoadCompletely();
              
         	// Verify loan amounts
         	Assert.assertEquals(offerPage.getLoanAmount(), offerRow.get(0));
         	
         	// Verify APR
         	Assert.assertEquals(offerPage.get3YearAPRValueOnOffersChart(), offerRow.get(1));
         	
         	// Verify Interest
         	Assert.assertTrue(offerPage.getFeeBreakdown().contains(offerRow.get(2)));
         	
         	// Verify Monthly Payment
         	Assert.assertEquals(offerPage.getThreeYearFixedMonthlyPaymentAmount(), offerRow.get(3));
         }
         LOG.info("GEAR-586 Verify that correct offers at correct intervals are displayed on slider to prior borrower eligible for 2nd loan (Current Loan)");
     }
    
}

