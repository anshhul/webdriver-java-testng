
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.dao.LoanOfferPageTrackingDOA;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.AccountOverviewPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.ui.WebDriverTestBase;

/**
 * MWEB-428 - Verify that new offers page is load correctly.
 * MWEB-430 - Verify that user is able to complete the listing with selected offer of 3 years
 * MWEB-439 - Verify that 'Get this loan' button displayed for 3 years loan term offer is functional.
 * MWEB-445 - Verify that on clicking edit icon displayed on offers page, loan amount becomes editable.
 * MWEB-446 - Verify that slider is displayed on loan offers page.
 * MWEB-450 - Verify that on clicking edit icon displayed on offers page, offers in background gets blurred.
 * MWEB-451 - Verify that offers for requested loan amount is displayed by default.
 * MWEB-452 - Verify that total 10 offers are offered to the user.
 * MWEB-458 - Verify that offers for both 3 year and 5 years loan term are displayed.
 * MWEB-462 - Verify that edit icon is displayed next to loan amount on offers page.
 * MWEB-463 - Verify that slider is by default set to requested loan amount.
 * MWEB-465 - Verify that 'Get this loan' button is displayed for 3 years loan term offer.
 * MWEB-457 - Verify that on entering invalid detail in edit loan amount text field, error message is displayed
 * MWEB-570 - Verify that on entering no value in edit loan amount text field, error message is displayed
 * MWEB-426 - Verify that 'Get this loan' button is displayed for 5 years loan term offer
 * MWEB-456 - Verify that 'Get this loan' button displayed for 5 years loan term offer is functional
 * MWEB-427 Verify that as we move the slider the values are updated for 3 year loan
 * MWEB-433 Verify that as we move the slider the values are updated for 5 year loan
 * MWEB-434 Verify that correct highest offer amount is displayed at the right end of slider
 * MWEB-437 Verify that correct lowest offer amount is displayed at the left end of slider
 * MWEB-444 Verify that slider on loan offers page is functional
 * MWEB-438 Verify that APR and fixed monthly payment are displayed rounded off upto 2 decimal places.
 * MWEB-453 Verify that offers for 5 years and 3 years changes w.r.t. loan amount when slider is moved.
 * MWEB-459 Verify that offers page is displayed correctly to the user who initially requested for amount greater than loan cap amount
 * MWEB-635 Verify that Slider is corrected to chosen amount on going back to offers page from personal detail
 * MWEB-636 Verify that Slider is corrected to chosen amount on going back to offers page from TIL page
 *
 * @author hnegi
 */
@Deprecated
public class NewLoanOfferPageBorrowerTest extends WebDriverTestBase {

    protected static final Logger LOG = Logger.getLogger(NewLoanOfferPageBorrowerTest.class.getSimpleName());

    @Autowired
    @Qualifier("publicSitePreRegistrationPage")
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

    @Value("${public.site.scheme}")
    protected String publicSiteUrlScheme;
    @Value("${public.site.url}")
    protected String publicSiteUrl;

    @DataProvider(name = "validUserDetails")
    public static Object[][] userDetails() {
        return new Object[][]{Xls_Reader.readExcelData(
                "userRegistrationData.xlsx", "tilaPageDetails",
                "Valid User Details")};
    }

    @Test(dataProvider = "validUserDetails", groups = {TestGroup.NIGHTLY}, enabled = false)
    public void verifyNewLoanOfferPageForThreeYears(String key,
                                                    String loanAmount, String loanPurpose, String creditQuality,
                                                    String firstName, String middleInitial, String suffix,
                                                    String lastName, String homeAddress, String city, String state,
                                                    String zip, String employmentStatus, String yearlyIncome,
                                                    String dob, String emailAddress, String password,
                                                    String primaryPhone, String secondaryPhone, String workPhone,
                                                    String employerName, String employerPhone, String occupation,
                                                    String employmentStartDate, String ssn, String bankName,
                                                    String accountType, String accountHolderName,
                                                    String altAccountHolderName, String routingNumber,
                                                    String accountNumber, String paymentType)
            throws InterruptedException, NumberFormatException,
            AutomationException {


        // Submit Home page
        PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        emailAddress =
                registrationPage.fillRegistrationForm(zip, loanAmount, loanPurpose, emailAddress,
                        MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                        yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // navigate to new loan offer page
        offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_PAGE);
        Assert.assertTrue(offerPage.isLoanOfferPageDisplayed());
        LOG.info("MWEB-428 - Verify that new offers page is load correctly");
        LOG.info("MWEB-451 - Verify that offers for requested loan amount is displayed by default");
        Assert.assertTrue(offerPage.isSliderDisplayed());
        LOG.info("MWEB-446 - Verify that slider is displayed on loan offers page");

        Assert.assertTrue(offerPage.getLoanAmount().replace(",", "")
                .contains(loanAmount));
        LOG.info("MWEB-463 - Verify that slider is by default set to requested loan amount");

        Assert.assertTrue(offerPage.isGetThisLoanButtonForThreeYearsDisplayed());
        LOG.info("MWEB-465 - Verify that 'Get this loan' button is displayed for 3 years loan term offer");

        offerPage.clickEditPencilIcon();

        // Entering any invalid amount in edit loan amount text field
        offerPage.submitEditLoanAmount("$^&*%");
        Assert.assertEquals(offerPage.getEditLoanAmountValidation(),
                MessageBundle.getMessage("editLoanAmountValidationFor35K"));
        LOG.info("MWEB-457 - Verify that on entering invalid detail in edit loan amount text field, error message is displayed");

        // Leaving blank edit loan amount text field
        offerPage.submitEditLoanAmount("");
        Assert.assertEquals(offerPage.getEditLoanAmountValidation(),
                MessageBundle.getMessage("editLoanAmountValidationFor35K"));
        LOG.info("MWEB-570 - Verify that on entering no value in edit loan amount text field, error message is displayed");

        offerPage.submitEditLoanAmount("35000");
        LOG.info("MWEB-445 - Verify that on clicking edit icon displayed on offers page, loan amount becomes editable");
        LOG.info("MWEB-462 - Verify that edit icon is displayed next to loan amount on offers page");
        LOG.info("MWEB-450 - Verify that on clicking edit icon displayed on offers page, offers in background gets blurred");

        Assert.assertEquals(offerPage.getOfferCount(), 10);
        LOG.info("MWEB-452 - Verify that total 10 offers are offered to the user");
        LOG.info("MWEB-458 - Verify that offers for both 3 year and 5 years loan term are displayed");

        PublicSitePersonalDetailPage personalDetailsPage = offerPage
                .clickOnGetThisLoanButtonForThreeYears();

        Assert.assertTrue(personalDetailsPage.isPersonalDetailsPageDisplayed());
        LOG.info("MWEB-439 - Verify that 'Get this loan' button displayed for 3 years loan term offer is functional");

        // Submit Personal Details page
        personalDetailsPage.fillPersonalDetailPage(primaryPhone,
                secondaryPhone, workPhone, employerName, employerPhone,
                occupation, employmentStartDate, ssn);
        PublicSiteTruthInLendingDisclosurePage tilPage = personalDetailsPage
                .clickContinue();

        // Accept agreement and submit Tila page
        tilPage.confirmElectronicSignature();
        PublicSiteBankAccountInfoPage bankInfoPage = tilPage.clickContinue();
        PublicSiteBankAccountInfoPage.Manual manualBankPage = bankInfoPage
                .clickAddBankInfoManually();

        // Submit Bank Information Page
        PublicSiteThankYouPage borrowerThankYouPage = manualBankPage.enterBankInfo(bankName, accountType, accountHolderName,
                altAccountHolderName, routingNumber, accountNumber,
                accountNumber, paymentType);

        // Submit Thank you page
        AccountOverviewPage overviewPage = borrowerThankYouPage.clickGoToMyAccountPage();
        LOG.info("MWEB-430 - Verify that user is able to complete the listing with selected offer of 3 years");
        overviewPage.goTo(String.format(Constant.SCHEME_URL_TEMPLATE, publicSiteUrlScheme, publicSiteUrl + "/myaccount"));
        overviewPage.dismissCongratulationWelcomeModal();
        String listingID1 = overviewPage.getListingInfo().get("LISTING ID");
        Assert.assertNotNull(listingID1, "Account Overview page should be displayed");

        //Verify ListingId variable value
        int listingID = Integer.parseInt(listingID1);
        LoanOfferPageTrackingDOA loanOfferTracking = circleOneDBConnection.getDataAccessObject(LoanOfferPageTrackingDOA.class);
        String offersPageVersion = loanOfferTracking.getOfferSliderPageTracking(listingID);
        LOG.info("Offer Page Version ::" + offersPageVersion);
        Assert.assertEquals(offersPageVersion, "slider");
        //TODO:Add testcase
    }

    @Test(dataProvider = "validUserDetails", groups = {TestGroup.NIGHTLY}, enabled = false)
    public void verifyNewLoanOfferPageForFiveYears(String key,
                                                   String loanAmount, String loanPurpose, String creditQuality,
                                                   String firstName, String middleInitial, String suffix,
                                                   String lastName, String homeAddress, String city, String state,
                                                   String zip, String employmentStatus, String yearlyIncome,
                                                   String dob, String emailAddress, String password,
                                                   String primaryPhone, String secondaryPhone, String workPhone,
                                                   String employerName, String employerPhone, String occupation,
                                                   String employmentStartDate, String ssn, String bankName,
                                                   String accountType, String accountHolderName,
                                                   String altAccountHolderName, String routingNumber,
                                                   String accountNumber, String paymentType)
            throws InterruptedException, AutomationException {


        // Submit Home page
        PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();


        // Submit Register page
        emailAddress =
                registrationPage.fillRegistrationForm(zip, loanAmount, loanPurpose, emailAddress,
                        MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                        yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();

        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        Assert.assertNotNull(offerPage);
        // navigate to new loan offer page
        offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_PAGE);

        Assert.assertTrue(offerPage.getLoanAmount().replace(",", "")
                .contains("10000"));
        LOG.info("MWEB-437 Verify that correct lowest offer amount is displayed at the left end of slider");

        String threeYearLoanAmntBefore = offerPage
                .getThreeYearFixedMonthlyPaymentAmount();
        String fiveYearLoanAmntBefore = offerPage
                .getFiveYearFixedMonthlyPaymentAmount();

        offerPage.moveSlider(50);
        LOG.info("MWEB-444 Verify that slider on loan offers page is functional");

        String threeYearLoanAmntAfter = offerPage
                .getThreeYearFixedMonthlyPaymentAmount();
        String fiveYearLoanAmntAfter = offerPage
                .getFiveYearFixedMonthlyPaymentAmount();

        Assert.assertNotEquals(threeYearLoanAmntBefore, threeYearLoanAmntAfter);
        LOG.info("MWEB-427 Verify that as we move the slider the values are updated for 3 year loan");

        Assert.assertNotEquals(fiveYearLoanAmntBefore, fiveYearLoanAmntAfter);
        LOG.info("MWEB-433 Verify that as we move the slider the values are updated for 5 year loan");
        LOG.info("MWEB-453 Verify that offers for 5 years and 3 years changes w.r.t. loan amount when slider is moved.");

        offerPage.moveSlider(200);
        Assert.assertTrue(offerPage.getLoanAmount().replace(",", "")
                .contains("35000"));
        LOG.info("MWEB-434 Verify that correct highest offer amount is displayed at the right end of slider");

        // Verify Decimal Format
        offerPage.verifyDecimalFormat(offerPage.getThreeYearAPR());
        offerPage.verifyDecimalFormat(offerPage.getFiveYearAPR());
        offerPage.verifyDecimalFormat(offerPage
                .getThreeYearFixedMonthlyPaymentAmount());
        offerPage.verifyDecimalFormat(offerPage
                .getFiveYearFixedMonthlyPaymentAmount());
        LOG.info("MWEB-438 Verify that APR and fixed monthly payment are displayed rounded off upto 2 decimal places.");

        PublicSitePersonalDetailPage personalDetailsPage = offerPage
                .clickOnGetThisLoanButtonForFiveYears();
        Assert.assertTrue(personalDetailsPage.isPersonalDetailsPageDisplayed());
        LOG.info("MWEB-456 - Verify that 'Get this loan' button displayed for 5 years loan term offer is functional");
    }


    @DataProvider(name = "loanCapUserDetails")
    public static Object[][] loanCapUser() {
        return new Object[][]{Xls_Reader.readExcelData("userRegistrationData.xlsx", "tilaPageDetails", "loanCapUser")};
    }


    @Test(dataProvider = "loanCapUserDetails", groups = {TestGroup.NIGHTLY}, enabled = false)
    public void verifyNewLoanOfferPageForLoanCapUSer(String key,
                                                     String loanAmount, String loanPurpose, String creditQuality,
                                                     String firstName, String middleInitial, String suffix,
                                                     String lastName, String homeAddress, String city, String state,
                                                     String zip, String employmentStatus, String yearlyIncome,
                                                     String dob, String emailAddress, String password,
                                                     String primaryPhone, String secondaryPhone, String workPhone,
                                                     String employerName, String employerPhone, String occupation,
                                                     String employmentStartDate, String ssn, String bankName,
                                                     String accountType, String accountHolderName,
                                                     String altAccountHolderName, String routingNumber,
                                                     String accountNumber, String paymentType)
            throws InterruptedException, AutomationException {

        // Submit Home page
        PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        emailAddress =
                registrationPage.fillRegistrationForm(zip, loanAmount, loanPurpose, emailAddress,
                        MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                        yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();

        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // navigate to new loan offer page
        offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_PAGE);

        Assert.assertTrue(offerPage.isGetThisLoanButtonForFiveYearsDisplayed());
        LOG.info("MWEB-426 - Verify that 'Get this loan' button is displayed for 5 years loan term offer");

        Assert.assertNotEquals(offerPage.getLoanAmount(), "35000");
        LOG.info("MWEB-459 Verify that offers page is displayed correctly to the user who initially requested for amount greater than loan cap amount");

        String maxOfferAmount = offerPage.getMaxOfferAmount();

        offerPage.clickEditPencilIcon();
        offerPage.submitEditLoanAmount("35000");
        Assert.assertEquals(offerPage.getEditLoanAmountValidation(),
                MessageBundle.getMessage("editLoanAmountValidation").replace("{maxOfferAmount}", maxOfferAmount));
        LOG.info("MWEB-571 Verify that on entering loan amount greater than user is eligible for in edit loan amount text field, error message is displayed");
    }

    @Test(dataProvider = "validUserDetails", groups = {TestGroup.NIGHTLY}, enabled = false)
    public void verifyNewLoanOfferPageBackAndForthTest(String key,
                                                       String loanAmount, String loanPurpose, String creditQuality,
                                                       String firstName, String middleInitial, String suffix,
                                                       String lastName, String homeAddress, String city, String state,
                                                       String zip, String employmentStatus, String yearlyIncome,
                                                       String dob, String emailAddress, String password,
                                                       String primaryPhone, String secondaryPhone, String workPhone,
                                                       String employerName, String employerPhone, String occupation,
                                                       String employmentStartDate, String ssn, String bankName,
                                                       String accountType, String accountHolderName,
                                                       String altAccountHolderName, String routingNumber,
                                                       String accountNumber, String paymentType)
            throws InterruptedException, AutomationException {

        // Submit Home page
        PublicSiteRegistrationPage registrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        // Submit Register page
        emailAddress =
                registrationPage.fillRegistrationForm(zip, loanAmount, loanPurpose, emailAddress,
                        MessageBundle.getMessage("password"), firstName, lastName, homeAddress, city, state, employmentStatus,
                        yearlyIncome, dob);

        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

        // navigate to new loan offer page
        offerPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_PAGE);

        offerPage.moveSlider(100);

        String loanAmountBefore = offerPage.getLoanAmount();

        PublicSitePersonalDetailPage perosnalDetailsPage = offerPage
                .clickOnGetThisLoanButtonForFiveYears();
        Assert.assertTrue(perosnalDetailsPage.isPersonalDetailsPageDisplayed());

        // Submit Personal Details page
        perosnalDetailsPage.fillPersonalDetailPage(primaryPhone,
                secondaryPhone, workPhone, employerName, employerPhone,
                occupation, employmentStartDate, ssn);
        PublicSiteTruthInLendingDisclosurePage tilPage = perosnalDetailsPage
                .clickContinue();

        // Back to personal details offer page
        tilPage.navigateToBack();

        perosnalDetailsPage.waitForPageToLoad("personal-detail");

        // Back to new loan offer page
        perosnalDetailsPage.navigateToBack();

        String loanAmountAfter = offerPage.getLoanAmount();

        Assert.assertEquals(loanAmountBefore, loanAmountAfter);
        LOG.info("MWEB-635 Verify that Slider is corrected to chosen amount on going back to offers page from personal detail");
        LOG.info("MWEB-636 Verify that Slider is corrected to chosen amount on going back to offers page from TIL page");
    }

}
