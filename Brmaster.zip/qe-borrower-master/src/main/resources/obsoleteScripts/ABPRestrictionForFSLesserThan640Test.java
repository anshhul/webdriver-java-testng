
package test.ui.pubsite.borrower.appByPhone;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage.ABPDeclineOfferPage;
import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 *
 * BMP-446 Credit Score less than 640: Correct "General Restriction" message should be displayed to the (New User/ New Listing)
 * user having Credit Score less than 640.
 *
 * @author jdoriya 16-May-2016
 *
 */
public class ABPRestrictionForFSLesserThan640Test extends DXCompleteListingTestBase {

    private static String ABP_PARTNER_CHANNEL = "Direct Mail";
    protected static final Logger LOG = Logger.getLogger(ABPRestrictionForFSLesserThan640Test.class.getSimpleName());


    // BOR-6736 Credit Score less than 640:Correct "General Restriction" message should be displayed to the (New User/ New
    // Listing) user having Credit Score less than 640.
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testRestrictionForFSLesserThan640() throws AutomationException {
        LOG.info("~~~~~~~~Executing: testRestrictionForFSLesserThan640~~~~~~~~~~~~~~~~~");
        // login to support site
        final ApplicationContext jobContext =
                new ClassPathXmlApplicationContext("support_site/spring/support_site_landing_page.xml");

        final SupportSiteLandingPage supportSiteLandingPage =
                (SupportSiteLandingPage) jobContext.getBean("supportSiteLandingPage");

        supportSiteLandingPage.enterEmailAddress();
        supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
        final SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
        // navigate to home page and select default abp partner as direct mail
        supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
        final String email = TestDataProviderUtil.getGloballyUniqueEmailDomain("testRestrictionForFSLesserThan640", "p2pcredit");
        LOG.info("ABP prime borrower credit score less than 640 email is" + email);
        supportSiteMainPage.enterEmailAddress(email);
        // click on start application button
        final ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
        // navigate to ABP Registration Page
        abpRegistrationPage
                .enterFirstName(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG));
        LOG.info("CSA user entered the firstname of prime borrower credit score less than 640");
        abpRegistrationPage
                .enterLastName(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG));
        LOG.info("CSA user entered the lastname of prime borrower credit score less than 640");
        abpRegistrationPage.enterMiddleName("L");
        LOG.info("CSA user entered the middle name of  prime borrower credit score less than 640");
        abpRegistrationPage.selectSuffix("Jr.");
        LOG.info("CSA user entered the streetname of prime borrower credit score less than 640");
        abpRegistrationPage
                .enterHomeAddress(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG));
        abpRegistrationPage.enterCity(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG));
        LOG.info("CSA user entered the cityname of prime borrower credit score less than 640");
        abpRegistrationPage.selectState(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG));
        LOG.info("CSA user select the state of borrower");
        abpRegistrationPage
                .enterZipCode(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG));
        LOG.info("CSA user entered the zipcode of prime borrower credit score less than 640");
        // User enter the employment status as Employed
        abpRegistrationPage.selectEmploymentStatus(
                getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
        LOG.info("CSA user select employment status of prime borrower credit score less than 640");

        // User enter the Yearly Income
        abpRegistrationPage
                .enterYearlyIncome(
                        getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
        LOG.info("CSA user entered the yearlyincome of prime borrower credit score less than 640");
        // User enter the Date of Birth >18 years
        abpRegistrationPage
                .enterDateOfBirth(getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        LOG.info("CSA user entered the dateofbirth prime borrower credit score less than 640");
        // select all disclosures agreements
        abpRegistrationPage.clickOnDisclosures();
        LOG.info("CSA user agreed to disclosures for prime borrower credit score less than 640");
        abpRegistrationPage.enterHomePhone(getLowFicoLessThan640BorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
        abpRegistrationPage
                .enterSecondaryPhone(getLowFicoLessThan640BorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));

        abpRegistrationPage.enterLoanAmount(getLowFicoLessThan640BorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
        LOG.info("CSA user entered the loanamount for borrower");
        abpRegistrationPage
                .selectLoanPurposer(getLowFicoLessThan640BorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
        LOG.info("CSA user select loan purpose for borrower");
        final ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
        abpRegistrationPage.handleSSNPage(getLowFicoLessThan640BorrowerData().get(Constants.PersonalDetailPage.SSN_TAG));
        final ABPDeclineOfferPage abpDeclineOfferPage = abpOfferPage.goToDeclinePage();
        Assert.assertTrue(abpDeclineOfferPage.getDeclineContentAsElement().getText()
                .contains(Constants.VALIDATIONS.ABP_DECLINE_MESSAGE));
        LOG.info(
                "BOR-6736 Credit Score less than 640:Correct \"General Restriction\" message should be displayed to the (New User/ New Listing) user having Credit Score less than 640.");
        LOG.info("~~~~~~~~~~~testRestrictionForFSLesserThan640--PASSED~~~~~~~~~~~~~~~~~~~~");
    }
}
