// package test.ui.pubsite.borrower.directToSite.primeAA;
//
// import org.apache.log4j.Logger;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.context.ApplicationContext;
// import org.springframework.context.support.ClassPathXmlApplicationContext;
// import org.testng.Assert;
// import org.testng.annotations.Test;
//
// import com.prosper.automation.constant.Constant;
// import com.prosper.automation.constant.test.TestGroup;
// import com.prosper.automation.constant.web.Constants;
// import com.prosper.automation.constant.web.MessageBundle;
// import com.prosper.automation.db.dao.AdverseActionEventDAO;
// import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
// import com.prosper.automation.db.dao.UserEmailDAO;
// import com.prosper.automation.exception.AutomationException;
// import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
// import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
// import com.prosper.automation.pubsite.enumeration.HeaderOptions;
// import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
// import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
// import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
// import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
// import com.prosper.automation.pubsite.pages.borrower.PublicSiteSignInPage;
// import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
// import com.prosper.automation.supportsite.pages.SupportSiteLandingPage;
// import com.prosper.automation.supportsite.pages.SupportSiteMainPage;
// import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage;
// import com.prosper.automation.supportsite.pages.appliedbyphone.ABPOfferPage.ABPDeclineOfferPage;
// import com.prosper.automation.supportsite.pages.appliedbyphone.ABPRegistrationPage;
//
// import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;
//
/// **
// * @author ntaneja BMP-4283:ABP: Verify that decline is displayed to user having
// * DTI>50%
// */
// public class HighDTIAAByABP extends PartnerLandingPageTestBase {
//
// private static String ABP_PARTNER_CHANNEL = "Direct Mail";
// private static String messageId;
// protected static final Logger LOG = Logger.getLogger(HighDTIAAByABP.class.getSimpleName());
//
// @Autowired
// OutlookWebAppLoginPage outlookQAWebAppPage;
//
// @Test(groups = { TestGroup.NIGHTLY })
// void testHighDTIbyABP() throws AutomationException {
// LOG.info("~~~~~~~Executing: testHighDTIbyABP~~~~~~~~~~~~~~");
//
// final ApplicationContext jobContext = new ClassPathXmlApplicationContext(
// "support_site/spring/support_site_landing_page.xml");
//
// SupportSiteLandingPage supportSiteLandingPage = (SupportSiteLandingPage) jobContext
// .getBean("supportSiteLandingPage");
// String email = "mvLy2oGXjVxG_7e8dd1624177723@c1.dev";
// supportSiteLandingPage.enterEmailAddress();
// supportSiteLandingPage.enterPassword(Constant.COMMON_PASSWORD);
// SupportSiteMainPage supportSiteMainPage = supportSiteLandingPage.clickLogin();
//
// supportSiteMainPage.selectABPPartner(ABP_PARTNER_CHANNEL);
// LOG.info("ABP User email is " + email);
// supportSiteMainPage.enterEmailAddress(email);
//
// LOG.info("ABP User email is: " + email);
// supportSiteMainPage.enterEmailAddress(email);
// // click on start application button
// ABPRegistrationPage abpRegistrationPage = supportSiteMainPage.clickOnStartApplication();
//
// // navigate to ABP Registration Page
// abpRegistrationPage.enterLoanAmount(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANAMOUNT_TAG));
// LOG.info("CSA user entered the loanamount for borrower");
//
// abpRegistrationPage.selectLoanPurposer(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));
// LOG.info("CSA user select loan purpose for borrower");
//
// // Enter Phone details
// abpRegistrationPage.enterHomePhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
// abpRegistrationPage
// .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.MOBILEPHONE_TAG));
// String firstName = abpRegistrationPage.getFirstName();
// // select all disclosures agreements
// abpRegistrationPage.clickOnDisclosures();
// LOG.info("CSA user agreed to disclosures for borrower");
//
// ABPOfferPage abpOfferPage = abpRegistrationPage.clickGetYourRate();
// Assert.assertTrue(abpOfferPage.isDelclinePageDisplayed(), "Decline should be displayed");
// final ABPDeclineOfferPage abpDeclineOfferPage = abpOfferPage.goToDeclinePage();
//
// ///// Go to Public Site Page
//
// ApplicationContext jobContext1 = new ClassPathXmlApplicationContext(
// "public_site/spring/public_site_context.xml");
// PublicSitePreRegistrationPage publicSitePreRegistrationPage = (PublicSitePreRegistrationPage) jobContext1
// .getBean("publicSitePreRegistrationPage");
//
// Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());
//
// PublicSiteSignInPage publicSiteSignInPage = publicSitePreRegistrationPage.clickOnSignIn();
//
// publicSiteSignInPage.enterUserEmail(email);
// publicSiteSignInPage.enterUserPassword("P@ssword23");
// publicSiteSignInPage.clickContinue();
//
// publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());
//
// // Navigate to Messages Page
// publicSitePreRegistrationPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.MESSAGES.getValue());
// final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();
// // check url response for 503 or 400 bad request
// messagesPage.waitForPageToLoad("messages.aspx");
// if (!messagesPage.isLinkActive(messagesPage.getWindowLocationHref())) {
// messagesPage.reload();
// }
// // Verify message and navigate to View Messages Page
// final ViewMessagePage viewmessagesPage = messagesPage
// .verifyAndClickMessage(Constants.MessagesPage.UNABLE_TO_APPLY);
//
// messageId = viewmessagesPage.getMessageIdFromURL();
//
// // Verify message content
// viewmessagesPage.verifyMessageContent(firstName, MessageBundle.getMessage("debtIsTooLarge"));
//
// // To check HTML tags. Refer ticket BMP-2652
// Assert.assertFalse(viewmessagesPage.messageContains("<"));
//
// // Navigate to History Page
// viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
//
// // Navigate to 'Event History' Page
// final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
// final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();
//
// // Verify that appropriate events are displayed on the 'Event History'
// // page
// eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
// Constants.EventHistorypage.CREDIT_SCORE_UNAVAILABLE_EVENT_NAME);
// eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
// Constants.EventHistorypage.AALETTERDETAILS);
//
// // Click on 'Adverse Action Letter' link displayed within event details
// // and verify Agreement Page content
// eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
// // switched to newly opened window
// eventHistoryPage.switchToNewlyOpenedWindow();
// Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
// .contains(MessageBundle.getMessage("debtIsTooLarge")));
// eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);
//
// // Navigate to History Page
// eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
// final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();
//
// // Verify Agreement page content and get AgreementID from URL for
// // further use
// final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(
// MessageBundle.getMessage("AALetter"), MessageBundle.getMessage("debtIsTooLarge"));
//
// // Get user id
// final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
// final String userId = userEmail.getUserIDByEmail(emailAddress);
//
// // Verify the values displayed in table AdverseActionEvent
// final AdverseActionEventDAO adverseActionEventInfo = circleOneDBConnection
// .getDataAccessObject(AdverseActionEventDAO.class);
//
// Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(emailAddress),
// AdverseActionTemplate.NONMORTGAGE_PAYMENT_TOOHIGH_TU.getAdverseActionEventTypeID());
//
// // Get 'AdverseActionEventID' from the query result
// final String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(emailAddress);
// Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
// "messagesent data should not be null");
//
// // Verify the values displayed in MessageSent tabl
// Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));
//
// Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));
//
// // Verify the values displayed in AdverseActionEventSquareCutInfo table
//
// Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
// SquareCutTemplate.NONMORTGAGE_PAYMENT_TOOHIGH.getSquareCutTypeID());
//
// // Verify the values displayed in tblloanofferdecline table
// final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection
// .getDataAccessObject(LoanOfferDeclineDAO.class);
//
// Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
// DeclineReasonTemplate.NONMORTGAGE_PAYMENT_TOOHIGH.getDeclineReasonID());
//
// // Note: Message is not triggered
// // instantly(https://saucelabs.com/beta/tests/b5354c6442a04e2da6f741b355e924b1/watch),
// // hence assert webmail box before validation of AA letter and message
// // section
// // Verify An email notification "Information about your loan request"
// // should be triggered to user in his personal email
// // inbox
// verifyWebMail(outlookQAWebAppPage, "QA", emailAddress, firstName,
// MessageBundle.getMessage("infoAboutLoanRequest"), MessageBundle.getMessage("notEligibleForLoan"));
// LOG.info("**** Passed ****");
//
// LOG.info(
// "~~~~~~~~~~~~~~~~~~~~~BMP-4283:ABP: Verify that decline is displayed to user having
// DTI>50%~~~~~~~~~~~~~~~~~~~~~~~~~~PASSED~~~~~~~~~~~~~~~~~~~");
//
// }
//
// }
