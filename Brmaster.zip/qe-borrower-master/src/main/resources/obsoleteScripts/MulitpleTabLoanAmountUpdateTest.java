
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Defect vs Test Automation
 *
 * @author jdoriya 08-Aug-2016
 *
 */
public class MulitpleTabLoanAmountUpdateTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(LoanOfferTableValidationTest.class.getSimpleName());
    private static final int MOVE_LOAN_AMOUNT_SLIDER = 0;
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // GEAR-1741 Loan amount not updated in previous offer tab after changing loan amount in new tab
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testMulitpleTabLoanAmountUpdate() throws AutomationException, InterruptedException {
        LOG.info("~~~~~~~ Executing: testMulitpleTabLoanAmountUpdate ~~~~~~~~~~");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        final PublicSiteRegistrationPage modernizeRegistrationPage = publicSitePreRegistrationPage.checkYourRate();
        modernizeRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);
        modernizeRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        modernizeRegistrationPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage offerPage = modernizeRegistrationPage.clickGetYourRate(false, false);

        final String offerPageUrl = offerPage.getWindowLocationHref();
        // Click on Prosper logo and open in another tab and switch control to
        // it
        offerPage.openCurrentUrlIntoNewTab(offerPageUrl);
        offerPage.waitForLoanOfferPageToLoadCompletely();
        final PublicSitePreRegistrationPage publicSitePreRegistrationAgainPage = offerPage.clickOnProsperLogo();
        // Submit Home Page
        final PublicSiteRegistrationPage publicSiteRegistrationAgainPage = publicSitePreRegistrationAgainPage.checkYourRate();
        publicSiteRegistrationAgainPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);
        if (publicSiteRegistrationAgainPage.getNumberOfPanes() > 0) {
            publicSiteRegistrationAgainPage.enterLoanAmount("10000");
        }
        publicSiteRegistrationAgainPage.clickElectronicSignatureCheckBox();

        final PublicSiteOfferPage publicSiteOfferSecondPage = publicSiteRegistrationAgainPage.clickGetYourRate(false, false);

        // Switch back to first tab and submit Offer Chart page
        publicSiteOfferSecondPage.moveToNextTab();

        final String initialLoanAmount = offerPage.getLoanAmount();

        offerPage.moveSlider(MOVE_LOAN_AMOUNT_SLIDER + 100);
        final String afterSliderMoveLoanAmount = offerPage.getLoanAmount();
        Assert.assertTrue(!afterSliderMoveLoanAmount.equalsIgnoreCase(initialLoanAmount));
        final PublicSitePersonalDetailPage publicSitePersonalDetailPage =offerPage.clickOnGetThisLoanButtonForThreeYears();
        Assert.assertNotNull(publicSitePersonalDetailPage);

        LOG.info("GEAR-1741 Loan amount not updated in previous offer tab after changing loan amount in new tab");
    }

}
