
package test.ui.pubsite.borrower.coBrandingPages.unitedmileageplus;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerAccountInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteBankAccountInfoPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteThankYouPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteTruthInLendingDisclosurePage;
import com.prosper.automation.util.TimeUtilities;
import com.prosper.automation.util.URLUtilities;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;
/**
 * Verify listing creationg and QP pricing for united mileage plus
 *
 * @author jdoriya
 */
public class UnitedMileagePlusUserListingCreationTest extends PartnerLandingPageTestBase {

    private static final Double LOAN_AMOUNT = 4000.0;
    // limited test data for testing united mileageplus page
    private static final String LAST_NAME = "Fellows";
    private static final String FIRST_NAME = "Casimir";
    private static final String ZIP_CODE = "20818";
    private static final String MILEAGE_PLUS_NUMBER = "NL505609";
    protected static final Logger LOG = Logger.getLogger(UnitedMileagePlusUserListingCreationTest.class.getSimpleName());


    // BMP-371
    @Deprecated
    @BeforeClass
    void createListingViaUnitedMileagePlus() throws AutomationException {

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(getUnitedMileagePlusURI().get("URL")),
                URLUtilities.getStringURLWithoutScheme(getUnitedMileagePlusURI().get("URL")))) {
            partnerLandingPage.setPageElements(pageElements);
            // enter the loan amount = $4000.0
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);
            // select loanpurose
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));

            // click on check your rate button
            PartnerAccountInformationPage partnerAccountInformationPage = partnerLandingPage.CheckYouRate();

            // verify mileageplust account information header
            Assert.assertEquals(partnerAccountInformationPage.getPartnerAccountInfoHeader().getText(),
                    Constants.PartnerAccountInformationPage.MILEAGEPLUSACCOUNTINFORMATIONHEADER);
            // enter the lastname of user
            partnerAccountInformationPage.enterLastName(LAST_NAME);
            // enter the zip code
            partnerAccountInformationPage.enterZipCode(ZIP_CODE);
            // enter the mileageplus no
            partnerAccountInformationPage.enterMileagePlusNumber(MILEAGE_PLUS_NUMBER);

            PublicSiteRegistrationPage publicSiteRegistrationPage = partnerAccountInformationPage
                    .ClickOnCheckYouRate();
            // wait for Registration Page to Load
            Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());
            refAc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_ac").toString();
            LOG.info("RefAc value is:" + refAc);
            refMc = getQueryMap(publicSiteRegistrationPage.getCurrentURL()).get("ref_mc").toString();
            LOG.info("RefMc value is:" + refMc);
            // verify pre-filled registraion page
            Assert.assertTrue(publicSiteRegistrationPage.verifyPrefilledLastName(LAST_NAME),
                    "lastname of user is not correct on Registration Page");
            Assert.assertTrue(publicSiteRegistrationPage.verifyPrefilledFirstName(FIRST_NAME),
                    "firstname of user is not correct on Registration Page");
            Assert.assertTrue(publicSiteRegistrationPage.verifyPrefilledZip(ZIP_CODE),
                    "zip code is not correct on Registration Page");

            // complete the funnel and create a listing for user
            publicSiteRegistrationPage.selectEmploymentStatus(
                    getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG));
            // User enter the Yearly Income
            publicSiteRegistrationPage
                    .enterYearlyIncome(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG));
            // User enter the Date of Birth >18 years
            publicSiteRegistrationPage
                    .enterDateOfBirth(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
            // Generate Random email for borrower
            emailAddress = Constant.getGloballyUniqueEmail(true);
            // User entered the random email address
            publicSiteRegistrationPage.enterEmailAddress(emailAddress);
            LOG.info("User email addresss is:" + emailAddress);
            // User entered the common Password: "Password23"
            publicSiteRegistrationPage.enterPassword(Constant.COMMON_PASSWORD);
            // User accept the agreement on Reg Page
            publicSiteRegistrationPage.clickElectronicSignatureCheckBox();

            // User clicked on get your rate button
            final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
            LOG.info("User navigate to Loan Offer Page");
            // User navigate to Personald detail page
            final PublicSitePersonalDetailPage personalDetailPage = publicSiteOfferPage.clickGetLoan();
            LOG.info("User navigate to Personal detail Page");
            // Submit the general personal details
            personalDetailPage
                    .enterPrimaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.HOMEPHONE_TAG));
            personalDetailPage
                    .enterSecondaryPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.SECONDARYPHONE_TAG));
            personalDetailPage.enterWorkPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.WORKPHONE_TAG));
            personalDetailPage
                    .enterEmployerName(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERNAME_TAG));
            personalDetailPage
                    .enterEmployerPhone(getPrimeBorrowerData().get(Constants.PersonalDetailPage.EMPLOYERPHONE_TAG));
            personalDetailPage
                    .selectOccupation(getPrimeBorrowerData().get(Constants.PersonalDetailPage.OCCUPATION_TAG));
            personalDetailPage.enterStartOfEmployment(
                    getPrimeBorrowerData().get(Constants.PersonalDetailPage.STARTEMPLOYMENTDATE_TAG));
            // User entered the SSN of Borrower coming with Offercode
            personalDetailPage
                    .enterSocialSecurityNumber(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.SSN_TAG));
            // User navigateed to TIL Page
            final PublicSiteTruthInLendingDisclosurePage publicSiteTILAPage = personalDetailPage.clickContinue();
            LOG.info("User navigate to TIL Page");
            listingID = getQueryMap(publicSiteTILAPage.getListingIdFromTILAContent()).get("listing_id");
            publicSiteTILAPage.confirmElectronicSignature();
            // User navigated to bank info page
            final PublicSiteBankAccountInfoPage publicSiteBankAccountInfoPage = publicSiteTILAPage.clickContinue();
            // User select the Manual Bank options
            LOG.info("User navigate to Bank Info Page");
            final PublicSiteBankAccountInfoPage.Manual manualBankAccountPage = publicSiteBankAccountInfoPage
                    .clickAddBankInfoManually();
            // User added general Bank details with routing no
            manualBankAccountPage.enterBankName(getPrimeBorrowerData().get(Constants.BankInfoPage.BANKNAME_TAG));
            manualBankAccountPage.enterAlternateAccountHolderName(
                    getPrimeBorrowerData().get(Constants.BankInfoPage.ALTACCOUNTHOLDERNAME_TAG));
            manualBankAccountPage.enterRoutingNumber(getPrimeBorrowerData().get(Constants.BankInfoPage.ROUTING_TAG));
            final String accountNumber = Constant.getRandomIntegerString(10);
            manualBankAccountPage.enterAccountNumber(accountNumber);
            manualBankAccountPage.enterConfirmAccountNumber(accountNumber);

            final PublicSiteThankYouPage publicSiteThankYouPage = manualBankAccountPage.clickAddBank();
            // User navigate to Thank you Page and clicked on go to my account
            // button
            LOG.info("User navigate to Thank you  Page");
            publicSiteThankYouPage.clickGoToMyAccountPage();

            // verify the tblLoanofferScore for pricing
            List<Map<String, Object>> loanOfferScoreDetails =
                    queryCircleOne(MessageBundle.getMessage("pricingVerificationQuery").replace("{listingID}",
                            listingID));
            // verify qp reduce pricing as BestQPSegment|1| corresponding to variableID(73)
            Assert.assertFalse(loanOfferScoreDetails.get(1).get("Value").toString().contains("||"),
                    "Pipes should not be displayed for the VALID Offer Code --- Standard Pricing displayed to invalid/blank offer code user");
        }
    }
    @Test(groups = {TestGroup.SANITY})
    void testListingCreationForUnitedMileagePlus() throws AutomationException {

        LOG.info("Executing: testListingCreationForUnitedMileagePlus");
    }

    @Test(groups = {TestGroup.ACCEPTANCE}, dataProvider = UNITEDMILEAGEPLUS)
    void testProspectRecordsForUnitedUser(String partnerUrl) throws AutomationException {
        LOG.info("Executing: testProspectRecordsForUnitedUser");
        // Prospect records shouldnot be null
        // verify the prospect tbl records
        Map<String, Object> prospectRows = queryProspectDb(
                MessageBundle.getMessage("prospect_query").replace("{emailAddress}", emailAddress)).get(0);
        Assert.assertFalse(prospectRows.isEmpty(), "Prospect is not generated yet");
        LOG.info("Prospect is generated into prospecttbl for prospect user");

        // verify created date of prospect
        Assert.assertTrue(prospectRows.get("CreatedDate").toString()
                        .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");
        // verify prepopeddate of prospect
        Assert.assertTrue(prospectRows.get("PrePopDate").toString()
                        .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'PrePopDate' should be displayed");
        // verify engagementdate of prospect
        Assert.assertTrue(prospectRows.get("EngagementDate").toString()
                        .contains(TimeUtilities.getCurrentTimeInFormat("yyyy-MM-dd", "America/Los_Angeles")),
                "Correct 'CreatedDate' should be displayed");

        // verify loanamount associated with prospect of user
        Assert.assertEquals(prospectRows.get("LoanAmount").toString().replaceAll("\\..*", ""),
                String.valueOf(LOAN_AMOUNT).replaceAll("\\..*", ""));
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    void testRefAcForUnitedUser() throws AutomationException, MalformedURLException {
        LOG.info("Executing: testRefAcForUnitedUser");
        // verify RefAC record in prospect tbl
        Assert.assertTrue(queryProspectDb(MessageBundle.getMessage("refacNrefmc").replace("{emailAddress}", emailAddress))
                .get(0).get("RefAC").toString().contains(refAc));
    }

    @Test(groups = {TestGroup.ACCEPTANCE})
    void testRefmcForUnitedUser() throws AutomationException, MalformedURLException {
        LOG.info("Executing: testRefmcForUnitedUser");
        // verify RefAC record in prospect tbl
        Assert.assertTrue(queryProspectDb(MessageBundle.getMessage("refacNrefmc").replace("{emailAddress}", emailAddress))
                .get(0).get("RefMC").toString().contains(refMc));
    }

}
