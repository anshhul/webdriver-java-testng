
package test.ui.pubsite.borrower.coBrandingPages.unitedmileageplus;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerAccountInformationPage;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import com.prosper.automation.util.URLUtilities;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * Verify Validation of Membership with invalid MPN on Member's account information page
 *
 * @author jdoriya
 */
public class UnitedMileagePlusMemberShipValidationTest extends PartnerLandingPageTestBase {

    private static final Double LOAN_AMOUNT = 4000.0;
    // limited test data for testing united mileageplus page
    private static final String LAST_NAME = "Fellows";
    private static final String ZIP_CODE = "20818";
    protected static final Logger LOG = Logger.getLogger(UnitedMileagePlusMemberShipValidationTest.class.getSimpleName());


    // United Non-DM : Verify that validation should be displayed on submitting United Membership Page page with invalid Rewards /
    // Mileage Number
    // BMP-371
    @Deprecated
    @Test(groups = {TestGroup.SANITY}, dataProvider = UNITEDMILEAGEPLUS)
    void testMemberShipValidationModalOnInvalidMPN(String partnerUrl) throws AutomationException {

        LOG.info("Executing: testMemberShipValidationModalOnInvalidMPN");

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(partnerUrl), URLUtilities.getStringURLWithoutScheme(partnerUrl))) {
            partnerLandingPage.setPageElements(pageElements);
            Assert.assertTrue(partnerLandingPage.isAjaxSpinnerDismiss());
            // enter the loan amount = $4000.0
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);

            // select loanpurose
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));

            // click on check your rate button
            PartnerAccountInformationPage partnerAccountInformationPage = partnerLandingPage.CheckYouRate();

            // verify mileageplust account information header
            Assert.assertEquals(partnerAccountInformationPage.getPartnerAccountInfoHeader().getText(),
                    Constants.PartnerAccountInformationPage.MILEAGEPLUSACCOUNTINFORMATIONHEADER);
            // enter the lastname of user
            partnerAccountInformationPage.enterLastName(LAST_NAME);
            // enter the zip code
            partnerAccountInformationPage.enterZipCode(ZIP_CODE);
            // enter the invalid mileageplus no
            partnerAccountInformationPage.enterMileagePlusNumber(Constants.PartnerAccountInformationPage.INVALIDMPN);
            partnerAccountInformationPage.ClickOnCheckYouRate();
            // verify Validation Message is displayed with invalid MPN no on Account Information page
            Assert.assertTrue(partnerAccountInformationPage.getMemberShipLoaderAsElement().isDisplayed());
            LOG.info(
                    "United Non-DM : Verify that validation should be displayed on submitting United Membership Page page with invalid Rewards / Mileage Number");
        }
    }

    // United Non-DM : Verify that validation should be displayed on submitting United Membership Page page with Blank Rewards /
    // Mileage Number
    // BMP-371
    @Deprecated
    @Test(groups = {TestGroup.SANITY}, dataProvider = UNITEDMILEAGEPLUS)
    void testMemberShipValidationModalOnBlankMPN(String partnerUrl) throws AutomationException {

        LOG.info("Executing: testMemberShipValidationModalOnBlankMPN");

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                URLUtilities.getScheme(partnerUrl), URLUtilities.getStringURLWithoutScheme(partnerUrl))) {
            partnerLandingPage.setPageElements(pageElements);

            Assert.assertTrue(partnerLandingPage.isAjaxSpinnerDismiss());
            // enter the loan amount = $4000.0
            partnerLandingPage.enterLoanAmount(LOAN_AMOUNT);

            // select loanpurose
            partnerLandingPage.selectLoanPurpose(getPrimeBorrowerData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG));

            // click on check your rate button
            PartnerAccountInformationPage partnerAccountInformationPage = partnerLandingPage.CheckYouRate();

            // verify mileageplust account information header
            Assert.assertEquals(partnerAccountInformationPage.getPartnerAccountInfoHeader().getText(),
                    Constants.PartnerAccountInformationPage.MILEAGEPLUSACCOUNTINFORMATIONHEADER);
            // enter the lastname of user
            partnerAccountInformationPage.enterLastName(LAST_NAME);
            // enter the zip code
            partnerAccountInformationPage.enterZipCode("20819");
            // blank MileagePlus Number
            partnerAccountInformationPage.enterMileagePlusNumber("");
            partnerAccountInformationPage.ClickOnCheckYouRate();
            // verify Validation Message is displayed with invalid MPN no on Account Information page
            Assert.assertTrue(partnerAccountInformationPage.getMemberShipLoaderAsElement().isDisplayed());

            LOG.info(
                    "United Non-DM : Verify that validation should be displayed on submitting United Membership Page page with Blank Rewards / Mileage Number");
        }
    }
}
