
package test.ui.pubsite.borrower.coBrandingPages.unitedmileageplus;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.pages.borrower.PartnerLandingPage;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 *
 * @author jdoriya 23-Jun-2016
 *
 */
public class UnitedMileagePlusEmailLandingPageTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(UnitedMileagePlusEmailLandingPageTest.class.getSimpleName());


    // BMP-1627 Verify that user is navigated to no service page on accessing United Email Landing Page URL
    @Test(groups = {TestGroup.ACCEPTANCE})
    void testNoServiceTemplateForUnitedMileageEmailLandingPage() throws AutomationException, IOException {
        LOG.info("~~~~~~Executing: testNoServiceTemplateForUnitedMileageEmailLandingPage~~~~~~~~");

        try (final PartnerLandingPage partnerLandingPage = new PartnerLandingPage(webDriverConfig,
                publicSiteUrlScheme, publicSiteUrl + UNITED_MILEAGE_PLUS_EMAIL_LANDINGPAGE_URL)) {
            partnerLandingPage.setPageElements(pageElements);

            Assert.assertTrue(partnerLandingPage.getPlpPageHeadingContent()
                    .contains(Constants.PartnerLandingPage.UNITED_MILEAGE_SORRY_HEADING));
            Assert.assertTrue(partnerLandingPage.getPlpPageHeadingContent()
                    .contains(Constants.PartnerLandingPage.UNITED_MILEAGE_SUB_HEADING));
            LOG.info("BMP-1627 Verify that user is navigated to no service page on accessing United Email Landing Page URL");

            Assert.assertTrue(partnerLandingPage.getQuestionsPanelContent()
                    .contains(Constants.PartnerLandingPage.UNITED_MILEAGE_QUESTIONS));

            partnerLandingPage.goBackToYourAccount();
            Assert.assertTrue(partnerLandingPage.isLinkActive("https://www.united.com/web/en-US/apps/account/account.aspx"));
            Assert.assertTrue(partnerLandingPage.getWindowLocationHref()
                    .contains("https://www.united.com/web/en-US/apps/account/account.aspx"));
            LOG.info(
                    "BMP-1629 Verify that user is navigated to correct page on clicking Go Back to Your Account button on no service page");

            LOG.info("~~~~~~testNoServiceTemplateForUnitedMileageEmailLandingPage--PASSED~~~~~~~~");
        }
    }
}
