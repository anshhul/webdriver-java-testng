
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.db.dao.ListingsDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 13-Jul-2016
 *
 */
public class OfferChartForBLenderTest extends PartnerLandingPageTestBase {


    protected static final Logger LOG = Logger.getLogger(OfferChartForBLenderTest.class.getSimpleName());


    // GEAR-1399 Verify that correct offers are displayed to blender
    // TODO: Test data is not available
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testOfferChartForBlender() throws AutomationException {
        LOG.info("~~~~~~~Executing: testOfferChartForBlender~~~~~~~~~~");
        // Pre-requisite for test
        final String priorUserEmail = getUserForEnvironment("testOfferChartForBlender");
        final UserEmailDAO userInfo = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
        final String userId = userInfo.getUserIDByEmail(priorUserEmail);
        // Clean Existing User for new listing creation
        final ListingsDAO listingInfo = circleOneDBConnection.getDataAccessObject(ListingsDAO.class);
        listingInfo.updateListingStatusOfUser(7, Long.valueOf(userId));

        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");
        final PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();
        publicSiteRegistrationPage.enterEmailAddress(priorUserEmail);
        LOG.info("User email addresss is:" + priorUserEmail);
        // login modal displayed
        Assert.assertTrue(publicSiteRegistrationPage.getLoginModalAsElement().isDisplayed());
        publicSiteRegistrationPage.enterPasswordIntoLoginModal(Constant.COMMON_PASSWORD);
        // User accept the agreement on Reg Page
        publicSiteRegistrationPage.clickOnSignInToContinue();
        LOG.info("Existing Borrower Logged-in via Sign-modal");

        publicSiteRegistrationPage.enableOfferPageFlag(NewOfferPageWithSlider.OFFER_SLIDER_FLAG);

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);
        publicSiteRegistrationPage.handleSSNPage(
                getUserForTest("testOfferChartForBlender").get(Constants.RegisterationPageConstants.SSN_TAG));
        Assert.assertTrue(publicSiteOfferPage.isSliderPageDisplayed());

        Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForThreeYearsDisplayed());
        Assert.assertTrue(publicSiteOfferPage.isGetThisLoanButtonForFiveYearsDisplayed());
        LOG.info("GEAR-1399 Verify that correct offers are displayed to blender");
    }
}
