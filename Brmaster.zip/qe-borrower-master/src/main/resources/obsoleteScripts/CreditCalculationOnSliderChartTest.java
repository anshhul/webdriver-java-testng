
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 03-Aug-2016
 *
 */
public class CreditCalculationOnSliderChartTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(CreditCalculationOnSliderChartTest.class.getSimpleName());
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // Deprecated : Gear-1948
    // GEAR-1326 Verify that user is able to see total lifetime cost of his credit card balance as grey bar
    // GEAR-1335 Verify that credit card's grey bar gets affected by changing expected monthly payment & credit card APR
    // GEAR-1328 Verify that \"Edit\" link in credit card section is clickable
    // GEAR-1332 Verify that user is able to edit credit card APR. in credit card section
    // GEAR-1330 Verify that by default, credit card APR is set to 15%
    // GEAR-1329 Verify that by default, expected monthly payment is set to 4% of the user's gross loan amount
    // GEAR-1331 Verify that user is able to edit expected monthly payment in credit card section
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testCreditCardCalculation() throws AutomationException {
        LOG.info("~~~~~~~Executing: testCreditCardCalculation~~~~~~~~~~");

        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("WvAuto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), Double.toString(LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email, Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
            publicSiteOfferPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        }

        publicSiteOfferPage.getLoanAmount();

        Assert.assertTrue(publicSiteOfferPage.isCreditCardEstimationDisplayed());
        LOG.info("GEAR-1326 Verify that user is able to see total lifetime cost of his credit card balance as grey bar");

        final String initialCrediCardInfo = publicSiteOfferPage.getCreditCardEstimation().getText().replaceAll("\\D", "");
        LOG.info(initialCrediCardInfo);

        publicSiteOfferPage.clickEditCreditCardPencil();
        Assert.assertTrue(publicSiteOfferPage.isCreditCardEstimationPopUpDisplayed());
        LOG.info("GEAR-1328 Verify that \"Edit\" link in credit card section is clickable");

        // defect for default Credti Card APR
        // As per comment mentioned in ticket GEAR-1430, Default APR is set to the maximum of the following values
        // 3 year apr * 120% or
        // 5 year apr * 120% or
        // 15%
        final int creditCardAPR =
                (int) Math.max(Double.parseDouble(publicSiteOfferPage.get3YearAPRValueOnOffersChart().replace("%", "")) * 1.2,
                        Math.max(Double.parseDouble(publicSiteOfferPage.get5YearAPRValueOnOffersChart().replace("%", "")) * 1.2,
                                15));
        Assert.assertTrue(publicSiteOfferPage.getCreditCardAPR().getAttribute("value").replaceAll("\\D", "")
                .contains(String.valueOf(creditCardAPR)));

        LOG.info("GEAR-1330 Verify that by default, credit card APR is set to 15%");

        // As per comment mentioned in ticket GEAR-1431, Monthly payment is set by the minimum of the following values
        // 5 year monthly payment or
        // 3 year monthly payment.
        final int monthlyPayment =
                (int) Math.min((double) Math.round(Double
                        .parseDouble(publicSiteOfferPage.get3YearMonthlyPaymentOnOffersChart().replace("$", ""))),
                        (double) Math.round(Double
                                .parseDouble(publicSiteOfferPage.get5YearMonthlyPaymentOnOffersChart().replace("$", ""))));

        Assert.assertTrue(publicSiteOfferPage.getCreditCardExpectedMonthlyPayment().contains(
                String.valueOf(monthlyPayment)));
        LOG.info("GEAR-1329 Verify that by default, expected monthly payment is set to 4% of the user's gross loan amount");

        publicSiteOfferPage.editCreditCardCalculator("17", "109");
        LOG.info("GEAR-1332 Verify that user is able to edit credit card APR. in credit card section");
        LOG.info("GEAR-1331 Verify that user is able to edit expected monthly payment in credit card section");
        final String afterEditCrediCardInfo = publicSiteOfferPage.getCreditCardEstimation().getText().replaceAll("\\D", "");
        LOG.info(afterEditCrediCardInfo);
        Assert.assertTrue(!initialCrediCardInfo.equals(afterEditCrediCardInfo));
        LOG.info(
                "GEAR-1335 Verify that credit card's grey bar gets affected by changing expected monthly payment & credit card APR");
    }

}
