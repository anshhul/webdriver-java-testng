
package test.ui.pubsite.borrower.directToSite.gear_647;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.NewOfferPageWithSlider;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 03-Aug-2016
 *
 */
public class CreditCardEstimationOfferSliderTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(OfferSliderChartPageTest.class.getSimpleName());
    private static final String EXPECTED_CREDIT_CARD_PAYMENT = "$7,149.93";
    @Resource
    private PublicSitePreRegistrationPage publicSitePreRegistrationPage;


    // Deprecated: Gear-1948
    // GEAR-1333 Verify that loan through prosper green bar for 3 & 5 year loan is correctly displayed as compared to credit card
    @Test(groups = {TestGroup.ACCEPTANCE}, enabled = false)
    void testCreditCardEstimation() throws AutomationException {
        LOG.info("~~~~~~~Executing: testCreditCardEstimation()~~~~~~~~~~");

        final PublicSiteRegistrationPage publicSiteRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();

        Assert.assertTrue(publicSiteRegistrationPage.getRegistrationPageHeader());

        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("WvAuto");
        publicSiteRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG), Double.toString(LOAN_AMOUNT),
                getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG),
                email, Constant.COMMON_PASSWORD,
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getCommonTestData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        publicSiteRegistrationPage.clickElectronicSignatureCheckBox();
        final PublicSiteOfferPage publicSiteOfferPage = publicSiteRegistrationPage.clickGetYourRate(false, false);

        if (!publicSiteOfferPage.getWindowLocationHref().contains("offersSlider?")) {
            publicSiteOfferPage.navigateToNewOfferPage(NewOfferPageWithSlider.NEW_OFFER_SLIDER_CHART_PAGE);
            publicSiteOfferPage.waitForLoanOfferPageToLoadCompletely();
        }

        final String threeYearPayOffAmountBefore = publicSiteOfferPage.getThreeYearPayOffAmount();
        final String fiveYearPayOffAmountBefore = publicSiteOfferPage.getFiveYearPayOffAmount();
        final String crediCardInfoBefore = publicSiteOfferPage.getCreditCardEstimation().getText();

        publicSiteOfferPage.clickEditCreditCardPencil();

        // Edit credit card APR as 20% and Expected monthly Payment as 110%
        publicSiteOfferPage.editCreditCardCalculator("20", "160");

        final String threeYearPayOffAmountAfter = publicSiteOfferPage.getThreeYearPayOffAmount();
        final String fiveYearPayOffAmountAfter = publicSiteOfferPage.getFiveYearPayOffAmount();
        final String CrediCardInfoAfter =
                publicSiteOfferPage.getCreditCardEstimation().getText();

        Assert.assertEquals(threeYearPayOffAmountBefore, threeYearPayOffAmountAfter);
        Assert.assertEquals(fiveYearPayOffAmountBefore, fiveYearPayOffAmountAfter);
        Assert.assertNotEquals(crediCardInfoBefore, CrediCardInfoAfter);
        Assert.assertTrue(CrediCardInfoAfter.contains(EXPECTED_CREDIT_CARD_PAYMENT));
        LOG.info(
                "GEAR-1333 Verify that loan through prosper green bar for 3 & 5 year loan is correctly displayed as compared to credit card");
    }
}
