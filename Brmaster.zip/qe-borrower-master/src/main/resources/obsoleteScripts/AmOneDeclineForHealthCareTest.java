
package test.ui.pubsite.borrower.directToSite.gear_1737;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import test.ui.pubsite.borrower.coBrandingPages.PartnerLandingPageTestBase;

/**
 * CLASS / TYPE DESCRIPTION GOES HERE.
 *
 * @author jdoriya 09-Aug-2016
 *
 */
public class AmOneDeclineForHealthCareTest extends PartnerLandingPageTestBase {

    protected static final Logger LOG = Logger.getLogger(AmOneDeclineForHealthCareTest.class.getSimpleName());
    private static final String HEALTH_CARE_LOAN_PURPOSE = "Medical / Dental";


    // GEAR-1745 Verify that selecting 'home improvement' and 'healthcare' loan purpose from old landing page redirects user to
    // amOne decline
    @Test(groups = TestGroup.NIGHTLY)
    void testAmOneDeclineForHCNewRegPage() throws AutomationException {
        LOG.info("testAmOneDeclineForHCNewRegPage");
        String email = TestDataProviderUtil.getUniqueEmailIdForTest("testAmOneDeclineForHCNewRegPage");
        Assert.assertFalse(checkAmOneDeclineOnRegPage(email));
    }

    @Test(groups = TestGroup.NIGHTLY)
    void testAmOneDeclineForHCOriginalPreReg() throws AutomationException {
        LOG.info("testAmOneDeclineForHCOriginalPreReg");
        Assert.assertFalse(checkAmOneDeclineOnOriginalPreReg());
    }

    private boolean checkAmOneDeclineOnOriginalPreReg() throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage originalPreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("originalPreRegistrationPage");
        PublicSiteRegistrationPage publicSiteRegistrationPage = originalPreRegistrationPage.checkYourRate();

        PublicSiteOfferPage offerPage = publicSiteRegistrationPage.clickToGoToOffersPage();

        if (offerPage.isDeclinePageAppears()) {

            PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
            declinePage.scrollIntoView(declinePage.getDeclinePageContentAsElement());
            Assert.assertTrue(declinePage.getDeclinePageContentAsElement().getText().replaceAll("[^\\x00-\\x7f]", "")
                    .contains(MessageBundle.getMessage("amOneDeclineForLoanPurpose_new")));
            LOG.info(
                    "GEAR-1745 Verify that selecting 'home improvement' and 'healthcare' loan purpose from old landing page redirects user to amOne decline");
            return true;
        } else {
            return false;
        }
    }

    private boolean checkAmOneDeclineOnRegPage(String email) throws AutomationException {
        final ApplicationContext jobContext = new ClassPathXmlApplicationContext("public_site/spring/public_site_context.xml");

        PublicSitePreRegistrationPage publicSitePreRegistrationPage =
                (PublicSitePreRegistrationPage) jobContext.getBean("publicSitePreRegistrationPage");
        final PublicSiteRegistrationPage modernizeRegistrationPage =
                publicSitePreRegistrationPage.checkYourRate();
        modernizeRegistrationPage.fillRegistrationForm(
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                Double.toString(LOAN_AMOUNT), HEALTH_CARE_LOAN_PURPOSE, email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));
        // Click to view offers
        modernizeRegistrationPage.clickElectronicSignatureCheckBox();

        modernizeRegistrationPage.clickGetYourRate(false, false);
        PublicSiteOfferPage offerPage = modernizeRegistrationPage.clickToGoToOffersPage();

        // Decline Page content check
        if (offerPage.isDeclinePageAppears()) {
            PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
            Assert.assertTrue(declinePage.getDeclinePageContentAsElement().getText().replaceAll("[^\\x00-\\x7f]", "")
                    .contains(MessageBundle.getMessage("amOneDeclineForLoanPurpose_new")));
            LOG.info(
                    "GEAR-1745 Verify that selecting 'home improvement' and 'healthcare' loan purpose from old landing page redirects user to amOne decline");
            return true;
        } else {
            return false;
        }
    }
}
