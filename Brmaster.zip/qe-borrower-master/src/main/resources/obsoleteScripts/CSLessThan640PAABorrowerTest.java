
package test.ui.pubsite.borrower.directToSite.primeAA;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.constant.web.MessageBundle;
import com.prosper.automation.db.CloseableJdbcConnection;
import com.prosper.automation.db.dao.AdverseActionEventDAO;
import com.prosper.automation.db.dao.LoanOfferDeclineDAO;
import com.prosper.automation.db.dao.UserEmailDAO;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.enumeration.AdverseActionTemplate;
import com.prosper.automation.pubsite.enumeration.DeclineReasonTemplate;
import com.prosper.automation.pubsite.enumeration.HeaderOptions;
import com.prosper.automation.pubsite.enumeration.SquareCutTemplate;
import com.prosper.automation.pubsite.pages.OutlookWebAppLoginPage;
import com.prosper.automation.pubsite.pages.borrower.AccountHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.MessagesPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteEventHistoryPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLegalAgreementsPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage.PublicSiteDeclinePage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.ViewMessagePage;
import com.prosper.automation.util.PollingUtilities;
import com.prosper.automation.util.web.borrower.common.Xls_Reader;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * BOR-10979 Verify that user having credit Score less than 640 gets decline
 *
 * @author hisharma
 */
public class CSLessThan640PAABorrowerTest extends DXCompleteListingTestBase {

	protected static final Logger LOG = Logger.getLogger(CSLessThan640PAABorrowerTest.class.getSimpleName());

	@Autowired
	protected CloseableJdbcConnection adverseActionEventDBConnection;

	@Autowired
	OutlookWebAppLoginPage outlookQAWebAppPage;

	@Resource
	private PublicSitePreRegistrationPage publicSitePreRegistrationPage;

	private static String messageId;



	@DataProvider(name = "csLessThan640")
	public static Object[][] tooFewTradeLinesUserData() {

		return new Object[][] {
			Xls_Reader.readExcelData("borTestData.xlsx", "newUserAATU", "csLessThan640")};

	}

	// Defect GEAR-1619
	@Test(dataProvider="csLessThan640" ,groups = {TestGroup.ACCEPTANCE})
	public void verifyCreditScoreLessThan640Decline(String adverseAction, String loanAmount,
			String loanPurpose, String creditQuality, String firstName, String lastName,
			String homeAddress, String city, String state, String zipCode,
			String employmentStatus, String yearlyIncome, String dob, String emailAddress,
			String password) throws AutomationException {
		LOG.info("Test Method Name - verifyCreditScoreLessThan640Decline()");

		// Submit Home page
		final PublicSiteRegistrationPage registrationPage = publicSitePreRegistrationPage
				.checkYourRate();

		// Submit Register page
		final String email = TestDataProviderUtil.getUniqueEmailIdForTest("verifyTooFewTradeLinesPAA");
		emailAddress = registrationPage.fillRegistrationForm(zipCode, loanAmount, loanPurpose, email,
				password, firstName, lastName, homeAddress, city, state, employmentStatus,
				yearlyIncome, dob);
		logger.info("Email address of the user: " + emailAddress);

		registrationPage.clickElectronicSignatureCheckBox();
		final PublicSiteOfferPage offerPage = registrationPage.clickGetYourRate(false, false);

		// Decline Page content check
		Assert.assertTrue(offerPage.isDeclinePageAppears(),
				"Decline should be thrown to the user having fico less than 640");

		final PublicSiteDeclinePage declinePage = offerPage.goToDeclinePage();
		PollingUtilities.sleep(4000);
		Assert.assertTrue(declinePage.isTextDisplayed(Constants.AMONE_PARTNER_DECLINE),
				"Decline Message is not correct");
		Assert.assertTrue(declinePage.isTextDisplayed(Constants.BASED_ON_CREDIT_DECLINE),
				"Decline Message is not correct");
		Assert.assertTrue(declinePage.isTextDisplayed(Constants.CONTINUE_ANYWAY_ON_DECLINE),
				"Decline Message is not correct");
		declinePage.clickOnProsperLogo();

		Assert.assertTrue(publicSitePreRegistrationPage.isBorrowerLandingPageDisplayed());

		// Navigate to History page through dropdown: a workaround due to NGMA-1006
		publicSitePreRegistrationPage.selectFromUserHeaderDropdown(HeaderOptions.HISTORY.getValue());

		// Navigate to Messages Page
		publicSitePreRegistrationPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.MESSAGES.getValue());
		final MessagesPage messagesPage = publicSitePreRegistrationPage.goToMessagesPage();
		// check url response for 503 or 400 bad request
		messagesPage.waitForPageToLoad("messages.aspx");
		if (!messagesPage.isLinkActive(messagesPage.getWindowLocationHref())) {
			messagesPage.reload();
		}
		// Verify message and navigate to View Messages Page
		final ViewMessagePage viewmessagesPage = messagesPage
				.verifyAndClickMessage(Constants.MessagesPage.CREDIT_SCORE_LOW_SUBJECT);
		messageId = viewmessagesPage.getMessageIdFromURL();

		// Verify message content
		viewmessagesPage.verifyMessageContent(
				getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				MessageBundle.getMessage("fico08CreditScoreBelow"));

		// To check HTML tags. Refer ticket BMP-2652
		Assert.assertFalse(viewmessagesPage.messageContains("<"));

		// Navigate to History Page
		viewmessagesPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());

		// Navigate to 'Event History' Page
		final AccountHistoryPage historyPage = publicSitePreRegistrationPage.goToHistoryPage();
		final PublicSiteEventHistoryPage eventHistoryPage = historyPage.clickEventHistoryLink();

		// Verify that appropriate events are displayed on the 'Event History'
		// page
		eventHistoryPage.verifyEventDisplayed(Constants.EventHistorypage.USERRECEIVEDMESSAGETYPE,
				Constants.EventHistorypage.CREDITSCORELOWEVENTNAME);
		eventHistoryPage.verifyEventDisplayed(eventHistoryPage.legalDocumentSavedEventType,
				Constants.EventHistorypage.AALETTERDETAILS);

		// Click on 'Adverse Action Letter' link displayed within event details
		// and verify Agreement Page content
		eventHistoryPage.clickOnLinkWithinEventDetail("adverseActionLetter_linktext");
		// switched to newly opened window
		eventHistoryPage.switchToNewlyOpenedWindow();
		Assert.assertTrue(eventHistoryPage.getAdverseActionLetterPageAsElement().getText()
				.contains(MessageBundle.getMessage("fico08CreditScoreBelow")));
		eventHistoryPage.switchToNewlyOpenedWindowUsingTitle(Constants.EventHistorypage.EVENT_HISTORY_PAGE_TITLE);

		// Navigate to History Page
		eventHistoryPage.selectFromUserHeaderDropdownDOTNET(HeaderOptions.HISTORY.getValue());
		final PublicSiteLegalAgreementsPage legalAgreementsPage = historyPage.clickLegalAgreementsLink();

		// Verify Agreement page content and get AgreementID from URL for
		// further use
		final String agreementId = legalAgreementsPage.verifyLinkAndAgreementContent(MessageBundle.getMessage("AALetter"),
				MessageBundle.getMessage("fico08CreditScoreBelow"));

		// Get user id
		final UserEmailDAO userEmail = circleOneDBConnection.getDataAccessObject(UserEmailDAO.class);
		final String userId = userEmail.getUserIDByEmail(email);

		// Verify the values displayed in table AdverseActionEvent
		final AdverseActionEventDAO adverseActionEventInfo = circleOneDBConnection
				.getDataAccessObject(AdverseActionEventDAO.class);
		Assert.assertEquals(adverseActionEventInfo.getAdverseActionEventTypeID(email),
				AdverseActionTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getAdverseActionEventTypeID());

		// Get 'AdverseActionEventID' from the query result
		final String adverseActionEventId = adverseActionEventInfo.getAdverseActionEventID(email);
		Assert.assertTrue(adverseActionEventInfo.doesMessageSentForAdverseActionUser(adverseActionEventId),
				"messagesent data should not be null");

		// Verify the values displayed in MessageSent tabl
		Assert.assertEquals(adverseActionEventInfo.getAgreementId(adverseActionEventId), Integer.parseInt(agreementId));

		Assert.assertEquals(adverseActionEventInfo.getMessageId(adverseActionEventId), Integer.parseInt(messageId));

		// Verify the values displayed in AdverseActionEventSquareCutInfo table
		Assert.assertEquals(adverseActionEventInfo.getSquareCutTypeID(adverseActionEventId),
				SquareCutTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getSquareCutTypeID());

		// Verify the values displayed in tblloanofferdecline table
		final LoanOfferDeclineDAO loanOfferDeclineInfo = circleOneDBConnection.getDataAccessObject(LoanOfferDeclineDAO.class);
		Assert.assertEquals(loanOfferDeclineInfo.getDeclineReasonID(userId),
				DeclineReasonTemplate.CREDIT_SCORE_TOOLOW_NEW_BORROWER.getDeclineReasonID());
		// Note: Message is not triggered instantly(https://saucelabs.com/beta/tests/b5354c6442a04e2da6f741b355e924b1/watch),
		// hence assert webmail box before validation of AA letter and message section
		// Email Verification
		verifyWebMail(outlookQAWebAppPage, "QA", email,
				getLowFicoLessThan640BorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
				MessageBundle.getMessage("infoAboutLoanRequest"), MessageBundle.getMessage("notEligibleForLoan"));
	}
}
