
package test.ui.pubsite.borrower.directToSite;

import com.prosper.automation.constant.Constant;
import com.prosper.automation.constant.test.TestGroup;
import com.prosper.automation.constant.web.Constants;
import com.prosper.automation.exception.AutomationException;
import com.prosper.automation.model.platform.marketplace.util.TestDataProviderUtil;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteLoanEstimatorPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteOfferPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePersonalDetailPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSitePreRegistrationPage;
import com.prosper.automation.pubsite.pages.borrower.PublicSiteRegistrationPage;
import com.prosper.automation.util.MonthlyPaymentCalculator;

import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import java.util.Map;

import test.ui.pubsite.borrower.dataExchange.DXCompleteListingTestBase;

/**
 * Created by rsubramanyam on 6/2/16.
 */
public class LoanEstimatorHomePageTest extends DXCompleteListingTestBase {

    private static final String LOAN_AMOUNT_VALIDAGTION_ERROR = "Your loan amount should be between 2000 and 35000.";
    private static final String CREDIT_SCORE_VALIDATION_ERROR = "Your credit score should be between 640 and 850.";
    private static final String TOOL_TIP_TEXT =
            "If your credit score is less than 640, you may not be eligible for a loan through Prosper at this time.";
    private static final String FOOTNOTE_TEXT =
            "*Your actual APR may be higher or lower than the APR we have estimated for you. Estimates are based off of the 20th - 80th percentile of actual Prosper users from March 2016 who share your self-selected FICO score and prospective loan amount.";
    private static final String NEXT_STEP_NOTE = "Like what you see? Take the next step.";
    private static final String ESTIMATE_HEADER = "Estimates Based on People Like You";
    private static final String ESTIMATE_YOUR_CREDIT_SCORE = "Estimate Your Credit Score";
    private static final String NOT_AFFECT_SCORE_TEXT ="We use this number to give you a rough estimate.";
    private static final String LOW_SCORE_TEXT = "your score is below 640";
    private static final String THREE_YEAR_TERM = "3-Year Term (Estimate*)";
    private static final String FIVE_YEAR_TERM = "5-Year Term (Estimate*)";
    private static final String APR = "APR";
    private static final String MONTHLY_PAYMENT = "MONTHLY PAYMENT";
    private static final String HOW_MUCH_DO_YOU_NEED = "How Much Do You Need?";
    @Resource
    PublicSitePreRegistrationPage loanEstimatorPreRegistrationPage;
    @Resource
    protected Map<String, String> pageElements;


    /**
     * GEAR-1080    Verify that details on register page gets prefilled for logged in user submitting 'loan estimate' drawer
     * GEAR-1078   Verify that filled 'loan amount' on the drawer is passed to the registration page
     * GEAR-1077   Verify that clicking on "Get my custom rate" CTA takes user to registration page
     * GEAR-1076   Verify that "Get my custom rate" CTA appears at the bottom of 'loan estimate' drawer
     * GEAR-1075   Verify that appropriate changes in 3 & 5 year sections displayed on making changes in loan amount selection bar in 'loan estimate' drawer
     * GEAR-1074   Verify that appropriate changes in 3 & 5 year sections displayed on changing credit score in 'loan estimate' drawer
     * GEAR-1072   Verify that loan amount selection bar is displayed on 'loan estimate' drawer
     * GEAR-1070   Verify that link 'I think my score is less than 640' is displayed in 'loan estimate' drawer
     * GEAR-1069   Verify that value in 'Estimate your credit score' textbox can not be decreased below 640
     * GEAR-1068   Verify that value in 'Estimate your credit score' textbox can not be increased after 850
     * GEAR-1067   Verify that 'Estimate your credit score' textbox displayes 640 value by default
     * GEAR-1066   Verify that 'Estimate your credit score' textbox is displayed on 'loan estimate' drawer
     * GEAR-1065   Verify that 'loan estimate' drawer closes on clicking the cross icon displayed on its top right corner
     * GEAR-1064   Verify that cross icon is displayed on top right corner of the 'loan estimate' drawer
     * GEAR-1062   Verify that clicking on 'Check Your Rate' CTA opens up 'loan estimate' drawer
     * GEAR-1061   Verify that 'Check Your Rate' CTA is displayed next to "Apply for a Loan" CTA
     *
     * @throws AutomationException
     * @throws InterruptedException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testLoanEstimatorFromHomePageFlow() throws AutomationException, InterruptedException {
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();

        // Check all static text displayed
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(FOOTNOTE_TEXT));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(NEXT_STEP_NOTE));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(ESTIMATE_HEADER));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(ESTIMATE_YOUR_CREDIT_SCORE));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(NOT_AFFECT_SCORE_TEXT));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(LOW_SCORE_TEXT));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(THREE_YEAR_TERM));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(FIVE_YEAR_TERM));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(APR));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(MONTHLY_PAYMENT));
        Assert.assertTrue(loanEstimatorPage.isStaticTextDisplayed(HOW_MUCH_DO_YOU_NEED));

        PublicSitePreRegistrationPage loanEstimatorPreRegPage = loanEstimatorPage.clickClose();
        loanEstimatorPage = loanEstimatorPreRegPage.clickGetYourFreeEstimate();
        loanEstimatorPreRegPage = loanEstimatorPage.clickTakeMeBack();
        loanEstimatorPage = loanEstimatorPreRegPage.clickGetYourFreeEstimate();

        // Default values
        Assert.assertEquals(loanEstimatorPage.getLoanAmountMin(), "$2,000");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountMax(), "$35,000");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreMin(), "640");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreMax(), "850");
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$18,500");
        Assert.assertEquals(loanEstimatorPage.getCreditScore(), "640");

        // Change loan amount and credit score
        loanEstimatorPage.moveLoanAmountSlider(4000);
        loanEstimatorPage.moveCreditScoreSlider(1000);
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$35,000");
        Assert.assertEquals(loanEstimatorPage.getCreditScore(), "850");

        Assert.assertEquals(loanEstimatorPage.getLoanEstimatorTooltipText().trim(), TOOL_TIP_TEXT);

        loanEstimatorPage.enterLoanAmount("5000");
        loanEstimatorPage.enterCreditScore("800");

        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$5,000");
        Assert.assertEquals(loanEstimatorPage.getCreditScore(), "800");

        // Verify calculated monthly payments since APR is calculated at the backend
        String visibleFiveYearApr = loanEstimatorPage.getFiveYearEstimatedApr().replace("%", "").replace("$", "");
        String visibleThreeYearApr = loanEstimatorPage.getThreeYearEstimatedApr().replace("%", "").replace("$", "");
        String visibleFiveYearMonthlyPayment =
                loanEstimatorPage.getFiveYearEstimatedMonthlyPayment().replace("%", "").replace("$", "");
        String visibleThreeYearMonthlyPayment =
                loanEstimatorPage.getThreeYearEstimatedMonthlyPayment().replace("%", "").replace("$", "");
        Double fiveYearExpectedMonthlypayment =
                MonthlyPaymentCalculator.calculateMonthlyPayment(5000.0, Double.valueOf(visibleFiveYearApr) / 100, 5 * 12);
        Assert.assertTrue(fiveYearExpectedMonthlypayment.toString().contains(
                String.valueOf(Double.valueOf(visibleFiveYearMonthlyPayment).intValue())));
        Double threeYearExpectedMonthlypayment =
                MonthlyPaymentCalculator.calculateMonthlyPayment(5000.0, Double.valueOf(visibleThreeYearApr) / 100, 3 * 12);
        Assert.assertTrue(threeYearExpectedMonthlypayment.toString().contains(
                String.valueOf(Double.valueOf(visibleThreeYearMonthlyPayment).intValue())));

        PublicSiteRegistrationPage registrationPage = loanEstimatorPage.clickGetCustomRate();
        registrationPage.getWindowLocationHref().contains("registration");
        Assert.assertEquals(registrationPage.getPrefilledLoanAmount(), "5000");
    }

    /**
     *
     * GEAR-1158 Verify that loan amount cannot be less than 2000 and more than 35000
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testBoundaryCheckLoanAmount() throws AutomationException {
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        loanEstimatorPage.enterLoanAmount("1999");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountValidationError(), LOAN_AMOUNT_VALIDAGTION_ERROR);
        loanEstimatorPage.sendEscapeToLoanAmountInput();

        loanEstimatorPage.enterLoanAmount("35001");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountValidationError(), LOAN_AMOUNT_VALIDAGTION_ERROR);
        loanEstimatorPage.sendEscapeToLoanAmountInput();

        loanEstimatorPage.enterLoanAmount("-1");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountValidationError(), LOAN_AMOUNT_VALIDAGTION_ERROR);
        loanEstimatorPage.sendEscapeToLoanAmountInput();

        loanEstimatorPage.enterLoanAmount("A");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountValidationError(), LOAN_AMOUNT_VALIDAGTION_ERROR);
        loanEstimatorPage.sendEscapeToLoanAmountInput();

        loanEstimatorPage.enterLoanAmount("2000");
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$2,000");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountMin(), "$2,000");

        loanEstimatorPage.enterLoanAmount("35000");
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$35,000");
        Assert.assertEquals(loanEstimatorPage.getLoanAmountMax(), "$35,000");
        PublicSiteRegistrationPage registrationPage = loanEstimatorPage.clickGetCustomRate();
        registrationPage.getWindowLocationHref().contains("registration");
        logger.info("GEAR-1158 Verify that loan amount cannot be less than 2000 and more than 35000");
    }

    /**
     * GEAR-1069 Verify that value in 'Estimate your credit score' textbox can not be decreased below 640
     * GEAR-1068 Verify that value in 'Estimate your credit score' textbox can not be increased after 850
     * GEAR-1067 Verify that 'Estimate your credit score' textbox displayes 640 value by default
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testBoundaryCheckCreditScore() throws AutomationException {
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        loanEstimatorPage.enterCreditScore("639");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreValidationError(), CREDIT_SCORE_VALIDATION_ERROR);
        loanEstimatorPage.sendEscapeToCreditScoreInput();

        loanEstimatorPage.enterCreditScore("851");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreValidationError(), CREDIT_SCORE_VALIDATION_ERROR);
        loanEstimatorPage.sendEscapeToCreditScoreInput();

        loanEstimatorPage.enterCreditScore("-1");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreValidationError(), CREDIT_SCORE_VALIDATION_ERROR);
        loanEstimatorPage.sendEscapeToCreditScoreInput();

        loanEstimatorPage.enterCreditScore("A");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreValidationError(), CREDIT_SCORE_VALIDATION_ERROR);
        loanEstimatorPage.sendEscapeToCreditScoreInput();

        loanEstimatorPage.enterCreditScore("640");
        Assert.assertEquals(loanEstimatorPage.getCreditScore(), "640");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreMin(), "640");
        loanEstimatorPage.enterCreditScore("850");
        Assert.assertEquals(loanEstimatorPage.getCreditScore(), "850");
        Assert.assertEquals(loanEstimatorPage.getCreditScoreMax(), "850");
        PublicSiteRegistrationPage registrationPage = loanEstimatorPage.clickGetCustomRate();
        registrationPage.getWindowLocationHref().contains("registration");
    }

    /**
     *
     * GEAR-1080 Verify that details on register page gets prefilled for logged in user submitting 'loan estimate' drawer
     *
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testPrefilledData() throws AutomationException {
        String originUrl = loanEstimatorPreRegistrationPage.getOriginUrlWithScheme();
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        loanEstimatorPage.enterLoanAmount("8000");
        PublicSiteRegistrationPage registrationPage = loanEstimatorPage.clickGetCustomRate();
        registrationPage.getWindowLocationHref().contains("registration");
        Assert.assertEquals(registrationPage.getPrefilledLoanAmount(), "8000");
        final String email = TestDataProviderUtil.getUniqueEmailIdForTest("auto");
        registrationPage.fillRegistrationForm(getPrimeBorrowerData().get(Constants.RegisterationPageConstants.ZIPCODE_TAG),
                null, getCommonTestData().get(Constants.HomeWidgetPage.LOANPURPOSER_TAG), email,
                Constant.COMMON_PASSWORD, getPrimeBorrowerData().get(Constants.RegisterationPageConstants.FIRSTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.LASTNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STREETNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.CITYNAME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.STATE_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.EMPLOYMENTSTATUS_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.YEARLYINCOME_TAG),
                getPrimeBorrowerData().get(Constants.RegisterationPageConstants.DATEOFBIRTH_TAG));

        registrationPage.clickElectronicSignatureCheckBox();
        PublicSiteOfferPage offersPage = registrationPage.clickGetYourRate(false, false);
        PublicSitePersonalDetailPage personalDetailsPage = offersPage.clickGetLoan();
        personalDetailsPage.goTo(originUrl);
        loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        loanEstimatorPage.enterLoanAmount("9000");
        registrationPage = loanEstimatorPage.clickGetCustomRate();
        registrationPage.getWindowLocationHref().contains("registration");
        Assert.assertEquals(registrationPage.getPrefilledLoanAmount(), "9000");
        logger.info(
                "GEAR-1080 Verify that details on register page gets prefilled for logged in user submitting 'loan estimate' drawer");
    }

    /**
     * GEAR-1079 Verify that by default selected $18,500 'loan amount' on the drawer is passed to the registration page GEAR-1073
     * Verify that default value in loan amount selection bar is displayed as $18,500 on 'loan estimate' drawer
     *
     * @throws AutomationException
     */
    @Test(groups = {TestGroup.ACCEPTANCE})
    public void testDefaultPrefillRegPageAfterLoanEstimator() throws AutomationException {
        PublicSiteLoanEstimatorPage loanEstimatorPage = loanEstimatorPreRegistrationPage.clickGetYourFreeEstimate();
        Assert.assertEquals(loanEstimatorPage.getloanAmount(), "$18,500");
        logger.info(
                "GEAR-1073 Verify that default value in loan amount selection bar is displayed as $18,500 on 'loan estimate' drawer");

        PublicSiteRegistrationPage registrationpage = loanEstimatorPage.clickGetCustomRate();
        Assert.assertEquals(registrationpage.getPrefilledLoanAmount(), "18500");
        logger.info(
                "GEAR-1079 Verify that by default selected $18,500 'loan amount' on the drawer is passed to the registration page");

    }
}
